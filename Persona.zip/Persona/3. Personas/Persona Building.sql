select min(len(SSN)), max(len(SSN))
from ANALYTICS.DBO.ChannelUsageClusters_093023


update ANALYTICS.DBO.ChannelUsageClusters_093023
set SSN = case when len(SSN) = 1 then CONCAT('00000000',SSN)
					when len(SSN) = 2 then CONCAT('0000000',SSN)
					when len(SSN) = 3 then CONCAT('000000',SSN)
					when len(SSN) = 4 then CONCAT('00000',SSN)
					when len(SSN) = 5 then CONCAT('0000',SSN)
					when len(SSN) = 6 then CONCAT('000',SSN)
					when len(SSN) = 7 then CONCAT('00',SSN)
					when len(SSN) = 8 then CONCAT('0',SSN)
				else SSN
			end 

SELECT TOP 20 ["SSN"]
	,updated_clusters
	,'MULTI CHANNEL ORIENTED' CLUSTER_NAME
	,["ACH_E_TRN_AMOUNT_6M"]
	,["ATM_A_TRN_AMOUNT_6M"]
	,["BILLPAY_B_TRN_AMOUNT_6M"]
	,["CASH_C_TRN_AMOUNT_6M"]
	,["CHECK_K_TRN_AMOUNT_6M"]
	,["DEBITCARD_G_TRN_AMOUNT_6M"]
	,["DRAFT_D_TRN_AMOUNT_6M"]
	,["HOMEBANKING_H_TRN_AMOUNT_6M"]
	,["KIOSK_S_TRN_AMOUNT_6M"]
	,["POS_O_TRN_AMOUNT_6M"]
	,["WIRE_M_TRN_AMOUNT_6M"]
	,["ZELLE_Z_TRN_AMOUNT_6M"]
	,["TOTAL_TRN_AMOUNT_6M"]
FROM Analytics..ChannelUsageClusters_033123
WHERE updated_clusters = 6


declare @date as date = (select EOMONTH(DATEADD(MM,-1,(MAX(DATEFROMPARTS(LEFT(processdate,4),LEFT(RIGHT(processdate,4),2),RIGHT(processdate,2)))))) from ..NAME)

DROP TABLE IF EXISTS #ACTIVE_ACCOUNTS
SELECT SSN
	,n.PARENTACCOUNT
	,a.ACCOUNTNUMBER
	,BIRTHDATE
	,a.OPENDATE
	,ROW_NUMBER() over (partition by SSN order by a.opendate) as opendate_rownum
	,DATEDIFF(MM, A.OPENDATE, @date) AS MOB
	,A.ESTMTENABLE AS ESTMTENABLE
	,S.PARENTACCOUNT AS SHARE_ACCOUNT_NUMBER
	,S.ID AS SHARE_ID
	,S.TYPE AS SHARE_TYPE
	,S.DESCRIPTION AS SHARE_DESCRIPTION
	,L.PARENTACCOUNT AS LOAN_ACCOUNT_NUMBER
	,L.ID  AS LOAN_ID
	,L.TYPE AS LOAN_TYPE
	,L.DESCRIPTION AS LOAN_DESCRIPTION
INTO #ACTIVE_ACCOUNTS
FROM ..NAME N
LEFT JOIN ..ACCOUNT A
	ON N.PARENTACCOUNT = A.ACCOUNTNUMBER
	AND N.ProcessDate = A.ProcessDate
LEFT JOIN ..LOAN L
	ON N.PARENTACCOUNT = L.PARENTACCOUNT
	AND N.ProcessDate = L.ProcessDate
LEFT JOIN ..SAVINGS S
	ON N.PARENTACCOUNT = S.PARENTACCOUNT
	AND N.ProcessDate = S.ProcessDate
WHERE DATEFROMPARTS(LEFT(N.ProcessDate,4),LEFT(RIGHT(N.ProcessDate,4),2),RIGHT(N.ProcessDate,2)) = @date
	AND N.TYPE = 0 --FOR PRIME MEMBERS FROM NAME TABLE
	AND A.CLOSEDATE IS NULL
	AND S.CLOSEDATE IS NULL
	AND L.CLOSEDATE IS NULL
	AND A.TYPE = 0 --FOR GENERAL MEMBERSHIP FROM ACCOUNT TABLE
	AND N.SSNType = 0 --FOR INDIVIDUAL SSNTYPE
	AND A.COMMERCIALCODE = 0 --FOR CONSUMER ACCOUNTTYPE
	AND N.DEATHDATE IS NULL
	AND EXPIRATIONDATE IS NULL
	AND L.CHARGEOFFDATE IS NULL --LOAN CHARGE-OFF
	AND S.CHARGEOFFDATE IS NULL --SHARE CHARGE-OFF


-----********** CONSIDERING ONLY THOSE MEMBERS WITH MOB>=12 AS MEMBER BASE FOR PERSONAS **********-----
--declare @date as date = (select EOMONTH(DATEADD(MM,-1,(MAX(DATEFROMPARTS(LEFT(processdate,4),LEFT(RIGHT(processdate,4),2),RIGHT(processdate,2)))))) from ..NAME)
DROP TABLE IF EXISTS #MEMBER_BASE
SELECT DISTINCT SSN
INTO #MEMBER_BASE
FROM #ACTIVE_ACCOUNTS
WHERE EOMONTH(OPENDATE) <= EOMONTH(DATEADD(MM, -12, @date))


--- CALCULATING AGE AND MOB
DROP TABLE IF EXISTS #AGE_MOB
SELECT SSN
	,MAX(DATEDIFF(YY,BIRTHDATE,GETDATE())) AS AGE
	,MAX(DATEDIFF(MM,OPENDATE,GETDATE())) AS MOB
INTO #AGE_MOB
FROM #ACTIVE_ACCOUNTS
WHERE SSN IN (SELECT SSN FROM #MEMBER_BASE)
GROUP BY SSN


-----********** CREDIT CARD DATA **********-----
--declare @date as date = (select EOMONTH(DATEADD(MM,-1,(MAX(DATEFROMPARTS(LEFT(processdate,4),LEFT(RIGHT(processdate,4),2),RIGHT(processdate,2)))))) from ..NAME)
DECLARE @date_cc AS VARCHAR(6) =(Select max(extract_datepart) from TMGData.dbo.cardholder)
DECLARE @DATE_CC_6M AS VARCHAR(6)=(SELECT CASE WHEN RIGHT(MAX(extract_datepart),2)<=5 THEN MAX(extract_datepart) - 93 ELSE MAX(extract_datepart) - 5 END AS DATE_6M
									FROM TMGData.dbo.cardholder )


DROP TABLE IF EXISTS #1
SELECT  
      DISTINCT [Social Security Number]
INTO #1
FROM [TMGData].[DBO].[cardholder] WITH (NOLOCK)

WHERE EXTRACT_DATEPART = @date_cc

	AND [Social Security Number] IS NOT NULL and [Social Security Number]<>0

	AND Active_Flag = 1

	AND  [External Status Code] in ('') and [Internal Status Code] in ('','N')

	--select * from  #1 order by [Social Security Number]

DROP TABLE IF EXISTS #CC_HOLDERS
SELECT [Social Security Number] AS MEMBER_ID

	,COUNT(DISTINCT [MASTER ACCOUNT KEY]) AS TOTAL_CARDS

INTO #CC_HOLDERS

FROM  [TMGData].[DBO].[cardholder]  WITH (NOLOCK)

WHERE 1=1
	AND [Social Security Number] IS NOT NULL
	AND [Social Security Number] IN (SELECT [Social Security Number] FROM #1)
	AND Active_Flag = 1
	AND EXTRACT_DATEPART = @date_cc
	AND [External Status Code] not IN ('C') and [Internal Status Code] in ('','N')
GROUP BY [Social Security Number]

drop table if exists #product_holding
select SSN
	,MAX(case when b.ShareCategory3 = 'IRA' THEN 1 ELSE 0 END) AS IRA
	,MAX(case when b.ShareCategory2 = 'CD' AND ShareCategory3 = '' THEN 1 ELSE 0 END) AS CD
	,MAX(case when b.ShareCategory2 = 'Checking' AND ShareCategory3 = '' THEN 1 ELSE 0 END) AS Checking
	,MAX(case when b.ShareCategory2 = 'Money Market' AND ShareCategory3 = '' THEN 1 ELSE 0 END) AS [Money Market]
	,MAX(case when b.ShareCategory2 = 'Savings' AND ShareCategory3 = '' THEN 1 ELSE 0 END) AS Savings
	,MAX(case when c.LoanCategory3 = '1st Mortgage' THEN 1 ELSE 0 END) AS [1st Mortgage]
	,MAX(case when c.LoanCategory3 = '2nd Mortgage' THEN 1 ELSE 0 END) AS [2nd Mortgage]
	,MAX(case when c.LoanCategory3 = 'Indirect' THEN 1 ELSE 0 END) AS Indirect
	,MAX(case when c.LoanCategory3 = 'OTC' THEN 1 ELSE 0 END) AS OTC
	,MAX(case when c.LoanCategory3 = 'Secured' THEN 1 ELSE 0 END) AS Secured
	,MAX(case when c.LoanCategory3 = 'Small Business' THEN 1 ELSE 0 END) AS [Small Business]
	,MAX(case when c.LoanCategory3 = 'Unsecured' THEN 1 ELSE 0 END) AS Unsecured
	,MAX(case when c.LoanCategory3 = 'Writeoff' THEN 1 ELSE 0 END) AS Writeoff
	,MAX(case when d.TOTAL_CARDS > 0 THEN 1 ELSE 0 END) AS [Credit Card]
into #product_holding
from #ACTIVE_ACCOUNTS a
left join ARCUSYM000.arcu.ARCUShareCategory b
	on a.SHARE_TYPE = b.ShareType
left join ARCUSYM000.arcu.ARCUloanCategory c
	on a.loan_TYPE = c.loanType
left join #CC_HOLDERS d
	on a.SSN = d.MEMBER_ID
group by SSN


DROP TABLE IF EXISTS Analytics.DBO.PERSONAS_093023
SELECT EXTRACT_DATE
	,A.MEMBER_ID
	,case when eng_groups = 'Latents' and updated_clusters in (1,2,3,4,5,6) then 'Persona 1'
		when eng_groups = 'Potentialists' and updated_clusters in (1,2) then 'Persona 2'
		when eng_groups = 'Potentialists' and updated_clusters in (3,4,5,6) then 'Persona 3'
		when (eng_groups = 'Associates' and updated_clusters = 1 ) then 'Persona 4'
		when eng_groups = 'Associates' and updated_clusters in (4,5) then 'Persona 5'
		when (eng_groups = 'Associates' and updated_clusters in (3,6)) 
		or (eng_groups = 'Loyalists' and updated_clusters = 3) then 'Persona 7'
		when (eng_groups = 'Loyalists' and updated_clusters in (4,5)) 
		or (eng_groups = 'Champions' and updated_clusters = 5) then 'Persona 8'
		when (eng_groups = 'Associates' and updated_clusters = 2) 
		or (eng_groups = 'Loyalists' and updated_clusters in (1,2)) then 'Persona 6'
		when (eng_groups = 'Champions' and updated_clusters = 4) 
		or (eng_groups = 'Loyalists' and updated_clusters = 6) then 'Persona 9'
		when (eng_groups = 'Champions' and updated_clusters in (1,2,3,6)) then 'Persona 10'
	end as Persona
	,AGE
	,case when Age >=0 and Age <10 then 'Alpha Generation'
 when Age >=10 and Age <=20 then 'Generation Z'
 when Age >=21 and Age <=40 then 'Millennials'
 when Age >=41 and Age <=55 then 'Generation X'
 when Age >=56 and Age <=74 then 'Baby Boomers'
  when Age >=75 and Age <=95 then 'Silent Generation'
 when Age >=96 and Age <=120 then 'Greatest Generation'
 else 'N/A' end AgeBand
	,MOB
	,case when MOB between 0 and 12 then '0-1 Year'
 when MOB between 13 and 24 then '1-2 Years'
 when MOB between 25 and 36 then '2-3 Years'
 when MOB between 37 and 48 then '3-4 Years'
 when MOB between 49 and 60 then '4-5 Years'
 when MOB between 61 and 72 then '5-10 Years'
 when MOB >=73 then '10+ Years'
  else 'N/A'
  end MOBBands
	,A.ACTIVE_DEPOSIT_ACCOUNTS
	,A.ACTIVE_LOAN_ACCOUNTS
	,A.AVG_DEPOSIT_BALANCE_6M
	,A.AVG_DEPOSIT_TRAN_AMOUNT_6M
	,A.AVG_DEPOSIT_TRAN_COUNT_6M
	,A.AVG_LOAN_TRAN_AMOUNT_6M
	,A.AVG_LOAN_TRAN_COUNT_6M
	,A.ESTATEMENT_ENABLED_FLAG
	,A.HOMEBANKING_FLAG
	,A.MobileBanking_FLAG
	,A.TOTAL_ACCESS_CHANNELS_6M
	,B.eng_bands
	,B.eng_bands_id
	,B.eng_groups
	,B.eng_group_id
	,B.ENG_Score
	,B.ENG_Score_Scaled
	,c.[clusters classification]
	,c.updated_clusters
	,C.ACH_E_TRN_AMOUNT_6M
	,C.ACH_E_TRN_AMOUNT_6M_DEP
	,C.ATM_A_TRN_AMOUNT_6M
	,C.ATM_A_TRN_AMOUNT_6M_DEP
	,C.BILLPAY_B_TRN_AMOUNT_6M
	,C.BILLPAY_B_TRN_AMOUNT_6M_DEP
	,C.CASH_C_TRN_AMOUNT_6M
	,C.CASH_C_TRN_AMOUNT_6M_DEP
	,C.CHECK_K_TRN_AMOUNT_6M
	,C.CHECK_K_TRN_AMOUNT_6M_DEP
	,C.DEBITCARD_G_TRN_AMOUNT_6M
	,C.DEBITCARD_G_TRN_AMOUNT_6M_DEP
	,C.DRAFT_D_TRN_AMOUNT_6M
	,C.DRAFT_D_TRN_AMOUNT_6M_DEP
	,C.HOMEBANKING_H_TRN_AMOUNT_6M
	,C.HOMEBANKING_H_TRN_AMOUNT_6M_DEP
	,C.KIOSK_S_TRN_AMOUNT_6M
	,C.KIOSK_S_TRN_AMOUNT_6M_DEP
	,C.POS_O_TRN_AMOUNT_6M
	,C.POS_O_TRN_AMOUNT_6M_DEP
	,C.TOTAL_TRN_AMOUNT_6M
	,C.TOTAL_TRN_AMOUNT_6M_DEP
	,C.WIRE_M_TRN_AMOUNT_6M
	,C.WIRE_M_TRN_AMOUNT_6M_DEP
	,C.ZELLE_Z_TRN_AMOUNT_6M
	,C.ZELLE_Z_TRN_AMOUNT_6M_DEP
	,e.CD
	,e.Checking
	,e.IRA
	,e.[Money Market]
	,e.Savings
	,e.[1st Mortgage]
	,e.[2nd Mortgage]
	,e.[Credit Card]
	,e.Indirect
	,e.OTC
	,e.Secured
	,e.[Small Business]
	,e.Unsecured
	,e.Writeoff
INTO Analytics.DBO.PERSONAS_093023
FROM Analytics.DBO.COE_BT_MEMBER_PROFILE_0930 A
LEFT JOIN Analytics.DBO.COE_ENG_GROUPS_0930 B
	ON A.MEMBER_ID = B.MEMBER_ID
LEFT JOIN Analytics.DBO.ChannelUsageClusters_093023 C
	ON A.MEMBER_ID = C.SSN
LEFT JOIN #AGE_MOB D
	ON A.MEMBER_ID = D.SSN
LEFT JOIN #product_holding E
	ON A.MEMBER_ID = E.SSN

select Persona
	,count(*)
from Analytics.dbo.PERSONAS_033123
group by Persona
order by 1

select Persona
	,count(*)
from Analytics.dbo.PERSONAS_093023
group by Persona
order by 1



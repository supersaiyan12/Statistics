SELECT Persona_Name, COUNT(*)
FROM PERSONAS_033123
GROUP BY Persona_Name
ORDER BY 1

ALTER TABLE PERSONAS_033123
ADD Persona_Name VARCHAR(50)


UPDATE PERSONAS_033123
SET Persona_Name = 'Lost Luke'
where Persona = 'Persona 1'

UPDATE PERSONAS_033123
SET Persona_Name = 'Lost Luke'
where Persona = 'Persona 1'

UPDATE PERSONAS_033123
SET Persona_Name = 'Elsewhere Eric'
where Persona = 'Persona 2'

UPDATE PERSONAS_033123
SET Persona_Name = 'Naive Nova'
where Persona = 'Persona 3'

UPDATE PERSONAS_033123
SET Persona_Name = 'Moderate Maeve'
where Persona = 'Persona 4'

UPDATE PERSONAS_033123
SET Persona_Name = 'Transacting Tom'
where Persona = 'Persona 5'

UPDATE PERSONAS_033123
SET Persona_Name = 'Preserving Parker'
where Persona = 'Persona 6'

UPDATE PERSONAS_033123
SET Persona_Name = 'Two Product Tina'
where Persona = 'Persona 7'

UPDATE PERSONAS_033123
SET Persona_Name = 'Card Ready Cathy'
where Persona = 'Persona 8'

UPDATE PERSONAS_033123
SET Persona_Name = 'Committed Cory'
where Persona = 'Persona 9'

UPDATE PERSONAS_033123
SET Persona_Name = 'Wise Willy'
where Persona = 'Persona 10'
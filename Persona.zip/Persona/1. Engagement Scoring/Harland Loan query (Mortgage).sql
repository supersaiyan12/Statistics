

declare @staticpooldate date
		declare @staticpooldate2 date
		declare @staticpooldate3 date
		set  @staticpooldate= (select datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Processdate from
	(select max(ProcessDate) processdate from ARCUSYM000..LOAN) A)
set  @staticpooldate2 = (Select case when @staticpooldate = EOMONTH(@staticpooldate) then @staticpooldate else EOmonth(DATEADD(Month,-1,@staticpooldate)) end)
set  @staticpooldate3 = (select dateadd(month,-35,@staticpooldate2))


drop table if exists #processdate
select process_date,max(ProcessDate) max_ProcessDate,max([process date]) [process date]
into #processdate
		from (select ProcessDate,left(ProcessDate,6) process_date ,datefromparts(left(processdate,4),right(left(processdate,6),2),RIGHT(processdate,2)) [process date]
				from ARCUSYM000..loan) A
where [process date]>=@staticpooldate3 and [process date]<=@staticpooldate2
group by process_date


Drop table if exists #mortgagedelinquency1
		Select *
		into #mortgagedelinquency1
		from 
		(
		SELECT 
        case when datediff(d, h.duedate, DateAdd(month, -1, eomonth(cutoffdate)))  < 30 then 'New' end New30Flag
		,case when datediff(d, h.duedate, DateAdd(month, -1, eomonth(cutoffdate)))  between 30 and 60 then 'New' end New61Flag
                ,h.loanid,InvestorID MortgageDescription
	,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and datediff(d, h.duedate, eomonth(cutoffdate)) < 30 then 1 else 0  end [DQ 1+ Days Flag]
    ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 30 and datediff(d, h.duedate, eomonth(cutoffdate)) < 60 then 1 else 0  end [DQ 30+ Days Flag]
    ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 60 and datediff(d, h.duedate, eomonth(cutoffdate)) < 90 then 1 else 0  end [DQ 60+ Days Flag]
	,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 90 and datediff(d, h.duedate, eomonth(cutoffdate)) < 120 then 1 else 0  end [DQ 90+ Days Flag]
	,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 120 and datediff(d, h.duedate, eomonth(cutoffdate)) < 150 then 1 else 0  end [DQ 120+ Days Flag]
    ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 150 and datediff(d, h.duedate, eomonth(cutoffdate)) < 179 then 1 else 0  end [DQ 150+ Days Flag]
	,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 180 and datediff(d, h.duedate, eomonth(cutoffdate)) < 359 then 1 else 0  end [DQ 180+ Days Flag]
	,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 360 then 1 else 0  end [DQ 360+ Days Flag]
    ,h.duedate NextDueDate,lastpmtrecd,cast(CutoffDate as date) CutoffDate,MortgageOpenDate,InvestorPrinBal,CurrentBalance Balance
    ,datediff(d, h.duedate, eomonth(cutoffdate)) DQDays
	,Case when len(MONTH(CutoffDate)) = 1 then CONCAT(YEAR(cutoffdate),0,month(cutoffdate))
	else CONCAT(YEAR(cutoffdate),month(cutoffdate)) end as extract_date 
	FROM [UICCU].[dbo].[HarlandLoanCutoff] h
    left join ae_edw.dbo.f_mortgage f on f.mortgageid = h.loanid and month(reportmonth) = month(cutoffdate)
                                    and year(reportmonth) = year(cutoffdate)
	WHERE CutoffDate in (select [process date] from #processdate) and
	loanprincipalbal > 0 AND RegPrincipalColl != investorprinbal AND (investorid LIKE '%bal' or investorid LIKE '%fix%' or investorid LIKE '%arm' or
								investorid LIKE 'E-10YR' or investorid LIKE 'E-WORK' or InvestorID like '%Equity%' or InvestorID like '%TDR%' or
								InvestorID = 'F-ARM' or InvestorID = 'FAB-HH' )
               and investorprinbal is not null
               and datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and RecordType <> 2
		)T 
			   where CutoffDate between @staticpooldate3 and @staticpooldate2
install.packages("RODBC")
install.packages("odbc")
install.packages("DBI")
install.packages("rstudioapi")
install.packages("caret")
install.packages("mclust")
install.packages("psych")
install.packages("tidyverse")
library(psych)
library(tidyverse)
library(mclust)
library(caret)
library(RODBC)
library(DBI)
library(odbc)


# Making SQL connection with RStudio
connection <- odbcDriverConnect("Driver= {SQL Server};
                              server=acarcu01;
                              database=Analytics;
                              trusted_connection=TRUE")

# Using the required data                             
data <- sqlQuery(connection, "select * from Channel_Usage_Segmentation_DRIFT")

# Removing Member_ID column for clustering
dataset <- data[,-1]

# Dropping variables with 0 variance
data1 <- dataset[-as.numeric(which(apply(dataset,2,var)==0))]


# ONLY CONSIDERING FLAG AND WD VARIABLES
data2 <- data1[,2:115]

### Clustering ###

# Data Normalization

preproc <- preProcess(data2,method = "range")

norm <- predict(preproc, data2)
summary(norm)

# Building the cluster model
?Mclust


clusters <- Mclust(norm,9)
clusters
summary(clusters)
plot(clusters, what = c("BIC","Classification"))

clusters$classification
norm

data_final <- data.frame(clusters$classification, data)
data_final


# Exporting the model output to CSV file

write.csv(data_final,
          "Z:\\cu rise\\CU Rise Workspace\\Asfiya\\1. Persona Development\\2. Channel Usage Segmentation\\ChannelUsageClusters_9_WDs2_Drift.csv",
          row.names = FALSE)


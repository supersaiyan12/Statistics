
 --Date: 6th Apr 2021
--Change the static pool month from entire code....
	drop table if exists #temp0
	drop table if exists #temp1
	drop table if exists #temp_pre_12mo_2
	drop table if exists #temp_pre_12mo_3
	drop table if exists #temp_pre_12mo_3a
	drop table if exists #temp_pre_12mo_4
	
	drop table if exists #temp_pre_to_pre_6mo_2
	drop table if exists #temp_pre_to_pre_6mo_3
	drop table if exists #temp_pre_6mo_2
	drop table if exists #temp_pre_6mo_3
	drop table if exists #temp_pre_6mo_3a
	drop table if exists #temp_pre_6mo_3b
	drop table if exists #temp_pre_6mo_4

	drop table if exists #temp_post_12mo_2
	drop table if exists #temp_post_12mo_3
	drop table if exists #temp_post_12mo_3a
	drop table if exists #temp_post_12mo_4
	
	drop table if exists #temp2
	drop table if exists #temp3
	drop table if exists #temp4
	drop table if exists #temp5
	drop table if exists #temp6
	drop table if exists #temp7
	drop table if exists #temp8
	drop table if exists #temp9
	drop table if exists #temp10

  drop table if exists #temp0
  select Durable_Key,Offer,'2020' as flag
  into #temp0
  FROM [Analytics].[sadam].[GreenState_CU_Rise_BT_Campaign_Targetlist_06172020]
  union all
  select Durable_Key,Offer,'2019' as flag
  FROM [Analytics].[brijesh].[UICCU_CU_Rise_BT_Campaign_Targetlist_05242019]
  union all
  select Durable_Key,Offer,'2021' as flag
  FROM [Analytics].[brijesh].[GreenState_Trellance_BT_Campaign_Targetlist_06012021]
  order by flag

  go

 

	--select distinct [Card Description] FROM [TMGData].[dbo].[cardholder] where  Extract_DatePart = 201812
	--select max(Extract_DatePart) FROM [TMGData].[dbo].[cardholder] where  Extract_DatePart = 201812
	--static pool data
	drop table if exists #temp1
	select Durable_Key,[Master Account Key],[Social Security Number],[Account Number],
	[Credit Limit],mob,[Card Description],
	[Credit Limit] - [Last Statement Balance Amount] as Open_To_Buy,
	[External Status Code],[Internal Status Code] ,[Calc Norm Cash Annual Rate],
	[Last Statement Balance Amount],RevolvingBalance,age,
	([Last Statement Sale Amount]-[Last Statement Return Amount]) as spend,
	TRIPFLAG,[Last Statement Payment Amount], Extract_DatePart as sp_month
    into #temp1
	FROM [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and Durable_Key in 
	(select Durable_Key from #temp0 where flag = '2021')
	and extract_datepart = 202104
	--select * from #temp1

	go
	--Step 1: Pre 12 month numbers'
	--drop table if exists #
	select Durable_Key as d_pre_12mo,
	--sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_12mo,
	--sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_12mo,
	--sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_12mo,
	--sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_12mo,
	--sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_12mo,
	--sum([Last Statement Balance Amount]) as sum_bal_pre_12mo,
	--sum(RevolvingBalance) as sum_revbal_pre_12mo,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_12mo,
	avg([Last Statement Balance Amount]) as avg_bal_pre_12mo,
	avg(RevolvingBalance) as avg_revbal_pre_12mo,
	avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_12mo,
	sum(case when TRIPFLAG='T' then 1 else 0 end) Transactor_Pre_12mo,
	sum(case when extract_datepart= 202104 then [Last Statement Balance Amount] else 0 end) as statement_balance_sp,
	sum(case when extract_datepart= 202010 then [Last Statement Balance Amount] else 0 end) as statement_balance_6mon_back,
	sum(case when extract_datepart= 202005 then [Last Statement Balance Amount] else 0 end) as statement_balance_12mon_back,
	sum(case when extract_datepart= 202104 then [Last Statement Balance Amount] else 0 end) as Revolving_balance_sp,
	sum(case when extract_datepart= 202010 then [RevolvingBalance] else 0 end) as Revolving_balance_6mon_back,
	sum(case when extract_datepart= 202005 then [RevolvingBalance] else 0 end) as Revolving_balance_12mon_back
	into #temp_pre_12mo_2
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 --and [Card Description] not in ('Mastercard Business')
	and Extract_DatePart between 202104 - 99 and 202104
	and Durable_Key in 
	(select Durable_Key from #temp1)
	group by Durable_Key

	go

	--Pre 12 month Profit numbers
	drop table if exists #temp_pre_12mo_3
	select Durable_Key,Extract_DatePart,
	case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization,
	case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate,
	case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate,
	
	([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income,
	([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees,
	([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income,    
	([Last Statement Balance Amount]*0.02/12) as COF,
	(ChargeoffAmount_final) as chgoff_amt,
	case when [Card Description] in ('MasterCard Platinum Rewards','MasterCard World Credit') 
	then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end as rewards_expense,
	([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense,
	case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost
	into #temp_pre_12mo_3
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 --and [Card Description] not in ('Mastercard Business')
	and Extract_DatePart between 202104 - 99 and 202104
	and Durable_Key in 
	(select Durable_Key from #temp1)
	--select * from #temp_pre_12mo_3
	go

	--Pre 12 month Profit numbers_summary
	drop table if exists #temp_pre_12mo_3a
	select Durable_Key,count(*) as N_months,
	sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit,
	avg(Utilization) as avg_Utilization,avg(revolve_rate) as avg_revolve_rate,avg(payment_rate) as avg_payment_rate
	into #temp_pre_12mo_3a
	from #temp_pre_12mo_3
	group by Durable_Key
		
	go
	
	drop table if exists #temp_pre_12mo_4
	select a.*,
	--b.profit as sum_profit_pre_12mo,b.profit/b.N_months as avg_profit_pre_12mo, 
	b.avg_Utilization as avg_Utilization_pre_12mo,
	b.avg_revolve_rate as avg_revolve_rate_pre_12mo,
	b.avg_payment_rate as avg_payment_rate_pre_12mo,
	statement_balance_sp - statement_balance_12mon_back as statement_balance_diff_sp_12mon_back,
	statement_balance_sp - statement_balance_6mon_back as statement_balance_diff_sp_6mon_back,
	Revolving_balance_sp - Revolving_balance_12mon_back as Revolving_balance_diff_sp_12mon_back,
	Revolving_balance_sp - Revolving_balance_6mon_back as Revolving_balance_diff_sp_6mon_back
	into #temp_pre_12mo_4
	from #temp_pre_12mo_2 a
	left join #temp_pre_12mo_3a b
	on a.d_pre_12mo = b.Durable_Key

	go

	--select top 1000 * from #temp_pre_12mo_4

	go

	
			
	go
	--Step 2: Pre 6 month numbers
	
	--drop table if exists #temp_pre_to_pre_6mo_2
	--drop table if exists #temp_pre_to_pre_6mo_3
	--drop table if exists #temp_pre_to_pre_6mo_3a
	--drop table if exists #temp_pre_to_pre_6mo_4


	go

	--Pre 6 month Profit numbers
	select Durable_Key,Extract_DatePart,
	case when [Credit Limit] = 0 then 0 
	else [Last Statement Balance Amount]/[Credit Limit] end as Utilization
	into #temp_pre_to_pre_6mo_2
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and Extract_DatePart between 202005 and 202010
	and Durable_Key in 
	(select Durable_Key from #temp1)
	
	go

	--Pre 6 month Profit numbers_summary
	select Durable_Key,avg(Utilization) as avg_Utilization_pre_to_pre_6mo
	into #temp_pre_to_pre_6mo_3
	from #temp_pre_to_pre_6mo_2
	group by Durable_Key
	


	
	go
	--Step 2: Pre 6 month numbers
	
	--drop table if exists #temp_pre_6mo_2
	--drop table if exists #temp_pre_6mo_3
	--drop table if exists #temp_pre_6mo_3a
	--drop table if exists #temp_pre_6mo_4
	
	select Durable_Key  as d_pre_6mo,
	--sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_6mo,
	--sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_6mo,
	--sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_6mo,
	--sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_6mo,
	--sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_6mo,
	--sum([Last Statement Balance Amount]) as sum_bal_pre_6mo,
	--sum(RevolvingBalance) as sum_revbal_pre_6mo,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_6mo,
	avg([Last Statement Balance Amount]) as avg_bal_pre_6mo,
	avg(RevolvingBalance) as avg_revbal_pre_6mo,
	avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_6mo
	into #temp_pre_6mo_2
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 --and [Card Description] not in ('Mastercard Business')
	and Extract_DatePart between 202011 and 202104
	and Durable_Key in 
	(select Durable_Key from #temp1)
	group by Durable_Key

	go

	--Pre 6 month Profit numbers
	select Durable_Key,Extract_DatePart,
	case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization,
	case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate,
	case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate,

	([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income,
	([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees,
	([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income,    
	([Last Statement Balance Amount]*0.02/12) as COF,
	(ChargeoffAmount_final) as chgoff_amt,
	case when [Card Description] in ('MasterCard Platinum Rewards','MasterCard World Credit') 
	then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end as rewards_expense,
	([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense,
	case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost
	into #temp_pre_6mo_3
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 --and [Card Description] not in ('Mastercard Business')
	and Extract_DatePart between 202011 and 202104
	and Durable_Key in 
	(select Durable_Key from #temp1)
	
	go

	--Pre 6 month Profit numbers_summary
	select Durable_Key,count(*) as N_months,
	sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit,
	avg(Utilization) as avg_Utilization,avg(revolve_rate) as avg_revolve_rate,avg(payment_rate) as avg_payment_rate
	into #temp_pre_6mo_3a
	from #temp_pre_6mo_3
	group by Durable_Key
		
	go
	
	select a.*,
	--b.profit as sum_profit_pre_6mo,b.profit/b.N_months as avg_profit_pre_6mo,
	b.avg_Utilization as avg_Utilization_pre_6mo,
	b.avg_revolve_rate as avg_revolve_rate_pre_6mo,
	b.avg_payment_rate as avg_payment_rate_pre_6mo,
	c.avg_Utilization_pre_to_pre_6mo as avg_Utilization_pre_to_pre_6mo,
	b.avg_Utilization - c.avg_Utilization_pre_to_pre_6mo as Utilization_drift
	into #temp_pre_6mo_3b
	from #temp_pre_6mo_2 a
	left join #temp_pre_6mo_3a b
	on a.d_pre_6mo = b.Durable_Key
	left join #temp_pre_to_pre_6mo_3 c
	on a.d_pre_6mo = c.Durable_Key
		
	go
	
	select *,
	case 
	when Utilization_drift <= -1.00 then '<=-100%'
	when Utilization_drift <= -0.75 then '<=-75%'
	when Utilization_drift <= -0.50 then '<=-50%'
	when Utilization_drift <= -0.25 then '<=-25%'
	when Utilization_drift <= 0.00  then '<=0%'
	when Utilization_drift <= 0.25  then '<=25%'
	when Utilization_drift <= 0.50  then '<=50%'
	when Utilization_drift <= 0.75  then '<=75%'
	when Utilization_drift <= 1.00  then '<=100%'
	else '100%+' end as Utilization_drift_Band
	into #temp_pre_6mo_4
	from #temp_pre_6mo_3b

	go




	go
	--drop table if exists #temp2
	select a.*,b.*,c.*
	into #temp3
	from #temp1 a
	left join #temp_pre_12mo_4 b
	on a.Durable_Key = b.d_pre_12mo
	left join #temp_pre_6mo_4 c
	on a.Durable_Key = c.d_pre_6mo


	go

	--select * from #temp3
	--select * from #temp7
	go

	--select top 10 * from [TMGData].[dbo].[TransUnion_CreditBureau_data_Jun20]
	drop table if exists #temp4
	select distinct 
	Reference_Field,
	Score_1*1 as FICO_score,
	left(INCOME,3)*1000 as Annual_Income,
	--left(INCOME,3)*1000/12 as Monthly_Income,
	[BC07]*1 as N_bankcard_Trades_in_past_12months,
	[BC33]*1 as Bureau_Balance,
	convert(float,[RE34]) as Debt_Burden,
	--[AT36_Months since most recent delinquency on any trade captures ]*1 as Months_since_most_recent_delq,
	[BC28]*1 as Bureau_CL,
	--[COLL_Number of collections in 12 months ]*1 as N_collections_in_past_12months,
	--[G068_Total number of accounts 90 or more days past due in the la]*1 as N_accts_90plus_days_past_due_in_past_6months,
	--[G094_Number of public record bankruptcies]*1 as N_accts_bankruptcies,
	[G098]*1 as N_Inquiries_in_past_6months
	--,[AT34_Ratio of total current balance to high credit / credit limi]*1 as [Avg_Bureau Balance]
	--,[BC31_Percentage of all open bankcard trades with > 75% of the li]*1 as [Utilization >75%]

	--	[BC07]*1 as N_bankcard_Trades_in_past_12months,
	--[BC33]*1 as Bureau_Balance,
	--convert(float,[RE34]) as Debt_Burden,
	--[AT36]*1 as Months_since_most_recent_delq,
	--[BC28]*1 as Bureau_CL,
	--[COLL]*1 as N_collections_in_past_12months,
	--[G068]*1 as N_accts_90plus_days_past_due_in_past_6months,
	--[G094]*1 as N_accts_bankruptcies,
	--[G098]*1 as N_Inquiries_in_past_6months
	--,[AT34]*1 as [Avg_Bureau Balance]
	--,[BC31]*1 as [Utilization >75%]
	into #temp4
	from [Analytics].[dbo].[TransUnion_CreditBureau_data_May21]
	--where SSN <> 0 or SSN is not null
	--select distinct N_Inquiries_in_past_6months from #temp4 order by 1
	--select * from #temp4
	
	go


	select a.*,b.*
	into #temp5
	from #temp3 a
	left join #temp4 b
	on a.Durable_Key = b.Reference_Field
	--select * from #temp5

	go

	
	select left(RDT_TRANSACTION_DATE,4),count(*) as cnt
  FROM [TMGData].[dbo].[TMGCompleteCC]
  group by left(RDT_TRANSACTION_DATE,4)
  order by left(RDT_TRANSACTION_DATE,4)
  --select top 10 * FROM [TMGData].[dbo].[TMGCompleteCC]


	go

	--select Durable_Key,sum(TranAmount) as BT_amount
	--  FROM [TMGData].[dbo].[Transactions]
 -- where TranCode in (253,254) and MCCCode in (0,3,6) and Active_Flag = 1

  go

  
/****** Script for SelectTopNRows command from SSMS  ******/
--drop table if exists [analytics].[brijesh].[TMGCompleteCC_required variables]  
SELECT 
     [RDT_CHD_ACCOUNT_NUMBER],[RDT_TRANSACTION_DATE]     ,[RDT_TRANSACTION_CODE],[RDT_MRCH_SIC_CODE]
,[RDT_TRANSACTION_AMOUNT]
,[RDT_MERCHANT_NAME],[RDT_MERCHANT_CITY],[RDT_MERCHANT_STATE]
 ,[RDT_CHD_SYSTEM_NO],[RDT_CHD_PRIN_BANK],[RDT_CHD_AGENT_BANK]
	   
,[RDT_CHD_EXT_STATUS],[RDT_CHD_INT_STATUS]   ,[ReportDate],[RDT_COFF_PRIN_PAID],[RDT_COFF_INT_PAID]
  
,[RDT_ITEM_ADDITIONAL_AMT],[RDT_DETL_ICHG_FEE_AM]

,[RDT_REBATE_ADDITIONAL_AMT],[RDT_FRGN_CURR_CODE],[RDT_FGN_TRAN_AMT]
  
,[RDT_OVLMT_FEE_NET],[RDT_NET_ITEM_CHG_CHNG],[RDT_YYMM_EXPIRE_DATE],[RDT_FLAP_PROMOTION_ID]
 ,[RTI_REG_TICKET_AUTH_AMOUNT]
 
,[APR_SEGMENT_CODE],[APR_EAPR_CASH_INT],[APR_EAPR_MRCH_INT],[APR_EAPR_CASH_ITEM_CHG],[APR_EAPR_MRCH_ITEM_CHG],[APR_EAPR_LATE_CHG],[APR_EAPR_OVLM_CHG]
   into [analytics].[brijesh].[TMGCompleteCC_required variables]  
  FROM [TMGData].[dbo].[TMGCompleteCC]

  
  go

--  select [RDT_TRANSACTION_CODE],RDT_MRCH_SIC_CODE,[RDT_MERCHANT_NAME] ,
--  count(*) as N_BTS,
--	sum(cast(RDT_TRANSACTION_AMOUNT as money)) TotalTransactionAmount
--  from [analytics].[brijesh].[TMGCompleteCC_required variables]  
--  where [RDT_TRANSACTION_CODE] in (253,254) 
--and RDT_MRCH_SIC_CODE in (0,3,6) and cast(left(concat(20,[RDT_TRANSACTION_DATE]),6) as int) <= 202104
--group by [RDT_TRANSACTION_CODE],RDT_MRCH_SIC_CODE,[RDT_MERCHANT_NAME]


  go

  drop table if exists #temp6
  select [RDT_CHD_ACCOUNT_NUMBER],
  count(*) as N_BTS,
	sum(cast(RDT_TRANSACTION_AMOUNT as money)) BT_Amount
  into #temp6
  from [analytics].[brijesh].[TMGCompleteCC_required variables]  
  where [RDT_TRANSACTION_CODE] in (253,254) 
and RDT_MRCH_SIC_CODE in (3,6) and cast(left(concat(20,[RDT_TRANSACTION_DATE]),6) as int) between 202104 - 99 and 202104
group by [RDT_CHD_ACCOUNT_NUMBER]

go

drop table if exists #temp7a
  select [RDT_CHD_ACCOUNT_NUMBER],
  sum(case when cast(left(concat(20,[RDT_TRANSACTION_DATE]),6) as int) between 202104 + 1 and 202104 + 100
  then 1 else 0 end) as N_BTS_next_1year,
  sum(case when cast(left(concat(20,[RDT_TRANSACTION_DATE]),6) as int) between 202104 + 1 and 202110
  then 1 else 0 end) as N_BTS_next_6months,
  sum(case when cast(left(concat(20,[RDT_TRANSACTION_DATE]),6) as int) between 202104 + 1 and 202107
  then 1 else 0 end) as N_BTS_next_3months,
   sum(case when cast(left(concat(20,[RDT_TRANSACTION_DATE]),6) as int) = 202105
  then 1 else 0 end) as N_BTS_next_month
  into #temp7a
  from [analytics].[brijesh].[TMGCompleteCC_required variables]  
  where [RDT_TRANSACTION_CODE] in (253,254) 
and RDT_MRCH_SIC_CODE in (3,6) and cast(left(concat(20,[RDT_TRANSACTION_DATE]),6) as int) between 202104 + 1 and 202104 + 100
group by [RDT_CHD_ACCOUNT_NUMBER]

go

drop table if exists #temp7
  select [RDT_CHD_ACCOUNT_NUMBER],
  case when N_BTS_next_1year > 0 then 1 else 0 end as target_flag_1year,
   case when N_BTS_next_6months > 0 then 1 else 0 end as target_flag_6months,
    case when N_BTS_next_3months > 0 then 1 else 0 end as target_flag_3months,
	 case when N_BTS_next_month > 0 then 1 else 0 end as target_flag_month
  into #temp7
  from #temp7a

go

drop table if exists #temp8
select a.*,'2021' as _BT_year,isnull(b.N_BTS,0) as N_BTs,isnull(b.BT_Amount,0) as BT_Amount,
isnull(c.target_flag_1year,0) as target_flag_1year,
isnull(c.target_flag_6months,0) as target_flag_6months,
isnull(c.target_flag_3months,0) as target_flag_3months,
isnull(c.target_flag_month,0) as target_flag_1month
into #temp8
from #temp5 a 
left join #temp6 b
on a.[Account Number] = b.RDT_CHD_ACCOUNT_NUMBER
left join #temp7 c
on a.[Account Number] = c.RDT_CHD_ACCOUNT_NUMBER

go

select count(*) from #temp5
go
select count(*) from #temp8

go

select * from #temp8
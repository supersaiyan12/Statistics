
rm(list=ls())
getwd()
## install.packages('RODBC')
library(RODBC)
##install.packages("lubridate")
library(lubridate)
databaseConnection <- odbcDriverConnect("Driver={SQL Server};server=ACARCU01;trusted_connection=true")
Attrition_Data <- sqlQuery(databaseConnection, "select * from  [Analytics].[UICCU\\sadamhuseni].[Indirect_Member_attrition_data_20220120]")

Attrition_dataframe <- data.frame(Attrition_Data,stringsAsFactors=FALSE)
dim(Attrition_dataframe)

index_number <- colnames(Attrition_dataframe)
write.csv(index_number,"index_number.csv")

##1. Extracting out the date and char variable.

#type = sapply(Attrition_dataframe,class)
#write.csv(type,"CLASS.csv")
char_data = unlist(lapply(Attrition_dataframe,is.character))
df_c= Attrition_dataframe[,char_data ]
dim(df_c)
date_data = unlist(lapply(Attrition_dataframe,is.POSIXct))
df_d = Attrition_dataframe[,date_data]
dim(df_d)

index_c=colnames(df_c)
index_d=colnames(df_d)

log_data = unlist(lapply(Attrition_dataframe,is.logical))
df_l= Attrition_dataframe[,log_data]
##write.csv(df_l,"logical.csv")
dim(df_l)
sapply(df_l,unique)
##write.csv(sapply(df_l,unique),"Unique_logical.csv")


df1 = Attrition_dataframe[,!sapply(Attrition_dataframe,is.character)]   ## Excluding character variable
dim(df1)
df2 =  df1[,!sapply(df1,is.POSIXct)]   ## Excluding date variable
dim(df2)
##df2 is the final data after excluding date and character

df3 =  df2[,!sapply(df2,is.logical)]   ## Excluding logical variable
dim(df3)
##df3 is the final data after excluding date , character and logical.

###2. Creating the summary function

Myfunction1 <- function(data)
{
  a <- data.frame()
  e <- data.frame()
  f <- data.frame()
  G <- data.frame()
  H <- data.frame()
  I <- data.frame()
  J <- data.frame()
  K <- data.frame()
  L <- data.frame()
  M <- data.frame()
  N <- data.frame()
  Col_bined <- data.frame()
  
  
  for (i in 1:ncol(data))
  {
    if(class(data[,c(i)])!="factor") {
      Total_count <- NROW(data)-(sum(is.na(data[,c(i)]))+sum(data[,c(i)]==0,na.rm = TRUE))
      Count_NA <- data.frame(sum(is.na(data[,c(i)])))
      Count_zero <- data.frame(sum(data[,c(i)]==0,na.rm = TRUE))
      Mean_1 <- data.frame(mean(data[,c(i)],na.rm = TRUE))
      Median_1 <- data.frame(median(data[,c(i)],na.rm = TRUE))
      std <- data.frame(sd(data[,c(i)],na.rm = TRUE))
      Max_1 <- data.frame(max(data[,c(i)],na.rm = TRUE))
      Min_1 <- data.frame(min(data[,c(i)],na.rm = TRUE))
      b <-data.frame(colnames(data)[i],quantile(data[,c(i)],.25,na.rm = TRUE))
      c <-data.frame(quantile(data[,c(i)],.75,na.rm = TRUE))
      d <-data.frame(quantile(data[,c(i)],.99,na.rm = TRUE))
      row.names(Count_NA) <- NULL
      row.names(Count_zero) <- NULL
      row.names(Mean_1) <- NULL
      row.names(Median_1) <- NULL
      row.names(std) <- NULL
      row.names(Max_1) <- NULL
      row.names(Min_1) <- NULL
      row.names(Total_count) <- NULL
      row.names(b) <- NULL
      row.names(c) <- NULL
      row.names(d) <- NULL
      
      a <- rbind(b,a)
      e <- rbind(c,e)
      f <- rbind(d,f)
      
      G <- rbind(Count_NA,G)
      H <- rbind(Count_zero,H)
      I <- rbind(Mean_1,I)
      J <- rbind(Median_1,J)
      K <- rbind(Max_1,K)
      L <- rbind(Min_1,L)
      M <- rbind(std,M)
      N <- rbind(Total_count,N)
      Col_bined <- data.frame(cbind(a,e,f,N,G,H,I,J,M,K,L))
      colnames(Col_bined) <- c("Variables","Percentile 25%","Percentile 75%","Percentile 99%"
                               ,"Total_No_obs","Count_NA","Count_zero","Mean","Median","Standard_Deviation","Max","Min")
      
    }
    
  }
  
  Col_bined1<- data.frame(apply(Col_bined,2,rev))
  
  write.csv(Col_bined1,"Summary_checking_attrition.csv")
}

Myfunction1(df3)

index_number_1 = colnames(df3)
write.csv(index_number_1,"Updated index_number.csv")

###3. Removing the 0 and NA variance  

df4 = df3[,c( 1	,20	,21	,22	,24	,25	,26	,28	,29	,30	,31	,32	,33	,34	,35	,38	,39	,41	,42	,43	,44	,45	,46	,47	,48	,49	,50	,51	,52	,53	,54	,55	,56	,57	,58	,59	,62	,63	,65	,66	,67	,68	,69	,70	,71	,72	,73	,74	,75	,76	,77	,78	,79	,80	,81	,82	,85	,86	,88	,89	,90	,91	,92	,93	,94	,95	,96	,97	,98	,99	,100	,101	,102	,103	,104	,105	,108	,109	,111	,112	,113	,114	,115	,116	,117	,118	,119	,120	,121	,122	,123	,124	,125	,126	,127	,128	,131	,132	,134	,135	,136	,137	,138	,139	,140	,141	,142	,143	,144	,145	,146	,147	,148	,149	,150	,153	,154	,155	,156	,157	,159	,160	,161	,162	,163	,164	,165	,166	,167	,168	,169	,170	,171	,172	,173	,174	,175	,176	,177	,178	,179	,180	,181	,182	,183	,184	,185	,186	,188	,189	,190	,191	,192	,193	,194	,195	,196	,197	,198	,199	,200	,201	,202	,203	,204	,205	,206	,207	,208	,209	,210	,211	,212	,213	,214	,215	,216	,217	,218	,219	,220	,221	,222	,223	,224	,225	,226	,227	,228	,229	,230	,231	,232	,233	,234	,235	,236	,237	,238	,239	,240	,241	,242	,243	,244	,245	,246	,247	,248	,249	,250	,251	,252	,253	,254	,255	,256	,257	,258	,259	,260	,261	,262	,263	,264	,265	,266	,267	,268	,269	,270	,271	,272	,273	,274	,275	,276	,277	,278	,279	,280	,281	,282	,283	,284	,285	,286	,287	,288	,289	,290	,291	,292	,293	,294	,295	,297	,298	,299	,300	,301	,305	,306	,307	,308	,309	,310	,311	,312	,313	,314	,315	,319	,320	,321	,322	,323	,324	,325	,326	,327	,328	,329	,333	,334	,335	,336	,337	,338	,339	,340	,341	,342	,343	,348	,349	,350	,351	,352	,353	,354	,355	,356	,357	,358	,363	,364	,365	,366	,367	,368	,369	,370	,371	,391	,392	,393	,394	,395	,396	,397	,398	,399	,400	,401	,402	,403	,404	,405	,406	,407	,408	,409	,410	,411	,412	,413	,414	,415	,416	,417	,418	,419	,420	,421	,422	,423	,424	,425	,426	,427	,428	,429	,430	,431	,432	,433	,434	,435	,436	,437	,438	,439	,440	,441	,442	,443	,444	,445	,446	,447	,448	,449	,450	,451	,607	,608	,609	,610	,611	,612	,613	,614	,615	,616	,618	,620	,621	,622	,623	,624	,625	,626	,627	,628	,629	,630	,631	,633	,635	,636	,637	,638	,639	,640	,641	,642	,643	,644	,645	,646	,647	,648	,649	,650	,651	,652	,653	,654	,655	,656	,661	,662	,664	,666	,670	,671	,676	,677	,679	,681	,685	,686	,687	,688	,689	,690	,691	,692	,693	,694	,695	,696	,697	,698	,699	,700	,701	,757	,758	,759	,760	,761	,762	,763	,764	,765	,766	,767	,768	,769	,770	,771	,772	,773	,775)]

dim(df4)

### Looking for missing variables with more than 50 %


Myfunction2 <- function(data)
{
  a <- data.frame()
  e <- data.frame()
  f <- data.frame()
  G <- data.frame()
  H <- data.frame()
  I <- data.frame()
  J <- data.frame()
  K <- data.frame()
  L <- data.frame()
  M <- data.frame()
  N <- data.frame()
  Col_bined <- data.frame()
  
  
  for (i in 1:ncol(data))
  {
    if(class(data[,c(i)])!="factor") {
      Total_count <- NROW(data)-(sum(is.na(data[,c(i)]))+sum(data[,c(i)]==0,na.rm = TRUE))
      Count_NA <- data.frame(sum(is.na(data[,c(i)])))
      Count_zero <- data.frame(sum(data[,c(i)]==0,na.rm = TRUE))
      Mean_1 <- data.frame(mean(data[,c(i)],na.rm = TRUE))
      Median_1 <- data.frame(median(data[,c(i)],na.rm = TRUE))
      std <- data.frame(sd(data[,c(i)],na.rm = TRUE))
      Max_1 <- data.frame(max(data[,c(i)],na.rm = TRUE))
      Min_1 <- data.frame(min(data[,c(i)],na.rm = TRUE))
      b <-data.frame(colnames(data)[i],quantile(data[,c(i)],.25,na.rm = TRUE))
      c <-data.frame(quantile(data[,c(i)],.75,na.rm = TRUE))
      d <-data.frame(quantile(data[,c(i)],.99,na.rm = TRUE))
      row.names(Count_NA) <- NULL
      row.names(Count_zero) <- NULL
      row.names(Mean_1) <- NULL
      row.names(Median_1) <- NULL
      row.names(std) <- NULL
      row.names(Max_1) <- NULL
      row.names(Min_1) <- NULL
      row.names(Total_count) <- NULL
      row.names(b) <- NULL
      row.names(c) <- NULL
      row.names(d) <- NULL
      
      a <- rbind(b,a)
      e <- rbind(c,e)
      f <- rbind(d,f)
      
      G <- rbind(Count_NA,G)
      H <- rbind(Count_zero,H)
      I <- rbind(Mean_1,I)
      J <- rbind(Median_1,J)
      K <- rbind(Max_1,K)
      L <- rbind(Min_1,L)
      M <- rbind(std,M)
      N <- rbind(Total_count,N)
      Col_bined <- data.frame(cbind(a,e,f,N,G,H,I,J,M,K,L))
      colnames(Col_bined) <- c("Variables","Percentile 25%","Percentile 75%","Percentile 99%"
                               ,"Total_No_obs","Count_NA","Count_zero","Mean","Median","Standard_Deviation","Max","Min")
      
    }
    
  }
  
  Col_bined1<- data.frame(apply(Col_bined,2,rev))
  
  write.csv(Col_bined1,"Updated_Summary_checking_attrition.csv")
}
Myfunction2(df4) 


##4. Variables which are containing NA more than 50% of actual observation

##Allowing 60% NA

df_miss = df4[,-c(1 , 152 ,153, 154, 155, 156, 157 ,158, 159,160, 161, 162, 163, 164, 165, 166, 167, 168, 169
                  ,170,171, 172 ,173, 174, 175, 178 ,179, 180, 181, 182, 183, 184, 193, 194, 195, 196, 197, 198
                  ,199,208,209,210,211,212,213,214,223,224,225,226,227,228,229,238,239,240,241
                  ,242,243,244,245,246,247,248,249,250,251,252,253,316,317,318,319,320,321,322
                  ,323,324,333,33,335,344,345,346,355,356,357,366,367,368,483)]
dim(df_miss)
df_non_miss = df4[,c(1 , 152 ,153, 154, 155, 156, 157 ,158, 159,160, 161, 162, 163, 164, 165, 166, 167, 168, 169
                     ,170,171, 172 ,173, 174, 175, 178 ,179, 180, 181, 182, 183, 184, 193, 194, 195, 196, 197, 198
                     ,199,208,209,210,211,212,213,214,223,224,225,226,227,228,229,238,239,240,241
                     ,242,243,244,245,246,247,248,249,250,251,252,253,316,317,318,319,320,321,322
                     ,323,324,333,33,335,344,345,346,355,356,357,366,367,368,483)]
dim(df_non_miss)
sum(is.na(df_non_miss))
## Removing the IID variable SSN
length(unique(df_non_miss$SSN))
df_non_miss=df_non_miss[,-1]
dim(df_non_miss)    ##[193756,90]

## Allowing 65% Na

#df_miss_65 = df4[,-c(1,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,
#                  170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,
#                  189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,
#                  208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,
#                  227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,
#                  246,247,248,249,250,251,252,253,316,317,318,319,320,321,322,323,324,333,334,
#                  335,344,345,346,355,356,357,366,367,368,369,370,371,372,373,374,375,376,483)]
#dim(df_miss_65)
#df_non_miss_65 = df4[,c(1,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,
#                        170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,
#                        189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,
#                        208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,
#                        227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,
#                        246,247,248,249,250,251,252,253,316,317,318,319,320,321,322,323,324,333,334,
#                        335,344,345,346,355,356,357,366,367,368,369,370,371,372,373,374,375,376,483)]
#dim(df_non_miss_65)                  #133
#sum(is.na(df_non_miss_65))           #11451623




#out = boxplot.stats(df4[,152])$out
#out_ind = which(df4[,152] %in% c(out))
#write.csv(out_ind,"Outlier 152")

##5. Detection of Indexes of Outliers

#install.packages("outliers")
#library(outliers)
#dim(df4)
#out = outlier(df4[,2:483],logical = TRUE)
#out = cbind(FALSE,out)
#Outlier Index
#out_index = which(out[,],TRUE)
#out_index = as.data.frame(out_index)
#dim(out_index)
#write.csv(out_index,"Indexes of Outliers.csv",row.names= FALSE)
#sum(is.na(df4))

##install.packages('missForest')
##library(missForest)
##df.imp=missForest(df_non_miss,maxiter = 50,ntree = 500)
##df_clean=df.imp$ximp


##5.WOE binning

NAReplace_data <- replace(df_non_miss,is.na(df_non_miss),-99999999)
index_number3 <- colnames(NAReplace_data)
write.csv(index_number3,"index_number3.csv") 

#install.packages("woeBinning")
library(woeBinning)
binning <- woe.binning(NAReplace_data,'Attrition_flag',NAReplace_data)
tabulate.binning <- woe.binning.table(binning)

library(woeBinning)
Binning.Data <- woe.binning(NAReplace_data,'Attrition_flag',NAReplace_data)
Dataset_woe <- woe.binning.deploy(NAReplace_data,Binning.Data,add.woe.or.dum.var = "woe")
index_number4 <- colnames(Dataset_woe)
write.csv(index_number4,"index_number4.csv") 


WOEsumm <-data.matrix(tabulate.binning, rownames.force = NA)
write.csv(WOEsumm,"WOE&IV_memberattrition.csv")
### Including Only the woe variables and the Attrition_Flag column
df_checking = Dataset_woe[,c(90,92,94,96,98,100,102,104,106,108,110,112,114,116,118,120,122,124,126,128,130,132,134,136,138,140,142,144,146,148,150,152,154,156,158,160,162,164,166
                             ,168,170,172,174,176,178,180,182,184,186,188,190,192,194,196,198,200,202,204,206,208,210,212,214,216,218,220,222,224,226,228,230,232,234
                             ,236,238,240,242,244,246,248,250,252,254,256,258,260,262,264,266,268)]
dim(df_checking) ##[193756,90]



#After allowing 65% NA
#NAReplace_data <- replace(df_non_miss_65,is.na(df_non_miss_65),-99999999)
#index_number3 <- colnames(NAReplace_data)
#write.csv(index_number3,"index_number3.csv") 

#install.packages("woeBinning")
#library(woeBinning)
#binning <- woe.binning(NAReplace_data,'Attrition_flag',NAReplace_data)
#tabulate.binning <- woe.binning.table(binning)

#library(woeBinning)
#Binning.Data <- woe.binning(NAReplace_data,'Attrition_flag',NAReplace_data)
#Dataset_woe <- woe.binning.deploy(NAReplace_data,Binning.Data,add.woe.or.dum.var = "woe")
#dim(Dataset_woe)                       #397 columns
#index_number5 <- colnames(Dataset_woe)
#write.csv(index_number5,"index_number5.csv") 


#WOEsumm <-data.matrix(tabulate.binning, rownames.force = NA)
#write.csv(WOEsumm,"WOE&IV_memberattrition.csv")

##6. Random Forest Feature Selection
##install.packages('randomForest')
##install.packages('e1071')
##install.packages('caret')
##install.packages('ROCR')
library(randomForest)
library(e1071)
library(caret)
library(ROCR)
set.seed(2017)
df_checking$Attrition_flag <- as.factor(df_checking$Attrition_flag)
RF <- randomForest(Attrition_flag ~.,data = df_checking,ntree=50)
unique(df_checking$Attrition_flag)
Important_vr <- importance(RF)
write.csv(Important_vr,"Imp_VR100_all_Member_Attrition.csv")
#install.packages("digest")
#install.packages("randomForestExplainer")
library(digest)
library(randomForestExplainer)
min_depth_frame <- min_depth_distribution(RF)
plot_min_depth_distribution(min_depth_frame)


importance_frame <- measure_importance(RF)
save(importance_frame, file = "importance_frame_CheckingAttrition.rda")
load("importance_frame_Unsecured.rda")
importance_frame
write.csv(importance_frame,"Importance_frame_all_CheckingAttrition.csv")


## Selecting the variables which have Gini decrease more than 10

Checking_data = Dataset_woe[,c(202,106,98,244,150,218,204,166,174,246,226,134,96,118,122,94,234,228,178,190,126,248,160,92,112,104,132,130,136,142,162,
                               138,222,164,148,140,146,232,220,152,216,154,176,158,156,230,224,144,108,100,120,102,260)]
#Checking1 = Checking_data[,sapply(Checking_data,is.numeric)]
#Including Attrition_flag in Checking_data
Checking_data$Attrition_flag=Dataset_woe[,90]
dim(Checking_data)        # 54 variables
#dim(Checking1)


#Correlation_matrix = cor(Checking1)
#write.csv(Correlation_matrix,'Correlation_Matrix.csv')

##7. Stepwise Logistic Regression

#install.packages("My.stepwise")
#library(My.stepwise)

Checking_data$Attrition_flag <- as.numeric(Checking_data$Attrition_flag)
#Checking_data$Attrition_flag[Checking_data$Attrition_flag==1]<-0
#Checking_data$Attrition_flag[Checking_data$Attrition_flag==2]<-1
unique((Dataset_woe$Attrition_flag))
sum(Checking_data$Attrition_flag)
my.variable.list <- colnames(subset(Checking_data,select = -Attrition_flag))

summary(Checking_data$Attrition_flag)

dim(Checking_data)

##8. Stepwise Regression :

model.null_1 = glm(Attrition_flag~1,data=Checking_data,family = binomial(link = 'logit'))
model.full_1 = glm(Attrition_flag~.,data = Checking_data, family = binomial(link = 'logit'))
my_stepwise_regression_testing = step(model.null_1 ,scope= list(upper = model.full_1),direction = "both",test ="Chisq"
                                      ,data =Checking_data)

##9. Final Stepwise Regression model
test_model_1=glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
                                  woe.Count_Total_Deposit_ACCT.binned +
                                  woe.sum_Month_end_balance_savings_Q1.binned + 
                                  woe.AVG_Deposited_amount_Total_Deposit_ACCT.binned +
                                  woe.sum_Month_end_balance_Checkings_Q1.binned + 
                                  woe.Count_product_Total_Deposit_ACCT.binned + 
                                  woe.Last.Statement.Return.Amount_CC_Q2.binned + 
                                  woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + 
                                  woe.MOB_Savings.binned + 
                                  woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned +
                                  woe.Sum_LASTDIVAMOUNT_savings_Q3.binned + 
                                  woe.Avg_Month_end_balance_savings_Staticpool.binned +
                                  woe.Sum_LASTDIVAMOUNT_Checkings_Q3.binned + 
                                  woe.Avg_Month_end_balance_savings_Q4.binned +
                                  woe.Sum_LASTDIVAMOUNT_savings_Q1.binned + 
                                  woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned +
                                  woe.Avg_Month_end_balance_savings_Q1.binned + 
                                  woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
                                  woe.Sum_transaction_count_checkings_Staticpool.binned + 
                                  woe.SUM_Deposited_count_Total_Deposit_ACCT.binned +
                                  woe.Sum_LASTDIVAMOUNT_Checkings_Staticpool.binned + 
                                  woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned + 
                                  woe.sum_Month_end_balance_savings_Q4.binned + 
                                  woe.AVG_balancechange_Checkings_Staticpool.binned +
                                  woe.Sum_transaction_amount_checkings_Staticpool.binned + 
                                  woe.Avg_transaction_amount_checkings_Staticpool.binned
                                 ,data = Checking_data, family = binomial(link = 'logit'))

summary(test_model_1)

## Change from here

##10. ANOVA Wald's test
install.packages('carData')
install.packages('car')
library(carData)
library(car)
Anova(test_model_1, type="II", test="Wald")
##woe.AVG_Deposited_amount_Total_Deposit_ACCT.binned has p value over 0.05. So it can be excluded.


test_model_2=glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
                   woe.Count_Total_Deposit_ACCT.binned +
                   woe.sum_Month_end_balance_savings_Q1.binned + 
                   woe.sum_Month_end_balance_Checkings_Q1.binned + 
                   woe.Count_product_Total_Deposit_ACCT.binned + 
                   woe.Last.Statement.Return.Amount_CC_Q2.binned + 
                   woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + 
                   woe.MOB_Savings.binned + 
                   woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned +
                   woe.Sum_LASTDIVAMOUNT_savings_Q3.binned + 
                   woe.Avg_Month_end_balance_savings_Staticpool.binned +
                   woe.Sum_LASTDIVAMOUNT_Checkings_Q3.binned + 
                   woe.Avg_Month_end_balance_savings_Q4.binned +
                   woe.Sum_LASTDIVAMOUNT_savings_Q1.binned + 
                   woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned +
                   woe.Avg_Month_end_balance_savings_Q1.binned + 
                   woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
                   woe.Sum_transaction_count_checkings_Staticpool.binned + 
                   woe.SUM_Deposited_count_Total_Deposit_ACCT.binned +
                   woe.Sum_LASTDIVAMOUNT_Checkings_Staticpool.binned + 
                   woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned + 
                   woe.sum_Month_end_balance_savings_Q4.binned + 
                   woe.AVG_balancechange_Checkings_Staticpool.binned +
                   woe.Sum_transaction_amount_checkings_Staticpool.binned + 
                   woe.Avg_transaction_amount_checkings_Staticpool.binned
                 ,data = Checking_data, family = binomial(link = 'logit'))

Anova(test_model_2, type="II", test="Wald")
##woe.Sum_LASTDIVAMOUNT_Checkings_Q3.binned has p value over 0.05. So it can be excluded.


test_model_3=glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
                   woe.Count_Total_Deposit_ACCT.binned +
                   woe.sum_Month_end_balance_savings_Q1.binned + 
                   woe.sum_Month_end_balance_Checkings_Q1.binned + 
                   woe.Count_product_Total_Deposit_ACCT.binned + 
                   woe.Last.Statement.Return.Amount_CC_Q2.binned + 
                   woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + 
                   woe.MOB_Savings.binned + 
                   woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned +
                   woe.Sum_LASTDIVAMOUNT_savings_Q3.binned + 
                   woe.Avg_Month_end_balance_savings_Staticpool.binned +
                   woe.Avg_Month_end_balance_savings_Q4.binned +
                   woe.Sum_LASTDIVAMOUNT_savings_Q1.binned + 
                   woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned +
                   woe.Avg_Month_end_balance_savings_Q1.binned + 
                   woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
                   woe.Sum_transaction_count_checkings_Staticpool.binned + 
                   woe.SUM_Deposited_count_Total_Deposit_ACCT.binned +
                   woe.Sum_LASTDIVAMOUNT_Checkings_Staticpool.binned + 
                   woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned + 
                   woe.sum_Month_end_balance_savings_Q4.binned + 
                   woe.AVG_balancechange_Checkings_Staticpool.binned +
                   woe.Sum_transaction_amount_checkings_Staticpool.binned + 
                   woe.Avg_transaction_amount_checkings_Staticpool.binned
                 ,data = Checking_data, family = binomial(link = 'logit'))

Anova(test_model_3, type="II", test="Wald")
##woe.sum_Month_end_balance_savings_Q4.binned has p value over 0.05. So it can be excluded.


test_model_4=glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
                   woe.Count_Total_Deposit_ACCT.binned +
                   woe.sum_Month_end_balance_savings_Q1.binned + 
                   woe.sum_Month_end_balance_Checkings_Q1.binned + 
                   woe.Count_product_Total_Deposit_ACCT.binned + 
                   woe.Last.Statement.Return.Amount_CC_Q2.binned + 
                   woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + 
                   woe.MOB_Savings.binned + 
                   woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned +
                   woe.Sum_LASTDIVAMOUNT_savings_Q3.binned + 
                   woe.Avg_Month_end_balance_savings_Staticpool.binned +
                   woe.Avg_Month_end_balance_savings_Q4.binned +
                   woe.Sum_LASTDIVAMOUNT_savings_Q1.binned + 
                   woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned +
                   woe.Avg_Month_end_balance_savings_Q1.binned + 
                   woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
                   woe.Sum_transaction_count_checkings_Staticpool.binned + 
                   woe.SUM_Deposited_count_Total_Deposit_ACCT.binned +
                   woe.Sum_LASTDIVAMOUNT_Checkings_Staticpool.binned + 
                   woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned + 
                   woe.AVG_balancechange_Checkings_Staticpool.binned +
                   woe.Sum_transaction_amount_checkings_Staticpool.binned + 
                   woe.Avg_transaction_amount_checkings_Staticpool.binned
                 ,data = Checking_data, family = binomial(link = 'logit'))

Anova(test_model_4, type="II", test="Wald")
##woe.sum_Month_end_balance_savings_Q4.binned has p value over 0.05. So it can be excluded.


test_model_5=glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
                   woe.Count_Total_Deposit_ACCT.binned +
                   woe.sum_Month_end_balance_savings_Q1.binned + 
                   woe.sum_Month_end_balance_Checkings_Q1.binned + 
                   woe.Count_product_Total_Deposit_ACCT.binned + 
                   woe.Last.Statement.Return.Amount_CC_Q2.binned + 
                   woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + 
                   woe.MOB_Savings.binned + 
                   woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned +
                   woe.Sum_LASTDIVAMOUNT_savings_Q3.binned + 
                   woe.Avg_Month_end_balance_savings_Staticpool.binned +
                   woe.Avg_Month_end_balance_savings_Q4.binned +
                   woe.Sum_LASTDIVAMOUNT_savings_Q1.binned + 
                   woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned +
                   woe.Avg_Month_end_balance_savings_Q1.binned + 
                   woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
                   woe.Sum_transaction_count_checkings_Staticpool.binned + 
                   woe.SUM_Deposited_count_Total_Deposit_ACCT.binned +
                   woe.Sum_LASTDIVAMOUNT_Checkings_Staticpool.binned + 
                   woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned + 
                   woe.AVG_balancechange_Checkings_Staticpool.binned +
                   woe.Sum_transaction_amount_checkings_Staticpool.binned 
                 ,data = Checking_data, family = binomial(link = 'logit'))

Anova(test_model_5, type="II", test="Wald")
##woe.Avg_transaction_amount_checkings_Staticpool.binned has p value over 0.05. So it can be excluded.

test_model_6=glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
                   woe.Count_Total_Deposit_ACCT.binned +
                   woe.sum_Month_end_balance_savings_Q1.binned + 
                   woe.sum_Month_end_balance_Checkings_Q1.binned + 
                   woe.Count_product_Total_Deposit_ACCT.binned + 
                   woe.Last.Statement.Return.Amount_CC_Q2.binned + 
                   woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + 
                   woe.MOB_Savings.binned + 
                   woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned +
                   woe.Sum_LASTDIVAMOUNT_savings_Q3.binned + 
                   woe.Avg_Month_end_balance_savings_Staticpool.binned +
                   woe.Avg_Month_end_balance_savings_Q4.binned +
                   woe.Sum_LASTDIVAMOUNT_savings_Q1.binned + 
                   woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned +
                   woe.Avg_Month_end_balance_savings_Q1.binned + 
                   woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
                   woe.Sum_transaction_count_checkings_Staticpool.binned + 
                   woe.SUM_Deposited_count_Total_Deposit_ACCT.binned +
                   woe.Sum_LASTDIVAMOUNT_Checkings_Staticpool.binned + 
                   woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned + 
                   woe.AVG_balancechange_Checkings_Staticpool.binned  
                 ,data = Checking_data, family = binomial(link = 'logit'))

Anova(test_model_6, type="II", test="Wald")
##woe.AVG_balancechange_Checkings_Staticpool.binned  has p value over 0.05. So it can be excluded.

test_model_7=glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
                   woe.Count_Total_Deposit_ACCT.binned +
                   woe.sum_Month_end_balance_savings_Q1.binned + 
                   woe.sum_Month_end_balance_Checkings_Q1.binned + 
                   woe.Count_product_Total_Deposit_ACCT.binned + 
                   woe.Last.Statement.Return.Amount_CC_Q2.binned + 
                   woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + 
                   woe.MOB_Savings.binned + 
                   woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned +
                   woe.Sum_LASTDIVAMOUNT_savings_Q3.binned + 
                   woe.Avg_Month_end_balance_savings_Staticpool.binned +
                   woe.Avg_Month_end_balance_savings_Q4.binned +
                   woe.Sum_LASTDIVAMOUNT_savings_Q1.binned + 
                   woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned +
                   woe.Avg_Month_end_balance_savings_Q1.binned + 
                   woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
                   woe.Sum_transaction_count_checkings_Staticpool.binned + 
                   woe.SUM_Deposited_count_Total_Deposit_ACCT.binned +
                   woe.Sum_LASTDIVAMOUNT_Checkings_Staticpool.binned + 
                   woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned  
                 ,data = Checking_data, family = binomial(link = 'logit'))

Anova(test_model_7, type="II", test="Wald")
##All variables have  p value less than 0.05. So it can be excluded.


### Multicollinearity check

vif(test_model_7)

##woe.Sum_LASTDIVAMOUNT_savings_Q1.binned   has high VIF and hence eliminated.

test_model_8 = glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
                   woe.Count_Total_Deposit_ACCT.binned +
                   woe.sum_Month_end_balance_savings_Q1.binned + 
                   woe.sum_Month_end_balance_Checkings_Q1.binned + 
                   woe.Count_product_Total_Deposit_ACCT.binned + 
                   woe.Last.Statement.Return.Amount_CC_Q2.binned + 
                   woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + 
                   woe.MOB_Savings.binned + 
                   woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned +
                   woe.Sum_LASTDIVAMOUNT_savings_Q3.binned + 
                   woe.Avg_Month_end_balance_savings_Staticpool.binned +
                   woe.Avg_Month_end_balance_savings_Q4.binned +
                   woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned +
                   woe.Avg_Month_end_balance_savings_Q1.binned + 
                   woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
                   woe.Sum_transaction_count_checkings_Staticpool.binned + 
                   woe.SUM_Deposited_count_Total_Deposit_ACCT.binned +
                   woe.Sum_LASTDIVAMOUNT_Checkings_Staticpool.binned + 
                   woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned  
                 ,data = Checking_data, family = binomial(link = 'logit'))

vif(test_model_8)
## woe.Avg_Month_end_balance_savings_Q1.binned   has high VIF and hence eliminated.

test_model_9 = glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
                     woe.Count_Total_Deposit_ACCT.binned +
                     woe.sum_Month_end_balance_savings_Q1.binned + 
                     woe.sum_Month_end_balance_Checkings_Q1.binned + 
                     woe.Count_product_Total_Deposit_ACCT.binned + 
                     woe.Last.Statement.Return.Amount_CC_Q2.binned + 
                     woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + 
                     woe.MOB_Savings.binned + 
                     woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned +
                     woe.Sum_LASTDIVAMOUNT_savings_Q3.binned + 
                     woe.Avg_Month_end_balance_savings_Staticpool.binned +
                     woe.Avg_Month_end_balance_savings_Q4.binned +
                     woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned +
                     woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
                     woe.Sum_transaction_count_checkings_Staticpool.binned + 
                     woe.SUM_Deposited_count_Total_Deposit_ACCT.binned +
                     woe.Sum_LASTDIVAMOUNT_Checkings_Staticpool.binned + 
                     woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned  
                   ,data = Checking_data, family = binomial(link = 'logit'))
vif(test_model_9)

## woe.Sum_LASTDIVAMOUNT_savings_Q3.binned  has high VIF and hence eliminated.

test_model_10 =glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
                     woe.Count_Total_Deposit_ACCT.binned +
                     woe.sum_Month_end_balance_savings_Q1.binned + 
                     woe.sum_Month_end_balance_Checkings_Q1.binned + 
                     woe.Count_product_Total_Deposit_ACCT.binned + 
                     woe.Last.Statement.Return.Amount_CC_Q2.binned + 
                     woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + 
                     woe.MOB_Savings.binned + 
                     woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned +
                     woe.Avg_Month_end_balance_savings_Staticpool.binned +
                     woe.Avg_Month_end_balance_savings_Q4.binned +
                     woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned +
                     woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
                     woe.Sum_transaction_count_checkings_Staticpool.binned + 
                     woe.SUM_Deposited_count_Total_Deposit_ACCT.binned +
                     woe.Sum_LASTDIVAMOUNT_Checkings_Staticpool.binned + 
                     woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned  
                   ,data = Checking_data, family = binomial(link = 'logit'))
vif(test_model_10)

##woe.Count_product_Total_Deposit_ACCT.binned   has high VIF and hence eliminated.


test_model_11 = glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
                      woe.Count_Total_Deposit_ACCT.binned +
                      woe.sum_Month_end_balance_savings_Q1.binned + 
                      woe.sum_Month_end_balance_Checkings_Q1.binned +
                      woe.Last.Statement.Return.Amount_CC_Q2.binned + 
                      woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + 
                      woe.MOB_Savings.binned + 
                      woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned +
                      woe.Avg_Month_end_balance_savings_Staticpool.binned +
                      woe.Avg_Month_end_balance_savings_Q4.binned +
                      woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned +
                      woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
                      woe.Sum_transaction_count_checkings_Staticpool.binned + 
                      woe.SUM_Deposited_count_Total_Deposit_ACCT.binned +
                      woe.Sum_LASTDIVAMOUNT_Checkings_Staticpool.binned + 
                      woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned  
                    ,data = Checking_data, family = binomial(link = 'logit'))
vif(test_model_11)

##woe.Sum_transaction_count_checkings_Staticpool.binned  have VIF more than 5 and so eliminated.

test_model_12 =  glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
                       woe.Count_Total_Deposit_ACCT.binned +
                       woe.sum_Month_end_balance_savings_Q1.binned + 
                       woe.sum_Month_end_balance_Checkings_Q1.binned +
                       woe.Last.Statement.Return.Amount_CC_Q2.binned + 
                       woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + 
                       woe.MOB_Savings.binned + 
                       woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned +
                       woe.Avg_Month_end_balance_savings_Staticpool.binned +
                       woe.Avg_Month_end_balance_savings_Q4.binned +
                       woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned +
                       woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
                       woe.SUM_Deposited_count_Total_Deposit_ACCT.binned +
                       woe.Sum_LASTDIVAMOUNT_Checkings_Staticpool.binned + 
                       woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned  
                     ,data = Checking_data, family = binomial(link = 'logit'))
vif(test_model_12)

## This is the final Model as all VIF are less than 5.

FINAL_MODEL = glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
                    woe.Count_Total_Deposit_ACCT.binned +
                    woe.sum_Month_end_balance_savings_Q1.binned + 
                    woe.sum_Month_end_balance_Checkings_Q1.binned +
                    woe.Last.Statement.Return.Amount_CC_Q2.binned + 
                    woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + 
                    woe.MOB_Savings.binned + 
                    woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned +
                    woe.Avg_Month_end_balance_savings_Staticpool.binned +
                    woe.Avg_Month_end_balance_savings_Q4.binned +
                    woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned +
                    woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
                    woe.SUM_Deposited_count_Total_Deposit_ACCT.binned +
                    woe.Sum_LASTDIVAMOUNT_Checkings_Staticpool.binned + 
                    woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned  
                  ,data = Checking_data, family = binomial(link = 'logit'))
summary(FINAL_MODEL)




##GAIN AND LIFT PLOT

#install.packages('funModeling')
#library(funModeling)
#gain_lift()











## Train Test Split ::

##install.packages('caTools')
##library(caTools)
##set.seed(123)
##sample = sample.split(Checking_data$Attrition_flag,SplitRatio = 0.6)
##train_set =subset(Checking_data,sample ==TRUE)
##test_set = subset(Checking_data,sample == FALSE)
##dim(train_set)
##dim(test_set)

##train_model = glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
##                    woe.Count_Total_Deposit_ACCT.binned +
##                    woe.sum_Month_end_balance_savings_Q1.binned + 
##                    woe.sum_Month_end_balance_Checkings_Q1.binned +
##                    woe.Last.Statement.Return.Amount_CC_Q2.binned + 
##                    woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + 
##                    woe.MOB_Savings.binned + 
##                    woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned +
##                    woe.Avg_Month_end_balance_savings_Staticpool.binned +
##                    woe.Avg_Month_end_balance_savings_Q4.binned +
##                    woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned +
##                    woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
##                    woe.SUM_Deposited_count_Total_Deposit_ACCT.binned +
##                    woe.Sum_LASTDIVAMOUNT_Checkings_Staticpool.binned + 
##                    woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned  
##                  ,data = train_set, family = binomial(link = 'logit'))

##fitted_results=predict(train_model,newdata = train_set)
##fit = ifelse(fitted_results>0.5,1,0)




##7. Stepwise Logistic Regression

#install.packages("My.stepwise")
#library(My.stepwise)
Checking_data1 = Dataset_woe[,c(202,106,98,244,150,218,204,166,174,246,226,134,96,118,122,94,234,228,178,190,126,248,160,92,112,104,132,130,136,142,162,
                               +                                138,222,164,148,140,146,220,152,216,154,176,158,156,230,224,144,108,100,120,102,260)]
Checking_data1$Attrition_flag = Dataset_woe$Attrition_flag
dim(Checking_data1)
Checking_data1$Attrition_flag <- as.numeric(Checking_data$Attrition_flag)
#Checking_data$Attrition_flag[Checking_data$Attrition_flag==1]<-0
#Checking_data$Attrition_flag[$Attrition_flag==2]<-1
unique((Dataset_woe$Attrition_flag))
sum(Checking_data$Attrition_flag)
my.variable.list <- colnames(subset(Checking_data,select = -Attrition_flag))

summary(Checking_data$Attrition_flag)


##8. Stepwise Regression :

model.null_2 = glm(Attrition_flag~1,data=Checking_data1,family = binomial(link = 'logit'))
model.full_2 = glm(Attrition_flag~.,data = Checking_data1, family = binomial(link = 'logit'))
my_stepwise_regression_testing = step(model.null_2 ,scope= list(upper = model.full_2),direction = "both",test ="Chisq"
                                      ,data =Checking_data1)

final_model2 = glm(Attrition_flag ~ woe.SUM_Closed_flag_Total_Deposit_ACCT.binned + 
                     woe.Count_Total_Deposit_ACCT.binned + woe.sum_Month_end_balance_savings_Q1.binned + 
                     woe.AVG_Deposited_amount_Total_Deposit_ACCT.binned + woe.sum_Month_end_balance_Checkings_Q1.binned + 
                     woe.Count_product_Total_Deposit_ACCT.binned + woe.Last.Statement.Return.Amount_CC_Q2.binned + 
                     woe.AVG_withdrawal_count_Total_Deposit_ACCT.binned + woe.MOB_Savings.binned + 
                     woe.Total_No_Account_Savings.binned + woe.sum_Month_end_balance_savings_Q3.binned + 
                     woe.Sum_transaction_count_checkings_Staticpool.binned + woe.SUM_withdrawal_count_Total_Deposit_ACCT.binned + 
                     woe.Sum_LASTDIVAMOUNT_Checkings_Q3.binned + woe.SUM_Deposited_count_Total_Deposit_ACCT.binned
                   ,data=Checking_data1,family=binomial(link = 'logit'))

summary(final_model2)




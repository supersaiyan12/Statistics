--================================================================= CLI & BT - TARGET LIST ========================================================================
--=================================================================================================================================================================
Drop table if exists #StaticPool
SELECT 
distinct
durable_key,
[social security number]

into #StaticPool
FROM Analytics.DBO.JK_cli22_APR22_FinalList 
union
select durable_key,
[social security number] from Analytics.DBO.JK_BT22_APR22_FinalList

--===== CLI & BT ALLOCATION FLAGS
--===============================
Drop table if exists #Main
Select 
*
,case when (Durable_Key in (select distinct Durable_Key from Analytics.DBO.JK_CLI22_Apr22_FinalList) and 
	Durable_Key not in (select distinct Durable_Key from Analytics.DBO.JK_BT22_APR22_FinalList)) then 1 else 0 end as OnlyCLI

,case when (Durable_Key not in (select distinct Durable_Key from Analytics.DBO.JK_CLI22_Apr22_FinalList) and 
	Durable_Key  in (select distinct Durable_Key from Analytics.DBO.JK_BT22_APR22_FinalList)) then 1 else 0 end as OnlyBT

,case when (Durable_Key in (select distinct Durable_Key from Analytics.DBO.JK_CLI22_Apr22_FinalList) and 
	Durable_Key  in (select distinct Durable_Key from Analytics.DBO.JK_BT22_APR22_FinalList)) then 1 else 0 end as Both_BTCLI

into #Main
from #StaticPool



--**********************
--|| MEMBER DATA PULL ||
--**********************
Drop table if exists #Member
Select 
distinct 
ssn
,first
,last

into #member
From 
	(select
	*
	,ROW_NUMBER() Over(Partition by ssn order by lastfmdate desc,recordchangedate desc) as rank
	from ARCUSYM000..NAME
	where ProcessDate = '20220531'
	and SSN in (select distinct [Social Security Number] from #Main)
	and FIRST is not null
	and LAST is not null
	and city is not null
	and STATE is not null
	and ZIPCODE is not null
	and type = 0  and EXPIRATIONDATE is null and DEATHDATE is null) a
where rank =1


--===== MAILING ADDESS
--====================
Drop table if exists #Mailing
Select 
*
into #Mailing
from 
(Select 
distinct SSN,
		Street as [Address 1],ExtraAddress as [Address 2],City,State,ZipCode,
		namemailflag,MailingOnly,EStatementsEnabled,AddressTypeDescription
		,ROW_NUMBER() Over(Partition by ssn order by EStatementsEnabled desc,namemailflag desc) as rank
from UICCU.bi.vwMailingAddressCurrent
where ssn in (select distinct [Social Security Number]  from #Main)
and  NameType = 'PRIMARY'
		and ParentAccount in 
		(select distinct ParentAccount 		from ARCUSYM000..NAME	
		where ProcessDate = 20220531 and ADDRESSTYPE = 0 
		and SSN is not null and EXPIRATIONDATE is null and DEATHDATE is null and type = 0 
		and SSN in (select distinct  [Social Security Number] from #Main))
		and addressTypeDescription = 'Domestic Address') a
where rank=1


--===== joining member & mailing data to main
--===========================================
Drop table if exists #Master
Select 
distinct 
a.*
,b.FIRST,b.LAST
,c.[Address 1],c.[Address 2],c.AddressTypeDescription,c.City,c.EStatementsEnabled,c.MailingOnly
,c.NameMailFlag,c.STATE,c.ZipCode

into #Master
from #Main a
left join #member b 
on a.[Social Security Number]=b.SSN
left join #Mailing c 
on a.[Social Security Number] = c.ssn

--===== Only CLI List
--===================
Drop table if exists #OnlyCLI
select 
distinct
a.[Social Security Number],a.[Durable_Key],a.[Master Account Key],[Account Number],
	a.[Card Description],
	a.[Credit Limit] as [Existing CL],[Proposed CL],
	c.[Calc Norm Cash Annual Rate] as GO_TO_APR_CASH,
	b.FIRST as first_name,b.LAST as Last_name,b.City as City,b.State as State,
	b.ZIPCODE,b.[Address 1] ,b.[Address 2],
	a.[External Status Code],a.[Internal Status Code],
	[sp_month] as [Static Pool Month],(a.[Credit Limit] - a.[Last Statement Balance Amount]) as [Open to Buy],
	a.[mob],a.[Last Statement Balance Amount],a.[RevolvingBalance],
	a.[spend],a.[TRIPFLAG],a.[Last Statement Payment Amount],
	[FICO_score],[Annual_Income],[Monthly_Income]
	--,[N_active_bankcard_Trades]
	,d.bc07 as [N_bankcard_Trades_in_past_12months],[Bureau_balance],[Debt_Burden],
	d.AT36 as [Months_since_most_recent_delq],d.BC28 as [Bureau_CL],
	e.Score_1 as FICO_May21 ,(a.FICO_Score-e.Score_1) as FICO_drift,
	d.COLL as N_collections_in_past_12months,d.G068 as N_accts_90plus_days_past_due_in_past_6months,N_Inquiries_in_past_6months,
	N_accts_bankruptcies,a.AGE,FICO_Band_DT,CL_Band_DT,Monthly_Diposable_Income,
	case when (Monthly_Diposable_Income - (0.03*([Proposed CL] - a.[Credit Limit]))) > 0 then 'YES' else 'NO' end as Ability_TO_Repay,
	--rand(convert(varbinary,NEWID())) as random_number,
	'Test'as [TEST_CONTROL group],
	b.NameMailFlag,b.MailingOnly,b.EStatementsEnabled,b.AddressTypeDescription

	into #OnlyCLI
FROM (Select * from Analytics.DBO.JK_CLI22_Apr22_FinalList
where  durable_key IN (SELECT distinct durable_key FROM #main where onlycli =1) ) a 
left join #master b on a.[Social Security Number]= b.[Social Security Number]
left join 
(select *  FROM [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and [External Status Code] in ('') and [Internal Status Code] in ('','N')
	and Extract_DatePart = 202204 and mob > 11) c  
	on a.Durable_Key=c.Durable_Key
left join (select * from [Analytics].[dbo].[Transunion_CreditBureau_data_Apr22]) d   
on a.[Social Security Number] =d.SSN
left join (select ssn,min(Score_1) as Score_1 from analytics.dbo.TransUnion_CreditBureau_data_May21 group by SSN) e
on a.[Social Security Number] = e.SSN


select * from #OnlyCLI 

--===== Only BT List
--===================
Drop table if exists #OnlyBT
select 
distinct
a.[Social Security Number],a.[Durable_Key],a.[Master Account Key],a.[Account Number],
	a.[Card Description],
	cast('7/1/2022' as date) as [Campaign Start Date]
	,cast('8/31/2022' as date) as [Campaign End Date],
	case when(a.Deciling in (1,2,3)) then '3.99% for 12 Months, No BT Fees'
		when(a.Deciling in (4,5,6)) then '0% for 12 Months, No BT Fees' else NULL end as Offer,
	(a.[Credit Limit] - a.[Last Statement Balance Amount]) as [Open to Buy],
	a.[Credit Limit] as [Existing CL],a.[Credit Limit] [Proposed CL],
	c.[Calc Norm Cash Annual Rate] as GO_TO_APR_CASH,
	b.FIRST as first_name,b.LAST as Last_name,b.City as City,b.State as State,
	b.ZIPCODE,b.[Address 1] ,b.[Address 2],
	a.[External Status Code],a.[Internal Status Code],
	[sp_month] as [Static Pool Month],
	a.[mob],a.[Last Statement Balance Amount],a.[RevolvingBalance],
	a.[spend],a.[TRIPFLAG],a.[Last Statement Payment Amount],
	[FICO_score],[Annual_Income],[Monthly_Income]
	--,[N_active_bankcard_Trades]
	,d.bc07 as [N_bankcard_Trades_in_past_12months],[Bureau_balance],[Debt_Burden],
	d.AT36 as [Months_since_most_recent_delq],d.BC28 as [Bureau_CL],
	e.Score_1 as FICO_May21 ,(a.FICO_Score-e.Score_1) as FICO_drift,
	d.COLL as N_collections_in_past_12months,d.G068 as N_accts_90plus_days_past_due_in_past_6months,N_Inquiries_in_past_6months,
	N_accts_bankruptcies,a.AGE,Times_Transactors Transactor_Pre_12mo,
	b.NameMailFlag,b.MailingOnly,b.EStatementsEnabled,b.AddressTypeDescription


	into #OnlyBT
FROM (Select * from Analytics.DBO.JK_BT22_Apr22_FinalList
where  durable_key IN (SELECT distinct durable_key FROM #main where OnlyBT =1) ) a 
left join #master b 
on a.[Social Security Number]= b.[Social Security Number]
left join 
(select *  FROM [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and [External Status Code] in ('') and [Internal Status Code] in ('','N')
	and Extract_DatePart = 202204 and mob > 11) c  
	on a.Durable_Key=c.Durable_Key
left join (select * from [Analytics].[dbo].[Transunion_CreditBureau_data_Apr22]) d   
on a.[Social Security Number] =d.SSN
left join (select ssn,min(Score_1) as Score_1 from analytics.dbo.TransUnion_CreditBureau_data_May21 group by SSN) e
on a.[Social Security Number] = e.SSN


select * from #OnlyBT



--===== CLI & BT List
--===================
Drop table if exists #Both
select 
distinct
g.[Social Security Number],g.[Durable_Key],a.[Master Account Key],f.[Account Number],
	a.[Card Description],
	cast('7/1/2022' as date) as [Campaign Start Date]
	,cast('8/31/2022' as date) as [Campaign End Date],
	case when(f.Deciling in (1,2,3)) then '3.99% for 12 Months, No BT Fees'
		when(f.Deciling in (4,5,6)) then '0% for 12 Months, No BT Fees' else NULL end as Offer,
	a.[Credit Limit] as [Existing CL],a.[Proposed CL] [Proposed CL],
	c.[Calc Norm Cash Annual Rate] as GO_TO_APR_CASH,
	b.FIRST as first_name,b.LAST as Last_name,b.City as City,b.State as State,
	b.ZIPCODE,b.[Address 1] ,b.[Address 2],
	a.[External Status Code],a.[Internal Status Code],
	a.[sp_month] as [Static Pool Month],
	(a.[Credit Limit] - a.[Last Statement Balance Amount]) as [Open to Buy],
	a.[mob],a.[Last Statement Balance Amount],a.[RevolvingBalance],
	a.[spend],a.[TRIPFLAG],a.[Last Statement Payment Amount],
	a.[FICO_Score],a.[Annual_Income],a.[Monthly_Income]
	--,[N_active_bankcard_Trades]
	,d.bc07 as [N_bankcard_Trades_in_past_12months],a.[Bureau_balance],a.[Debt_Burden],
	d.AT36 as [Months_since_most_recent_delq],d.BC28 as [Bureau_CL],
	e.Score_1 as FICO_May21 ,(a.FICO_Score-e.Score_1) as FICO_drift,
	d.COLL as N_collections_in_past_12months,d.G068 as N_accts_90plus_days_past_due_in_past_6months,a.N_Inquiries_in_past_6months,
	a.N_accts_bankruptcies,a.AGE,a.FICO_Band_DT,a.CL_Band_DT,a.Monthly_Diposable_Income,
	case when (Monthly_Diposable_Income - (0.03*([Proposed CL] - a.[Credit Limit]))) > 0 then 'YES' else 'NO' end as Ability_TO_Repay,
	'Test' [TEST_CONTROL group],
	b.NameMailFlag,b.MailingOnly,b.EStatementsEnabled,b.AddressTypeDescription


	into #Both
FROM (select * from #Main where Both_BTCLI=1) g 
left join (Select * from Analytics.DBO.JK_CLI22_Apr22_FinalList) a 
on g.Durable_Key = a.Durable_Key 
left join (Select * from Analytics.DBO.JK_BT22_Apr22_FinalList) f  
on g.Durable_Key = f.Durable_Key
left join #master b 
on g.[Social Security Number]= b.[Social Security Number]
left join 
	(select *  FROM [TMGData].[dbo].[cardholder]
		where [Active_flag] = 1 
		and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
		and [External Status Code] in ('') and [Internal Status Code] in ('','N')
		and Extract_DatePart = 202204 and mob > 11) c  
	on g.Durable_Key=c.Durable_Key
left join (select * from [Analytics].[dbo].[Transunion_CreditBureau_data_Apr22]) d   
on g.[Social Security Number] =d.SSN
left join (select ssn,min(Score_1) as Score_1 from analytics.dbo.TransUnion_CreditBureau_data_May21 group by SSN) e
on g.[Social Security Number] = e.SSN

go

select * from #Both

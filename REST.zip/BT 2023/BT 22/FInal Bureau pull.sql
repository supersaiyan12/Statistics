----------------------------------------------------- BUREAU DATA PULL --------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------
Drop table if exists #temp1
select 
Durable_Key
	,[Master Account Key]
	,[Social Security Number]
	,[Credit Limit]
	,mob
	,[Card Description]
	,[External Status Code]
	,[Internal Status Code]
	,[Last Statement Balance Amount]
	,RevolvingBalance
	,[Account Number]
	,[Account System Entry Date]
	,age
	,([Last Statement Sale Amount]-[Last Statement Return Amount]) as spend
	,TRIPFLAG
	,[Last Statement Payment Amount]
	,Extract_DatePart as sp_month

into #temp1
FROM [TMGData].[dbo].[cardholder]
where 1=1
AND [Active_flag] = 1 
and [Card Description] not in ('Mastercard Business','MasterCard Black & Gold','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
and [External Status Code] in ('') and [Internal Status Code] in ('','N')
and Extract_DatePart = 202203
and mob > 11 
and (Durable_Key in (select distinct Durable_Key from Analytics.dbo.JK_CLI2022_FinalCards) 
or Durable_Key in (select distinct Durable_Key from Analytics.dbo.jk_2022_BTList) )


--**********************
--|| SSN REDUDANCIES ||
--**********************
--Drop table if exists #MultipleSSNs
--select
--distinct
--SSN
--,count(*) cnt
--into #MultipleSSNs
--from ARCUSYM000..NAME
--where ProcessDate = '20220430'
--and SSN in (select distinct [Social Security Number] from #temp1)
--and type = 0  and EXPIRATIONDATE is null and DEATHDATE is null

--group by 
--ssn
--having count(*)>1
--order by 2 desc

--**********************
--|| MEMBER DATA PULL ||
--**********************
Drop table if exists #Member
Select 
distinct 
ssn
,first
,last
,CITY
,STATE
,street
,ZIPCODE
into #member
From 
(select
*
,ROW_NUMBER() Over(Partition by ssn order by lastfmdate desc,recordchangedate desc) as rank
from ARCUSYM000..NAME
where ProcessDate = '20220430'
and SSN in (select distinct [Social Security Number] from #temp1)
and FIRST is not null
and LAST is not null
and city is not null
and STATE is not null
and ZIPCODE is not null
and type = 0  and EXPIRATIONDATE is null and DEATHDATE is null) a
where rank =1



select distinct SSN from ARCUSYM000..NAME
where ProcessDate = '20220430'
and type = 0  and EXPIRATIONDATE is null and DEATHDATE is null
and SSN in (select distinct [Social Security Number] from #temp1)




--****************************
--|| SECURED CARD EXCLUSION ||
--****************************
drop table if exists #temp3a
select distinct PARENTACCOUNT,SSN_UserChar3,TMGDurableKey_UserChar10
		 into #temp3a
		 from ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard 
		 where ProcessDate = 20220501
		 and ExpireDate is null and SSN_UserChar3 is not null and TMGDurableKey_UserChar10 is not null

drop table if exists #temp3
		 select a.ACCOUNTNUMBER,b.PARENTACCOUNT,b.USERCHAR1,b.USERCHAR13
		 into #temp3
		 from ARCUSYM000..ACCOUNT A
		 left join ARCUSYM000..TRACKING b
		 on a.ACCOUNTNUMBER = b.PARENTACCOUNT
		 and a.ProcessDate = b.ProcessDate
		 where a.ProcessDate = 20220501
		 and b.TYPE = 30
		 and b.EXPIREDATE is null


--*****************************
--|| CARDHOLDER OPTIMIZATION ||
--*****************************
Drop table if exists #temp1a
select
* 
into #temp1a
from 
(Select 
*
,rank() Over(Partition by [Social Security Number] order by Durable_Key desc) as rank
from #temp1
where
[Social Security Number] in (select distinct SSN from #Member)
) a
where rank =1


--*********************************
--|| SSN REDUNDANCY OPTIMIZATION ||
--*********************************
--Drop table if exists #SSNOpti
--Select 
--distinct 
--SSN
--,FIRST
--,LAST
--,STREET
--,city
--,STATE
--into #SSNOpti
--from 
--( 
--SELECT 
--*
--,ROW_NUMBER() Over(Partition by ssn order by lastfmdate desc,recordchangedate desc) as rank
--FROM ARCUSYM000..NAME
--where ProcessDate = '20220430'
--and SSN in (select distinct SSN from #MultipleSSNs)
--and FIRST is not null
--and LAST is not null
--and city is not null
--and STATE is not null
--and ZIPCODE is not null
--and type = 0  and EXPIRATIONDATE is null and DEATHDATE is null) X

--where rank =1




--****************
--|| FINAL DATA ||
--***************
Drop table if exists #Final
Select 
distinct

 b.FIRST as [First Name],b.LAST as [Last Name],
	  a.Durable_Key as [Reference Number],
	  a.[Social Security Number] as [Social Security Number (SSN)],
	  '' as [Address Number],
	  '' as [Pre-Directional],
	  b.STREET as [Street Name or Full Street Address (Required)],
	  '' as [Post-Directional],
	  '' as [Street Type],
	  b.CITY as [CITY],
	  b.STATE as [STATE],
	  b.ZIPCODE as [ZIPCODE],
	  '' as [Maternal Name],
	  a.[Master Account Key],
	  a.[Account Number],
	  a.[External Status Code],
	  a.[Internal Status Code],
	  a.[Card Description],
	  a.[Account System Entry Date],
	  a.[Credit Limit],
	  202203 as extract_datepart,
	  a.AGE		
	  ,USERCHAR13
into #Final
from #temp1a a left join #Member b
on a.[Social Security Number] = b.SSN
left join #temp3 c
on a.[Account Number] = c.USERCHAR1


-------------------

select 
[First Name],
[Last Name],
	[Reference Number],
	 [Social Security Number (SSN)] = cast( [Social Security Number (SSN)] as varchar),
	  '' as [Address Number],
	  '' as [Pre-Directional],
	  [Street Name or Full Street Address (Required)],
	  '' as [Post-Directional],

	  '' as [Street Type],
	  CITY as [CITY],
	  STATE as [STATE],
	  ZIPCODE as [ZIPCODE],
	  '' as [Maternal Name],
	  [Master Account Key],
	  [Account Number],
	  [External Status Code],
	  [Internal Status Code],
	  [Card Description],
	  [Account System Entry Date],
	  [Credit Limit],
	  202203 as extract_datepart,
	  AGE	
from #Final
where 1=1
and [Social Security Number (SSN)] not in (select distinct [Social Security Number (SSN)] from #Final where USERCHAR13 = 'S')







--******************************************** TARGET LIST ***************************************************
--******************************************** ***************************************************************


--GREENSTATE_CREDIT_CARD

 DROP TABLE IF EXISTS #GSMEMBER

 SELECT [ACCOUNT NUMBER],
 [LAST STATEMENT BALANCE AMOUNT],[ACCOUNT SYSTEM ENTRY DATE],[CARD DESCRIPTION] 
 INTO #GSMEMBER 
 FROM [TMGDATA].[DBO].[CARDHOLDER] 
 WHERE ACTIVE_FLAG=1
 AND EXTRACT_DATEPART IN (SELECT MAX(EXTRACT_DATEPART) FROM [TMGDATA].[DBO].[CARDHOLDER]  ) --202212 IS NOT AVAILABLE 
--AND [INTERNAL STATUS CODE] IN ('','N') 
AND [EXTERNAL STATUS CODE] NOT IN ('C','Z')


	DROP TABLE IF EXISTS #TEMP6
	SELECT DISTINCT PARENTACCOUNT,CARDNUMBER_USERCHAR1,SSN_USERCHAR3,STATEMENTBALANCE_USERAMOUNT12
	INTO #TEMP6  
	FROM ARCUSYM000.TRACKING.TVWARCUTRACKINGCREDITCARD
	WHERE PROCESSDATE IN (SELECT MAX(PROCESSDATE) FROM ARCUSYM000.TRACKING.TVWARCUTRACKINGCREDITCARD )
	 --JUST TO FETCH P.AC WE CAN USE NOV DATA BUT I USED LATEST P.DATE
	AND OPENDATE_USERDATE7 IS NOT NULL 
	AND EXPIRATIONDATE_USERDATE3 IS NOT NULL 
	AND (EXTERNALSTATUS_USERCHAR8 NOT IN ('CHARGEOFF','CLOSED')  --CRT CLOSED instead of CLOSE
	OR  EXTERNALSTATUS_USERCHAR8 IS NULL)
	AND SSN_USERCHAR3 NOT IN ('000000000','111111111','999999999')
	ORDER BY CARDNUMBER_USERCHAR1 --118015


	DROP TABLE IF EXISTS #TEMP7
	SELECT A.*,PARENTACCOUNT  /*,MAX(B.SSN_USERCHAR3)*/
	 INTO #TEMP7  
	 FROM #GSMEMBER A
	LEFT JOIN #TEMP6 B
	ON A.[ACCOUNT NUMBER]=B.CARDNUMBER_USERCHAR1 
	WHERE [CARD DESCRIPTION] NOT IN ('MASTERCARD BUSINESS','MASTERCARD MERCHANT PLATINUM')
	--GROUP BY [ACCOUNT NUMBER],[LAST STATEMENT BALANCE AMOUNT],   --CRT hided
	--[ACCOUNT SYSTEM ENTRY DATE],[CARD DESCRIPTION],PARENTACCOUNT

--=========================================== TO FIND NUMBER OF CARDS AND BALANCE ========================================================
--====================================================================================================================

--TO FIND NUMBER OF CARDS AND BALANCE 
	DROP TABLE IF EXISTS #TEMP
	SELECT  PARENTACCOUNT,COUNT(*) '#CC',ISNULL(SUM([LAST STATEMENT BALANCE AMOUNT]),0) '$CC_BALANCE' 
	INTO #TEMP
	FROM
	#TEMP7
	GROUP BY PARENTACCOUNT


--=========================================== FETCHING SSN ========================================================
--====================================================================================================================

	DROP TABLE IF EXISTS #TEMP_1
	 SELECT A.*, B.ACCOUNTPRIMENAMESSN
	 INTO #TEMP_1 
	 FROM #TEMP A
	 LEFT JOIN ARCUSYM000.ARCU.ARCUACCOUNTDETAILED B
	 ON A.PARENTACCOUNT=B.ACCOUNTNUMBER
	 WHERE B.PROCESSDATE IN (SELECT MAX(PROCESSDATE) FROM ARCUSYM000.TRACKING.TVWARCUTRACKINGCREDITCARD ) --JUST TO FETCH SSN WE CAN USE NOV DATA BUT I USED LATEST P.DATE


--===========================================ADDING BUREAU DATA AND EXCLUDING GREENSTATE CC HOLDER   ========================================================
--====================================================================================================================

	 DROP TABLE IF EXISTS #1
	 SELECT A.* ,B.#CC,B.[$CC_BALANCE]
	 --,B.PARENTACCOUNT
	 --(A.CCOPENCOUNT-#CC) OTHER_CC 
	 INTO #1 
	 from  OPENQUERY ( [GSDWSQL01],'SELECT * FROM [BUREAUDATA].[DBO].[TRANSUNIONATTRIBUTEHISTORY] WHERE DATE = 202411') A --NEW BUREAU TABLE NEED TO BE CHANGE 
	 LEFT JOIN #TEMP_1  B
	 ON A.SSN=B.ACCOUNTPRIMENAMESSN
	 WHERE B.#CC IS NULL 

 --SELECT SSN ,COUNT(SSN) FROM #1 GROUP BY SSN  HAVING COUNT(SSN)>1 

 --select count(1) from  #1 # 255009
 --#TEMP_1 where AccountPrimeNameSSN in (Select top 3 * from #1)
 --Select top 3 * from #1
 --Select top 3 * from #TEMP_1
 
--=========================================== reference List  ========================================================
--====================================================================================================================
DROP TABLE IF EXISTS #Referencelist
	SELECT SSN,FICO,
	ISNULL(NUMBERINQUIRIESP6MONTHS,-9999999) NUMBERINQUIRIESP6MONTHS,
	ISNULL(AGGREGATEDSPENDPAST3MONTHS,-9999999) AGGREGATEDSPENDPAST3MONTHS,
	ISNULL(CCTOTALAVAILABLELOC,-9999999) CCTOTALAVAILABLELOC,
	ISNULL(TOPOFWALLETCCANNUALSPEND,-9999999) TOPOFWALLETCCANNUALSPEND,
	ISNULL(AUTOOPENTRADEBALANCE,-9999999) AUTOOPENTRADEBALANCE,
	ISNULL(CCOPENCOUNT,-9999999) CCOPENCOUNT,
	ISNULL(AUTOOPENTRADECOUNT,-9999999)AUTOOPENTRADECOUNT
	INTO #Referencelist
	FROM #1 -- 

  select * from #Referencelist order by 1 desc
  
--=========================================== RISK_EXCLUSION ========================================================
--====================================================================================================================

 DROP TABLE IF EXISTS #TARGET_MEMBERS
	SELECT SSN,FICO
	,case when NUMBERINQUIRIESP6MONTHS < 0 then 0 else NUMBERINQUIRIESP6MONTHS end as NUMBERINQUIRIESP6MONTHS
	,case when AGGREGATEDSPENDPAST3MONTHS < 0 then 0 else AGGREGATEDSPENDPAST3MONTHS end as AGGREGATEDSPENDPAST3MONTHS
	,case when CCTOTALAVAILABLELOC < 0 then 0 else CCTOTALAVAILABLELOC end as CCTOTALAVAILABLELOC
	,case when TOPOFWALLETCCANNUALSPEND < 0 then 0 else TOPOFWALLETCCANNUALSPEND end as TOPOFWALLETCCANNUALSPEND
	,case when AUTOOPENTRADEBALANCE < 0 then 0 else AUTOOPENTRADEBALANCE end as AUTOOPENTRADEBALANCE
	,case when CCOPENCOUNT < 0 then 0 else CCOPENCOUNT end as CCOPENCOUNT
	,case when AUTOOPENTRADECOUNT < 0 then 0 else AUTOOPENTRADECOUNT end as AUTOOPENTRADECOUNT



	--ISNULL(NUMBERINQUIRIESP6MONTHS,0) NUMBERINQUIRIESP6MONTHS,
	--ISNULL(AGGREGATEDSPENDPAST3MONTHS,0) AGGREGATEDSPENDPAST3MONTHS,
	--ISNULL(CCTOTALAVAILABLELOC,0) CCTOTALAVAILABLELOC,
	--ISNULL(TOPOFWALLETCCANNUALSPEND,0) TOPOFWALLETCCANNUALSPEND,
	--ISNULL(AUTOOPENTRADEBALANCE,0) AUTOOPENTRADEBALANCE,
	--ISNULL(CCOPENCOUNT,0) CCOPENCOUNT,
	--ISNULL(AUTOOPENTRADECOUNT,0)AUTOOPENTRADECOUNT

	--,CASE WHEN FICO < 640 THEN '20.90'
	--							  WHEN FICO >= 640 AND FICO <=679 THEN '16.90'
	--							  WHEN FICO > 680 AND FICO <=729 THEN '13.90'
						
	--							  WHEN FICO >= 730 THEN '12.90'
	--							  ELSE NULL END [APR_GS] 
	INTO #TARGET_MEMBERS
	FROM #1 --269392 
	WHERE (FICO>700)--161610
	--AND CCREVOLVINGBALANCE>0 --47926
	AND (BANKRUPTCYCOUNT=0 OR BANKRUPTCYCOUNT =-4) --46134
	--AND (NUMBERINQUIRIESP6MONTHS<=3) --43866 
	AND (CHARGEOFFTRADECOUNTP12MONTHS<=0  )--43811
	AND (CCWORSTRATINGP12MONTHS<=1  ) --43452

	AND (NUMBERINQUIRIESP6MONTHS<=2) -- 0
	--AND (CHARGEOFFTRADECOUNTP12MONTHS<=0  )-- 13
	--AND (Worst_Rating_on_CC_Trades_in_Past_12_Months<=1  ) -- 359
	and (ForeclosureCountP12Months<=0)-- 0
	AND (autoWORSTRATINGP12MONTHS<=1 ) -- 45
	AND (helocWORSTRATINGP12MONTHS<=1 ) -- 10
	AND (heWORSTRATINGP12MONTHS<=1 )  -- 6


--where (FICO>660) --182323
----and CCRevolvingBalance>0 --60597
--and (BankruptcyCount=0 or BankruptcyCount is null) --57234
--and (NumberInquiriesP6Months<=3) --44417 
--and (ChargeOffTradeCountP12Months=0 or ChargeOffTradeCountP12Months is null )
--and (CCWorstRatingP12Months<3 or CCWorstRatingP12Months is null )

--SELECT 
--CHARGEOFFTRADECOUNTP12MONTHS,COUNT(*) 
--FROM 
--  OPENQUERY ( [GSDWSQL01],'SELECT * FROM [BUREAUDATA].[DBO].[TRANSUNIONATTRIBUTEHISTORY] WHERE DATE = 202311')
--  --WHERE BANKRUPTCYCOUNT<0
--  WHERE DATE=202311
--  GROUP BY CHARGEOFFTRADECOUNTP12MONTHS
  
--   --NEW BUREAU TABLE NEED TO BE CHANGE 
--SELECT 
--DISTINCT BANKRUPTCYCOUNT FROM [BUREAUDATA].[DBO].[TRANSUNIONATTRIBUTEHISTORY]



-- CREATING SCORE  136361

select top 4 * from #TARGET_MEMBERS
select top 4 * from #FINAL

--=========================================== CREATING SCORE ========================================================
--====================================================================================================================

	DROP TABLE IF EXISTS #FINAL
	SELECT *
	,((0.35*SCALED_NUMBERINQUIRIESP6MONTHS)+(0.25*SCALED_AGGREGATEDSPENDPAST3MONTHS)+(0.15*SCALED_CCTOTALAVAILABLELOC)
	+(0.10*SCALED_TOPOFWALLETCCANNUALSPEND)+(0.05*SCALED_AUTOOPENTRADEBALANCE)+(0.05*SCALED_AUTOOPENTRADECOUNT)
	+(0.05*SCALED_CCOPENCOUNT)) SCORE
	INTO #FINAL 
	FROM (
	SELECT DISTINCT *,
	(CAST((NUMBERINQUIRIESP6MONTHS-(SELECT MIN(NUMBERINQUIRIESP6MONTHS) FROM #TARGET_MEMBERS))AS DECIMAL(18,7))/
	CAST(((SELECT  MAX(NUMBERINQUIRIESP6MONTHS) FROM #TARGET_MEMBERS)-(SELECT  MIN(NUMBERINQUIRIESP6MONTHS) FROM #TARGET_MEMBERS)
	)AS DECIMAL(18,7)))*100 SCALED_NUMBERINQUIRIESP6MONTHS,

	(CAST((AGGREGATEDSPENDPAST3MONTHS -(SELECT  MIN(AGGREGATEDSPENDPAST3MONTHS) FROM #TARGET_MEMBERS))AS DECIMAL(18,7))/
	CAST(((SELECT  MAX(AGGREGATEDSPENDPAST3MONTHS) FROM #TARGET_MEMBERS)-(SELECT  MIN(AGGREGATEDSPENDPAST3MONTHS) FROM #TARGET_MEMBERS)
	)AS DECIMAL(18,7)))*100 SCALED_AGGREGATEDSPENDPAST3MONTHS,

	(CAST((CCTOTALAVAILABLELOC -(SELECT  MIN(CCTOTALAVAILABLELOC) FROM #TARGET_MEMBERS))AS DECIMAL(18,7))/
	CAST(((SELECT  MAX(CCTOTALAVAILABLELOC) FROM #TARGET_MEMBERS)-(SELECT  MIN(CCTOTALAVAILABLELOC) FROM #TARGET_MEMBERS)
	)AS DECIMAL(18,7)))*100 SCALED_CCTOTALAVAILABLELOC,


	(CAST((TOPOFWALLETCCANNUALSPEND -(SELECT  MIN(TOPOFWALLETCCANNUALSPEND) FROM #TARGET_MEMBERS))AS DECIMAL(18,7))/
	CAST(((SELECT  MAX(TOPOFWALLETCCANNUALSPEND) FROM #TARGET_MEMBERS)-(SELECT  MIN(TOPOFWALLETCCANNUALSPEND) FROM #TARGET_MEMBERS)
	)AS DECIMAL(18,7)))*100 SCALED_TOPOFWALLETCCANNUALSPEND,


	(CAST((AUTOOPENTRADEBALANCE -(SELECT  MIN(AUTOOPENTRADEBALANCE) FROM #TARGET_MEMBERS))AS DECIMAL(18,7))/
	CAST(((SELECT MAX(AUTOOPENTRADEBALANCE) FROM #TARGET_MEMBERS)-(SELECT  MIN(AUTOOPENTRADEBALANCE) FROM #TARGET_MEMBERS)
	)AS DECIMAL(18,7)))*100 SCALED_AUTOOPENTRADEBALANCE,


	(CAST((AUTOOPENTRADECOUNT -(SELECT  MIN(AUTOOPENTRADECOUNT) FROM #TARGET_MEMBERS))AS DECIMAL(18,7))/
	CAST(((SELECT  MAX(AUTOOPENTRADECOUNT) FROM #TARGET_MEMBERS)-(SELECT  MIN(AUTOOPENTRADECOUNT) FROM #TARGET_MEMBERS)
	)AS DECIMAL(18,7)))*100 SCALED_AUTOOPENTRADECOUNT,

	(CAST((CCOPENCOUNT -(SELECT  MIN(CCOPENCOUNT) FROM #TARGET_MEMBERS))AS DECIMAL(18,7))/
	CAST(((SELECT  MAX(CCOPENCOUNT) FROM #TARGET_MEMBERS)-(SELECT  MIN(CCOPENCOUNT) FROM #TARGET_MEMBERS)
	)AS DECIMAL(18,7)))*100 SCALED_CCOPENCOUNT

	FROM #TARGET_MEMBERS 

	 ) A

--=========================================== CREATING DECILE ========================================================
--====================================================================================================================

	 DROP TABLE IF EXISTS #FINAL1
	 SELECT *,
	(CAST(CAST((SCORE-(SELECT  MIN(SCORE) FROM #FINAL))AS DECIMAL(18,7))/
	CAST(((SELECT  MAX(SCORE) FROM #FINAL)-(SELECT  MIN(SCORE) FROM #FINAL)
	)AS DECIMAL(18,7))*1000 AS INT)) SCALED_SCORE
	, NTILE (10) OVER (
	ORDER BY SCORE DESC
	) DECILE INTO #FINAL1
	 FROM #FINAL

	 select DECILE,count(DECILE)  from #FINAL1 group by DECILE

	 /***savings results into perm table ***/
	 select * 
	 into Analytics.dbo.gebt2025
	 from #FINAL1

 --=========================================== VALIDATION ========================================================
----====================================================================================================================

-- SELECT * FROM #FINAL1 ORDER BY SCALED_SCORE DESC

-- select top 3 * from TMGData..cardholder where [Social Security Number] = '482279540'

-- SELECT COUNT(*) FROM #GSMEMBER --95570
 
-- SELECT COUNT(*) FROM #TEMP6 --138266
  
-- SELECT COUNT(*) FROM #TEMP7 --96296
   
-- SELECT COUNT(*) FROM #TEMP --94089
  
-- SELECT COUNT(*) FROM #TEMP_1 --94088

-- SELECT COUNT(*) FROM #1 --269392
  
-- SELECT COUNT(*) FROM #TARGET_MEMBERS--43452
 
-- SELECT COUNT(*) FROM #FINAL --43452
  
-- SELECT COUNT(*) FROM #FINAL1 --43452

-- SELECT count(*) FROM #FINAL1
-- where 1=1  
----and AUTOOPENTRADEBALANCE=0 --53987
----and NUMBERINQUIRIESP6MONTHS = 0 --100736
----and	AGGREGATEDSPENDPAST3MONTHS =0  --15912
----and	CCTOTALAVAILABLELOC = 0 --8149
----and	TOPOFWALLETCCANNUALSPEND =0 --10497
----and	AUTOOPENTRADEBALANCE =0 --53987
----and	CCOPENCOUNT =0 --7876
----and	AUTOOPENTRADECOUNT =0 --53975


/***last year data to create decision tree input data ***/
drop table if exists Analytics.dbo.gebt2024
select a.[Date First Active],a.[Date First Active New] Dates,a.FICO fico2,a.newcardwithbtflag,a.newcardflag,a.SSN ssn2,b.*
into Analytics.dbo.gebt2024
from analytics.dbo.[GreatEscapecrosstargetlist24withresponse] a -- In case of 2025 , take 2025 target list here
left join (SELECT * FROM OPENQUERY([GSDWSQL01],'SELECT * FROM [BureauData].[dbo].[TransUnionAttributeHistory] where Date = 202405 ')) b
on cast(a.SSN as int ) = b.ssn  --and cast(format(a.[Date First Active New],'yyyyMM') as int) = b.date
where newcardflag = 1

select top 4 *  from Analytics.dbo.gebt2025 a

/***current year data to implement decision tree results data ***/
drop table if exists Analytics.dbo.Great_Escape_Cross_sell_Targetlist2025
select a.*,
case when b.CCOpenBalance > 2255 and b.CCOpenCount <= 4 and b.AggregatedSpendPast3Months > 5197.5 then 'High'
	 when b.CCOpenBalance > 2255 and b.CCOpenCount <= 4 and b.AggregatedSpendPast3Months <= 5197.5 then 'Medium'
	 when b.CCOpenBalance > 2255 and b.CCOpenCount > 4 and b.AUTOOPENTRADEBALANCE > 445 then 'High'
	 when b.CCOpenBalance > 2255 and b.CCOpenCount > 4 and b.AUTOOPENTRADEBALANCE <= 445 then 'Medium'
	 when b.CCOpenBalance <= 2255 and b.OpenTradeBalance > 54556 then 'Low'
	 when b.CCOpenBalance <= 2255 and b.OpenTradeBalance <= 54556 then 'Low' end as BT_prob_segment
 -- Change this as per decision tree variables
into Analytics.dbo.Great_Escape_Cross_sell_Targetlist2025
from Analytics.dbo.gebt2025 a
left join (SELECT * FROM OPENQUERY([GSDWSQL01],'SELECT * FROM [BureauData].[dbo].[TransUnionAttributeHistory] where Date = 202411 ')) b
on cast(a.SSN as int ) = b.ssn  --and cast(format(a.[Date First Active New],'yyyyMM') as int) = b.date
--where newcardflag = 1

--select BT_prob_segment,count(*) from Analytics.dbo.Great_Escape_Cross_sell_Targetlist2025 group by BT_prob_segment
select * from Analytics.dbo.Great_Escape_Cross_sell_Targetlist2025 order by DECILE,BT_prob_segment

/***last year data to create decision tree input data ***/
drop table if exists Analytics.dbo.gebt2024
select a.[Date First Active],a.[Date First Active New] Dates,a.FICO fico2,a.newcardwithbtflag,a.newcardflag,a.SSN ssn2,b.*
into Analytics.dbo.gebt2024
from analytics.dbo.[GreatEscapecrosstargetlist24withresponse] a
left join (SELECT * FROM OPENQUERY([GSDWSQL01],'SELECT * FROM [BureauData].[dbo].[TransUnionAttributeHistory] where Date = 202405 ')) b
on cast(a.SSN as int ) = b.ssn  --and cast(format(a.[Date First Active New],'yyyyMM') as int) = b.date
where newcardflag = 1

select 
*
 --CCOpenCount,count(CCOpenCount) 
 --newcardwithbtflag,count(newcardwithbtflag)
from  Analytics.dbo.gebt2024-- order by 1
where 1 = 1
and CCOpenBalance <= 2255
--and OpenTradeBalance > 54556
--and CCOpenCount <= 4
group by newcardwithbtflag

/***this year data to create decision tree input data ***/
drop table if exists #gebt2025
select a.ssn,a.fico,a.DECILE,a.NUMBERINQUIRIESP6MONTHS,a.CCTOTALAVAILABLELOC,a.TOPOFWALLETCCANNUALSPEND,a.AUTOOPENTRADEBALANCE,b.CCOpenBalance,b.CCOpenCount,b.AggregatedSpendPast3Months,b.OpenTradeBalance
into #gebt2025
from Analytics.dbo.gebt2025 a
left join (SELECT * FROM OPENQUERY([GSDWSQL01],'SELECT * FROM [BureauData].[dbo].[TransUnionAttributeHistory] where Date = 202412 ')) b
on cast(a.SSN as int ) = b.ssn  --and cast(format(a.[Date First Active New],'yyyyMM') as int) = b.date
--where newcardflag = 1


drop table if exists #test
select *,
case when CCOpenBalance > 2255 and CCOpenCount <= 4 and AggregatedSpendPast3Months > 5197.5 then 'high'
	 when CCOpenBalance > 2255 and CCOpenCount <= 4 and AggregatedSpendPast3Months <= 5197.5 then 'high'
	 when CCOpenBalance > 2255 and CCOpenCount > 4 and AUTOOPENTRADEBALANCE > 445 then 'high'
	 when CCOpenBalance > 2255 and CCOpenCount > 4 and AUTOOPENTRADEBALANCE <= 445 then 'Medium'
	 when CCOpenBalance <= 2255 and OpenTradeBalance > 54556 then 'Low'
	 when CCOpenBalance <= 2255 and OpenTradeBalance <= 54556 then 'Low' end as BT_prob_segment
	 into #test
	  from #gebt2025
where 1 = 1

select
 BT_prob_segment,count(*) 

from #test
--where BT_prob_segment is not null
 group by BT_prob_segment





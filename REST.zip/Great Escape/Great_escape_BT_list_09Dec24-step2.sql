--==================================================== 2024 BALANCE TRANSFER - LIST GENERATION ====================================================
--=====================================================================================================================================================

--**********************
--|| STATIC POOL DATA ||
--**********************

---------------------------------------

DROP TABLE IF EXISTS #temp1
SELECT 
	A.Durable_Key
	,A.[Master Account Key]
	,A.[Social Security Number],
	A.[Credit Limit] -- getting new CL if they got
	,A.mob
	,A.[Card Description]
	,A.[External Status Code]
	,A.[Internal Status Code]
	,A.[Last Statement Balance Amount]
	,A.RevolvingBalance
	,A.age
	,(A.[Last Statement Sale Amount]-A.[Last Statement Return Amount]) as spendOpenToBuy
	,A.TRIPFLAG
	,A.[Last Statement Payment Amount]
	,A.Extract_DatePart as sp_month
	,A.[Account System Entry Date]
	,A.[Account Number]
	--, CASE WHEN B.DURABLE_KEY IS NOT NULL THEN B.[Proposed CL] ELSE
	 ,A.[Credit Limit] - A.[Last Statement Balance Amount] as OpenToBuy
	,case when a.TRIPFLAG = 'T' then 1 else 0 end as TransactorFlag
INTO #temp1
FROM [TMGData].[dbo].[cardholder] a
where 1=1
and a.[Active_flag] = 1 
and a.Extract_DatePart = 202411 --?
and a.[External Status Code] in ('') and a.[Internal Status Code] in ('','N')
and a.[Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
and A.[Credit Limit] > 1000
--and  ( A.[Credit Limit] - a.[Last Statement Balance Amount]) > 500
and A.mob > 11
and A.[Credit Limit] - A.[Last Statement Balance Amount] >= 2500 -- open to buy

--select *  from #temp1

--***********************************
-- || STEP 1: PRE 12 MONTH NUMBERS ||
--***********************************
Drop table if exists #temp_pre_12mo_2
select 
	Durable_Key as d_pre_12mo
	,sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_12mo
	,sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_12mo
	,sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_12mo
	,sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_12mo
	,sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_12mo
	,sum([Last Statement Balance Amount]) as sum_bal_pre_12mo
	,sum(RevolvingBalance) as sum_revbal_pre_12mo
	,sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_12mo
	,avg([Last Statement Balance Amount]) as avg_bal_pre_12mo
	,avg(RevolvingBalance) as avg_revbal_pre_12mo
	,avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_12mo

into #temp_pre_12mo_2
from [TMGData].[dbo].[cardholder]

	where [Active_flag] = 1 
	and Extract_DatePart between 202411 - 99 and 202411 --11?
	and Durable_Key in (select Durable_Key from #temp1)
	group by Durable_Key

go


--******************************************
-- ||  TIMES TRANSACTORS IN LAST 24 MONTHS ||
--******************************************
drop table if exists #Times_Transactors
Select 
Durable_Key as DurableKey_TimesTransactors
,sum(case when TRIPFLAG = 'T' then 1 else 0 end) as Times_Transactors

into #Times_Transactors
from [TMGData].[dbo].[cardholder]

where [Active_flag] = 1 
and Extract_DatePart between 202411 - 199 and 202411
and Durable_Key in (select Durable_Key from #temp1)
group by Durable_Key

--******************************************
-- || STEP 2: PRE 12 MONTH PROFIT NUMBERS ||
--******************************************
Drop table if exists #temp_pre_12mo_3
select 
	Durable_Key
	,Extract_DatePart
	,case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization
	,case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate
	,case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate

	,([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income
	,([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees
	,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income    
	,([Last Statement Balance Amount]*0.02/12) as COF
	,(ChargeoffAmount_final) as chgoff_amt
	,case when [Card Description] in ('Mastercard Platinum Rewards','Mastercard World Credit') 
	then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end as rewards_expense -- verify it with internal team
	,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense
	,case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost
	into #temp_pre_12mo_3
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and Extract_DatePart between 202411 - 99 and 202411
	and Durable_Key in 
	(select Durable_Key from #temp1)

--**************************************************
-- || STEP 3: PRE 12 MONTH PROFIT NUMBERS SUMMARY ||
--**************************************************
Drop table if exists #temp_pre_12mo_3a
select 
	Durable_Key
	,count(*) as N_months
	,sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit
	,avg(Utilization) as avg_Utilization
	,avg(revolve_rate) as avg_revolve_rate
	,avg(payment_rate) as avg_payment_rate

into #temp_pre_12mo_3a
from #temp_pre_12mo_3
group by Durable_Key
	
go

Drop table if exists #temp_pre_12mo_4
select 
	a.*
	,b.profit as sum_profit_pre_12mo,b.profit/b.N_months as avg_profit_pre_12mo
	,b.avg_Utilization as avg_Utilization_pre_12mo
	,b.avg_revolve_rate as avg_revolve_rate_pre_12mo
	,b.avg_payment_rate as avg_payment_rate_pre_12mo

into #temp_pre_12mo_4
from #temp_pre_12mo_2 a
left join #temp_pre_12mo_3a b
on a.d_pre_12mo = b.Durable_Key

--*********************************
-- || STEP 4: PRE 6 MONTH NUMBERS||
--*********************************
Drop table if exists #temp_pre_6mo_2
select Durable_Key  as d_pre_6mo,
	sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_6mo,
	sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_6mo,
	sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_6mo,
	sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_6mo,
	sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_6mo,
	sum([Last Statement Balance Amount]) as sum_bal_pre_6mo,
	sum(RevolvingBalance) as sum_revbal_pre_6mo,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_6mo,
	avg([Last Statement Balance Amount]) as avg_bal_pre_6mo,
	avg(RevolvingBalance) as avg_revbal_pre_6mo,
	avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_6mo
	
	into #temp_pre_6mo_2
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and Extract_DatePart between  202406 and 202411
	and Durable_Key in 
	(select Durable_Key from #temp1)
	group by Durable_Key


--******************************************
-- || STEP 5: PRE 6 MONTH PROFIT NUMBERS ||
--******************************************
Drop table if exists  #temp_pre_6mo_3
select 
	Durable_Key
	,Extract_DatePart
	,case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization
	,case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate
	,case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate

	,([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income
	,([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees
	,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income   
	,([Last Statement Balance Amount]*0.02/12) as COF
	,(ChargeoffAmount_final) as chgoff_amt
	,case when [Card Description] in ('Mastercard Platinum Rewards','Mastercard World Credit') 
	then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end as rewards_expense -- verify
	,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense
	,case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost

into #temp_pre_6mo_3
from [TMGData].[dbo].[cardholder]
where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
and Extract_DatePart between 202406 and 202411
and Durable_Key in 
(select Durable_Key from #temp1)


--*************************************************
-- || STEP 6: PRE 6 MONTH PROFIT NUMBERS SUMMARY ||
--*************************************************
Drop table if exists #temp_pre_6mo_3a
select 
	Durable_Key
	,count(*) as N_months
	,sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit
	,avg(Utilization) as avg_Utilization,avg(revolve_rate) as avg_revolve_rate,avg(payment_rate) as avg_payment_rate

into #temp_pre_6mo_3a
from #temp_pre_6mo_3
group by Durable_Key

--***************************************************
-- || STEP 7: DATA GETHERING OF DATA BUILDED ABOVE ||
--***************************************************
Drop table if exists #temp_pre_6mo_3b
select a.*,
	b.profit as sum_profit_pre_6mo,b.profit/b.N_months as avg_profit_pre_6mo
	,b.avg_Utilization as avg_Utilization_pre_6mo
	,b.avg_revolve_rate as avg_revolve_rate_pre_6mo
	,b.avg_payment_rate as avg_payment_rate_pre_6mo

into #temp_pre_6mo_3b
from #temp_pre_6mo_2 a
left join #temp_pre_6mo_3a b
on a.d_pre_6mo = b.Durable_Key

go

--bureau data 
	Drop table if exists #temp4a
	select distinct 
	SSN
	,FICO as FICO_Score,
	case when CCTotalAvailableLOC = 0 then 1 else 
	(CCRevolvingBalance/CCTotalAvailableLOC) end as Debt_Burden
	,NumberInquiriesP6Months as N_Inquiries_in_past_6months
	,CCRevolvingBalance*1 as Bureau_Balance
	,NumberInquiriesP6Months as N_accts_bankruptcies
	,CCOpenCount as N_BanckcardTradesPast12Mos --N_BanckcardTradesPast12Mos
	,CCWorstRatingP12Months as Worst_Rating_on_CC_Trades_in_Past_12_Months
	, BANKRUPTCYCOUNT
	, NUMBERINQUIRIESP6MONTHS
	, CHARGEOFFTRADECOUNTP12MONTHS
	, ForeclosureCountP12Months
	, autoWORSTRATINGP12MONTHS
	, helocWORSTRATINGP12MONTHS
	, heWORSTRATINGP12MONTHS
into #temp4a
from openquery ( [GSDWsql01],'select * from [BureauData].[dbo].[TransUnionAttributeHistory] where date = 202411 ' )
where SSN in (select  distinct [Social Security Number] from #temp1)


	go
--GREENSTATE_CREDIT_CARD (COPIED FROM VISHAL CODE)

 DROP TABLE IF EXISTS #GSMEMBER

 SELECT  [ACCOUNT NUMBER],
 [LAST STATEMENT BALANCE AMOUNT],[ACCOUNT SYSTEM ENTRY DATE],[CARD DESCRIPTION] 
 INTO #GSMEMBER 
 FROM [TMGDATA].[DBO].[CARDHOLDER] 
 WHERE ACTIVE_FLAG=1
 AND EXTRACT_DATEPART IN (SELECT MAX(EXTRACT_DATEPART) FROM [TMGDATA].[DBO].[CARDHOLDER]  ) --202212 IS NOT AVAILABLE 
--AND [INTERNAL STATUS CODE] IN ('','N') 
AND [EXTERNAL STATUS CODE] NOT IN ('C','Z')

	go

	DROP TABLE IF EXISTS #TEMP6
	SELECT DISTINCT PARENTACCOUNT,CARDNUMBER_USERCHAR1,SSN_USERCHAR3,STATEMENTBALANCE_USERAMOUNT12
	INTO #TEMP6  
	FROM 
	ARCUSYM000.TRACKING.TVWARCUTRACKINGCREDITCARD
	WHERE PROCESSDATE IN (SELECT max(PROCESSDATE) FROM ARCUSYM000.TRACKING.TVWARCUTRACKINGCREDITCARD ) ---CRT we can take latest process date
	 --JUST TO FETCH P.AC WE CAN USE NOV DATA BUT I USED LATEST P.DATE
	AND OPENDATE_USERDATE7 IS NOT NULL 
	AND EXPIRATIONDATE_USERDATE3 IS NOT NULL 
	AND (EXTERNALSTATUS_USERCHAR8 NOT IN ('CHARGEOFF','CLOSED') ---CRT CLOSED instead of CLOSE
	OR  EXTERNALSTATUS_USERCHAR8 IS NULL)
	AND SSN_USERCHAR3 NOT IN ('000000000','111111111','999999999')
	ORDER BY CARDNUMBER_USERCHAR1 --118015

	DROP TABLE IF EXISTS #TEMP7
	SELECT A.*,PARENTACCOUNT  /*,MAX(B.SSN_USERCHAR3)*/
	 INTO #TEMP7  
	 FROM #GSMEMBER A
	LEFT JOIN #TEMP6 B
	ON A.[ACCOUNT NUMBER]=B.CARDNUMBER_USERCHAR1 
	WHERE [CARD DESCRIPTION] NOT IN ('MASTERCARD BUSINESS','MASTERCARD MERCHANT PLATINUM')
	GROUP BY [ACCOUNT NUMBER],[LAST STATEMENT BALANCE AMOUNT],
	[ACCOUNT SYSTEM ENTRY DATE],[CARD DESCRIPTION],PARENTACCOUNT

--=========================================== TO FIND NUMBER OF CARDS AND BALANCE ========================================================
--====================================================================================================================

--TO FIND NUMBER OF CARDS AND BALANCE 
	DROP TABLE IF EXISTS #TEMP_VR
	SELECT  PARENTACCOUNT,COUNT(*) '#CC',ISNULL(SUM([LAST STATEMENT BALANCE AMOUNT]),0) 'CC_BALANCE' 
	INTO #TEMP_VR
	FROM #TEMP7
	GROUP BY PARENTACCOUNT
	
--=========================================== FETCHING SSN ========================================================
--====================================================================================================================

 DROP TABLE IF EXISTS #TEMP_1
 SELECT B.ACCOUNTPRIMENAMESSN,A.* 
 INTO #TEMP_1 
 FROM #TEMP_VR A
 LEFT JOIN ARCUSYM000.ARCU.ARCUACCOUNTDETAILED B
 ON A.PARENTACCOUNT=B.ACCOUNTNUMBER
 WHERE B.PROCESSDATE IN (SELECT MAX(PROCESSDATE) FROM ARCUSYM000.TRACKING.TVWARCUTRACKINGCREDITCARD ) --JUST TO FETCH SSN WE CAN USE NOV DATA BUT I USED LATEST P.DATE
 
 -- REMOVING GS CARD ONLY
 drop table if exists #BUREAUSSN
select *
INTO #BUREAUSSN
from #temp4a aa--bureau
left join #TEMP_1 bb--GS
on aa.ssn = bb.AccountPrimeNameSSN
where 1 =1 
--and (Bureau_Balance-bb.CC_BALANCE) between 2000 and 15000
--and Bureau_Balance between 2000 and 15000
--select * from #temp2

SELECT  Bureau_Balance,count(Bureau_Balance) 
FROM #BUREAUSSN group by Bureau_Balance
order by 1

Drop table if exists #temp4
select 
a.*
into #temp4
from #temp4a a
--WHERE Ssn IN (SELECT SSN FROM #BUREAUSSN)

-- left join #temp4b b
--on a.SSN = b.customerInput_socSecurityNum0007

--**********************************
-- || STEP 09 : COMBINING ALL DATA ||
--**********************************
--no chnages 
Drop table if exists #temp2
select a.*,b.*,c.*,d.*,e.*
	,(avg_Utilization_pre_6mo-avg_Utilization_pre_12mo) / case when avg_Utilization_pre_12mo =0 then 1 else avg_Utilization_pre_12mo end as Util_Drift
	,case when(avg_Utilization_pre_12mo > 0.75) then 1 else 0 end as Exclu_AvgUtilPre12Months
	,case when((avg_Utilization_pre_12mo between 0.50 and 0.75) and 
		(avg_Utilization_pre_6mo-avg_Utilization_pre_12mo) / case when avg_Utilization_pre_12mo =0 then 1 else avg_Utilization_pre_12mo end > 0.25) then 1 else 0 end as Exclu_Utili2

	, case when (case when(avg_Utilization_pre_12mo >0.75) then 1 else 0 end =1 OR 
		case when((avg_Utilization_pre_6mo between 0.50 and 0.75)  and (avg_Utilization_pre_6mo-avg_Utilization_pre_12mo) / 
		case when avg_Utilization_pre_12mo =0 then 1 else avg_Utilization_pre_12mo end > 0.25) then 1 else 0 end =1) then 1 else 0 end as Exclu_FinalUtil
	
	,case when(d.FICO_score-f.Score_1 > 50) then 1 else 0 end as Exc_FicoDropped50Pts
	,case when((d.FICO_score between  680 and 709) and (d.FICO_score-f.Score_1) > 25) then 1 else 0 end as Exc_Fico2

	,case when(case when(d.FICO_score-f.Score_1 > 50) then 1 else 0 end =1 OR	
		case when((d.FICO_score between  680 and 709) and (d.FICO_score-f.Score_1) > 25) then 1 else 0 end =1) then 1 else 0 end as Exclu_FicoDrop

	into #temp2
	from #temp1 a
	left join #temp_pre_12mo_4 b
	on a.Durable_Key = b.d_pre_12mo
	left join #temp_pre_6mo_3b c
	on a.Durable_Key = c.d_pre_6mo
	left join #temp4 d
	on a.[Social Security Number] = d.SSN
	left join #Times_Transactors e
	on a.Durable_Key = e.DurableKey_TimesTransactors 
	left join analytics.dbo.TransUnion_CreditBureau_data_May21  f
	on a.[Social Security Number] = f.SSN

go

---***********************************
-- || STEP 14: RISK TRIGGERS DATA ||
--***********************************
drop table if exists #NAME1
	--select max(processdate) from ARCUSYM000..SAVINGS
	select distinct a.PARENTACCOUNT,SSN,BIRTHDATE,a.USERCHAR3 FICO_Latest
		into #NAME1
		from 
		(
		select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date 
		from ARCUSYM000..NAME
		) a
		left join ARCUSYM000..SAVINGS b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		and a.ProcessDate=b.ProcessDate
		where a.TYPE=0
		and a.ProcessDate=20241130
		and b.SHARECODE=0 
		and b.IRSCODE=0
		and b.TYPE<9000
		and b.type<>10 
		and b.type<>11
		and b.type<>12
		and b.type<>14
		and b.type<>113
		and b.type<>510
		and b.type<>512
		and b.ORIGINALDEPOSITDATE is not null
		and b.CLOSEDATE is null 
		and b.CHARGEOFFDATE is null
		order by PARENTACCOUNT
	
	go

	declare @date as date
	set @date = '2024-11-30'

	drop table if exists #Unemployment
	select 
	a.PARENTACCOUNT,1 Unemployment,sum(BALANCECHANGE) Amount
	into #Unemployment
	from 
	(
	select PARENTACCOUNT,PARENTID,EFFECTIVEDATE,SEQUENCENUMBER-1 as SEQUENCENUMBER,COMMENT
	, case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE)) 
	else  CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVE_DATE from ARCUSYM000..SAVINGSTRANSACTION
	where COMMENT like '%Unemplo%' and EFFECTIVEDATE >= @date --'2023-07-01' 
	) A 
	left join 
	(
	select PARENTACCOUNT,PARENTID,EFFECTIVEDATE,SEQUENCENUMBER,COMMENT,BALANCECHANGE
	, case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE)) 
	else  CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVE_DATE from ARCUSYM000..SAVINGSTRANSACTION
	where EFFECTIVEDATE >=   @date  --'2021-11-01 00:00:00'
	) b
	on a.PARENTACCOUNT=b.PARENTACCOUNT and a.PARENTID=b.PARENTID
	and a.EFFECTIVEDATE=b.EFFECTIVEDATE and a.SEQUENCENUMBER=b.SEQUENCENUMBER
	group by a.PARENTACCOUNT 


--select top 10 *  from #Unemployment
--select count(1)  from #Unemployment

	go

	--	declare @date as date
	--set @date = '2023-12-31'

	drop table if exists #Overdraft
	select 
	PARENTACCOUNT,sum(case when ProcessDate in (20230930,20231031,20231130) then [# Overdraft] else 0 end) [# Overdraft_2023] --(20220228,20220331,20220430)
		,sum(case when ProcessDate in (20240930,20241031,20241130) then [# Overdraft] else 0 end) [# Overdraft_2024]
	into #Overdraft
	from
		(select 
		ProcessDate,PARENTACCOUNT,sum(Overdraft_fee) Overdraft_fee,sum(Overdraft_count) [# Overdraft]
				
		from
				(
				select 
				*,case when Overdraft_fee>0 then 1 else 0 end Overdraft_count
				from
						(
						select 
						*,isnull(case when OVERDRAFTFEEYTD>0 then lead_overdraft-OVERDRAFTFEEYTD else 0 end,0) Overdraft_fee
						from 
								( select ProcessDate,PARENTACCOUNT,ID,TYPE
								,BALANCE
								,case when OPENDATE=CLOSEDATE then 0 else 1 end FLag ,OVERDRAFTFEELASTYR,OVERDRAFTTOLERANCE
								,overdraftfeeytd,LEAD(overdraftfeeytd,1) 
								over(partition by PARENTACCOUNT,ID,TYPE,year_ order by PARENTACCOUNT,ID,ProcessDate) lead_overdraft
								,CHARGEOFFDATE,OPENDATE,closedate
								from 
										(select * ,left(ProcessDate,4) year_ from ARCUSYM000..SAVINGS 
										where ProcessDate in (20230930,20231031,20231130,20240930,20241031,20241130)) A --(20210430,20210228,20210331,20220430,20220228,20220331)
								) B
						where  CHARGEOFFDATE is null and OpenDate is not null and CLOSEDATE is null and flag=1
						) A
				) D
				group by ProcessDate,PARENTACCOUNT
		) F
		where [# Overdraft] >0
		group by PARENTACCOUNT
				
			
Drop table if exists #HELOC
select PARENTACCOUNT,sum(Flag_HELOC) Flag_HELOC,sum(HELOC_sept) HELOC_sept,sum(HELOC_oct) HELOC_oct,
sum(HELOC_nov) HELOC_nov
into #HELOC
from
	(
	select top 100  ProcessDate,PARENTACCOUNT,case when Extract_date=Extract_open then 1 else 0 end Flag_HELOC
	,case when Extract_date=Extract_open and ProcessDate=20240930 then 1 else 0 end HELOC_sept
	,case when Extract_date=Extract_open and ProcessDate=20241031 then 1 else 0 end HELOC_oct
	,case when Extract_date=Extract_open and ProcessDate=20241130 then 1 else 0 end HELOC_nov
	from
	( select *,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate)) 
	else concat(year(opendate),month(opendate)) end Extract_open
	,CONCAT((PARENTACCOUNT),(id))UNID,dateadd(month,-1,DUEDATE) [Duedatenew]
	,left(ProcessDate,6) Extract_date,
	case when len(month(CHARGEOFFDATE))=1then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
	else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end extract_chargeoff
	,case when opendate=closedate then 0 else 1 end Flag
	,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
		from ARCUSYM000.dbo.LOAN 
		where  ORIGINALDATE is not null 
		and OpenDate is not null and CLOSEDATE is null 
		and (chargeoffdate is null)
		and processdate in (20240930,20241031,20241130) --(20210430,20210228,20210331)
		) A
		left join  ARCUSYM000.arcu.ARCULoanCategory B
		on a.TYPE=b.LoanType
		where DESCRIPTION like '%line of%' or DESCRIPTION like '%HELOC%'--LoanCategory2 like 'HEl%' 
		) B
		where Flag_HELOC>0
		group by PARENTACCOUNT
		
		go
		
	drop table if exists ##RiskTrigger
	select 
	a.SSN,a.FICO_Latest
	,sum(isnull(b.[# Overdraft_2024],0)) [# Overdraft_2024]
	,sum(isnull(b.[# Overdraft_2023],0)) [# Overdraft_2023]
	,sum(isnull(c.Amount,0)) [$ Unemployment],sum(isnull(c.Unemployment,0)) Unemployment
	,sum(isnull(d.Flag_HELOC,0)) Flag_HELOC,sum(isnull(d.HELOC_sept,0)) HELOC_sept
	,sum(isnull(d.HELOC_oct,0)) HELOC_oct,sum(isnull(d.HELOC_nov,0)) HELOC_nov
	into ##RiskTrigger
	from #NAME1 A
	left join #Overdraft b
	on a.PARENTACCOUNT=b.PARENTACCOUNT
	left join #Unemployment c
	on a.PARENTACCOUNT=c.PARENTACCOUNT
	left join #HELOC d
	on a.PARENTACCOUNT=d.PARENTACCOUNT
	Group by A.SSn,a.FICO_Latest

	select top 10 * from ##RiskTrigger

GO

drop table if exists #Risktriger_data
	select a.[Social Security Number],a.Durable_Key,a.[Master Account Key]
	,b.[# Overdraft_2024],b.[# Overdraft_2023],b.[$ Unemployment],b.Unemployment,b.Flag_HELOC,b.HELOC_sept,b.HELOC_oct,b.HELOC_nov--,b.HELOC_April
	into #Risktriger_data
	from (select distinct [Social Security Number],Durable_Key,[Master Account Key]
	from #temp1) a
	left join (select SSN
				,sum([# Overdraft_2024]) [# Overdraft_2024],sum([# Overdraft_2023]) [# Overdraft_2023]
				,sum([$ Unemployment]) [$ Unemployment],sum(Unemployment) Unemployment
				,sum(Flag_HELOC) Flag_HELOC,sum(HELOC_sept) HELOC_sept
				,sum(HELOC_oct) HELOC_oct,sum(HELOC_nov) HELOC_nov--,sum(HELOC_April) HELOC_April
				from ##RiskTrigger 
				group by SSN
				) b
	on a.[Social Security Number]=b.ssn
	where a.Durable_Key in (select Durable_Key from #temp1) 
	and a.[Master Account Key] in (select [Master Account Key] from #temp1	)
	
	go

	drop table if exists #Overdraft
	select *,case when [# Overdraft_2023]>0 and [# Overdraft_2024]>0 
	then [# Overdraft_2023]/[# Overdraft_2024] else 0 end Overdraft_rate
	 into #Overdraft
	 from #Risktriger_data
	 where [# Overdraft_2024]>0
	
	go

	 drop table if exists #Unemployment
	 select *,
	 case when [# Overdraft_2023]>0 and [# Overdraft_2024]>0 
	 then [# Overdraft_2023]/[# Overdraft_2024] else 0 end Overdraft_rate
	 into #Unemployment
	 from #Risktriger_data
	 where [$ Unemployment]>0
	
	go

	 drop table if exists #Heloc
	  select *,case when [# Overdraft_2023]>0 and [# Overdraft_2024]>0 
	  then [# Overdraft_2023]/[# Overdraft_2024] else 0 end Overdraft_rate
	 into #Heloc
	 from #Risktriger_data
	 where Flag_HELOC>0

	 go

	 drop table if exists #RiskExclude
	  select *,case when [# Overdraft_2023]>0 and [# Overdraft_2024]>0 
	  then [# Overdraft_2023]/[# Overdraft_2024] else 0 end Overdraft_rate
	 into #RiskExclude
	 from #Risktriger_data
	 where Flag_HELOC>0 or  [# Overdraft_2024]>0 or [$ Unemployment]>0

	go

	drop table if exists #risk_model_Exclusion
	select Durable_Key
	into #risk_model_Exclusion
	from analytics.dbo.Final_Riskmodel_list_25 --##Final_Riskmodel_list 
	where Deciling=1 

	go

	--select * from #temp2

--*******************************
-- || STEP 11: RISK EXCLUSIONS ||
--*******************************
	Drop table if exists Analytics.dbo.BTRisk25
	SELECT *
	into Analytics.dbo.BTRisk25
	FROM #temp2
	where 1=1
	and N_accts_bankruptcies <= 0  
	AND Times_Transactors < 13
	and Times_1_cycle_delq_pre_6mo <1 --1485
	and Times_2_cycle_delq_pre_12mo <1 -- 193
	and Times_overlimit_pre_6mo <1 --223
	and Times_cash_Advances_pre_6mo <1 --1132
	and avg_Utilization_pre_12mo <= 0.75 --1110
	and Exclu_Utili2 =0 --122
	and FICO_score >= 700 -- Earlier it was 680 but as jim request to keep it to 700 --4131
	and Exc_FicoDropped50Pts=0 --12744
	and Exc_Fico2 = 0 --262
	AND DEBT_BURDEN<100 --669
	and N_Inquiries_in_past_6months < 2 ---6142
	AND Worst_Rating_on_CC_Trades_in_Past_12_Months < 3 --1408
	and AGE >21 -- 202
	and Durable_Key not in (select Durable_Key from #RiskExclude) --859
	and Durable_Key not in (select Durable_Key from #risk_model_Exclusion) --859


--select count(1) from Analytics.dbo.BTRisk25 
--select top 10 * from #N_BTS

--======================= NUMBER OF BTS ============================
--==================================================================

  drop table if exists #N_BTS
  select [RDT_CHD_ACCOUNT_NUMBER],
  count(*) as N_BTS,
	sum(cast(RDT_TRANSACTION_AMOUNT as money)) BT_Amount
  into #N_BTS
  from [TMGData].[dbo].[TMGCompleteCC]  
  where [RDT_TRANSACTION_CODE] in (253,254) 
and RDT_MRCH_SIC_CODE in (3,6) and cast(left(concat(20,[RDT_TRANSACTION_DATE]),6) as int) between 202411 - 99 and 202411
group by [RDT_CHD_ACCOUNT_NUMBER]


--select top 3 * from #risk #probablity
--=====================================
Drop table if exists #probablity 
select a.*
,case when(b.N_BTS is null) then 0 else N_BTS end as N_BTS
,(EXP (-4.32257144279648
        + 0.0000375281298805703 * Bureau_Balance
		+ 0.829366442313848  * (case when(b.N_BTS is null) then 0 else N_BTS end)
		+ 0.0138406409410405 * Debt_Burden
		- 0.71846077334887   * TransactorFlag
		+ 0.23315590235426   * N_BanckcardTradesPast12Mos
		+ 0.093151509799649  * N_Inquiries_in_past_6months
		)
		/
		(1 +
		(EXP (-4.32257144279648
        + 0.0000375281298805703 * Bureau_Balance
		+ 0.829366442313848 * (case when(b.N_BTS is null) then 0 else N_BTS end)
		+ 0.0138406409410405 * Debt_Burden
		- 0.71846077334887 * TransactorFlag
		+ 0.23315590235426 * N_BanckcardTradesPast12Mos
		+ 0.093151509799649 * N_Inquiries_in_past_6months
		))
		)
		) as [Probability Value]
		into #Probablity
from Analytics.dbo.BTRisk25 a -- #risk a
left join #N_BTS b
on a.[Account Number]=b.RDT_CHD_ACCOUNT_NUMBER



	--Drop table if exists #final
	--select 
	--*
	--,NTILE(10) over (order by [Probability Value] desc) as Deciling 
	--into #final
	--from #Probablity

	--select count(1) from #Probablity
	drop table if exists #BT23_FinalList
	select * 
	into #BT23_FinalList
	from #Probablity


	/*** LIVE CHECK SSN***/
	drop table if exists #excludeSSN
	select  DISTINCT aa.SSN 
	into #excludeSSN
	from #BT23_FinalList aa
	left join ARCUSYM000..name bb
	on aa.[Social Security Number] = bb.SSN and bb.ProcessDate = '20241130'   ---CRT added latest process date
	left join ARCUSYM000..loan cc
	on bb.PARENTACCOUNT = cc.PARENTACCOUNT and cc.ProcessDate = '20241130'		---CRT added latest process date
	left join ARCUSYM000.arcu.ARCULoanCategory dd
	on cc.TYPE = dd.LoanType
	where 1 = 1
	and opendate is not null
	and closedate is null 
	and dd.LoanCategory4 = 'Live Check'

	go

	/***EXCLUDE LIVE CHECK SSN ***/ -- 15369
	drop table if exists #final_test --Analytics.dbo.BT25_FinalList
	select *
	into #final_test--Analytics.dbo.BT25_FinalList
	from #BT23_FinalList
	where 1 =1
	AND ssn in  (select ssn  FROM #BUREAUSSN) 
	AND ssn not in (select ssn from #excludeSSN) --212
	AND ssn in (select ssn from Analytics..Member_Level_Risk_Score_v2 where Final_score <= 20) -- 4854
	AND (BANKRUPTCYCOUNT=0 OR BANKRUPTCYCOUNT =-4) -- 4792
	AND (NUMBERINQUIRIESP6MONTHS<=2) -- 4792
	AND (CHARGEOFFTRADECOUNTP12MONTHS<=0  )-- 4791
	AND (Worst_Rating_on_CC_Trades_in_Past_12_Months<=1  ) -- 4683
	and (ForeclosureCountP12Months<=0)-- 4683
	AND (autoWORSTRATINGP12MONTHS<=1 ) -- 4660
	AND (helocWORSTRATINGP12MONTHS<=1 ) -- 4657
	AND (heWORSTRATINGP12MONTHS<=1 )  -- 4657
	and Bureau_Balance >2000-- 2000 and 15000 -- 1682


	Drop table if exists Analytics.dbo.GE_BT25_FinalList
	select 
	*
	,NTILE(10) over (order by [Probability Value] desc) as Deciling 
	into Analytics.dbo.GE_BT25_FinalList
	from #final_test

	alter table Analytics.dbo.GE_BT25_FinalList
	drop column N_accts_bankruptcies,NUMBERINQUIRIESP6MONTHS

,


	select count(*) from Analytics.dbo.BT25_FinalList group by Deciling 


	Select * from Analytics.dbo.BT25_FinalList order by Deciling


----------------------------------------------------- WILL APPLY AT LAST --------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------

--**********************
--|| MEMBER DATA PULL ||
--**********************
--Drop table if exists #Member
--select
--distinct
--SSN
--,first
--,LAST
--,CITY
--,STATE
--,ZIPCODE
--INTO #Member
--from ARCUSYM000.dbo.NAME
--where ProcessDate = '20220431'
--and SSN in (select distinct [Social Security Number] from #temp1)
--and FIRST is not null
--and LAST is not null
--and city is not null
--and STATE is not null
--and ZIPCODE is not null



--*******************
--|| DATA MATCHING ||
--*******************
--Drop table if exists #SemiFinal
--Select 
--distinct
--b.FIRST
--,b.LAST
--, a.Durable_Key as [Reference Number]
--,a.[Social Security Number]
---- Address Number
---- Pre Directinal Number
----[7] Street Name or Full Street Address (Required)
----[8] Post-Directional
----[9] Street Type
--,b.CITY as [City (Required)]
--,b.STATE as [State (Required)]
--,b.ZIPCODE as [Zip Code (Required)]
----[13] Maternal Name (recommended for Puerto Rico)
--,a.[Master Account Key] as [Master Account Key]
--,a.[Account Number] as [Account Number]
--,a.[External Status Code]
--,a.[Internal Status Code]
--,a.[Card Description]
--,a.[Account System Entry Date]
--,a.[Credit Limit]
--,202204 as extract_datepart
--,a.AGE
--,rank() Over(Partition by a.[Social Security Number] order by [Master Account Key]) as rank

--into #SemiFinal
--from #temp1 a left join 
--	(select * from #Member where SSN not in (select distinct ssn from #Member group by ssn  having count(*) >1)) b
--on a.[Social Security Number] = b.SSN
--where first is not null


--------------



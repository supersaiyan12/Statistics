-- 9th Jun'23 Campaign (Test)
/******1.arcusym000.tracking.tvwarcutrackingcreditcard ( to get the paymentof creditcard)  ******/
/******2.SELECT CardNumber_UserChar1 FROM analytics.dbo.ABTesting062023_Text (to get the atual member by each month)  ******/
/******3. Jody Excel for timeslot of each text being made ( thourgh SSIS)  ******/

SELECT MinimumPaymentDue_UserAmount2
	,LastPaymentDate_UserDate2
	,LastPaymentAmount_UserAmount9
FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
WHERE 1=1 
	AND CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM analytics.dbo.ABTesting062023_Text)
	AND ProcessDate = 20230612
	AND LastPaymentDate_UserDate2 IN ('2023-06-08 00:00:00')
										--('2023-06-09 00:00:00','2023-06-10 00:00:00','2023-06-11 00:00:00')
										--('2023-05-09 00:00:00','2023-05-10 00:00:00','2023-05-11 00:00:00')
										--('2023-04-09 00:00:00','2023-04-10 00:00:00','2023-04-11 00:00:00')
SELECT MinimumPaymentDue_UserAmount2
	,LastPaymentDate_UserDate2
	,LastPaymentAmount_UserAmount9
	,CASE WHEN LastPaymentAmount_UserAmount9 = MinimumPaymentDue_UserAmount2 THEN 1 ELSE 0 END AS Min_Pymnt_Flag
FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
WHERE 1=1 
	AND CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM analytics.dbo.ABTesting062023_Text)
	AND ProcessDate = 20230614
	AND LastPaymentDate_UserDate2 BETWEEN '2023-06-05 00:00:00' AND '2023-06-13 00:00:00'
	--AND LastPaymentDate_UserDate2 IN ('2023-06-08 00:00:00')--('2023-06-09 00:00:00','2023-06-10 00:00:00','2023-06-11 00:00:00')
										--('2023-05-09 00:00:00','2023-05-10 00:00:00','2023-05-11 00:00:00')
										--('2023-04-09 00:00:00','2023-04-10 00:00:00','2023-04-11 00:00:00')


SELECT DISTINCT CardNumber_UserChar1, AgeBand
FROM analytics.dbo.ABTesting062023_Text
WHERE CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
									WHERE ProcessDate = 20230612
										AND LastPaymentDate_UserDate2 IN ('2023-06-09 00:00:00','2023-06-10 00:00:00','2023-06-11 00:00:00'))
	OR CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
									WHERE ProcessDate = 20230512
										AND LastPaymentDate_UserDate2 IN ('2023-05-09 00:00:00','2023-05-10 00:00:00','2023-05-11 00:00:00'))
	OR CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
									WHERE ProcessDate = 20230412
										AND LastPaymentDate_UserDate2 IN ('2023-04-09 00:00:00','2023-04-10 00:00:00','2023-04-11 00:00:00'))


DROP TABLE IF EXISTS #JunTestAgeBands
SELECT *
INTO #JunTestAgeBands
FROM analytics.dbo.ABTesting062023_Text
WHERE CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
									WHERE ProcessDate = 20230614
										AND LastPaymentDate_UserDate2 IN ('2023-06-09 00:00:00','2023-06-10 00:00:00','2023-06-11 00:00:00'
																			,'2023-06-12 00:00:00','2023-06-13 00:00:00'))


SELECT A.MinimumPaymentDue_UserAmount2
	,A.LastPaymentDate_UserDate2
	,LastPaymentAmount_UserAmount9
	,AgeBand
FROM arcusym000.tracking.tvwarcutrackingcreditcard A
LEFT JOIN #JunTestAgeBands B
	ON A.CardNumber_UserChar1 = B.CardNumber_UserChar1
WHERE 1=1 
	AND A.CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM #JunTestAgeBands)
	--AND A.CardNumber_UserChar1 NOT IN (SELECT CardNumber_UserChar1 FROM analytics.dbo.ABTesting012023_Text)
	AND ProcessDate = 20230614
	AND A.LastPaymentDate_UserDate2 BETWEEN '2023-06-09 00:00:00' AND '2023-06-13 00:00:00'


----**------********

DROP TABLE IF EXISTS #OctTestAgeBands
SELECT *
INTO #OctTestAgeBands
FROM analytics.dbo.ABTesting10122022_Text
WHERE CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
									WHERE ProcessDate = 20221031
										AND LastPaymentDate_UserDate2 BETWEEN '2022-09-15 00:00:00' AND '2022-10-13 00:00:00')

SELECT 'Oct' AS Month
	,A.MinimumPaymentDue_UserAmount2
	,A.LastPaymentDate_UserDate2
	,LastPaymentAmount_UserAmount9
	,AgeBand
FROM arcusym000.tracking.tvwarcutrackingcreditcard A
LEFT JOIN #OctTestAgeBands B
	ON A.CardNumber_UserChar1 = B.CardNumber_UserChar1
WHERE 1=1 
	AND A.CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM #OctTestAgeBands)
	AND ProcessDate = 20221031
	AND A.LastPaymentDate_UserDate2 BETWEEN '2022-09-15 00:00:00' AND '2022-10-13 00:00:00'

------**------********
--select top 10 * from Analytics..ABTestingTimeTracking 
SELECT B.*
	,LastPaymentAmount_UserAmount9
	,A.LastPaymentDate_UserDate2 AS PaymentDate_Current
FROM arcusym000.tracking.tvwarcutrackingcreditcard A
LEFT JOIN Analytics..ABTestingTimeTracking B
	ON A.CardNumber_UserChar1 = B.CardNumber_UserChar1
WHERE ProcessDate = 20221231
	AND A.LastPaymentDate_UserDate2 = '2022-12-12 00:00:00'
	AND Month = 'Dec Group 5'

select Month
	,count(*)
from Analytics..ABTestingTimeTracking
group by month
order by 1


SELECT B.*
	,LastPaymentAmount_UserAmount9
	,A.LastPaymentDate_UserDate2 AS PaymentDate_Current
	,CASE WHEN A.MinimumPaymentDue_UserAmount2 = A.LastPaymentAmount_UserAmount9 THEN 1 ELSE 0 END AS MIN_PYMNT
	,CASE WHEN A.StatementBalance_UserAmount12 = A.LastPaymentAmount_UserAmount9 THEN 1 ELSE 0 END AS FULL_PYMNT
	,CASE WHEN A.LastPaymentAmount_UserAmount9 = (0.7*A.StatementBalance_UserAmount12) THEN 1 ELSE 0 END AS MIN_PYMNT
FROM arcusym000.tracking.tvwarcutrackingcreditcard A
LEFT JOIN Analytics..ABTestingTimeTracking B
	ON A.CardNumber_UserChar1 = B.CardNumber_UserChar1
WHERE ProcessDate = 20230611
	AND A.LastPaymentDate_UserDate2 = '2023-06-09 00:00:00'
	AND Month LIKE 'June%'







----**------********


DROP TABLE IF EXISTS #MayTestAgeBands
SELECT *
INTO #MayTestAgeBands
FROM analytics.dbo.ABTesting052023_Text
WHERE CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
									WHERE ProcessDate = 20230515
										AND LastPaymentDate_UserDate2 BETWEEN '2023-05-10 00:00:00' AND '2023-05-14 00:00:00')

SELECT A.MinimumPaymentDue_UserAmount2
	,A.LastPaymentDate_UserDate2
	,LastPaymentAmount_UserAmount9
	,AgeBand
FROM arcusym000.tracking.tvwarcutrackingcreditcard A
LEFT JOIN #MayTestAgeBands B
	ON A.CardNumber_UserChar1 = B.CardNumber_UserChar1
WHERE 1=1 
	AND A.CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM #MayTestAgeBands)
	AND A.CardNumber_UserChar1 NOT IN (SELECT CardNumber_UserChar1 FROM analytics.dbo.ABTesting012023_Text)
	AND ProcessDate = 20230131
	AND A.LastPaymentDate_UserDate2 BETWEEN '2023-01-10 00:00:00' AND '2023-01-14 00:00:00'


-- 9th Jun'23 Control
SELECT MinimumPaymentDue_UserAmount2
	,LastPaymentDate_UserDate2
	,LastPaymentAmount_UserAmount9
FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
WHERE 1=1 
	AND CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM analytics.dbo.ABTesting062023_NoText)
	AND ProcessDate = 20230612
	AND LastPaymentDate_UserDate2 IN ('2023-06-08 00:00:00')--('2023-06-09 00:00:00','2023-06-10 00:00:00','2023-06-11 00:00:00')
										--('2023-05-09 00:00:00','2023-05-10 00:00:00','2023-05-11 00:00:00')
										--('2023-04-09 00:00:00','2023-04-10 00:00:00','2023-04-11 00:00:00')

-----------------------------------------------------------------------------------------------------------------------------------
-- 10th May'23 Campaign (Test)
SELECT MinimumPaymentDue_UserAmount2
	,LastPaymentDate_UserDate2
	,LastPaymentAmount_UserAmount9
FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
WHERE 1=1 
	AND CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM analytics.dbo.ABTesting052023_Text)
	AND ProcessDate = 20230513
	AND LastPaymentDate_UserDate2 IN ('2023-05-09 00:00:00') --('2023-05-10 00:00:00','2023-05-11 00:00:00','2023-05-12 00:00:00')
										--('2023-04-10 00:00:00','2023-04-11 00:00:00','2023-04-12 00:00:00')
										--('2023-03-10 00:00:00','2023-03-11 00:00:00','2023-03-12 00:00:00')

SELECT DISTINCT CardNumber_UserChar1, AgeBand
FROM analytics.dbo.ABTesting052023_Text
WHERE CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
									WHERE ProcessDate = 20230513
										AND LastPaymentDate_UserDate2 IN ('2023-05-10 00:00:00','2023-05-11 00:00:00','2023-05-12 00:00:00'))
	OR CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
									WHERE ProcessDate = 20230413
										AND LastPaymentDate_UserDate2 IN ('2023-04-10 00:00:00','2023-04-11 00:00:00','2023-04-12 00:00:00'))
	OR CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
									WHERE ProcessDate = 20230331
										AND LastPaymentDate_UserDate2 IN ('2023-03-10 00:00:00','2023-03-11 00:00:00','2023-03-12 00:00:00'))


-- 10th May'23 Control
SELECT MinimumPaymentDue_UserAmount2
	,LastPaymentDate_UserDate2
	,LastPaymentAmount_UserAmount9
FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
WHERE 1=1 
	AND CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM analytics.dbo.ABTesting052023_NoText)
	AND ProcessDate = 20230513
	AND LastPaymentDate_UserDate2 IN ('2023-05-09 00:00:00')--('2023-05-10 00:00:00','2023-05-11 00:00:00','2023-05-12 00:00:00')
										--('2023-04-10 00:00:00','2023-04-11 00:00:00','2023-04-12 00:00:00')
										--('2023-03-10 00:00:00','2023-03-11 00:00:00','2023-03-12 00:00:00')

-----------------------------------------------------------------------------------------------------------------------------------
-- Common members on every test list

DROP TABLE IF EXISTS #CommonMembers
SELECT DISTINCT CardNumber_UserChar1
INTO #CommonMembers
FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
WHERE 1=1 
	AND CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM analytics.dbo.ABTesting062023_Text)
	AND CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM analytics.dbo.ABTesting052023_Text)
	AND CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM analytics.dbo.ABTesting042023_Text)


SELECT MinimumPaymentDue_UserAmount2
	,LastPaymentDate_UserDate2
	,LastPaymentAmount_UserAmount9
FROM arcusym000.tracking.tvwarcutrackingcreditcard nolock
WHERE 1=1 
	AND CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM #CommonMembers)
	--AND CardNumber_UserChar1 IN (SELECT CardNumber_UserChar1 FROM analytics.dbo.ABTesting032023_Text)
	AND ProcessDate = 20230414
	AND LastPaymentDate_UserDate2 BETWEEN '2023-03-15 00:00:00' AND '2023-04-13 00:00:00'
	--AND LastPaymentDate_UserDate2 IN ('2023-06-08 00:00:00')--('2023-06-09 00:00:00','2023-06-10 00:00:00','2023-06-11 00:00:00')
										--('2023-05-09 00:00:00','2023-05-10 00:00:00','2023-05-11 00:00:00')
										--('2023-04-09 00:00:00','2023-04-10 00:00:00','2023-04-11 00:00:00')



-----------------------------------------------------------------------------------------------------------------------------------

Drop table if exists #ABTesting122022_Text_Tracking
select MinimumPaymentDue_UserAmount2, LastPaymentDate_UserDate2, LastPaymentAmount_UserAmount9
into #ABTesting122022_Text_Tracking
from arcusym000.tracking.tvwarcutrackingcreditcard
where CardNumber_UserChar1 in (select CardNumber_UserChar1 from analytics.dbo.ABTesting122022_Text)
and ProcessDate=20221212
and LastPaymentDate_UserDate2='2022-12-12 00:00:00'


Drop table if exists analytics.dbo.ABTesting122022_NoText_Tracking
select MinimumPaymentDue_UserAmount2, LastPaymentDate_UserDate2, LastPaymentAmount_UserAmount9
into analytics.dbo.ABTesting122022_NoText_Tracking
from arcusym000.tracking.tvwarcutrackingcreditcard
where CardNumber_UserChar1 in (select CardNumber_UserChar1 from analytics.dbo.ABTesting122022_NoText)
and ProcessDate=20221212
and LastPaymentDate_UserDate2='2022-12-12 00:00:00'


-----------------------------------------------------------------------------------------------------------------------------------

select MinimumPaymentDue_UserAmount2, LastPaymentDate_UserDate2, LastPaymentAmount_UserAmount9
from arcusym000.tracking.tvwarcutrackingcreditcard
where CardNumber_UserChar1 in (select CardNumber_UserChar1 from analytics.dbo.ABTesting11102022_Text)
--and ProcessDate=20221110
and LastPaymentDate_UserDate2>'2022-11-10 00:00:00'

select MinimumPaymentDue_UserAmount2, LastPaymentDate_UserDate2, LastPaymentAmount_UserAmount9
from arcusym000.tracking.tvwarcutrackingcreditcard
where CardNumber_UserChar1 in (select CardNumber_UserChar1 from analytics.dbo.ABTesting11102022_NoText)
and ProcessDate=20221110


select max(LastPaymentDate_UserDate2) from arcusym000.tracking.tvwarcutrackingcreditcard
where ProcessDate=20221212

select RDT_TRANSACTION_AMOUNT, [RDT_TRANSACTION_DATE],RDT_CHD_ACCOUNT_NUMBER from tmgdata.dbo.TMGCompleteCC
where [RDT_TRANSACTION_CODE]=271
and RDT_CHD_ACCOUNT_NUMBER in (select CardNumber_UserChar1 from analytics.dbo.ABTesting11102022_Text)
and ( [RDT_TRANSACTION_DATE] >= '221010' and [RDT_TRANSACTION_DATE] <= '221012' )


----------------------------------------AGE Bandwise----------------------------------------------------------


select RDT_TRANSACTION_AMOUNT, [RDT_TRANSACTION_DATE],RDT_CHD_ACCOUNT_NUMBER,b.AgeBand from tmgdata.dbo.TMGCompleteCC a

left join  analytics.dbo.ABTesting11102022_Text b
on a.RDT_CHD_ACCOUNT_NUMBER=b.CardNumber_UserChar1
where [RDT_TRANSACTION_CODE]=271
and RDT_CHD_ACCOUNT_NUMBER in (select CardNumber_UserChar1 from analytics.dbo.ABTesting11102022_Text)
and (( [RDT_TRANSACTION_DATE] >= '221010' and [RDT_TRANSACTION_DATE] <= '221012' )
or ( [RDT_TRANSACTION_DATE] >= '220910' and [RDT_TRANSACTION_DATE] <= '220912' )
or ( [RDT_TRANSACTION_DATE] >= '221110' and [RDT_TRANSACTION_DATE] <= '221112' )
)


select RDT_TRANSACTION_AMOUNT, [RDT_TRANSACTION_DATE],RDT_CHD_ACCOUNT_NUMBER,b.AgeBand  from tmgdata.dbo.TMGCompleteCC a
left join  analytics.dbo.ABTesting122022_Text b
on a.RDT_CHD_ACCOUNT_NUMBER=b.CardNumber_UserChar1
where [RDT_TRANSACTION_CODE]=271
and RDT_CHD_ACCOUNT_NUMBER in (select CardNumber_UserChar1 from analytics.dbo.ABTesting122022_Text)
and (( [RDT_TRANSACTION_DATE] >= '221010' and [RDT_TRANSACTION_DATE] <= '221012' )
or ( [RDT_TRANSACTION_DATE] >= '220910' and [RDT_TRANSACTION_DATE] <= '220912' )
or ( [RDT_TRANSACTION_DATE] >= '221110' and [RDT_TRANSACTION_DATE] <= '221112' )
or ( [RDT_TRANSACTION_DATE] >= '221210' and [RDT_TRANSACTION_DATE] <= '221212' )
)





--------------No Text-----


select RDT_TRANSACTION_AMOUNT, [RDT_TRANSACTION_DATE],RDT_CHD_ACCOUNT_NUMBER from tmgdata.dbo.TMGCompleteCC
where [RDT_TRANSACTION_CODE]=271
and RDT_CHD_ACCOUNT_NUMBER in (select CardNumber_UserChar1 from analytics.dbo.ABTesting11102022_NoText)
and (( [RDT_TRANSACTION_DATE] >= '221010' and [RDT_TRANSACTION_DATE] <= '221012' )
or ( [RDT_TRANSACTION_DATE] >= '220910' and [RDT_TRANSACTION_DATE] <= '220912' )
or ( [RDT_TRANSACTION_DATE] >= '221110' and [RDT_TRANSACTION_DATE] <= '221112' )
)


select RDT_TRANSACTION_AMOUNT, [RDT_TRANSACTION_DATE],RDT_CHD_ACCOUNT_NUMBER from tmgdata.dbo.TMGCompleteCC
where [RDT_TRANSACTION_CODE]=271
and RDT_CHD_ACCOUNT_NUMBER in (select CardNumber_UserChar1 from analytics.dbo.ABTesting122022_NoText)
and (( [RDT_TRANSACTION_DATE] >= '221010' and [RDT_TRANSACTION_DATE] <= '221012' )
or ( [RDT_TRANSACTION_DATE] >= '220910' and [RDT_TRANSACTION_DATE] <= '220912' )
or ( [RDT_TRANSACTION_DATE] >= '221110' and [RDT_TRANSACTION_DATE] <= '221112' )
or ( [RDT_TRANSACTION_DATE] >= '221210' and [RDT_TRANSACTION_DATE] <= '221212' )
)






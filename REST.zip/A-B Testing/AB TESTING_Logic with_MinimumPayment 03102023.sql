
----Exclusions ---------------

	drop table if exists #ExclusionCards
	select distinct CardNumber_UserChar1 into #ExclusionCards from arcusym000.tracking.tvwARCUTRACKINGCreditCard 
WHERE  1=1
AND  ExternalStatus_UserChar8 in ('CHARGEOFF','BANKRUPT','CLOSED','FRAUD','C','F') --risky cards from history removed

	drop table if exists #listdata
select CardDescription_UserChar4, cc.PARENTACCOUNT,ExternalStatus_UserChar8,InternalStatus_UserChar9,
getdate() BatchExtractionDateTime,
     cc.CardNumber_UserChar1
    , cc.MinimumPaymentDue_UserAmount2
	,cc.CurrentBalance_UserAmount1
    ,PurchaseAmountMTD_UserAmount15
	,PurchaseAmountYTD_UserAmount16
	,FeesYTD_UserAmount5
	, cc.DelinquentAmount_UserAmount7
    , cc.LastPaymentAmount_UserAmount9
    , cc.StatementBalance_UserAmount12
    , cc.DaysDelinquent_UserNumber1
	,cc.ProcessDate
	, cc.LastPaymentDate_UserDate2,MonthBeginDate,
	DATEADD(DAY,DAY(6),dd.MonthBeginDate) [Due Date]  
	, CASE WHEN cc.LastPaymentDate_UserDate2 < DATEADD(DAY,DAY(6),dd.MonthBeginDate)
	 AND cc.MinimumPaymentDue_UserAmount2>5
  THEN DATEDIFF(Month,LastPaymentDate_UserDate2,
 concat(left(processdate,4),'-',right(left(processdate,6),2),'-', right(processdate,2))
 ) ELSE NULL ENd DQMonth,
  CASE WHEN cc.LastPaymentDate_UserDate2 < DATEADD(DAY,DAY(6),dd.MonthBeginDate) 
  AND cc.MinimumPaymentDue_UserAmount2  > 5
   THEN DATEDIFF(DAY,DATEADD(DAY,DAY(6),dd.MonthBeginDate),dd.FullDate) ELSE NULL
   END AS DaysDQ_New
	, datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Process_Date
   into #listdata               
FROM        arcusym000.tracking.tvwARCUTRACKINGCreditCard cc
 INNER JOIN arcusym000.dbo.dimDate dd ON cc.ProcessDate = dd.DateKey
WHERE  1=1
AND ( ExternalStatus_UserChar8 not in ('CHARGEOFF','BANKRUPT','CLOSED','FRAUD','C','F') --current risky removed
or ExternalStatus_UserChar8 is NULL)
And (InternalStatus_UserChar9 is null or InternalStatus_UserChar9 in ('OVERLIMIT'))
 AND ProcessDate in (select max(processdate) from arcusym000.tracking.tvwARCUTRACKINGCreditCard)  --change this to the latest month date of campaign 
    AND cc.ExpirationDate_UserDate3 IS NOT NULL
	And StatementBalance_UserAmount12>0
	And CardDescription_UserChar4 in ('STUDENT MC' ,'BLACK & GOLD MC' ,'MASTERCARD PLATINUM', 'WORLD MC','PLATINUM REWARDS MC')
    AND  CardNumber_UserChar1 in 
        (
          select distinct CardNumber_UserChar1  from arcusym000.tracking.tvwARCUTRACKINGCreditCard
where 1=1
--( AutomaticPaymentFlag_UserChar6 IS NULL -- Do Not Charge Auto Pay
--           or  AutomaticPaymentFlag_UserChar6 = '0' )
		   and ProcessDate in (select max(ProcessDate) from arcusym000.tracking.tvwARCUTRACKINGCreditCard)

		  
		   and (   AutomaticPaymentFlag_UserChar6  is null  -- Do Not Charge Auto Pay
           or AutomaticPaymentFlag_UserChar6 in ( '0' ))

        ) -- No Autopay
			 
			 AND cc.MinimumPaymentDue_UserAmount2 >0 
			 And CardNumber_UserChar1 in
			 (select [Account Number] from TMGData.dbo.cardholder 
where 1=1
and  Active_Flag=1 and [External Status Code] not in ('C','Z')
 and extract_datepart= ( select max(extract_datepart) from TMGData.dbo.cardholder where Active_Flag=1 )

)
and CardNumber_UserChar1 not in ( select CardNumber_UserChar1 from #ExclusionCards
 )

--removing accounts which are not in scope of current objective of "delinquency should be less than 30 days"

drop table if exists #temp1
select * into #temp1 from #listdata
where DQMonth<=1 
and DaysDelinquent_UserNumber1<15 
AND LastPaymentDate_UserDate2>=DateADD(Month,-1, [DUE DATE])
  order by LastPaymentDate_UserDate2


--Account Identifier logic

drop table if exists #TemenosIdentifier
SELECT DISTINCT
    
       l.PARENTACCOUNT,
    CAST(CONVERT(INT, l.PARENTACCOUNT) AS NVARCHAR) + 'T' + RIGHT('0000' + CAST(t.LOCATOR AS VARCHAR), 4) AS TemenosIdentifier
	,NUMBER
	into #TemenosIdentifier
FROM
    ARCUSYM000.dbo.LOOKUP        AS l
    JOIN ARCUSYM000.dbo.TRACKING AS t WITH(NOLOCK)
           ON t.PARENTACCOUNT = l.PARENTACCOUNT
           AND t.ProcessDate = l.ProcessDate
           AND t.USERCHAR1 = l.NUMBER
    LEFT JOIN
        (
            SELECT
                n.PARENTACCOUNT
                , n.SSN
                , n.FIRST
                , n.LAST
                , n.HOMEPHONE
                , n.MOBILEPHONE
                , n.WORKPHONE
                , n.STREET
                , n.EXTRAADDRESS
                , n.CITY
                , n.STATE
                , n.ZIPCODE
                , n.EMAIL
            FROM
                ARCUSYM000.dbo.NAME AS n
            WHERE
                n.EXPIRATIONDATE IS NULL
                AND n.TYPE = 0
                AND n.ProcessDate = (SELECT MAX(ProcessDate)FROM arcusym000.dbo.irs)
            UNION
            SELECT
                n.PARENTACCOUNT
                , n.SSN
                , n.FIRST
                , n.LAST
                , n.HOMEPHONE
                , n.MOBILEPHONE
                , n.WORKPHONE
                , n.STREET
                , n.EXTRAADDRESS
                , n.CITY
                , n.STATE
                , n.ZIPCODE
                , n.EMAIL
            FROM
                ARCUSYM000.dbo.SAVINGS          AS s
                JOIN ARCUSYM000.dbo.SAVINGSNAME AS n
                    ON n.PARENTACCOUNT = s.PARENTACCOUNT
                       AND n.ProcessDate = s.ProcessDate
                       AND n.EXPIRATIONDATE IS NULL
                       AND n.TYPE = 1
            WHERE
                s.SHARECODE = 0
                AND s.MINIMUMBALANCE = 5
                AND s.ProcessDate = (SELECT MAX(ProcessDate)FROM arcusym000.dbo.irs)
                AND s.CLOSEDATE IS NULL
            UNION
            SELECT
                n.PARENTACCOUNT
                , n.SSN
                , n.FIRST
                , n.LAST
                , n.HOMEPHONE
                , n.MOBILEPHONE
                , n.WORKPHONE
                , n.STREET
                , n.EXTRAADDRESS
                , n.CITY
                , n.STATE
                , n.ZIPCODE
                , n.EMAIL
            FROM
                ARCUSYM000.dbo.LOAN          AS s
                JOIN ARCUSYM000.dbo.LOANNAME AS n
                    ON n.PARENTACCOUNT = s.PARENTACCOUNT
                       AND n.ProcessDate = s.ProcessDate
                      AND n.EXPIRATIONDATE IS NULL
                       AND n.TYPE = 1
            WHERE
                s.ProcessDate = (SELECT MAX(ProcessDate)FROM arcusym000.dbo.irs)
                AND s.CLOSEDATE IS NULL
        )         AS n
        ON n.PARENTACCOUNT = l.PARENTACCOUNT
WHERE
    l.ProcessDate = (SELECT MAX(ProcessDate)FROM arcusym000.dbo.irs)

		
		--General Membership Accounts for removing business accounts

		drop table if exists #generalmembership
	select distinct  AccountNumber 
	into #generalmembership from ARCUSYM000.arcu.ARCUShareDetailed 
	where  AccountTypeDescription = 'GENERAL MEMBERSHIP'
	and  ProcessDate = (select max(processdate) from ARCUSYM000.arcu.ARCUShareDetailed ) ---removing business accounts
	and AccountStatus='Open'

--Joining the Temenos Identifier to original table

drop table if exists #Final_Master
	select a.*,b.TemenosIdentifier,concat(a.CardNumber_UserChar1,b.TemenosIdentifier) UNID
	into #Final_Master from #temp1 a 
	left join #TemenosIdentifier b
	on a.PARENTACCOUNT=b.PARENTACCOUNT
	and a.CardNumber_UserChar1=b.NUMBER
	and a.parentaccount in ( select AccountNumber from #generalmembership)
	and TemenosIdentifier is not null


	---Removing Warnings-- (Reference to Ryan's Code)
	
DECLARE @maxProcessDate INT = (select max(processdate) from arcusym000.dbo.irs)
DECLARE @maxFullDate DATE = (SELECT max(FullDate) FROM arcusym000.dbo.dimDate WHERE datekey = @maxProcessDate)

DROP TABLE IF EXISTS #warnings
DROP TABLE IF EXISTS #warningsUnpacked
DROP TABLE IF EXISTS #warningExpUnpacked
DROP TABLE IF EXISTS #ActiveWarnings
DROP TABLE IF EXISTS #NAMES
DROP TABLE IF EXISTS #SavvyNames
DROP TABLE IF EXISTS UICCU.stg.TransUnionMonthly

--load raw data into temp table
SELECT a.WarningCode1
, a.WarningCode2
, a.WarningCode3
, a.WarningCode4
, a.WarningCode5
, a.WarningCode6
, a.WarningCode7
, a.WarningCode8
, a.WarningCode9
, a.WarningCode10
, a.WarningCode11
, a.WarningCode12
, a.WarningCode13
, a.WarningCode14
, a.WarningCode15
, a.WarningCode16
, a.WarningCode17
, a.WarningCode18
, a.WarningCode19
, a.WarningCode20
, a.WarningExpiration1
, a.WarningExpiration2
, a.WarningExpiration3
, a.WarningExpiration4
, a.WarningExpiration5
, a.WarningExpiration6
, a.WarningExpiration7
, a.WarningExpiration8
, a.WarningExpiration9
, a.WarningExpiration10
, a.WarningExpiration11
, a.WarningExpiration12
, a.WarningExpiration13
, a.WarningExpiration14
, a.WarningExpiration15
, a.WarningExpiration16
, a.WarningExpiration17
, a.WarningExpiration18
, a.WarningExpiration19
, a.WarningExpiration20
, ACCOUNTNUMBER
INTO #warnings
FROM arcusym000.dbo.account a
WHERE a.ProcessDate = @maxProcessDate
--unpivot codes by slot
SELECT unpvt.ACCOUNTNUMBER
, unpvt.Slot
, unpvt.Code
INTO #warningsUnpacked
FROM #warnings w
UNPIVOT(code FOR slot IN (
WarningCode1
, WarningCode2
, WarningCode3
, WarningCode4
, WarningCode5
, WarningCode6
, WarningCode7
, WarningCode8
, WarningCode9
, WarningCode10
, WarningCode11
, WarningCode12
, WarningCode13
, WarningCode14
, WarningCode15
, WarningCode16
, WarningCode17
, WarningCode18
, WarningCode19
, WarningCode20
)) AS unpvt
WHERE unpvt.code > 0



--unpivot expirations by slot
SELECT unpvt.ACCOUNTNUMBER
, '' LoanID
, unpvt.Slot
, unpvt.expiration
INTO #warningExpUnpacked
FROM #warnings w
UNPIVOT(expiration FOR slot IN (
Warningexpiration1
, Warningexpiration2
, Warningexpiration3
, Warningexpiration4
, Warningexpiration5
, Warningexpiration6
, Warningexpiration7
, Warningexpiration8
, Warningexpiration9
, Warningexpiration10
, Warningexpiration11
, Warningexpiration12
, Warningexpiration13
, Warningexpiration14
, Warningexpiration15
, Warningexpiration16
, Warningexpiration17
, Warningexpiration18
, Warningexpiration19
, Warningexpiration20
)) AS unpvt
WHERE unpvt.expiration <= @maxFullDate


SELECT AccountNumber
, Code
INTO #ActiveWarnings
FROM #warningsUnpacked w
WHERE NOT EXISTS (
SELECT AccountNumber
FROM #warningExpUnpacked we
WHERE we.AccountNumber = w.ACCOUNTNUMBER
AND SUBSTRING(we.Slot, 18, 100) = SUBSTRING(w.Slot, 12, 100)
)


DECLARE @ProcessDate int = (select max(processdate) from ARCUSYM000.dbo.irs)

drop table if exists #List
SELECT N.FIRST
      ,N.LAST
	  ,N.BIRTHDATE,
	  FLOOR(DATEDIFF(DAY, N.BIRTHDATE , GETDATE()) / 365.25) Age
	  ,N.SSN
	  ,N.STREET
	  ,N.CITY
	  ,N.STATE
	  ,N.ZIPCODE
	  ,N.MOBILEPHONE
	   ,T.*
	    into #List
FROM #Final_Master T
JOIN ARCUSYM000.DBO.NAME N ON N.PARENTACCOUNT=T.PARENTACCOUNT
                          AND N.ProcessDate=@ProcessDate
						  AND N.TYPE=0
						  AND N.SSNTYPE=0
	                      AND N.NAMEFORMAT=0
						  AND N.FIRST IS NOT NULL
						  AND N.LAST IS NOT NULL
						  AND N.DEATHDATE IS NULL
						  --AND FLOOR(DATEDIFF(DAY, N.BIRTHDATE , GETDATE()) / 365.25)>=21
						  AND N.ADDRESSTYPE=0
						  AND N.STREET IS NOT NULL
						  AND N.CITY IS NOT NULL
						  AND N.STATE IS NOT NULL
						  AND N.ZIPCODE IS NOT NULL
						  ANd MOBILEPHONE is not Null
LEFT JOIN #ActiveWarnings W on W.AccountNumber=T.ParentAccount
                           and W.Code=72

  AND W.ACCOUNTNUMBER IS NULL



  --Online Bankinf Flag--

 drop table if exists  #LOGININFO
 select max(last_logon) logintime, user_logon_id,a.user_id, right( '00000000000'+ isnull(b.primary_cif,''),10) AccountNumber
  into #LOGININFO
  from Q2EVE.dbo.UserLogon a
  left join Q2EVE.dbo.UserDataPII b
  on a.user_id=b.user_id
    where last_logon is not null and last_logon>'2022-07-01 00:00:00.000'--06?
  group by a.user_id,right( '00000000000'+ isnull(b.primary_cif,''),10),user_logon_id
  order by user_id

  drop table if exists #OnlineBankingFlag
  select AccountNumber ParentAccount,1 OnlineBanking
  Into #OnlineBankingFlag 
  from #LOGININFO
   where AccountNumber<>'0000000000' order by AccountNumber


   --online banking Flag Adding to the list--

   drop table if exists #Final_OnlineBankinfFlag_Added
   select distinct a.*, case when b.OnlineBanking=1 then 1 else 0 end OnlineBanking_Flag
    into #Final_OnlineBankinfFlag_Added from  #List a
   left join #OnlineBankingFlag b
   on a.PARENTACCOUNT=b.ParentAccount
  where  TemenosIdentifier is not null


 -- FINAL List of two segments of 1000 members

 drop table if exists #RowNo
  select *,CASE  WHEN Age > 77 THEN 'Silent (till 1945)'
	WHEN Age BETWEEN 59 AND 77 THEN 'Baby Boomers (1946-1964)'
	WHEN Age BETWEEN 42 AND 58 THEN 'Gen X (1965-1980)'
	WHEN Age BETWEEN 26 AND 41 THEN 'Gen Y (1981-1996)'
	WHEN Age < 26 THEN 'Gen Z (1997 and above)'
								ELSE 'NA'
							END AgeBand,
							
	right (CardNumber_UserChar1,4) Last4DigitofCardNumber,
	row_number() over (order by MinimumPaymentDue_UserAmount2 desc,StatementBalance_UserAmount12 desc) as RowNo
	 into #RowNo from #Final_OnlineBankinfFlag_Added
	
	 
	 --segment splitting-- 
drop table if exists #FINAL_LIST_ABTESTING
  select *,case when  RowNo%2=0 then 'TextNotification' else 'NoCommunication' end Segment 
  into #FINAL_LIST_ABTESTING
   from #RowNo
   where RowNo between 0 and 2000 


   ----FINAL WORKING LIST--
   drop taBLE IF EXISTS #FINALWORKINGLIST_TEXT_NOTIFICATION
   select FIRST,LAST,AGE,MOBILEPHONE, SSN ,CardNumber_UserChar1, Last4DigitofCardNumber, Segment,PARENTACCOUNT,AgeBand
   ,BatchExtractionDateTime,TemenosIdentifier AccountIdentifier, ExternalStatus_UserChar8, MinimumPaymentDue_UserAmount2,
   StatementBalance_UserAmount12,LastPaymentDate_UserDate2, OnlineBanking_Flag,DaysDQ_New
   into #FINALWORKINGLIST_TEXT_NOTIFICATION from #FINAL_LIST_ABTESTING where Segment='TextNotification'
  and CardNumber_UserChar1 not in (
select  CardNumber_UserChar1  
from #FINAL_LIST_ABTESTING
group by CardNumber_UserChar1
having count(CardNumber_UserChar1) >1)

--drop table if exists Analytics.dbo.ABTesting032023_Text
--select * into Analytics.dbo.ABTesting032023_Text from #FINALWORKINGLIST_TEXT_NOTIFICATION

---Tracking Control List--

 drop taBLE IF EXISTS #FINALWORKINGLIST_CONTROLGroup

   select FIRST,LAST,AGE,MOBILEPHONE, SSN ,CardNumber_UserChar1, Last4DigitofCardNumber, Segment,PARENTACCOUNT,AgeBand
   ,BatchExtractionDateTime,TemenosIdentifier AccountIdentifier, ExternalStatus_UserChar8, MinimumPaymentDue_UserAmount2,
   StatementBalance_UserAmount12,LastPaymentDate_UserDate2,OnlineBanking_Flag,DaysDQ_New
   into #FINALWORKINGLIST_CONTROLGroup from #FINAL_LIST_ABTESTING 
	where Segment='NoCommunication'
  and CardNumber_UserChar1 not in (
select  CardNumber_UserChar1  
from #FINAL_LIST_ABTESTING
group by CardNumber_UserChar1
having count(CardNumber_UserChar1) >1)


--drop table if exists Analytics.dbo.ABTesting032023_NoText
--select * into  Analytics.dbo.ABTesting032023_NoText
--from #FINALWORKINGLIST_CONTROLGroup 

--List in Excel --

--select * from #warningExpUnpacked
--select * from #FINALWORKINGLIST_TEXT_NOTIFICATION
--select * from #FINALWORKINGLIST_CONTROLGroup


--select * from  Analytics.dbo.ABTesting032023_Text
--select * from  Analytics.dbo.ABTesting032023_NoText

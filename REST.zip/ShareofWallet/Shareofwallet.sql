drop table if exists #temp
select distinct PARENTACCOUNT into #temp from ARCUSYM000.dbo.SAVINGS
where ProcessDate = '20220831' and OPENDATE is not null 
and CLOSEDATE is null 
and CHARGEOFFDATE is null


drop table if exists #temp1
select distinct PARENTACCOUNT into #temp1 from  ARCUSYM000.dbo.LOAN
 where ProcessDate = '20220831'
 and OPENDATE is not null 
 and CLOSEDATE is null 
 and CHARGEOFFDATE is null


 
drop table if exists #TPa
 select distinct PARENTACCOUNT
 into #TPa
 from
 (
 select * from #temp
 union all
 select * from #temp1
 )a
 
 --auto loan 

 drop table if exists #temp3
select distinct a.PARENTACCOUNT,a.BALANCE,a.OPENDATE
--1 as Grenstate_Auto_Loan
--,datefromparts(left(a.ProcessDate,4),right(left(a.ProcessDate,6),2),right(a.ProcessDate,2)) date 
into #temp3
from ARCUSYM000.dbo.LOAN a
left join [ARCUSYM000].[arcu].[ARCULoanCategory] b	
on b.loantype=a.TYPE
where 
 b.LoanCategory1 = 'Consumer' and b.LoanCategory2='Vehicle'
 and a.ProcessDate = '20220831'
 and a.OPENDATE is not null 
 and a.CLOSEDATE is null 
 and a.CHARGEOFFDATE is null

 --select distinct PARENTACCOUNT from #temp3
 --where PARENTACCOUNT in (Select * from #TPa)

 --select count( * ) from #temp3

 drop table if exists #Auto_loan
 Select Distinct a.*,
 b.#AL,
 b.[$AL_Balance],
 case when a.PARENTACCOUNT=b.PARENTACCOUNT then 1 else 0 end as 'AL_Flag'
 into #Auto_loan
 from #TPa a
 left join
  (
 Select Distinct PARENTACCOUNT,count(*) '#AL',sum(BALANCE) '$AL_Balance' 
 from
 #temp3
 group by PARENTACCOUNT
 ) b
 on a.PARENTACCOUNT=b.PARENTACCOUNT
 order by AL_Flag desc


 --HELOC


 
 drop table if exists #temp4
select distinct a.PARENTACCOUNT,a.BALANCE,a.OPENDATE
--1 as Grenstate_Auto_Loan
--,datefromparts(left(a.ProcessDate,4),right(left(a.ProcessDate,6),2),right(a.ProcessDate,2)) date 
into #temp4
from ARCUSYM000.dbo.LOAN a
left join [ARCUSYM000].[arcu].[ARCULoanCategory] b	
on b.loantype=a.TYPE
where 
 --b.LoanCategory1 = 'Consumer' and
  b.LoanCategory4='HELOC'
 and a.ProcessDate = '20220831'
 and a.OPENDATE is not null 
 and a.CLOSEDATE is null 
 and a.CHARGEOFFDATE is null

 --select distinct LoanCategory1,LoanCategory3,LoanCategory4,LoanCategory2 from  [ARCUSYM000].[arcu].[ARCULoanCategory]

  drop table if exists #Heloc
 Select Distinct a.*,
 b.#HL,
 b.[$HL_Balance],
 case when a.PARENTACCOUNT=b.PARENTACCOUNT then 1 else 0 end as 'HL_Flag'
 into #Heloc
 from #TPa a
 left join
  (
 Select Distinct PARENTACCOUNT,count(*) '#HL',sum(BALANCE) '$HL_Balance' 
 from
 #temp3
 group by PARENTACCOUNT
 ) b
 on a.PARENTACCOUNT=b.PARENTACCOUNT
 order by HL_Flag desc

 --select * from #Heloc


 --Credit_Cards

 --select [Extract Date],extract_datepart,fullExtractdate,[Last Statement Date] from TMGData..cardholder
 --where extract_datepart=202208

 drop table if exists #temp5
 select distinct  [Account Number],
 [Last Statement Balance Amount],[Account System Entry Date] into #temp5 from [TMGData].[dbo].[cardholder] --balance?
 where Active_Flag=1
 and extract_datepart = 202208 
--and [Internal Status Code] in ('','N') 
and [External Status Code] not in ('c','z')
--and [Account System Entry Date] is not null 
--and CHARGEOFF_FLAG=0

 drop table if exists #temp6
select distinct CardNumber_UserChar1,PARENTACCOUNT
into #temp6  
from 
ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard
where ProcessDate='20220831'
and OpenDate_UserDate7 is not null 
and ExpirationDate_UserDate3 is not null 
and (ExternalStatus_UserChar8 not in ('chargeoff','Close')
or  ExternalStatus_UserChar8 is null)
order by CardNumber_UserChar1


drop table if exists #temp7
select a.*,b.PARENTACCOUNT into #temp7  from 
#temp5 a
left join 
#temp6 b
on a.[Account Number]=b.CardNumber_UserChar1 


--


  drop table if exists #CC
 Select Distinct a.*,
 b.#CC,
 b.[$cc_Balance],
 case when a.PARENTACCOUNT=b.PARENTACCOUNT then 1 else 0 end as 'CC_Flag'
 into #CC
 from #TPa a
 left join
  (
 Select Distinct PARENTACCOUNT,count(*) '#CC',sum([Last Statement Balance Amount]) '$CC_Balance' 
 from
 #temp7
 group by PARENTACCOUNT
 ) b
 on a.PARENTACCOUNT=b.PARENTACCOUNT
 order by CC_Flag desc






--morgage
drop table if exists #Extractdate_mortgage
		select  Extractdate,max(AsOfDate) AsOfDate
		into #Extractdate_mortgage
		from (select case when len(month(AsOfDate))=1 then concat(year(AsOfDate),0,month(AsOfDate)) else concat(year(AsOfDate),month(AsOfDate)) end Extractdate,* 
		from AE_EDW..F_Mortgage_Daily) A
		where CoreMortgageStatus='Active' and Extractdate='202208'
		group by Extractdate
		order by Extractdate
		go


		drop table if exists #Tracking
		select parentaccount,ID,(USERCHAR1) USERCHAR1,EXPIREDATE,ProcessDate,left(ProcessDate,6) Process_Date 
		into #Tracking
		from ARCUSYM000..TRACKING where ProcessDate='20220831'
		group by parentaccount,ID,USERCHAR1,EXPIREDATE,ProcessDate
		go
	
	
		drop table if exists #Mortgage1
		select distinct a.PARENTACCOUNT,a.Opendate,a.CurrentBalance	
		into #Mortgage1
				from (
				select b.parentaccount,a.*,case when Extractdate=Opendate then 1 else 0 end New_flag
				from	(select case when len(month(AsOfDate))=1 then concat(year(AsOfDate),0,month(AsOfDate)) else concat(year(AsOfDate),month(AsOfDate)) end Extractdate
						,case when len(month(MortgageOpenDate))=1 then concat(year(MortgageOpenDate),0,month(MortgageOpenDate)) else concat(year(MortgageOpenDate),month(MortgageOpenDate)) end Opendate
						,* from AE_EDW..F_Mortgage_Daily 
						) A
				left join (Select * from #Tracking) b
				on a.mortgageid=b.USERCHAR1 and a.Extractdate=b.Process_Date	
				where CoreMortgageStatus='Active' 
				and AsOfDate in (select AsOfDate from #Extractdate_mortgage) and b.EXPIREDATE is null --and MortgageDueDate>'2020-01-31' 
				and CurrentBalance>0 and b.USERCHAR1 is not null
				) A

  drop table if exists #Mortgage
 Select Distinct a.*,
 b.#MG,
 b.[$MG_Balance],
 case when a.PARENTACCOUNT=b.PARENTACCOUNT then 1 else 0 end as 'MG_Flag'
 into #Mortgage
 from #TPa a
 left join
  (
 Select Distinct PARENTACCOUNT,count(*) '#MG',sum(CurrentBalance) '$MG_Balance' 
 from
 #Mortgage1
 group by PARENTACCOUNT
 ) b
 on a.PARENTACCOUNT=b.PARENTACCOUNT
 order by MG_Flag desc

 select * from #Mortgage

 --final data 
 Drop table if exists #preFinal
 select a.*,isnull(b.#AL,0) #AL,isnull(b.[$AL_Balance],0)[$AL_Balance],b.AL_Flag,isnull(c.#CC,0) #CC,isnull(c.[$CC_Balance],0)[$CC_Balance],c.CC_Flag,
 isnull(d.#MG,0) #MG,isnull(d.[$MG_Balance],0)[$MG_Balance],d.MG_Flag,isnull(e.#HL,0)#HL,isnull(e.[$HL_Balance],0)[$HL_Balance],e.HL_Flag
 into #preFinal from #TPa a
 left join #Auto_loan b
 on a.PARENTACCOUNT=b.PARENTACCOUNT
 left join #CC c
 on a.PARENTACCOUNT=c.PARENTACCOUNT
 left join #Mortgage d
 on a.PARENTACCOUNT=d.PARENTACCOUNT
 left join #heloc e
 on a.PARENTACCOUNT=e.PARENTACCOUNT

 --select count(*) from #prefinal

 DRop table if exists #Final
 select b.AccountPrimeNameSSN,a.* into #final from #preFinal a
 left join 
 ARCUSYM000.arcu.ARCUAccountDetailed b
 on a.PARENTACCOUNT=b.AccountNumber
 where b.ProcessDate = (select max(ProcessDate) from ARCUSYM000.arcu.ARCUAccountDetailed )


  DRop table if exists #Final1
  select a.*,b.SSN,case when (#AL+#CC+#HL+#MG)=0 then 0 else 1 end as GreenState_flag,case when b.SSN is null then 0 else 1 end ssn_flag
  ,case when a.AccountPrimeNameSSN=b.SSN then 1 else 0 end as Product_check_flag
  ,isnull(b.AutoOpenTradeCount,0) AutoOpenTradeCount ,isnull(b.AutoOpenTradeBalance,0) AutoOpenTradeBalance,
  isnull(b.CCOpenCount,0) CCOpenCount,isnull(b.CCRevolvingBalance,0) CCRevolvingBalance,
  ISNULL(b.HELOCOpenCount,0) HELOCOpenCount,isnull(b.HELOCOpenBalance,0) HELOCOpenBalance,
  isnull(b.MortgageOpenCount,0)MortgageOpenCount,isnull(b.MortgageOpenBalance,0) MortgageOpenBalance
  into #final1 
  from #final a
  left join BureauData.dbo.TransUnionAttributeHistory  b
  on a.AccountPrimeNameSSN=b.SSN




 --====================================================

 --select * from #final1


 --where AccountPrimeNameSSN is not null


 
 DRop table if exists #Final222
 select b.AccountPrimeNameSSN,a.* into #final222 from #Heloc a
 left join 
 ARCUSYM000.arcu.ARCUAccountDetailed b
 on a.PARENTACCOUNT=b.AccountNumber
 where b.ProcessDate = (select max(ProcessDate) from ARCUSYM000.arcu.ARCUAccountDetailed )

 select * from BureauData.dbo.TransUnionAttributeHistory
 where SSN='480237771'

 --select * from #Final222
 --where AccountPrimeNameSSN=480237771

 --select * from 
 
 --select top 10  * from #Auto_loan
 --where 
 -- select top 10  * from #Heloc
 --  select top 10  * from #Mortgage
 --  where #MG is not null
 --   select top 10  * from #CC

drop table if exists #temp6
select a.*,b.PARENTACCOUNT,b.TMGDurableKey_UserChar10
into #temp6
from #temp5 a
left join 
ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard b
on a.Durable_Key=b.TMGDurableKey_UserChar10
where b.ProcessDate='20220831'


select count(distinct Durable_Key) from [TMGData].[dbo].[cardholder]
where Active_Flag=1
 and extract_datepart = 202208 
and [Internal Status Code] in ('','N') 
and [External Status Code] not in ('c','z')


select count (distinct TMGDurableKey_UserChar10) from ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard
where processdate like '%202208%'


select count(distinct Durable_Key) from #temp5

select TMGDurableKey_UserChar10 from #temp6
where TMGDurableKey_UserChar10  in (select Durable_Key from #temp5)

--Select * from ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard where PARENTACCOUNT=0013883636 and processdate='20220831'
--where SSN_UserChar3 in (select distinct [Social Security Number] from  #temp5)
--and processdate='20220831'
--order by 1





select a.[Account Number],b.PARENTACCOUNT from [TMGData].[dbo].[cardholder] a
left join ARCUSYM000..SAVINGS b
on a.[Account Number]=b.PARENTACCOUNT

select Extract_ACCOUNT_OPEN_DATE,[Date First Active New] from [TMGData].[dbo].[cardholder]


 select * from #Heloc





				select * from ARCUSYM000..TRACKING
				select distinct PARENTACCOUNT from #Tracking
drop table if exists #test
select distinct  a.*,b.AccountPrimeNameSSN
 into
#test
from #temp a
left join
(select distinct AccountPrimeNameSSN,accountnumber,processdate from  ARCUSYM000.[arcu].[ARCUAccountDetailed] where ProcessDate like '%202208%') b
on a.PARENTACCOUNT=b.accountnumber 

----


--drop table if exists #temp
--select Distinct b.ApplicationTypeID,cast(ProductCode as varchar) ProductCode,ProductName,ApplicationDescription,ApplicationTableName
--			--into #temp
--			 from [AE_EDW].[tempods].[S_CRMProductType] a
--			left join [AE_EDW].[tempods].[S_CRMApplicationType] b
--			on a.ApplicationTypeID=b.ApplicationTypeID
--			where ApplicationDescription is not null and ProductName!='IRA Savings'
--			and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits'

--select  a.PARENTACCOUNT,a.BALANCE,b.ProductCode,a.ProcessDate from arcusym000.dbo.SAVINGS a
--left join #temp b
--on 
--a.TYPE=b.ProductCode
--where  ProcessDate in (select ProcessDate from #processdate)
--group by a.ProcessDate, a.PARENTACCOUNT,a.BALANCE,b.ProductCode

--			e.ProductCode=aa.TYPE

--	select * from 		[AE_EDW].[tempods].[S_CRMProductType]
--	select * from 			 [AE_EDW].[tempods].[S_CRMApplicationType]


--loan category 4
--ARCUSYM000..TRACKING
--cardholder
--openclose ex in

select * from ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard
rm(list=ls())
getwd()
library(RODBC)
databaseConnection <- odbcDriverConnect("Driver={SQL Server};server=10.200.102.244;database=Analytics;uid=Curisesadamhuseni;pwd=Analyst@1990")
Checking_Data <- sqlQuery(databaseConnection, "select  *  from Analytics.sadam.[Checking_Attrition_Model_data201801]")
Checking_dataframe <- data.frame(Checking_Data,stringsAsFactors=FALSE)

 #Column_type <- sapply(Checking_dataframe,class)
 #write.csv(Column_type,"Columnnames.csv")
#index_number <- colnames(Checking_dataframe)
#write.csv(index_number,"index_number.csv")
# Checking_dataframe_colnames<- colnames(Checking_dataframe)
# write.csv(Checking_dataframe_colnames,"Checking_dataframe_colnames.csv")
#Checking_dataframe_1<- Checking_dataframe[,c(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,523,524,525,526,527,528,529,530,531,532,533,534,535,536,537,538,539,540,541,542,543,544,545,546,547,548,549,550,551,552,553,554,555,556,557,558,559,560,561,562,563,564,565,566,567,568,569,570,571,572,573,574,575,576,577,578,579,580,581,582,583,584,585,586,587,588,589,590,591,592,593,594,595,596,597,598,599,600,601,602,603,604,605,606,607,608,609,610,611,612,613,614,615,616,617,618,619,620,621,622,623,624,625,626,627,628,629,630,631,632,633,634,635,636,637,638,639,640,641,642,643,644,645,646,647,648,649,650,651,652,653,654,655,656,657,658,659,660,661,662,663,664,665,666,667,668,669,670,671,672,673,674,675,676,677,678,679,680,681,682,683,684,685,686,687,688,689,690,691,692,693,694,695,696,697,698,699,700,701,702,703,704,705,706,707,708,709,710,711,712,713,714,715,716,717,718,719,720,721,722,723,724,725,726,727,728,729,730,731,732,733,734,735,736,737,738,739,740,741,742,743,744,745,746,747,748,749,750,751,752,753,754,755,756,757,758,759,760,761,762,763,764,765,766,767,768,769,770,771,772,773,774,775,776,777,778,779,780,781,782,783,784,785,786,787,788,789,790,791,792,793,794,795,796,797,798,799,800,801,802,803,804,805,806,807,808,809,810,811,812,813,814,815,816,817,818,819,820,821,822,823,824,825,826,827,828,829,830,831,832,833,834,835,836,837,838,839,840,841,842,843,844,845,846,847,848,849,850,851,852,853,854,855,856,857,858,859,860,861,862,863,864,865,866,867,868,869,870,871,872,873,874,875,876,877,878,879,880,881,884,885,886,887,888,889,890,891,892,893,894,895,896,897,898,899,902,903,904,905,906,907,908,909,910,911,912,913,914,915,916,917,920,921,922,923,924,925,926,927,928,929,930,931,932,933,934,935,938,939,940,941,942,943,944,945,946,947,948,949,950,951,952,953,956,957,958,959,960,961,962,963,964,965,966,967,968,969,970,973,974,975,976,977,978,979,980,981,982,983,984,985,986,987,988,989,990,991)]

#Checking_dataframe_1 <- Filter(function(x)sd(x) !=0,Checking_dataframe)
#library(pastecs)
#Summary_file <- stat.desc(Checking_dataframe)
#write.csv(Summary_file,"Statistics_summary.csv")
# 
# Myfunction1 <- function(data)
# {
#   a <- data.frame()
#   e <- data.frame()
#   f <- data.frame()
#   G <- data.frame()
#   H <- data.frame()
#   I <- data.frame()
#   J <- data.frame()
#   K <- data.frame()
#   L <- data.frame()
#   M <- data.frame()
#   N <- data.frame()
#   Col_bined <- data.frame()
# 
# 
#   for (i in 1:ncol(data))
#   {
#     if(class(data[,c(i)])!="factor") {
#       Total_count <- NROW(data)-(sum(is.na(data[,c(i)]))+sum(data[,c(i)]==0,na.rm = TRUE))
#       Count_NA <- data.frame(sum(is.na(data[,c(i)])))
#       Count_zero <- data.frame(sum(data[,c(i)]==0,na.rm = TRUE))
#       Mean_1 <- data.frame(mean(data[,c(i)],na.rm = TRUE))
#       Median_1 <- data.frame(median(data[,c(i)],na.rm = TRUE))
#       std <- data.frame(sd(data[,c(i)],na.rm = TRUE))
#       Max_1 <- data.frame(max(data[,c(i)],na.rm = TRUE))
#       Min_1 <- data.frame(min(data[,c(i)],na.rm = TRUE))
#       b <-data.frame(colnames(data)[i],quantile(data[,c(i)],.25,na.rm = TRUE))
#       c <-data.frame(quantile(data[,c(i)],.75,na.rm = TRUE))
#       d <-data.frame(quantile(data[,c(i)],.99,na.rm = TRUE))
#       row.names(Count_NA) <- NULL
#       row.names(Count_zero) <- NULL
#       row.names(Mean_1) <- NULL
#       row.names(Median_1) <- NULL
#       row.names(std) <- NULL
#       row.names(Max_1) <- NULL
#       row.names(Min_1) <- NULL
#       row.names(Total_count) <- NULL
#       row.names(b) <- NULL
#       row.names(c) <- NULL
#       row.names(d) <- NULL
# 
#       a <- rbind(b,a)
#       e <- rbind(c,e)
#       f <- rbind(d,f)
# 
#       G <- rbind(Count_NA,G)
#       H <- rbind(Count_zero,H)
#       I <- rbind(Mean_1,I)
#       J <- rbind(Median_1,J)
#       K <- rbind(Max_1,K)
#       L <- rbind(Min_1,L)
#       M <- rbind(std,M)
#       N <- rbind(Total_count,N)
#       Col_bined <- data.frame(cbind(a,e,f,N,G,H,I,J,M,K,L))
#       colnames(Col_bined) <- c("Variables","Percentile 25%","Percentile 75%","Percentile 99%"
#                                ,"Total_No_obs","Count_NA","Count_zero","Mean","Median","Standard_Deviation","Max","Min")
# 
#     }
# 
#   }
# 
#   Col_bined1<- data.frame(apply(Col_bined,2,rev))
# 
#   write.csv(Col_bined1,"Summary_checking_attrition.csv")
# }

#Myfunction1(Checking_dataframe_1)

# column_name <- colnames(Checking_dataframe_1)
# write.csv(column_name,"colname_datafrma1.csv")
# 
# Checking_dataframe_2 <- Checking_dataframe_1[,c(958,20,21,22,23,24,25,26,27,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48
#                                                 ,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74
#                                                 ,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100
#                                                 ,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119
#                                                 ,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138
#                                                 ,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,157,158
#                                                 ,159,160,161,162,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179
#                                                 ,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198
#                                                 ,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217
#                                                 ,219,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238
#                                                 ,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257
#                                                 ,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276
#                                                 ,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295
#                                                 ,296,297,298,299,380,444,445,446,448,451,452,453,454,455,456,457,458,459,460
#                                                 ,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479
#                                                 ,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498
#                                                 ,499,500,501,502,503,504,505,506,507,559,560,561,562,563,564,565,566,567,568
#                                                 ,569,570,571,572,573,574,575,576,577,578,579,580,581,582,583,584,585,586,587
#                                                 ,588,589,590,591,592,593,594,595,596,597,598,599,600,601,602,603,604,605,606
#                                                 ,607,608,759,760,761,762,763,764,765,766,767,768,769,770,771,772,773,774,775
#                                                 ,776,777,778,779,780,781,782,783,784,785,786,787,788,794,795,796,797,798,799
#                                                 ,800,801,802,803,875,876,877,878,879,880,881,882,883,884,885,886,887,888,889
#                                                 ,905,921,938,939,940,941,942,943,944,945,946,947,948,949,950,951,952,1)]
# 
# # column_name2 <- colnames(Checking_dataframe_2)
# # write.csv(column_name2,"colname_datafrma2.csv")
# Checking_dataframe_3 <- Checking_dataframe_2[,c(1,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35
#                                                 ,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62
#                                                 ,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89
#                                                 ,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112
#                                                 ,113,114,115,116,117,118,119,120,121,122,123,124,125,127,128,129,130,132
#                                                 ,133,135,136,138,140,141,142,143,144,145,146,147,148,149,150,151,152,153
#                                                 ,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173
#                                                 ,174,175,176,180,181,182,183,184,185,186,187,188,189,190,191,192,193,195,196
#                                                 ,197,198,199,200,202,203,204,205,206,207,208,209,210,211,212,213,214,215,217,218
#                                                 ,219,220,221,222,223,224,225,226,227,228,229,230,232,233,234,235,236,237,238,239
#                                                 ,240,241,242,243,244,245,247,248,249,250,251,252,253,254,255,256,257,258,259,263
#                                                 ,264,265,266,267,268,269,270,271,275,276,277,278,279,280,281,282,283,284,285,286
#                                                 ,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306
#                                                 ,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326
#                                                 ,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346
#                                                 ,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366
#                                                 ,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386
#                                                 ,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406
#                                                 ,407,408,409,410,411,412,413,414,425,426,427,428,429,430,431,432,433,434,435,436
#                                                 ,437,438,442,443,444,445,446,447,448,449,450,451,452,453,454,455,457)]

Checking_dataframe_3 <- Checking_dataframe[,c(991,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,158,159,160,161,163,164,167,168,170,174,175,178,179,180,181,182,183,184,185,186,187,188,189,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,211,212,213,214,218,219,220,221,222,223,224,225,226,227,228,229,230,232,237,238,239,240,241,242,244,245,246,247,248,249,250,251,252,253,254,255,256,257,259,260,261,262,263,264,265,266,267,268,269,270,271,272,274,275,276,277,278,279,280,281,282,283,284,285,286,287,289,290,291,292,293,294,295,296,297,298,299,300,301,305,306,307,308,309,310,311,312,313,464,465,467,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,523,524,525,526,527,528,580,581,582,583,584,585,586,587,588,589,590,591,592,593,594,595,596,597,598,599,600,601,602,603,604,605,606,607,608,609,610,611,612,613,614,615,616,617,618,619,620,621,622,623,624,625,626,627,628,629,780,781,782,783,784,785,786,787,788,789,790,791,792,793,794,795,796,797,798,799,800,801,802,803,804,805,806,807,808,809,898,899,902,903,904,905,906,907,908,909,910,911,912,913,969,970,973,974,975,976,977,978,979,980,981,982,983,984,1)]
 # colnames.dataframe_3 <- colnames(Checking_dataframe_3)
 # write.csv(colnames.dataframe_3,"colnames.dataframe_3.csv")
#********************* Imputation method
Checking_dataframe_3[,c(164,165,166,167,168,169,170,171,172,173,255,256,257,258,259,260,261,262,266,267,268,269,270,271,272,273,277,278,279,280,281,282,283,284,288,289,290,291,292,293,294,295,299,300,301,302,303,304,305,306)][is.na(Checking_dataframe_3[,c(164,165,166,167,168,169,170,171,172,173,255,256,257,258,259,260,261,262,266,267,268,269,270,271,272,273,277,278,279,280,281,282,283,284,288,289,290,291,292,293,294,295,299,300,301,302,303,304,305,306)])] <- 0

Median.impute <-Checking_dataframe_3[,c(1,415,185,186,187,188,189,190,191,192,199,200,201,202,203,204,205,206,213,214,215,216,217,218,219,220,227,228,229,230,231,232,233,234,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,263,264,265,274,275,276,285,286,287,296,297,298
                                        ,164,165,166,167,168,169,170,171,172,173,255,256,257,258,259,260,261,262,266,267,268,269,270,271,272,273,277,278,279,280,281,282,283,284,288,289,290,291,292,293,294,295,299,300,301,302,303,304,305,306
                                        ,157,158,159,160,161,162,163,174,175,176,177,178,179,180,181,182,183,184,193,194,195,196,197,198,207,208,209,210,211,212,221,222,223,224,225,226,235,236,237,238)]

a_a <- lapply(Median.impute,function(x){ x[is.na(x)]<- median(x,na.rm = TRUE) 
x }) 
Median.impute
Median.impute.value <- as.data.frame(a_a)
sum(is.na(Median.impute.value))
#write.csv(cl,"col_checking_dataframe_3.csv")
Impute_dataframe_1<- Checking_dataframe_3[, c(415,2,3,4,5,6,7,8,9,12,16,17,18,19,21,23,24,25,26,27,28,29,30,31,32,33,36,39,40,41,42,43,45,47,48,49,50,51,52,53,54,55,56,59,62,63,64,65,66,68,70,71,72,73,74,75,76,77,78,79,82,86,87,88,89,91,93,94,95,96,97,99,100,102,105,109,110,111,112,114,116,117,118,119,120,121,122,124,125,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,149,150,151,152,154,155,156,307,308,309,310,312,313,314,315,316,317,318,320,321,322,323,324,325,327,328,329,330,331,332,333,335,336,337,338,339,340,341,342,343,344,346,347,348,349,351,352,353,354,356,357,360,362,364,365,366,370,371,372,375,377,379,380,381,385,386,387,388,389,390,391,392,393,394,396,398,399,400,401,402,403,404,405,406,407,408,409,410,412,413,414)]

Impute_dataframe_2<-Impute_dataframe_1[,c(1,2,3,4,5,6)]
Impute_dataframe_3<-Impute_dataframe_1[,c(1,27,28,29,30,31)]
Impute_dataframe_4<-Impute_dataframe_1[,c(1,52,53,54,55,56)]
Impute_dataframe_5<-Impute_dataframe_1[,c(1,77,78,79,80,81)]
Impute_dataframe_6<-Impute_dataframe_1[,c(1,102,103,104,105,106)]
Impute_dataframe_7<-Impute_dataframe_1[,c(1,127,128,129,130,131)]
Impute_dataframe_8<-Impute_dataframe_1[,c(1,152,153,154,155,156)]
Impute_dataframe_9<-Impute_dataframe_1[,c(1,177,178,179,180,181)]
Impute_dataframe_10<-Impute_dataframe_1[,c(1,7,8,9,10,11)]
Impute_dataframe_11<-Impute_dataframe_1[,c(1,32,33,34,35,36)]
Impute_dataframe_12<-Impute_dataframe_1[,c(1,57,58,59,60,61)]
Impute_dataframe_13<-Impute_dataframe_1[,c(1,82,83,84,85,86)]
Impute_dataframe_14<-Impute_dataframe_1[,c(1,107,108,109,110,111)]
Impute_dataframe_15<-Impute_dataframe_1[,c(1,132,133,134,135,136)]
Impute_dataframe_16<-Impute_dataframe_1[,c(1,157,158,159,160,161)]
Impute_dataframe_17<-Impute_dataframe_1[,c(1,182,183,184,185,186)]
Impute_dataframe_18<-Impute_dataframe_1[,c(1,12,13,14,15,16)]
Impute_dataframe_19<-Impute_dataframe_1[,c(1,37,38,39,40,41)]
Impute_dataframe_20<-Impute_dataframe_1[,c(1,62,63,64,65,66)]
Impute_dataframe_21<-Impute_dataframe_1[,c(1,87,88,89,90,91)]
Impute_dataframe_22<-Impute_dataframe_1[,c(1,112,113,114,115,116)]
Impute_dataframe_23<-Impute_dataframe_1[,c(1,137,138,139,140,141)]
Impute_dataframe_24<-Impute_dataframe_1[,c(1,162,163,164,165,166)]
Impute_dataframe_25<-Impute_dataframe_1[,c(1,187,188,189,190,191)]
Impute_dataframe_26<-Impute_dataframe_1[,c(1,17,18,19,20,21)]
Impute_dataframe_27<-Impute_dataframe_1[,c(1,42,43,44,45,46)]
Impute_dataframe_28<-Impute_dataframe_1[,c(1,67,68,69,70,71)]
Impute_dataframe_29<-Impute_dataframe_1[,c(1,92,93,94,95,96)]
Impute_dataframe_30<-Impute_dataframe_1[,c(1,117,118,119,120,121)]
Impute_dataframe_31<-Impute_dataframe_1[,c(1,142,143,144,145,146)]
Impute_dataframe_32<-Impute_dataframe_1[,c(1,167,168,169,170,171)]
Impute_dataframe_33<-Impute_dataframe_1[,c(1,192,193,194,195,196)]
Impute_dataframe_34<-Impute_dataframe_1[,c(1,22,23,24,25,26)]
Impute_dataframe_35<-Impute_dataframe_1[,c(1,47,48,49,50,51)]
Impute_dataframe_36<-Impute_dataframe_1[,c(1,72,73,74,75,76)]
Impute_dataframe_37<-Impute_dataframe_1[,c(1,97,98,99,100,101)]
Impute_dataframe_38<-Impute_dataframe_1[,c(1,122,123,124,125,126)]
Impute_dataframe_39<-Impute_dataframe_1[,c(1,147,148,149,150,151)]
Impute_dataframe_40<-Impute_dataframe_1[,c(1,172,173,174,175,176)]
Impute_dataframe_41<-Impute_dataframe_1[,c(1,197,198,199,200,201)]




library(doParallel)
registerDoParallel()
#install.packages("mice")
library(mice)
#md.pattern(Impute_dataframe_2)

#install.packages("VIM")
library(VIM)
# Plot_missing <- aggr(Checking_dataframe_3,col=c('navyblue','yellow'),number=TRUE
#                      ,labels=names(Checking_dataframe_3),cex.axis=0.7,gap=3,ylab=c("missing data","pattern"))

impute_data2 <- mice(Impute_dataframe_2,m=4,method='cart',seed=500)
compeletedata2 <- complete(impute_data2,2)
impute_data3 <- mice(Impute_dataframe_3,m=4,method='cart',seed=500)
compeletedata3 <- complete(impute_data3,2)
impute_data4 <- mice(Impute_dataframe_4,m=4,method='cart',seed=500)
compeletedata4 <- complete(impute_data4,2)
impute_data5 <- mice(Impute_dataframe_5,m=4,method='cart',seed=500)
compeletedata5 <- complete(impute_data5,2)
impute_data6 <- mice(Impute_dataframe_6,m=4,method='cart',seed=500)
compeletedata6 <- complete(impute_data6,2)
impute_data7 <- mice(Impute_dataframe_7,m=4,method='cart',seed=500)
compeletedata7 <- complete(impute_data7,2)
impute_data8 <- mice(Impute_dataframe_8,m=4,method='cart',seed=500)
compeletedata8 <- complete(impute_data8,2)
impute_data9 <- mice(Impute_dataframe_9,m=4,method='cart',seed=500)
compeletedata9 <- complete(impute_data9,2)
impute_data10 <- mice(Impute_dataframe_10,m=4,method='cart',seed=500)
compeletedata10 <- complete(impute_data10,2)
impute_data11 <- mice(Impute_dataframe_11,m=4,method='cart',seed=500)
compeletedata11 <- complete(impute_data11,2)
impute_data12 <- mice(Impute_dataframe_12,m=4,method='cart',seed=500)
compeletedata12 <- complete(impute_data12,2)
impute_data13 <- mice(Impute_dataframe_13,m=4,method='cart',seed=500)
compeletedata13 <- complete(impute_data13,2)
impute_data14 <- mice(Impute_dataframe_14,m=4,method='cart',seed=500)
compeletedata14 <- complete(impute_data14,2)
impute_data15 <- mice(Impute_dataframe_15,m=4,method='cart',seed=500)
compeletedata15 <- complete(impute_data15,2)
impute_data16 <- mice(Impute_dataframe_16,m=4,method='cart',seed=500)
compeletedata16 <- complete(impute_data16,2)
impute_data17 <- mice(Impute_dataframe_17,m=4,method='cart',seed=500)
compeletedata17 <- complete(impute_data17,2)
impute_data18 <- mice(Impute_dataframe_18,m=4,method='cart',seed=500)
compeletedata18 <- complete(impute_data18,2)
impute_data19 <- mice(Impute_dataframe_19,m=4,method='cart',seed=500)
compeletedata19 <- complete(impute_data19,2)
impute_data20 <- mice(Impute_dataframe_20,m=4,method='cart',seed=500)
compeletedata20 <- complete(impute_data20,2)
impute_data21 <- mice(Impute_dataframe_21,m=4,method='cart',seed=500)
compeletedata21 <- complete(impute_data21,2)
impute_data21 <- mice(Impute_dataframe_21,m=4,method='cart',seed=500)
compeletedata21 <- complete(impute_data21,2)
impute_data22 <- mice(Impute_dataframe_22,m=4,method='cart',seed=500)
compeletedata22 <- complete(impute_data22,2)
impute_data23 <- mice(Impute_dataframe_23,m=4,method='cart',seed=500)
compeletedata23 <- complete(impute_data23,2)
impute_data24 <- mice(Impute_dataframe_24,m=4,method='cart',seed=500)
compeletedata24 <- complete(impute_data24,2)
impute_data25 <- mice(Impute_dataframe_25,m=4,method='cart',seed=500)
compeletedata25 <- complete(impute_data25,2)
impute_data26 <- mice(Impute_dataframe_26,m=4,method='cart',seed=500)
compeletedata26 <- complete(impute_data26,2)
impute_data27 <- mice(Impute_dataframe_27,m=4,method='cart',seed=500)
compeletedata27 <- complete(impute_data27,2)
impute_data28 <- mice(Impute_dataframe_28,m=4,method='cart',seed=500)
compeletedata28 <- complete(impute_data28,2)
impute_data29 <- mice(Impute_dataframe_29,m=4,method='cart',seed=500)
compeletedata29 <- complete(impute_data29,2)
impute_data30 <- mice(Impute_dataframe_30,m=4,method='cart',seed=500)
compeletedata30 <- complete(impute_data30,2)
impute_data31 <- mice(Impute_dataframe_31,m=4,method='cart',seed=500)
compeletedata31 <- complete(impute_data31,2)
impute_data32 <- mice(Impute_dataframe_32,m=4,method='cart',seed=500)
compeletedata32 <- complete(impute_data32,2)
impute_data33 <- mice(Impute_dataframe_33,m=4,method='cart',seed=500)
compeletedata33 <- complete(impute_data33,2)
impute_data34 <- mice(Impute_dataframe_34,m=4,method='cart',seed=500)
compeletedata34 <- complete(impute_data34,2)
impute_data35 <- mice(Impute_dataframe_35,m=4,method='cart',seed=500)
compeletedata35 <- complete(impute_data35,2)
impute_data36 <- mice(Impute_dataframe_36,m=4,method='cart',seed=500)
compeletedata36 <- complete(impute_data36,2)
impute_data37 <- mice(Impute_dataframe_37,m=4,method='cart',seed=500)
compeletedata37 <- complete(impute_data37,2)
impute_data38 <- mice(Impute_dataframe_38,m=4,method='cart',seed=500)
compeletedata38 <- complete(impute_data38,2)
impute_data39 <- mice(Impute_dataframe_39,m=4,method='cart',seed=500)
compeletedata39 <- complete(impute_data39,2)
impute_data40 <- mice(Impute_dataframe_40,m=4,method='cart',seed=500)
compeletedata40 <- complete(impute_data40,2)
impute_data41 <- mice(Impute_dataframe_41,m=4,method='cart',seed=500)
compeletedata41 <- complete(impute_data41,2)

Final_Imputation_data<- merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(compeletedata2,compeletedata3,by="Parentaccount",all=TRUE)
                                                                                                                                                                                                                                                            ,compeletedata4,by="Parentaccount",all=TRUE)
                                                                                                                                                                                                                                                      ,compeletedata5,by="Parentaccount",all=TRUE)
                                                                                                                                                                                                                                                ,compeletedata6,by="Parentaccount",all=TRUE)
                                                                                                                                                                                                                                          ,compeletedata7,by="Parentaccount",all=TRUE)
                                                                                                                                                                                                                                    ,compeletedata8,by="Parentaccount",all=TRUE)
                                                                                                                                                                                                                              ,compeletedata9,by="Parentaccount",all=TRUE)
                                                                                                                                                                                                                        ,compeletedata10,by="Parentaccount",all=TRUE)
                                                                                                                                                                                                                  ,compeletedata11,by="Parentaccount",all=TRUE)
                                                                                                                                                                                                            ,compeletedata12,by="Parentaccount",all=TRUE)
                                                                                                                                                                                                      ,compeletedata13,by="Parentaccount",all=TRUE)
                                                                                                                                                                                                ,compeletedata14,by="Parentaccount",all=TRUE)
                                                                                                                                                                                          ,compeletedata15,by="Parentaccount",all=TRUE)
                                                                                                                                                                                    ,compeletedata16,by="Parentaccount",all=TRUE)
                                                                                                                                                                              ,compeletedata17,by="Parentaccount",all=TRUE)
                                                                                                                                                                        ,compeletedata18,by="Parentaccount",all=TRUE)
                                                                                                                                                                  ,compeletedata19,by="Parentaccount",all=TRUE)
                                                                                                                                                            ,compeletedata20,by="Parentaccount",all=TRUE)
                                                                                                                                                      ,compeletedata21,by="Parentaccount",all=TRUE)
                                                                                                                                                ,compeletedata22,by="Parentaccount",all=TRUE)
                                                                                                                                          ,compeletedata23,by="Parentaccount",all=TRUE)
                                                                                                                                    ,compeletedata24,by="Parentaccount",all=TRUE)
                                                                                                                              ,compeletedata25,by="Parentaccount",all=TRUE)
                                                                                                                        ,compeletedata26,by="Parentaccount",all=TRUE)
                                                                                                                  ,compeletedata27,by="Parentaccount",all=TRUE)
                                                                                                            ,compeletedata28,by="Parentaccount",all=TRUE)
                                                                                                      ,compeletedata29,by="Parentaccount",all=TRUE)
                                                                                                ,compeletedata30,by="Parentaccount",all=TRUE)
                                                                                          

Final_Imputation_data2 <-merge(merge(merge(merge(merge(merge(merge(merge(merge(merge(compeletedata31,compeletedata32,by="Parentaccount",all=TRUE)
                                                                                     ,compeletedata33,by="Parentaccount",all=TRUE)
                                                                         ,compeletedata34,by="Parentaccount",all=TRUE)
                                                                   ,compeletedata35,by="Parentaccount",all=TRUE)
                                                             ,compeletedata36,by="Parentaccount",all=TRUE)
                                                       ,compeletedata37,by="Parentaccount",all=TRUE)
                                                 ,compeletedata38,by="Parentaccount",all=TRUE)
                                           ,compeletedata39,by="Parentaccount",all=TRUE)
                                     ,compeletedata40,by="Parentaccount",all=TRUE)
                               ,compeletedata41,by="Parentaccount",all=TRUE)
                        
                                    
Final.data.imputed <- merge(Median.impute.value,Final_Imputation_data,by="Parentaccount",all=TRUE)
write.csv(Final.data.imputed,"Finaldataimputed.csv")
write.csv(Final_Imputation_data2,"Finaldataimputed2.csv")
# Final.data.imputed
# impute_data$imp$Last.Statement.Payment.Amount_CC_Q1
# compeletedata <- complete(impute_data,2)
# write.csv(compeletedata,"imputed_data.csv")
# write.csv(Impute_dataframe_2,"datatoimpute.csv")
# colnames.Checking_dataframe_3<- colnames(Checking_dataframe_3)
# write.csv(colnames.Checking_dataframe_3,"Checking_dataframe_3.csv")
#Checking_MOdel_dataframe4 <- replace(Checking_dataframe_3,is.na(Checking_dataframe_3),-99999999)

library(fit.models)
library(BBmisc)
Checking_Data4 <- sqlQuery(databaseConnection, "select  *  FROM [Analytics].[dbo].[Checking_Attrition_Imputed_data]")
Checking_MOdel_dataframe4 <- data.frame(Checking_Data4)
Checking_MOdel_dataframe5 <- normalize(Checking_MOdel_dataframe4,method = "standardize",range = c(0,1),margin = 1L,on.constant = "quiet")

# temp <- Checking_MOdel_dataframe4[,c(1,2,3,4,5,6)]
# Outlier_mah <- mahalanobis(temp,colMeans(temp),cov(temp))
# Final.data.imputed$Checking_Attrition_Flag
set.seed(1701)
sample_1 <- sample.int(n= nrow(Checking_MOdel_dataframe5)
                       ,size = floor(.60*nrow(Checking_MOdel_dataframe4)),replace = F)
Train_data <- Checking_MOdel_dataframe4[sample_1,]
Test_data <- Checking_MOdel_dataframe4[-sample_1,]
# Train_data$Checking_Attrition_Flag <- as.factor(Train_data$Checking_Attrition_Flag)

# Random Forest Tree
# install.packages("randomForest")
# install.packages("e1071")
# install.packages("caret")
# install.packages("ROCR")
library(randomForest)
library(e1071)
library(caret)
library(ROCR)
set.seed(2017)

RF <- randomForest(Checking_Attrition_Flag ~.,data = Train_data,ntree=200)

Important_vr <- importance(RF)
write.csv(Important_vr,"Imp_VR100_all_CheckingAttrition.csv")
install.packages("digest")
library(digest)
library(randomForestExplainer)
min_depth_frame <- min_depth_distribution(RF)
plot_min_depth_distribution(min_depth_frame)

importance_frame <- measure_importance(RF)
save(importance_frame, file = "importance_frame_CheckingAttrition.rda")
load("importance_frame_Unsecured.rda")
importance_frame
write.csv(importance_frame,"Importance_frame_all_CheckingAttrition.csv")


prediction1 <- predict(RF,test1,type = "prob")
Col_2 <- prediction1[,2]
prediction2 <- prediction(Col_2,test1$Final_Checking_flag)
RF.performance <- performance(prediction2,"rec","prec")
RF.performance <- performance(prediction2,"fpr","tpr")
plot(RF.performance)
score_frame_RF <- data.frame(test1,prediction)

write.csv(score_frame_RF,"score_test_CheckingModel_RandomForest19.csv")


levels(train1$Final_Checking_flag) <- make.names(levels(factor(train1$Final_Checking_flag)))

levels(test1$Final_Checking_flag) <- make.names(levels(factor(test1$Final_Checking_flag)))

control  <- trainControl(method = "cv",number = 5,search = "grid")#,summaryFunction = twoClassSummary,classProbs = TRUE)
Train_data$Checking_Attrition_Flag <-as.factor(Train_data$Checking_Attrition_Flag)
model_weights <- ifelse(Train_data$Checking_Attrition_Flag == "0",
                        (1/table(Train_data$Final_Checking_flag)[1]) * 0.25,
                        (1/table(Train_data$Final_Checking_flag)[2]) * 0.75)

set.seed(2017)
control$sampling <- "down"
down_fit <- train(Checking_Attrition_Flag ~.,Train_data,method = "rf",metric="Accuracy"
                  ,trControl = control,tuneGrid = NULL)
print(control)
print(down_fit)
rf_default1 <- train(Final_Checking_flag ~.,Train_data,method = "rf",metric="ROC"
                     ,trControl = control,tuneGrid = NULL,weights = model_weights)
print(rf_default1)
summary(RF)
set.seed(2017)
tunegrid <- expand.grid(.mtry=c(1:10))
colnames(Train_data)
RF_mtry <-  train(Checking_Attrition_Flag ~.,Train_data,method = "rf",metric="Accuracy"
                  ,trControl = control,tuneGrid = tunegrid,importance = TRUE
                  ,nodesize = 14,ntree = 300)

print(RF_mtry)
best_mtry <- RF_mtry$bestTune$mtry
max(RF_mtry$bestTune$mtry)

store_maxnode <- list()
tunegrid1 <- expand.grid(.mtry = best_mtry)
for(maxnodes in c(20:30))
{set.seed(123)
  rf_maxnode <- train(Final_Checking_flag ~.,train1,method = "rf",metric="Accuracy"
                      ,trControl = control,tuneGrid = tunegrid1,importance = TRUE
                      ,maxnodes = maxnodes,nodesize = 14,ntree = 300)
  current_iteration <- toString(maxnodes)
  store_maxnode[[current_iteration]] <- rf_maxnode
}
results_mtry <- resamples(store_maxnode)
summary(results_mtry)

store_maxtree <- list()
for (ntree in c(250,300,350,400,450,500,550,600,650,700,750,800,850,900,1000,2000))
{
  set.seed(123)
  rf_maxTree <- train(Final_Checking_flag ~.,train1,method = "rf",metric="Accuracy"
                      ,trControl = control,tuneGrid = tunegrid1,importance = TRUE
                      ,maxnodes = 21,nodesize = 14,ntree = ntree)
  key <- toString(ntree)
  store_maxtree[[key]] <- rf_maxTree
}
results_Tree <- resamples(store_maxtree)
summary(results_Tree)
dotplot(results_Tree)
plot(RF,log = "x",main="black default,red samplesize, gree tree depth")

set.seed(2017)
rf_final_model <- train(Final_Checking_flag ~.,train1,method = "rf",metric="Accuracy"
                        ,trControl = control,importance = TRUE
                        ,tunegrid = tunegrid1,maxnodes = 21,nodesize = 14,ntree = 250)
set.seed(2017)
RF_11 <- randomForest(Final_Checking_flag ~.,train1,method = "rf",metric="Accuracy"
                      ,importance = TRUE
                      ,mtry = 1,maxnodes = 21,nodesize = 14,ntree = 250)
summary(rf_final_model)

prediction <- predict(rf_final_model,test1)

score_frame_RF <- data.frame(test1,prediction)

write.csv(score_frame_RF,"score_test_CheckingModel_RandomForest.csv")

confusionMatrix(prediction,test1$Final_Checking_flag)

library(MLmetrics)

test1$Final_Checking_flag <- as.numeric(test1$Final_Checking_flag)
prediction = as.numeric(prediction)
F1_Score(y_pred = prediction,y_true = test1$Final_Checking_flag)
F1_Score(y_pred = prediction,y_true = test1$Final_Checking_flag,positive = "1")

Important_vr <- importance(RF)
write.csv(Important_vr,"Imp_VR100_CheckingAccount.csv")
library(randomForestExplainer)
min_depth_frame <- min_depth_distribution(RF)
plot_min_depth_distribution(min_depth_frame)

importance_frame <- measure_importance(RF)
save(importance_frame, file = "importance_frame_CheckingAccount.rda")
load("importance_frame_CheckingAccount.rda")
importance_frame
write.csv(importance_frame,"Importance_frame_all_CheckingAccount.csv")

fitted.RF.results <- predict(rf_default1,train1,type = 'response')
score_frame3 <- data.frame(train1,fitted.RF.results)
write.csv(score_frame3,"score_train_CheckingModel_RandomForest.csv")

library(AUC)
auc(fitpreds,(rf_default1$Final_Checking_flag))

predictions <- as.numeric(predict(GLM_Model, Training_dataset_woe, type = 'response'))
multiclass.roc(Training_dataset_woe$Final_Checking_flag, predictions)


Colnames.V_2<- colnames(Direct_vehicle_dataframe2)
write.csv(Colnames.V_2,"colnames.Direct_vehicle_dataframe2.csv")
colnames(Checking_MOdel_dataframe3)


Checking_MOdel_dataframe4<- Checking_MOdel_dataframe3[,c(1,2,32,57,59,52,48,42,56,58,55,53,51,46,18,37,50,19,47,59)]

Checking_MOdel_dataframe4$Final_Checking_flag <- as.numeric(as.character(Checking_MOdel_dataframe4$Final_Checking_flag))

Checking_MOdel_dataframe3$Final_Checking_flag <- as.numeric(as.character(Checking_MOdel_dataframe3$Final_Checking_flag))


# My Step wise 

# library(woeBinning)
# 
# Binning.train.sample <- woe.binning(Train1.sample,'Direct_vehicle_loan_Flag',Train1.sample)
# Training_dataset_woe.sample <- woe.binning.deploy(Train1.sample, Binning.train.sample, add.woe.or.dum.var = "woe")
# 
# 
# My.stepwise.glm.results <- My.stepwise.glm(Y = "Direct_vehicle_loan_Flag", my.variable.list.sample, data = Training_dataset_woe.sample, sle = 0.05,
#                                            sls = 0.05, myfamily="binomial")
# 
# 
# 
# #*************** PRINCIPLE COMPONANT ANALYSIS
# Direct_vehicle_train1 <- train1[,c(3:85)]
# 
# Direct_vehicle.PCA <- prcomp(Direct_vehicle_train1,center = TRUE,scale. = TRUE)
# summary(Direct_vehicle.PCA)
# str(Direct_vehicle.PCA)
# Direct_vehivle_PC <- Direct_vehicle.PCA$x
# print(Direct_vehivle_PC)
# ss=as.data.frame(Direct_vehivle_PC)
# write.csv(ss,"PCA.value.csv")
# write.csv(train1,"Train1.value.csv")
# class(ss)
# names(Direct_vehicle.PCA)
# Direct_vehicle.PCA$rotation
# my.variable.list1 <- c("PC1","PC2","PC3","PC4","PC5","PC6")
# library(My.stepwise)                     
# My.stepwise.glm.results <- My.stepwise.glm(Y = train1$Direct_vehicle_loan_Flag, ss[,1:6], data = ss, sle = 0.05,
#                                            sls = 0.05, myfamily="binomial")
# 
# LM_model <- glm(train1$Direct_vehicle_loan_Flag ~ Direct_vehivle_PC[,1:6])
# summary(LM_model)
# 
# library(devtools)
# install_github("vqv/ggbiplot")
# library(ggbiplot)
# ggbitplot(Direct_vehicle.PCA)
# 
# library(car)
# library(carData)
# Anova(LM_model, type="II", test="Wald")
# vif(LM_model)
# alias.result <- alias(LM_model)
# 
# fitted.results <- predict(LM_model,Direct_vehivle_PC,type='response')
# score_train <- data.frame(Direct_vehivle_PC,fitted.results)
# write.csv(score_train,"direct.vehicle.pca.csv")
# 
# 
# # Xgboost *******************************
# require(data.table)
# setDT(Train_data)
# setDT(Test_data)
# 
# Train_data[is.na(Train_data)] <- "Missing"
# Test_data[is.na(Test_data)] <- "Missing"
# 
# Train_data$Checking_Attrition_Flag <- as.numeric(Train_data$Checking_Attrition_Flag)
# Test_data$Checking_Attrition_Flag <- as.numeric(Test_data$Checking_Attrition_Flag)
# 
# Tr1 <- Train_data[,c(1,2,3,4,5,6,7,8,9,10)]
# Ts1 <- Train_data[,c(1,2,3,4,5,6,7,8,9,10)]
# # using one hot codding 
# labels <- Tr1$Checking_Attrition_Flag
# labels_test <- Ts1$Checking_Attrition_Flag
# 
# New_traindata <- model.matrix(~.+0,data = Tr1[,-c("Checking_Attrition_Flag"),with=F])
# New_testdata <- model.matrix(~.+0,data = Ts1[,-c("Checking_Attrition_Flag"),with= F])
# library(xgboost)
# DTrain <- xgb.DMatrix(data = New_traindata,label=labels)
# DTest <- xgb.DMatrix(data = Test_data,label=labels_test)
# 
# #install.packages("xgboost")
# 
# params_Xgboost = list(params=list("objective"="reg:linear","bst:eta"=0.001
#                                   ,"subsample"=0.75,"max_depth"=5,"colsample_bytree"))
# summary(params_Xgboost)   
# library(devtools)
# library(githubinstall)
# install.packages("Rcpp")
# library(Rcpp)
# devtools::install_github('mlampros/FeatureSelection')
# 2
# githubinstall("FeatureSelection")
# library(FeatureSelection)
# ?FeatureSelection
# pkgbuild::find_rtools(debug = TRUE)
# library(doMC)
# install.packages("doMC", repos="http://R-Forge.R-project.org")
# 2
# 


# **************** LASSO regression

train_matrix <- as.matrix(Train_data)
test_matrix <- as.matrix(Test_data)
# write.csv(train_matrix,"traindatamatrix.csv")
library(glmnet)
library(pROC)
Train_Target_set <- as.matrix(as.factor(Train_data[,c("Checking_Attrition_Flag")]))
Test_Target_set <- as.matrix(as.factor(Test_data[,c("Checking_Attrition_Flag")]))
Train_independent_set<- as.matrix(Train_data[,-which(names(Train_data)=="Checking_Attrition_Flag")])
Test_independent_set<-  as.matrix(Test_data[,-which(names(Train_data)=="Checking_Attrition_Flag")])
library(doParallel)
registerDoParallel()


GLMmod_CV <- cv.glmnet(x = Train_independent_set,y = Train_Target_set,alpha = 1,family = "binomial",nfolds = 10,type.measure = "deviance",parallel = TRUE,)
GLMmod <- glmnet(x = Train_independent_set,y = Train_Target_set,alpha = 1,family = "binomial",lambda =GLMmod_CV$lambda.1se )
plot(GLMmod,xvar = "lambda",label = TRUE)
plot(GLMmod,xvar = "dev",label = TRUE)
plot(GLMmod_CV)
coef(GLMmod_CV)
coef(GLMmod)
roc(Test_Target_set,as.numeric(predict(GLMmod,Test_independent_set,type = "response")))
plot(reg)
reg$lamda

CV_coeff <- matrix(coef(GLMmod_CV))
colnames.trainmatrix<- matrix(colnames(Train_independent_set))
CC <- table(colnames.trainmatrix,CV_coeff)
write.csv(colnames.trainmatrix,"CC.csv")
summary(GLMmod)
Score1 <- predict(GLMmod,newx =Train_independent_set,s = c(0.01,0.005))
Score <- predict(GLMmod,type = "response",newx = Train_independent_set)
write.csv(Score1,"score_1.csv")
plot(GLMmod,xvar = "lambda")

coef(GLMmod)

GLMmod_CV$lambda.min
coef(GLMmod_CV,s= "lambda.min")
score_train_cv <- predict(GLMmod_CV,newx = Train_independent_set,type = "class",s= "lambda.min")
score_train_final  <- data.frame(train_matrix,score_train_cv)
write.csv(score_train_final,"score_train_class.csv")

score_test_cv <- predict(GLMmod_CV,newx = Test_independent_set,type = "response",s= "lambda.min")
score_test_final  <- data.frame(test_matrix,score_test_cv)
write.csv(score_test_final,"score_test_final.csv")
install.packages("caret")
install.packages("e1071")
install.packages("MLmetrics")
library(caret)
library(e1071)
library(MLmetrics)
target_value <- as.table(Train_Target_set)

pred <-as.table(score_train_cv)
u <- union(target_value,pred)
t <- table(factor(target_value,u),factor(pred,u))
confusionMatrix(t)
as.factor(score_train_cv)
confusionMatrix(data = pred ,reference = (target_value))
F1 <- F1_Score(y_pred = as.numeric(pred),y_true =as.numeric(target_value),positive = "1" )


#************* Ridge 
GLMmod_CV_R <- cv.glmnet(x = Train_independent_set,y = Train_Target_set,alpha = 0,family = "binomial",nfolds = 10,type.measure = "deviance",parallel = TRUE,)
GLMmod_R <- glmnet(x = Train_independent_set,y = Train_Target_set,alpha = 0,family = "binomial",lambda =GLMmod_CV$lambda.1se )
plot(GLMmod_R,xvar = "lambda",label = TRUE)
plot(GLMmod_R,xvar = "dev",label = TRUE)
plot(GLMmod_CV_R)
coef(GLMmod_R)
coef(GLMmod_CV_R)
multiclass.roc(Test_Target_set,as.numeric(predict(GLMmod_R,Test_independent_set,type = "response")))


# *************////////  Elastic Net
library(foreach)
library(glmnet)
library(doParallel)
registerDoParallel()

a <- seq(0.1, 0.9, 0.05)
search <- foreach(i = a, .combine = rbind,.packages='glmnet') %dopar% {
  cv <- cv.glmnet(Train_independent_set_v, Train_Target_set, family = "binomial", nfold = 10, type.measure = "deviance", paralle = TRUE, alpha = i)
  data.frame(cvm = cv$cvm[cv$lambda == cv$lambda.1se], lambda.1se = cv$lambda.1se, alpha = i)
}
cv3 <- search[search$cvm == min(search$cvm), ]
md3 <- glmnet(Train_independent_set_v, Train_Target_set, family = "binomial", lambda = cv3$lambda.1se, alpha = cv3$alpha)
coef(md3)
multiclass.roc(Test_Target_set,as.numeric(predict(md3,Test_independent_set_v,type = "response")))
plot(cv3)

colnames.traindata <- colnames(Train_independent_set)
write.csv(colnames.traindata,"colnames_traindata.csv")
Train_independent_set_v <- Train_independent_set[,c(109,149,124,121,148,67,63,71,15,118,66,62,117,17,70,120,139,133,119,213,134)]
Test_independent_set_v <- Test_independent_set[,c(109,149,124,121,148,67,63,71,15,118,66,62,117,17,70,120,139,133,119,213,134)]
colnames(Train_independent_set_v)
library(car)
vif(md3)
Train_independent_set_vv<- Train_independent_set_v[,c(1,2,3,4,5,6,7,8,9,10,11,12,15,18,21)]
Train_independent_set_vvv<-Train_independent_set_vv[,c(1,2,3,4,5,6,9,10,11,14,15)]
Train_independent_set_vvvv <- Train_independent_set_v[,c(1,6,2,10,5)]
Test_independent_set_vvvv<-Test_independent_set_v[,c(1,6,2,10,5)]

 Train_data_v <-Train_data[,c(2,134,135,118,18,121,140,120,214,72,64,63,71,150,122,125,119,110,16,149,67,68)]
# 
# colnames(Train_independent_set_vvvv)
# write.csv(Train_data_v,"Train_data_v.csv")
# 
# pred <- predict(md3,s='lambda.min',newx = Train_independent_set_v, type = "response")
# score_train <- data.frame(Train_Target_set,pred)
# write.csv(score_train,"score_train.csv")
# 
# pred_t <- predict(md3,s='lambda.min',newx = Test_independent_set_v, type = "response")
# score_test <- data.frame(Test_Target_set,pred_t)
# write.csv(score_test,"score_test.csv")
# 
# GLM_Model <- glm(Checking_Attrition_Flag~ .,data = Train_data_v,family = "binomial")

library(arm)
fit_CV <- cv.glmnet(x = Train_independent_set_vvvv,y = Train_Target_set,alpha = 1,family = "binomial",nfolds = 10,type.measure = "deviance",parallel = TRUE,)
fit <- glmnet(x = Train_independent_set_vvvv,y = Train_Target_set,alpha = 1,family = "binomial",lambda =fit_CV$lambda.1se )
 # coef(fit)
 # fit_CV$lambda.1se
pred <- predict(fit,s='lambda.min',newx = Train_independent_set_vvvv, type = "response")
score_train <- data.frame(Train_Target_set,pred)
write.csv(score_train,"score_train_Lasso_VVVV.csv")

pred_t <- predict(fit,s='lambda.min',newx = Test_independent_set_vvvv, type = "response")
score_test <- data.frame(Test_Target_set,pred_t)
write.csv(score_test,"score_test_Lasso_VVVV.csv")

X <- as.matrix(Train_independent_set_vvvv)
w <- as.matrix(coef(fit))
keep_x <- rownames(w)[w!=0]
keep_x <- keep_x[!keep_x=="(Intercept)"]
X <- X[,keep_x]
# sapply(X,class)
# class(Train_data$Checking_Attrition_Flag)
Lm.model <- glm(Checking_Attrition_Flag~Sum_transaction_count_savings_Staticpool
                +AVG_Deposited_count_Total_Deposit_ACCT
                +Avg_Month_end_balance_Checkings_Staticpool
                +MAX_MOB_Total_Deposit_ACCT
                +Sum_LASTDIVAMOUNT_Checkings_Staticpool,data = Train_data_v)
summary(Lm.model)
library(car)
Anova(Lm.model, type="II", test="Wald")
vif(Lm.model)
alias.result <- alias(Lm.model)

#*********////// VISULIZATION \\\\\\\\*****************
Train_data$Checking_Attrition_Flag
Dataframe_new2_v <- Train_data[,c("Parentaccount","Checking_Attrition_Flag"
                                  ,"sum_COURTESYPAYMONTHTODATE_checkings_Q2"
                                  ,"sum_OVERDRAFTFEEYTD_checkings_Q2"
                                  ,"AVG_withdrawal_count_Total_Deposit_ACCT"
                                  ,"AVG_Transaction_COUNT_Total_Deposit_ACCT"
                                  ,"SUM_Transaction_COUNT_Total_Deposit_ACCT"
                                  ,"SUM_withdrawal_count_Total_Deposit_ACCT"
                                  ,"Avg_Month_end_balance_Checkings_Staticpool"
                                  ,"MOB_Checkings"
                                  ,"Sum_LASTDIVAMOUNT_Checkings_Q1"
                                  ,"MAX_MOB_Total_Deposit_ACCT"
                                  ,"Sum_transaction_count_savings_Staticpool"
                                  ,"avg_Deposited_count_Checkings_Q2"
                                  ,"Sum_LASTDIVAMOUNT_Checkings_Staticpool"
                                  ,"SUM_Deposited_count_Total_Deposit_ACCT"
                                  ,"AVG_Deposited_count_Total_Deposit_ACCT")]

write.csv(Dataframe_new2_v,"Dataframe_new2_v.csv")
library(dplyr)
Decile_Function <- function(data)
{  
  a<- data.frame()
  Decile<- data.frame()
  
  for (i in 1:ncol(data))
  {
    a <- colnames(data)[i]
    Decile <- data[,c(i)]<- ntile(data[,c(i)],10)
   
   Final <- cbind(a,Decile)
  }
  write.csv(Final,"Final Summary.csv")
}
Decile_Function(Train_data_v)


Dataframe_new2_v$Decile <- ntile(Dataframe_new2_v$sum_COURTESYPAYMONTHTODATE_checkings_Q2,10)
Dataframe_new2_v$Decile1 <- ntile(Dataframe_new2_v$sum_OVERDRAFTFEEYTD_checkings_Q2,10)
Dataframe_new2_v$Decile2 <- ntile(Dataframe_new2_v$AVG_withdrawal_count_Total_Deposit_ACCT,10)
Dataframe_new2_v$Decile3 <- ntile(Dataframe_new2_v$AVG_Transaction_COUNT_Total_Deposit_ACCT,10)
Dataframe_new2_v$Decile4 <- ntile(Dataframe_new2_v$SUM_Transaction_COUNT_Total_Deposit_ACCT,10)
Dataframe_new2_v$Decile5 <- ntile(Dataframe_new2_v$SUM_withdrawal_count_Total_Deposit_ACCT,10)
Dataframe_new2_v$Decile6 <- ntile(Dataframe_new2_v$Avg_Month_end_balance_Checkings_Staticpool,10)
Dataframe_new2_v$Decile7 <- ntile(Dataframe_new2_v$MOB_Checkings,10)
Dataframe_new2_v$Decile8 <- ntile(Dataframe_new2_v$Sum_LASTDIVAMOUNT_Checkings_Q1,10)
Dataframe_new2_v$Decile9 <- ntile(Dataframe_new2_v$MAX_MOB_Total_Deposit_ACCT,10)
Dataframe_new2_v$Decile10 <- ntile(Dataframe_new2_v$Sum_transaction_count_savings_Staticpool,10)
Dataframe_new2_v$Decile11 <- ntile(Dataframe_new2_v$avg_Deposited_count_Checkings_Q2,10)
Dataframe_new2_v$Decile12 <- ntile(Dataframe_new2_v$Sum_LASTDIVAMOUNT_Checkings_Staticpool,10)
Dataframe_new2_v$Decile13 <- ntile(Dataframe_new2_v$SUM_Deposited_count_Total_Deposit_ACCT,10)
Dataframe_new2_v$Decile14 <- ntile(Dataframe_new2_v$AVG_Deposited_count_Total_Deposit_ACCT,10)


library(dplyr)
stats <- Dataframe_new2_v %>% group_by(Decile15) %>%
  summarise(Total_obsv = length(Parentaccount[!is.na(Parentaccount)])
    ,avg_var = mean(sum_COURTESYPAYMONTHTODATE_checkings_Q2_Decile,na.rm = TRUE)
            ,Max_var = max(sum_COURTESYPAYMONTHTODATE_checkings_Q2_Decile,na.rm = TRUE)
            ,Min_var = min(sum_COURTESYPAYMONTHTODATE_checkings_Q2_Decile,na.rm = TRUE)
    ,total_event = sum(Checking_Attrition_Flag,na.rm = TRUE)
    ,event_rate = sum(Checking_Attrition_Flag,na.rm = TRUE)/length(Parentaccount[!is.na(Parentaccount)])
    )


library(ggplot2)
ggplot(stats,aes(x=avg_var,y=event_rate,color=(avg_var))) +
  geom_line() + labs(title = "Event vs sum_COURTESYPAYMONTHTODATE_checkings_Q2_Decile", x="",y="Event rate") 
theme(axis.text = element_text(angle = 60,vjust = 1,hjust = 1),
      panel.background = element_rect(fill = "gray97",colour = "black"),
      axis.text= element_text(size = 11),
      axis.title = element_text(size = 13),
      plot.title = element_text(hjust = 0.5))


select 
	'select '''+COLUMN_NAME+''' AS CNAME,
	CAST((SELECT CAST(COUNT([SSN003]) AS decimal(18,4)) FROM ['+TABLE_NAME+'] WHERE ['+COLUMN_NAME+'] IS NULL)/CAST(COUNT([SSN003])AS decimal(18,4) ) AS decimal(6,2)) * 100 AS NULLPERCNT,
	(SELECT COUNT([SSN003]) FROM ['+TABLE_NAME+'] WHERE ['+COLUMN_NAME+'] IS NULL) AS NULLS,
	COUNT([SSN003]) AS ALLREC
	FROM ['+TABLE_NAME+'] UNION'
from INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'Member_Attrition_MOdel_0801' 



select
'select count([' + COLUMN_NAME+ '] )
from  ['+TABLE_NAME+'] union '
from INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'REVISED_MASTER_DATA_March_2023_Updated'

/*** master data blank ****/
select 
'select '''+COLUMN_NAME+''' AS CNAME,cast(cast(sum(case when [' + COLUMN_NAME+ '] = 0 then 1 else 0 end ) as decimal(18,2))/cast(COUNT(1)aS decimal(18,2)) as decimal(18,2))*100 AS ZERO_PER 
from  ['+TABLE_NAME+'] union ' 
from INFORMATION_SCHEMA.COLUMNS
where TABLE_NAME = 'REVISED_MASTER_DATA_March_2023'
and DATA_TYPE in ('decimal'
,'int'
,'money'
,'numeric'
,'smallint')



select 
'
SELECT 
	Iv.TABLE_SCHEMA,
    t.NAME AS TableName,    
    p.rows AS RowCounts,
    CONVERT(DECIMAL,SUM(a.total_pages)) * 8 / 1024  AS TotalSpaceMB, 
    SUM(a.used_pages)  * 8 / 1024 AS UsedSpaceGB , 
    (SUM(a.total_pages) - SUM(a.used_pages)) * 8 / 1024  AS UnusedSpaceMB
FROM 
    sys.tables t
INNER JOIN      
    sys.indexes i ON t.OBJECT_ID = i.object_id
INNER JOIN 
    sys.partitions p ON i.object_id = p.OBJECT_ID AND i.index_id = p.index_id
INNER JOIN 
    sys.allocation_units a ON p.partition_id = a.container_id
LEFT OUTER JOIN 
    sys.schemas s ON t.schema_id = s.schema_id
INNER JOIN INFORMATION_SCHEMA.TABLES as Iv
on t.name = Iv.TABLE_NAME

WHERE 
    t.NAME ='''+table_name+'''
    AND t.is_ms_shipped = 0
    AND i.OBJECT_ID > 255 
GROUP BY 
    Iv.TABLE_SCHEMA,t.Name, s.Name, p.Rows
union

'
from INFORMATION_SCHEMA.TABLES
where TABLE_NAME not like '%''%'


SELECT 
	Iv.TABLE_SCHEMA,
    t.NAME AS TableName,    
    p.rows AS RowCounts,
    CONVERT(DECIMAL,SUM(a.total_pages)) * 8 / 1024  AS TotalSpaceMB, 
    SUM(a.used_pages)  * 8 / 1024 AS UsedSpaceGB , 
    (SUM(a.total_pages) - SUM(a.used_pages)) * 8 / 1024  AS UnusedSpaceMB
FROM 
    sys.tables t
INNER JOIN      
    sys.indexes i ON t.OBJECT_ID = i.object_id
INNER JOIN 
    sys.partitions p ON i.object_id = p.OBJECT_ID AND i.index_id = p.index_id
INNER JOIN 
    sys.allocation_units a ON p.partition_id = a.container_id
LEFT OUTER JOIN 
    sys.schemas s ON t.schema_id = s.schema_id
INNER JOIN INFORMATION_SCHEMA.TABLES as Iv
on t.name = Iv.TABLE_NAME

WHERE 
    t.NAME ='''+table_name+'''
    AND t.is_ms_shipped = 0
    AND i.OBJECT_ID > 255 
GROUP BY 
    Iv.TABLE_SCHEMA,t.Name, s.Name, p.Rows


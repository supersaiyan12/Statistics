select 'select * into [BureauData].[' + table_schema + '].['+table_name+'_tested] from [BureauData].[' + table_schema + '].[' + table_name + ']'
from BureauData.INFORMATION_SCHEMA.TABLES	

select * into [BureauData].[stg].[TransUnionMonthlyExtract_tested] from [BureauData].[stg].[TransUnionMonthlyExtract]
select * into [BureauData].[stg].[TransUnionBaseAttributeReturn_tested] from [BureauData].[stg].[TransUnionBaseAttributeReturn]
select * into [BureauData].[dbo].[TransUnionAttributeHistory_tested] from [BureauData].[dbo].[TransUnionAttributeHistory]
select * into [BureauData].[stg].[TransUnionAttributeHistory_tested] from [BureauData].[stg].[TransUnionAttributeHistory]
select * into [BureauData].[dbo].[TransUnionAttributeDefinitions_tested] from [BureauData].[dbo].[TransUnionAttributeDefinitions]


select 'select * from '+ TABLE_NAME+'_Tested' from INFORMATION_SCHEMA.TABLES

select 'select * from ' + TABLE_CATALOG +'.'+TABLE_SCHEMA+'.'+TABLE_NAME--  *--'select * from ' +TABLE_NAME 
from INFORMATION_SCHEMA.TABLES

select * from BureauData.stg.TransUnionMonthlyExtract
select * from BureauData.stg.TransUnionBaseAttributeReturn
select * from BureauData.dbo.TransUnionAttributeHistory
select * from BureauData.stg.TransUnionAttributeHistory
select * from BureauData.dbo.TransUnionAttributeDefinitions


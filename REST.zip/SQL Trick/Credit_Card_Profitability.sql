-- Create the temporary table
CREATE TABLE #temp (
    MonthYear INT,
    COF DECIMAL(5, 2)
);

-- Insert values into the temporary table with YYYYMM format
INSERT INTO #temp (MonthYear, COF) VALUES
(202301, 2.23),
(202302, 2.46),
(202303, 2.32),
(202304, 2.52),
(202305, 2.71),
(202306, 2.72),
(202307, 2.78),
(202308, 2.94),
(202309, 3.02),
(202310, 3.12),
(202311, 3.21),
(202312, 3.28),
(202401, 3.32),
(202402, 3.39),
(202403, 3.40),
(202404, 3.36),
(202405, 3.38),
(202406, 3.39),
(202407, 3.09);

-- Select the values to verify the insertion
SELECT * FROM #temp;



drop table if exists #test
select extract_datepart,
	--43416.33 as incentive,
	case when left(extract_datepart,4) = 2023 then 43416.66 when left(extract_datepart,4) = 2024 then 23533.33 end as incentive,
	count(*) as N_cards,
	sum([Last Statement Balance Amount]) as Balance,
	sum(RevolvingBalance) as Rev_Bal,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as spend,
	sum([Protected_Current_Interest]+[Promo_Current_Interest]
	+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income,

	sum([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]
	+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] 
	  +[Dynamic Interest Fees Charges Statement Year To Date]) as fees,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income,    
	(sum([Last Statement Balance Amount]*cc.COF)/100)/12 as COF, -- added 0.0309 instead of 0.02 as COF (0.02/12)
	sum(ChargeoffAmount_final) as chgoff_amt,
	sum(case when [Card Description] in ('MasterCard Platinum Rewards','MasterCard World Credit','MasterCard Merchant Platinum') 
	then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end) as rewards_expense,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense,
	sum(case when TRIPFLAG = 'I' then 0.9 else 2.75 end) as processing_cost
	into #test
	from [TMGData].[dbo].[cardholder] a
	left join [Analytics].[brijesh].[CC_Origination_FICO_03262024] b
	on a.[Durable_Key] = b.TMGDurableKey
	left join #temp cc
	on a.extract_datepart=cc.MonthYear
	where Active_Flag = 1 and extract_datepart between 202301 and 202405
	and [External Status Code] not in('C')
	group by extract_datepart
	order by 1 

	select * from #test order by 1

	select 
	extract_datepart,
	N_cards,
	 interchange_income+fees+Interest_Income as Revenue,
	 incentive+COF+	chgoff_amt	+rewards_expense+	visa_expense+	processing_cost as Cost ,
	 ( interchange_income+fees+Interest_Income)- (incentive+COF+	chgoff_amt	+rewards_expense+	visa_expense+	processing_cost ) as profit,
	cast( (( interchange_income+fees+Interest_Income)- (incentive+COF+	chgoff_amt	+rewards_expense+	visa_expense+	processing_cost )) /N_cards as decimal(18,2)) as Per_card_Profit
	from #test
	order by 1

declare @startdate as date
declare @currentdate as date
declare @eomonth as date
declare @lastdate as date
declare @enddate as date

set @startdate = '2018-05-31'
set @currentdate = getdate()
set @eomonth = EOMONTH(@currentdate)
set @lastdate = eomonth(dateadd(month,-1,getdate()))

if @currentdate = @eomonth 
	 set @enddate = @currentdate;
	 else 
	 set @enddate = @lastdate;
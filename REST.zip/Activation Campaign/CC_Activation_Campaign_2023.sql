--==================================================== 2023 Home Improvement - Risk exclusions ====================================================
--=====================================================================================================================================================

--**********************
--|| STATIC POOL DATA ||
--**********************
---------------------------------------
	DROP TABLE IF EXISTS #temp1
	SELECT 
		Durable_Key	,[Master Account Key]	,[Social Security Number]
		,[Credit Limit] 	,mob	,[Card Description]
		,[External Status Code]	,[Internal Status Code]
		,[Last Statement Balance Amount]	,RevolvingBalance	,age
		,([Last Statement Sale Amount]-[Last Statement Return Amount]) as spend
		,TRIPFLAG	,[Last Statement Payment Amount]
		,Extract_DatePart as sp_month	,[Account System Entry Date]	,[Account Number]
		,[Credit Limit] - [Last Statement Balance Amount] as OpenToBuy
		,case when TRIPFLAG = 'T' then 1 else 0 end as TransactorFlag
	INTO #temp1
	FROM [TMGData].[dbo].[cardholder] 
	where 
	[Active_flag] = 1 
	and Extract_DatePart = 202303
	and [External Status Code] not in ('C','Z')

	and [Card Description] in ('MasterCard Platinum','Mastercard Black & Gold','MasterCard Platinum Rewards','MasterCard World Credit') 
	and [Agent Bank] = '0000' and [Prin Bank] <> '7000'

	go

--***********************************
-- || STEP 1: PRE 12 MONTH NUMBERS ||
--***********************************
	Drop table if exists #temp_pre_12mo_2
	select 
		Durable_Key as d_pre_12mo
		,sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_12mo
		,sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_12mo
		,sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_12mo
		,sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_12mo
		,sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_12mo
		,sum([Last Statement Balance Amount]) as sum_bal_pre_12mo
		,sum(RevolvingBalance) as sum_revbal_pre_12mo
		,sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_12mo
		,avg([Last Statement Balance Amount]) as avg_bal_pre_12mo
		,avg(RevolvingBalance) as avg_revbal_pre_12mo
		,avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_12mo

	into #temp_pre_12mo_2
	from [TMGData].[dbo].[cardholder]

		where [Active_flag] = 1 
		and Extract_DatePart between 202303 - 99 and 202303
		and Durable_Key in (select Durable_Key from #temp1)
		group by Durable_Key

go


--******************************************
-- || STEP 2: PRE 12 MONTH PROFIT NUMBERS ||
--******************************************
Drop table if exists #temp_pre_12mo_3
select 
	Durable_Key
	,Extract_DatePart
	,case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization
	,case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate
	,case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate

	,([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income
	,([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees
	,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income    
	,([Last Statement Balance Amount]*0.02/12) as COF
	,(ChargeoffAmount_final) as chgoff_amt
	,case when [Card Description] in ('Mastercard Platinum Rewards','Mastercard World Credit') 
	then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.01 else 0 end as rewards_expense -- verify it with internal team
	,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense
	,case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost
	into #temp_pre_12mo_3
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and Extract_DatePart between 202303 - 99 and 202303
	and Durable_Key in 
	(select Durable_Key from #temp1)

--**************************************************
-- || STEP 3: PRE 12 MONTH PROFIT NUMBERS SUMMARY ||
--**************************************************
Drop table if exists #temp_pre_12mo_3a
select 
	Durable_Key
	,count(*) as N_months
	,sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit
	,avg(Utilization) as avg_Utilization
	,avg(revolve_rate) as avg_revolve_rate
	,avg(payment_rate) as avg_payment_rate

into #temp_pre_12mo_3a
from #temp_pre_12mo_3
group by Durable_Key
	
go

Drop table if exists #temp_pre_12mo_4
select 
	a.*
	,b.profit as sum_profit_pre_12mo,b.profit/b.N_months as avg_profit_pre_12mo
	,b.avg_Utilization as avg_Utilization_pre_12mo
	,b.avg_revolve_rate as avg_revolve_rate_pre_12mo
	,b.avg_payment_rate as avg_payment_rate_pre_12mo

into #temp_pre_12mo_4
from #temp_pre_12mo_2 a
left join #temp_pre_12mo_3a b
on a.d_pre_12mo = b.Durable_Key



--*********************************
-- || STEP 4: PRE 6 MONTH NUMBERS||
--*********************************
	Drop table if exists #temp_pre_6mo_2
	select Durable_Key  as d_pre_6mo,
		sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_6mo,
		sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_6mo,
		sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_6mo,
		sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_6mo,
		sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_6mo,
		sum([Last Statement Balance Amount]) as sum_bal_pre_6mo,
		sum(RevolvingBalance) as sum_revbal_pre_6mo,
		sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_6mo,
		avg([Last Statement Balance Amount]) as avg_bal_pre_6mo,
		avg(RevolvingBalance) as avg_revbal_pre_6mo,
		avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_6mo
	
		into #temp_pre_6mo_2
		from [TMGData].[dbo].[cardholder]
		where [Active_flag] = 1 
		--and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
		and Extract_DatePart between  202210 and 202303
		and Durable_Key in 
		(select Durable_Key from #temp1)
		group by Durable_Key


	--******************************************
	-- || STEP 5: PRE 6 MONTH PROFIT NUMBERS ||
	--******************************************
	Drop table if exists  #temp_pre_6mo_3
	select 
		Durable_Key
		,Extract_DatePart
		,case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization
		,case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate
		,case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate

		,([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income
		,([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
		  +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
		  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees
		,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income   
		,([Last Statement Balance Amount]*0.02/12) as COF
		,(ChargeoffAmount_final) as chgoff_amt
		,case when [Card Description] in ('Mastercard Platinum Rewards','Mastercard World Credit') 
		then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.01 else 0 end as rewards_expense -- verify
		,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense
		,case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost

	into #temp_pre_6mo_3
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	--and [Card Description] not in ('Mastercard Business','MasterCard Black & Gold','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and Extract_DatePart between 202210 and 202303
	and Durable_Key in 
	(select Durable_Key from #temp1)


	--*************************************************
	-- || STEP 6: PRE 6 MONTH PROFIT NUMBERS SUMMARY ||
	--*************************************************
	Drop table if exists #temp_pre_6mo_3a
	select 
		Durable_Key
		,count(*) as N_months
		,sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit
		,avg(Utilization) as avg_Utilization,avg(revolve_rate) as avg_revolve_rate,avg(payment_rate) as avg_payment_rate

	into #temp_pre_6mo_3a
	from #temp_pre_6mo_3
	group by Durable_Key


	--***************************************************
	-- || STEP 7: DATA GETHERING OF DATA BUILDED ABOVE ||
	--***************************************************
	Drop table if exists #temp_pre_6mo_3b
	select a.*,
		b.profit as sum_profit_pre_6mo,b.profit/b.N_months as avg_profit_pre_6mo
		,b.avg_Utilization as avg_Utilization_pre_6mo
		,b.avg_revolve_rate as avg_revolve_rate_pre_6mo
		,b.avg_payment_rate as avg_payment_rate_pre_6mo

	into #temp_pre_6mo_3b
	from #temp_pre_6mo_2 a
	left join #temp_pre_6mo_3a b
	on a.d_pre_6mo = b.Durable_Key

go

--********************************
-- || STEP 08 : BUREAU DATA PULL ||
--********************************
	Drop table if exists #temp4a
	select 
		a.SSN
		,case when b.creditscore is not null then b.creditscore else a.FICO end as FICO_Score
		,case when [CCTotalAvailableLOC] = 0 then 0 else [CCOpenBalance]/[CCTotalAvailableLOC] end as Debt_Burden
		,[NumberInquiriesP6Months] as N_Inquiries_in_past_6month
		,[CCOpenBalance] as Bureau_Balance
		--,left(INCOME,3)*1000 as Annual_Income
		--,left(INCOME,3)*1000/12 as Monthly_Income
		,[BankruptcyCount] as N_accts_bankruptcies
		,[ChargeOffTradeCountP12Months] as N_chgoff_Trades_in_past_12months
		,[ForeclosureCountP12Months] as N_foreclousres_in_past_12months
		,[CCWorstRatingP12Months] as CC_worst_rating_in_past_12months
	into #temp4a
	from [BureauData].[dbo].[TransUnionAttributeHistory] a
	left join UICCU.dbo.transuniondata b
	on a.SSN = b.SSN
	where date in (select  max(date) from [BureauData].[dbo].[TransUnionAttributeHistory])
	and a.SSN in (select  distinct [Social Security Number] from #temp1)
	and b.ProcessDate = '20230331'


go

--Drop table if exists #temp4
--select 
--a.*
--,b.Worst_Rating_on_CC_Trades_in_Past_12_Months

--into #temp4
--from #temp4a a left join #temp4b b
--on a.SSN = b.customerInput_socSecurityNum0007


--**********************************
-- || STEP 09 : COMBINING ALL DATA ||
--**********************************
Drop table if exists #temp2
select a.*,b.*,c.*,d.*,f.[bFinscr]
	,(avg_Utilization_pre_6mo-avg_Utilization_pre_12mo) / case when avg_Utilization_pre_12mo =0 then 1 else avg_Utilization_pre_12mo end as Util_Drift
	,case when(avg_Utilization_pre_12mo > 0.75) then 1 else 0 end as Exclu_AvgUtilPre12Months
	,case when((avg_Utilization_pre_12mo between 0.50 and 0.75)  and (avg_Utilization_pre_6mo-avg_Utilization_pre_12mo) / 
	case when avg_Utilization_pre_12mo =0 then 1 else avg_Utilization_pre_12mo end > 0.25) then 1 else 0 end as Exclu_Utili2

	--, case when (case when(avg_Utilization_pre_12mo >0.75) then 1 else 0 end =1 OR 
	--	case when((avg_Utilization_pre_6mo between 0.50 and 0.75)  and (avg_Utilization_pre_6mo-avg_Utilization_pre_12mo) / 
	--	case when avg_Utilization_pre_12mo =0 then 1 else avg_Utilization_pre_12mo end > 0.25) then 1 else 0 end =1) then 1 else 0 end as Exclu_FinalUtil
	
	,case when (d.FICO_score-f.[bFinscr] < -50) then 1 else 0 end as Exc_FicoDropped50Pts
	,case when (d.FICO_score between  660 and 689) and ((d.FICO_score-f.[bFinscr]) < -25) then 1 else 0 end as Exc_Fico2

	--,case when(case when(d.FICO_score-f.Score_1 > 50) then 1 else 0 end =1 OR	
	--	case when((d.FICO_score between  660 and 689) and (d.FICO_score-f.Score_1) > 25) then 1 else 0 end =1) then 1 else 0 end as Exclu_FicoDrop

	into #temp2
	from #temp1 a
	left join #temp_pre_12mo_4 b
	on a.Durable_Key = b.d_pre_12mo
	left join #temp_pre_6mo_3b c
	on a.Durable_Key = c.d_pre_6mo
	left join #temp4a d
	on a.[Social Security Number] = d.SSN
	left join [Analytics].[dbo].[Bureaudata_042022]  f
	on a.[Social Security Number] = f.SSN

	--select SSN,FICO_Score,Score_1,Exc_FicoDropped50Pts,Exc_Fico2 from #temp2

	Drop table if exists #long_term_Inactives
	select 
		Durable_Key 
		,sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_24mo
	into #long_term_Inactives
	from [TMGData].[dbo].[cardholder]

		where [Active_flag] = 1 
		and Extract_DatePart between 202303 - 199 and 202303
		and Durable_Key in (select Durable_Key from #temp1)
		group by Durable_Key
		--select Durable_Key from #long_term_Inactives where sum_spend_pre_24mo = 0

	 go

	Drop table if exists #less_active
	select Durable_Key
	into #less_active
	from #temp2
	where
	mob > 11 and TRIPFLAG <> 'I'
	and (
		case 
		when (sum_spend_pre_12mo - sum_spend_pre_6mo) <= 0 then 0 
		when (sum_spend_pre_12mo - sum_spend_pre_6mo) = 0 and sum_spend_pre_6mo < 0 then 1
		else ((sum_spend_pre_12mo - sum_spend_pre_6mo) - sum_spend_pre_6mo)/(sum_spend_pre_12mo - sum_spend_pre_6mo) end
		) > 0.8


	 --select top 10 DEBT_BURDEN from #temp2
	select  count(*)
	from #temp2
	where [External Status Code] in ('') and [Internal Status Code] in ('','N')
		and mob > 5
		and Durable_Key in
		(
			(select Durable_Key from #temp2 where TRIPFLAG = 'I')
			union
			(select Durable_Key from #less_active)
			union
			(select Durable_Key from #temp2 where TRIPFLAG <> 'I' and mob >= 5 and sum_spend_pre_6mo <= 300)
			union
			(select Durable_Key from #temp2 where TRIPFLAG <> 'I' and mob >= 11 and sum_spend_pre_12mo <= 500)
		)
		and Durable_Key not in 
		(select Durable_Key from #temp2 where avg_spend_pre_6mo > 200)
		and Durable_Key not in 
		(select Durable_Key from #long_term_Inactives where sum_spend_pre_24mo = 0)
		and (N_accts_bankruptcies = 0 or N_accts_bankruptcies is null)
		AND Times_1_cycle_delq_pre_6mo <2
		and Times_2_cycle_delq_pre_6mo <1
		and Times_overlimit_pre_6mo <2
		and Times_cash_Advances_pre_6mo <2
		and avg_Utilization_pre_12mo <= 0.75

		and (FICO_score> 700) --or FICO_Score is null)
		and Exc_FicoDropped50Pts=0
		and Exc_Fico2 = 0
		AND (Bureau_Balance<=30000) --or Bureau_Balance is null)
		AND (DEBT_BURDEN<=0.75) --or Debt_Burden is null)
		and isnull(N_Inquiries_in_past_6month,0) < 3
		and isnull(CC_worst_rating_in_past_12months,0) < 3
		and isnull(N_chgoff_Trades_in_past_12months,0) < 1
		and isnull(N_foreclousres_in_past_12months,0) < 1
		and AGE > 21

	go

	Drop table if exists #Activation_Campaign
	SELECT *
	into #Activation_Campaign
	FROM #temp2
	where [External Status Code] in ('') and [Internal Status Code] in ('','N')
		and mob > 5
		and Durable_Key in
		(
			(select Durable_Key from #temp2 where TRIPFLAG = 'I')
			union
			(select Durable_Key from #less_active)
			union
			(select Durable_Key from #temp2 where TRIPFLAG <> 'I' and mob >= 5 and sum_spend_pre_6mo <= 300)
			union
			(select Durable_Key from #temp2 where TRIPFLAG <> 'I' and mob >= 11 and sum_spend_pre_12mo <= 500)
		)
		and Durable_Key not in 
		(select Durable_Key from #temp2 where avg_spend_pre_6mo > 200)
		and Durable_Key not in 
		(select Durable_Key from #long_term_Inactives where sum_spend_pre_24mo = 0)
		and (N_accts_bankruptcies = 0 or N_accts_bankruptcies is null)
		AND Times_1_cycle_delq_pre_6mo <2
		and Times_2_cycle_delq_pre_6mo <1
		and Times_overlimit_pre_6mo <2
		and Times_cash_Advances_pre_6mo <2
		and avg_Utilization_pre_12mo <= 0.75

		and (FICO_score> 700) --or FICO_Score is null)
		and Exc_FicoDropped50Pts=0
		and Exc_Fico2 = 0
		AND (Bureau_Balance<=30000) --or Bureau_Balance is null)
		AND (DEBT_BURDEN<=0.75) --or Debt_Burden is null)
		and isnull(N_Inquiries_in_past_6month,0) < 3
		and isnull(CC_worst_rating_in_past_12months,0) < 3
		and isnull(N_chgoff_Trades_in_past_12months,0) < 1
		and isnull(N_foreclousres_in_past_12months,0) < 1
		and AGE > 21

	--select * from #Activation_Campaign
	go


	DROP TABLE IF EXISTS #listdata 
	select  distinct cc.PARENTACCOUNT,ExternalStatus_UserChar8,InternalStatus_UserChar9
	,tmgdurablekey_userchar10
		 ,cc.CardNumber_UserChar1
		,cc.CurrentBalance_UserAmount1
		,cc.ProcessDate
		, datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Process_Date
	   into #listdata               
		FROM arcusym000.tracking.tvwARCUTRACKINGCreditCard cc
	where
	  ProcessDate in (select max(processdate) from arcusym000.tracking.tvwARCUTRACKINGCreditCard)   --(cc.ProcessDate='20221011') 
		AND cc.ExpireDate IS NULL

		--select * from #listdata 


	--**********************
	--|| MEMBER DATA PULL ||
	--**********************
	Drop table if exists #Member
	Select 
	distinct 
	ssn
	,first
	,last

	into #member
	From 
		(select
		*
		,ROW_NUMBER() Over(Partition by ssn order by lastfmdate desc,recordchangedate desc) as rank
		from ARCUSYM000..NAME
		where ProcessDate = '20230411'
		and SSN in (select distinct [Social Security Number] from #Activation_Campaign)
		and FIRST is not null
		and LAST is not null
		and city is not null
		and STATE is not null
		and ZIPCODE is not null
		and type = 0  and EXPIRATIONDATE is null and DEATHDATE is null) a
	where rank =1
	--select * from #member
	go
	--===== MAILING ADDESS
	--====================
	Drop table if exists #Mailing
	Select 
	*
	into #Mailing
	from 
	(Select 
	distinct SSN,
			Street as [Address 1],ExtraAddress as [Address 2],City,State,ZipCode,
			namemailflag,MailingOnly,EStatementsEnabled,AddressTypeDescription
			,ROW_NUMBER() Over(Partition by ssn order by EStatementsEnabled desc,namemailflag desc) as rank
	from UICCU.bi.vwMailingAddressCurrent
	where ssn in (select distinct [Social Security Number]  from #Activation_Campaign)
	and  NameType = 'PRIMARY'
			and ParentAccount in 
			(select distinct ParentAccount 		from ARCUSYM000..NAME	
			where ProcessDate = 20230411 and ADDRESSTYPE = 0 
			and SSN is not null and EXPIRATIONDATE is null and DEATHDATE is null and type = 0 
			and SSN in (select distinct  [Social Security Number] from #Activation_Campaign))
			and addressTypeDescription = 'Domestic Address') a
	where rank=1
	--select count(*) from #Activation_Campaign where [Social Security Number] is null
	--select count(*),count(distinct durable_key) from #Activation_Campaign
	--select * from #Mailing
	
	--===== joining member & mailing data to main
	--===========================================
	Drop table if exists #Master
	Select 
	distinct 
	a.*
	,b.FIRST,b.LAST
	,c.[Address 1],c.[Address 2],c.AddressTypeDescription,c.City,c.EStatementsEnabled,c.MailingOnly
	,c.NameMailFlag,c.STATE,c.ZipCode

	into #Master
	from #Activation_Campaign a
	left join #member b 
	on a.[Social Security Number]=b.SSN
	left join #Mailing c 
	on a.[Social Security Number] = c.ssn

	--select * from #master 
	--where first is not null and AddressTypeDescription = 'Domestic Address'

	go


	drop table if exists #Activation_Campaign_list
	select distinct
	 a.Durable_Key, a.[Social Security Number],a.[Account Number],
	 a.[card Description],
	 ---d.segment,
	 '06/01/2023' as Campaign_start_Date,
	 '07/31/2023' as Campaign_End_Date,
		case 
		when a.[card Description] in ('Mastercard World Credit','Mastercard Platinum Rewards')
		then '4X additional rewards on all spending'
		when a.[card Description] in ('Mastercard Platinum','Mastercard Black & Gold')
		then '4% lower rate for 9 months on all spending'
		else 'Others' end as offer,
		a.[Credit Limit],a.avg_profit_pre_12mo,a.sum_spend_pre_6mo,a.avg_spend_pre_12mo,a.[Account System Entry Date],
		a.[Master Account Key],
		c.ExternalStatus_UserChar8 as [External Status Code],c.InternalStatus_UserChar9  as [Internal Status Code],
		a.mob,a.[Last Statement Balance Amount],a.RevolvingBalance,a.spend,a.TRIPFLAG,a.[Last Statement Payment Amount],
		a.FICO_Score,a.Bureau_Balance,a.Debt_Burden,a.AGE,
		b.FIRST as [FIRST NAME],b.LAST as [LAST NAME],b.City,b.ZipCode,b.STATE,b.[Address 1] as Street,
		MailingOnly,EStatementsEnabled,AddressTypeDescription
	into #Activation_Campaign_list
	from #Activation_Campaign a
	left join #Master b
	on a.Durable_Key = b.Durable_Key
	left join #listdata c
	on a.[Account Number] = c.CardNumber_UserChar1

	--select distinct [External Status Code] from #Activation_Campaign_list
		go

		drop table if exists  #multiple_entries
		Select Durable_Key,count(*) as cnt
		into #multiple_entries
		from #Activation_Campaign_list
		group by Durable_Key
		having count(*) > 1

		go
		drop table if exists  #multiple_durablekeys
		Select *,
		ROW_NUMBER() Over(Partition by Durable_Key order by Durable_Key) as rank
		into #multiple_durablekeys
		from #Activation_Campaign_list
		   where Durable_Key in (select Durable_Key from #multiple_entries)

		go

		 --exclusion 1 - Bad address--------------------------
	  declare @Processdate int = '20230411'

	 -- go

	  drop table if  exists #BADADDRESS
	 select  *
	 into #BADADDRESS
	  from  arcusym000.dbo.ufnanywarningaccount(@ProcessDate,13)
	  --select * from #BADADDRESS
	
	go

	  drop table if exists #membershavingmorethan1card
	  select  distinct [Durable_Key],[Social Security Number],[Card Description],offer  
	  into #membershavingmorethan1card 
	  from #Activation_Campaign_list
	  where  [Social Security Number] in (select  [Social Security Number] from #Activation_Campaign_list    
	  group by [Social Security Number] 
	  having count([Card Description])>1) order by [Card Description]
	

	
	
	drop table if exists #membershaving1card
	  select  distinct [Durable_Key],[Social Security Number],[Card Description],offer  
	  into #membershaving1card 
	  from #Activation_Campaign_list    
	  where  [Social Security Number] in (select distinct [Social Security Number] from #Activation_Campaign_list        
	  group by [Social Security Number] 
	  having count([Card Description])=1) order by [Card Description]
	   
	   go

	   drop table if exists #tempz
		select * into #tempz 
		from  #membershavingmorethan1card 
		order by [Card Description]
		--select * from #tempz
		
		--card description
	 
	 drop table if exists #pivotcarddescription
	  select [Social Security Number],Card1,Card2,Card3
	  into #pivotcarddescription
	  from
		  (
			  select [Social Security Number],[Card Description],
			  'Card' + cast(row_number() over (partition by [Social Security Number] 
			  order by [Social Security Number],[Card Description]) as varchar(10)) ColumnSequence
			  from #tempz) temp
			  pivot
			  (max([Card Description])
			  for ColumnSequence in (Card1,Card2,Card3)
		  ) Piv
  

	  --segment
	  drop table if exists #pivotsegment
  
	   select [Social Security Number],Card1 offer1,Card2 offer2,Card3 offer3
	   into #pivotoffer
	  from
	  (
	  select [Social Security Number],offer,
	  'Card' + cast(row_number() over (partition by [Social Security Number] 
	  order by [Social Security Number],[Card Description]) as varchar(10)) ColumnSequence
	  from #tempz) temp
	  pivot
	  (max(offer)
	  for ColumnSequence in (Card1,Card2,Card3)
	  ) Piv


	  --durable key
  
	  drop table if exists #durablekey
  
	   select [Social Security Number],Card1 DurableKey1,Card2 DurableKey2,Card3 DurableKey3
	   into #durablekey
	  from
	  (
	  select [Social Security Number],Durable_Key,
	  'Card' + cast(row_number() over (partition by [Social Security Number] 
	  order by [Social Security Number],[Card Description]) as varchar(10)) ColumnSequence
	  from #tempz) temp
	  pivot
	  (max(Durable_Key)
	  for ColumnSequence in (Card1,Card2,Card3)
	  ) Piv


	  drop table if exists #multiplecards
	  select a.[Social Security Number], 
	  a.card1,convert(varchar(20),DurableKey1)   DurableKey1,
	  a.card2,convert(varchar(20),DurableKey2)   DurableKey2 ,
	  a.card3,convert(varchar(20),DurableKey3)   DurableKey3, 
	  c.offer1,c.offer2,c.offer3
	  into #multiplecards 
	  from #pivotcarddescription a
	  left join #durablekey b
	  on a.[Social Security Number]=b.[Social Security Number]
		left join #pivotoffer c
	  on a.[Social Security Number]=c.[Social Security Number]
      
	 --select * from #multiplecards where card3 is null
	  --select distinct segment3 from #multiplecards where card3 is not null
 
  
	  --multiplecardexclusion1 - members have more than1 card will  get offer on only 1 card
  

	  drop table if exists #cardexclusions
	  select 
	  case 
	  when card1='Mastercard Platinum Rewards' then DurableKey1
	  when card2='Mastercard Platinum Rewards' then DurableKey2
	  when card3='Mastercard Platinum Rewards' then DurableKey3
	
	  when card1='Mastercard World Credit' 
	  and card2 <> ('Mastercard Platinum Rewards') and card3 <> ('Mastercard Platinum Rewards') then DurableKey1
	  when Card2='Mastercard World Credit' 
	  and card1 <> ('Mastercard Platinum Rewards') and card3 <> ('Mastercard Platinum Rewards') then DurableKey2
	  when Card3='Mastercard World Credit' 
	  and card1 <> ('Mastercard Platinum Rewards') and card2 <> ('Mastercard Platinum Rewards') then DurableKey3
	   when card1='Mastercard World Credit' 
	  and card2 = ('Mastercard World Credit') and card3 is null then DurableKey2

	  when card1='Mastercard Platinum' 
	  and card2 not in ('Mastercard Platinum Rewards','Mastercard World Credit') 
	  and card3 not in ('Mastercard Platinum Rewards','Mastercard World Credit')  then DurableKey1
	  when card2='Mastercard Platinum' 
	  and card1 not in ('Mastercard Platinum Rewards','Mastercard World Credit') 
	  and card3 not in ('Mastercard Platinum Rewards','Mastercard World Credit')  then DurableKey2
	  when card3='Mastercard Platinum' 
	  and card1 not in ('Mastercard Platinum Rewards','Mastercard World Credit') 
	  and card2 not in ('Mastercard Platinum Rewards','Mastercard World Credit')  then DurableKey3
	  when card1='Mastercard Platinum' and card2 = 'Mastercard World Credit' and card3 is null  then DurableKey2
	  when card1='Mastercard Platinum' and card2 = 'Mastercard Platinum' and card3 is null  then DurableKey1
	  when card1='Mastercard Platinum' and card2 = 'Mastercard Platinum Rewards' and card3 is null  then DurableKey2

	  when card1='Mastercard Black & Gold' and card2='Mastercard Black & Gold' and card3='Mastercard Black & Gold'
	  then DurableKey1
	  when card1='Mastercard Black & Gold' and card2='Mastercard Black & Gold' and card3 is null
	  then DurableKey1
	 when card1='Mastercard Black & Gold' and card2='Mastercard Platinum' and card3 is null
	  then DurableKey2	
	  when card1='Mastercard Black & Gold' and card2='Mastercard World Credit' and card3 is null
	  then DurableKey2	
		else 'NA'
		end Priority, *
		into #cardexclusions 
		from #multiplecards
		--order by Priority desc

		go

		--select * from #cardexclusions where priority <> 'NA'
		drop table if exists #Exclude_multiple_cards
		select Durable_Key
		into #Exclude_multiple_cards
		from #membershavingmorethan1card
		where Durable_Key not in (select priority from #cardexclusions)
	
		go

		drop table if exists #temp11
		select parentaccount,count(*) as N_loan_relationship
		into #temp11
		from ARCUSYM000.dbo.loan
		where closedate is null and chargeoffdate is null
		and processdate = '20230411'
		and type in 
		(select loantype from ARCUSYM000.ARCU.ARCUloancategory
		where loancategory1  not in ('','Commercial')
		and loancategory4  not in ('Writeoff'))
		group by parentaccount

		go

		drop table if exists #temp12
		select parentaccount,count(*) as N_deposits_relationship
		into #temp12
		from ARCUSYM000.dbo.savings
		where closedate is null and chargeoffdate is null
		and processdate = '20230411'
		and type in 
		(select sharetype from ARCUSYM000.ARCU.ARCUsharecategory
		where sharecategory1 in ('Consumer','Non-Member')
		and sharecategory2 not in ('Savings'))
		group by parentaccount

		go

		drop table if exists #temp13
		SELECT [SSN],[OnlineBankingFlag]
		into #temp13
		FROM [Q2EVE].[dbo].[vwMemberOnlineBankingSummary]

		go

		--drop table if exists #relationships
		--select a.Durable_Key,a.[Social Security Number],c.parentaccount
		--,c.N_loan_relationship,d.N_deposits_relationship,e.[OnlineBankingFlag]
		--into #relationships
		--from #Activation_Campaign_list a
		--left join #listdata b
		--on a.[Account Number] = b.CardNumber_UserChar1
		--left join #temp11 c
		--on b.parentaccount = b.parentaccount
		--left join #temp12 d
		--on b.parentaccount = c.parentaccount
		--left join #temp13 e
		--on a.[Social Security Number] = e.[SSN]

		--[analytics].[brijesh].[GreenState_Trellance_Activation_Campiagn_Targetlist_04122023]
		drop table if exists #GreenState_Trellance_Activation_Campiagn_Targetlist
		select a.*,c.PARENTACCOUNT--,d.N_loan_relationship,d.N_deposits_relationship,d.[OnlineBankingFlag]
		into #GreenState_Trellance_Activation_Campiagn_Targetlist
		from #Activation_Campaign_list a
		left join #listdata c
		on a.[Account Number] = c.CardNumber_UserChar1
		--left join #relationships d
		--on a.Durable_Key = d.Durable_Key
	
		where [External Status Code] is null and [Internal Status Code] is null
		and [FIRST NAME] is not null 
		and [LAST NAME] is not null 
		and [LAST NAME] not like '%trust%' 
		and [LAST NAME] not like '%trst%'
		and [LAST NAME] not like '%truse%'
		and [LAST NAME] not like '%trus%'
		and city is not null
		and STATE is not null
		and ZIPCODE is not null
		and Street is not null
		--and PARENTACCOUNT not in (select PARENTACCOUNT from #multiple_parentaccounts where rank = 1)  --excluding 1 entry out of 2
		--and Durable_Key not in (select Durable_Key from #Inactivefrompast2years)
		and c.PARENTACCOUNT not in 
		( select distinct PARENTACCOUNT from ARCUSYM000..TRACKING 
		where USERCHAR13='S' and ProcessDate=20230411)  ---userchar13 secure cards
		and [Social Security Number] <> 000000000 
		and [Social Security Number] not like  '%11111%'
		and [Social Security Number] not like  '%00000%'
		and [Social Security Number] not like  '%999999%'
		and [Social Security Number] not like '0'

		and AddressTypeDescription<>'Foreign Address' and AddressTypeDescription<>'Foreign Address Zip Last'  
		and c.PARENTACCOUNT not in (select * from #BADADDRESS)
		and Durable_Key not in (select Durable_Key from #Exclude_multiple_cards)
		and Durable_Key not in 
		( select Durable_Key
		from [analytics].[brijesh].[GreenState_Trellance_Home_Improvement_Targetlist_03012023])
		--and N_deposits_relationship <> 0
		--and N_loan_relationship <> 0
		
		go
		
		drop table if exists [analytics].[brijesh].[GreenState_Trellance_Activation_Campiagn_Targetlist_04122023]
		select a.*,b.N_loan_relationship,c.N_deposits_relationship,d.[OnlineBankingFlag]
		into [analytics].[brijesh].[GreenState_Trellance_Activation_Campiagn_Targetlist_04122023]
		from #GreenState_Trellance_Activation_Campiagn_Targetlist a
		left join #temp11 b
		on a.parentaccount = b.parentaccount
		left join #temp12 c
		on a.parentaccount = c.parentaccount
		left join #temp13 d
		on a.[Social Security Number] = d.[SSN]
		where (isnull(N_loan_relationship,0) > 0 or isnull(c.N_deposits_relationship,0) > 0)
		
		
		select   *
		from [analytics].[brijesh].[GreenState_Trellance_Activation_Campiagn_Targetlist_04122023]


		--		select *
		--from [analytics].[brijesh].[GreenState_Trellance_Home_Improvement_Targetlist_04122023]
		--where PARENTACCOUNT  in (	0013889096	,
		--0013721846	,
		--0013458029	,
		--0013580711	)	
		--order by PARENTACCOUNT,Durable_Key

		--Durable_Key = 19026744
		--[Social Security Number] = 482969778
		--PARENTACCOUNT	(No column name)
		--0013889096	2
		--0013721846	2
		--0013458029	2
		--0013580711	2



	--select Durable_Key,[Card Description],extract_datepart,spend
	--from [TMGData].[dbo].[cardholder]
	--where [Active_flag] = 1 and extract_datepart >=201803
	--and Durable_Key in (select Durable_Key
	--from [analytics].[brijesh].[GreenState_Trellance_Activation_Campiagn_Targetlist_04122023])
	--order by Durable_Key,[Card Description],extract_datepart

	--	go

	--	select Durable_Key,spend,[Last Statement Balance Amount],RevolvingBalance,sum_spend_pre_6mo,avg_spend_pre_12mo
	--	from [analytics].[brijesh].[GreenState_Trellance_Home_Improvement_Targetlist_03012023]

	--where Durable_Key in (select Durable_Key
	--	from [analytics].[brijesh].[GreenState_Trellance_Activation_Campiagn_Targetlist_04122023])

		go




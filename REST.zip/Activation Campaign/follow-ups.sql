		-------------------------------------------------------follow-ups-------------------------------------------------
		select state,count(*) as cnt
		from [analytics].[brijesh].[GreenState_Trellance_Activation_Campiagn_Targetlist_03302023]
		group by state
		
		go

		select city,count(*) as cnt
		from [analytics].[brijesh].[GreenState_Trellance_Activation_Campiagn_Targetlist_03302023]
		group by city

		go

		--select top 10 * from ARCUSYM000.dbo.loan
		drop table #temp1
		select parentaccount,count(*) as N_loan_relationship
		into #temp1
		from ARCUSYM000.dbo.loan
		where closedate is null and chargeoffdate is null
		and processdate = '20230330'
		and type in 
		(select loantype from ARCUSYM000.ARCU.ARCUloancategory
		where loancategory1  not in ('','Commercial')
		and loancategory4  not in ('Writeoff'))
		group by parentaccount

		go

		drop table #temp2
		select parentaccount,count(*) as N_deposits_relationship
		into #temp2
		from ARCUSYM000.dbo.savings
		where closedate is null and chargeoffdate is null
		and processdate = '20230330'
		and type in 
		(select sharetype from ARCUSYM000.ARCU.ARCUsharecategory
		where sharecategory1 in ('Consumer','Non-Member')
		and sharecategory2 not in ('Savings'))
		group by parentaccount

		go

		drop table #temp3
		SELECT [SSN],[OnlineBankingFlag]
		into #temp3
		FROM [Q2EVE].[dbo].[vwMemberOnlineBankingSummary]

		go

		select a.*,b.N_loan_relationship,c.N_deposits_relationship,d.[OnlineBankingFlag]
		from [analytics].[brijesh].[GreenState_Trellance_Activation_Campiagn_Targetlist_03302023] a
		left join #temp1 b
		on a.parentaccount = b.parentaccount
		left join #temp2 c
		on a.parentaccount = c.parentaccount
		left join #temp3 d
		on a.[Social Security Number] = d.[SSN]


		-------------------------------------------------------follow-ups-------------------------------------------------
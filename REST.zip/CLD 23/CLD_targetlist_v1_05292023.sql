	
	DROP TABLE IF EXISTS #temp1
	SELECT 
		Durable_Key
		,[Master Account Key]
		,[Social Security Number]
		,[Credit Limit]
		,mob
		,[Card Account Delinquent Day Account]
		,[Account Number]
		,[External Status Code]
		,[Internal Status Code]
		,[Last Statement Balance Amount]
		,RevolvingBalance
		,age
		,([Last Statement Sale Amount]-[Last Statement Return Amount]) as spend
		,TRIPFLAG
		,[Last Statement Payment Amount]
		,Extract_DatePart as sp_month

	INTO #temp1
	FROM [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 and Extract_DatePart = 202305 and [External Status Code] not in ('C','Z')
	and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and [Social Security Number] is not null
	--and mob > 5


go

--***********************************
-- || STEP 1: PRE 12 MONTH NUMBERS ||
--***********************************

	Drop table if exists #temp_pre_12mo_2
	select 
		Durable_Key as d_pre_12mo
		,sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_12mo
		,sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_12mo
		,sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_12mo
		,sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_12mo
		,sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_12mo
		--,sum([Last Statement Balance Amount]) as sum_bal_pre_12mo
		--,sum(RevolvingBalance) as sum_revbal_pre_12mo
		,sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_12mo
		--,avg([Last Statement Balance Amount]) as avg_bal_pre_12mo
		,avg(RevolvingBalance) as avg_revbal_pre_12mo
		,avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_12mo

	into #temp_pre_12mo_2
	from [TMGData].[dbo].[cardholder]
		where [Active_flag] = 1 
		and Extract_DatePart between 202305 - 99 and 202305
		and Durable_Key in 
		(select Durable_Key from #temp1)
		group by Durable_Key


go

--******************************************
-- || STEP 2: PRE 12 MONTH PROFIT NUMBERS ||
--******************************************
	Drop table if exists #temp_pre_12mo_3
	select 
		Durable_Key
		,Extract_DatePart
		,case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization
		,case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate
		,case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate

		,([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income
		,([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
		  +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
		  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees
		,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income    
		,([Last Statement Balance Amount]*0.02/12) as COF
		,(ChargeoffAmount_final) as chgoff_amt
		,case when [Card Description] in ('Mastercard Platinum Rewards','Mastercard World Credit') then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end as rewards_expense -- verify it with internal team
		,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense
		,case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost
		into #temp_pre_12mo_3
		from [TMGData].[dbo].[cardholder]
		where [Active_flag] = 1 
		and Extract_DatePart between 202305 - 99 and 202305
		and Durable_Key in 
		(select Durable_Key from #temp1)

--**************************************************
-- || STEP 3: PRE 12 MONTH PROFIT NUMBERS SUMMARY ||
--**************************************************
	Drop table if exists #temp_pre_12mo_3a
	select 
		Durable_Key
		,count(*) as N_months
		--,sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit
		,avg(Utilization) as avg_Utilization
		,avg(revolve_rate) as avg_revolve_rate
		,avg(payment_rate) as avg_payment_rate

	into #temp_pre_12mo_3a
	from #temp_pre_12mo_3
	group by Durable_Key
	
go

	Drop table if exists #temp_pre_12mo_4
	select 
		a.*
		--,b.profit as sum_profit_pre_12mo,b.profit/b.N_months as avg_profit_pre_12mo
		,b.avg_Utilization as avg_Utilization_pre_12mo
		,b.avg_revolve_rate as avg_revolve_rate_pre_12mo
		,b.avg_payment_rate as avg_payment_rate_pre_12mo

	into #temp_pre_12mo_4
	from #temp_pre_12mo_2 a
	left join #temp_pre_12mo_3a b
	on a.d_pre_12mo = b.Durable_Key



--*********************************
-- || STEP 4: PRE 6 MONTH NUMBERS||
--*********************************
	Drop table if exists #temp_pre_6mo_2
	select Durable_Key  as d_pre_6mo,
		sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_6mo,
		sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_6mo,
		sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_6mo,
		sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_6mo,
		sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_6mo,
		--sum([Last Statement Balance Amount]) as sum_bal_pre_6mo,
		--sum(RevolvingBalance) as sum_revbal_pre_6mo,
		sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_6mo,
		--avg([Last Statement Balance Amount]) as avg_bal_pre_6mo,
		avg(RevolvingBalance) as avg_revbal_pre_6mo,
		avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_6mo
	
		into #temp_pre_6mo_2
		from [TMGData].[dbo].[cardholder]
		where [Active_flag] = 1 
		and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
		and Extract_DatePart between  202212 and 202305
		and Durable_Key in 
		(select Durable_Key from #temp1)
		group by Durable_Key


--******************************************
-- || STEP 5: PRE 6 MONTH PROFIT NUMBERS ||
--******************************************
	Drop table if exists  #temp_pre_6mo_3
	select 
		Durable_Key
		,Extract_DatePart
		,case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization
		,case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate
		,case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate

		,([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income
		,([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
		  +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
		  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees
		,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income   
		,([Last Statement Balance Amount]*0.02/12) as COF
		,(ChargeoffAmount_final) as chgoff_amt
		,case when [Card Description] in ('Mastercard Platinum Rewards','Mastercard World Credit') then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end as rewards_expense -- verify
		,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense
		,case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost

	into #temp_pre_6mo_3
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and Extract_DatePart between 202212 and 202305
	and Durable_Key in 
	(select Durable_Key from #temp1)

	go

--*************************************************
-- || STEP 6: PRE 6 MONTH PROFIT NUMBERS SUMMARY ||
--*************************************************
	Drop table if exists #temp_pre_6mo_3a
	select 
		Durable_Key
		,count(*) as N_months
		--,sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit
		,avg(Utilization) as avg_Utilization,avg(revolve_rate) as avg_revolve_rate,avg(payment_rate) as avg_payment_rate

	into #temp_pre_6mo_3a
	from #temp_pre_6mo_3
	group by Durable_Key


--***************************************************
-- || STEP 7: DATA GETHERING OF DATA BUILDED ABOVE ||
--***************************************************
	Drop table if exists #temp_pre_6mo_3b
	select a.*
		--,b.profit as sum_profit_pre_6mo,b.profit/b.N_months as avg_profit_pre_6mo
		,b.avg_Utilization as avg_Utilization_pre_6mo
		,b.avg_revolve_rate as avg_revolve_rate_pre_6mo
		,b.avg_payment_rate as avg_payment_rate_pre_6mo

	into #temp_pre_6mo_3b
	from #temp_pre_6mo_2 a
	left join #temp_pre_6mo_3a b
	on a.d_pre_6mo = b.Durable_Key

	go

	--select top 10 * from #temp2 where FICO is not null
	Drop table if exists #temp2
	select a.*,b.*,c.*,d.*
	into #temp2
	from #temp1 a
	left join #temp_pre_12mo_4 b
	on a.Durable_Key = b.d_pre_12mo
	left join #temp_pre_6mo_3b c
	on a.Durable_Key = c.d_pre_6mo
	left join 
	(select * from openquery 
	( [GSDWsql01],
	'select SSN
	,FICO
	  ,case when [CCAPREstimate] <0 then null else [CCAPREstimate] end as [CCAPREstimate]
      ,case when	[AggregatedSpendPast3Months]	<0 then null else	[AggregatedSpendPast3Months]	 end as 	[AggregatedSpendPast3Months]
	,case when	[TopOfWalletCCAnnualSpend]	<0 then null else	[TopOfWalletCCAnnualSpend]	 end as 	[TopOfWalletCCAnnualSpend]
	,case when	[TopOfWalletCCCurrentBalance]	<0 then null else	[TopOfWalletCCCurrentBalance]	 end as 	[TopOfWalletCCCurrentBalance]
	,case when	[OpenTradeCount]	<0 then null else	[OpenTradeCount]	 end as 	[OpenTradeCount]
	,case when	[OpenTradeBalance]	<0 then null else	[OpenTradeBalance]	 end as 	[OpenTradeBalance]
	,case when	[AutoOpenTradeCount]	<0 then null else	[AutoOpenTradeCount]	 end as 	[AutoOpenTradeCount]
	,case when	[AutoLoanOrgBalanceP12Months]	<0 then null else	[AutoLoanOrgBalanceP12Months]	 end as 	[AutoLoanOrgBalanceP12Months]
	,case when	[AutoOpenTradeBalance]	<0 then null else	[AutoOpenTradeBalance]	 end as 	[AutoOpenTradeBalance]
	,case when	[CCCount]	<0 then null else	[CCCount]	 end as 	[CCCount]
	,case when	[CCOpenCount]	<0 then null else	[CCOpenCount]	 end as 	[CCOpenCount]
	,case when	[CCTotalAvailableLOC]	<0 then null else	[CCTotalAvailableLOC]	 end as 	[CCTotalAvailableLOC]
	,case when	[CCOpenBalance]	<0 then null else	[CCOpenBalance]	 end as 	[CCOpenBalance]
	,case when	[ChargeOffTradeCountP12Months]	<0 then null else	[ChargeOffTradeCountP12Months]	 end as 	[ChargeOffTradeCountP12Months]
	,case when	[ChargeOffTotalBalance]	<0 then null else	[ChargeOffTotalBalance]	 end as 	[ChargeOffTotalBalance]
	,case when	[ForeclosureCountP12Months]	<0 then null else	[ForeclosureCountP12Months]	 end as 	[ForeclosureCountP12Months]
	,case when	[ForeclosureTotalBalance]	<0 then null else	[ForeclosureTotalBalance]	 end as 	[ForeclosureTotalBalance]
	,case when	[BankruptcyCount]	<0 then null else	[BankruptcyCount]	 end as 	[BankruptcyCount]
	,case when	[NumberInquiriesP6Months]	<0 then null else	[NumberInquiriesP6Months]	 end as 	[NumberInquiriesP6Months]
	,case when	[CCWorstRatingP12Months]	<0 then null else	[CCWorstRatingP12Months]	 end as 	[CCWorstRatingP12Months]
	,case when	[AutoWorstRatingP12Months]	<0 then null else	[AutoWorstRatingP12Months]	 end as 	[AutoWorstRatingP12Months]
	,case when	[MortgageWorstRatingP12Months]	<0 then null else	[MortgageWorstRatingP12Months]	 end as 	[MortgageWorstRatingP12Months]
	,case when	[HELOCWorstRatingP12Months]	<0 then null else	[HELOCWorstRatingP12Months]	 end as 	[HELOCWorstRatingP12Months]
	,case when	[HEWorstRatingP12Months]	<0 then null else	[HEWorstRatingP12Months]	 end as 	[HEWorstRatingP12Months]
	,case when	[HEOpenCount]	<0 then null else	[HEOpenCount]	 end as 	[HEOpenCount]
	,case when	[HETotalAvailableLOC]	<0 then null else	[HETotalAvailableLOC]	 end as 	[HETotalAvailableLOC]
	,case when	[HEOpenBalance]	<0 then null else	[HEOpenBalance]	 end as 	[HEOpenBalance]
	,case when	[HELOCOpenCount]	<0 then null else	[HELOCOpenCount]	 end as 	[HELOCOpenCount]
	,case when	[HELOCTotalAvailableLOC]	<0 then null else	[HELOCTotalAvailableLOC]	 end as 	[HELOCTotalAvailableLOC]
	,case when	[HELOCOpenBalance]	<0 then null else	[HELOCOpenBalance]	 end as 	[HELOCOpenBalance]
	,case when	[MortgageOpenCount]	<0 then null else	[MortgageOpenCount]	 end as 	[MortgageOpenCount]
	,case when	[MortgageOpenBalance]	<0 then null else	[MortgageOpenBalance]	 end as 	[MortgageOpenBalance]
	,case when	[RevolvingAccountCount]	<0 then null else	[RevolvingAccountCount]	 end as 	[RevolvingAccountCount]
	,case when	[CCRevolvingBalance]	<0 then null else	[CCRevolvingBalance]	 end as 	[CCRevolvingBalance]

      ,[CCTripTypeP6Months]
      ,case when [StudentLoanOpenCount] <0 then null else [StudentLoanOpenCount]	 end as [StudentLoanOpenCount]
      ,case when [StudentLoanOpenBalance] <0 then null else [StudentLoanOpenBalance]	 end as [StudentLoanOpenBalance]
 
	from [BureauData].[dbo].[TransUnionAttributeHistory] where date = 202304')
	) d
	on a.[Social Security Number] = d.SSN

	go

		DROP TABLE IF EXISTS #listdata 
	select  distinct cc.PARENTACCOUNT,ExternalStatus_UserChar8,InternalStatus_UserChar9
	,tmgdurablekey_userchar10
		 ,cc.CardNumber_UserChar1
		,cc.CurrentBalance_UserAmount1
		,cc.ProcessDate
		,cc.SSN_UserChar3
		, datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Process_Date
	   into #listdata               
		FROM arcusym000.tracking.tvwARCUTRACKINGCreditCard cc
	where
	  ProcessDate in (select max(processdate) from arcusym000.tracking.tvwARCUTRACKINGCreditCard)   --(20230611) 
		AND cc.ExpireDate IS NULL


	--select distinct ExternalStatus_UserChar8 from #listdata   
	--where ExternalStatus_UserChar8 is not null

	go

	drop table if exists #Unemployment
	select 
	a.PARENTACCOUNT,1 Unemployment,sum(BALANCECHANGE) Amount
	into #Unemployment
	from 
	(
	select PARENTACCOUNT,PARENTID,EFFECTIVEDATE,SEQUENCENUMBER-1 as SEQUENCENUMBER,COMMENT
	, case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE)) 
	else  CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVE_DATE from ARCUSYM000..SAVINGSTRANSACTION
	where COMMENT like '%Unemplo%' and EFFECTIVEDATE >= '2022-12-01 00:00:00' 
	) A 
	left join 
	(
	select PARENTACCOUNT,PARENTID,EFFECTIVEDATE,SEQUENCENUMBER,COMMENT,BALANCECHANGE
	, case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE)) 
	else  CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVE_DATE from ARCUSYM000..SAVINGSTRANSACTION
	where EFFECTIVEDATE >='2022-12-01 00:00:00'
	) b
	on a.PARENTACCOUNT=b.PARENTACCOUNT and a.PARENTID=b.PARENTID
	and a.EFFECTIVEDATE=b.EFFECTIVEDATE and a.SEQUENCENUMBER=b.SEQUENCENUMBER
	group by a.PARENTACCOUNT

	go

	--select top 10 * from #temp3
	drop table if exists #temp3
	select 
	case when SSN is null then SSN_UserChar3 else ssn end as SSN
	,Durable_Key
	,[Master Account Key]
	,[Account Number]
	,mob
	,[Card Account Delinquent Day Account]
	,b.PARENTACCOUNT
	,case 
	when ([CCWorstRatingP12Months] > 1 or [CCWorstRatingP12Months] is null)
	and Times_1_cycle_delq_pre_12mo	> 0 then '1.Severe'
	when ([CCWorstRatingP12Months] > 1 or [CCWorstRatingP12Months] is null)
	and Times_1_cycle_delq_pre_12mo	= 0 then '3.Moderate'
	when ([CCWorstRatingP12Months] <= 1) and FICO > 675 then '4.Low'	
	when ([CCWorstRatingP12Months] <= 1) and FICO <= 675 
	and avg_payment_rate_pre_12mo <= 0.033 then '2.High'
	when ([CCWorstRatingP12Months] <= 1) and FICO <= 675 
	and avg_payment_rate_pre_12mo > 0.033 then '3.Moderate'
	else 'Others' end as risk_segment
	,sp_month as Month
	,ExternalStatus_UserChar8 as [External Status Code]
	,InternalStatus_UserChar9 as [Internal Status Code]
	,isnull(c.Unemployment,0)  as Unemployment_flag_past_6months
	,[Credit Limit]
	,[Last Statement Balance Amount]
	,RevolvingBalance
	,CurrentBalance_UserAmount1 as Current_Balance
	--,SSN_UserChar3
	,[Last Statement Payment Amount]
	,spend as spend_May23
	,FICO
	,[CCWorstRatingP12Months] as [Credit Card_worst_Rating_past_12months]
	,Times_1_cycle_delq_pre_12mo
	,avg_payment_rate_pre_12mo
	,Times_2_cycle_delq_pre_12mo
	,Times_overlimit_pre_12mo
	,avg_Utilization_pre_12mo
	,avg_revolve_rate_pre_12mo
	--,avg_payment_rate_pre_12mo

	,Times_2_cycle_delq_pre_6mo
	,Times_overlimit_pre_6mo
	,avg_Utilization_pre_6mo
	,avg_revolve_rate_pre_6mo
	,avg_payment_rate_pre_6mo

	,CCOpenBalance
	,AutoWorstRatingP12months
	,MOrtgageWorstRatingP12months
	,HelocWorstRatingP12months
	,CCRevolvingBalance
	--select top 10 * from #temp2
	into #temp3
	from #temp2 a
	left join #listdata b
	on a.Durable_Key = b.TMGDurableKey_UserChar10 and a.[Account Number] = b.CardNumber_UserChar1
	left join #Unemployment c
	on b.PARENTACCOUNT = c.PARENTACCOUNT
	order by RevolvingBalance desc,FICO

	--where ExternalStatus_UserChar8 not in ('CLOSED','CHARGEOFF','FRAUD','BANKRUPT')
	--select * from #temp2 where SSN is null
	--select * from #temp3 where SSN is null	
	
	go

	select [External Status Code],count(*) as cnt
	from #temp3
	where [External Status Code] not in ('CLOSED','CHARGEOFF','FRAUD','BANKRUPT')
	or [External Status Code] is null
	group by [External Status Code]
	
	go

	select risk_segment,count(*) as cnt
	from #temp3
	where [External Status Code] not in ('CLOSED','CHARGEOFF','FRAUD','BANKRUPT')
	or [External Status Code] is null
	group by risk_segment
	
	go

	drop table if exists #temp11
	select parentaccount,count(*) as N_loan_relationship,
	sum(Balance) as Loan_Balance
	into #temp11
	from ARCUSYM000.dbo.loan
	where closedate is null and chargeoffdate is null
	and processdate = '20230611'
	and type in 
	(select loantype from ARCUSYM000.ARCU.ARCUloancategory
	where loancategory1  not in ('','Commercial')
	and loancategory4  not in ('Writeoff'))
	group by parentaccount

	go

	drop table if exists #temp12
	select parentaccount,count(*) as N_deposits_relationship,
	sum(Balance) as Deposits_Balance
	into #temp12
	from ARCUSYM000.dbo.savings
	where closedate is null and chargeoffdate is null
	and processdate = '20230611'
	and type in 
	(select sharetype from ARCUSYM000.ARCU.ARCUsharecategory
	where sharecategory1 in ('Consumer','Non-Member'))
	group by parentaccount

	go

	drop table if exists #temp4
	select a.*,b.Loan_Balance,c.Deposits_Balance
	into #temp4
	from #temp3 a
	left join #temp11 b
	on a.PARENTACCOUNT = b.PARENTACCOUNT
	left join #temp12 c
	on a.PARENTACCOUNT = c.PARENTACCOUNT
	where risk_segment = '1.Severe'
	and ([External Status Code] not in ('CLOSED','CHARGEOFF','FRAUD','BANKRUPT')
	or [External Status Code] is null)
	order by cast(RevolvingBalance as float) desc,cast(FICO as int) asc

	go

	drop table if exists [analytics].[brijesh].[CLD_2023_Severe_risk_group_06122023]
	select *
	into [analytics].[brijesh].[CLD_2023_Severe_risk_group_06122023]
	from #temp4
	order by cast(RevolvingBalance as float) desc,cast(FICO as int) asc


	go

	--Cut Short list
	select *
	from [analytics].[brijesh].[CLD_2023_Severe_risk_group_06122023]
	where 
	[Credit Limit] > 2000
	and FICO <= 780
	and Deposits_Balance <= 10000
	and RevolvingBalance  > 1000
	and case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end > 0.3
	order by Deposits_Balance desc
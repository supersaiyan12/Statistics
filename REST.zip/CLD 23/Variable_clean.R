
#PACKAGES
library("RODBC")

# Loading the Train Data :
databaseConnection <- odbcDriverConnect("Driver={SQL Server};server=ACARCU01;trusted_connection=true")
databaseConnection <- odbcDriverConnect('driver={SQL Server};server=ACARCU01;database=Analytics;trusted_connection=true')
data <- sqlQuery(databaseConnection, "select * from Analytics.dbo.CLD_MASTER")

dim(data)
dim(data1)
dim(data2)

summary(data)

#TO CHECK NA IN AA THE COLUMN BY NAMES
write.csv(cbind(lapply(lapply(data,is.na),sum)),'var.csv')
sum(is.na(data))

# dropping column that contain all null
data2 <- Filter(function(x)!all(is.na(x)),data)

#Final Data set to export to SQL back (Timestamp with result)
databaseConnection <- RODBC::odbcDriverConnect('driver={SQL Server};server=ACARCU01;database=Analytics;trusted_connection=true')
sqlQuery(databaseConnection, 'drop table if exists  ARIMA_OUTPUTS')
sqlSave(databaseConnection,df2,tablename = "ARIMA_OUTPUTS")

	
	DROP TABLE IF EXISTS #temp1
	SELECT 
		Durable_Key
		,[Master Account Key]
		,[Social Security Number]
		,[Credit Limit]
		,mob
		--,[Card Description]
		,[External Status Code]
		,[Internal Status Code]
		,[Last Statement Balance Amount]
		,RevolvingBalance
		,age
		,([Last Statement Sale Amount]-[Last Statement Return Amount]) as spend
		,TRIPFLAG
		,[Last Statement Payment Amount]
		--,Extract_DatePart as sp_month

	INTO #temp1
	FROM [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 and Extract_DatePart = 202204 and [External Status Code] not in ('C','Z')
	and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and [Social Security Number] is not null

go

--***********************************
-- || STEP 1: PRE 12 MONTH NUMBERS ||
--***********************************

	Drop table if exists #temp_pre_12mo_2
	select 
		Durable_Key as d_pre_12mo
		,sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_12mo
		,sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_12mo
		,sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_12mo
		,sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_12mo
		,sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_12mo
		--,sum([Last Statement Balance Amount]) as sum_bal_pre_12mo
		--,sum(RevolvingBalance) as sum_revbal_pre_12mo
		,sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_12mo
		--,avg([Last Statement Balance Amount]) as avg_bal_pre_12mo
		,avg(RevolvingBalance) as avg_revbal_pre_12mo
		,avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_12mo

	into #temp_pre_12mo_2
	from [TMGData].[dbo].[cardholder]
		where [Active_flag] = 1 
		and Extract_DatePart between 202204 - 99 and 202204
		and Durable_Key in 
		(select Durable_Key from #temp1)
		group by Durable_Key


go

--******************************************
-- || STEP 2: PRE 12 MONTH PROFIT NUMBERS ||
--******************************************
	Drop table if exists #temp_pre_12mo_3
	select 
		Durable_Key
		,Extract_DatePart
		,case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization
		,case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate
		,case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate

		,([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income
		,([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
		  +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
		  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees
		,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income    
		,([Last Statement Balance Amount]*0.02/12) as COF
		,(ChargeoffAmount_final) as chgoff_amt
		,case when [Card Description] in ('Mastercard Platinum Rewards','Mastercard World Credit') then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end as rewards_expense -- verify it with internal team
		,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense
		,case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost
		into #temp_pre_12mo_3
		from [TMGData].[dbo].[cardholder]
		where [Active_flag] = 1 
		and Extract_DatePart between 202204 - 99 and 202204
		and Durable_Key in 
		(select Durable_Key from #temp1)

--**************************************************
-- || STEP 3: PRE 12 MONTH PROFIT NUMBERS SUMMARY ||
--**************************************************
	Drop table if exists #temp_pre_12mo_3a
	select 
		Durable_Key
		,count(*) as N_months
		--,sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit
		,avg(Utilization) as avg_Utilization
		,avg(revolve_rate) as avg_revolve_rate
		,avg(payment_rate) as avg_payment_rate

	into #temp_pre_12mo_3a
	from #temp_pre_12mo_3
	group by Durable_Key
	
go

	Drop table if exists #temp_pre_12mo_4
	select 
		a.*
		--,b.profit as sum_profit_pre_12mo,b.profit/b.N_months as avg_profit_pre_12mo
		,b.avg_Utilization as avg_Utilization_pre_12mo
		,b.avg_revolve_rate as avg_revolve_rate_pre_12mo
		,b.avg_payment_rate as avg_payment_rate_pre_12mo

	into #temp_pre_12mo_4
	from #temp_pre_12mo_2 a
	left join #temp_pre_12mo_3a b
	on a.d_pre_12mo = b.Durable_Key



--*********************************
-- || STEP 4: PRE 6 MONTH NUMBERS||
--*********************************
	Drop table if exists #temp_pre_6mo_2
	select Durable_Key  as d_pre_6mo,
		sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_6mo,
		sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_6mo,
		sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_6mo,
		sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_6mo,
		sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_6mo,
		--sum([Last Statement Balance Amount]) as sum_bal_pre_6mo,
		--sum(RevolvingBalance) as sum_revbal_pre_6mo,
		sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_6mo,
		--avg([Last Statement Balance Amount]) as avg_bal_pre_6mo,
		avg(RevolvingBalance) as avg_revbal_pre_6mo,
		avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_6mo
	
		into #temp_pre_6mo_2
		from [TMGData].[dbo].[cardholder]
		where [Active_flag] = 1 
		and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
		and Extract_DatePart between  202111 and 202204
		and Durable_Key in 
		(select Durable_Key from #temp1)
		group by Durable_Key


--******************************************
-- || STEP 5: PRE 6 MONTH PROFIT NUMBERS ||
--******************************************
Drop table if exists  #temp_pre_6mo_3
select 
	Durable_Key
	,Extract_DatePart
	,case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization
	,case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate
	,case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate

	,([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income
	,([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees
	,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income   
	,([Last Statement Balance Amount]*0.02/12) as COF
	,(ChargeoffAmount_final) as chgoff_amt
	,case when [Card Description] in ('Mastercard Platinum Rewards','Mastercard World Credit') then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end as rewards_expense -- verify
	,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense
	,case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost

into #temp_pre_6mo_3
from [TMGData].[dbo].[cardholder]
where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
and Extract_DatePart between 202111 and 202204
and Durable_Key in 
(select Durable_Key from #temp1)


--*************************************************
-- || STEP 6: PRE 6 MONTH PROFIT NUMBERS SUMMARY ||
--*************************************************
Drop table if exists #temp_pre_6mo_3a
select 
	Durable_Key
	,count(*) as N_months
	--,sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit
	,avg(Utilization) as avg_Utilization,avg(revolve_rate) as avg_revolve_rate,avg(payment_rate) as avg_payment_rate

into #temp_pre_6mo_3a
from #temp_pre_6mo_3
group by Durable_Key


--***************************************************
-- || STEP 7: DATA GETHERING OF DATA BUILDED ABOVE ||
--***************************************************
Drop table if exists #temp_pre_6mo_3b
select a.*
	--,b.profit as sum_profit_pre_6mo,b.profit/b.N_months as avg_profit_pre_6mo
	,b.avg_Utilization as avg_Utilization_pre_6mo
	,b.avg_revolve_rate as avg_revolve_rate_pre_6mo
	,b.avg_payment_rate as avg_payment_rate_pre_6mo

into #temp_pre_6mo_3b
from #temp_pre_6mo_2 a
left join #temp_pre_6mo_3a b
on a.d_pre_6mo = b.Durable_Key


	go
--**********************************************
-- || STEP 9: POST 12 MONTHS PROFIT VARIABLES ||
--**********************************************
Drop table if exists #temp_post_12mo_3
select 
	Durable_Key
	,Extract_DatePart
	,(ChargeoffAmount_final) as chgoff_amt
	
into #temp_post_12mo_3
from [TMGData].[dbo].[cardholder]
where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
and Extract_DatePart between 202204 + 1 and 202204 + 100
and Durable_Key in 
(select Durable_Key from #temp1)

	go
--*******************************************************
-- || STEP 10: POST 12 MONTHS PROFIT SUMMARY VARIABLES ||
--*******************************************************
Drop table if exists #temp_post_12mo_4
select 
	Durable_Key
	,count(*) as N_month
	,sum(case when chgoff_amt > 0 then 1 else 0 end) as chgoff_flag_post_12mo
	,sum(chgoff_amt) as chgoff_amt_post_12mo
	
into #temp_post_12mo_4
from #temp_post_12mo_3
group by Durable_Key


	go
--**********************************
-- || STEP 11: COMBINING ALL DATA ||
--**********************************
	Drop table if exists #temp2
	select a.*,b.*,c.*,d.N_month,d.chgoff_flag_post_12mo,d.chgoff_amt_post_12mo
	into #temp2
	from #temp1 a
	left join #temp_pre_12mo_4 b
	on a.Durable_Key = b.d_pre_12mo
	left join #temp_pre_6mo_3b c
	on a.Durable_Key = c.d_pre_6mo
	left join #temp_post_12mo_4 d
	on a.Durable_Key = d.Durable_Key

	go

	select a.*,b.* 
	into [analytics].[brijesh].[CLD_2023_segmentation_Data_05252023]
	from #temp2 a
	left join [analytics].[brijesh].[CLD_2023_segmentation_Data_05232023] b
	on a.[Social Security Number] = b.SSN
	where [SSN] is not null

	go

	--select SSN,chgoff_flag_post_12mo,Target_flag
	--from #temp3
	--where [SSN] is not null


	--select count(*) 
	--from [analytics].[brijesh].[CLD_2023_segmentation_Data_05232023]
	--where ssn is null


	select 
	[Durable_Key]
,[Credit Limit]
,[mob]
,[External Status Code]
,[Internal Status Code]
,[Last Statement Balance Amount]
,[RevolvingBalance]
,[age]
,[spend]
,[TRIPFLAG]
,[Last Statement Payment Amount]
,[Times_1_cycle_delq_pre_12mo]
,[Times_2_cycle_delq_pre_12mo]
,[Times_overlimit_pre_12mo]
,[Times_5pc_overlimit_pre_12mo]
,[Times_cash_Advances_pre_12mo]
,[sum_spend_pre_12mo]
,[avg_revbal_pre_12mo]
,[avg_spend_pre_12mo]
,[avg_Utilization_pre_12mo]
,[avg_revolve_rate_pre_12mo]
,[avg_payment_rate_pre_12mo]
,[Times_1_cycle_delq_pre_6mo]
,[Times_2_cycle_delq_pre_6mo]
,[Times_overlimit_pre_6mo]
,[Times_5pc_overlimit_pre_6mo]
,[Times_cash_Advances_pre_6mo]
,[sum_spend_pre_6mo]
,[avg_revbal_pre_6mo]
,[avg_spend_pre_6mo]
,[avg_Utilization_pre_6mo]
,[avg_revolve_rate_pre_6mo]
,[avg_payment_rate_pre_6mo]
,[chgoff_flag_post_12mo]
,[chgoff_amt_post_12mo]
,[PRODUCT_SAVINGS_SP]
,[MOB_SAVINGS]
,[AVG_MONTH_END_BALANCE_SAVINGS_Q1]
,[DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2]
,[DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3]
,[SUM_LASTDIVAMOUNT_SAVINGS_Q1]
,[DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2]
,[DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3]
,[AVG_CHARGEOFFAMOUNT_SAVINGS_SP]
,[AVG_CHARGEOFFAMOUNT_SAVINGS_Q1]
,[DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q2]
,[DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q3]
,[PRODUCT_CHECKING_SP]
,[MOB_CHECKING]
,[AVG_MONTH_END_BALANCE_CHECKING_Q1]
,[DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2]
,[DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3]
,[SUM_LASTDIVAMOUNT_CHECKING_Q1]
,[DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2]
,[DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q3]
,[AVG_CHARGEOFFAMOUNT_CHECKING_SP]
,[AVG_CHARGEOFFAMOUNT_CHECKING_Q1]
,[DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q2]
,[DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q3]
,[PRODUCT_CERTIFICATES_SP]
,[MOB_CERTIFICATES]
,[AVG_MONTH_END_BALANCE_CERTIFICATES_Q1]
,[DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2]
,[DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q3]
,[SUM_LASTDIVAMOUNT_CERTIFICATES_Q1]
,[DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q2]
,[DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q3]
,[PRODUCT_MONEYMARKET_SP]
,[MOB_MONEYMARKET]
,[AVG_MONTH_END_BALANCE_MONEYMARKET_Q1]
,[DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2]
,[DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q3]
,[SUM_LASTDIVAMOUNT_MONEYMARKET_Q1]
,[DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2]
,[DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q3]
,[PRODUCT_IRA_SP]
,[MOB_IRA]
,[AVG_MONTH_END_BALANCE_IRA_Q1]
,[DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q2]
,[DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q3]
,[SUM_LASTDIVAMOUNT_IRA_Q1]
,[DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q2]
,[DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q3]
,[AVG_MONTH_END_BALANCE_HSA_Q1]
,[DFT_AVG_MONTH_END_BALANCE_HSA_Q1_Q2]
,[DFT_AVG_MONTH_END_BALANCE_HSA_Q1_Q3]
,[PRODUCT_DEPOSITS_SP]
,[PRODUCT_DEPOSITS_Q1]
,[DFT_PRODUCT_DEPOSITS_Q1_Q2]
,[DFT_PRODUCT_DEPOSITS_Q1_Q3]
,[TYPE_DEPOSITS_Q1]
,[DFT_TYPE_DEPOSITS_Q1_Q2]
,[DFT_TYPE_DEPOSITS_Q1_Q3]
,[MOB_DEPOSITS]
,[AVG_MONTH_END_BALANCE_DEPOSITS_Q1]
,[DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2]
,[DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3]
,[SUM_LASTDIVAMOUNT_DEPOSITS_Q1]
,[DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2]
,[DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3]
,[AVG_CHARGEOFFAMOUNT_DEPOSITS_SP]
,[AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1]
,[DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q2]
,[DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q3]
,[SAVINGS_StaticpoolFlag]
,[CHECKING_StaticpoolFlag]
,[CERTIFICATES_StaticpoolFlag]
,[MONEYMARKET_StaticpoolFlag]
,[IRA_StaticpoolFlag]
,[SAVINGS_Q1Flag]
,[CHECKING_Q1Flag]
,[CERTIFICATES_Q1Flag]
,[MONEYMARKET_Q1Flag]
,[IRA_Q1Flag]
,[HSA_Q1Flag]
,[DEPOSITED_AMOUNT_SAVINGS_Q1]
,[DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2]
,[DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3]
,[DEPOSITED_COUNT_SAVINGS_Q1]
,[DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2]
,[DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3]
,[WITHDRAWAL_AMOUNT_SAVINGS_Q1]
,[DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2]
,[DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3]
,[WITHDRAWAL_COUNT_SAVINGS_Q1]
,[DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2]
,[DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q3]
,[DEPOSITED_AMOUNT_CHECKING_Q1]
,[DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2]
,[DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3]
,[DEPOSITED_COUNT_CHECKING_Q1]
,[DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2]
,[DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3]
,[WITHDRAWAL_AMOUNT_CHECKING_Q1]
,[DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2]
,[DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q3]
,[WITHDRAWAL_COUNT_CHECKING_Q1]
,[DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2]
,[DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q3]
,[DEPOSITED_AMOUNT_CERTIFICATES_Q1]
,[DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q2]
,[DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q3]
,[DEPOSITED_COUNT_CERTIFICATES_Q1]
,[DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q2]
,[DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q3]
,[WITHDRAWAL_AMOUNT_CERTIFICATES_Q1]
,[DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q2]
,[DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q3]
,[WITHDRAWAL_COUNT_CERTIFICATES_Q1]
,[DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q2]
,[DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q3]
,[SUM_INTEREST_CERTIFICATES_Q1]
,[DFT_SUM_INTEREST_CERTIFICATES_Q1_Q2]
,[DFT_SUM_INTEREST_CERTIFICATES_Q1_Q3]
,[DEPOSITED_AMOUNT_MONEYMARKET_Q1]
,[DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q2]
,[DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q3]
,[DEPOSITED_COUNT_MONEYMARKET_Q1]
,[DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q2]
,[DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q3]
,[WITHDRAWAL_AMOUNT_MONEYMARKET_Q1]
,[DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q2]
,[DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q3]
,[WITHDRAWAL_COUNT_MONEYMARKET_Q1]
,[DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q2]
,[DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q3]
,[DEPOSITED_AMOUNT_IRA_Q1]
,[DFT_DEPOSITED_AMOUNT_IRA_Q1_Q2]
,[DFT_DEPOSITED_AMOUNT_IRA_Q1_Q3]
,[DEPOSITED_COUNT_IRA_Q1]
,[DFT_DEPOSITED_COUNT_IRA_Q1_Q2]
,[DFT_DEPOSITED_COUNT_IRA_Q1_Q3]
,[WITHDRAWAL_AMOUNT_IRA_Q1]
,[DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q2]
,[DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q3]
,[WITHDRAWAL_COUNT_IRA_Q1]
,[DFT_WITHDRAWAL_COUNT_IRA_Q1_Q2]
,[DFT_WITHDRAWAL_COUNT_IRA_Q1_Q3]
,[SUM_INTEREST_IRA_Q1]
,[DFT_SUM_INTEREST_IRA_Q1_Q2]
,[DFT_SUM_INTEREST_IRA_Q1_Q3]
,[DEPOSITED_AMOUNT_DEPOSITS_Q1]
,[DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2]
,[DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3]
,[DEPOSITED_COUNT_DEPOSITS_Q1]
,[DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2]
,[DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q3]
,[WITHDRAWAL_AMOUNT_DEPOSITS_Q1]
,[DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2]
,[DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q3]
,[WITHDRAWAL_COUNT_DEPOSITS_Q1]
,[DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2]
,[DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3]
,[SUM_INTEREST_DEPOSITS_Q1]
,[DFT_SUM_INTEREST_DEPOSITS_Q1_Q2]
,[DFT_SUM_INTEREST_DEPOSITS_Q1_Q3]
,[PRODUCT_RealEstate_Q1]
,[DFT_PRODUCT_RealEstate_Q1_Q3]
,[PRODUCT_SecuredLoan_Q1]
,[DFT_PRODUCT_SecuredLoan_Q1_Q3]
,[PRODUCT_UnsecuredLoan_Q1]
,[DFT_PRODUCT_UnsecuredLoan_Q1_Q3]
,[PRODUCT_VehicleLoan_Q1]
,[DFT_PRODUCT_VehicleLoan_Q1_Q3]
,[PRODUCT_Loan_Q1]
,[DFT_PRODUCT_Loan_Q1_Q3]
,[RealEstate_MOB]
,[SecuredLoan_MOB]
,[UnsecuredLoan_MOB]
,[Vehicleloan_MOB]
,[MAX_Loan_MOB]
,[PAYMENTCOUNT_RealEstate_Q1]
,[DFT_PAYMENTCOUNT_RealEstate_Q1_Q2]
,[DFT_PAYMENTCOUNT_RealEstate_Q1_Q3]
,[PAYMENTCOUNT_SecuredLoan_Q1]
,[DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q2]
,[DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q3]
,[PAYMENTCOUNT_UnsecuredLoan_Q1]
,[DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q2]
,[DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q3]
,[PAYMENTCOUNT_VehicleLoan_Q1]
,[DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q2]
,[DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q3]
,[PAYMENTCOUNT_Loan_Q1]
,[DFT_PAYMENTCOUNT_Loan_Q1_Q2]
,[DFT_PAYMENTCOUNT_Loan_Q1_Q3]
,[SUM_OriginalBalance_RealEstate_Q1]
,[DFT_SUM_OriginalBalance_RealEstate_Q1_Q2]
,[DFT_SUM_OriginalBalance_RealEstate_Q1_Q3]
,[SUM_OriginalBalance_SecuredLoan_Q1]
,[DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q2]
,[DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q3]
,[SUM_OriginalBalance_UnsecuredLoan_Q1]
,[DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q2]
,[DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q3]
,[SUM_OriginalBalance_VehicleLoan_Q1]
,[DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q2]
,[DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q3]
,[SUM_OriginalBalance_Loan_Q1]
,[DFT_SUM_OriginalBalance_Loan_Q1_Q2]
,[DFT_SUM_OriginalBalance_Loan_Q1_Q3]
,[SUM_PAYMENT_RealEstate_Q1]
,[DFT_SUM_PAYMENT_RealEstate_Q1_Q2]
,[DFT_SUM_PAYMENT_RealEstate_Q1_Q3]
,[SUM_PAYMENT_SecuredLoan_Q1]
,[DFT_SUM_PAYMENT_SecuredLoan_Q1_Q2]
,[DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3]
,[SUM_PAYMENT_UnsecuredLoan_Q1]
,[DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q2]
,[DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q3]
,[SUM_PAYMENT_VehicleLoan_Q1]
,[DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2]
,[DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3]
,[SUM_PAYMENT_Loan_Q1]
,[DFT_SUM_PAYMENT_Loan_Q1_Q2]
,[DFT_SUM_PAYMENT_Loan_Q1_Q3]
,[MAX_INTERESTRATE_RealEstate_Q1]
,[DFT_MAX_INTERESTRATE_RealEstate_Q1_Q2]
,[DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3]
,[MAX_INTERESTRATE_SecuredLoan_Q1]
,[DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q2]
,[DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3]
,[MAX_INTERESTRATE_UnsecuredLoan_Q1]
,[DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q2]
,[DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q3]
,[MAX_INTERESTRATE_VehicleLoan_Q1]
,[MAX_INTERESTRATE_Loan_Q1]
,[MAX_CREDITLIMIT_RealEstate_Q1]
,[MAX_CREDITLIMIT_SecuredLoan_Q1]
,[MAX_CREDITLIMIT_UnsecuredLoan_Q1]
,[MAX_CREDITLIMIT_VehicleLoan_Q1]
,[MAX_CREDITLIMIT_Loan_Q1]
,[COUNT_DUEDAY1_RealEstate_Q1]
,[COUNT_DUEDAY1_RealEstate_Q2]
,[COUNT_DUEDAY1_RealEstate_Q3]
,[COUNT_DUEDAY1_SecuredLoan_Q1]
,[COUNT_DUEDAY1_SecuredLoan_Q2]
,[COUNT_DUEDAY1_SecuredLoan_Q3]
,[COUNT_DUEDAY1_UnsecuredLoan_Q1]
,[COUNT_DUEDAY1_UnsecuredLoan_Q2]
,[COUNT_DUEDAY1_UnsecuredLoan_Q3]
,[COUNT_DUEDAY1_VehicleLoan_Q1]
,[COUNT_DUEDAY1_VehicleLoan_Q2]
,[COUNT_DUEDAY1_VehicleLoan_Q3]
,[COUNT_DUEDAY2_UnsecuredLoan_Q1]
,[COUNT_DUEDAY2_UnsecuredLoan_Q2]
,[COUNT_DUEDAY2_UnsecuredLoan_Q3]
,[RealEstate_Month_to_Maturity]
,[SecuredLoan_Month_to_Maturity]
,[UnsecuredLoan_Month_to_Maturity]
,[Vehicleloan_Month_to_Maturity]
,[Max_Loan_Month_to_Maturity]
,[Delinquency_RealEstate_SP]
,[Delinquency_SecuredLoan_SP]
,[Delinquency_UnsecuredLoan_SP]
,[Delinquency_Vehicleloan_SP]
,[Delinquency_Others_SP]
,[Delinquency_Loan_SP]
,[RealEstate_StaticPoolFlag]
,[SecuredLoan_StaticPoolFlag]
,[UnsecuredLoan_StaticPoolFlag]
,[VehicleLoan_StaticPoolFlag]
,[CREDIT_SCORE_SP]
,[DFT_CREDIT_SCORE_SP_Q4]
,[CreditCard_Q1Flag]
,[Last Statement payment Count_CC_Q1]
,[DFT_Last Statement payment Count_CC_Q1_Q2]
,[DFT_Last Statement payment Count_CC_Q1_Q3]
,[Last Statement payment Amount_CC_Q1]
,[DFT_Last Statement payment Amount_CC_Q1_Q2]
,[DFT_Last Statement payment Amount_CC_Q1_Q3]
,[Last Statement Sale Amount_CC_Q1]
,[DFT_Last Statement Sale Amount_CC_Q1_Q2]
,[DFT_Last Statement Sale Amount_CC_Q1_Q3]
,[Last Statement Cash Amount_CC_Q1]
,[DFT_Last Statement Cash amount_CC_Q1_Q2]
,[DFT_Last Statement Cash amount_CC_Q1_Q3]
,[Last Statement Sale Count_CC_Q1]
,[DFT_Last Statement Sale Count_CC_Q1_Q2]
,[DFT_Last Statement Sale Count_CC_Q1_Q3]
,[Last Statement Cash Advance Count_CC_Q1]
,[DFT_Last Statement Cash Advance Count_CC_Q1_Q2]
,[DFT_Last Statement Cash Advance Count_CC_Q1_Q3]
,[Last Statement Charge Late amount_CC_Q1]
,[DFT_Last Statement Charge late amount_CC_Q1_Q2]
,[DFT_Last Statement Charge late amount_CC_Q1_Q3]
,[Last Statement Charge cash amount_CC_Q1]
,[DFT_Last Statement Charge cash amount_CC_Q1_Q2]
,[DFT_Last Statement Charge cash amount_CC_Q1_Q3]
,[Last Statement Charge Sale amount_CC_Q1]
,[DFT_Last Statement Charge Sale amount_CC_Q1_Q2]
,[DFT_Last Statement Charge Sale amount_CC_Q1_Q3]
,[Last Statement cash Average Daily Balance amount_CC_Staticpool]
,[Last Statement cash Average Daily Balance amount_CC_Q1]
,[DFT_Last Statement cash Average Daily Balance amount_CC_Q1_Q2]
,[DFT_Last Statement cash Average Daily Balance amount_CC_Q1_Q3]
,[DFT_spend_CC_Q1_Q2]
,[DFT_spend_CC_Q1_Q3]
,[Protected_Balance_CC_Q1]
,[DFT_Protected_Balance_CC_Q1_Q2]
,[DFT_Protected_Balance_CC_Q1_Q3]
,[Promo_Balance_CC_Q1]
,[DFT_Promo_Balance_CC_Q1_Q2]
,[DFT_Promo_Balance_CC_Q1_Q3]
,[DFT_RevolvingBalance_CC_Q1_Q2]
,[DFT_RevolvingBalance_CC_Q1_Q3]
,[DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2]
,[DFT_AVG_UTILIZATION_RATE_CC_Q1_Q3]
,[CL_DIFF_past_oneyear]
,[Days Since Last Login]
,[FICO]
,[CCAPREstimate]
,[AggregatedSpendPast3Months]
,[TopOfWalletCCAnnualSpend]
,[TopOfWalletCCCurrentBalance]
,[OpenTradeCount]
,[OpenTradeBalance]
,[AutoOpenTradeCount]
,[AutoLoanOrgBalanceP12Months]
,[AutoOpenTradeBalance]
,[CCCount]
,[CCOpenCount]
,[CCTotalAvailableLOC]
,[CCOpenBalance]
,[ChargeOffTradeCountP12Months]
,[ChargeOffTotalBalance]
,[ForeclosureCountP12Months]
,[ForeclosureTotalBalance]
,[BankruptcyCount]
,[NumberInquiriesP6Months]
,[CCWorstRatingP12Months]
,[AutoWorstRatingP12Months]
,[MortgageWorstRatingP12Months]
,[HELOCWorstRatingP12Months]
,[HEWorstRatingP12Months]
,[HEOpenCount]
,[HETotalAvailableLOC]
,[HEOpenBalance]
,[HELOCOpenCount]
,[HELOCTotalAvailableLOC]
,[HELOCOpenBalance]
,[MortgageOpenCount]
,[MortgageOpenBalance]
,[RevolvingAccountCount]
,[CCRevolvingBalance]
,[StudentLoanOpenCount]
,[StudentLoanOpenBalance]
,[Target_flag]

	into [analytics].[brijesh].[CLD_2023_segmentation_Data_05252023_v2]
	from [analytics].[brijesh].[CLD_2023_segmentation_Data_05252023]





	select
	[Durable_Key]
,[Credit Limit]
,[mob]
,[External Status Code]
,[Internal Status Code]
,[Last Statement Balance Amount]
,[RevolvingBalance]
,[age]
,[spend]
,[TRIPFLAG]
,[Last Statement Payment Amount]
,[Times_1_cycle_delq_pre_12mo]
,[Times_2_cycle_delq_pre_12mo]
,[Times_overlimit_pre_12mo]
,[Times_5pc_overlimit_pre_12mo]
,[Times_cash_Advances_pre_12mo]
,[sum_spend_pre_12mo]
,[avg_revbal_pre_12mo]
,[avg_spend_pre_12mo]
,[avg_Utilization_pre_12mo]
,[avg_revolve_rate_pre_12mo]
,[avg_payment_rate_pre_12mo]
,[Times_1_cycle_delq_pre_6mo]
,[Times_2_cycle_delq_pre_6mo]
,[Times_overlimit_pre_6mo]
,[Times_5pc_overlimit_pre_6mo]
,[Times_cash_Advances_pre_6mo]
,[sum_spend_pre_6mo]
,[avg_revbal_pre_6mo]
,[avg_spend_pre_6mo]
,[avg_Utilization_pre_6mo]
,[avg_revolve_rate_pre_6mo]
,[avg_payment_rate_pre_6mo]
,[chgoff_flag_post_12mo]
,[chgoff_amt_post_12mo]
,[COUNT_DUEDAY1_RealEstate_Q1]
,[COUNT_DUEDAY1_RealEstate_Q2]
,[COUNT_DUEDAY1_RealEstate_Q3]
,[COUNT_DUEDAY1_SecuredLoan_Q1]
,[COUNT_DUEDAY1_SecuredLoan_Q2]
,[COUNT_DUEDAY1_SecuredLoan_Q3]
,[COUNT_DUEDAY1_UnsecuredLoan_Q1]
,[COUNT_DUEDAY1_UnsecuredLoan_Q2]
,[COUNT_DUEDAY1_UnsecuredLoan_Q3]
,[COUNT_DUEDAY1_VehicleLoan_Q1]
,[COUNT_DUEDAY1_VehicleLoan_Q2]
,[COUNT_DUEDAY1_VehicleLoan_Q3]
,[COUNT_DUEDAY2_UnsecuredLoan_Q1]
,[COUNT_DUEDAY2_UnsecuredLoan_Q2]
,[COUNT_DUEDAY2_UnsecuredLoan_Q3]
,[Delinquency_RealEstate_SP]
,[Delinquency_SecuredLoan_SP]
,[Delinquency_UnsecuredLoan_SP]
,[Delinquency_Vehicleloan_SP]
,[Delinquency_Others_SP]
,[Delinquency_Loan_SP]
,[CREDIT_SCORE_SP]
,[DFT_CREDIT_SCORE_SP_Q4]
,[DFT_spend_CC_Q1_Q2]
,[DFT_spend_CC_Q1_Q3]
,[DFT_RevolvingBalance_CC_Q1_Q2]
,[DFT_RevolvingBalance_CC_Q1_Q3]
,[DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2]
,[DFT_AVG_UTILIZATION_RATE_CC_Q1_Q3]
,[CL_DIFF_past_oneyear]
,[Days Since Last Login]
,[FICO]
,[CCAPREstimate]
,[AggregatedSpendPast3Months]
,[TopOfWalletCCAnnualSpend]
,[TopOfWalletCCCurrentBalance]
,[OpenTradeCount]
,[OpenTradeBalance]
,[AutoOpenTradeCount]
,[AutoLoanOrgBalanceP12Months]
,[AutoOpenTradeBalance]
,[CCCount]
,[CCOpenCount]
,[CCTotalAvailableLOC]
,[CCOpenBalance]
,[ChargeOffTradeCountP12Months]
,[ChargeOffTotalBalance]
,[ForeclosureCountP12Months]
,[ForeclosureTotalBalance]
,[BankruptcyCount]
,[NumberInquiriesP6Months]
,[CCWorstRatingP12Months]
,[AutoWorstRatingP12Months]
,[MortgageWorstRatingP12Months]
,[HELOCWorstRatingP12Months]
,[HEWorstRatingP12Months]
,[HEOpenCount]
,[HETotalAvailableLOC]
,[HEOpenBalance]
,[HELOCOpenCount]
,[HELOCTotalAvailableLOC]
,[HELOCOpenBalance]
,[MortgageOpenCount]
,[MortgageOpenBalance]
,[RevolvingAccountCount]
,[CCRevolvingBalance]
,[StudentLoanOpenCount]
,[StudentLoanOpenBalance]
,[Target_flag]

	into [analytics].[brijesh].[CLD_2023_segmentation_Data_05252023_v2_reduced]
	from [analytics].[brijesh].[CLD_2023_segmentation_Data_05252023_v2]
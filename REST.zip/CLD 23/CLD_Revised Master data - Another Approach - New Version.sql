--/****************************************************************************************************/
--/*       NOTES BEFORE USING THIS CODE                                                               */
--/*                                                                                                  */
--/*       EXCLUSION *                                                                                */
--/*      Workout & Writeoff (add it back in case you're using for Attrition)                         */
--/*                                                                                                  */
--/*                                                                                                  */
--/*      Included all IRA types (IRA Money Market , IRA Checking) execept "IRA SAVING"				  */
--/*      Included HSA                                                                                */                                                                                                
--/*                                                                                                  */
--/*       Updated :- (Added new Features related to Deposit)                                         */
--/*                                                                                                  */                                                                                                  
--/*                                                                                                  */
 --/****************************************************************************************************/
       --Declaring the STATIC POOL

		DECLARE @staticpooldate date
		set @staticpooldate = '2022-04-30'

		--Taking Member Having General membership of Greenstate

		drop table if exists #Name
		select distinct a.PARENTACCOUNT,SSN 
		into #NAME
		from 
		(select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date 
		from ARCUSYM000.dbo.NAME) a
		left join ARCUSYM000.dbo.SAVINGS b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		and a.ProcessDate=b.ProcessDate
		where a.TYPE=0
		and a.Process_date=@staticpooldate
		
		
		---- SAVING ACCOUNTS DETAIL
		 drop table if exists #Static_SSN_account_final
		select distinct  SSN 
		--,PARENTACCOUNT,Process_date
		into #Static_SSN_account_final
		from
		(    
			select  b.SSN
					,a.PARENTACCOUNT
					,id
					,cast(OPENDATE as date) OPEN_DATE
					,cast(CLOSEDATE as date) CLOSE_DATE
					,cast(CHARGEOFFDATE as date) CHARGEOFFDATE
					,left(a.ProcessDate,6) ProcessDate_V
					,datefromparts(left(a.ProcessDate ,4),right(left(a.ProcessDate,6),2),right(a.ProcessDate,2)) Process_date
					,case when len(month(closedate))=1 then CONCAT(year(closedate),0,month(closedate)) 
						  else CONCAT(year(closedate),month(closedate)) end CLOSED_DATE_SAVINGS 
					,case when len(month(OpenDate))=1 then CONCAT(year(OpenDate),0,month(OpenDate)) 
					      else CONCAT(year(OpenDate),month(OpenDate))end  OPEN_DATE_INT_SAVINGS
					,case when len(month(CHARGEOFFDATE))=1 then CONCAT(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE)) 
					      else CONCAT(year(CHARGEOFFDATE),month(CHARGEOFFDATE))end  CHARGEOFF_DATE_SAVINGS
		
			from ARCUSYM000.dbo.SAVINGS a
			left join #NAME b 
			on a.PARENTACCOUNT=b.PARENTACCOUNT
		) aa
		where ssn is not null 
			and OPEN_DATE<@staticpooldate  
			and (CLOSE_DATE is null or CLOSE_DATE>@staticpooldate)
			and (CHARGEOFFDATE is null or CHARGEOFFDATE>@staticpooldate)  
			and Process_date=@staticpooldate 
		
		
		-- Re-Naming ParentAccount to account name
		drop table if exists #Static_SSN_account
			select distinct 
				PARENTACCOUNT AccountNumber
				,SSN
			into #Static_SSN_account
			from #NAME

        ------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Loan Membership Master Data ***\\\-------------------------------------------------------------------
			 drop table if exists #membership_loan
			
			--select distinct parentaccount from #commercial_loan
			select 
				*
				,case when  (LoanCategory1 like 'commercial%')
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then  'Commercial_loan'
                 --when LoanCategory3 = '1st Mortgage'
				 --and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 --and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 --then 'Real_Estate_loan1'
				 --when LoanCategory3 = '2nd Mortgage'
				 --and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 --and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 --then 'Real_Estate_loan2'
				 when LoanCategory3 in ('1st Mortgage','2nd Mortgage')
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then 'Real_Estate_loan'
                when LoanCategory3 = 'Secured'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then 'SecuredLoan' 
                when LoanCategory3 = 'Unsecured'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				  then 'UnsecuredLoan' 
				when LoanCategory2 ='Vehicle'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				  then 'Vehicleloan' else 'Others' end as Product_Flag
							into #membership_loan
			from
			(
					select [ProcessDate]
						   ,left(ProcessDate,6) ProcessDate_V
						   ,Process_Date
						   ,Open_date
						   ,Close_date
						   ,case when Process_Date in (eomonth((DATEADD(month,-12,@staticpooldate))),(eomonth(DATEADD(month,-11,@staticpooldate))),(eomonth(DATEADD(month,-10,@staticpooldate) ))) then 'Q4'
		                         when Process_Date in (eomonth((DATEADD(month,-9,@staticpooldate ))),(eomonth(DATEADD(month,-8,@staticpooldate))) ,(eomonth(DATEADD(month,-7,@staticpooldate)))) then 'Q3'
 								 when Process_Date in (eomonth((DATEADD(month,-6,@staticpooldate ))),(eomonth(DATEADD(month,-5,@staticpooldate))) ,(eomonth(DATEADD(month,-4,@staticpooldate)))) then 'Q2'
								 when Process_Date in (eomonth((DATEADD(month,-3,@staticpooldate))) ,(eomonth(DATEADD(month,-2,@staticpooldate ))),(eomonth(DATEADD(month,-1,@staticpooldate )))) then 'Q1'
								 when Process_Date in (@staticpooldate) then 'Staticpool'
							end Quarters
							,d.SSN
							,[PARENTACCOUNT]
							,[ID]
							,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
							,case when len(month(a.closedate))=1 then CONCAT(year(a.closedate),0,month(a.closedate))
							      else CONCAT(year(a.closedate),month(a.closedate)) end  Closed_date_INT
							,case when len(month(a.opendate))=1 then CONCAT(year(a.opendate),0,month(a.opendate))
							      else CONCAT(year(a.opendate),month(a.opendate)) end  OPEN_date_INT
							,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
							,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
							,[TYPE]
							,[LASTFMDATE]
							,[LASTTRANDATE]
							,[ORIGINALDATE]
							,a.[OPENDATE]
							,a.[CLOSEDATE]
							,[LOANCODE]
							,[APPROVALCODE]
							,[APPROVALDATE]
							,[PAYMENTFREQUENCY]
							,[PARTIALPAYMENT]
							,[PAYMENT]
							,[PAYMENTCOUNT]
							,[DUEDAY1]
							,[DUEDAY2]
							,[INTERESTRATE]
							,[ORIGINALBALANCE]
							,BALANCE
							,[CREDITLIMIT]
							,[DESCRIPTION]
							,[NSFMONTHTODATE]
							,[MATURITYDATE]
							,[APR]
							,[CREDITSCORE]
							--,(BALANCE/CREDITLIMIT) [UTILIZATION_RATE]
							,[ADVANCEAMOUNT]
							,b.LoanCategory1
							,b.LoanCategory2
							,b.LoanCategory3
							,b.LoanCategory4
							,b.LoanCategory5
							,b.LoanTypeDescription
							,CRPMTCURRENT
					  from 
					 (
						 select * 
						 ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
						 ,cast(OPENDATE as date) Open_date
						 ,cast(CLOSEDATE as date) Close_date,cast(MATURITYDATE as date) as MATURITY_DATE 
						 from ARCUSYM000.dbo.LOAN 
				     ) a
			
					left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
					on b.loantype=a.TYPE
					left join  #Static_SSN_account d
					on a.PARENTACCOUNT=d.AccountNumber
					where  ORIGINALDATE is not null 
					and a.OpenDate is not null and a.Open_date < @staticpooldate  
					and (a.CLOSEDATE is null or a.Close_date>@staticpooldate )   
					and process_date between (select dateadd(MM,-12,@staticpooldate)) and (select dateadd(MM,12,@staticpooldate)) 
					and  PARENTACCOUNT in (select distinct AccountNumber PARENTACCOUNT from #Static_SSN_account )
		) AA
		where		LoanCategory3 not in ('Writeoff','Workout/TDR')
				    and LoanCategory4 not in ('Writeoff','Workout/TDR')
					and OPEN_DATE<@staticpooldate
					and (Close_date is null or Close_date>@staticpooldate) 
					and ORIGINALDATE <= Open_date 
					and Quarters is not null

		--SELECT count( ssn) FROM #membership_loan  -- 152347 out of 1944047 (On an Average Each member holds 12 product)

		-- SSN having loan accounts except  Credit Cards

		DROP TABLE IF EXISTS #loan_woCC

		SELECT DISTINCT SSN
		INTO #loan_woCC
		FROM #membership_loan -- 152345

-- Derived variables for product holdings for loan variables without Credit Card

		DROP TABLE IF EXISTS #loan_product_holdings
		--SELECT DISTINCT QUARTERS FROM #membership_loan
		--SELECT DISTINCT Product_Flag FROM #membership_loan
		SELECT SSN [SSN001]
			   ,#Products_CommercialLoan_Q1 [PRODUCT_CommercialLoan_Q1]
			   ,CASE WHEN (#Products_CommercialLoan_Q1 IS NULL AND #Products_CommercialLoan_Q2 IS  NULL) THEN #Products_CommercialLoan_Q1 else (ISNULL(#Products_CommercialLoan_Q1,0) - ISNULL(#Products_CommercialLoan_Q2,0)) end [DFT_PRODUCT_CommercialLoan_Q1_Q2]
			   ,CASE WHEN (#Products_CommercialLoan_Q1 IS NULL AND #Products_CommercialLoan_Q3 IS  NULL) THEN #Products_CommercialLoan_Q1 else (ISNULL(#Products_CommercialLoan_Q1,0) - ISNULL(#Products_CommercialLoan_Q3,0)) end [DFT_PRODUCT_CommercialLoan_Q1_Q3]
			   --,CASE WHEN (#Products_CommercialLoan_Q1 IS NULL AND #Products_CommercialLoan_Q4 IS  NULL) THEN #Products_CommercialLoan_Q1 else (ISNULL(#Products_CommercialLoan_Q1,0) - ISNULL(#Products_CommercialLoan_Q4,0)) end [DFT_PRODUCT_CommercialLoan_Q1_Q4]
			   ,#Products_RealEstate_Q1 [PRODUCT_RealEstate_Q1]
			   ,CASE WHEN (#Products_RealEstate_Q1 IS NULL AND #Products_RealEstate_Q2 IS  NULL) THEN #Products_RealEstate_Q1 else (ISNULL(#Products_RealEstate_Q1,0) - ISNULL(#Products_RealEstate_Q2,0)) end [DFT_PRODUCT_RealEstate_Q1_Q2]
			   ,CASE WHEN (#Products_RealEstate_Q1 IS NULL AND #Products_RealEstate_Q3 IS  NULL) THEN #Products_RealEstate_Q1 else (ISNULL(#Products_RealEstate_Q1,0) - ISNULL(#Products_RealEstate_Q3,0)) end [DFT_PRODUCT_RealEstate_Q1_Q3]
			   --,CASE WHEN (#Products_RealEstate_Q1 IS NULL AND #Products_RealEstate_Q4 IS  NULL) THEN #Products_RealEstate_Q1 else (ISNULL(#Products_RealEstate_Q1,0) - ISNULL(#Products_RealEstate_Q4,0)) end [DFT_PRODUCT_RealEstate_Q1_Q4]
			   ,#Products_SecuredLoan_Q1 [PRODUCT_SecuredLoan_Q1]
			   ,CASE WHEN (#Products_SecuredLoan_Q1 IS NULL AND #Products_SecuredLoan_Q2 IS  NULL) THEN #Products_SecuredLoan_Q1 else (ISNULL(#Products_SecuredLoan_Q1,0) - ISNULL(#Products_SecuredLoan_Q2,0)) end [DFT_PRODUCT_SecuredLoan_Q1_Q2]
			   ,CASE WHEN (#Products_SecuredLoan_Q1 IS NULL AND #Products_SecuredLoan_Q3 IS  NULL) THEN #Products_SecuredLoan_Q1 else (ISNULL(#Products_SecuredLoan_Q1,0) - ISNULL(#Products_SecuredLoan_Q3,0)) end [DFT_PRODUCT_SecuredLoan_Q1_Q3]
			   --,CASE WHEN (#Products_SecuredLoan_Q1 IS NULL AND #Products_SecuredLoan_Q4 IS  NULL) THEN #Products_SecuredLoan_Q1 else (ISNULL(#Products_SecuredLoan_Q1,0) - ISNULL(#Products_SecuredLoan_Q4,0)) end [DFT_PRODUCT_SecuredLoan_Q1_Q4]
			   ,#Products_UnsecuredLoan_Q1 [PRODUCT_UnsecuredLoan_Q1]
			   ,CASE WHEN (#Products_UnsecuredLoan_Q1 IS NULL AND #Products_UnsecuredLoan_Q2 IS  NULL) THEN #Products_UnsecuredLoan_Q1 else (ISNULL(#Products_UnsecuredLoan_Q1,0) - ISNULL(#Products_UnsecuredLoan_Q2,0)) end [DFT_PRODUCT_UnsecuredLoan_Q1_Q2]
			   ,CASE WHEN (#Products_UnsecuredLoan_Q1 IS NULL AND #Products_UnsecuredLoan_Q3 IS  NULL) THEN #Products_UnsecuredLoan_Q1 else (ISNULL(#Products_UnsecuredLoan_Q1,0) - ISNULL(#Products_UnsecuredLoan_Q3,0)) end [DFT_PRODUCT_UnsecuredLoan_Q1_Q3]
			   --,CASE WHEN (#Products_UnsecuredLoan_Q1 IS NULL AND #Products_UnsecuredLoan_Q4 IS  NULL) THEN #Products_UnsecuredLoan_Q1 else (ISNULL(#Products_UnsecuredLoan_Q1,0) - ISNULL(#Products_UnsecuredLoan_Q4,0)) end [DFT_PRODUCT_UnsecuredLoan_Q1_Q4]
			   ,#Products_VehicleLoan_Q1 [PRODUCT_VehicleLoan_Q1]
			   ,CASE WHEN (#Products_VehicleLoan_Q1 IS NULL AND #Products_VehicleLoan_Q2 IS  NULL) THEN #Products_VehicleLoan_Q1 else (ISNULL(#Products_VehicleLoan_Q1,0) - ISNULL(#Products_VehicleLoan_Q2,0)) end [DFT_PRODUCT_VehicleLoan_Q1_Q2]
			   ,CASE WHEN (#Products_VehicleLoan_Q1 IS NULL AND #Products_VehicleLoan_Q3 IS  NULL) THEN #Products_VehicleLoan_Q1 else (ISNULL(#Products_VehicleLoan_Q1,0) - ISNULL(#Products_VehicleLoan_Q3,0)) end [DFT_PRODUCT_VehicleLoan_Q1_Q3]
			   --,CASE WHEN (#Products_VehicleLoan_Q1 IS NULL AND #Products_VehicleLoan_Q4 IS  NULL) THEN #Products_VehicleLoan_Q1 else (ISNULL(#Products_VehicleLoan_Q1,0) - ISNULL(#Products_VehicleLoan_Q4,0)) end [DFT_PRODUCT_VehicleLoan_Q1_Q4]
			   ,#Products_Others_Q1 [PRODUCT_Others_Q1]
			   ,CASE WHEN (#Products_Others_Q1 IS NULL AND #Products_Others_Q2 IS  NULL) THEN #Products_Others_Q1 else (ISNULL(#Products_Others_Q1,0) - ISNULL(#Products_Others_Q2,0)) end [DFT_PRODUCT_Others_Q1_Q2]
			   ,CASE WHEN (#Products_Others_Q1 IS NULL AND #Products_Others_Q3 IS  NULL) THEN #Products_Others_Q1 else (ISNULL(#Products_Others_Q1,0) - ISNULL(#Products_Others_Q3,0)) end [DFT_PRODUCT_Others_Q1_Q3]
			   --,CASE WHEN (#Products_Others_Q1 IS NULL AND #Products_Others_Q4 IS  NULL) THEN #Products_Others_Q1 else (ISNULL(#Products_Others_Q1,0) - ISNULL(#Products_Others_Q4,0)) end [DFT_PRODUCT_Others_Q1_Q4]
			   ,#Products_Loan_Q1 [PRODUCT_Loan_Q1]
			   ,CASE WHEN (#Products_Loan_Q1 IS NULL AND #Products_Loan_Q2 IS  NULL) THEN #Products_Loan_Q1 else (ISNULL(#Products_Loan_Q1,0) - ISNULL(#Products_Loan_Q2,0)) end [DFT_PRODUCT_Loan_Q1_Q2]
			   ,CASE WHEN (#Products_Loan_Q1 IS NULL AND #Products_Loan_Q3 IS  NULL) THEN #Products_Loan_Q1 else (ISNULL(#Products_Loan_Q1,0) - ISNULL(#Products_Loan_Q3,0)) end [DFT_PRODUCT_Loan_Q1_Q3]

			   --,#Type_CommercialLoan_Q1 [TYPE_CommercialLoan_Q1]
			   --,CASE WHEN (#Type_CommercialLoan_Q1 IS NULL AND #Type_CommercialLoan_Q2 IS  NULL) THEN #Type_CommercialLoan_Q1 else (ISNULL(#Type_CommercialLoan_Q1,0) - ISNULL(#Type_CommercialLoan_Q2,0)) end [DFT_TYPE_CommercialLoan_Q1_Q2]
			   --,CASE WHEN (#Type_CommercialLoan_Q1 IS NULL AND #Type_CommercialLoan_Q3 IS  NULL) THEN #Type_CommercialLoan_Q1 else (ISNULL(#Type_CommercialLoan_Q1,0) - ISNULL(#Type_CommercialLoan_Q3,0)) end [DFT_TYPE_CommercialLoan_Q1_Q3]
			   ----,CASE WHEN (#Type_CommercialLoan_Q1 IS NULL AND #Type_CommercialLoan_Q4 IS  NULL) THEN #Type_CommercialLoan_Q1 else (ISNULL(#Type_CommercialLoan_Q1,0) - ISNULL(#Type_CommercialLoan_Q4,0)) end [DFT_TYPE_CommercialLoan_Q1_Q4]
			   --,#Type_RealEstate_Q1 [TYPE_RealEstate_Q1]
			   --,CASE WHEN (#Type_RealEstate_Q1 IS NULL AND #Type_RealEstate_Q2 IS  NULL) THEN #Type_RealEstate_Q1 else (ISNULL(#Type_RealEstate_Q1,0) - ISNULL(#Type_RealEstate_Q2,0)) end [DFT_TYPE_RealEstate_Q1_Q2]
			   --,CASE WHEN (#Type_RealEstate_Q1 IS NULL AND #Type_RealEstate_Q3 IS  NULL) THEN #Type_RealEstate_Q1 else (ISNULL(#Type_RealEstate_Q1,0) - ISNULL(#Type_RealEstate_Q3,0)) end [DFT_TYPE_RealEstate_Q1_Q3]
			   ----,CASE WHEN (#Type_RealEstate_Q1 IS NULL AND #Type_RealEstate_Q4 IS  NULL) THEN #Type_RealEstate_Q1 else (ISNULL(#Type_RealEstate_Q1,0) - ISNULL(#Type_RealEstate_Q4,0)) end [DFT_TYPE_RealEstate_Q1_Q4]
			   --,#Type_SecuredLoan_Q1 [TYPE_SecuredLoan_Q1]
			   --,CASE WHEN (#Type_SecuredLoan_Q1 IS NULL AND #Type_SecuredLoan_Q2 IS  NULL) THEN #Type_SecuredLoan_Q1 else (ISNULL(#Type_SecuredLoan_Q1,0) - ISNULL(#Type_SecuredLoan_Q2,0)) end [DFT_TYPE_SecuredLoan_Q1_Q2]
			   --,CASE WHEN (#Type_SecuredLoan_Q1 IS NULL AND #Type_SecuredLoan_Q3 IS  NULL) THEN #Type_SecuredLoan_Q1 else (ISNULL(#Type_SecuredLoan_Q1,0) - ISNULL(#Type_SecuredLoan_Q3,0)) end [DFT_TYPE_SecuredLoan_Q1_Q3]
			   ----,CASE WHEN (#Type_SecuredLoan_Q1 IS NULL AND #Type_SecuredLoan_Q4 IS  NULL) THEN #Type_SecuredLoan_Q1 else (ISNULL(#Type_SecuredLoan_Q1,0) - ISNULL(#Type_SecuredLoan_Q4,0)) end [DFT_TYPE_SecuredLoan_Q1_Q4]
			   --,#Type_UnsecuredLoan_Q1 [TYPE_UnsecuredLoan_Q1]
			   --,CASE WHEN (#Type_UnsecuredLoan_Q1 IS NULL AND #Type_UnsecuredLoan_Q2 IS  NULL) THEN #Type_UnsecuredLoan_Q1 else (ISNULL(#Type_UnsecuredLoan_Q1,0) - ISNULL(#Type_UnsecuredLoan_Q2,0)) end [DFT_TYPE_UnsecuredLoan_Q1_Q2]
			   --,CASE WHEN (#Type_UnsecuredLoan_Q1 IS NULL AND #Type_UnsecuredLoan_Q3 IS  NULL) THEN #Type_UnsecuredLoan_Q1 else (ISNULL(#Type_UnsecuredLoan_Q1,0) - ISNULL(#Type_UnsecuredLoan_Q3,0)) end [DFT_TYPE_UnsecuredLoan_Q1_Q3]
			   ----,CASE WHEN (#Type_UnsecuredLoan_Q1 IS NULL AND #Type_UnsecuredLoan_Q4 IS  NULL) THEN #Type_UnsecuredLoan_Q1 else (ISNULL(#Type_UnsecuredLoan_Q1,0) - ISNULL(#Type_UnsecuredLoan_Q4,0)) end [DFT_TYPE_UnsecuredLoan_Q1_Q4]
			   --,#Type_VehicleLoan_Q1 [TYPE_VehicleLoan_Q1]
			   --,CASE WHEN (#Type_VehicleLoan_Q1 IS NULL AND #Type_VehicleLoan_Q2 IS  NULL) THEN #Type_VehicleLoan_Q1 else (ISNULL(#Type_VehicleLoan_Q1,0) - ISNULL(#Type_VehicleLoan_Q2,0)) end [DFT_TYPE_VehicleLoan_Q1_Q2]
			   --,CASE WHEN (#Type_VehicleLoan_Q1 IS NULL AND #Type_VehicleLoan_Q3 IS  NULL) THEN #Type_VehicleLoan_Q1 else (ISNULL(#Type_VehicleLoan_Q1,0) - ISNULL(#Type_VehicleLoan_Q3,0)) end [DFT_TYPE_VehicleLoan_Q1_Q3]
			   ----,CASE WHEN (#Type_VehicleLoan_Q1 IS NULL AND #Type_VehicleLoan_Q4 IS  NULL) THEN #Type_VehicleLoan_Q1 else (ISNULL(#Type_VehicleLoan_Q1,0) - ISNULL(#Type_VehicleLoan_Q4,0)) end [DFT_TYPE_VehicleLoan_Q1_Q4]
			   --,#Type_Others_Q1 [TYPE_Others_Q1]
			   --,CASE WHEN (#Type_Others_Q1 IS NULL AND #Type_Others_Q2 IS  NULL) THEN #Type_Others_Q1 else (ISNULL(#Type_Others_Q1,0) - ISNULL(#Type_Others_Q2,0)) end [DFT_TYPE_Others_Q1_Q2]
			   --,CASE WHEN (#Type_Others_Q1 IS NULL AND #Type_Others_Q3 IS  NULL) THEN #Type_Others_Q1 else (ISNULL(#Type_Others_Q1,0) - ISNULL(#Type_Others_Q3,0)) end [DFT_TYPE_Others_Q1_Q3]
			   ----,CASE WHEN (#Type_Others_Q1 IS NULL AND #Type_Others_Q4 IS  NULL) THEN #Type_Others_Q1 else (ISNULL(#Type_Others_Q1,0) - ISNULL(#Type_Others_Q4,0)) end [DFT_TYPE_Others_Q1_Q4]
			   --,#Type_Loan_Q1 [TYPE_Loan_Q1]
			   --,CASE WHEN (#Type_Loan_Q1 IS NULL AND #Type_Loan_Q2 IS  NULL) THEN #Type_Loan_Q1 else (ISNULL(#Type_Loan_Q1,0) - ISNULL(#Type_Loan_Q2,0)) end [DFT_TYPE_Loan_Q1_Q2]
			   --,CASE WHEN (#Type_Loan_Q1 IS NULL AND #Type_Loan_Q3 IS  NULL) THEN #Type_Loan_Q1 else (ISNULL(#Type_Loan_Q1,0) - ISNULL(#Type_Loan_Q3,0)) end [DFT_TYPE_Loan_Q1_Q3]

				,[CommercialLoan_MOB]
				,[RealEstate_MOB]
				,[SecuredLoan_MOB]
				,[UnsecuredLoan_MOB]
				,[Vehicleloan_MOB]
				,[Others_MOB]
				,MAX_Loan_MOB

			   ,PAYMENTCOUNT_CommercialLoan_Q1 [PAYMENTCOUNT_CommercialLoan_Q1]
			   ,CASE WHEN (PAYMENTCOUNT_CommercialLoan_Q1 IS NULL AND PAYMENTCOUNT_CommercialLoan_Q2 IS  NULL) THEN PAYMENTCOUNT_CommercialLoan_Q1 else (ISNULL(PAYMENTCOUNT_CommercialLoan_Q1,0) - ISNULL(PAYMENTCOUNT_CommercialLoan_Q2,0)) end [DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q2]
			   ,CASE WHEN (PAYMENTCOUNT_CommercialLoan_Q1 IS NULL AND PAYMENTCOUNT_CommercialLoan_Q3 IS  NULL) THEN PAYMENTCOUNT_CommercialLoan_Q1 else (ISNULL(PAYMENTCOUNT_CommercialLoan_Q1,0) - ISNULL(PAYMENTCOUNT_CommercialLoan_Q3,0)) end [DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q3]
			   --,CASE WHEN (PAYMENTCOUNT_CommercialLoan_Q1 IS NULL AND PAYMENTCOUNT_CommercialLoan_Q4 IS  NULL) THEN PAYMENTCOUNT_CommercialLoan_Q1 else (ISNULL(PAYMENTCOUNT_CommercialLoan_Q1,0) - ISNULL(PAYMENTCOUNT_CommercialLoan_Q4,0)) end [DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q4]
			   ,PAYMENTCOUNT_RealEstate_Q1 [PAYMENTCOUNT_RealEstate_Q1]
			   ,CASE WHEN (PAYMENTCOUNT_RealEstate_Q1 IS NULL AND PAYMENTCOUNT_RealEstate_Q2 IS  NULL) THEN PAYMENTCOUNT_RealEstate_Q1 else (ISNULL(PAYMENTCOUNT_RealEstate_Q1,0) - ISNULL(PAYMENTCOUNT_RealEstate_Q2,0)) end [DFT_PAYMENTCOUNT_RealEstate_Q1_Q2]
			   ,CASE WHEN (PAYMENTCOUNT_RealEstate_Q1 IS NULL AND PAYMENTCOUNT_RealEstate_Q3 IS  NULL) THEN PAYMENTCOUNT_RealEstate_Q1 else (ISNULL(PAYMENTCOUNT_RealEstate_Q1,0) - ISNULL(PAYMENTCOUNT_RealEstate_Q3,0)) end [DFT_PAYMENTCOUNT_RealEstate_Q1_Q3]
			   --,CASE WHEN (PAYMENTCOUNT_RealEstate_Q1 IS NULL AND PAYMENTCOUNT_RealEstate_Q4 IS  NULL) THEN PAYMENTCOUNT_RealEstate_Q1 else (ISNULL(PAYMENTCOUNT_RealEstate_Q1,0) - ISNULL(PAYMENTCOUNT_RealEstate_Q4,0)) end [DFT_PAYMENTCOUNT_RealEstate_Q1_Q4]
			   ,PAYMENTCOUNT_SecuredLoan_Q1 [PAYMENTCOUNT_SecuredLoan_Q1]
			   ,CASE WHEN (PAYMENTCOUNT_SecuredLoan_Q1 IS NULL AND PAYMENTCOUNT_SecuredLoan_Q2 IS  NULL) THEN PAYMENTCOUNT_SecuredLoan_Q1 else (ISNULL(PAYMENTCOUNT_SecuredLoan_Q1,0) - ISNULL(PAYMENTCOUNT_SecuredLoan_Q2,0)) end [DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q2]
			   ,CASE WHEN (PAYMENTCOUNT_SecuredLoan_Q1 IS NULL AND PAYMENTCOUNT_SecuredLoan_Q3 IS  NULL) THEN PAYMENTCOUNT_SecuredLoan_Q1 else (ISNULL(PAYMENTCOUNT_SecuredLoan_Q1,0) - ISNULL(PAYMENTCOUNT_SecuredLoan_Q3,0)) end [DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q3]
			   --,CASE WHEN (PAYMENTCOUNT_SecuredLoan_Q1 IS NULL AND PAYMENTCOUNT_SecuredLoan_Q4 IS  NULL) THEN PAYMENTCOUNT_SecuredLoan_Q1 else (ISNULL(PAYMENTCOUNT_SecuredLoan_Q1,0) - ISNULL(PAYMENTCOUNT_SecuredLoan_Q4,0)) end [DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q4]
			   ,PAYMENTCOUNT_UnsecuredLoan_Q1 [PAYMENTCOUNT_UnsecuredLoan_Q1]
			   ,CASE WHEN (PAYMENTCOUNT_UnsecuredLoan_Q1 IS NULL AND PAYMENTCOUNT_UnsecuredLoan_Q2 IS  NULL) THEN PAYMENTCOUNT_UnsecuredLoan_Q1 else (ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q1,0) - ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q2,0)) end [DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q2]
			   ,CASE WHEN (PAYMENTCOUNT_UnsecuredLoan_Q1 IS NULL AND PAYMENTCOUNT_UnsecuredLoan_Q3 IS  NULL) THEN PAYMENTCOUNT_UnsecuredLoan_Q1 else (ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q1,0) - ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q3,0)) end [DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q3]
			   --,CASE WHEN (PAYMENTCOUNT_UnsecuredLoan_Q1 IS NULL AND PAYMENTCOUNT_UnsecuredLoan_Q4 IS  NULL) THEN PAYMENTCOUNT_UnsecuredLoan_Q1 else (ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q1,0) - ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q4,0)) end [DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q4]
			   ,PAYMENTCOUNT_VehicleLoan_Q1 [PAYMENTCOUNT_VehicleLoan_Q1]
			   ,CASE WHEN (PAYMENTCOUNT_VehicleLoan_Q1 IS NULL AND PAYMENTCOUNT_VehicleLoan_Q2 IS  NULL) THEN PAYMENTCOUNT_VehicleLoan_Q1 else (ISNULL(PAYMENTCOUNT_VehicleLoan_Q1,0) - ISNULL(PAYMENTCOUNT_VehicleLoan_Q2,0)) end [DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q2]
			   ,CASE WHEN (PAYMENTCOUNT_VehicleLoan_Q1 IS NULL AND PAYMENTCOUNT_VehicleLoan_Q3 IS  NULL) THEN PAYMENTCOUNT_VehicleLoan_Q1 else (ISNULL(PAYMENTCOUNT_VehicleLoan_Q1,0) - ISNULL(PAYMENTCOUNT_VehicleLoan_Q3,0)) end [DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q3]
			   --,CASE WHEN (PAYMENTCOUNT_VehicleLoan_Q1 IS NULL AND PAYMENTCOUNT_VehicleLoan_Q4 IS  NULL) THEN PAYMENTCOUNT_VehicleLoan_Q1 else (ISNULL(PAYMENTCOUNT_VehicleLoan_Q1,0) - ISNULL(PAYMENTCOUNT_VehicleLoan_Q4,0)) end [DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q4]
			   ,PAYMENTCOUNT_Others_Q1 [PAYMENTCOUNT_Others_Q1]
			   ,CASE WHEN (PAYMENTCOUNT_Others_Q1 IS NULL AND PAYMENTCOUNT_Others_Q2 IS  NULL) THEN PAYMENTCOUNT_Others_Q1 else (ISNULL(PAYMENTCOUNT_Others_Q1,0) - ISNULL(PAYMENTCOUNT_Others_Q2,0)) end [DFT_PAYMENTCOUNT_Others_Q1_Q2]
			   ,CASE WHEN (PAYMENTCOUNT_Others_Q1 IS NULL AND PAYMENTCOUNT_Others_Q3 IS  NULL) THEN PAYMENTCOUNT_Others_Q1 else (ISNULL(PAYMENTCOUNT_Others_Q1,0) - ISNULL(PAYMENTCOUNT_Others_Q3,0)) end [DFT_PAYMENTCOUNT_Others_Q1_Q3]
			   --,CASE WHEN (PAYMENTCOUNT_Others_Q1 IS NULL AND PAYMENTCOUNT_Others_Q4 IS  NULL) THEN PAYMENTCOUNT_Others_Q1 else (ISNULL(PAYMENTCOUNT_Others_Q1,0) - ISNULL(PAYMENTCOUNT_Others_Q4,0)) end [DFT_PAYMENTCOUNT_Others_Q1_Q4]
			   ,PAYMENTCOUNT_Loan_Q1 [PAYMENTCOUNT_Loan_Q1]
			   ,CASE WHEN (PAYMENTCOUNT_Loan_Q1 IS NULL AND PAYMENTCOUNT_Loan_Q2 IS  NULL) THEN PAYMENTCOUNT_Loan_Q1 else (ISNULL(PAYMENTCOUNT_Loan_Q1,0) - ISNULL(PAYMENTCOUNT_Loan_Q2,0)) end [DFT_PAYMENTCOUNT_Loan_Q1_Q2]
			   ,CASE WHEN (PAYMENTCOUNT_Loan_Q1 IS NULL AND PAYMENTCOUNT_Loan_Q3 IS  NULL) THEN PAYMENTCOUNT_Loan_Q1 else (ISNULL(PAYMENTCOUNT_Loan_Q1,0) - ISNULL(PAYMENTCOUNT_Loan_Q3,0)) end [DFT_PAYMENTCOUNT_Loan_Q1_Q3]

			   ,SUM_OriginalBalance_CommercialLoan_Q1 [SUM_OriginalBalance_CommercialLoan_Q1]
			   ,CASE WHEN (SUM_OriginalBalance_CommercialLoan_Q1 IS NULL AND SUM_OriginalBalance_CommercialLoan_Q2 IS  NULL) THEN SUM_OriginalBalance_CommercialLoan_Q1 else (ISNULL(SUM_OriginalBalance_CommercialLoan_Q1,0) - ISNULL(SUM_OriginalBalance_CommercialLoan_Q2,0)) end [DFT_SUM_OriginalBalance_CommercialLoan_Q1_Q2]
			   ,CASE WHEN (SUM_OriginalBalance_CommercialLoan_Q1 IS NULL AND SUM_OriginalBalance_CommercialLoan_Q3 IS  NULL) THEN SUM_OriginalBalance_CommercialLoan_Q1 else (ISNULL(SUM_OriginalBalance_CommercialLoan_Q1,0) - ISNULL(SUM_OriginalBalance_CommercialLoan_Q3,0)) end [DFT_SUM_OriginalBalance_CommercialLoan_Q1_Q3]
			   --,CASE WHEN (SUM_OriginalBalance_CommercialLoan_Q1 IS NULL AND SUM_OriginalBalance_CommercialLoan_Q4 IS  NULL) THEN SUM_OriginalBalance_CommercialLoan_Q1 else (ISNULL(SUM_OriginalBalance_CommercialLoan_Q1,0) - ISNULL(SUM_OriginalBalance_CommercialLoan_Q4,0)) end [DFT_SUM_OriginalBalance_CommercialLoan_Q1_Q4]
			   ,SUM_OriginalBalance_RealEstate_Q1 [SUM_OriginalBalance_RealEstate_Q1]
			   ,CASE WHEN (SUM_OriginalBalance_RealEstate_Q1 IS NULL AND SUM_OriginalBalance_RealEstate_Q2 IS  NULL) THEN SUM_OriginalBalance_RealEstate_Q1 else (ISNULL(SUM_OriginalBalance_RealEstate_Q1,0) - ISNULL(SUM_OriginalBalance_RealEstate_Q2,0)) end [DFT_SUM_OriginalBalance_RealEstate_Q1_Q2]
			   ,CASE WHEN (SUM_OriginalBalance_RealEstate_Q1 IS NULL AND SUM_OriginalBalance_RealEstate_Q3 IS  NULL) THEN SUM_OriginalBalance_RealEstate_Q1 else (ISNULL(SUM_OriginalBalance_RealEstate_Q1,0) - ISNULL(SUM_OriginalBalance_RealEstate_Q3,0)) end [DFT_SUM_OriginalBalance_RealEstate_Q1_Q3]
			   --,CASE WHEN (SUM_OriginalBalance_RealEstate_Q1 IS NULL AND SUM_OriginalBalance_RealEstate_Q4 IS  NULL) THEN SUM_OriginalBalance_RealEstate_Q1 else (ISNULL(SUM_OriginalBalance_RealEstate_Q1,0) - ISNULL(SUM_OriginalBalance_RealEstate_Q4,0)) end [DFT_SUM_OriginalBalance_RealEstate_Q1_Q4]
			   ,SUM_OriginalBalance_SecuredLoan_Q1 [SUM_OriginalBalance_SecuredLoan_Q1]
			   ,CASE WHEN (SUM_OriginalBalance_SecuredLoan_Q1 IS NULL AND SUM_OriginalBalance_SecuredLoan_Q2 IS  NULL) THEN SUM_OriginalBalance_SecuredLoan_Q1 else (ISNULL(SUM_OriginalBalance_SecuredLoan_Q1,0) - ISNULL(SUM_OriginalBalance_SecuredLoan_Q2,0)) end [DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q2]
			   ,CASE WHEN (SUM_OriginalBalance_SecuredLoan_Q1 IS NULL AND SUM_OriginalBalance_SecuredLoan_Q3 IS  NULL) THEN SUM_OriginalBalance_SecuredLoan_Q1 else (ISNULL(SUM_OriginalBalance_SecuredLoan_Q1,0) - ISNULL(SUM_OriginalBalance_SecuredLoan_Q3,0)) end [DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q3]
			   --,CASE WHEN (SUM_OriginalBalance_SecuredLoan_Q1 IS NULL AND SUM_OriginalBalance_SecuredLoan_Q4 IS  NULL) THEN SUM_OriginalBalance_SecuredLoan_Q1 else (ISNULL(SUM_OriginalBalance_SecuredLoan_Q1,0) - ISNULL(SUM_OriginalBalance_SecuredLoan_Q4,0)) end [DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q4]
			   ,SUM_OriginalBalance_UnsecuredLoan_Q1 [SUM_OriginalBalance_UnsecuredLoan_Q1]
			   ,CASE WHEN (SUM_OriginalBalance_UnsecuredLoan_Q1 IS NULL AND SUM_OriginalBalance_UnsecuredLoan_Q2 IS  NULL) THEN SUM_OriginalBalance_UnsecuredLoan_Q1 else (ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q1,0) - ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q2,0)) end [DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q2]
			   ,CASE WHEN (SUM_OriginalBalance_UnsecuredLoan_Q1 IS NULL AND SUM_OriginalBalance_UnsecuredLoan_Q3 IS  NULL) THEN SUM_OriginalBalance_UnsecuredLoan_Q1 else (ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q1,0) - ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q3,0)) end [DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q3]
			   --,CASE WHEN (SUM_OriginalBalance_UnsecuredLoan_Q1 IS NULL AND SUM_OriginalBalance_UnsecuredLoan_Q4 IS  NULL) THEN SUM_OriginalBalance_UnsecuredLoan_Q1 else (ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q1,0) - ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q4,0)) end [DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q4]
			   ,SUM_OriginalBalance_VehicleLoan_Q1 [SUM_OriginalBalance_VehicleLoan_Q1]
			   ,CASE WHEN (SUM_OriginalBalance_VehicleLoan_Q1 IS NULL AND SUM_OriginalBalance_VehicleLoan_Q2 IS  NULL) THEN SUM_OriginalBalance_VehicleLoan_Q1 else (ISNULL(SUM_OriginalBalance_VehicleLoan_Q1,0) - ISNULL(SUM_OriginalBalance_VehicleLoan_Q2,0)) end [DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q2]
			   ,CASE WHEN (SUM_OriginalBalance_VehicleLoan_Q1 IS NULL AND SUM_OriginalBalance_VehicleLoan_Q3 IS  NULL) THEN SUM_OriginalBalance_VehicleLoan_Q1 else (ISNULL(SUM_OriginalBalance_VehicleLoan_Q1,0) - ISNULL(SUM_OriginalBalance_VehicleLoan_Q3,0)) end [DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q3]
			   --,CASE WHEN (SUM_OriginalBalance_VehicleLoan_Q1 IS NULL AND SUM_OriginalBalance_VehicleLoan_Q4 IS  NULL) THEN SUM_OriginalBalance_VehicleLoan_Q1 else (ISNULL(SUM_OriginalBalance_VehicleLoan_Q1,0) - ISNULL(SUM_OriginalBalance_VehicleLoan_Q4,0)) end [DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q4]
			   ,SUM_OriginalBalance_Others_Q1 [SUM_OriginalBalance_Others_Q1]
			   ,CASE WHEN (SUM_OriginalBalance_Others_Q1 IS NULL AND SUM_OriginalBalance_Others_Q2 IS  NULL) THEN SUM_OriginalBalance_Others_Q1 else (ISNULL(SUM_OriginalBalance_Others_Q1,0) - ISNULL(SUM_OriginalBalance_Others_Q2,0)) end [DFT_SUM_OriginalBalance_Others_Q1_Q2]
			   ,CASE WHEN (SUM_OriginalBalance_Others_Q1 IS NULL AND SUM_OriginalBalance_Others_Q3 IS  NULL) THEN SUM_OriginalBalance_Others_Q1 else (ISNULL(SUM_OriginalBalance_Others_Q1,0) - ISNULL(SUM_OriginalBalance_Others_Q3,0)) end [DFT_SUM_OriginalBalance_Others_Q1_Q3]
			   --,CASE WHEN (SUM_OriginalBalance_Others_Q1 IS NULL AND SUM_OriginalBalance_Others_Q4 IS  NULL) THEN SUM_OriginalBalance_Others_Q1 else (ISNULL(SUM_OriginalBalance_Others_Q1,0) - ISNULL(SUM_OriginalBalance_Others_Q4,0)) end [DFT_SUM_OriginalBalance_Others_Q1_Q4]
			   ,SUM_OriginalBalance_Loan_Q1 [SUM_OriginalBalance_Loan_Q1]
			   ,CASE WHEN (SUM_OriginalBalance_Loan_Q1 IS NULL AND SUM_OriginalBalance_Loan_Q2 IS  NULL) THEN SUM_OriginalBalance_Loan_Q1 else (ISNULL(SUM_OriginalBalance_Loan_Q1,0) - ISNULL(SUM_OriginalBalance_Loan_Q2,0)) end [DFT_SUM_OriginalBalance_Loan_Q1_Q2]
			   ,CASE WHEN (SUM_OriginalBalance_Loan_Q1 IS NULL AND SUM_OriginalBalance_Loan_Q3 IS  NULL) THEN SUM_OriginalBalance_Loan_Q1 else (ISNULL(SUM_OriginalBalance_Loan_Q1,0) - ISNULL(SUM_OriginalBalance_Loan_Q3,0)) end [DFT_SUM_OriginalBalance_Loan_Q1_Q3]

			   ,SUM_PAYMENT_CommercialLoan_Q1 [SUM_PAYMENT_CommercialLoan_Q1]
			   ,CASE WHEN (SUM_PAYMENT_CommercialLoan_Q1 IS NULL AND SUM_PAYMENT_CommercialLoan_Q2 IS  NULL) THEN SUM_PAYMENT_CommercialLoan_Q1 else (ISNULL(SUM_PAYMENT_CommercialLoan_Q1,0) - ISNULL(SUM_PAYMENT_CommercialLoan_Q2,0)) end [DFT_SUM_PAYMENT_CommercialLoan_Q1_Q2]
			   ,CASE WHEN (SUM_PAYMENT_CommercialLoan_Q1 IS NULL AND SUM_PAYMENT_CommercialLoan_Q3 IS  NULL) THEN SUM_PAYMENT_CommercialLoan_Q1 else (ISNULL(SUM_PAYMENT_CommercialLoan_Q1,0) - ISNULL(SUM_PAYMENT_CommercialLoan_Q3,0)) end [DFT_SUM_PAYMENT_CommercialLoan_Q1_Q3]
			   --,CASE WHEN (SUM_PAYMENT_CommercialLoan_Q1 IS NULL AND SUM_PAYMENT_CommercialLoan_Q4 IS  NULL) THEN SUM_PAYMENT_CommercialLoan_Q1 else (ISNULL(SUM_PAYMENT_CommercialLoan_Q1,0) - ISNULL(SUM_PAYMENT_CommercialLoan_Q4,0)) end [DFT_SUM_PAYMENT_CommercialLoan_Q1_Q4]
			   ,SUM_PAYMENT_RealEstate_Q1 [SUM_PAYMENT_RealEstate_Q1]
			   ,CASE WHEN (SUM_PAYMENT_RealEstate_Q1 IS NULL AND SUM_PAYMENT_RealEstate_Q2 IS  NULL) THEN SUM_PAYMENT_RealEstate_Q1 else (ISNULL(SUM_PAYMENT_RealEstate_Q1,0) - ISNULL(SUM_PAYMENT_RealEstate_Q2,0)) end [DFT_SUM_PAYMENT_RealEstate_Q1_Q2]
			   ,CASE WHEN (SUM_PAYMENT_RealEstate_Q1 IS NULL AND SUM_PAYMENT_RealEstate_Q3 IS  NULL) THEN SUM_PAYMENT_RealEstate_Q1 else (ISNULL(SUM_PAYMENT_RealEstate_Q1,0) - ISNULL(SUM_PAYMENT_RealEstate_Q3,0)) end [DFT_SUM_PAYMENT_RealEstate_Q1_Q3]
			   --,CASE WHEN (SUM_PAYMENT_RealEstate_Q1 IS NULL AND SUM_PAYMENT_RealEstate_Q4 IS  NULL) THEN SUM_PAYMENT_RealEstate_Q1 else (ISNULL(SUM_PAYMENT_RealEstate_Q1,0) - ISNULL(SUM_PAYMENT_RealEstate_Q4,0)) end [DFT_SUM_PAYMENT_RealEstate_Q1_Q4]
			   ,SUM_PAYMENT_SecuredLoan_Q1 [SUM_PAYMENT_SecuredLoan_Q1]
			   ,CASE WHEN (SUM_PAYMENT_SecuredLoan_Q1 IS NULL AND SUM_PAYMENT_SecuredLoan_Q2 IS  NULL) THEN SUM_PAYMENT_SecuredLoan_Q1 else (ISNULL(SUM_PAYMENT_SecuredLoan_Q1,0) - ISNULL(SUM_PAYMENT_SecuredLoan_Q2,0)) end [DFT_SUM_PAYMENT_SecuredLoan_Q1_Q2]
			   ,CASE WHEN (SUM_PAYMENT_SecuredLoan_Q1 IS NULL AND SUM_PAYMENT_SecuredLoan_Q3 IS  NULL) THEN SUM_PAYMENT_SecuredLoan_Q1 else (ISNULL(SUM_PAYMENT_SecuredLoan_Q1,0) - ISNULL(SUM_PAYMENT_SecuredLoan_Q3,0)) end [DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3]
			   --,CASE WHEN (SUM_PAYMENT_SecuredLoan_Q1 IS NULL AND SUM_PAYMENT_SecuredLoan_Q4 IS  NULL) THEN SUM_PAYMENT_SecuredLoan_Q1 else (ISNULL(SUM_PAYMENT_SecuredLoan_Q1,0) - ISNULL(SUM_PAYMENT_SecuredLoan_Q4,0)) end [DFT_SUM_PAYMENT_SecuredLoan_Q1_Q4]
			   ,SUM_PAYMENT_UnsecuredLoan_Q1 [SUM_PAYMENT_UnsecuredLoan_Q1]
			   ,CASE WHEN (SUM_PAYMENT_UnsecuredLoan_Q1 IS NULL AND SUM_PAYMENT_UnsecuredLoan_Q2 IS  NULL) THEN SUM_PAYMENT_UnsecuredLoan_Q1 else (ISNULL(SUM_PAYMENT_UnsecuredLoan_Q1,0) - ISNULL(SUM_PAYMENT_UnsecuredLoan_Q2,0)) end [DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q2]
			   ,CASE WHEN (SUM_PAYMENT_UnsecuredLoan_Q1 IS NULL AND SUM_PAYMENT_UnsecuredLoan_Q3 IS  NULL) THEN SUM_PAYMENT_UnsecuredLoan_Q1 else (ISNULL(SUM_PAYMENT_UnsecuredLoan_Q1,0) - ISNULL(SUM_PAYMENT_UnsecuredLoan_Q3,0)) end [DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q3]
			   --,CASE WHEN (SUM_PAYMENT_UnsecuredLoan_Q1 IS NULL AND SUM_PAYMENT_UnsecuredLoan_Q4 IS  NULL) THEN SUM_PAYMENT_UnsecuredLoan_Q1 else (ISNULL(SUM_PAYMENT_UnsecuredLoan_Q1,0) - ISNULL(SUM_PAYMENT_UnsecuredLoan_Q4,0)) end [DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q4]
			   ,SUM_PAYMENT_VehicleLoan_Q1 [SUM_PAYMENT_VehicleLoan_Q1]
			   ,CASE WHEN (SUM_PAYMENT_VehicleLoan_Q1 IS NULL AND SUM_PAYMENT_VehicleLoan_Q2 IS  NULL) THEN SUM_PAYMENT_VehicleLoan_Q1 else (ISNULL(SUM_PAYMENT_VehicleLoan_Q1,0) - ISNULL(SUM_PAYMENT_VehicleLoan_Q2,0)) end [DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2]
			   ,CASE WHEN (SUM_PAYMENT_VehicleLoan_Q1 IS NULL AND SUM_PAYMENT_VehicleLoan_Q3 IS  NULL) THEN SUM_PAYMENT_VehicleLoan_Q1 else (ISNULL(SUM_PAYMENT_VehicleLoan_Q1,0) - ISNULL(SUM_PAYMENT_VehicleLoan_Q3,0)) end [DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3]
			   --,CASE WHEN (SUM_PAYMENT_VehicleLoan_Q1 IS NULL AND SUM_PAYMENT_VehicleLoan_Q4 IS  NULL) THEN SUM_PAYMENT_VehicleLoan_Q1 else (ISNULL(SUM_PAYMENT_VehicleLoan_Q1,0) - ISNULL(SUM_PAYMENT_VehicleLoan_Q4,0)) end [DFT_SUM_PAYMENT_VehicleLoan_Q1_Q4]
			   ,SUM_PAYMENT_Others_Q1 [SUM_PAYMENT_Others_Q1]
			   ,CASE WHEN (SUM_PAYMENT_Others_Q1 IS NULL AND SUM_PAYMENT_Others_Q2 IS  NULL) THEN SUM_PAYMENT_Others_Q1 else (ISNULL(SUM_PAYMENT_Others_Q1,0) - ISNULL(SUM_PAYMENT_Others_Q2,0)) end [DFT_SUM_PAYMENT_Others_Q1_Q2]
			   ,CASE WHEN (SUM_PAYMENT_Others_Q1 IS NULL AND SUM_PAYMENT_Others_Q3 IS  NULL) THEN SUM_PAYMENT_Others_Q1 else (ISNULL(SUM_PAYMENT_Others_Q1,0) - ISNULL(SUM_PAYMENT_Others_Q3,0)) end [DFT_SUM_PAYMENT_Others_Q1_Q3]
			   --,CASE WHEN (SUM_PAYMENT_Others_Q1 IS NULL AND SUM_PAYMENT_Others_Q4 IS  NULL) THEN SUM_PAYMENT_Others_Q1 else (ISNULL(SUM_PAYMENT_Others_Q1,0) - ISNULL(SUM_PAYMENT_Others_Q4,0)) end [DFT_SUM_PAYMENT_Others_Q1_Q4]
			   ,SUM_PAYMENT_Loan_Q1 [SUM_PAYMENT_Loan_Q1]
			   ,CASE WHEN (SUM_PAYMENT_Loan_Q1 IS NULL AND SUM_PAYMENT_Loan_Q2 IS  NULL) THEN SUM_PAYMENT_Loan_Q1 else (ISNULL(SUM_PAYMENT_Loan_Q1,0) - ISNULL(SUM_PAYMENT_Loan_Q2,0)) end [DFT_SUM_PAYMENT_Loan_Q1_Q2]
			   ,CASE WHEN (SUM_PAYMENT_Loan_Q1 IS NULL AND SUM_PAYMENT_Loan_Q3 IS  NULL) THEN SUM_PAYMENT_Loan_Q1 else (ISNULL(SUM_PAYMENT_Loan_Q1,0) - ISNULL(SUM_PAYMENT_Loan_Q3,0)) end [DFT_SUM_PAYMENT_Loan_Q1_Q3]

			   ,MAX_INTERESTRATE_CommercialLoan_Q1 [MAX_INTERESTRATE_CommercialLoan_Q1]
			   ,CASE WHEN (MAX_INTERESTRATE_CommercialLoan_Q1 IS NULL AND MAX_INTERESTRATE_CommercialLoan_Q2 IS  NULL) THEN MAX_INTERESTRATE_CommercialLoan_Q1 else (ISNULL(MAX_INTERESTRATE_CommercialLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_CommercialLoan_Q2,0)) end [DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q2]
			   ,CASE WHEN (MAX_INTERESTRATE_CommercialLoan_Q1 IS NULL AND MAX_INTERESTRATE_CommercialLoan_Q3 IS  NULL) THEN MAX_INTERESTRATE_CommercialLoan_Q1 else (ISNULL(MAX_INTERESTRATE_CommercialLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_CommercialLoan_Q3,0)) end [DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q3]
			   --,CASE WHEN (MAX_INTERESTRATE_CommercialLoan_Q1 IS NULL AND MAX_INTERESTRATE_CommercialLoan_Q4 IS  NULL) THEN MAX_INTERESTRATE_CommercialLoan_Q1 else (ISNULL(MAX_INTERESTRATE_CommercialLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_CommercialLoan_Q4,0)) end [DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q4]
			   ,MAX_INTERESTRATE_RealEstate_Q1 [MAX_INTERESTRATE_RealEstate_Q1]
			   ,CASE WHEN (MAX_INTERESTRATE_RealEstate_Q1 IS NULL AND MAX_INTERESTRATE_RealEstate_Q2 IS  NULL) THEN MAX_INTERESTRATE_RealEstate_Q1 else (ISNULL(MAX_INTERESTRATE_RealEstate_Q1,0) - ISNULL(MAX_INTERESTRATE_RealEstate_Q2,0)) end [DFT_MAX_INTERESTRATE_RealEstate_Q1_Q2]
			   ,CASE WHEN (MAX_INTERESTRATE_RealEstate_Q1 IS NULL AND MAX_INTERESTRATE_RealEstate_Q3 IS  NULL) THEN MAX_INTERESTRATE_RealEstate_Q1 else (ISNULL(MAX_INTERESTRATE_RealEstate_Q1,0) - ISNULL(MAX_INTERESTRATE_RealEstate_Q3,0)) end [DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3]
			   --,CASE WHEN (MAX_INTERESTRATE_RealEstate_Q1 IS NULL AND MAX_INTERESTRATE_RealEstate_Q4 IS  NULL) THEN MAX_INTERESTRATE_RealEstate_Q1 else (ISNULL(MAX_INTERESTRATE_RealEstate_Q1,0) - ISNULL(MAX_INTERESTRATE_RealEstate_Q4,0)) end [DFT_MAX_INTERESTRATE_RealEstate_Q1_Q4]
			   ,MAX_INTERESTRATE_SecuredLoan_Q1 [MAX_INTERESTRATE_SecuredLoan_Q1]
			   ,CASE WHEN (MAX_INTERESTRATE_SecuredLoan_Q1 IS NULL AND MAX_INTERESTRATE_SecuredLoan_Q2 IS  NULL) THEN MAX_INTERESTRATE_SecuredLoan_Q1 else (ISNULL(MAX_INTERESTRATE_SecuredLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_SecuredLoan_Q2,0)) end [DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q2]
			   ,CASE WHEN (MAX_INTERESTRATE_SecuredLoan_Q1 IS NULL AND MAX_INTERESTRATE_SecuredLoan_Q3 IS  NULL) THEN MAX_INTERESTRATE_SecuredLoan_Q1 else (ISNULL(MAX_INTERESTRATE_SecuredLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_SecuredLoan_Q3,0)) end [DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3]
			   --,CASE WHEN (MAX_INTERESTRATE_SecuredLoan_Q1 IS NULL AND MAX_INTERESTRATE_SecuredLoan_Q4 IS  NULL) THEN MAX_INTERESTRATE_SecuredLoan_Q1 else (ISNULL(MAX_INTERESTRATE_SecuredLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_SecuredLoan_Q4,0)) end [DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q4]
			   ,MAX_INTERESTRATE_UnsecuredLoan_Q1 [MAX_INTERESTRATE_UnsecuredLoan_Q1]
			   ,CASE WHEN (MAX_INTERESTRATE_UnsecuredLoan_Q1 IS NULL AND MAX_INTERESTRATE_UnsecuredLoan_Q2 IS  NULL) THEN MAX_INTERESTRATE_UnsecuredLoan_Q1 else (ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q2,0)) end [DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q2]
			   ,CASE WHEN (MAX_INTERESTRATE_UnsecuredLoan_Q1 IS NULL AND MAX_INTERESTRATE_UnsecuredLoan_Q3 IS  NULL) THEN MAX_INTERESTRATE_UnsecuredLoan_Q1 else (ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q3,0)) end [DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q3]
			   --,CASE WHEN (MAX_INTERESTRATE_UnsecuredLoan_Q1 IS NULL AND MAX_INTERESTRATE_UnsecuredLoan_Q4 IS  NULL) THEN MAX_INTERESTRATE_UnsecuredLoan_Q1 else (ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q4,0)) end [DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q4]
			   ,MAX_INTERESTRATE_VehicleLoan_Q1 [MAX_INTERESTRATE_VehicleLoan_Q1]
			   ,CASE WHEN (MAX_INTERESTRATE_VehicleLoan_Q1 IS NULL AND MAX_INTERESTRATE_VehicleLoan_Q2 IS  NULL) THEN MAX_INTERESTRATE_VehicleLoan_Q1 else (ISNULL(MAX_INTERESTRATE_VehicleLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_VehicleLoan_Q2,0)) end [DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q2]
			   ,CASE WHEN (MAX_INTERESTRATE_VehicleLoan_Q1 IS NULL AND MAX_INTERESTRATE_VehicleLoan_Q3 IS  NULL) THEN MAX_INTERESTRATE_VehicleLoan_Q1 else (ISNULL(MAX_INTERESTRATE_VehicleLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_VehicleLoan_Q3,0)) end [DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q3]
			   --,CASE WHEN (MAX_INTERESTRATE_VehicleLoan_Q1 IS NULL AND MAX_INTERESTRATE_VehicleLoan_Q4 IS  NULL) THEN MAX_INTERESTRATE_VehicleLoan_Q1 else (ISNULL(MAX_INTERESTRATE_VehicleLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_VehicleLoan_Q4,0)) end [DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q4]
			   ,MAX_INTERESTRATE_Others_Q1 [MAX_INTERESTRATE_Others_Q1]
			   ,CASE WHEN (MAX_INTERESTRATE_Others_Q1 IS NULL AND MAX_INTERESTRATE_Others_Q2 IS  NULL) THEN MAX_INTERESTRATE_Others_Q1 else (ISNULL(MAX_INTERESTRATE_Others_Q1,0) - ISNULL(MAX_INTERESTRATE_Others_Q2,0)) end [DFT_MAX_INTERESTRATE_Others_Q1_Q2]
			   ,CASE WHEN (MAX_INTERESTRATE_Others_Q1 IS NULL AND MAX_INTERESTRATE_Others_Q3 IS  NULL) THEN MAX_INTERESTRATE_Others_Q1 else (ISNULL(MAX_INTERESTRATE_Others_Q1,0) - ISNULL(MAX_INTERESTRATE_Others_Q3,0)) end [DFT_MAX_INTERESTRATE_Others_Q1_Q3]
			   --,CASE WHEN (MAX_INTERESTRATE_Others_Q1 IS NULL AND MAX_INTERESTRATE_Others_Q4 IS  NULL) THEN MAX_INTERESTRATE_Others_Q1 else (ISNULL(MAX_INTERESTRATE_Others_Q1,0) - ISNULL(MAX_INTERESTRATE_Others_Q4,0)) end [DFT_MAX_INTERESTRATE_Others_Q1_Q4]
			   ,MAX_INTERESTRATE_Loan_Q1 [MAX_INTERESTRATE_Loan_Q1]
			   ,CASE WHEN (MAX_INTERESTRATE_Loan_Q1 IS NULL AND MAX_INTERESTRATE_Loan_Q2 IS  NULL) THEN MAX_INTERESTRATE_Loan_Q1 else (ISNULL(MAX_INTERESTRATE_Loan_Q1,0) - ISNULL(MAX_INTERESTRATE_Loan_Q2,0)) end [DFT_MAX_INTERESTRATE_Loan_Q1_Q2]
			   ,CASE WHEN (MAX_INTERESTRATE_Loan_Q1 IS NULL AND MAX_INTERESTRATE_Loan_Q3 IS  NULL) THEN MAX_INTERESTRATE_Loan_Q1 else (ISNULL(MAX_INTERESTRATE_Loan_Q1,0) - ISNULL(MAX_INTERESTRATE_Loan_Q3,0)) end [DFT_MAX_INTERESTRATE_Loan_Q1_Q3]

			   ,MAX_CREDITLIMIT_CommercialLoan_Q1 [MAX_CREDITLIMIT_CommercialLoan_Q1]
			   ,CASE WHEN (MAX_CREDITLIMIT_CommercialLoan_Q1 IS NULL AND MAX_CREDITLIMIT_CommercialLoan_Q2 IS  NULL) THEN MAX_CREDITLIMIT_CommercialLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q2,0)) end [DFT_MAX_CREDITLIMIT_CommercialLoan_Q1_Q2]
			   ,CASE WHEN (MAX_CREDITLIMIT_CommercialLoan_Q1 IS NULL AND MAX_CREDITLIMIT_CommercialLoan_Q3 IS  NULL) THEN MAX_CREDITLIMIT_CommercialLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q3,0)) end [DFT_MAX_CREDITLIMIT_CommercialLoan_Q1_Q3]
			   --,CASE WHEN (MAX_CREDITLIMIT_CommercialLoan_Q1 IS NULL AND MAX_CREDITLIMIT_CommercialLoan_Q4 IS  NULL) THEN MAX_CREDITLIMIT_CommercialLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q4,0)) end [DFT_MAX_CREDITLIMIT_CommercialLoan_Q1_Q4]
			   ,MAX_CREDITLIMIT_RealEstate_Q1 [MAX_CREDITLIMIT_RealEstate_Q1]
			   ,CASE WHEN (MAX_CREDITLIMIT_RealEstate_Q1 IS NULL AND MAX_CREDITLIMIT_RealEstate_Q2 IS  NULL) THEN MAX_CREDITLIMIT_RealEstate_Q1 else (ISNULL(MAX_CREDITLIMIT_RealEstate_Q1,0) - ISNULL(MAX_CREDITLIMIT_RealEstate_Q2,0)) end [DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q2]
			   ,CASE WHEN (MAX_CREDITLIMIT_RealEstate_Q1 IS NULL AND MAX_CREDITLIMIT_RealEstate_Q3 IS  NULL) THEN MAX_CREDITLIMIT_RealEstate_Q1 else (ISNULL(MAX_CREDITLIMIT_RealEstate_Q1,0) - ISNULL(MAX_CREDITLIMIT_RealEstate_Q3,0)) end [DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q3]
			   --,CASE WHEN (MAX_CREDITLIMIT_RealEstate_Q1 IS NULL AND MAX_CREDITLIMIT_RealEstate_Q4 IS  NULL) THEN MAX_CREDITLIMIT_RealEstate_Q1 else (ISNULL(MAX_CREDITLIMIT_RealEstate_Q1,0) - ISNULL(MAX_CREDITLIMIT_RealEstate_Q4,0)) end [DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q4]
			   ,MAX_CREDITLIMIT_SecuredLoan_Q1 [MAX_CREDITLIMIT_SecuredLoan_Q1]
			   ,CASE WHEN (MAX_CREDITLIMIT_SecuredLoan_Q1 IS NULL AND MAX_CREDITLIMIT_SecuredLoan_Q2 IS  NULL) THEN MAX_CREDITLIMIT_SecuredLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q2,0)) end [DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q2]
			   ,CASE WHEN (MAX_CREDITLIMIT_SecuredLoan_Q1 IS NULL AND MAX_CREDITLIMIT_SecuredLoan_Q3 IS  NULL) THEN MAX_CREDITLIMIT_SecuredLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q3,0)) end [DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q3]
			   --,CASE WHEN (MAX_CREDITLIMIT_SecuredLoan_Q1 IS NULL AND MAX_CREDITLIMIT_SecuredLoan_Q4 IS  NULL) THEN MAX_CREDITLIMIT_SecuredLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q4,0)) end [DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q4]
			   ,MAX_CREDITLIMIT_UnsecuredLoan_Q1 [MAX_CREDITLIMIT_UnsecuredLoan_Q1]
			   ,CASE WHEN (MAX_CREDITLIMIT_UnsecuredLoan_Q1 IS NULL AND MAX_CREDITLIMIT_UnsecuredLoan_Q2 IS  NULL) THEN MAX_CREDITLIMIT_UnsecuredLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q2,0)) end [DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q2]
			   ,CASE WHEN (MAX_CREDITLIMIT_UnsecuredLoan_Q1 IS NULL AND MAX_CREDITLIMIT_UnsecuredLoan_Q3 IS  NULL) THEN MAX_CREDITLIMIT_UnsecuredLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q3,0)) end [DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q3]
			   --,CASE WHEN (MAX_CREDITLIMIT_UnsecuredLoan_Q1 IS NULL AND MAX_CREDITLIMIT_UnsecuredLoan_Q4 IS  NULL) THEN MAX_CREDITLIMIT_UnsecuredLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q4,0)) end [DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q4]
			   ,MAX_CREDITLIMIT_VehicleLoan_Q1 [MAX_CREDITLIMIT_VehicleLoan_Q1]
			   ,CASE WHEN (MAX_CREDITLIMIT_VehicleLoan_Q1 IS NULL AND MAX_CREDITLIMIT_VehicleLoan_Q2 IS  NULL) THEN MAX_CREDITLIMIT_VehicleLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q2,0)) end [DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q2]
			   ,CASE WHEN (MAX_CREDITLIMIT_VehicleLoan_Q1 IS NULL AND MAX_CREDITLIMIT_VehicleLoan_Q3 IS  NULL) THEN MAX_CREDITLIMIT_VehicleLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q3,0)) end [DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q3]
			   --,CASE WHEN (MAX_CREDITLIMIT_VehicleLoan_Q1 IS NULL AND MAX_CREDITLIMIT_VehicleLoan_Q4 IS  NULL) THEN MAX_CREDITLIMIT_VehicleLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q4,0)) end [DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q4]
			   ,MAX_CREDITLIMIT_Others_Q1 [MAX_CREDITLIMIT_Others_Q1]
			   ,CASE WHEN (MAX_CREDITLIMIT_Others_Q1 IS NULL AND MAX_CREDITLIMIT_Others_Q2 IS  NULL) THEN MAX_CREDITLIMIT_Others_Q1 else (ISNULL(MAX_CREDITLIMIT_Others_Q1,0) - ISNULL(MAX_CREDITLIMIT_Others_Q2,0)) end [DFT_MAX_CREDITLIMIT_Others_Q1_Q2]
			   ,CASE WHEN (MAX_CREDITLIMIT_Others_Q1 IS NULL AND MAX_CREDITLIMIT_Others_Q3 IS  NULL) THEN MAX_CREDITLIMIT_Others_Q1 else (ISNULL(MAX_CREDITLIMIT_Others_Q1,0) - ISNULL(MAX_CREDITLIMIT_Others_Q3,0)) end [DFT_MAX_CREDITLIMIT_Others_Q1_Q3]
			   --,CASE WHEN (MAX_CREDITLIMIT_Others_Q1 IS NULL AND MAX_CREDITLIMIT_Others_Q4 IS  NULL) THEN MAX_CREDITLIMIT_Others_Q1 else (ISNULL(MAX_CREDITLIMIT_Others_Q1,0) - ISNULL(MAX_CREDITLIMIT_Others_Q4,0)) end [DFT_MAX_CREDITLIMIT_Others_Q1_Q4]
			   ,MAX_CREDITLIMIT_Loan_Q1 [MAX_CREDITLIMIT_Loan_Q1]
			   ,CASE WHEN (MAX_CREDITLIMIT_Loan_Q1 IS NULL AND MAX_CREDITLIMIT_Loan_Q2 IS  NULL) THEN MAX_CREDITLIMIT_Loan_Q1 else (ISNULL(MAX_CREDITLIMIT_Loan_Q1,0) - ISNULL(MAX_CREDITLIMIT_Loan_Q2,0)) end [DFT_MAX_CREDITLIMIT_Loan_Q1_Q2]
			   ,CASE WHEN (MAX_CREDITLIMIT_Loan_Q1 IS NULL AND MAX_CREDITLIMIT_Loan_Q3 IS  NULL) THEN MAX_CREDITLIMIT_Loan_Q1 else (ISNULL(MAX_CREDITLIMIT_Loan_Q1,0) - ISNULL(MAX_CREDITLIMIT_Loan_Q3,0)) end [DFT_MAX_CREDITLIMIT_Loan_Q1_Q3]

			   --,AVG_UTILIZATION_RATE_CommercialLoan_Q1 [AVG_UTILIZATION_RATE_CommercialLoan_Q1]
			   --,CASE WHEN (AVG_UTILIZATION_RATE_CommercialLoan_Q1 IS NULL AND AVG_UTILIZATION_RATE_CommercialLoan_Q2 IS  NULL) THEN AVG_UTILIZATION_RATE_CommercialLoan_Q1 else (ISNULL(AVG_UTILIZATION_RATE_CommercialLoan_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_CommercialLoan_Q2,0)) end [DFT_AVG_UTILIZATION_RATE_CommercialLoan_Q1_Q2]
			   --,CASE WHEN (AVG_UTILIZATION_RATE_CommercialLoan_Q1 IS NULL AND AVG_UTILIZATION_RATE_CommercialLoan_Q3 IS  NULL) THEN AVG_UTILIZATION_RATE_CommercialLoan_Q1 else (ISNULL(AVG_UTILIZATION_RATE_CommercialLoan_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_CommercialLoan_Q3,0)) end [DFT_AVG_UTILIZATION_RATE_CommercialLoan_Q1_Q3]
			   ----,CASE WHEN (AVG_UTILIZATION_RATE_CommercialLoan_Q1 IS NULL AND AVG_UTILIZATION_RATE_CommercialLoan_Q4 IS  NULL) THEN AVG_UTILIZATION_RATE_CommercialLoan_Q1 else (ISNULL(AVG_UTILIZATION_RATE_CommercialLoan_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_CommercialLoan_Q4,0)) end [DFT_AVG_UTILIZATION_RATE_CommercialLoan_Q1_Q4]
			   --,AVG_UTILIZATION_RATE_RealEstate_Q1 [AVG_UTILIZATION_RATE_RealEstate_Q1]
			   --,CASE WHEN (AVG_UTILIZATION_RATE_RealEstate_Q1 IS NULL AND AVG_UTILIZATION_RATE_RealEstate_Q2 IS  NULL) THEN AVG_UTILIZATION_RATE_RealEstate_Q1 else (ISNULL(AVG_UTILIZATION_RATE_RealEstate_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_RealEstate_Q2,0)) end [DFT_AVG_UTILIZATION_RATE_RealEstate_Q1_Q2]
			   --,CASE WHEN (AVG_UTILIZATION_RATE_RealEstate_Q1 IS NULL AND AVG_UTILIZATION_RATE_RealEstate_Q3 IS  NULL) THEN AVG_UTILIZATION_RATE_RealEstate_Q1 else (ISNULL(AVG_UTILIZATION_RATE_RealEstate_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_RealEstate_Q3,0)) end [DFT_AVG_UTILIZATION_RATE_RealEstate_Q1_Q3]
			   ----,CASE WHEN (AVG_UTILIZATION_RATE_RealEstate_Q1 IS NULL AND AVG_UTILIZATION_RATE_RealEstate_Q4 IS  NULL) THEN AVG_UTILIZATION_RATE_RealEstate_Q1 else (ISNULL(AVG_UTILIZATION_RATE_RealEstate_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_RealEstate_Q4,0)) end [DFT_AVG_UTILIZATION_RATE_RealEstate_Q1_Q4]
			   --,AVG_UTILIZATION_RATE_SecuredLoan_Q1 [AVG_UTILIZATION_RATE_SecuredLoan_Q1]
			   --,CASE WHEN (AVG_UTILIZATION_RATE_SecuredLoan_Q1 IS NULL AND AVG_UTILIZATION_RATE_SecuredLoan_Q2 IS  NULL) THEN AVG_UTILIZATION_RATE_SecuredLoan_Q1 else (ISNULL(AVG_UTILIZATION_RATE_SecuredLoan_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_SecuredLoan_Q2,0)) end [DFT_AVG_UTILIZATION_RATE_SecuredLoan_Q1_Q2]
			   --,CASE WHEN (AVG_UTILIZATION_RATE_SecuredLoan_Q1 IS NULL AND AVG_UTILIZATION_RATE_SecuredLoan_Q3 IS  NULL) THEN AVG_UTILIZATION_RATE_SecuredLoan_Q1 else (ISNULL(AVG_UTILIZATION_RATE_SecuredLoan_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_SecuredLoan_Q3,0)) end [DFT_AVG_UTILIZATION_RATE_SecuredLoan_Q1_Q3]
			   ----,CASE WHEN (AVG_UTILIZATION_RATE_SecuredLoan_Q1 IS NULL AND AVG_UTILIZATION_RATE_SecuredLoan_Q4 IS  NULL) THEN AVG_UTILIZATION_RATE_SecuredLoan_Q1 else (ISNULL(AVG_UTILIZATION_RATE_SecuredLoan_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_SecuredLoan_Q4,0)) end [DFT_AVG_UTILIZATION_RATE_SecuredLoan_Q1_Q4]
			   --,AVG_UTILIZATION_RATE_UnsecuredLoan_Q1 [AVG_UTILIZATION_RATE_UnsecuredLoan_Q1]
			   --,CASE WHEN (AVG_UTILIZATION_RATE_UnsecuredLoan_Q1 IS NULL AND AVG_UTILIZATION_RATE_UnsecuredLoan_Q2 IS  NULL) THEN AVG_UTILIZATION_RATE_UnsecuredLoan_Q1 else (ISNULL(AVG_UTILIZATION_RATE_UnsecuredLoan_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_UnsecuredLoan_Q2,0)) end [DFT_AVG_UTILIZATION_RATE_UnsecuredLoan_Q1_Q2]
			   --,CASE WHEN (AVG_UTILIZATION_RATE_UnsecuredLoan_Q1 IS NULL AND AVG_UTILIZATION_RATE_UnsecuredLoan_Q3 IS  NULL) THEN AVG_UTILIZATION_RATE_UnsecuredLoan_Q1 else (ISNULL(AVG_UTILIZATION_RATE_UnsecuredLoan_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_UnsecuredLoan_Q3,0)) end [DFT_AVG_UTILIZATION_RATE_UnsecuredLoan_Q1_Q3]
			   ----,CASE WHEN (AVG_UTILIZATION_RATE_UnsecuredLoan_Q1 IS NULL AND AVG_UTILIZATION_RATE_UnsecuredLoan_Q4 IS  NULL) THEN AVG_UTILIZATION_RATE_UnsecuredLoan_Q1 else (ISNULL(AVG_UTILIZATION_RATE_UnsecuredLoan_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_UnsecuredLoan_Q4,0)) end [DFT_AVG_UTILIZATION_RATE_UnsecuredLoan_Q1_Q4]
			   --,AVG_UTILIZATION_RATE_VehicleLoan_Q1 [AVG_UTILIZATION_RATE_VehicleLoan_Q1]
			   --,CASE WHEN (AVG_UTILIZATION_RATE_VehicleLoan_Q1 IS NULL AND AVG_UTILIZATION_RATE_VehicleLoan_Q2 IS  NULL) THEN AVG_UTILIZATION_RATE_VehicleLoan_Q1 else (ISNULL(AVG_UTILIZATION_RATE_VehicleLoan_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_VehicleLoan_Q2,0)) end [DFT_AVG_UTILIZATION_RATE_VehicleLoan_Q1_Q2]
			   --,CASE WHEN (AVG_UTILIZATION_RATE_VehicleLoan_Q1 IS NULL AND AVG_UTILIZATION_RATE_VehicleLoan_Q3 IS  NULL) THEN AVG_UTILIZATION_RATE_VehicleLoan_Q1 else (ISNULL(AVG_UTILIZATION_RATE_VehicleLoan_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_VehicleLoan_Q3,0)) end [DFT_AVG_UTILIZATION_RATE_VehicleLoan_Q1_Q3]
			   ----,CASE WHEN (AVG_UTILIZATION_RATE_VehicleLoan_Q1 IS NULL AND AVG_UTILIZATION_RATE_VehicleLoan_Q4 IS  NULL) THEN AVG_UTILIZATION_RATE_VehicleLoan_Q1 else (ISNULL(AVG_UTILIZATION_RATE_VehicleLoan_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_VehicleLoan_Q4,0)) end [DFT_AVG_UTILIZATION_RATE_VehicleLoan_Q1_Q4]
			   --,AVG_UTILIZATION_RATE_Others_Q1 [AVG_UTILIZATION_RATE_Others_Q1]
			   --,CASE WHEN (AVG_UTILIZATION_RATE_Others_Q1 IS NULL AND AVG_UTILIZATION_RATE_Others_Q2 IS  NULL) THEN AVG_UTILIZATION_RATE_Others_Q1 else (ISNULL(AVG_UTILIZATION_RATE_Others_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_Others_Q2,0)) end [DFT_AVG_UTILIZATION_RATE_Others_Q1_Q2]
			   --,CASE WHEN (AVG_UTILIZATION_RATE_Others_Q1 IS NULL AND AVG_UTILIZATION_RATE_Others_Q3 IS  NULL) THEN AVG_UTILIZATION_RATE_Others_Q1 else (ISNULL(AVG_UTILIZATION_RATE_Others_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_Others_Q3,0)) end [DFT_AVG_UTILIZATION_RATE_Others_Q1_Q3]
			   ----,CASE WHEN (AVG_UTILIZATION_RATE_Others_Q1 IS NULL AND AVG_UTILIZATION_RATE_Others_Q4 IS  NULL) THEN AVG_UTILIZATION_RATE_Others_Q1 else (ISNULL(AVG_UTILIZATION_RATE_Others_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_Others_Q4,0)) end [DFT_AVG_UTILIZATION_RATE_Others_Q1_Q4]
			   --,AVG_UTILIZATION_RATE_Loan_Q1 [AVG_UTILIZATION_RATE_Loan_Q1]
			   --,CASE WHEN (AVG_UTILIZATION_RATE_Loan_Q1 IS NULL AND AVG_UTILIZATION_RATE_Loan_Q2 IS  NULL) THEN AVG_UTILIZATION_RATE_Loan_Q1 else (ISNULL(AVG_UTILIZATION_RATE_Loan_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_Loan_Q2,0)) end [DFT_AVG_UTILIZATION_RATE_Loan_Q1_Q2]
			   --,CASE WHEN (AVG_UTILIZATION_RATE_Loan_Q1 IS NULL AND AVG_UTILIZATION_RATE_Loan_Q3 IS  NULL) THEN AVG_UTILIZATION_RATE_Loan_Q1 else (ISNULL(AVG_UTILIZATION_RATE_Loan_Q1,0) - ISNULL(AVG_UTILIZATION_RATE_Loan_Q3,0)) end [DFT_AVG_UTILIZATION_RATE_Loan_Q1_Q3]

			   ,ISNULL(COUNT_DUEDAY1_CommercialLoan_Q1,0) [COUNT_DUEDAY1_CommercialLoan_Q1]
			   ,ISNULL(COUNT_DUEDAY1_CommercialLoan_Q2,0) [COUNT_DUEDAY1_CommercialLoan_Q2]
			   ,ISNULL(COUNT_DUEDAY1_CommercialLoan_Q3,0) [COUNT_DUEDAY1_CommercialLoan_Q3]

			   ,ISNULL(COUNT_DUEDAY1_RealEstate_Q1,0) [COUNT_DUEDAY1_RealEstate_Q1]
			   ,ISNULL(COUNT_DUEDAY1_RealEstate_Q2,0) [COUNT_DUEDAY1_RealEstate_Q2]
			   ,ISNULL(COUNT_DUEDAY1_RealEstate_Q3,0) [COUNT_DUEDAY1_RealEstate_Q3]

			   ,ISNULL(COUNT_DUEDAY1_SecuredLoan_Q1,0) [COUNT_DUEDAY1_SecuredLoan_Q1]
			   ,ISNULL(COUNT_DUEDAY1_SecuredLoan_Q2,0) [COUNT_DUEDAY1_SecuredLoan_Q2]
			   ,ISNULL(COUNT_DUEDAY1_SecuredLoan_Q3,0) [COUNT_DUEDAY1_SecuredLoan_Q3]

			   ,ISNULL(COUNT_DUEDAY1_UnsecuredLoan_Q1,0) [COUNT_DUEDAY1_UnsecuredLoan_Q1]
			   ,ISNULL(COUNT_DUEDAY1_UnsecuredLoan_Q2,0) [COUNT_DUEDAY1_UnsecuredLoan_Q2]
			   ,ISNULL(COUNT_DUEDAY1_UnsecuredLoan_Q3,0) [COUNT_DUEDAY1_UnsecuredLoan_Q3]

			   ,ISNULL(COUNT_DUEDAY1_VehicleLoan_Q1,0) [COUNT_DUEDAY1_VehicleLoan_Q1]
			   ,ISNULL(COUNT_DUEDAY1_VehicleLoan_Q2,0) [COUNT_DUEDAY1_VehicleLoan_Q2]
			   ,ISNULL(COUNT_DUEDAY1_VehicleLoan_Q3,0) [COUNT_DUEDAY1_VehicleLoan_Q3]

			   ,ISNULL(COUNT_DUEDAY1_Others_Q1,0) [COUNT_DUEDAY1_Others_Q1]
			   ,ISNULL(COUNT_DUEDAY1_Others_Q2,0) [COUNT_DUEDAY1_Others_Q2]
			   ,ISNULL(COUNT_DUEDAY1_Others_Q3,0) [COUNT_DUEDAY1_Others_Q3]


			   ,ISNULL(COUNT_DUEDAY2_CommercialLoan_Q1,0) [COUNT_DUEDAY2_CommercialLoan_Q1]
			   ,ISNULL(COUNT_DUEDAY2_CommercialLoan_Q2,0) [COUNT_DUEDAY2_CommercialLoan_Q2]
			   ,ISNULL(COUNT_DUEDAY2_CommercialLoan_Q3,0) [COUNT_DUEDAY2_CommercialLoan_Q3]

			   ,ISNULL(COUNT_DUEDAY2_RealEstate_Q1,0) [COUNT_DUEDAY2_RealEstate_Q1]
			   ,ISNULL(COUNT_DUEDAY2_RealEstate_Q2,0) [COUNT_DUEDAY2_RealEstate_Q2]
			   ,ISNULL(COUNT_DUEDAY2_RealEstate_Q3,0) [COUNT_DUEDAY2_RealEstate_Q3]

			   ,ISNULL(COUNT_DUEDAY2_SecuredLoan_Q1,0) [COUNT_DUEDAY2_SecuredLoan_Q1]
			   ,ISNULL(COUNT_DUEDAY2_SecuredLoan_Q2,0) [COUNT_DUEDAY2_SecuredLoan_Q2]
			   ,ISNULL(COUNT_DUEDAY2_SecuredLoan_Q3,0) [COUNT_DUEDAY2_SecuredLoan_Q3]

			   ,ISNULL(COUNT_DUEDAY2_UnsecuredLoan_Q1,0) [COUNT_DUEDAY2_UnsecuredLoan_Q1]
			   ,ISNULL(COUNT_DUEDAY2_UnsecuredLoan_Q2,0) [COUNT_DUEDAY2_UnsecuredLoan_Q2]
			   ,ISNULL(COUNT_DUEDAY2_UnsecuredLoan_Q3,0) [COUNT_DUEDAY2_UnsecuredLoan_Q3]

			   ,ISNULL(COUNT_DUEDAY2_VehicleLoan_Q1,0) [COUNT_DUEDAY2_VehicleLoan_Q1]
			   ,ISNULL(COUNT_DUEDAY2_VehicleLoan_Q2,0) [COUNT_DUEDAY2_VehicleLoan_Q2]
			   ,ISNULL(COUNT_DUEDAY2_VehicleLoan_Q3,0) [COUNT_DUEDAY2_VehicleLoan_Q3]

			   ,ISNULL(COUNT_DUEDAY2_Others_Q1,0) [COUNT_DUEDAY2_Others_Q1]
			   ,ISNULL(COUNT_DUEDAY2_Others_Q2,0) [COUNT_DUEDAY2_Others_Q2]
			   ,ISNULL(COUNT_DUEDAY2_Others_Q3,0) [COUNT_DUEDAY2_Others_Q3]


			   ,[CommercialLoan_Month_to_Maturity]
			   ,[RealEstate_Month_to_Maturity]
			   ,[SecuredLoan_Month_to_Maturity]
			   ,[UnsecuredLoan_Month_to_Maturity]
			   ,[Vehicleloan_Month_to_Maturity]
			   ,[Others_Month_to_Maturity] 	
			   ,Max_Loan_Month_to_Maturity
			   ,[Delinquency_CommercialLoan_SP]
			   ,[Delinquency_RealEstate_SP]
			   ,[Delinquency_SecuredLoan_SP]
			   ,[Delinquency_UnsecuredLoan_SP]
			   ,[Delinquency_Vehicleloan_SP]
			   ,[Delinquency_Others_SP]
			   ,Delinquency_Loan_SP
			   ,CommercialLoan_OPENDATE
			   ,CommercialLoan_CLOSEDATE
			   ,RealEstate_OPENDATE
			   ,RealEstate_CLOSEDATE
			   ,SecuredLoan_OPENDATE
			   ,SecuredLoan_CLOSEDATE
			   ,UnsecuredLoan_OPENDATE
			   ,UnsecuredLoan_CLOSEDATE
			   ,Vehicleloan_OPENDATE
			   ,Vehicleloan_CLOSEDATE
			   ,Others_OPENDATE
			   ,Others_CLOSEDATE
			   ,Min_Loan_OPENDATE
			   ,Max_Loan_CLOSEDATE
			   ,[CommercialLoan_StaticPoolFlag]
			   ,[RealEstate_StaticPoolFlag]
			   ,[SecuredLoan_StaticPoolFlag]
			   ,[UnsecuredLoan_StaticPoolFlag]
			   ,[VehicleLoan_StaticPoolFlag]

			   ,ISNULL([CREDIT_SCORE_SP],0) [CREDIT_SCORE_SP]
			   ,CASE WHEN (CREDIT_SCORE_SP IS NULL AND CREDIT_SCORE_Q4 IS  NULL) THEN CREDIT_SCORE_SP else (ISNULL(CREDIT_SCORE_SP,0) - ISNULL(CREDIT_SCORE_Q4,0)) end [DFT_CREDIT_SCORE_SP_Q4]
       
			   --,[CommercialLoan_Q1Flag]
			   --,[RealEstate_Q1Flag]
			   --,[SecuredLoan_Q1Flag]
			   --,[UnsecuredLoan_Q1Flag]
			   --,[VehicleLoan_Q1Flag]

		into #loan_product_holdings
		FROM
		(
		SELECT *
		,CASE WHEN #Products_CommercialLoan_SP > 0 then 1 ELSE 0 end  [CommercialLoan_StaticPoolFlag]
		,CASE WHEN #Products_RealEstate_SP > 0 then 1 ELSE 0 end  [RealEstate_StaticPoolFlag]
		,CASE WHEN #Products_SecuredLoan_SP > 0 then 1 ELSE 0 end  [SecuredLoan_StaticPoolFlag]
		,CASE WHEN #Products_UnsecuredLoan_SP > 0 then 1 ELSE 0 end  [UnsecuredLoan_StaticPoolFlag]
		,CASE WHEN #Products_VehicleLoan_SP > 0 then 1 ELSE 0 end  [VehicleLoan_StaticPoolFlag]

		,CASE WHEN #Products_CommercialLoan_Q1 > 0 then 1 ELSE 0 end  [CommercialLoan_Q1Flag]
		,CASE WHEN #Products_RealEstate_Q1 > 0 then 1 ELSE 0 end  [RealEstate_Q1Flag]
		,CASE WHEN #Products_SecuredLoan_Q1 > 0 then 1 ELSE 0 end  [SecuredLoan_Q1Flag]
		,CASE WHEN #Products_UnsecuredLoan_Q1 > 0 then 1 ELSE 0 end  [UnsecuredLoan_Q1Flag]
		,CASE WHEN #Products_VehicleLoan_Q1 > 0 then 1 ELSE 0 end  [VehicleLoan_Q1Flag]
		FROM
		 (SELECT  SSN [SSN]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_CommercialLoan_SP] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q1' THEN UNID END) as [#Products_CommercialLoan_Q1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q2' THEN UNID END) as [#Products_CommercialLoan_Q2]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q3' THEN UNID END) as [#Products_CommercialLoan_Q3]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q4' THEN UNID END) as [#Products_CommercialLoan_Q4] 		 		 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_RealEstate_SP] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q1' THEN UNID END) as  [#Products_RealEstate_Q1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q2' THEN UNID END) as  [#Products_RealEstate_Q2]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q3' THEN UNID END) as [#Products_RealEstate_Q3]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q4' THEN UNID END) as [#Products_RealEstate_Q4]		
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_RealEstate1_SP] 
		  --      ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q1' THEN UNID END) as  [#Products_RealEstate1_Q1] 
		  --      ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q2' THEN UNID END) as  [#Products_RealEstate1_Q2]
		  --      ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q3' THEN UNID END) as [#Products_RealEstate1_Q3]
		  --      ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q4' THEN UNID END) as [#Products_RealEstate1_Q4]		 		 
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_RealEstate2_SP]
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q1' THEN UNID END) as [#Products_RealEstate2_Q1] 
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q2' THEN UNID END) as [#Products_RealEstate2_Q2]
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q3' THEN UNID END) as [#Products_RealEstate2_Q3]
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q4' THEN UNID END) as [#Products_RealEstate2_Q4] 		
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_SecuredLoan_SP]
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q1' THEN UNID END) as [#Products_SecuredLoan_Q1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q2' THEN UNID END) as [#Products_SecuredLoan_Q2]
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q3' THEN UNID END) as [#Products_SecuredLoan_Q3]
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q4' THEN UNID END) as [#Products_SecuredLoan_Q4] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_UnsecuredLoan_SP]
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q1' THEN UNID END) as [#Products_UnsecuredLoan_Q1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q2' THEN UNID END) as [#Products_UnsecuredLoan_Q2]
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q3' THEN UNID END) as [#Products_UnsecuredLoan_Q3]
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q4' THEN UNID END) as [#Products_UnsecuredLoan_Q4]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_VehicleLoan_SP]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q1' THEN UNID END) as [#Products_VehicleLoan_Q1]      
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q2' THEN UNID END) as [#Products_VehicleLoan_Q2]      
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q3' THEN UNID END) as [#Products_VehicleLoan_Q3]      
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q4' THEN UNID END) as [#Products_VehicleLoan_Q4]      
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_Others_SP]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q1' THEN UNID END) as [#Products_Others_Q1]       
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q2' THEN UNID END) as [#Products_Others_Q2]       
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q3' THEN UNID END) as [#Products_Others_Q3]       
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q4' THEN UNID END) as [#Products_Others_Q4]     
		
				,COUNT(Distinct CASE WHEN Quarters = 'Staticpool' THEN UNID END) as [#Products_Loan_SP]
				,COUNT(Distinct CASE WHEN Quarters = 'Q1' THEN UNID END) as [#Products_Loan_Q1]       
				,COUNT(Distinct CASE WHEN Quarters = 'Q2' THEN UNID END) as [#Products_Loan_Q2]       
				,COUNT(Distinct CASE WHEN Quarters = 'Q3' THEN UNID END) as [#Products_Loan_Q3]       
				,COUNT(Distinct CASE WHEN Quarters = 'Q4' THEN UNID END) as [#Products_Loan_Q4]

				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_CommercialLoan_SP] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q1' THEN [TYPE] END) as [#Type_CommercialLoan_Q1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q2' THEN [TYPE] END) as [#Type_CommercialLoan_Q2]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_CommercialLoan_Q3]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_CommercialLoan_Q4] 		 		 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_RealEstate_SP] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q1' THEN [TYPE] END) as  [#Type_RealEstate_Q1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q2' THEN [TYPE] END) as  [#Type_RealEstate_Q2]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_RealEstate_Q3]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_RealEstate_Q4]			
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_RealEstate1_SP] 
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q1' THEN [TYPE] END) as  [#Type_RealEstate1_Q1] 
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q2' THEN [TYPE] END) as  [#Type_RealEstate1_Q2]
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_RealEstate1_Q3]
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_RealEstate1_Q4]		 		 
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_RealEstate2_SP]
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q1' THEN [TYPE] END) as [#Type_RealEstate2_Q1] 
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q2' THEN [TYPE] END) as [#Type_RealEstate2_Q2]
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_RealEstate2_Q3]
				--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_RealEstate2_Q4] 		
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_SecuredLoan_SP]
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q1' THEN [TYPE] END) as [#Type_SecuredLoan_Q1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q2' THEN [TYPE] END) as [#Type_SecuredLoan_Q2]
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_SecuredLoan_Q3]
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_SecuredLoan_Q4] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_UnsecuredLoan_SP]
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q1' THEN [TYPE] END) as [#Type_UnsecuredLoan_Q1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q2' THEN [TYPE] END) as [#Type_UnsecuredLoan_Q2]
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_UnsecuredLoan_Q3]
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_UnsecuredLoan_Q4]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_VehicleLoan_SP]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q1' THEN [TYPE] END) as [#Type_VehicleLoan_Q1]      
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q2' THEN [TYPE] END) as [#Type_VehicleLoan_Q2]      
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_VehicleLoan_Q3]      
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_VehicleLoan_Q4]      
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_Others_SP]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q1' THEN [TYPE] END) as [#Type_Others_Q1]       
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q2' THEN [TYPE] END) as [#Type_Others_Q2]       
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_Others_Q3]       
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_Others_Q4]

				,COUNT(Distinct CASE WHEN Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_Loan_SP]
				,COUNT(Distinct CASE WHEN Quarters = 'Q1' THEN [TYPE] END) as [#Type_Loan_Q1]       
				,COUNT(Distinct CASE WHEN Quarters = 'Q2' THEN [TYPE] END) as [#Type_Loan_Q2]       
				,COUNT(Distinct CASE WHEN Quarters = 'Q3' THEN [TYPE] END) as [#Type_Loan_Q3]       
				,COUNT(Distinct CASE WHEN Quarters = 'Q4' THEN [TYPE] END) as [#Type_Loan_Q4]

				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' THEN MOB END) [CommercialLoan_MOB]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' THEN MOB END) [RealEstate_MOB]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' THEN MOB END) [RealEstate1_MOB]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' THEN MOB END) [RealEstate2_MOB]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' THEN MOB END) [SecuredLoan_MOB]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' THEN MOB END) [UnsecuredLoan_MOB]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' THEN MOB END) [Vehicleloan_MOB]
				,MAX(CASE WHEN Product_Flag = 'Others' THEN MOB END) [Others_MOB] 
				,MAX(MOB) [MAX_Loan_MOB]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_CommercialLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_CommercialLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_CommercialLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_CommercialLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate_Q1]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate_Q2]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate_Q3]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate_Q4]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate1_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate1_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate1_Q3]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate1_Q4]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate2_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate2_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate2_Q3]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate2_Q4]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_SecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_SecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_SecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_SecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_UnsecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_UnsecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_UnsecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_UnsecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Vehicleloan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Vehicleloan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Vehicleloan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Vehicleloan_Q4]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Others_Q1]
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Others_Q2]
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Others_Q3]
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Others_Q4]

				,MAX(CASE WHEN Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Loan_Q1]
				,MAX(CASE WHEN Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Loan_Q2]
				,MAX(CASE WHEN Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Loan_Q3]
				,MAX(CASE WHEN Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Loan_Q4]

				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_CommercialLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_CommercialLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_CommercialLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_CommercialLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate_Q1]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate_Q2]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate_Q3]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate_Q4]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate1_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate1_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate1_Q3]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate1_Q4]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate2_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate2_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate2_Q3]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate2_Q4]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_SecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_SecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_SecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_SecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_UnsecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_UnsecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_UnsecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_UnsecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Vehicleloan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Vehicleloan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Vehicleloan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Vehicleloan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Others_Q1]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Others_Q2]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Others_Q3]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Others_Q4]

				,MAX(CASE WHEN Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Loan_Q1]	
				,MAX(CASE WHEN Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Loan_Q2]	
				,MAX(CASE WHEN Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Loan_Q3]	
				,MAX(CASE WHEN Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Loan_Q4]

				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_CommercialLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_CommercialLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_CommercialLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_CommercialLoan_Q4]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate_Q1]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate_Q2]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate_Q3]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate_Q4]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate1_Q1]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate1_Q2]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate1_Q3]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate1_Q4]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate2_Q1]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate2_Q2]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate2_Q3]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate2_Q4]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_SecuredLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_SecuredLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_SecuredLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_SecuredLoan_Q4]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_UnsecuredLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_UnsecuredLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_UnsecuredLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_UnsecuredLoan_Q4]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Vehicleloan_Q1]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Vehicleloan_Q2]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Vehicleloan_Q3]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Vehicleloan_Q4]
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Others_Q1]	
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Others_Q2]	
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Others_Q3]	
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Others_Q4]
				,SUM(CASE WHEN Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Loan_Q1]	
				,SUM(CASE WHEN Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Loan_Q2]	
				,SUM(CASE WHEN Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Loan_Q3]	
				,SUM(CASE WHEN Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Loan_Q4]
			
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_CommercialLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_CommercialLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_CommercialLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_CommercialLoan_Q4]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_RealEstate_Q1]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_RealEstate_Q2]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_RealEstate_Q3]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_RealEstate_Q4]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_RealEstate1_Q1]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_RealEstate1_Q2]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_RealEstate1_Q3]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_RealEstate1_Q4]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_RealEstate2_Q1]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_RealEstate2_Q2]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_RealEstate2_Q3]
				--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_RealEstate2_Q4]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_SecuredLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_SecuredLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_SecuredLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_SecuredLoan_Q4]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_UnsecuredLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_UnsecuredLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_UnsecuredLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_UnsecuredLoan_Q4]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_Vehicleloan_Q1]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_Vehicleloan_Q2]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_Vehicleloan_Q3]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_Vehicleloan_Q4]
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_Others_Q1]	
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_Others_Q2]	
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_Others_Q3]	
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_Others_Q4]

				,SUM(CASE WHEN Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_Loan_Q1]	
				,SUM(CASE WHEN Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_Loan_Q2]	
				,SUM(CASE WHEN Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_Loan_Q3]	
				,SUM(CASE WHEN Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_Loan_Q4]

				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_CommercialLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_CommercialLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_CommercialLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_CommercialLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate_Q1]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate_Q2]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate_Q3]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate_Q4]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate1_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate1_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate1_Q3]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate1_Q4]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate2_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate2_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate2_Q3]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate2_Q4]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_SecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_SecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_SecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_SecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_UnsecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_UnsecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_UnsecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_UnsecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_Vehicleloan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_Vehicleloan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_Vehicleloan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_Vehicleloan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_Others_Q1]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_Others_Q2]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_Others_Q3]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_Others_Q4]

				,MAX(CASE WHEN Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_Q1]	
				,MAX(CASE WHEN Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_Q2]	
				,MAX(CASE WHEN Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_Q3]	
				,MAX(CASE WHEN Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_Q4]

				--,CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q1' THEN (SELECT min(OPENDATE) FROM #membership_loan) ELSE NULL END [Total_CommercialLoan_Q4] 		 		 
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_CommercialLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_CommercialLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_CommercialLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_CommercialLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate_Q1]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate_Q2]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate_Q3]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate_Q4]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate1_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate1_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate1_Q3]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate1_Q4]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate2_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate2_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate2_Q3]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate2_Q4]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_SecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_SecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_SecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_SecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_UnsecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_UnsecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_UnsecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_UnsecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Vehicleloan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Vehicleloan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Vehicleloan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Vehicleloan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Others_Q1]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Others_Q2]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Others_Q3]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Others_Q4]	
		
				,MAX(CASE WHEN Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Loan_Q1]	
				,MAX(CASE WHEN Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Loan_Q2]	
				,MAX(CASE WHEN Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Loan_Q3]	
				,MAX(CASE WHEN Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Loan_Q4]	

				----,CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q1' THEN (SELECT min(OPENDATE) FROM #membership_loan) ELSE NULL END [Total_CommercialLoan_Q4] 		 		 
				--,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_CommercialLoan_Q1]
				--,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_CommercialLoan_Q2]
				--,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_CommercialLoan_Q3]
				--,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_CommercialLoan_Q4]
				--,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_RealEstate_Q1]
				--,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_RealEstate_Q2]
				--,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_RealEstate_Q3]
				--,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_RealEstate_Q4]
				----,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_RealEstate1_Q1]
				----,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_RealEstate1_Q2]
				----,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_RealEstate1_Q3]
				----,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_RealEstate1_Q4]
				----,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_RealEstate2_Q1]
				----,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_RealEstate2_Q2]
				----,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_RealEstate2_Q3]
				----,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_RealEstate2_Q4]
				--,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_SecuredLoan_Q1]
				--,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_SecuredLoan_Q2]
				--,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_SecuredLoan_Q3]
				--,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_SecuredLoan_Q4]
				--,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_UnsecuredLoan_Q1]
				--,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_UnsecuredLoan_Q2]
				--,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_UnsecuredLoan_Q3]
				--,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_UnsecuredLoan_Q4]
				--,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_Vehicleloan_Q1]
				--,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_Vehicleloan_Q2]
				--,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_Vehicleloan_Q3]
				--,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_Vehicleloan_Q4]
				--,AVG(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_Others_Q1]	
				--,AVG(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_Others_Q2]	
				--,AVG(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_Others_Q3]	
				--,AVG(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_Others_Q4]
				--,AVG(CASE WHEN Quarters = 'Q1' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_Loan_Q1]	
				--,AVG(CASE WHEN Quarters = 'Q2' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_Loan_Q2]	
				--,AVG(CASE WHEN Quarters = 'Q3' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_Loan_Q3]	
				--,AVG(CASE WHEN Quarters = 'Q4' THEN UTILIZATION_RATE END) [AVG_UTILIZATION_RATE_Loan_Q4]

				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_CommercialLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_CommercialLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_CommercialLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_CommercialLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate_Q1]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate_Q2]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate_Q3]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate_Q4]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate1_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate1_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate1_Q3]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate1_Q4]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate2_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate2_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate2_Q3]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate2_Q4]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_SecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_SecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_SecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_SecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_UnsecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_UnsecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_UnsecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_UnsecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_Vehicleloan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_Vehicleloan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_Vehicleloan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_Vehicleloan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_Others_Q1]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_Others_Q2]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_Others_Q3]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_Others_Q4]
		
				,MAX(CASE WHEN Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_Loan_Q1]	
				,MAX(CASE WHEN Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_Loan_Q2]	
				,MAX(CASE WHEN Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_Loan_Q3]	
				,MAX(CASE WHEN Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_Loan_Q4]
		
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_CommercialLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_CommercialLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_CommercialLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_CommercialLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate_Q1]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate_Q2]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate_Q3]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate_Q4]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate1_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate1_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate1_Q3]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate1_Q4]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate2_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate2_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate2_Q3]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate2_Q4]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_SecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_SecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_SecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_SecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_UnsecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_UnsecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_UnsecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_UnsecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_Vehicleloan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_Vehicleloan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_Vehicleloan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_Vehicleloan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_Others_Q1]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_Others_Q2]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_Others_Q3]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_Others_Q4]
		
				,MAX(CASE WHEN Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_Loan_Q1]	
				,MAX(CASE WHEN Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_Loan_Q2]	
				,MAX(CASE WHEN Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_Loan_Q3]	
				,MAX(CASE WHEN Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_Loan_Q4]

				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' THEN Month_to_Maturity END) [CommercialLoan_Month_to_Maturity]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' THEN Month_to_Maturity END) [RealEstate_Month_to_Maturity]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' THEN Month_to_Maturity END) [RealEstateLoan1_Month_to_Maturity]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' THEN Month_to_Maturity END) [RealEstateLoan2_Month_to_Maturity]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' THEN Month_to_Maturity END) [SecuredLoan_Month_to_Maturity]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' THEN Month_to_Maturity END) [UnsecuredLoan_Month_to_Maturity]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' THEN Month_to_Maturity END) [Vehicleloan_Month_to_Maturity]
				,MAX(CASE WHEN Product_Flag = 'Others' THEN Month_to_Maturity END) [Others_Month_to_Maturity] 	
				,MAX(Month_to_Maturity) [Max_Loan_Month_to_Maturity]

				,MIN(CASE WHEN Product_Flag = 'Commercial_loan' THEN OPENDATE END) [CommercialLoan_OPENDATE]
				,MIN(CASE WHEN Product_Flag = 'Real_Estate_loan' THEN OPENDATE END) [RealEstate_OPENDATE]
				--,MIN(CASE WHEN Product_Flag = 'Real_Estate_loan1' THEN OPENDATE END) [RealEstateLoan1_OPENDATE]
				--,MIN(CASE WHEN Product_Flag = 'Real_Estate_loan2' THEN OPENDATE END) [RealEstateLoan2_OPENDATE]
				,MIN(CASE WHEN Product_Flag = 'SecuredLoan' THEN OPENDATE END) [SecuredLoan_OPENDATE]
				,MIN(CASE WHEN Product_Flag = 'UnsecuredLoan' THEN OPENDATE END) [UnsecuredLoan_OPENDATE]
				,MIN(CASE WHEN Product_Flag = 'Vehicleloan' THEN OPENDATE END) [Vehicleloan_OPENDATE]
				,MIN(CASE WHEN Product_Flag = 'Others' THEN OPENDATE END) [Others_OPENDATE] 
				,MIN(OPENDATE) [Min_Loan_OPENDATE] 

				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' THEN CLOSEDATE END) [CommercialLoan_CLOSEDATE]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' THEN CLOSEDATE END) [RealEstate_CLOSEDATE]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' THEN CLOSEDATE END) [RealEstate1_CLOSEDATE]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' THEN CLOSEDATE END) [RealEstate2_CLOSEDATE]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' THEN CLOSEDATE END) [SecuredLoan_CLOSEDATE]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' THEN CLOSEDATE END) [UnsecuredLoan_CLOSEDATE]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' THEN CLOSEDATE END) [Vehicleloan_CLOSEDATE]
				,MAX(CASE WHEN Product_Flag = 'Others' THEN CLOSEDATE END) [Others_CLOSEDATE]
				,MAX(CLOSEDATE) [Max_Loan_CLOSEDATE]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_CommercialLoan_SP]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_RealEstate_SP]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_SecuredLoan_SP]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_UnsecuredLoan_SP]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_Vehicleloan_SP]
				,MAX(CASE WHEN Product_Flag = 'Others'and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_Others_SP]
				,MAX(CASE WHEN Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_Loan_SP]	

				,MAX( CASE WHEN Quarters = 'Staticpool' THEN CREDITSCORE END) [CREDIT_SCORE_SP]
				,MAX( CASE WHEN Quarters = 'Q4' THEN CREDITSCORE END) [CREDIT_SCORE_Q4]
						

               
							--,count(distinct UNID) Count_of_product_commercial_loan
					--,count(distinct TYPE) count_of_type_commercial_loan
					----,max(Staticpool_Commercial_loan_flag) Staticpool_Commercial_loan_flag
					--,min(OPENDATE) min_OPENDATE_commercial_loan,max(CLOSEDATE) max_CLOSEDATE_commercial_loan
					--,Max(MOB) Max_MOB_commercial_loan
					--,max(Month_to_Maturity) Month_to_Maturity_commercial_loan
					--,max(PAYMENTCOUNT) Max_paymentcount_commercial_loan
					--,max(DUEDAY1) max_Dueday1_commercial_loan
					--,max(ORIGINALBALANCE) max_ORIGINALBALANCE_commercial_loan
					--,max(INTERESTRATE) INTERESTRATE_commercial_loan
					--,max(CREDITLIMIT) max_CREDITLIMIT_commercial_loan
					--,sum(PAYMENT) Sum_PAYMENT_commercial_loan
					--,sum(ORIGINALBALANCE) Sum_ORIGINALBALANCE_commercial_loan
					--,max(CRPMTCURRENT) Max_delinquenty_commercial_loan
			 
					 from #membership_loan
					group by SSN ) B) D

					--ON A.SSN = B.SSN

					--group by SSN,Quarters,Product_Flag ) B
					--SELECT TOP 1000 * FROM #loan_product_holdings

					--SELECT TOP 1000 CRPMTCURRENT FROM ARCUSYM000..LOAN

		--SELECT COUNT(DISTINCT SSN001) FROM #loan_product_holdings

		-- DISTINCT UNID FROM #membership_loan			

			 DROP TABLE IF EXISTS #static_unid
			 SELECT DISTINCT UNID,PARENTACCOUNT,Product_Flag into #static_unid FROM #membership_loan

------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Loan Transaction Master Data ***\\\-------------------------------------------------------------------



			 DROP TABLE IF EXISTS #temp_loan_transaction
			 SELECT X.SSN,bb.*,Product_Flag 
			 into #temp_loan_transaction
			from 
			(

			select unid,PARENTACCOUNT
			,case when EFFECTIVEDATE_v1 in ((left(convert(varchar,eomonth(dateadd(month,-10,@staticpooldate)),112),6)),(left(convert(varchar,eomonth(dateadd(month,-11,@staticpooldate),112)),6)),(left(convert(varchar,eomonth(dateadd(month,-12,@staticpooldate),112)),6))) then 'Q4'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,eomonth(dateadd(month,-7,@staticpooldate),112)),6)),(left(convert(varchar,eomonth(dateadd(month,-8,@staticpooldate),112)),6)),(left(convert(varchar,eomonth(dateadd(month,-9,@staticpooldate),112)),6))) then 'Q3'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,eomonth(dateadd(month,-4,@staticpooldate),112)),6)),(left(convert(varchar,eomonth(dateadd(month,-5,@staticpooldate),112)),6)),(left(convert(varchar,eomonth(dateadd(month,-6,@staticpooldate),112)),6))) then 'Q2'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,eomonth(dateadd(month,-3,@staticpooldate),112)),6)),(left(convert(varchar,eomonth(dateadd(month,-2,@staticpooldate),112)),6)),(left(convert(varchar,eomonth(dateadd(month,-1,@staticpooldate),112)),6))) then 'Q1'
		    when EFFECTIVEDATE_v1 in (left(convert(varchar,@staticpooldate,112),6)) then 'Staticpool' end Quarters
			,EFFECTIVEDATE_v1
			,ACTIONCODE,SOURCECODE
			,case when ACTIONCODE='A' then 1 else 0 end Loan_addon
			,case when ACTIONCODE='N' then 1 else 0 end New_loan
			,case when ACTIONCODE='N' then 1 else 0 end loan_payment
			,case when SOURCECODE='C' then 1 else 0 end CASH
			,case when SOURCECODE='D' then 1 else 0 end DRAFT
			,case when SOURCECODE='E' then 1 else 0 end ACH
			,case when SOURCECODE='F' then 1 else 0 end FEE
			,case when SOURCECODE='H' then 1 else 0 end HOMEBANKING
			,case when SOURCECODE='I' then 1 else 0 end INSURANCE
			,case when SOURCECODE='K' then 1 else 0 end CHECKS
			,case when SOURCECODE='P' then 1 else 0 end PAYROLL
			,case when SOURCECODE='S' then 1 else 0 end KIOSK
			,case when SOURCECODE='T' then 1 else 0 end  AUDIO_RESPONSE_TELEPHONE
			,CASE WHEN ACTIONCODE='A' AND SOURCECODE='C' THEN 'LOANADDON_CASH'
			WHEN ACTIONCODE='A' AND SOURCECODE='F' THEN 'LOANADDON_FEE'
			WHEN ACTIONCODE='A' AND SOURCECODE='H' THEN 'LOANADDON_HOMEBANKING'
			WHEN ACTIONCODE='A' AND SOURCECODE='I' THEN 'LOANADDON_INSURANCE'
			WHEN ACTIONCODE='A' AND SOURCECODE='K' THEN 'LOANADDON_CHECK'
			WHEN ACTIONCODE='A' AND SOURCECODE='T' THEN 'LOANADDON_RESPONSE_TELEPHONE'
			WHEN ACTIONCODE='A' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'LOANADDON'
			WHEN ACTIONCODE='N' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'NEWLOAN'
			WHEN ACTIONCODE='N' AND SOURCECODE='K' THEN 'NEWLOAN_CHECKS'
			WHEN ACTIONCODE='N' AND SOURCECODE='S' THEN 'NEWLOAN_KIOSK'
			WHEN ACTIONCODE='P' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'LOANPAYMENT'
			
			WHEN ACTIONCODE='P' AND SOURCECODE='C' THEN 'LOANPAYMENT_CASH'
			WHEN ACTIONCODE='P' AND SOURCECODE='D' THEN 'LOANPAYMENT_DRAFT'
			WHEN ACTIONCODE='P' AND SOURCECODE='E' THEN 'LOANPAYMENT_ACH'
			WHEN ACTIONCODE='P' AND SOURCECODE='H' THEN 'LOANPAYMENT_HOMEBANKING'
			WHEN ACTIONCODE='P' AND SOURCECODE='K' THEN 'LOANPAYMENT_CHECKS'
			WHEN ACTIONCODE='P' AND SOURCECODE='P' THEN 'LOANPAYMENT_PAYROLL'
			WHEN ACTIONCODE='P' AND SOURCECODE='S' THEN 'LOANPAYMENT_KIOSK'
			WHEN ACTIONCODE='P' AND SOURCECODE='T' THEN  'LOANPAYMENT_RESPONSE_TELEPHONE' end action_source_code
			,BALANCECHANGE Transaction_amount,NEWBALANCE
			,INTEREST Interest_amount, FEEAMOUNT
			from	(

					select CONCAT(PARENTACCOUNT,PARENTID) UNID
					,PARENTACCOUNT,PARENTID
					,TRANSFERCODE
					,case when len(month(effectivedate))=1 then CONCAT(year(effectivedate),0,
					
					
					
					
					(effectivedate))
					else CONCAT(year(effectivedate),month(effectivedate)) end EFFECTIVEDATE_v1
					,cast(EFFECTIVEDATE as date) EFFECTIVEDATE ,POSTDATE
					,ACTIONCODE,SOURCECODE,BALANCECHANGE,NEWBALANCE,INTEREST,FEEAMOUNT
					from [ARCUSYM000].dbo.LOANTRANSACTION
					where
					ACTIONCODE in ('A','N','P') AND SOURCECODE in ('C','D','E','F','H','I','K','P','S','T')
					 and ACTIONCODE !='C' 
					  ) AA --where parentaccount=0014465465
			 )bb
			   left join #static_unid W
					  on bb.UNID = W.UNID
					  left join #Static_SSN_account X
					  on bb.PARENTACCOUNT = X.AccountNumber
			 where bb.Quarters is not null 
			 and bb.EFFECTIVEDATE_v1 between (Cast((left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6)) as int)) 
			 and cast((left(convert(varchar,@staticpooldate,112),6)) as int)
			
			 --group by PARENTACCOUNT
			 --,UNID
			 --,Quarters,action_source_code

          drop table if exists #transaction_loan

			 SELECT  *
			 INTO #transaction_loan
			 from
			 ((
			 SELECT
			 SSN
			--PARENTACCOUNT
			--,UNID
			--,Quarters
			--,action_source_code
			,sum(CASE WHEN Quarters = 'Staticpool' then Loan_addon END) COUNT_LOAN_ADDON_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then Loan_addon END) COUNT_LOAN_ADDON_Q1
			,sum(CASE WHEN Quarters = 'Q2' then Loan_addon END) COUNT_LOAN_ADDON_Q2
			,sum(CASE WHEN Quarters = 'Q3' then Loan_addon END) COUNT_LOAN_ADDON_Q3
			,sum(CASE WHEN Quarters = 'Q4' then Loan_addon END) COUNT_LOAN_ADDON_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then New_loan END) COUNT_NEW_LOAN_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then New_loan END) COUNT_NEW_LOAN_Q1
			,sum(CASE WHEN Quarters = 'Q2' then New_loan END) COUNT_NEW_LOAN_Q2
			,sum(CASE WHEN Quarters = 'Q3' then New_loan END) COUNT_NEW_LOAN_Q3
			,sum(CASE WHEN Quarters = 'Q4' then New_loan END) COUNT_NEW_LOAN_Q4	
			,sum(CASE WHEN Quarters = 'Staticpool' then loan_payment END) COUNT_LOAN_PAYMENT_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then loan_payment END) COUNT_LOAN_PAYMENT_Q1
			,sum(CASE WHEN Quarters = 'Q2' then loan_payment END) COUNT_LOAN_PAYMENT_Q2
			,sum(CASE WHEN Quarters = 'Q3' then loan_payment END) COUNT_LOAN_PAYMENT_Q3
			,sum(CASE WHEN Quarters = 'Q4' then loan_payment END) COUNT_LOAN_PAYMENT_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then CASH END) COUNT_CASH_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then CASH END) COUNT_CASH_Q1
			,sum(CASE WHEN Quarters = 'Q2' then CASH END) COUNT_CASH_Q2
			,sum(CASE WHEN Quarters = 'Q3' then CASH END) COUNT_CASH_Q3
			,sum(CASE WHEN Quarters = 'Q4' then CASH END) COUNT_CASH_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then DRAFT END) COUNT_DRAFT_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then DRAFT END) COUNT_DRAFT_Q1
			,sum(CASE WHEN Quarters = 'Q2' then DRAFT END) COUNT_DRAFT_Q2
			,sum(CASE WHEN Quarters = 'Q3' then DRAFT END) COUNT_DRAFT_Q3
			,sum(CASE WHEN Quarters = 'Q4' then DRAFT END) COUNT_DRAFT_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then ACH END) COUNT_ACH_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then ACH END) COUNT_ACH_Q1
			,sum(CASE WHEN Quarters = 'Q2' then ACH END) COUNT_ACH_Q2
			,sum(CASE WHEN Quarters = 'Q3' then ACH END) COUNT_ACH_Q3
			,sum(CASE WHEN Quarters = 'Q4' then ACH END) COUNT_ACH_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then FEE END) COUNT_FEE_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then FEE END) COUNT_FEE_Q1
			,sum(CASE WHEN Quarters = 'Q2' then FEE END) COUNT_FEE_Q2
			,sum(CASE WHEN Quarters = 'Q3' then FEE END) COUNT_FEE_Q3
			,sum(CASE WHEN Quarters = 'Q4' then FEE END) COUNT_FEE_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then HOMEBANKING END) COUNT_HOMEBANKING_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then HOMEBANKING END) COUNT_HOMEBANKING_Q1
			,sum(CASE WHEN Quarters = 'Q2' then HOMEBANKING END) COUNT_HOMEBANKING_Q2
			,sum(CASE WHEN Quarters = 'Q3' then HOMEBANKING END) COUNT_HOMEBANKING_Q3
			,sum(CASE WHEN Quarters = 'Q4' then HOMEBANKING END) COUNT_HOMEBANKING_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then INSURANCE END) COUNT_INSURANCE_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then INSURANCE END) COUNT_INSURANCE_Q1
			,sum(CASE WHEN Quarters = 'Q2' then INSURANCE END) COUNT_INSURANCE_Q2
			,sum(CASE WHEN Quarters = 'Q3' then INSURANCE END) COUNT_INSURANCE_Q3
			,sum(CASE WHEN Quarters = 'Q4' then INSURANCE END) COUNT_INSURANCE_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then CHECKS END) COUNT_CHECKS_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then CHECKS END) COUNT_CHECKS_Q1
			,sum(CASE WHEN Quarters = 'Q2' then CHECKS END) COUNT_CHECKS_Q2
			,sum(CASE WHEN Quarters = 'Q3' then CHECKS END) COUNT_CHECKS_Q3
			,sum(CASE WHEN Quarters = 'Q4' then CHECKS END) COUNT_CHECKS_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then PAYROLL END) COUNT_PAYROLL_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then PAYROLL END) COUNT_PAYROLL_Q1
			,sum(CASE WHEN Quarters = 'Q2' then PAYROLL END) COUNT_PAYROLL_Q2
			,sum(CASE WHEN Quarters = 'Q3' then PAYROLL END) COUNT_PAYROLL_Q3
			,sum(CASE WHEN Quarters = 'Q4' then PAYROLL END) COUNT_PAYROLL_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then KIOSK END) COUNT_KIOSK_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then KIOSK END) COUNT_KIOSK_Q1
			,sum(CASE WHEN Quarters = 'Q2' then KIOSK END) COUNT_KIOSK_Q2
			,sum(CASE WHEN Quarters = 'Q3' then KIOSK END) COUNT_KIOSK_Q3
			,sum(CASE WHEN Quarters = 'Q4' then KIOSK END) COUNT_KIOSK_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Q1
			,sum(CASE WHEN Quarters = 'Q2' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Q2
			,sum(CASE WHEN Quarters = 'Q3' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Q3
			,sum(CASE WHEN Quarters = 'Q4' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Q4
			--,sum(CASE WHEN Quarters = 'Staticpool' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_STATICPOOL
			--,sum(CASE WHEN Quarters = 'Q1' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Q1
			--,sum(CASE WHEN Quarters = 'Q2' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Q2
			--,sum(CASE WHEN Quarters = 'Q3' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Q3
			--,sum(CASE WHEN Quarters = 'Q4' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Q4
			--,sum(CASE WHEN Quarters = 'Staticpool' then Interest_amount END) INTEREST_AMOUNT_STATICPOOL
			--,sum(CASE WHEN Quarters = 'Q1' then Interest_amount END) INTEREST_AMOUNT_Q1
			--,sum(CASE WHEN Quarters = 'Q2' then Interest_amount END) INTEREST_AMOUNT_Q2
			--,sum(CASE WHEN Quarters = 'Q3' then Interest_amount END) INTEREST_AMOUNT_Q3
			--,sum(CASE WHEN Quarters = 'Q4' then Interest_amount END) INTEREST_AMOUNT_Q4
			--,sum(CASE WHEN Quarters = 'Staticpool' then FEEAMOUNT END) FEEAMOUNT_STATICPOOL
			--,sum(CASE WHEN Quarters = 'Q1' then FEEAMOUNT END) FEEAMOUNT_Q1
			--,sum(CASE WHEN Quarters = 'Q2' then FEEAMOUNT END) FEEAMOUNT_Q2
			--,sum(CASE WHEN Quarters = 'Q3' then FEEAMOUNT END) FEEAMOUNT_Q3
			--,sum(CASE WHEN Quarters = 'Q4' then FEEAMOUNT END) FEEAMOUNT_Q4
			--,AVG(CASE WHEN Quarters = 'Staticpool' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_STATICPOOL
			--,AVG(CASE WHEN Quarters = 'Q1' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Q1
			--,AVG(CASE WHEN Quarters = 'Q2' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Q2
			--,AVG(CASE WHEN Quarters = 'Q3' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Q3
			--,AVG(CASE WHEN Quarters = 'Q4' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Q4
			--,AVG(CASE WHEN Quarters = 'Staticpool' then NEWBALANCE END) AVG_NEWBALANCE_STATICPOOL
			--,AVG(CASE WHEN Quarters = 'Q1' then NEWBALANCE END) AVG_NEWBALANCE_Q1
			--,AVG(CASE WHEN Quarters = 'Q2' then NEWBALANCE END) AVG_NEWBALANCE_Q2
			--,AVG(CASE WHEN Quarters = 'Q3' then NEWBALANCE END) AVG_NEWBALANCE_Q3
			--,AVG(CASE WHEN Quarters = 'Q4' then NEWBALANCE END) AVG_NEWBALANCE_Q4
			--,AVG(CASE WHEN Quarters = 'Staticpool' then Interest_amount END) AVG_INTEREST_AMOUNT_STATICPOOL
			--,AVG(CASE WHEN Quarters = 'Q1' then Interest_amount END) AVG_INTEREST_AMOUNT_Q1
			--,AVG(CASE WHEN Quarters = 'Q2' then Interest_amount END) AVG_INTEREST_AMOUNT_Q2
			--,AVG(CASE WHEN Quarters = 'Q3' then Interest_amount END) AVG_INTEREST_AMOUNT_Q3
			--,AVG(CASE WHEN Quarters = 'Q4' then Interest_amount END) AVG_INTEREST_AMOUNT_Q4
			--,AVG(CASE WHEN Quarters = 'Staticpool' then FEEAMOUNT END) AVG_FEEAMOUNT_STATICPOOL
			--,AVG(CASE WHEN Quarters = 'Q1' then FEEAMOUNT END) AVG_FEEAMOUNT_Q1
			--,AVG(CASE WHEN Quarters = 'Q2' then FEEAMOUNT END) AVG_FEEAMOUNT_Q2
			--,AVG(CASE WHEN Quarters = 'Q3' then FEEAMOUNT END) AVG_FEEAMOUNT_Q3
			--,AVG(CASE WHEN Quarters = 'Q4' then FEEAMOUNT END) AVG_FEEAMOUNT_Q4

			--,sum(Loan_addon) Sum_count_loan_addon		
			--,sum(New_loan) Sum_count_New_loan
			--,sum(loan_payment) Sum_count_loan_payment
			--,sum(CASH) Sum_count_CASH
			--,sum(DRAFT) Sum_count_DRAFT
			--,sum(ACH) Sum_count_ACH
			--,sum(FEE) Sum_count_FEE
			--,sum(HOMEBANKING) Sum_count_HOMEBANKING
			--,sum(INSURANCE) Sum_count_INSURANCE
			--,sum(CHECKS) Sum_count_CHECKS
			--,sum(PAYROLL) Sum_count_PAYROLL
			--,sum(KIOSK) Sum_count_KIOSK
			--,sum(AUDIO_RESPONSE_TELEPHONE) Sum_count_AUDIO_RESPONSE_TELEPHONE
			--,avg(Transaction_amount) Avg_Transaction_amount
			--,avg(NEWBALANCE) Avg_NEWBALANCE
			--,avg(Interest_amount) avg_Interest_amount
			--,avg(FEEAMOUNT) avg_FEEAMOUNT
			--,sum(Transaction_amount) sum_Transaction_amount
			--,sum(Interest_amount) sum_Interest_amount
			--,sum(FEEAMOUNT) Sum_FEEAMOUNT
			 
			 from #temp_loan_transaction
			 --group by PARENTACCOUNT
		     group by SSN
			 ) A
			 left join 
			 ( SELECT SSN [SSN_Tran]
			  --PARENTACCOUNT [PARENTACCOUNT00]
            ,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_Q4	
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCECommercialLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCE_CommercialLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCE_CommercialLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCE_CommercialLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCE_CommercialLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_Q4

            ,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_Q4	
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_Q4	
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_Q4	
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_VehicleLoan_Q4	
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_VehicleLoan_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_VehicleLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_VehicleLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_VehicleLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_VehicleLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_VehicleLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_VehicleLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_VehicleLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_VehicleLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_VehicleLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_VehicleLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_VehicleLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_VehicleLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_VehicleLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_VehicleLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_VehicleLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_VehicleLoan_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_Q4	
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_Q4
			 FROM #temp_loan_transaction
			 --group by PARENTACCOUNT
			 group by SSN
			 ) B
			 on A.SSN = B.SSN_Tran )


--- Drift of the Loan Transaction data

			 DROP TABLE IF EXISTS #LOAN_TRANSACTION_derived_vars
			 SELECT SSN [SSN002]
			 --PARENTACCOUNT
			        --,UNID
			        ,COUNT_LOAN_ADDON_STATICPOOL
			        ,COUNT_LOAN_ADDON_Q1
					,CASE WHEN ( COUNT_LOAN_ADDON_Q1 IS NULL AND COUNT_LOAN_ADDON_Q2 IS  NULL ) THEN COUNT_LOAN_ADDON_Q1 else (ISNULL(COUNT_LOAN_ADDON_Q1,0)-ISNULL(COUNT_LOAN_ADDON_Q2,0)) end DFT_COUNT_LOAN_ADDON_Q1_Q2
					,CASE WHEN ( COUNT_LOAN_ADDON_Q1 IS NULL AND COUNT_LOAN_ADDON_Q3 IS  NULL ) THEN COUNT_LOAN_ADDON_Q1 else (ISNULL(COUNT_LOAN_ADDON_Q1,0)-ISNULL(COUNT_LOAN_ADDON_Q3,0)) end DFT_COUNT_LOAN_ADDON_Q1_Q3
					--,CASE WHEN ( COUNT_LOAN_ADDON_Q1 IS NULL AND COUNT_LOAN_ADDON_Q4 IS  NULL ) THEN COUNT_LOAN_ADDON_Q1 else (ISNULL(COUNT_LOAN_ADDON_Q1,0)-ISNULL(COUNT_LOAN_ADDON_Q4,0)) end DFT_COUNT_LOAN_ADDON_Q1_Q4
					,COUNT_NEW_LOAN_STATICPOOL
					,COUNT_NEW_LOAN_Q1
					,CASE WHEN ( COUNT_NEW_LOAN_Q1 IS NULL AND COUNT_NEW_LOAN_Q2 IS  NULL ) THEN COUNT_NEW_LOAN_Q1 else (ISNULL(COUNT_NEW_LOAN_Q1,0)-ISNULL(COUNT_NEW_LOAN_Q2,0)) end DFT_COUNT_NEW_LOAN_Q1_Q2
					,CASE WHEN ( COUNT_NEW_LOAN_Q1 IS NULL AND COUNT_NEW_LOAN_Q3 IS  NULL ) THEN COUNT_NEW_LOAN_Q1 else (ISNULL(COUNT_NEW_LOAN_Q1,0)-ISNULL(COUNT_NEW_LOAN_Q3,0)) end DFT_COUNT_NEW_LOAN_Q1_Q3
					--,CASE WHEN ( COUNT_NEW_LOAN_Q1 IS NULL AND COUNT_NEW_LOAN_Q4 IS  NULL ) THEN COUNT_NEW_LOAN_Q1 else (ISNULL(COUNT_NEW_LOAN_Q1,0)-ISNULL(COUNT_NEW_LOAN_Q4,0)) end DFT_COUNT_NEW_LOAN_Q1_Q4
					,COUNT_LOAN_PAYMENT_STATICPOOL
					,COUNT_LOAN_PAYMENT_Q1
					,CASE WHEN ( COUNT_LOAN_PAYMENT_Q1 IS NULL AND COUNT_LOAN_PAYMENT_Q2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_Q1,0) - (ISNULL(COUNT_LOAN_PAYMENT_Q2,0))) end DFT_COUNT_LOAN_PAYMENT_Q1_Q2
					,CASE WHEN ( COUNT_LOAN_PAYMENT_Q1 IS NULL AND COUNT_LOAN_PAYMENT_Q3 IS  NULL ) THEN COUNT_LOAN_PAYMENT_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_Q1,0) - (ISNULL(COUNT_LOAN_PAYMENT_Q3,0))) end DFT_COUNT_LOAN_PAYMENT_Q1_Q3
					--,CASE WHEN ( COUNT_LOAN_PAYMENT_Q1 IS NULL AND COUNT_LOAN_PAYMENT_Q4 IS  NULL ) THEN COUNT_LOAN_PAYMENT_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_Q1,0) - (ISNULL(COUNT_LOAN_PAYMENT_Q4,0))) end DFT_COUNT_LOAN_PAYMENT_Q1_Q4
					,COUNT_CASH_STATICPOOL
					,COUNT_CASH_Q1
					,CASE WHEN ( COUNT_CASH_Q1 IS NULL AND COUNT_CASH_Q2 IS  NULL ) THEN COUNT_CASH_Q1 else (ISNULL(COUNT_CASH_Q1,0) - ISNULL(COUNT_CASH_Q2,0)) end DFT_COUNT_CASH_Q1_Q2
					,CASE WHEN ( COUNT_CASH_Q1 IS NULL AND COUNT_CASH_Q3 IS  NULL ) THEN COUNT_CASH_Q1 else (ISNULL(COUNT_CASH_Q1,0) - ISNULL(COUNT_CASH_Q3,0)) end DFT_COUNT_CASH_Q1_Q3
					--,CASE WHEN ( COUNT_CASH_Q1 IS NULL AND COUNT_CASH_Q4 IS  NULL ) THEN COUNT_CASH_Q1 else (ISNULL(COUNT_CASH_Q1,0) - ISNULL(COUNT_CASH_Q4,0)) end DFT_COUNT_CASH_Q1_Q4
					,COUNT_DRAFT_STATICPOOL
					,COUNT_DRAFT_Q1
					,CASE WHEN ( COUNT_DRAFT_Q1 IS NULL AND COUNT_DRAFT_Q2 IS  NULL ) THEN COUNT_DRAFT_Q1 else (ISNULL(COUNT_DRAFT_Q1,0)-ISNULL(COUNT_DRAFT_Q2,0)) end DFT_COUNT_DRAFT_Q1_Q2
					,CASE WHEN ( COUNT_DRAFT_Q1 IS NULL AND COUNT_DRAFT_Q3 IS  NULL ) THEN COUNT_DRAFT_Q1 else (ISNULL(COUNT_DRAFT_Q1,0)-ISNULL(COUNT_DRAFT_Q3,0)) end DFT_COUNT_DRAFT_Q1_Q3
					--,CASE WHEN ( COUNT_DRAFT_Q1 IS NULL AND COUNT_DRAFT_Q4 IS  NULL ) THEN COUNT_DRAFT_Q1 else (ISNULL(COUNT_DRAFT_Q1,0)-ISNULL(COUNT_DRAFT_Q4,0)) end DFT_COUNT_DRAFT_Q1_Q4
					,COUNT_ACH_STATICPOOL
					,COUNT_ACH_Q1
					,CASE WHEN ( COUNT_ACH_Q1 IS NULL AND COUNT_ACH_Q2 IS  NULL ) THEN COUNT_ACH_Q1 else (ISNULL(COUNT_ACH_Q1,0)-ISNULL(COUNT_ACH_Q2,0)) end DFT_COUNT_ACH_Q1_Q2
					,CASE WHEN ( COUNT_ACH_Q1 IS NULL AND COUNT_ACH_Q3 IS  NULL ) THEN COUNT_ACH_Q1 else (ISNULL(COUNT_ACH_Q1,0)-ISNULL(COUNT_ACH_Q3,0)) end DFT_COUNT_ACH_Q1_Q3
					--,CASE WHEN ( COUNT_ACH_Q1 IS NULL AND COUNT_ACH_Q4 IS  NULL ) THEN COUNT_ACH_Q1 else (ISNULL(COUNT_ACH_Q1,0)-ISNULL(COUNT_ACH_Q4,0)) end DFT_COUNT_ACH_Q1_Q4
					,COUNT_FEE_STATICPOOL
					,COUNT_FEE_Q1
					,CASE WHEN (COUNT_FEE_Q1 IS NULL AND COUNT_FEE_Q2 IS  NULL ) THEN COUNT_FEE_Q1 else (ISNULL(COUNT_FEE_Q1,0)-ISNULL(COUNT_FEE_Q2,0)) end DFT_COUNT_FEE_Q1_Q2
					,CASE WHEN (COUNT_FEE_Q1 IS NULL AND COUNT_FEE_Q3 IS  NULL ) THEN COUNT_FEE_Q1 else (ISNULL(COUNT_FEE_Q1,0)-ISNULL(COUNT_FEE_Q3,0)) end DFT_COUNT_FEE_Q1_Q3
					--,CASE WHEN (COUNT_FEE_Q1 IS NULL AND COUNT_FEE_Q4 IS  NULL ) THEN COUNT_FEE_Q1 else (ISNULL(COUNT_FEE_Q1,0)-ISNULL(COUNT_FEE_Q4,0)) end DFT_COUNT_FEE_Q1_Q4
					,COUNT_HOMEBANKING_STATICPOOL
					,COUNT_HOMEBANKING_Q1
					,CASE WHEN (COUNT_HOMEBANKING_Q1 IS NULL AND COUNT_HOMEBANKING_Q2 IS  NULL ) THEN COUNT_HOMEBANKING_Q1 else (ISNULL(COUNT_HOMEBANKING_Q1,0)-ISNULL(COUNT_HOMEBANKING_Q2,0)) end DFT_COUNT_HOMEBANKING_Q1_Q2
					,CASE WHEN (COUNT_HOMEBANKING_Q1 IS NULL AND COUNT_HOMEBANKING_Q3 IS  NULL ) THEN COUNT_HOMEBANKING_Q1 else (ISNULL(COUNT_HOMEBANKING_Q1,0)-ISNULL(COUNT_HOMEBANKING_Q3,0)) end DFT_COUNT_HOMEBANKING_Q1_Q3
					--,CASE WHEN (COUNT_HOMEBANKING_Q1 IS NULL AND COUNT_HOMEBANKING_Q4 IS  NULL ) THEN COUNT_HOMEBANKING_Q1 else (ISNULL(COUNT_HOMEBANKING_Q1,0)-ISNULL(COUNT_HOMEBANKING_Q4,0)) end DFT_COUNT_HOMEBANKING_Q1_Q4
					,COUNT_INSURANCE_STATICPOOL
					,COUNT_INSURANCE_Q1
					,CASE WHEN ( COUNT_INSURANCE_Q1 IS NULL AND COUNT_INSURANCE_Q2 IS  NULL ) THEN COUNT_INSURANCE_Q1 else (ISNULL(COUNT_INSURANCE_Q1,0)-ISNULL(COUNT_INSURANCE_Q2,0)) end DFT_COUNT_INSURANCE_Q1_Q2
					,CASE WHEN ( COUNT_INSURANCE_Q1 IS NULL AND COUNT_INSURANCE_Q3 IS  NULL ) THEN COUNT_INSURANCE_Q1 else (ISNULL(COUNT_INSURANCE_Q1,0)-ISNULL(COUNT_INSURANCE_Q3,0)) end DFT_COUNT_INSURANCE_Q1_Q3
					--,CASE WHEN ( COUNT_INSURANCE_Q1 IS NULL AND COUNT_INSURANCE_Q4 IS  NULL ) THEN COUNT_INSURANCE_Q1 else (ISNULL(COUNT_INSURANCE_Q1,0)-ISNULL(COUNT_INSURANCE_Q4,0)) end DFT_COUNT_INSURANCE_Q1_Q4
					,COUNT_CHECKS_STATICPOOL
					,COUNT_CHECKS_Q1
					,CASE WHEN (COUNT_CHECKS_Q1 IS NULL AND COUNT_CHECKS_Q2 IS  NULL ) THEN COUNT_CHECKS_Q1 else (ISNULL(COUNT_CHECKS_Q1,0)-ISNULL(COUNT_CHECKS_Q2,0)) end DFT_COUNT_CHECKS_Q1_Q2
					,CASE WHEN (COUNT_CHECKS_Q1 IS NULL AND COUNT_CHECKS_Q3 IS  NULL ) THEN COUNT_CHECKS_Q1 else (ISNULL(COUNT_CHECKS_Q1,0)-ISNULL(COUNT_CHECKS_Q3,0)) end DFT_COUNT_CHECKS_Q1_Q3
					--,CASE WHEN (COUNT_CHECKS_Q1 IS NULL AND COUNT_CHECKS_Q4 IS  NULL ) THEN COUNT_CHECKS_Q1 else (ISNULL(COUNT_CHECKS_Q1,0)-ISNULL(COUNT_CHECKS_Q4,0)) end DFT_COUNT_CHECKS_Q1_Q4
					,COUNT_PAYROLL_STATICPOOL
					,COUNT_PAYROLL_Q1
					,CASE WHEN (COUNT_CHECKS_Q1 IS NULL AND COUNT_CHECKS_Q2 IS  NULL ) THEN COUNT_CHECKS_Q1 else (ISNULL(COUNT_PAYROLL_Q1,0)-ISNULL(COUNT_PAYROLL_Q2,0)) end DFT_COUNT_PAYROLL_Q1_Q2
					,CASE WHEN (COUNT_CHECKS_Q1 IS NULL AND COUNT_CHECKS_Q3 IS  NULL ) THEN COUNT_CHECKS_Q1 else (ISNULL(COUNT_PAYROLL_Q1,0)-ISNULL(COUNT_PAYROLL_Q3,0)) end DFT_COUNT_PAYROLL_Q1_Q3
					--,CASE WHEN (COUNT_CHECKS_Q1 IS NULL AND COUNT_CHECKS_Q4 IS  NULL ) THEN COUNT_CHECKS_Q1 else (ISNULL(COUNT_PAYROLL_Q1,0)-ISNULL(COUNT_PAYROLL_Q4,0)) end DFT_COUNT_PAYROLL_Q1_Q4
					,COUNT_KIOSK_STATICPOOL
					,COUNT_KIOSK_Q1
					,CASE WHEN ( COUNT_KIOSK_Q1 IS NULL AND COUNT_KIOSK_Q2 IS  NULL ) THEN COUNT_KIOSK_Q1 else (ISNULL(COUNT_KIOSK_Q1,0)-ISNULL(COUNT_KIOSK_Q2,0)) end DFT_COUNT_KIOSK_Q1_Q2
					,CASE WHEN ( COUNT_KIOSK_Q1 IS NULL AND COUNT_KIOSK_Q3 IS  NULL ) THEN COUNT_KIOSK_Q1 else (ISNULL(COUNT_KIOSK_Q1,0)-ISNULL(COUNT_KIOSK_Q3,0)) end DFT_COUNT_KIOSK_Q1_Q3
					--,CASE WHEN ( COUNT_KIOSK_Q1 IS NULL AND COUNT_KIOSK_Q4 IS  NULL ) THEN COUNT_KIOSK_Q1 else (ISNULL(COUNT_KIOSK_Q1,0)-ISNULL(COUNT_KIOSK_Q4,0)) end DFT_COUNT_KIOSK_Q1_Q4
					,COUNT_AUDIO_RESPONSE_TELEPHONE_STATICPOOL
					,COUNT_AUDIO_RESPONSE_TELEPHONE_Q1
					,CASE WHEN (COUNT_AUDIO_RESPONSE_TELEPHONE_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_Q2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Q1,0)-ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Q2,0)) end DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q2
					,CASE WHEN (COUNT_AUDIO_RESPONSE_TELEPHONE_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_Q3 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Q1,0)-ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Q3,0)) end DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q3
					--,CASE WHEN (COUNT_AUDIO_RESPONSE_TELEPHONE_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_Q4 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Q1,0)-ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Q4,0)) end DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q4
					--,LOAN_TRANSACTION_AMOUNT_STATICPOOL
					--,LOAN_TRANSACTION_AMOUNT_Q1
					--,(ISNULL(LOAN_TRANSACTION_AMOUNT_Q1,0)-ISNULL(LOAN_TRANSACTION_AMOUNT_Q2,0)) DFT_LOAN_TRANSACTION_AMOUNT_Q1_Q2
					--,(ISNULL(LOAN_TRANSACTION_AMOUNT_Q1,0)-ISNULL(LOAN_TRANSACTION_AMOUNT_Q3,0)) DFT_LOAN_TRANSACTION_AMOUNT_Q1_Q3
					----,(ISNULL(LOAN_TRANSACTION_AMOUNT_Q1,0)-ISNULL(LOAN_TRANSACTION_AMOUNT_Q4,0)) DFT_LOAN_TRANSACTION_AMOUNT_Q1_Q4
					--,INTEREST_AMOUNT_STATICPOOL
					--,INTEREST_AMOUNT_Q1
					--,(ISNULL(INTEREST_AMOUNT_Q1,0)-ISNULL(INTEREST_AMOUNT_Q2,0)) DFT_INTEREST_AMOUNT_Q1_Q2
					--,(ISNULL(INTEREST_AMOUNT_Q1,0)-ISNULL(INTEREST_AMOUNT_Q3,0)) DFT_INTEREST_AMOUNT_Q1_Q3
					----,(ISNULL(INTEREST_AMOUNT_Q1,0)-ISNULL(INTEREST_AMOUNT_Q4,0)) DFT_INTEREST_AMOUNT_Q1_Q4
					--,FEEAMOUNT_STATICPOOL
					--,FEEAMOUNT_Q1
					--,(ISNULL(FEEAMOUNT_Q1,0)-ISNULL(FEEAMOUNT_Q2,0)) DFT_FEEAMOUNT_Q1_Q2
					--,(ISNULL(FEEAMOUNT_Q1,0)-ISNULL(FEEAMOUNT_Q3,0)) DFT_FEEAMOUNT_Q1_Q3
					----,(ISNULL(FEEAMOUNT_Q1,0)-ISNULL(FEEAMOUNT_Q4,0)) DFT_FEEAMOUNT_Q1_Q4
					--,AVG_LOAN_TRANSACTION_AMOUNT_STATICPOOL
					--,AVG_LOAN_TRANSACTION_AMOUNT_Q1
					--,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Q1,0)-ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Q2,0)) DFT_AVG_LOAN_TRANSACTION_AMOUNT_Q1_Q2
					--,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Q1,0)-ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Q3,0)) DFT_AVG_LOAN_TRANSACTION_AMOUNT_Q1_Q3
					----,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Q1,0)-ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Q4,0)) DFT_AVG_LOAN_TRANSACTION_AMOUNT_Q1_Q4
					--,AVG_NEWBALANCE_STATICPOOL
					--,AVG_NEWBALANCE_Q1
					--,(ISNULL(AVG_NEWBALANCE_Q1,0)-ISNULL(AVG_NEWBALANCE_Q2,0)) DFT_AVG_NEWBALANCE_Q1_Q2
					--,(ISNULL(AVG_NEWBALANCE_Q1,0)-ISNULL(AVG_NEWBALANCE_Q3,0)) DFT_AVG_NEWBALANCE_Q1_Q3
					----,(ISNULL(AVG_NEWBALANCE_Q1,0)-ISNULL(AVG_NEWBALANCE_Q4,0)) DFT_AVG_NEWBALANCE_Q1_Q4
					--,AVG_INTEREST_AMOUNT_STATICPOOL
					--,AVG_INTEREST_AMOUNT_Q1
					--,(ISNULL(AVG_INTEREST_AMOUNT_Q1,0)-ISNULL(AVG_INTEREST_AMOUNT_Q2,0)) DFT_AVG_INTEREST_AMOUNT_Q1_Q2
					--,(ISNULL(AVG_INTEREST_AMOUNT_Q1,0)-ISNULL(AVG_INTEREST_AMOUNT_Q3,0)) DFT_AVG_INTEREST_AMOUNT_Q1_Q3
					----,(ISNULL(AVG_INTEREST_AMOUNT_Q1,0)-ISNULL(AVG_INTEREST_AMOUNT_Q4,0)) DFT_AVG_INTEREST_AMOUNT_Q1_Q4
					--,AVG_FEEAMOUNT_STATICPOOL
					--,AVG_FEEAMOUNT_Q1
					--,(ISNULL(AVG_FEEAMOUNT_Q1,0)-ISNULL(AVG_FEEAMOUNT_Q2,0)) DFT_AVG_FEEAMOUNT_Q1_Q2
					--,(ISNULL(AVG_FEEAMOUNT_Q1,0)-ISNULL(AVG_FEEAMOUNT_Q3,0)) DFT_AVG_FEEAMOUNT_Q1_Q3
					----,(ISNULL(AVG_FEEAMOUNT_Q1,0)-ISNULL(AVG_FEEAMOUNT_Q4,0)) DFT_AVG_FEEAMOUNT_Q1_Q4
	         --,COUNT_LOAN_ADDON_CommercialLoan_SP
	         ,COUNT_LOAN_ADDON_CommercialLoan_Q1
			 ,CASE WHEN ( COUNT_LOAN_ADDON_CommercialLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_CommercialLoan_Q2 IS  NULL ) THEN COUNT_LOAN_ADDON_CommercialLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q2,0)) end [DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_LOAN_ADDON_CommercialLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_CommercialLoan_Q3 IS  NULL ) THEN COUNT_LOAN_ADDON_CommercialLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q3,0)) end [DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_LOAN_ADDON_CommercialLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_CommercialLoan_Q4 IS  NULL ) THEN COUNT_LOAN_ADDON_CommercialLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q4,0)) end [DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q4]
			 --,COUNT_NEW_LOAN_CommercialLoan_SP
			 ,COUNT_NEW_LOAN_CommercialLoan_Q1
			 ,CASE WHEN ( COUNT_NEW_LOAN_CommercialLoan_Q1 IS NULL AND COUNT_NEW_LOAN_CommercialLoan_Q2 IS  NULL ) THEN COUNT_NEW_LOAN_CommercialLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q2,0)) end [COUNT_NEW_LOAN_CommercialLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_NEW_LOAN_CommercialLoan_Q1 IS NULL AND COUNT_NEW_LOAN_CommercialLoan_Q3 IS  NULL ) THEN COUNT_NEW_LOAN_CommercialLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q3,0)) end [COUNT_NEW_LOAN_CommercialLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_NEW_LOAN_CommercialLoan_Q1 IS NULL AND COUNT_NEW_LOAN_CommercialLoan_Q4 IS  NULL ) THEN COUNT_NEW_LOAN_CommercialLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q4,0)) end [COUNT_NEW_LOAN_CommercialLoan_Q1_Q4]
			 --,COUNT_LOAN_PAYMENT_CommercialLoan_SP
			 ,COUNT_LOAN_PAYMENT_CommercialLoan_Q1
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_CommercialLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_CommercialLoan_Q2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_CommercialLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q2,0)) end [DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_CommercialLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_CommercialLoan_Q3 IS  NULL ) THEN COUNT_LOAN_PAYMENT_CommercialLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q3,0)) end [DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_LOAN_PAYMENT_CommercialLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_CommercialLoan_Q4 IS  NULL ) THEN COUNT_LOAN_PAYMENT_CommercialLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q4,0)) end [DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q4]
			 --,COUNT_CASH_CommercialLoan_SP
			 ,COUNT_CASH_CommercialLoan_Q1
			 ,CASE WHEN ( COUNT_CASH_CommercialLoan_Q1 IS NULL AND COUNT_CASH_CommercialLoan_Q2 IS  NULL ) THEN COUNT_CASH_CommercialLoan_Q1 else (ISNULL(COUNT_CASH_CommercialLoan_Q1,0) - ISNULL(COUNT_CASH_CommercialLoan_Q2,0)) end [DFT_COUNT_CASH_CommercialLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_CASH_CommercialLoan_Q1 IS NULL AND COUNT_CASH_CommercialLoan_Q3 IS  NULL ) THEN COUNT_CASH_CommercialLoan_Q1 else (ISNULL(COUNT_CASH_CommercialLoan_Q1,0) - ISNULL(COUNT_CASH_CommercialLoan_Q3,0)) end [DFT_COUNT_CASH_CommercialLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_CASH_CommercialLoan_Q1 IS NULL AND COUNT_CASH_CommercialLoan_Q4 IS  NULL ) THEN COUNT_CASH_CommercialLoan_Q1 else (ISNULL(COUNT_CASH_CommercialLoan_Q1,0) - ISNULL(COUNT_CASH_CommercialLoan_Q4,0)) end [DFT_COUNT_CASH_CommercialLoan_Q1_Q4]
			 --,COUNT_DRAFT_CommercialLoan_SP
			 ,COUNT_DRAFT_CommercialLoan_Q1
			 ,CASE WHEN ( COUNT_DRAFT_CommercialLoan_Q1 IS NULL AND COUNT_DRAFT_CommercialLoan_Q2 IS  NULL ) THEN COUNT_DRAFT_CommercialLoan_Q1 else (ISNULL(COUNT_DRAFT_CommercialLoan_Q1,0) - ISNULL(COUNT_DRAFT_CommercialLoan_Q2,0)) end [DFT_COUNT_DRAFT_CommercialLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_DRAFT_CommercialLoan_Q1 IS NULL AND COUNT_DRAFT_CommercialLoan_Q3 IS  NULL ) THEN COUNT_DRAFT_CommercialLoan_Q1 else (ISNULL(COUNT_DRAFT_CommercialLoan_Q1,0) - ISNULL(COUNT_DRAFT_CommercialLoan_Q3,0)) end [DFT_COUNT_DRAFT_CommercialLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_DRAFT_CommercialLoan_Q1 IS NULL AND COUNT_DRAFT_CommercialLoan_Q4 IS  NULL ) THEN COUNT_DRAFT_CommercialLoan_Q1 else (ISNULL(COUNT_DRAFT_CommercialLoan_Q1,0) - ISNULL(COUNT_DRAFT_CommercialLoan_Q4,0)) end [DFT_COUNT_DRAFT_CommercialLoan_Q1_Q4]
			 --,COUNT_ACH_CommercialLoan_SP
			 ,COUNT_ACH_CommercialLoan_Q1
			 ,CASE WHEN ( COUNT_ACH_CommercialLoan_Q1 IS NULL AND COUNT_ACH_CommercialLoan_Q2 IS  NULL ) THEN COUNT_ACH_CommercialLoan_Q1 else (ISNULL(COUNT_ACH_CommercialLoan_Q1,0) - ISNULL(COUNT_ACH_CommercialLoan_Q2,0)) end [DFT_COUNT_ACH_CommercialLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_ACH_CommercialLoan_Q1 IS NULL AND COUNT_ACH_CommercialLoan_Q3 IS  NULL ) THEN COUNT_ACH_CommercialLoan_Q1 else (ISNULL(COUNT_ACH_CommercialLoan_Q1,0) - ISNULL(COUNT_ACH_CommercialLoan_Q3,0)) end [DFT_COUNT_ACH_CommercialLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_ACH_CommercialLoan_Q1 IS NULL AND COUNT_ACH_CommercialLoan_Q4 IS  NULL ) THEN COUNT_ACH_CommercialLoan_Q1 else (ISNULL(COUNT_ACH_CommercialLoan_Q1,0) - ISNULL(COUNT_ACH_CommercialLoan_Q4,0)) end [DFT_COUNT_ACH_CommercialLoan_Q1_Q4]
			 --,COUNT_FEE_CommercialLoan_SP
			 ,COUNT_FEE_CommercialLoan_Q1
			 ,CASE WHEN ( COUNT_FEE_CommercialLoan_Q1 IS NULL AND COUNT_FEE_CommercialLoan_Q2 IS  NULL ) THEN COUNT_FEE_CommercialLoan_Q1 else (ISNULL(COUNT_FEE_CommercialLoan_Q1,0) - ISNULL(COUNT_FEE_CommercialLoan_Q2,0)) end [DFT_COUNT_FEE_CommercialLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_FEE_CommercialLoan_Q1 IS NULL AND COUNT_FEE_CommercialLoan_Q3 IS  NULL ) THEN COUNT_FEE_CommercialLoan_Q1 else (ISNULL(COUNT_FEE_CommercialLoan_Q1,0) - ISNULL(COUNT_FEE_CommercialLoan_Q3,0)) end [DFT_COUNT_FEE_CommercialLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_FEE_CommercialLoan_Q1 IS NULL AND COUNT_FEE_CommercialLoan_Q4 IS  NULL ) THEN COUNT_FEE_CommercialLoan_Q1 else (ISNULL(COUNT_FEE_CommercialLoan_Q1,0) - ISNULL(COUNT_FEE_CommercialLoan_Q4,0)) end [DFT_COUNT_FEE_CommercialLoan_Q1_Q4]
			 --,COUNT_HOMEBANKING_CommercialLoan_SP
			 ,COUNT_HOMEBANKING_CommercialLoan_Q1
			 ,CASE WHEN (COUNT_HOMEBANKING_CommercialLoan_Q1 IS NULL AND COUNT_HOMEBANKING_CommercialLoan_Q2 IS  NULL ) THEN COUNT_HOMEBANKING_CommercialLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q2,0)) end [DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_HOMEBANKING_CommercialLoan_Q1 IS NULL AND COUNT_HOMEBANKING_CommercialLoan_Q3 IS  NULL ) THEN COUNT_HOMEBANKING_CommercialLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q3,0)) end [DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_HOMEBANKING_CommercialLoan_Q1 IS NULL AND COUNT_HOMEBANKING_CommercialLoan_Q4 IS  NULL ) THEN COUNT_HOMEBANKING_CommercialLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q4,0)) end [DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q4]
			 --,COUNT_INSURANCE_CommercialLoan_SP
			 ,COUNT_INSURANCE_CommercialLoan_Q1
			 ,CASE WHEN (COUNT_INSURANCE_CommercialLoan_Q1 IS NULL AND COUNT_INSURANCE_CommercialLoan_Q2 IS  NULL ) THEN COUNT_INSURANCE_CommercialLoan_Q1 else (ISNULL(COUNT_INSURANCE_CommercialLoan_Q1,0) - ISNULL(COUNT_INSURANCE_CommercialLoan_Q2,0)) end [DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_INSURANCE_CommercialLoan_Q1 IS NULL AND COUNT_INSURANCE_CommercialLoan_Q3 IS  NULL ) THEN COUNT_INSURANCE_CommercialLoan_Q1 else (ISNULL(COUNT_INSURANCE_CommercialLoan_Q1,0) - ISNULL(COUNT_INSURANCE_CommercialLoan_Q3,0)) end [DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_INSURANCE_CommercialLoan_Q1 IS NULL AND COUNT_INSURANCE_CommercialLoan_Q4 IS  NULL ) THEN COUNT_INSURANCE_CommercialLoan_Q1 else (ISNULL(COUNT_INSURANCE_CommercialLoan_Q1,0) - ISNULL(COUNT_INSURANCE_CommercialLoan_Q4,0)) end [DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q4]
			 --,COUNT_CHECKS_CommercialLoan_SP
			 ,COUNT_CHECKS_CommercialLoan_Q1
			 ,CASE WHEN (COUNT_CHECKS_CommercialLoan_Q1 IS NULL AND COUNT_CHECKS_CommercialLoan_Q2 IS  NULL ) THEN COUNT_CHECKS_CommercialLoan_Q1 else (ISNULL(COUNT_CHECKS_CommercialLoan_Q1,0) - ISNULL(COUNT_CHECKS_CommercialLoan_Q2,0)) end [DFT_COUNT_CHECKS_CommercialLoan_Q1_Q2] 
			 ,CASE WHEN (COUNT_CHECKS_CommercialLoan_Q1 IS NULL AND COUNT_CHECKS_CommercialLoan_Q3 IS  NULL ) THEN COUNT_CHECKS_CommercialLoan_Q1 else (ISNULL(COUNT_CHECKS_CommercialLoan_Q1,0) - ISNULL(COUNT_CHECKS_CommercialLoan_Q3,0)) end [DFT_COUNT_CHECKS_CommercialLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_CHECKS_CommercialLoan_Q1 IS NULL AND COUNT_CHECKS_CommercialLoan_Q4 IS  NULL ) THEN COUNT_CHECKS_CommercialLoan_Q1 else (ISNULL(COUNT_CHECKS_CommercialLoan_Q1,0) - ISNULL(COUNT_CHECKS_CommercialLoan_Q4,0)) end [DFT_COUNT_CHECKS_CommercialLoan_Q1_Q4]
			 --,COUNT_PAYROLL_CommercialLoan_SP
			 ,COUNT_PAYROLL_CommercialLoan_Q1
			 ,CASE WHEN (COUNT_PAYROLL_CommercialLoan_Q1 IS NULL AND COUNT_PAYROLL_CommercialLoan_Q2 IS  NULL ) THEN COUNT_PAYROLL_CommercialLoan_Q1 else (ISNULL(COUNT_PAYROLL_CommercialLoan_Q1,0) - ISNULL(COUNT_PAYROLL_CommercialLoan_Q2,0)) end [DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_PAYROLL_CommercialLoan_Q1 IS NULL AND COUNT_PAYROLL_CommercialLoan_Q3 IS  NULL ) THEN COUNT_PAYROLL_CommercialLoan_Q1 else (ISNULL(COUNT_PAYROLL_CommercialLoan_Q1,0) - ISNULL(COUNT_PAYROLL_CommercialLoan_Q3,0)) end [DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_PAYROLL_CommercialLoan_Q1 IS NULL AND COUNT_PAYROLL_CommercialLoan_Q4 IS  NULL ) THEN COUNT_PAYROLL_CommercialLoan_Q1 else (ISNULL(COUNT_PAYROLL_CommercialLoan_Q1,0) - ISNULL(COUNT_PAYROLL_CommercialLoan_Q4,0)) end [DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q4]
			 --,COUNT_KIOSK_CommercialLoan_SP
			 ,COUNT_KIOSK_CommercialLoan_Q1
			 ,CASE WHEN (COUNT_KIOSK_CommercialLoan_Q1 IS NULL AND COUNT_KIOSK_CommercialLoan_Q2 IS  NULL ) THEN COUNT_KIOSK_CommercialLoan_Q1 else (ISNULL(COUNT_KIOSK_CommercialLoan_Q1,0) - ISNULL(COUNT_KIOSK_CommercialLoan_Q2,0)) end [DFT_COUNT_KIOSK_CommercialLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_KIOSK_CommercialLoan_Q1 IS NULL AND COUNT_KIOSK_CommercialLoan_Q3 IS  NULL ) THEN COUNT_KIOSK_CommercialLoan_Q1 else (ISNULL(COUNT_KIOSK_CommercialLoan_Q1,0) - ISNULL(COUNT_KIOSK_CommercialLoan_Q3,0)) end [DFT_COUNT_KIOSK_CommercialLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_KIOSK_CommercialLoan_Q1 IS NULL AND COUNT_KIOSK_CommercialLoan_Q4 IS  NULL ) THEN COUNT_KIOSK_CommercialLoan_Q1 else (ISNULL(COUNT_KIOSK_CommercialLoan_Q1,0) - ISNULL(COUNT_KIOSK_CommercialLoan_Q4,0)) end [DFT_COUNT_KIOSK_CommercialLoan_Q1_Q4]
			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_SP
			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q3 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q3,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q4 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q4,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q4]

			 ,LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q2]
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q3]
			 --,CASE WHEN (LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q4]
			 --,INTEREST_AMOUNT_CommercialLoan_SP
			 ,INTEREST_AMOUNT_CommercialLoan_Q1
			 ,CASE WHEN (INTEREST_AMOUNT_CommercialLoan_Q1 IS NULL AND INTEREST_AMOUNT_CommercialLoan_Q2 IS  NULL ) THEN INTEREST_AMOUNT_CommercialLoan_Q1 else (ISNULL(INTEREST_AMOUNT_CommercialLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_CommercialLoan_Q2,0)) end [DFT_INTEREST_AMOUNT_CommercialLoan_Q1_Q2]
			 ,CASE WHEN (INTEREST_AMOUNT_CommercialLoan_Q1 IS NULL AND INTEREST_AMOUNT_CommercialLoan_Q3 IS  NULL ) THEN INTEREST_AMOUNT_CommercialLoan_Q1 else (ISNULL(INTEREST_AMOUNT_CommercialLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_CommercialLoan_Q3,0)) end [DFT_INTEREST_AMOUNT_CommercialLoan_Q1_Q3]
			 --,CASE WHEN (INTEREST_AMOUNT_CommercialLoan_Q1 IS NULL AND INTEREST_AMOUNT_CommercialLoan_Q4 IS  NULL ) THEN INTEREST_AMOUNT_CommercialLoan_Q1 else (ISNULL(INTEREST_AMOUNT_CommercialLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_CommercialLoan_Q4,0)) end [DFT_INTEREST_AMOUNT_CommercialLoan_Q1_Q4]
			 --,FEEAMOUNT_CommercialLoan_SP
			 ,FEEAMOUNT_CommercialLoan_Q1
			 ,CASE WHEN (FEEAMOUNT_CommercialLoan_Q1 IS NULL AND FEEAMOUNT_CommercialLoan_Q2 IS  NULL ) THEN FEEAMOUNT_CommercialLoan_Q1 else (ISNULL(FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(FEEAMOUNT_CommercialLoan_Q2,0)) end [DFT_FEEAMOUNT_CommercialLoan_Q1_Q2]
			 ,CASE WHEN (FEEAMOUNT_CommercialLoan_Q1 IS NULL AND FEEAMOUNT_CommercialLoan_Q3 IS  NULL ) THEN FEEAMOUNT_CommercialLoan_Q1 else (ISNULL(FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(FEEAMOUNT_CommercialLoan_Q3,0)) end [DFT_FEEAMOUNT_CommercialLoan_Q1_Q3]
			 --,CASE WHEN (FEEAMOUNT_CommercialLoan_Q1 IS NULL AND FEEAMOUNT_CommercialLoan_Q4 IS  NULL ) THEN FEEAMOUNT_CommercialLoan_Q1 else (ISNULL(FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(FEEAMOUNT_CommercialLoan_Q4,0)) end [DFT_FEEAMOUNT_CommercialLoan_Q1_Q4]
			 --,AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_SP
			 ,AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q2]
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q3]
			 --,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q4]
			 ,AVG_NEWBALANCE_CommercialLoan_Q1
			 ,CASE WHEN (AVG_NEWBALANCE_CommercialLoan_Q1 IS NULL AND AVG_NEWBALANCE_CommercialLoan_Q2 IS  NULL ) THEN AVG_NEWBALANCE_CommercialLoan_Q1 else (ISNULL(AVG_NEWBALANCE_CommercialLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_CommercialLoan_Q2,0)) end [DFT_AVG_NEWBALANCE_CommercialLoan_Q1_Q2]
			 ,CASE WHEN (AVG_NEWBALANCE_CommercialLoan_Q1 IS NULL AND AVG_NEWBALANCE_CommercialLoan_Q3 IS  NULL ) THEN AVG_NEWBALANCE_CommercialLoan_Q1 else (ISNULL(AVG_NEWBALANCE_CommercialLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_CommercialLoan_Q3,0)) end [DFT_AVG_NEWBALANCE_CommercialLoan_Q1_Q3]
			 --,CASE WHEN (AVG_NEWBALANCE_CommercialLoan_Q1 IS NULL AND AVG_NEWBALANCE_CommercialLoan_Q4 IS  NULL ) THEN AVG_NEWBALANCE_CommercialLoan_Q1 else (ISNULL(AVG_NEWBALANCE_CommercialLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_CommercialLoan_Q4,0)) end [DFT_AVG_NEWBALANCE_CommercialLoan_Q1_Q4]
			 --,AVG_FEEAMOUNT_CommercialLoan_SP
			 ,AVG_FEEAMOUNT_CommercialLoan_Q1
			 ,CASE WHEN (AVG_FEEAMOUNT_CommercialLoan_Q1 IS NULL AND AVG_FEEAMOUNT_CommercialLoan_Q2 IS  NULL ) THEN AVG_FEEAMOUNT_CommercialLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q2,0)) end [DFT_AVG_FEEAMOUNT_CommercialLoan_Q1_Q2]
			 ,CASE WHEN (AVG_FEEAMOUNT_CommercialLoan_Q1 IS NULL AND AVG_FEEAMOUNT_CommercialLoan_Q3 IS  NULL ) THEN AVG_FEEAMOUNT_CommercialLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q3,0)) end [DFT_AVG_FEEAMOUNT_CommercialLoan_Q1_Q3]
			 --,CASE WHEN (AVG_FEEAMOUNT_CommercialLoan_Q1 IS NULL AND AVG_FEEAMOUNT_CommercialLoan_Q4 IS  NULL ) THEN AVG_FEEAMOUNT_CommercialLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q4,0)) end [DFT_AVG_FEEAMOUNT_CommercialLoan_Q1_Q4]

	         ,COUNT_LOAN_ADDON_RealEstate_Q1
			 ,CASE WHEN ( COUNT_LOAN_ADDON_RealEstate_Q1 IS NULL AND COUNT_LOAN_ADDON_RealEstate_Q2 IS  NULL ) THEN COUNT_LOAN_ADDON_RealEstate_Q1 else (ISNULL(COUNT_LOAN_ADDON_RealEstate_Q1,0) - ISNULL(COUNT_LOAN_ADDON_RealEstate_Q2,0)) end [DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q2]
			 ,CASE WHEN ( COUNT_LOAN_ADDON_RealEstate_Q1 IS NULL AND COUNT_LOAN_ADDON_RealEstate_Q3 IS  NULL ) THEN COUNT_LOAN_ADDON_RealEstate_Q1 else (ISNULL(COUNT_LOAN_ADDON_RealEstate_Q1,0) - ISNULL(COUNT_LOAN_ADDON_RealEstate_Q3,0)) end [DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q3]
			 --,CASE WHEN ( COUNT_LOAN_ADDON_RealEstate_Q1 IS NULL AND COUNT_LOAN_ADDON_RealEstate_Q4 IS  NULL ) THEN COUNT_LOAN_ADDON_RealEstate_Q1 else (ISNULL(COUNT_LOAN_ADDON_RealEstate_Q1,0) - ISNULL(COUNT_LOAN_ADDON_RealEstate_Q4,0)) end [DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q4]
			 --,COUNT_NEW_LOAN_RealEstate_SP
			 ,COUNT_NEW_LOAN_RealEstate_Q1
			 ,CASE WHEN ( COUNT_NEW_LOAN_RealEstate_Q1 IS NULL AND COUNT_NEW_LOAN_RealEstate_Q2 IS  NULL ) THEN COUNT_NEW_LOAN_RealEstate_Q1 else (ISNULL(COUNT_NEW_LOAN_RealEstate_Q1,0) - ISNULL(COUNT_NEW_LOAN_RealEstate_Q2,0)) end [COUNT_NEW_LOAN_RealEstate_Q1_Q2]
			 ,CASE WHEN ( COUNT_NEW_LOAN_RealEstate_Q1 IS NULL AND COUNT_NEW_LOAN_RealEstate_Q3 IS  NULL ) THEN COUNT_NEW_LOAN_RealEstate_Q1 else (ISNULL(COUNT_NEW_LOAN_RealEstate_Q1,0) - ISNULL(COUNT_NEW_LOAN_RealEstate_Q3,0)) end [COUNT_NEW_LOAN_RealEstate_Q1_Q3]
			 --,CASE WHEN ( COUNT_NEW_LOAN_RealEstate_Q1 IS NULL AND COUNT_NEW_LOAN_RealEstate_Q4 IS  NULL ) THEN COUNT_NEW_LOAN_RealEstate_Q1 else (ISNULL(COUNT_NEW_LOAN_RealEstate_Q1,0) - ISNULL(COUNT_NEW_LOAN_RealEstate_Q4,0)) end [COUNT_NEW_LOAN_RealEstate_Q1_Q4]
			 --,COUNT_LOAN_PAYMENT_RealEstate_SP
			 ,COUNT_LOAN_PAYMENT_RealEstate_Q1
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_RealEstate_Q1 IS NULL AND COUNT_LOAN_PAYMENT_RealEstate_Q2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_RealEstate_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_RealEstate_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_RealEstate_Q2,0)) end [DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q2]
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_RealEstate_Q1 IS NULL AND COUNT_LOAN_PAYMENT_RealEstate_Q3 IS  NULL ) THEN COUNT_LOAN_PAYMENT_RealEstate_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_RealEstate_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_RealEstate_Q3,0)) end [DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q3]
			 --,CASE WHEN ( COUNT_LOAN_PAYMENT_RealEstate_Q1 IS NULL AND COUNT_LOAN_PAYMENT_RealEstate_Q4 IS  NULL ) THEN COUNT_LOAN_PAYMENT_RealEstate_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_RealEstate_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_RealEstate_Q4,0)) end [DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q4]
			 --,COUNT_CASH_RealEstate_SP
			 ,COUNT_CASH_RealEstate_Q1
			 ,CASE WHEN ( COUNT_CASH_RealEstate_Q1 IS NULL AND COUNT_CASH_RealEstate_Q2 IS  NULL ) THEN COUNT_CASH_RealEstate_Q1 else (ISNULL(COUNT_CASH_RealEstate_Q1,0) - ISNULL(COUNT_CASH_RealEstate_Q2,0)) end [DFT_COUNT_CASH_RealEstate_Q1_Q2]
			 ,CASE WHEN ( COUNT_CASH_RealEstate_Q1 IS NULL AND COUNT_CASH_RealEstate_Q3 IS  NULL ) THEN COUNT_CASH_RealEstate_Q1 else (ISNULL(COUNT_CASH_RealEstate_Q1,0) - ISNULL(COUNT_CASH_RealEstate_Q3,0)) end [DFT_COUNT_CASH_RealEstate_Q1_Q3]
			 --,CASE WHEN ( COUNT_CASH_RealEstate_Q1 IS NULL AND COUNT_CASH_RealEstate_Q4 IS  NULL ) THEN COUNT_CASH_RealEstate_Q1 else (ISNULL(COUNT_CASH_RealEstate_Q1,0) - ISNULL(COUNT_CASH_RealEstate_Q4,0)) end [DFT_COUNT_CASH_RealEstate_Q1_Q4]
			 --,COUNT_DRAFT_RealEstate_SP
			 ,COUNT_DRAFT_RealEstate_Q1
			 ,CASE WHEN ( COUNT_DRAFT_RealEstate_Q1 IS NULL AND COUNT_DRAFT_RealEstate_Q2 IS  NULL ) THEN COUNT_DRAFT_RealEstate_Q1 else (ISNULL(COUNT_DRAFT_RealEstate_Q1,0) - ISNULL(COUNT_DRAFT_RealEstate_Q2,0)) end [DFT_COUNT_DRAFT_RealEstate_Q1_Q2]
			 ,CASE WHEN ( COUNT_DRAFT_RealEstate_Q1 IS NULL AND COUNT_DRAFT_RealEstate_Q3 IS  NULL ) THEN COUNT_DRAFT_RealEstate_Q1 else (ISNULL(COUNT_DRAFT_RealEstate_Q1,0) - ISNULL(COUNT_DRAFT_RealEstate_Q3,0)) end [DFT_COUNT_DRAFT_RealEstate_Q1_Q3]
			 --,CASE WHEN ( COUNT_DRAFT_RealEstate_Q1 IS NULL AND COUNT_DRAFT_RealEstate_Q4 IS  NULL ) THEN COUNT_DRAFT_RealEstate_Q1 else (ISNULL(COUNT_DRAFT_RealEstate_Q1,0) - ISNULL(COUNT_DRAFT_RealEstate_Q4,0)) end [DFT_COUNT_DRAFT_RealEstate_Q1_Q4]
			 --,COUNT_ACH_RealEstate_SP
			 ,COUNT_ACH_RealEstate_Q1
			 ,CASE WHEN ( COUNT_ACH_RealEstate_Q1 IS NULL AND COUNT_ACH_RealEstate_Q2 IS  NULL ) THEN COUNT_ACH_RealEstate_Q1 else (ISNULL(COUNT_ACH_RealEstate_Q1,0) - ISNULL(COUNT_ACH_RealEstate_Q2,0)) end [DFT_COUNT_ACH_RealEstate_Q1_Q2]
			 ,CASE WHEN ( COUNT_ACH_RealEstate_Q1 IS NULL AND COUNT_ACH_RealEstate_Q3 IS  NULL ) THEN COUNT_ACH_RealEstate_Q1 else (ISNULL(COUNT_ACH_RealEstate_Q1,0) - ISNULL(COUNT_ACH_RealEstate_Q3,0)) end [DFT_COUNT_ACH_RealEstate_Q1_Q3]
			 --,CASE WHEN ( COUNT_ACH_RealEstate_Q1 IS NULL AND COUNT_ACH_RealEstate_Q4 IS  NULL ) THEN COUNT_ACH_RealEstate_Q1 else (ISNULL(COUNT_ACH_RealEstate_Q1,0) - ISNULL(COUNT_ACH_RealEstate_Q4,0)) end [DFT_COUNT_ACH_RealEstate_Q1_Q4]
			 --,COUNT_FEE_RealEstate_SP
			 ,COUNT_FEE_RealEstate_Q1
			 ,CASE WHEN ( COUNT_FEE_RealEstate_Q1 IS NULL AND COUNT_FEE_RealEstate_Q2 IS  NULL ) THEN COUNT_FEE_RealEstate_Q1 else (ISNULL(COUNT_FEE_RealEstate_Q1,0) - ISNULL(COUNT_FEE_RealEstate_Q2,0)) end [DFT_COUNT_FEE_RealEstate_Q1_Q2]
			 ,CASE WHEN ( COUNT_FEE_RealEstate_Q1 IS NULL AND COUNT_FEE_RealEstate_Q3 IS  NULL ) THEN COUNT_FEE_RealEstate_Q1 else (ISNULL(COUNT_FEE_RealEstate_Q1,0) - ISNULL(COUNT_FEE_RealEstate_Q3,0)) end [DFT_COUNT_FEE_RealEstate_Q1_Q3]
			 --,CASE WHEN ( COUNT_FEE_RealEstate_Q1 IS NULL AND COUNT_FEE_RealEstate_Q4 IS  NULL ) THEN COUNT_FEE_RealEstate_Q1 else (ISNULL(COUNT_FEE_RealEstate_Q1,0) - ISNULL(COUNT_FEE_RealEstate_Q4,0)) end [DFT_COUNT_FEE_RealEstate_Q1_Q4]
			 --,COUNT_HOMEBANKING_RealEstate_SP
			 ,COUNT_HOMEBANKING_RealEstate_Q1
			 ,CASE WHEN (COUNT_HOMEBANKING_RealEstate_Q1 IS NULL AND COUNT_HOMEBANKING_RealEstate_Q2 IS  NULL ) THEN COUNT_HOMEBANKING_RealEstate_Q1 else (ISNULL(COUNT_HOMEBANKING_RealEstate_Q1,0) - ISNULL(COUNT_HOMEBANKING_RealEstate_Q2,0)) end [DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q2]
			 ,CASE WHEN (COUNT_HOMEBANKING_RealEstate_Q1 IS NULL AND COUNT_HOMEBANKING_RealEstate_Q3 IS  NULL ) THEN COUNT_HOMEBANKING_RealEstate_Q1 else (ISNULL(COUNT_HOMEBANKING_RealEstate_Q1,0) - ISNULL(COUNT_HOMEBANKING_RealEstate_Q3,0)) end [DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q3]
			 --,CASE WHEN (COUNT_HOMEBANKING_RealEstate_Q1 IS NULL AND COUNT_HOMEBANKING_RealEstate_Q4 IS  NULL ) THEN COUNT_HOMEBANKING_RealEstate_Q1 else (ISNULL(COUNT_HOMEBANKING_RealEstate_Q1,0) - ISNULL(COUNT_HOMEBANKING_RealEstate_Q4,0)) end [DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q4]
			 --,COUNT_INSURANCE_RealEstate_SP
			 ,COUNT_INSURANCE_RealEstate_Q1
			 ,CASE WHEN (COUNT_INSURANCE_RealEstate_Q1 IS NULL AND COUNT_INSURANCE_RealEstate_Q2 IS  NULL ) THEN COUNT_INSURANCE_RealEstate_Q1 else (ISNULL(COUNT_INSURANCE_RealEstate_Q1,0) - ISNULL(COUNT_INSURANCE_RealEstate_Q2,0)) end [DFT_COUNT_INSURANCE_RealEstate_Q1_Q2]
			 ,CASE WHEN (COUNT_INSURANCE_RealEstate_Q1 IS NULL AND COUNT_INSURANCE_RealEstate_Q3 IS  NULL ) THEN COUNT_INSURANCE_RealEstate_Q1 else (ISNULL(COUNT_INSURANCE_RealEstate_Q1,0) - ISNULL(COUNT_INSURANCE_RealEstate_Q3,0)) end [DFT_COUNT_INSURANCE_RealEstate_Q1_Q3]
			 --,CASE WHEN (COUNT_INSURANCE_RealEstate_Q1 IS NULL AND COUNT_INSURANCE_RealEstate_Q4 IS  NULL ) THEN COUNT_INSURANCE_RealEstate_Q1 else (ISNULL(COUNT_INSURANCE_RealEstate_Q1,0) - ISNULL(COUNT_INSURANCE_RealEstate_Q4,0)) end [DFT_COUNT_INSURANCE_RealEstate_Q1_Q4]
			 --,COUNT_CHECKS_RealEstate_SP
			 ,COUNT_CHECKS_RealEstate_Q1
			 ,CASE WHEN (COUNT_CHECKS_RealEstate_Q1 IS NULL AND COUNT_CHECKS_RealEstate_Q2 IS  NULL ) THEN COUNT_CHECKS_RealEstate_Q1 else (ISNULL(COUNT_CHECKS_RealEstate_Q1,0) - ISNULL(COUNT_CHECKS_RealEstate_Q2,0)) end [DFT_COUNT_CHECKS_RealEstate_Q1_Q2] 
			 ,CASE WHEN (COUNT_CHECKS_RealEstate_Q1 IS NULL AND COUNT_CHECKS_RealEstate_Q3 IS  NULL ) THEN COUNT_CHECKS_RealEstate_Q1 else (ISNULL(COUNT_CHECKS_RealEstate_Q1,0) - ISNULL(COUNT_CHECKS_RealEstate_Q3,0)) end [DFT_COUNT_CHECKS_RealEstate_Q1_Q3]
			 --,CASE WHEN (COUNT_CHECKS_RealEstate_Q1 IS NULL AND COUNT_CHECKS_RealEstate_Q4 IS  NULL ) THEN COUNT_CHECKS_RealEstate_Q1 else (ISNULL(COUNT_CHECKS_RealEstate_Q1,0) - ISNULL(COUNT_CHECKS_RealEstate_Q4,0)) end [DFT_COUNT_CHECKS_RealEstate_Q1_Q4]
			 --,COUNT_PAYROLL_RealEstate_SP
			 ,COUNT_PAYROLL_RealEstate_Q1
			 ,CASE WHEN (COUNT_PAYROLL_RealEstate_Q1 IS NULL AND COUNT_PAYROLL_RealEstate_Q2 IS  NULL ) THEN COUNT_PAYROLL_RealEstate_Q1 else (ISNULL(COUNT_PAYROLL_RealEstate_Q1,0) - ISNULL(COUNT_PAYROLL_RealEstate_Q2,0)) end [DFT_COUNT_PAYROLL_RealEstate_Q1_Q2]
			 ,CASE WHEN (COUNT_PAYROLL_RealEstate_Q1 IS NULL AND COUNT_PAYROLL_RealEstate_Q3 IS  NULL ) THEN COUNT_PAYROLL_RealEstate_Q1 else (ISNULL(COUNT_PAYROLL_RealEstate_Q1,0) - ISNULL(COUNT_PAYROLL_RealEstate_Q3,0)) end [DFT_COUNT_PAYROLL_RealEstate_Q1_Q3]
			 --,CASE WHEN (COUNT_PAYROLL_RealEstate_Q1 IS NULL AND COUNT_PAYROLL_RealEstate_Q4 IS  NULL ) THEN COUNT_PAYROLL_RealEstate_Q1 else (ISNULL(COUNT_PAYROLL_RealEstate_Q1,0) - ISNULL(COUNT_PAYROLL_RealEstate_Q4,0)) end [DFT_COUNT_PAYROLL_RealEstate_Q1_Q4]
			 --,COUNT_KIOSK_RealEstate_SP
			 ,COUNT_KIOSK_RealEstate_Q1
			 ,CASE WHEN (COUNT_KIOSK_RealEstate_Q1 IS NULL AND COUNT_KIOSK_RealEstate_Q2 IS  NULL ) THEN COUNT_KIOSK_RealEstate_Q1 else (ISNULL(COUNT_KIOSK_RealEstate_Q1,0) - ISNULL(COUNT_KIOSK_RealEstate_Q2,0)) end [DFT_COUNT_KIOSK_RealEstate_Q1_Q2]
			 ,CASE WHEN (COUNT_KIOSK_RealEstate_Q1 IS NULL AND COUNT_KIOSK_RealEstate_Q3 IS  NULL ) THEN COUNT_KIOSK_RealEstate_Q1 else (ISNULL(COUNT_KIOSK_RealEstate_Q1,0) - ISNULL(COUNT_KIOSK_RealEstate_Q3,0)) end [DFT_COUNT_KIOSK_RealEstate_Q1_Q3]
			 --,CASE WHEN (COUNT_KIOSK_RealEstate_Q1 IS NULL AND COUNT_KIOSK_RealEstate_Q4 IS  NULL ) THEN COUNT_KIOSK_RealEstate_Q1 else (ISNULL(COUNT_KIOSK_RealEstate_Q1,0) - ISNULL(COUNT_KIOSK_RealEstate_Q4,0)) end [DFT_COUNT_KIOSK_RealEstate_Q1_Q4]
			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_SP
			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q2]
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q3 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q3,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q3]
			 --,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q4 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q4,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q4]

			 ,LOAN_TRANSACTION_AMOUNT_RealEstate_Q1
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_RealEstate_Q2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_Q2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2]
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_RealEstate_Q3 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_Q3,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q3]
			 --,CASE WHEN (LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_RealEstate_Q4 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_Q4,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q4]
			 --,INTEREST_AMOUNT_RealEstate_SP
			 ,INTEREST_AMOUNT_RealEstate_Q1
			 ,CASE WHEN (INTEREST_AMOUNT_RealEstate_Q1 IS NULL AND INTEREST_AMOUNT_RealEstate_Q2 IS  NULL ) THEN INTEREST_AMOUNT_RealEstate_Q1 else (ISNULL(INTEREST_AMOUNT_RealEstate_Q1,0) - ISNULL(INTEREST_AMOUNT_RealEstate_Q2,0)) end [DFT_INTEREST_AMOUNT_RealEstate_Q1_Q2]
			 ,CASE WHEN (INTEREST_AMOUNT_RealEstate_Q1 IS NULL AND INTEREST_AMOUNT_RealEstate_Q3 IS  NULL ) THEN INTEREST_AMOUNT_RealEstate_Q1 else (ISNULL(INTEREST_AMOUNT_RealEstate_Q1,0) - ISNULL(INTEREST_AMOUNT_RealEstate_Q3,0)) end [DFT_INTEREST_AMOUNT_RealEstate_Q1_Q3]
			 --,CASE WHEN (INTEREST_AMOUNT_RealEstate_Q1 IS NULL AND INTEREST_AMOUNT_RealEstate_Q4 IS  NULL ) THEN INTEREST_AMOUNT_RealEstate_Q1 else (ISNULL(INTEREST_AMOUNT_RealEstate_Q1,0) - ISNULL(INTEREST_AMOUNT_RealEstate_Q4,0)) end [DFT_INTEREST_AMOUNT_RealEstate_Q1_Q4]
			 --,FEEAMOUNT_RealEstate_SP
			 ,FEEAMOUNT_RealEstate_Q1
			 ,CASE WHEN (FEEAMOUNT_RealEstate_Q1 IS NULL AND FEEAMOUNT_RealEstate_Q2 IS  NULL ) THEN FEEAMOUNT_RealEstate_Q1 else (ISNULL(FEEAMOUNT_RealEstate_Q1,0) - ISNULL(FEEAMOUNT_RealEstate_Q2,0)) end [DFT_FEEAMOUNT_RealEstate_Q1_Q2]
			 ,CASE WHEN (FEEAMOUNT_RealEstate_Q1 IS NULL AND FEEAMOUNT_RealEstate_Q3 IS  NULL ) THEN FEEAMOUNT_RealEstate_Q1 else (ISNULL(FEEAMOUNT_RealEstate_Q1,0) - ISNULL(FEEAMOUNT_RealEstate_Q3,0)) end [DFT_FEEAMOUNT_RealEstate_Q1_Q3]
			 --,CASE WHEN (FEEAMOUNT_RealEstate_Q1 IS NULL AND FEEAMOUNT_RealEstate_Q4 IS  NULL ) THEN FEEAMOUNT_RealEstate_Q1 else (ISNULL(FEEAMOUNT_RealEstate_Q1,0) - ISNULL(FEEAMOUNT_RealEstate_Q4,0)) end [DFT_FEEAMOUNT_RealEstate_Q1_Q4]
			 --,AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_SP
			 ,AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2]
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q3 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q3,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q3]
			 --,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q4 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q4,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q4]
			 ,AVG_NEWBALANCE_RealEstate_Q1
			 ,CASE WHEN (AVG_NEWBALANCE_RealEstate_Q1 IS NULL AND AVG_NEWBALANCE_RealEstate_Q2 IS  NULL ) THEN AVG_NEWBALANCE_RealEstate_Q1 else (ISNULL(AVG_NEWBALANCE_RealEstate_Q1,0) - ISNULL(AVG_NEWBALANCE_RealEstate_Q2,0)) end [DFT_AVG_NEWBALANCE_RealEstate_Q1_Q2]
			 ,CASE WHEN (AVG_NEWBALANCE_RealEstate_Q1 IS NULL AND AVG_NEWBALANCE_RealEstate_Q3 IS  NULL ) THEN AVG_NEWBALANCE_RealEstate_Q1 else (ISNULL(AVG_NEWBALANCE_RealEstate_Q1,0) - ISNULL(AVG_NEWBALANCE_RealEstate_Q3,0)) end [DFT_AVG_NEWBALANCE_RealEstate_Q1_Q3]
			 --,CASE WHEN (AVG_NEWBALANCE_RealEstate_Q1 IS NULL AND AVG_NEWBALANCE_RealEstate_Q4 IS  NULL ) THEN AVG_NEWBALANCE_RealEstate_Q1 else (ISNULL(AVG_NEWBALANCE_RealEstate_Q1,0) - ISNULL(AVG_NEWBALANCE_RealEstate_Q4,0)) end [DFT_AVG_NEWBALANCE_RealEstate_Q1_Q4]
			 --,AVG_FEEAMOUNT_RealEstate_SP
			 ,AVG_FEEAMOUNT_RealEstate_Q1
			 ,CASE WHEN (AVG_FEEAMOUNT_RealEstate_Q1 IS NULL AND AVG_FEEAMOUNT_RealEstate_Q2 IS  NULL ) THEN AVG_FEEAMOUNT_RealEstate_Q1 else (ISNULL(AVG_FEEAMOUNT_RealEstate_Q1,0) - ISNULL(AVG_FEEAMOUNT_RealEstate_Q2,0)) end [DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q2]
			 ,CASE WHEN (AVG_FEEAMOUNT_RealEstate_Q1 IS NULL AND AVG_FEEAMOUNT_RealEstate_Q3 IS  NULL ) THEN AVG_FEEAMOUNT_RealEstate_Q1 else (ISNULL(AVG_FEEAMOUNT_RealEstate_Q1,0) - ISNULL(AVG_FEEAMOUNT_RealEstate_Q3,0)) end [DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q3]
			 --,CASE WHEN (AVG_FEEAMOUNT_RealEstate_Q1 IS NULL AND AVG_FEEAMOUNT_RealEstate_Q4 IS  NULL ) THEN AVG_FEEAMOUNT_RealEstate_Q1 else (ISNULL(AVG_FEEAMOUNT_RealEstate_Q1,0) - ISNULL(AVG_FEEAMOUNT_RealEstate_Q4,0)) end [DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q4]

	         ,COUNT_LOAN_ADDON_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_LOAN_ADDON_SecuredLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_SecuredLoan_Q2 IS  NULL ) THEN COUNT_LOAN_ADDON_SecuredLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_SecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_SecuredLoan_Q2,0)) end [DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_LOAN_ADDON_SecuredLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_SecuredLoan_Q3 IS  NULL ) THEN COUNT_LOAN_ADDON_SecuredLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_SecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_SecuredLoan_Q3,0)) end [DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_LOAN_ADDON_SecuredLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_SecuredLoan_Q4 IS  NULL ) THEN COUNT_LOAN_ADDON_SecuredLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_SecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_SecuredLoan_Q4,0)) end [DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q4]
			 --,COUNT_NEW_LOAN_SecuredLoan_SP
			 ,COUNT_NEW_LOAN_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_NEW_LOAN_SecuredLoan_Q1 IS NULL AND COUNT_NEW_LOAN_SecuredLoan_Q2 IS  NULL ) THEN COUNT_NEW_LOAN_SecuredLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_SecuredLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_SecuredLoan_Q2,0)) end [COUNT_NEW_LOAN_SecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_NEW_LOAN_SecuredLoan_Q1 IS NULL AND COUNT_NEW_LOAN_SecuredLoan_Q3 IS  NULL ) THEN COUNT_NEW_LOAN_SecuredLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_SecuredLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_SecuredLoan_Q3,0)) end [COUNT_NEW_LOAN_SecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_NEW_LOAN_SecuredLoan_Q1 IS NULL AND COUNT_NEW_LOAN_SecuredLoan_Q4 IS  NULL ) THEN COUNT_NEW_LOAN_SecuredLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_SecuredLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_SecuredLoan_Q4,0)) end [COUNT_NEW_LOAN_SecuredLoan_Q1_Q4]
			 --,COUNT_LOAN_PAYMENT_SecuredLoan_SP
			 ,COUNT_LOAN_PAYMENT_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_SecuredLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_SecuredLoan_Q2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_SecuredLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_Q2,0)) end [DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_SecuredLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_SecuredLoan_Q3 IS  NULL ) THEN COUNT_LOAN_PAYMENT_SecuredLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_Q3,0)) end [DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_LOAN_PAYMENT_SecuredLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_SecuredLoan_Q4 IS  NULL ) THEN COUNT_LOAN_PAYMENT_SecuredLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_Q4,0)) end [DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q4]
			 --,COUNT_CASH_SecuredLoan_SP
			 ,COUNT_CASH_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_CASH_SecuredLoan_Q1 IS NULL AND COUNT_CASH_SecuredLoan_Q2 IS  NULL ) THEN COUNT_CASH_SecuredLoan_Q1 else (ISNULL(COUNT_CASH_SecuredLoan_Q1,0) - ISNULL(COUNT_CASH_SecuredLoan_Q2,0)) end [DFT_COUNT_CASH_SecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_CASH_SecuredLoan_Q1 IS NULL AND COUNT_CASH_SecuredLoan_Q3 IS  NULL ) THEN COUNT_CASH_SecuredLoan_Q1 else (ISNULL(COUNT_CASH_SecuredLoan_Q1,0) - ISNULL(COUNT_CASH_SecuredLoan_Q3,0)) end [DFT_COUNT_CASH_SecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_CASH_SecuredLoan_Q1 IS NULL AND COUNT_CASH_SecuredLoan_Q4 IS  NULL ) THEN COUNT_CASH_SecuredLoan_Q1 else (ISNULL(COUNT_CASH_SecuredLoan_Q1,0) - ISNULL(COUNT_CASH_SecuredLoan_Q4,0)) end [DFT_COUNT_CASH_SecuredLoan_Q1_Q4]
			 --,COUNT_DRAFT_SecuredLoan_SP
			 ,COUNT_DRAFT_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_DRAFT_SecuredLoan_Q1 IS NULL AND COUNT_DRAFT_SecuredLoan_Q2 IS  NULL ) THEN COUNT_DRAFT_SecuredLoan_Q1 else (ISNULL(COUNT_DRAFT_SecuredLoan_Q1,0) - ISNULL(COUNT_DRAFT_SecuredLoan_Q2,0)) end [DFT_COUNT_DRAFT_SecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_DRAFT_SecuredLoan_Q1 IS NULL AND COUNT_DRAFT_SecuredLoan_Q3 IS  NULL ) THEN COUNT_DRAFT_SecuredLoan_Q1 else (ISNULL(COUNT_DRAFT_SecuredLoan_Q1,0) - ISNULL(COUNT_DRAFT_SecuredLoan_Q3,0)) end [DFT_COUNT_DRAFT_SecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_DRAFT_SecuredLoan_Q1 IS NULL AND COUNT_DRAFT_SecuredLoan_Q4 IS  NULL ) THEN COUNT_DRAFT_SecuredLoan_Q1 else (ISNULL(COUNT_DRAFT_SecuredLoan_Q1,0) - ISNULL(COUNT_DRAFT_SecuredLoan_Q4,0)) end [DFT_COUNT_DRAFT_SecuredLoan_Q1_Q4]
			 --,COUNT_ACH_SecuredLoan_SP
			 ,COUNT_ACH_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_ACH_SecuredLoan_Q1 IS NULL AND COUNT_ACH_SecuredLoan_Q2 IS  NULL ) THEN COUNT_ACH_SecuredLoan_Q1 else (ISNULL(COUNT_ACH_SecuredLoan_Q1,0) - ISNULL(COUNT_ACH_SecuredLoan_Q2,0)) end [DFT_COUNT_ACH_SecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_ACH_SecuredLoan_Q1 IS NULL AND COUNT_ACH_SecuredLoan_Q3 IS  NULL ) THEN COUNT_ACH_SecuredLoan_Q1 else (ISNULL(COUNT_ACH_SecuredLoan_Q1,0) - ISNULL(COUNT_ACH_SecuredLoan_Q3,0)) end [DFT_COUNT_ACH_SecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_ACH_SecuredLoan_Q1 IS NULL AND COUNT_ACH_SecuredLoan_Q4 IS  NULL ) THEN COUNT_ACH_SecuredLoan_Q1 else (ISNULL(COUNT_ACH_SecuredLoan_Q1,0) - ISNULL(COUNT_ACH_SecuredLoan_Q4,0)) end [DFT_COUNT_ACH_SecuredLoan_Q1_Q4]
			 --,COUNT_FEE_SecuredLoan_SP
			 ,COUNT_FEE_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_FEE_SecuredLoan_Q1 IS NULL AND COUNT_FEE_SecuredLoan_Q2 IS  NULL ) THEN COUNT_FEE_SecuredLoan_Q1 else (ISNULL(COUNT_FEE_SecuredLoan_Q1,0) - ISNULL(COUNT_FEE_SecuredLoan_Q2,0)) end [DFT_COUNT_FEE_SecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_FEE_SecuredLoan_Q1 IS NULL AND COUNT_FEE_SecuredLoan_Q3 IS  NULL ) THEN COUNT_FEE_SecuredLoan_Q1 else (ISNULL(COUNT_FEE_SecuredLoan_Q1,0) - ISNULL(COUNT_FEE_SecuredLoan_Q3,0)) end [DFT_COUNT_FEE_SecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_FEE_SecuredLoan_Q1 IS NULL AND COUNT_FEE_SecuredLoan_Q4 IS  NULL ) THEN COUNT_FEE_SecuredLoan_Q1 else (ISNULL(COUNT_FEE_SecuredLoan_Q1,0) - ISNULL(COUNT_FEE_SecuredLoan_Q4,0)) end [DFT_COUNT_FEE_SecuredLoan_Q1_Q4]
			 --,COUNT_HOMEBANKING_SecuredLoan_SP
			 ,COUNT_HOMEBANKING_SecuredLoan_Q1
			 ,CASE WHEN (COUNT_HOMEBANKING_SecuredLoan_Q1 IS NULL AND COUNT_HOMEBANKING_SecuredLoan_Q2 IS  NULL ) THEN COUNT_HOMEBANKING_SecuredLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_SecuredLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_SecuredLoan_Q2,0)) end [DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_HOMEBANKING_SecuredLoan_Q1 IS NULL AND COUNT_HOMEBANKING_SecuredLoan_Q3 IS  NULL ) THEN COUNT_HOMEBANKING_SecuredLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_SecuredLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_SecuredLoan_Q3,0)) end [DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_HOMEBANKING_SecuredLoan_Q1 IS NULL AND COUNT_HOMEBANKING_SecuredLoan_Q4 IS  NULL ) THEN COUNT_HOMEBANKING_SecuredLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_SecuredLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_SecuredLoan_Q4,0)) end [DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q4]
			 --,COUNT_INSURANCE_SecuredLoan_SP
			 ,COUNT_INSURANCE_SecuredLoan_Q1
			 ,CASE WHEN (COUNT_INSURANCE_SecuredLoan_Q1 IS NULL AND COUNT_INSURANCE_SecuredLoan_Q2 IS  NULL ) THEN COUNT_INSURANCE_SecuredLoan_Q1 else (ISNULL(COUNT_INSURANCE_SecuredLoan_Q1,0) - ISNULL(COUNT_INSURANCE_SecuredLoan_Q2,0)) end [DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_INSURANCE_SecuredLoan_Q1 IS NULL AND COUNT_INSURANCE_SecuredLoan_Q3 IS  NULL ) THEN COUNT_INSURANCE_SecuredLoan_Q1 else (ISNULL(COUNT_INSURANCE_SecuredLoan_Q1,0) - ISNULL(COUNT_INSURANCE_SecuredLoan_Q3,0)) end [DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_INSURANCE_SecuredLoan_Q1 IS NULL AND COUNT_INSURANCE_SecuredLoan_Q4 IS  NULL ) THEN COUNT_INSURANCE_SecuredLoan_Q1 else (ISNULL(COUNT_INSURANCE_SecuredLoan_Q1,0) - ISNULL(COUNT_INSURANCE_SecuredLoan_Q4,0)) end [DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q4]
			 --,COUNT_CHECKS_SecuredLoan_SP
			 ,COUNT_CHECKS_SecuredLoan_Q1
			 ,CASE WHEN (COUNT_CHECKS_SecuredLoan_Q1 IS NULL AND COUNT_CHECKS_SecuredLoan_Q2 IS  NULL ) THEN COUNT_CHECKS_SecuredLoan_Q1 else (ISNULL(COUNT_CHECKS_SecuredLoan_Q1,0) - ISNULL(COUNT_CHECKS_SecuredLoan_Q2,0)) end [DFT_COUNT_CHECKS_SecuredLoan_Q1_Q2] 
			 ,CASE WHEN (COUNT_CHECKS_SecuredLoan_Q1 IS NULL AND COUNT_CHECKS_SecuredLoan_Q3 IS  NULL ) THEN COUNT_CHECKS_SecuredLoan_Q1 else (ISNULL(COUNT_CHECKS_SecuredLoan_Q1,0) - ISNULL(COUNT_CHECKS_SecuredLoan_Q3,0)) end [DFT_COUNT_CHECKS_SecuredLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_CHECKS_SecuredLoan_Q1 IS NULL AND COUNT_CHECKS_SecuredLoan_Q4 IS  NULL ) THEN COUNT_CHECKS_SecuredLoan_Q1 else (ISNULL(COUNT_CHECKS_SecuredLoan_Q1,0) - ISNULL(COUNT_CHECKS_SecuredLoan_Q4,0)) end [DFT_COUNT_CHECKS_SecuredLoan_Q1_Q4]
			 --,COUNT_PAYROLL_SecuredLoan_SP
			 ,COUNT_PAYROLL_SecuredLoan_Q1
			 ,CASE WHEN (COUNT_PAYROLL_SecuredLoan_Q1 IS NULL AND COUNT_PAYROLL_SecuredLoan_Q2 IS  NULL ) THEN COUNT_PAYROLL_SecuredLoan_Q1 else (ISNULL(COUNT_PAYROLL_SecuredLoan_Q1,0) - ISNULL(COUNT_PAYROLL_SecuredLoan_Q2,0)) end [DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_PAYROLL_SecuredLoan_Q1 IS NULL AND COUNT_PAYROLL_SecuredLoan_Q3 IS  NULL ) THEN COUNT_PAYROLL_SecuredLoan_Q1 else (ISNULL(COUNT_PAYROLL_SecuredLoan_Q1,0) - ISNULL(COUNT_PAYROLL_SecuredLoan_Q3,0)) end [DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_PAYROLL_SecuredLoan_Q1 IS NULL AND COUNT_PAYROLL_SecuredLoan_Q4 IS  NULL ) THEN COUNT_PAYROLL_SecuredLoan_Q1 else (ISNULL(COUNT_PAYROLL_SecuredLoan_Q1,0) - ISNULL(COUNT_PAYROLL_SecuredLoan_Q4,0)) end [DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q4]
			 --,COUNT_KIOSK_SecuredLoan_SP
			 ,COUNT_KIOSK_SecuredLoan_Q1
			 ,CASE WHEN (COUNT_KIOSK_SecuredLoan_Q1 IS NULL AND COUNT_KIOSK_SecuredLoan_Q2 IS  NULL ) THEN COUNT_KIOSK_SecuredLoan_Q1 else (ISNULL(COUNT_KIOSK_SecuredLoan_Q1,0) - ISNULL(COUNT_KIOSK_SecuredLoan_Q2,0)) end [DFT_COUNT_KIOSK_SecuredLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_KIOSK_SecuredLoan_Q1 IS NULL AND COUNT_KIOSK_SecuredLoan_Q3 IS  NULL ) THEN COUNT_KIOSK_SecuredLoan_Q1 else (ISNULL(COUNT_KIOSK_SecuredLoan_Q1,0) - ISNULL(COUNT_KIOSK_SecuredLoan_Q3,0)) end [DFT_COUNT_KIOSK_SecuredLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_KIOSK_SecuredLoan_Q1 IS NULL AND COUNT_KIOSK_SecuredLoan_Q4 IS  NULL ) THEN COUNT_KIOSK_SecuredLoan_Q1 else (ISNULL(COUNT_KIOSK_SecuredLoan_Q1,0) - ISNULL(COUNT_KIOSK_SecuredLoan_Q4,0)) end [DFT_COUNT_KIOSK_SecuredLoan_Q1_Q4]
			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_SP
			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q3 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q3,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q4 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q4,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q4]

			 ,LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2]
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q3 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q3,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q3]
			 --,CASE WHEN (LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q4 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q4,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q4]
			 --,INTEREST_AMOUNT_SecuredLoan_SP
			 ,INTEREST_AMOUNT_SecuredLoan_Q1
			 ,CASE WHEN (INTEREST_AMOUNT_SecuredLoan_Q1 IS NULL AND INTEREST_AMOUNT_SecuredLoan_Q2 IS  NULL ) THEN INTEREST_AMOUNT_SecuredLoan_Q1 else (ISNULL(INTEREST_AMOUNT_SecuredLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_SecuredLoan_Q2,0)) end [DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q2]
			 ,CASE WHEN (INTEREST_AMOUNT_SecuredLoan_Q1 IS NULL AND INTEREST_AMOUNT_SecuredLoan_Q3 IS  NULL ) THEN INTEREST_AMOUNT_SecuredLoan_Q1 else (ISNULL(INTEREST_AMOUNT_SecuredLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_SecuredLoan_Q3,0)) end [DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q3]
			 --,CASE WHEN (INTEREST_AMOUNT_SecuredLoan_Q1 IS NULL AND INTEREST_AMOUNT_SecuredLoan_Q4 IS  NULL ) THEN INTEREST_AMOUNT_SecuredLoan_Q1 else (ISNULL(INTEREST_AMOUNT_SecuredLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_SecuredLoan_Q4,0)) end [DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q4]
			 --,FEEAMOUNT_SecuredLoan_SP
			 ,FEEAMOUNT_SecuredLoan_Q1
			 ,CASE WHEN (FEEAMOUNT_SecuredLoan_Q1 IS NULL AND FEEAMOUNT_SecuredLoan_Q2 IS  NULL ) THEN FEEAMOUNT_SecuredLoan_Q1 else (ISNULL(FEEAMOUNT_SecuredLoan_Q1,0) - ISNULL(FEEAMOUNT_SecuredLoan_Q2,0)) end [DFT_FEEAMOUNT_SecuredLoan_Q1_Q2]
			 ,CASE WHEN (FEEAMOUNT_SecuredLoan_Q1 IS NULL AND FEEAMOUNT_SecuredLoan_Q3 IS  NULL ) THEN FEEAMOUNT_SecuredLoan_Q1 else (ISNULL(FEEAMOUNT_SecuredLoan_Q1,0) - ISNULL(FEEAMOUNT_SecuredLoan_Q3,0)) end [DFT_FEEAMOUNT_SecuredLoan_Q1_Q3]
			 --,CASE WHEN (FEEAMOUNT_SecuredLoan_Q1 IS NULL AND FEEAMOUNT_SecuredLoan_Q4 IS  NULL ) THEN FEEAMOUNT_SecuredLoan_Q1 else (ISNULL(FEEAMOUNT_SecuredLoan_Q1,0) - ISNULL(FEEAMOUNT_SecuredLoan_Q4,0)) end [DFT_FEEAMOUNT_SecuredLoan_Q1_Q4]
			 --,AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_SP
			 ,AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2]
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q3 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q3,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q3]
			 --,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q4 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q4,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q4]
			 ,AVG_NEWBALANCE_SecuredLoan_Q1
			 ,CASE WHEN (AVG_NEWBALANCE_SecuredLoan_Q1 IS NULL AND AVG_NEWBALANCE_SecuredLoan_Q2 IS  NULL ) THEN AVG_NEWBALANCE_SecuredLoan_Q1 else (ISNULL(AVG_NEWBALANCE_SecuredLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_SecuredLoan_Q2,0)) end [DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q2]
			 ,CASE WHEN (AVG_NEWBALANCE_SecuredLoan_Q1 IS NULL AND AVG_NEWBALANCE_SecuredLoan_Q3 IS  NULL ) THEN AVG_NEWBALANCE_SecuredLoan_Q1 else (ISNULL(AVG_NEWBALANCE_SecuredLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_SecuredLoan_Q3,0)) end [DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q3]
			 --,CASE WHEN (AVG_NEWBALANCE_SecuredLoan_Q1 IS NULL AND AVG_NEWBALANCE_SecuredLoan_Q4 IS  NULL ) THEN AVG_NEWBALANCE_SecuredLoan_Q1 else (ISNULL(AVG_NEWBALANCE_SecuredLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_SecuredLoan_Q4,0)) end [DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q4]
			 --,AVG_FEEAMOUNT_SecuredLoan_SP
			 ,AVG_FEEAMOUNT_SecuredLoan_Q1
			 ,CASE WHEN (AVG_FEEAMOUNT_SecuredLoan_Q1 IS NULL AND AVG_FEEAMOUNT_SecuredLoan_Q2 IS  NULL ) THEN AVG_FEEAMOUNT_SecuredLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_SecuredLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_SecuredLoan_Q2,0)) end [DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q2]
			 ,CASE WHEN (AVG_FEEAMOUNT_SecuredLoan_Q1 IS NULL AND AVG_FEEAMOUNT_SecuredLoan_Q3 IS  NULL ) THEN AVG_FEEAMOUNT_SecuredLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_SecuredLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_SecuredLoan_Q3,0)) end [DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q3]
			 --,CASE WHEN (AVG_FEEAMOUNT_SecuredLoan_Q1 IS NULL AND AVG_FEEAMOUNT_SecuredLoan_Q4 IS  NULL ) THEN AVG_FEEAMOUNT_SecuredLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_SecuredLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_SecuredLoan_Q4,0)) end [DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q4]


	         ,COUNT_LOAN_ADDON_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_LOAN_ADDON_UnsecuredLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_LOAN_ADDON_UnsecuredLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_Q2,0)) end [DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_LOAN_ADDON_UnsecuredLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_UnsecuredLoan_Q3 IS  NULL ) THEN COUNT_LOAN_ADDON_UnsecuredLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_Q3,0)) end [DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_LOAN_ADDON_UnsecuredLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_UnsecuredLoan_Q4 IS  NULL ) THEN COUNT_LOAN_ADDON_UnsecuredLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_Q4,0)) end [DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q4]
			 --,COUNT_NEW_LOAN_UnsecuredLoan_SP
			 ,COUNT_NEW_LOAN_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_NEW_LOAN_UnsecuredLoan_Q1 IS NULL AND COUNT_NEW_LOAN_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_NEW_LOAN_UnsecuredLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_Q2,0)) end [COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_NEW_LOAN_UnsecuredLoan_Q1 IS NULL AND COUNT_NEW_LOAN_UnsecuredLoan_Q3 IS  NULL ) THEN COUNT_NEW_LOAN_UnsecuredLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_Q3,0)) end [COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_NEW_LOAN_UnsecuredLoan_Q1 IS NULL AND COUNT_NEW_LOAN_UnsecuredLoan_Q4 IS  NULL ) THEN COUNT_NEW_LOAN_UnsecuredLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_Q4,0)) end [COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q4]
			 --,COUNT_LOAN_PAYMENT_UnsecuredLoan_SP
			 ,COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_Q2,0)) end [DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_UnsecuredLoan_Q3 IS  NULL ) THEN COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_Q3,0)) end [DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_UnsecuredLoan_Q4 IS  NULL ) THEN COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_Q4,0)) end [DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q4]
			 --,COUNT_CASH_UnsecuredLoan_SP
			 ,COUNT_CASH_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_CASH_UnsecuredLoan_Q1 IS NULL AND COUNT_CASH_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_CASH_UnsecuredLoan_Q1 else (ISNULL(COUNT_CASH_UnsecuredLoan_Q1,0) - ISNULL(COUNT_CASH_UnsecuredLoan_Q2,0)) end [DFT_COUNT_CASH_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_CASH_UnsecuredLoan_Q1 IS NULL AND COUNT_CASH_UnsecuredLoan_Q3 IS  NULL ) THEN COUNT_CASH_UnsecuredLoan_Q1 else (ISNULL(COUNT_CASH_UnsecuredLoan_Q1,0) - ISNULL(COUNT_CASH_UnsecuredLoan_Q3,0)) end [DFT_COUNT_CASH_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_CASH_UnsecuredLoan_Q1 IS NULL AND COUNT_CASH_UnsecuredLoan_Q4 IS  NULL ) THEN COUNT_CASH_UnsecuredLoan_Q1 else (ISNULL(COUNT_CASH_UnsecuredLoan_Q1,0) - ISNULL(COUNT_CASH_UnsecuredLoan_Q4,0)) end [DFT_COUNT_CASH_UnsecuredLoan_Q1_Q4]
			 --,COUNT_DRAFT_UnsecuredLoan_SP
			 ,COUNT_DRAFT_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_DRAFT_UnsecuredLoan_Q1 IS NULL AND COUNT_DRAFT_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_DRAFT_UnsecuredLoan_Q1 else (ISNULL(COUNT_DRAFT_UnsecuredLoan_Q1,0) - ISNULL(COUNT_DRAFT_UnsecuredLoan_Q2,0)) end [DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_DRAFT_UnsecuredLoan_Q1 IS NULL AND COUNT_DRAFT_UnsecuredLoan_Q3 IS  NULL ) THEN COUNT_DRAFT_UnsecuredLoan_Q1 else (ISNULL(COUNT_DRAFT_UnsecuredLoan_Q1,0) - ISNULL(COUNT_DRAFT_UnsecuredLoan_Q3,0)) end [DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_DRAFT_UnsecuredLoan_Q1 IS NULL AND COUNT_DRAFT_UnsecuredLoan_Q4 IS  NULL ) THEN COUNT_DRAFT_UnsecuredLoan_Q1 else (ISNULL(COUNT_DRAFT_UnsecuredLoan_Q1,0) - ISNULL(COUNT_DRAFT_UnsecuredLoan_Q4,0)) end [DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q4]
			 --,COUNT_ACH_UnsecuredLoan_SP
			 ,COUNT_ACH_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_ACH_UnsecuredLoan_Q1 IS NULL AND COUNT_ACH_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_ACH_UnsecuredLoan_Q1 else (ISNULL(COUNT_ACH_UnsecuredLoan_Q1,0) - ISNULL(COUNT_ACH_UnsecuredLoan_Q2,0)) end [DFT_COUNT_ACH_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_ACH_UnsecuredLoan_Q1 IS NULL AND COUNT_ACH_UnsecuredLoan_Q3 IS  NULL ) THEN COUNT_ACH_UnsecuredLoan_Q1 else (ISNULL(COUNT_ACH_UnsecuredLoan_Q1,0) - ISNULL(COUNT_ACH_UnsecuredLoan_Q3,0)) end [DFT_COUNT_ACH_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_ACH_UnsecuredLoan_Q1 IS NULL AND COUNT_ACH_UnsecuredLoan_Q4 IS  NULL ) THEN COUNT_ACH_UnsecuredLoan_Q1 else (ISNULL(COUNT_ACH_UnsecuredLoan_Q1,0) - ISNULL(COUNT_ACH_UnsecuredLoan_Q4,0)) end [DFT_COUNT_ACH_UnsecuredLoan_Q1_Q4]
			 --,COUNT_FEE_UnsecuredLoan_SP
			 ,COUNT_FEE_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_FEE_UnsecuredLoan_Q1 IS NULL AND COUNT_FEE_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_FEE_UnsecuredLoan_Q1 else (ISNULL(COUNT_FEE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_FEE_UnsecuredLoan_Q2,0)) end [DFT_COUNT_FEE_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_FEE_UnsecuredLoan_Q1 IS NULL AND COUNT_FEE_UnsecuredLoan_Q3 IS  NULL ) THEN COUNT_FEE_UnsecuredLoan_Q1 else (ISNULL(COUNT_FEE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_FEE_UnsecuredLoan_Q3,0)) end [DFT_COUNT_FEE_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_FEE_UnsecuredLoan_Q1 IS NULL AND COUNT_FEE_UnsecuredLoan_Q4 IS  NULL ) THEN COUNT_FEE_UnsecuredLoan_Q1 else (ISNULL(COUNT_FEE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_FEE_UnsecuredLoan_Q4,0)) end [DFT_COUNT_FEE_UnsecuredLoan_Q1_Q4]
			 --,COUNT_HOMEBANKING_UnsecuredLoan_SP
			 ,COUNT_HOMEBANKING_UnsecuredLoan_Q1
			 ,CASE WHEN (COUNT_HOMEBANKING_UnsecuredLoan_Q1 IS NULL AND COUNT_HOMEBANKING_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_HOMEBANKING_UnsecuredLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_Q2,0)) end [DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_HOMEBANKING_UnsecuredLoan_Q1 IS NULL AND COUNT_HOMEBANKING_UnsecuredLoan_Q3 IS  NULL ) THEN COUNT_HOMEBANKING_UnsecuredLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_Q3,0)) end [DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_HOMEBANKING_UnsecuredLoan_Q1 IS NULL AND COUNT_HOMEBANKING_UnsecuredLoan_Q4 IS  NULL ) THEN COUNT_HOMEBANKING_UnsecuredLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_Q4,0)) end [DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q4]
			 --,COUNT_INSURANCE_UnsecuredLoan_SP
			 ,COUNT_INSURANCE_UnsecuredLoan_Q1
			 ,CASE WHEN (COUNT_INSURANCE_UnsecuredLoan_Q1 IS NULL AND COUNT_INSURANCE_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_INSURANCE_UnsecuredLoan_Q1 else (ISNULL(COUNT_INSURANCE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_INSURANCE_UnsecuredLoan_Q2,0)) end [DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_INSURANCE_UnsecuredLoan_Q1 IS NULL AND COUNT_INSURANCE_UnsecuredLoan_Q3 IS  NULL ) THEN COUNT_INSURANCE_UnsecuredLoan_Q1 else (ISNULL(COUNT_INSURANCE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_INSURANCE_UnsecuredLoan_Q3,0)) end [DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_INSURANCE_UnsecuredLoan_Q1 IS NULL AND COUNT_INSURANCE_UnsecuredLoan_Q4 IS  NULL ) THEN COUNT_INSURANCE_UnsecuredLoan_Q1 else (ISNULL(COUNT_INSURANCE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_INSURANCE_UnsecuredLoan_Q4,0)) end [DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q4]
			 --,COUNT_CHECKS_UnsecuredLoan_SP
			 ,COUNT_CHECKS_UnsecuredLoan_Q1
			 ,CASE WHEN (COUNT_CHECKS_UnsecuredLoan_Q1 IS NULL AND COUNT_CHECKS_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_CHECKS_UnsecuredLoan_Q1 else (ISNULL(COUNT_CHECKS_UnsecuredLoan_Q1,0) - ISNULL(COUNT_CHECKS_UnsecuredLoan_Q2,0)) end [DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q2] 
			 ,CASE WHEN (COUNT_CHECKS_UnsecuredLoan_Q1 IS NULL AND COUNT_CHECKS_UnsecuredLoan_Q3 IS  NULL ) THEN COUNT_CHECKS_UnsecuredLoan_Q1 else (ISNULL(COUNT_CHECKS_UnsecuredLoan_Q1,0) - ISNULL(COUNT_CHECKS_UnsecuredLoan_Q3,0)) end [DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_CHECKS_UnsecuredLoan_Q1 IS NULL AND COUNT_CHECKS_UnsecuredLoan_Q4 IS  NULL ) THEN COUNT_CHECKS_UnsecuredLoan_Q1 else (ISNULL(COUNT_CHECKS_UnsecuredLoan_Q1,0) - ISNULL(COUNT_CHECKS_UnsecuredLoan_Q4,0)) end [DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q4]
			 --,COUNT_PAYROLL_UnsecuredLoan_SP
			 ,COUNT_PAYROLL_UnsecuredLoan_Q1
			 ,CASE WHEN (COUNT_PAYROLL_UnsecuredLoan_Q1 IS NULL AND COUNT_PAYROLL_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_PAYROLL_UnsecuredLoan_Q1 else (ISNULL(COUNT_PAYROLL_UnsecuredLoan_Q1,0) - ISNULL(COUNT_PAYROLL_UnsecuredLoan_Q2,0)) end [DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_PAYROLL_UnsecuredLoan_Q1 IS NULL AND COUNT_PAYROLL_UnsecuredLoan_Q3 IS  NULL ) THEN COUNT_PAYROLL_UnsecuredLoan_Q1 else (ISNULL(COUNT_PAYROLL_UnsecuredLoan_Q1,0) - ISNULL(COUNT_PAYROLL_UnsecuredLoan_Q3,0)) end [DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_PAYROLL_UnsecuredLoan_Q1 IS NULL AND COUNT_PAYROLL_UnsecuredLoan_Q4 IS  NULL ) THEN COUNT_PAYROLL_UnsecuredLoan_Q1 else (ISNULL(COUNT_PAYROLL_UnsecuredLoan_Q1,0) - ISNULL(COUNT_PAYROLL_UnsecuredLoan_Q4,0)) end [DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q4]
			 --,COUNT_KIOSK_UnsecuredLoan_SP
			 ,COUNT_KIOSK_UnsecuredLoan_Q1
			 ,CASE WHEN (COUNT_KIOSK_UnsecuredLoan_Q1 IS NULL AND COUNT_KIOSK_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_KIOSK_UnsecuredLoan_Q1 else (ISNULL(COUNT_KIOSK_UnsecuredLoan_Q1,0) - ISNULL(COUNT_KIOSK_UnsecuredLoan_Q2,0)) end [DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_KIOSK_UnsecuredLoan_Q1 IS NULL AND COUNT_KIOSK_UnsecuredLoan_Q3 IS  NULL ) THEN COUNT_KIOSK_UnsecuredLoan_Q1 else (ISNULL(COUNT_KIOSK_UnsecuredLoan_Q1,0) - ISNULL(COUNT_KIOSK_UnsecuredLoan_Q3,0)) end [DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_KIOSK_UnsecuredLoan_Q1 IS NULL AND COUNT_KIOSK_UnsecuredLoan_Q4 IS  NULL ) THEN COUNT_KIOSK_UnsecuredLoan_Q1 else (ISNULL(COUNT_KIOSK_UnsecuredLoan_Q1,0) - ISNULL(COUNT_KIOSK_UnsecuredLoan_Q4,0)) end [DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q4]
			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_SP
			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q3 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q3,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q4 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q4,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q4]

			 ,LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q3 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q3,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN (LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q4 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q4,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q4]
			 --,INTEREST_AMOUNT_UnsecuredLoan_SP
			 ,INTEREST_AMOUNT_UnsecuredLoan_Q1
			 ,CASE WHEN (INTEREST_AMOUNT_UnsecuredLoan_Q1 IS NULL AND INTEREST_AMOUNT_UnsecuredLoan_Q2 IS  NULL ) THEN INTEREST_AMOUNT_UnsecuredLoan_Q1 else (ISNULL(INTEREST_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_UnsecuredLoan_Q2,0)) end [DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN (INTEREST_AMOUNT_UnsecuredLoan_Q1 IS NULL AND INTEREST_AMOUNT_UnsecuredLoan_Q3 IS  NULL ) THEN INTEREST_AMOUNT_UnsecuredLoan_Q1 else (ISNULL(INTEREST_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_UnsecuredLoan_Q3,0)) end [DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN (INTEREST_AMOUNT_UnsecuredLoan_Q1 IS NULL AND INTEREST_AMOUNT_UnsecuredLoan_Q4 IS  NULL ) THEN INTEREST_AMOUNT_UnsecuredLoan_Q1 else (ISNULL(INTEREST_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_UnsecuredLoan_Q4,0)) end [DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q4]
			 --,FEEAMOUNT_UnsecuredLoan_SP
			 ,FEEAMOUNT_UnsecuredLoan_Q1
			 ,CASE WHEN (FEEAMOUNT_UnsecuredLoan_Q1 IS NULL AND FEEAMOUNT_UnsecuredLoan_Q2 IS  NULL ) THEN FEEAMOUNT_UnsecuredLoan_Q1 else (ISNULL(FEEAMOUNT_UnsecuredLoan_Q1,0) - ISNULL(FEEAMOUNT_UnsecuredLoan_Q2,0)) end [DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN (FEEAMOUNT_UnsecuredLoan_Q1 IS NULL AND FEEAMOUNT_UnsecuredLoan_Q3 IS  NULL ) THEN FEEAMOUNT_UnsecuredLoan_Q1 else (ISNULL(FEEAMOUNT_UnsecuredLoan_Q1,0) - ISNULL(FEEAMOUNT_UnsecuredLoan_Q3,0)) end [DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN (FEEAMOUNT_UnsecuredLoan_Q1 IS NULL AND FEEAMOUNT_UnsecuredLoan_Q4 IS  NULL ) THEN FEEAMOUNT_UnsecuredLoan_Q1 else (ISNULL(FEEAMOUNT_UnsecuredLoan_Q1,0) - ISNULL(FEEAMOUNT_UnsecuredLoan_Q4,0)) end [DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q4]
			 --,AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_SP
			 ,AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q3 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q3,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q4 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q4,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q4]
			 ,AVG_NEWBALANCE_UnsecuredLoan_Q1
			 ,CASE WHEN (AVG_NEWBALANCE_UnsecuredLoan_Q1 IS NULL AND AVG_NEWBALANCE_UnsecuredLoan_Q2 IS  NULL ) THEN AVG_NEWBALANCE_UnsecuredLoan_Q1 else (ISNULL(AVG_NEWBALANCE_UnsecuredLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_UnsecuredLoan_Q2,0)) end [DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN (AVG_NEWBALANCE_UnsecuredLoan_Q1 IS NULL AND AVG_NEWBALANCE_UnsecuredLoan_Q3 IS  NULL ) THEN AVG_NEWBALANCE_UnsecuredLoan_Q1 else (ISNULL(AVG_NEWBALANCE_UnsecuredLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_UnsecuredLoan_Q3,0)) end [DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN (AVG_NEWBALANCE_UnsecuredLoan_Q1 IS NULL AND AVG_NEWBALANCE_UnsecuredLoan_Q4 IS  NULL ) THEN AVG_NEWBALANCE_UnsecuredLoan_Q1 else (ISNULL(AVG_NEWBALANCE_UnsecuredLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_UnsecuredLoan_Q4,0)) end [DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q4]
			 --,AVG_FEEAMOUNT_UnsecuredLoan_SP
			 ,AVG_FEEAMOUNT_UnsecuredLoan_Q1
			 ,CASE WHEN (AVG_FEEAMOUNT_UnsecuredLoan_Q1 IS NULL AND AVG_FEEAMOUNT_UnsecuredLoan_Q2 IS  NULL ) THEN AVG_FEEAMOUNT_UnsecuredLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_Q2,0)) end [DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q2]
			 ,CASE WHEN (AVG_FEEAMOUNT_UnsecuredLoan_Q1 IS NULL AND AVG_FEEAMOUNT_UnsecuredLoan_Q3 IS  NULL ) THEN AVG_FEEAMOUNT_UnsecuredLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_Q3,0)) end [DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q3]
			 --,CASE WHEN (AVG_FEEAMOUNT_UnsecuredLoan_Q1 IS NULL AND AVG_FEEAMOUNT_UnsecuredLoan_Q4 IS  NULL ) THEN AVG_FEEAMOUNT_UnsecuredLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_Q4,0)) end [DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q4]


	         ,COUNT_LOAN_ADDON_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_LOAN_ADDON_VehicleLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_VehicleLoan_Q2 IS  NULL ) THEN COUNT_LOAN_ADDON_VehicleLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_VehicleLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_VehicleLoan_Q2,0)) end [DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_LOAN_ADDON_VehicleLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_VehicleLoan_Q3 IS  NULL ) THEN COUNT_LOAN_ADDON_VehicleLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_VehicleLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_VehicleLoan_Q3,0)) end [DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_LOAN_ADDON_VehicleLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_VehicleLoan_Q4 IS  NULL ) THEN COUNT_LOAN_ADDON_VehicleLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_VehicleLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_VehicleLoan_Q4,0)) end [DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q4]
			 --,COUNT_NEW_LOAN_VehicleLoan_SP
			 ,COUNT_NEW_LOAN_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_NEW_LOAN_VehicleLoan_Q1 IS NULL AND COUNT_NEW_LOAN_VehicleLoan_Q2 IS  NULL ) THEN COUNT_NEW_LOAN_VehicleLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_VehicleLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_VehicleLoan_Q2,0)) end [COUNT_NEW_LOAN_VehicleLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_NEW_LOAN_VehicleLoan_Q1 IS NULL AND COUNT_NEW_LOAN_VehicleLoan_Q3 IS  NULL ) THEN COUNT_NEW_LOAN_VehicleLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_VehicleLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_VehicleLoan_Q3,0)) end [COUNT_NEW_LOAN_VehicleLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_NEW_LOAN_VehicleLoan_Q1 IS NULL AND COUNT_NEW_LOAN_VehicleLoan_Q4 IS  NULL ) THEN COUNT_NEW_LOAN_VehicleLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_VehicleLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_VehicleLoan_Q4,0)) end [COUNT_NEW_LOAN_VehicleLoan_Q1_Q4]
			 --,COUNT_LOAN_PAYMENT_VehicleLoan_SP
			 ,COUNT_LOAN_PAYMENT_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_VehicleLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_VehicleLoan_Q2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_VehicleLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_Q2,0)) end [DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_VehicleLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_VehicleLoan_Q3 IS  NULL ) THEN COUNT_LOAN_PAYMENT_VehicleLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_Q3,0)) end [DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_LOAN_PAYMENT_VehicleLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_VehicleLoan_Q4 IS  NULL ) THEN COUNT_LOAN_PAYMENT_VehicleLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_Q4,0)) end [DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q4]
			 --,COUNT_CASH_VehicleLoan_SP
			 ,COUNT_CASH_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_CASH_VehicleLoan_Q1 IS NULL AND COUNT_CASH_VehicleLoan_Q2 IS  NULL ) THEN COUNT_CASH_VehicleLoan_Q1 else (ISNULL(COUNT_CASH_VehicleLoan_Q1,0) - ISNULL(COUNT_CASH_VehicleLoan_Q2,0)) end [DFT_COUNT_CASH_VehicleLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_CASH_VehicleLoan_Q1 IS NULL AND COUNT_CASH_VehicleLoan_Q3 IS  NULL ) THEN COUNT_CASH_VehicleLoan_Q1 else (ISNULL(COUNT_CASH_VehicleLoan_Q1,0) - ISNULL(COUNT_CASH_VehicleLoan_Q3,0)) end [DFT_COUNT_CASH_VehicleLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_CASH_VehicleLoan_Q1 IS NULL AND COUNT_CASH_VehicleLoan_Q4 IS  NULL ) THEN COUNT_CASH_VehicleLoan_Q1 else (ISNULL(COUNT_CASH_VehicleLoan_Q1,0) - ISNULL(COUNT_CASH_VehicleLoan_Q4,0)) end [DFT_COUNT_CASH_VehicleLoan_Q1_Q4]
			 --,COUNT_DRAFT_VehicleLoan_SP
			 ,COUNT_DRAFT_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_DRAFT_VehicleLoan_Q1 IS NULL AND COUNT_DRAFT_VehicleLoan_Q2 IS  NULL ) THEN COUNT_DRAFT_VehicleLoan_Q1 else (ISNULL(COUNT_DRAFT_VehicleLoan_Q1,0) - ISNULL(COUNT_DRAFT_VehicleLoan_Q2,0)) end [DFT_COUNT_DRAFT_VehicleLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_DRAFT_VehicleLoan_Q1 IS NULL AND COUNT_DRAFT_VehicleLoan_Q3 IS  NULL ) THEN COUNT_DRAFT_VehicleLoan_Q1 else (ISNULL(COUNT_DRAFT_VehicleLoan_Q1,0) - ISNULL(COUNT_DRAFT_VehicleLoan_Q3,0)) end [DFT_COUNT_DRAFT_VehicleLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_DRAFT_VehicleLoan_Q1 IS NULL AND COUNT_DRAFT_VehicleLoan_Q4 IS  NULL ) THEN COUNT_DRAFT_VehicleLoan_Q1 else (ISNULL(COUNT_DRAFT_VehicleLoan_Q1,0) - ISNULL(COUNT_DRAFT_VehicleLoan_Q4,0)) end [DFT_COUNT_DRAFT_VehicleLoan_Q1_Q4]
			 --,COUNT_ACH_VehicleLoan_SP
			 ,COUNT_ACH_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_ACH_VehicleLoan_Q1 IS NULL AND COUNT_ACH_VehicleLoan_Q2 IS  NULL ) THEN COUNT_ACH_VehicleLoan_Q1 else (ISNULL(COUNT_ACH_VehicleLoan_Q1,0) - ISNULL(COUNT_ACH_VehicleLoan_Q2,0)) end [DFT_COUNT_ACH_VehicleLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_ACH_VehicleLoan_Q1 IS NULL AND COUNT_ACH_VehicleLoan_Q3 IS  NULL ) THEN COUNT_ACH_VehicleLoan_Q1 else (ISNULL(COUNT_ACH_VehicleLoan_Q1,0) - ISNULL(COUNT_ACH_VehicleLoan_Q3,0)) end [DFT_COUNT_ACH_VehicleLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_ACH_VehicleLoan_Q1 IS NULL AND COUNT_ACH_VehicleLoan_Q4 IS  NULL ) THEN COUNT_ACH_VehicleLoan_Q1 else (ISNULL(COUNT_ACH_VehicleLoan_Q1,0) - ISNULL(COUNT_ACH_VehicleLoan_Q4,0)) end [DFT_COUNT_ACH_VehicleLoan_Q1_Q4]
			 --,COUNT_FEE_VehicleLoan_SP
			 ,COUNT_FEE_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_FEE_VehicleLoan_Q1 IS NULL AND COUNT_FEE_VehicleLoan_Q2 IS  NULL ) THEN COUNT_FEE_VehicleLoan_Q1 else (ISNULL(COUNT_FEE_VehicleLoan_Q1,0) - ISNULL(COUNT_FEE_VehicleLoan_Q2,0)) end [DFT_COUNT_FEE_VehicleLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_FEE_VehicleLoan_Q1 IS NULL AND COUNT_FEE_VehicleLoan_Q3 IS  NULL ) THEN COUNT_FEE_VehicleLoan_Q1 else (ISNULL(COUNT_FEE_VehicleLoan_Q1,0) - ISNULL(COUNT_FEE_VehicleLoan_Q3,0)) end [DFT_COUNT_FEE_VehicleLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_FEE_VehicleLoan_Q1 IS NULL AND COUNT_FEE_VehicleLoan_Q4 IS  NULL ) THEN COUNT_FEE_VehicleLoan_Q1 else (ISNULL(COUNT_FEE_VehicleLoan_Q1,0) - ISNULL(COUNT_FEE_VehicleLoan_Q4,0)) end [DFT_COUNT_FEE_VehicleLoan_Q1_Q4]
			 --,COUNT_HOMEBANKING_VehicleLoan_SP
			 ,COUNT_HOMEBANKING_VehicleLoan_Q1
			 ,CASE WHEN (COUNT_HOMEBANKING_VehicleLoan_Q1 IS NULL AND COUNT_HOMEBANKING_VehicleLoan_Q2 IS  NULL ) THEN COUNT_HOMEBANKING_VehicleLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_VehicleLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_VehicleLoan_Q2,0)) end [DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_HOMEBANKING_VehicleLoan_Q1 IS NULL AND COUNT_HOMEBANKING_VehicleLoan_Q3 IS  NULL ) THEN COUNT_HOMEBANKING_VehicleLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_VehicleLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_VehicleLoan_Q3,0)) end [DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_HOMEBANKING_VehicleLoan_Q1 IS NULL AND COUNT_HOMEBANKING_VehicleLoan_Q4 IS  NULL ) THEN COUNT_HOMEBANKING_VehicleLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_VehicleLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_VehicleLoan_Q4,0)) end [DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q4]
			 --,COUNT_INSURANCE_VehicleLoan_SP
			 ,COUNT_INSURANCE_VehicleLoan_Q1
			 ,CASE WHEN (COUNT_INSURANCE_VehicleLoan_Q1 IS NULL AND COUNT_INSURANCE_VehicleLoan_Q2 IS  NULL ) THEN COUNT_INSURANCE_VehicleLoan_Q1 else (ISNULL(COUNT_INSURANCE_VehicleLoan_Q1,0) - ISNULL(COUNT_INSURANCE_VehicleLoan_Q2,0)) end [DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_INSURANCE_VehicleLoan_Q1 IS NULL AND COUNT_INSURANCE_VehicleLoan_Q3 IS  NULL ) THEN COUNT_INSURANCE_VehicleLoan_Q1 else (ISNULL(COUNT_INSURANCE_VehicleLoan_Q1,0) - ISNULL(COUNT_INSURANCE_VehicleLoan_Q3,0)) end [DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_INSURANCE_VehicleLoan_Q1 IS NULL AND COUNT_INSURANCE_VehicleLoan_Q4 IS  NULL ) THEN COUNT_INSURANCE_VehicleLoan_Q1 else (ISNULL(COUNT_INSURANCE_VehicleLoan_Q1,0) - ISNULL(COUNT_INSURANCE_VehicleLoan_Q4,0)) end [DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q4]
			 --,COUNT_CHECKS_VehicleLoan_SP
			 ,COUNT_CHECKS_VehicleLoan_Q1
			 ,CASE WHEN (COUNT_CHECKS_VehicleLoan_Q1 IS NULL AND COUNT_CHECKS_VehicleLoan_Q2 IS  NULL ) THEN COUNT_CHECKS_VehicleLoan_Q1 else (ISNULL(COUNT_CHECKS_VehicleLoan_Q1,0) - ISNULL(COUNT_CHECKS_VehicleLoan_Q2,0)) end [DFT_COUNT_CHECKS_VehicleLoan_Q1_Q2] 
			 ,CASE WHEN (COUNT_CHECKS_VehicleLoan_Q1 IS NULL AND COUNT_CHECKS_VehicleLoan_Q3 IS  NULL ) THEN COUNT_CHECKS_VehicleLoan_Q1 else (ISNULL(COUNT_CHECKS_VehicleLoan_Q1,0) - ISNULL(COUNT_CHECKS_VehicleLoan_Q3,0)) end [DFT_COUNT_CHECKS_VehicleLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_CHECKS_VehicleLoan_Q1 IS NULL AND COUNT_CHECKS_VehicleLoan_Q4 IS  NULL ) THEN COUNT_CHECKS_VehicleLoan_Q1 else (ISNULL(COUNT_CHECKS_VehicleLoan_Q1,0) - ISNULL(COUNT_CHECKS_VehicleLoan_Q4,0)) end [DFT_COUNT_CHECKS_VehicleLoan_Q1_Q4]
			 --,COUNT_PAYROLL_VehicleLoan_SP
			 ,COUNT_PAYROLL_VehicleLoan_Q1
			 ,CASE WHEN (COUNT_PAYROLL_VehicleLoan_Q1 IS NULL AND COUNT_PAYROLL_VehicleLoan_Q2 IS  NULL ) THEN COUNT_PAYROLL_VehicleLoan_Q1 else (ISNULL(COUNT_PAYROLL_VehicleLoan_Q1,0) - ISNULL(COUNT_PAYROLL_VehicleLoan_Q2,0)) end [DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_PAYROLL_VehicleLoan_Q1 IS NULL AND COUNT_PAYROLL_VehicleLoan_Q3 IS  NULL ) THEN COUNT_PAYROLL_VehicleLoan_Q1 else (ISNULL(COUNT_PAYROLL_VehicleLoan_Q1,0) - ISNULL(COUNT_PAYROLL_VehicleLoan_Q3,0)) end [DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_PAYROLL_VehicleLoan_Q1 IS NULL AND COUNT_PAYROLL_VehicleLoan_Q4 IS  NULL ) THEN COUNT_PAYROLL_VehicleLoan_Q1 else (ISNULL(COUNT_PAYROLL_VehicleLoan_Q1,0) - ISNULL(COUNT_PAYROLL_VehicleLoan_Q4,0)) end [DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q4]
			 --,COUNT_KIOSK_VehicleLoan_SP
			 ,COUNT_KIOSK_VehicleLoan_Q1
			 ,CASE WHEN (COUNT_KIOSK_VehicleLoan_Q1 IS NULL AND COUNT_KIOSK_VehicleLoan_Q2 IS  NULL ) THEN COUNT_KIOSK_VehicleLoan_Q1 else (ISNULL(COUNT_KIOSK_VehicleLoan_Q1,0) - ISNULL(COUNT_KIOSK_VehicleLoan_Q2,0)) end [DFT_COUNT_KIOSK_VehicleLoan_Q1_Q2]
			 ,CASE WHEN (COUNT_KIOSK_VehicleLoan_Q1 IS NULL AND COUNT_KIOSK_VehicleLoan_Q3 IS  NULL ) THEN COUNT_KIOSK_VehicleLoan_Q1 else (ISNULL(COUNT_KIOSK_VehicleLoan_Q1,0) - ISNULL(COUNT_KIOSK_VehicleLoan_Q3,0)) end [DFT_COUNT_KIOSK_VehicleLoan_Q1_Q3]
			 --,CASE WHEN (COUNT_KIOSK_VehicleLoan_Q1 IS NULL AND COUNT_KIOSK_VehicleLoan_Q4 IS  NULL ) THEN COUNT_KIOSK_VehicleLoan_Q1 else (ISNULL(COUNT_KIOSK_VehicleLoan_Q1,0) - ISNULL(COUNT_KIOSK_VehicleLoan_Q4,0)) end [DFT_COUNT_KIOSK_VehicleLoan_Q1_Q4]
			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_SP
			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q2]
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q3 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q3,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q3]
			 --,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q4 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q4,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q4]

			 ,LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2]
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q3 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q3,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3]
			 --,CASE WHEN (LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q4 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q4,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q4]
			 --,INTEREST_AMOUNT_VehicleLoan_SP
			 ,INTEREST_AMOUNT_VehicleLoan_Q1
			 ,CASE WHEN (INTEREST_AMOUNT_VehicleLoan_Q1 IS NULL AND INTEREST_AMOUNT_VehicleLoan_Q2 IS  NULL ) THEN INTEREST_AMOUNT_VehicleLoan_Q1 else (ISNULL(INTEREST_AMOUNT_VehicleLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_VehicleLoan_Q2,0)) end [DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2]
			 ,CASE WHEN (INTEREST_AMOUNT_VehicleLoan_Q1 IS NULL AND INTEREST_AMOUNT_VehicleLoan_Q3 IS  NULL ) THEN INTEREST_AMOUNT_VehicleLoan_Q1 else (ISNULL(INTEREST_AMOUNT_VehicleLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_VehicleLoan_Q3,0)) end [DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q3]
			 --,CASE WHEN (INTEREST_AMOUNT_VehicleLoan_Q1 IS NULL AND INTEREST_AMOUNT_VehicleLoan_Q4 IS  NULL ) THEN INTEREST_AMOUNT_VehicleLoan_Q1 else (ISNULL(INTEREST_AMOUNT_VehicleLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_VehicleLoan_Q4,0)) end [DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q4]
			 --,FEEAMOUNT_VehicleLoan_SP
			 ,FEEAMOUNT_VehicleLoan_Q1
			 ,CASE WHEN (FEEAMOUNT_VehicleLoan_Q1 IS NULL AND FEEAMOUNT_VehicleLoan_Q2 IS  NULL ) THEN FEEAMOUNT_VehicleLoan_Q1 else (ISNULL(FEEAMOUNT_VehicleLoan_Q1,0) - ISNULL(FEEAMOUNT_VehicleLoan_Q2,0)) end [DFT_FEEAMOUNT_VehicleLoan_Q1_Q2]
			 ,CASE WHEN (FEEAMOUNT_VehicleLoan_Q1 IS NULL AND FEEAMOUNT_VehicleLoan_Q3 IS  NULL ) THEN FEEAMOUNT_VehicleLoan_Q1 else (ISNULL(FEEAMOUNT_VehicleLoan_Q1,0) - ISNULL(FEEAMOUNT_VehicleLoan_Q3,0)) end [DFT_FEEAMOUNT_VehicleLoan_Q1_Q3]
			 --,CASE WHEN (FEEAMOUNT_VehicleLoan_Q1 IS NULL AND FEEAMOUNT_VehicleLoan_Q4 IS  NULL ) THEN FEEAMOUNT_VehicleLoan_Q1 else (ISNULL(FEEAMOUNT_VehicleLoan_Q1,0) - ISNULL(FEEAMOUNT_VehicleLoan_Q4,0)) end [DFT_FEEAMOUNT_VehicleLoan_Q1_Q4]
			 --,AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_SP
			 ,AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2]
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q3 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q3,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3]
			 --,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q4 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q4,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q4]
			 ,AVG_NEWBALANCE_VehicleLoan_Q1
			 ,CASE WHEN (AVG_NEWBALANCE_VehicleLoan_Q1 IS NULL AND AVG_NEWBALANCE_VehicleLoan_Q2 IS  NULL ) THEN AVG_NEWBALANCE_VehicleLoan_Q1 else (ISNULL(AVG_NEWBALANCE_VehicleLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_VehicleLoan_Q2,0)) end [DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2]
			 ,CASE WHEN (AVG_NEWBALANCE_VehicleLoan_Q1 IS NULL AND AVG_NEWBALANCE_VehicleLoan_Q3 IS  NULL ) THEN AVG_NEWBALANCE_VehicleLoan_Q1 else (ISNULL(AVG_NEWBALANCE_VehicleLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_VehicleLoan_Q3,0)) end [DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q3]
			 --,CASE WHEN (AVG_NEWBALANCE_VehicleLoan_Q1 IS NULL AND AVG_NEWBALANCE_VehicleLoan_Q4 IS  NULL ) THEN AVG_NEWBALANCE_VehicleLoan_Q1 else (ISNULL(AVG_NEWBALANCE_VehicleLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_VehicleLoan_Q4,0)) end [DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q4]
			 --,AVG_FEEAMOUNT_VehicleLoan_SP
			 ,AVG_FEEAMOUNT_VehicleLoan_Q1
			 ,CASE WHEN (AVG_FEEAMOUNT_VehicleLoan_Q1 IS NULL AND AVG_FEEAMOUNT_VehicleLoan_Q2 IS  NULL ) THEN AVG_FEEAMOUNT_VehicleLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_VehicleLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_VehicleLoan_Q2,0)) end [DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q2]
			 ,CASE WHEN (AVG_FEEAMOUNT_VehicleLoan_Q1 IS NULL AND AVG_FEEAMOUNT_VehicleLoan_Q3 IS  NULL ) THEN AVG_FEEAMOUNT_VehicleLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_VehicleLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_VehicleLoan_Q3,0)) end [DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q3]
			 --,CASE WHEN (AVG_FEEAMOUNT_VehicleLoan_Q1 IS NULL AND AVG_FEEAMOUNT_VehicleLoan_Q4 IS  NULL ) THEN AVG_FEEAMOUNT_VehicleLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_VehicleLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_VehicleLoan_Q4,0)) end [DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q4]

	         ,COUNT_LOAN_ADDON_Others_Q1
			 ,CASE WHEN ( COUNT_LOAN_ADDON_Others_Q1 IS NULL AND COUNT_LOAN_ADDON_Others_Q2 IS  NULL ) THEN COUNT_LOAN_ADDON_Others_Q1 else (ISNULL(COUNT_LOAN_ADDON_Others_Q1,0) - ISNULL(COUNT_LOAN_ADDON_Others_Q2,0)) end [DFT_COUNT_LOAN_ADDON_Others_Q1_Q2]
			 ,CASE WHEN ( COUNT_LOAN_ADDON_Others_Q1 IS NULL AND COUNT_LOAN_ADDON_Others_Q3 IS  NULL ) THEN COUNT_LOAN_ADDON_Others_Q1 else (ISNULL(COUNT_LOAN_ADDON_Others_Q1,0) - ISNULL(COUNT_LOAN_ADDON_Others_Q3,0)) end [DFT_COUNT_LOAN_ADDON_Others_Q1_Q3]
			 --,CASE WHEN ( COUNT_LOAN_ADDON_Others_Q1 IS NULL AND COUNT_LOAN_ADDON_Others_Q4 IS  NULL ) THEN COUNT_LOAN_ADDON_Others_Q1 else (ISNULL(COUNT_LOAN_ADDON_Others_Q1,0) - ISNULL(COUNT_LOAN_ADDON_Others_Q4,0)) end [DFT_COUNT_LOAN_ADDON_Others_Q1_Q4]
			 --,COUNT_NEW_LOAN_Others_SP
			 ,COUNT_NEW_LOAN_Others_Q1
			 ,CASE WHEN ( COUNT_NEW_LOAN_Others_Q1 IS NULL AND COUNT_NEW_LOAN_Others_Q2 IS  NULL ) THEN COUNT_NEW_LOAN_Others_Q1 else (ISNULL(COUNT_NEW_LOAN_Others_Q1,0) - ISNULL(COUNT_NEW_LOAN_Others_Q2,0)) end [COUNT_NEW_LOAN_Others_Q1_Q2]
			 ,CASE WHEN ( COUNT_NEW_LOAN_Others_Q1 IS NULL AND COUNT_NEW_LOAN_Others_Q3 IS  NULL ) THEN COUNT_NEW_LOAN_Others_Q1 else (ISNULL(COUNT_NEW_LOAN_Others_Q1,0) - ISNULL(COUNT_NEW_LOAN_Others_Q3,0)) end [COUNT_NEW_LOAN_Others_Q1_Q3]
			 --,CASE WHEN ( COUNT_NEW_LOAN_Others_Q1 IS NULL AND COUNT_NEW_LOAN_Others_Q4 IS  NULL ) THEN COUNT_NEW_LOAN_Others_Q1 else (ISNULL(COUNT_NEW_LOAN_Others_Q1,0) - ISNULL(COUNT_NEW_LOAN_Others_Q4,0)) end [COUNT_NEW_LOAN_Others_Q1_Q4]
			 --,COUNT_LOAN_PAYMENT_Others_SP
			 ,COUNT_LOAN_PAYMENT_Others_Q1
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_Others_Q1 IS NULL AND COUNT_LOAN_PAYMENT_Others_Q2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_Others_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_Others_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_Others_Q2,0)) end [DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q2]
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_Others_Q1 IS NULL AND COUNT_LOAN_PAYMENT_Others_Q3 IS  NULL ) THEN COUNT_LOAN_PAYMENT_Others_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_Others_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_Others_Q3,0)) end [DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q3]
			 --,CASE WHEN ( COUNT_LOAN_PAYMENT_Others_Q1 IS NULL AND COUNT_LOAN_PAYMENT_Others_Q4 IS  NULL ) THEN COUNT_LOAN_PAYMENT_Others_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_Others_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_Others_Q4,0)) end [DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q4]
			 --,COUNT_CASH_Others_SP
			 ,COUNT_CASH_Others_Q1
			 ,CASE WHEN ( COUNT_CASH_Others_Q1 IS NULL AND COUNT_CASH_Others_Q2 IS  NULL ) THEN COUNT_CASH_Others_Q1 else (ISNULL(COUNT_CASH_Others_Q1,0) - ISNULL(COUNT_CASH_Others_Q2,0)) end [DFT_COUNT_CASH_Others_Q1_Q2]
			 ,CASE WHEN ( COUNT_CASH_Others_Q1 IS NULL AND COUNT_CASH_Others_Q3 IS  NULL ) THEN COUNT_CASH_Others_Q1 else (ISNULL(COUNT_CASH_Others_Q1,0) - ISNULL(COUNT_CASH_Others_Q3,0)) end [DFT_COUNT_CASH_Others_Q1_Q3]
			 --,CASE WHEN ( COUNT_CASH_Others_Q1 IS NULL AND COUNT_CASH_Others_Q4 IS  NULL ) THEN COUNT_CASH_Others_Q1 else (ISNULL(COUNT_CASH_Others_Q1,0) - ISNULL(COUNT_CASH_Others_Q4,0)) end [DFT_COUNT_CASH_Others_Q1_Q4]
			 --,COUNT_DRAFT_Others_SP
			 ,COUNT_DRAFT_Others_Q1
			 ,CASE WHEN ( COUNT_DRAFT_Others_Q1 IS NULL AND COUNT_DRAFT_Others_Q2 IS  NULL ) THEN COUNT_DRAFT_Others_Q1 else (ISNULL(COUNT_DRAFT_Others_Q1,0) - ISNULL(COUNT_DRAFT_Others_Q2,0)) end [DFT_COUNT_DRAFT_Others_Q1_Q2]
			 ,CASE WHEN ( COUNT_DRAFT_Others_Q1 IS NULL AND COUNT_DRAFT_Others_Q3 IS  NULL ) THEN COUNT_DRAFT_Others_Q1 else (ISNULL(COUNT_DRAFT_Others_Q1,0) - ISNULL(COUNT_DRAFT_Others_Q3,0)) end [DFT_COUNT_DRAFT_Others_Q1_Q3]
			 --,CASE WHEN ( COUNT_DRAFT_Others_Q1 IS NULL AND COUNT_DRAFT_Others_Q4 IS  NULL ) THEN COUNT_DRAFT_Others_Q1 else (ISNULL(COUNT_DRAFT_Others_Q1,0) - ISNULL(COUNT_DRAFT_Others_Q4,0)) end [DFT_COUNT_DRAFT_Others_Q1_Q4]
			 --,COUNT_ACH_Others_SP
			 ,COUNT_ACH_Others_Q1
			 ,CASE WHEN ( COUNT_ACH_Others_Q1 IS NULL AND COUNT_ACH_Others_Q2 IS  NULL ) THEN COUNT_ACH_Others_Q1 else (ISNULL(COUNT_ACH_Others_Q1,0) - ISNULL(COUNT_ACH_Others_Q2,0)) end [DFT_COUNT_ACH_Others_Q1_Q2]
			 ,CASE WHEN ( COUNT_ACH_Others_Q1 IS NULL AND COUNT_ACH_Others_Q3 IS  NULL ) THEN COUNT_ACH_Others_Q1 else (ISNULL(COUNT_ACH_Others_Q1,0) - ISNULL(COUNT_ACH_Others_Q3,0)) end [DFT_COUNT_ACH_Others_Q1_Q3]
			 --,CASE WHEN ( COUNT_ACH_Others_Q1 IS NULL AND COUNT_ACH_Others_Q4 IS  NULL ) THEN COUNT_ACH_Others_Q1 else (ISNULL(COUNT_ACH_Others_Q1,0) - ISNULL(COUNT_ACH_Others_Q4,0)) end [DFT_COUNT_ACH_Others_Q1_Q4]
			 --,COUNT_FEE_Others_SP
			 ,COUNT_FEE_Others_Q1
			 ,CASE WHEN ( COUNT_FEE_Others_Q1 IS NULL AND COUNT_FEE_Others_Q2 IS  NULL ) THEN COUNT_FEE_Others_Q1 else (ISNULL(COUNT_FEE_Others_Q1,0) - ISNULL(COUNT_FEE_Others_Q2,0)) end [DFT_COUNT_FEE_Others_Q1_Q2]
			 ,CASE WHEN ( COUNT_FEE_Others_Q1 IS NULL AND COUNT_FEE_Others_Q3 IS  NULL ) THEN COUNT_FEE_Others_Q1 else (ISNULL(COUNT_FEE_Others_Q1,0) - ISNULL(COUNT_FEE_Others_Q3,0)) end [DFT_COUNT_FEE_Others_Q1_Q3]
			 --,CASE WHEN ( COUNT_FEE_Others_Q1 IS NULL AND COUNT_FEE_Others_Q4 IS  NULL ) THEN COUNT_FEE_Others_Q1 else (ISNULL(COUNT_FEE_Others_Q1,0) - ISNULL(COUNT_FEE_Others_Q4,0)) end [DFT_COUNT_FEE_Others_Q1_Q4]
			 --,COUNT_HOMEBANKING_Others_SP
			 ,COUNT_HOMEBANKING_Others_Q1
			 ,CASE WHEN (COUNT_HOMEBANKING_Others_Q1 IS NULL AND COUNT_HOMEBANKING_Others_Q2 IS  NULL ) THEN COUNT_HOMEBANKING_Others_Q1 else (ISNULL(COUNT_HOMEBANKING_Others_Q1,0) - ISNULL(COUNT_HOMEBANKING_Others_Q2,0)) end [DFT_COUNT_HOMEBANKING_Others_Q1_Q2]
			 ,CASE WHEN (COUNT_HOMEBANKING_Others_Q1 IS NULL AND COUNT_HOMEBANKING_Others_Q3 IS  NULL ) THEN COUNT_HOMEBANKING_Others_Q1 else (ISNULL(COUNT_HOMEBANKING_Others_Q1,0) - ISNULL(COUNT_HOMEBANKING_Others_Q3,0)) end [DFT_COUNT_HOMEBANKING_Others_Q1_Q3]
			 --,CASE WHEN (COUNT_HOMEBANKING_Others_Q1 IS NULL AND COUNT_HOMEBANKING_Others_Q4 IS  NULL ) THEN COUNT_HOMEBANKING_Others_Q1 else (ISNULL(COUNT_HOMEBANKING_Others_Q1,0) - ISNULL(COUNT_HOMEBANKING_Others_Q4,0)) end [DFT_COUNT_HOMEBANKING_Others_Q1_Q4]
			 --,COUNT_INSURANCE_Others_SP
			 ,COUNT_INSURANCE_Others_Q1
			 ,CASE WHEN (COUNT_INSURANCE_Others_Q1 IS NULL AND COUNT_INSURANCE_Others_Q2 IS  NULL ) THEN COUNT_INSURANCE_Others_Q1 else (ISNULL(COUNT_INSURANCE_Others_Q1,0) - ISNULL(COUNT_INSURANCE_Others_Q2,0)) end [DFT_COUNT_INSURANCE_Others_Q1_Q2]
			 ,CASE WHEN (COUNT_INSURANCE_Others_Q1 IS NULL AND COUNT_INSURANCE_Others_Q3 IS  NULL ) THEN COUNT_INSURANCE_Others_Q1 else (ISNULL(COUNT_INSURANCE_Others_Q1,0) - ISNULL(COUNT_INSURANCE_Others_Q3,0)) end [DFT_COUNT_INSURANCE_Others_Q1_Q3]
			 --,CASE WHEN (COUNT_INSURANCE_Others_Q1 IS NULL AND COUNT_INSURANCE_Others_Q4 IS  NULL ) THEN COUNT_INSURANCE_Others_Q1 else (ISNULL(COUNT_INSURANCE_Others_Q1,0) - ISNULL(COUNT_INSURANCE_Others_Q4,0)) end [DFT_COUNT_INSURANCE_Others_Q1_Q4]
			 --,COUNT_CHECKS_Others_SP
			 ,COUNT_CHECKS_Others_Q1
			 ,CASE WHEN (COUNT_CHECKS_Others_Q1 IS NULL AND COUNT_CHECKS_Others_Q2 IS  NULL ) THEN COUNT_CHECKS_Others_Q1 else (ISNULL(COUNT_CHECKS_Others_Q1,0) - ISNULL(COUNT_CHECKS_Others_Q2,0)) end [DFT_COUNT_CHECKS_Others_Q1_Q2] 
			 ,CASE WHEN (COUNT_CHECKS_Others_Q1 IS NULL AND COUNT_CHECKS_Others_Q3 IS  NULL ) THEN COUNT_CHECKS_Others_Q1 else (ISNULL(COUNT_CHECKS_Others_Q1,0) - ISNULL(COUNT_CHECKS_Others_Q3,0)) end [DFT_COUNT_CHECKS_Others_Q1_Q3]
			 --,CASE WHEN (COUNT_CHECKS_Others_Q1 IS NULL AND COUNT_CHECKS_Others_Q4 IS  NULL ) THEN COUNT_CHECKS_Others_Q1 else (ISNULL(COUNT_CHECKS_Others_Q1,0) - ISNULL(COUNT_CHECKS_Others_Q4,0)) end [DFT_COUNT_CHECKS_Others_Q1_Q4]
			 --,COUNT_PAYROLL_Others_SP
			 ,COUNT_PAYROLL_Others_Q1
			 ,CASE WHEN (COUNT_PAYROLL_Others_Q1 IS NULL AND COUNT_PAYROLL_Others_Q2 IS  NULL ) THEN COUNT_PAYROLL_Others_Q1 else (ISNULL(COUNT_PAYROLL_Others_Q1,0) - ISNULL(COUNT_PAYROLL_Others_Q2,0)) end [DFT_COUNT_PAYROLL_Others_Q1_Q2]
			 ,CASE WHEN (COUNT_PAYROLL_Others_Q1 IS NULL AND COUNT_PAYROLL_Others_Q3 IS  NULL ) THEN COUNT_PAYROLL_Others_Q1 else (ISNULL(COUNT_PAYROLL_Others_Q1,0) - ISNULL(COUNT_PAYROLL_Others_Q3,0)) end [DFT_COUNT_PAYROLL_Others_Q1_Q3]
			 --,CASE WHEN (COUNT_PAYROLL_Others_Q1 IS NULL AND COUNT_PAYROLL_Others_Q4 IS  NULL ) THEN COUNT_PAYROLL_Others_Q1 else (ISNULL(COUNT_PAYROLL_Others_Q1,0) - ISNULL(COUNT_PAYROLL_Others_Q4,0)) end [DFT_COUNT_PAYROLL_Others_Q1_Q4]
			 --,COUNT_KIOSK_Others_SP
			 ,COUNT_KIOSK_Others_Q1
			 ,CASE WHEN (COUNT_KIOSK_Others_Q1 IS NULL AND COUNT_KIOSK_Others_Q2 IS  NULL ) THEN COUNT_KIOSK_Others_Q1 else (ISNULL(COUNT_KIOSK_Others_Q1,0) - ISNULL(COUNT_KIOSK_Others_Q2,0)) end [DFT_COUNT_KIOSK_Others_Q1_Q2]
			 ,CASE WHEN (COUNT_KIOSK_Others_Q1 IS NULL AND COUNT_KIOSK_Others_Q3 IS  NULL ) THEN COUNT_KIOSK_Others_Q1 else (ISNULL(COUNT_KIOSK_Others_Q1,0) - ISNULL(COUNT_KIOSK_Others_Q3,0)) end [DFT_COUNT_KIOSK_Others_Q1_Q3]
			 --,CASE WHEN (COUNT_KIOSK_Others_Q1 IS NULL AND COUNT_KIOSK_Others_Q4 IS  NULL ) THEN COUNT_KIOSK_Others_Q1 else (ISNULL(COUNT_KIOSK_Others_Q1,0) - ISNULL(COUNT_KIOSK_Others_Q4,0)) end [DFT_COUNT_KIOSK_Others_Q1_Q4]
			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_Others_SP
			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q2]
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q3 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q3,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q3]
			 --,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q4 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q4,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q4]

			 ,LOAN_TRANSACTION_AMOUNT_Others_Q1
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_Others_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_Others_Q2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_Others_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_Others_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_Others_Q2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q2]
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_Others_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_Others_Q3 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_Others_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_Others_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_Others_Q3,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q3]
			 --,CASE WHEN (LOAN_TRANSACTION_AMOUNT_Others_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_Others_Q4 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_Others_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_Others_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_Others_Q4,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q4]
			 --,INTEREST_AMOUNT_Others_SP
			 ,INTEREST_AMOUNT_Others_Q1
			 ,CASE WHEN (INTEREST_AMOUNT_Others_Q1 IS NULL AND INTEREST_AMOUNT_Others_Q2 IS  NULL ) THEN INTEREST_AMOUNT_Others_Q1 else (ISNULL(INTEREST_AMOUNT_Others_Q1,0) - ISNULL(INTEREST_AMOUNT_Others_Q2,0)) end [DFT_INTEREST_AMOUNT_Others_Q1_Q2]
			 ,CASE WHEN (INTEREST_AMOUNT_Others_Q1 IS NULL AND INTEREST_AMOUNT_Others_Q3 IS  NULL ) THEN INTEREST_AMOUNT_Others_Q1 else (ISNULL(INTEREST_AMOUNT_Others_Q1,0) - ISNULL(INTEREST_AMOUNT_Others_Q3,0)) end [DFT_INTEREST_AMOUNT_Others_Q1_Q3]
			 --,CASE WHEN (INTEREST_AMOUNT_Others_Q1 IS NULL AND INTEREST_AMOUNT_Others_Q4 IS  NULL ) THEN INTEREST_AMOUNT_Others_Q1 else (ISNULL(INTEREST_AMOUNT_Others_Q1,0) - ISNULL(INTEREST_AMOUNT_Others_Q4,0)) end [DFT_INTEREST_AMOUNT_Others_Q1_Q4]
			 --,FEEAMOUNT_Others_SP
			 ,FEEAMOUNT_Others_Q1
			 ,CASE WHEN (FEEAMOUNT_Others_Q1 IS NULL AND FEEAMOUNT_Others_Q2 IS  NULL ) THEN FEEAMOUNT_Others_Q1 else (ISNULL(FEEAMOUNT_Others_Q1,0) - ISNULL(FEEAMOUNT_Others_Q2,0)) end [DFT_FEEAMOUNT_Others_Q1_Q2]
			 ,CASE WHEN (FEEAMOUNT_Others_Q1 IS NULL AND FEEAMOUNT_Others_Q3 IS  NULL ) THEN FEEAMOUNT_Others_Q1 else (ISNULL(FEEAMOUNT_Others_Q1,0) - ISNULL(FEEAMOUNT_Others_Q3,0)) end [DFT_FEEAMOUNT_Others_Q1_Q3]
			 --,CASE WHEN (FEEAMOUNT_Others_Q1 IS NULL AND FEEAMOUNT_Others_Q4 IS  NULL ) THEN FEEAMOUNT_Others_Q1 else (ISNULL(FEEAMOUNT_Others_Q1,0) - ISNULL(FEEAMOUNT_Others_Q4,0)) end [DFT_FEEAMOUNT_Others_Q1_Q4]
			 --,AVG_LOAN_TRANSACTION_AMOUNT_Others_SP
			 ,AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_Others_Q2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Others_Q2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q2]
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_Others_Q3 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Others_Q3,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q3]
			 --,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_Others_Q4 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Others_Q4,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q4]
			 ,AVG_NEWBALANCE_Others_Q1
			 ,CASE WHEN (AVG_NEWBALANCE_Others_Q1 IS NULL AND AVG_NEWBALANCE_Others_Q2 IS  NULL ) THEN AVG_NEWBALANCE_Others_Q1 else (ISNULL(AVG_NEWBALANCE_Others_Q1,0) - ISNULL(AVG_NEWBALANCE_Others_Q2,0)) end [DFT_AVG_NEWBALANCE_Others_Q1_Q2]
			 ,CASE WHEN (AVG_NEWBALANCE_Others_Q1 IS NULL AND AVG_NEWBALANCE_Others_Q3 IS  NULL ) THEN AVG_NEWBALANCE_Others_Q1 else (ISNULL(AVG_NEWBALANCE_Others_Q1,0) - ISNULL(AVG_NEWBALANCE_Others_Q3,0)) end [DFT_AVG_NEWBALANCE_Others_Q1_Q3]
			 --,CASE WHEN (AVG_NEWBALANCE_Others_Q1 IS NULL AND AVG_NEWBALANCE_Others_Q4 IS  NULL ) THEN AVG_NEWBALANCE_Others_Q1 else (ISNULL(AVG_NEWBALANCE_Others_Q1,0) - ISNULL(AVG_NEWBALANCE_Others_Q4,0)) end [DFT_AVG_NEWBALANCE_Others_Q1_Q4]
			 --,AVG_FEEAMOUNT_Others_SP
			 ,AVG_FEEAMOUNT_Others_Q1
			 ,CASE WHEN (AVG_FEEAMOUNT_Others_Q1 IS NULL AND AVG_FEEAMOUNT_Others_Q2 IS  NULL ) THEN AVG_FEEAMOUNT_Others_Q1 else (ISNULL(AVG_FEEAMOUNT_Others_Q1,0) - ISNULL(AVG_FEEAMOUNT_Others_Q2,0)) end [DFT_AVG_FEEAMOUNT_Others_Q1_Q2]
			 ,CASE WHEN (AVG_FEEAMOUNT_Others_Q1 IS NULL AND AVG_FEEAMOUNT_Others_Q3 IS  NULL ) THEN AVG_FEEAMOUNT_Others_Q1 else (ISNULL(AVG_FEEAMOUNT_Others_Q1,0) - ISNULL(AVG_FEEAMOUNT_Others_Q3,0)) end [DFT_AVG_FEEAMOUNT_Others_Q1_Q3]
			 --,CASE WHEN (AVG_FEEAMOUNT_Others_Q1 IS NULL AND AVG_FEEAMOUNT_Others_Q4 IS  NULL ) THEN AVG_FEEAMOUNT_Others_Q1 else (ISNULL(AVG_FEEAMOUNT_Others_Q1,0) - ISNULL(AVG_FEEAMOUNT_Others_Q4,0)) end [DFT_AVG_FEEAMOUNT_Others_Q1_Q4]

			  INTO #LOAN_TRANSACTION_derived_vars 
			  FROM #transaction_loan

			  --DROP TABLE IF EXISTS #LOAN_TRANSACTION_MASTER
			  --SELECT A.*,B.SSN SSN002
			  -- into #LOAN_TRANSACTION_MASTER
			  -- FROM 
			  --#LOAN_TRANSACTION_derived_vars A
			  --LEFT JOIN #Static_SSN_account B
			  --ON A.PARENTACCOUNT = B.AccountNumber

			  --SELECT COUNT(DISTINCT SSN_000) FROM #LOAN_TRANSACTION_MASTER
			  --where SSN_000 not in (SELECT SSN from #loan_woCC) -- 3239

			  --SELECT COUNT(DISTINCT SSN) FROM #loan_woCC
			  --where SSN not in (SELECT SSN_000 from #LOAN_TRANSACTION_MASTER) --27399

			  --DROP TABLE IF EXISTS #loan_accounts
			  --SELECT DISTINCT SSN001 SSN_L into #loan_accounts from #loan_product_holdings

			  DROP TABLE IF EXISTS #loan_product_summary
			 
			 SELECT A.*, B.*
			  into #loan_product_summary
			   --FROM #loan_accounts A
			   --left join
			   FROM #loan_product_holdings A
			   
			  LEFT JOIN
			  #LOAN_TRANSACTION_derived_vars B
			  ON A.SSN001 = B.SSN002

			  --SELECT SSN_L, COUNT(*) C FROM #loan_product_summary group by SSN_L
			  --SELECT * FROM #loan_product_summary where SSN_L = '584793617'
			 --DROP TABLE IF EXISTS #updated_loan_product_summary
			 
			 --SELECT CASE WHEN A.SSN001 = B.SSN002 THEN A.SSN001
			 --            WHEN A.SSN001 is null then B.SSN002
			 --		       WHEN B.SSN002 is null then A.SSN001 END [SSN_LOAN]
			 --,A.*,B.*
			 -- into #updated_loan_product_summary
			 --  FROM #loan_product_holdings A
			 -- FULL OUTER JOIN
			 -- #LOAN_TRANSACTION_MASTER B
			 -- ON A.SSN001 = B.SSN002

			  --SELECT DISTINCT SSN002 FROM #LOAN_TRANSACTION_MASTER where SSN002 not in (SELECT DISTINCT SSN001 from #loan_product_holdings) --3239
			   --SELECT DISTINCT SSN001 from #loan_product_holdings where SSN001 not in (SELECT DISTINCT SSN002 FROM #LOAN_TRANSACTION_MASTER) --27399


------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Credit Card ***\\\-------------------------------------------------------------------
			

			 
  drop table if exists #CC_Members_Static
  

	  select distinct [Social Security Number] 
	  into #CC_Members_Static
	  from TMGData.dbo.cardholder 
	  where Active_Flag=1 and ([External Status Code]='' or [Internal Status Code] in ('N',''))
	  and extract_datepart=left(convert(varchar,@staticpooldate,112),6)
	  --and datediff(MONTH,[Date First Active New],@staticpooldate) >= 6   
	   

			


		 drop table if exists #CC_data	
		
		
		select * 
		into #CC_data
		from 
		(
		SELECT  [Durable_Key]
		,case when extract_datepart in (left(convert(varchar,eomonth(dateadd(month,-12,@staticpooldate)),112),6),left(convert(varchar,eomonth(dateadd(month,-11,@staticpooldate)),112),6),left(convert(varchar,eomonth(dateadd(month,-10,@staticpooldate)),112),6)) then 'Q4'
		    when extract_datepart in (left(convert(varchar  ,eomonth(dateadd(month,-9,@staticpooldate)),112),6),left(convert(varchar ,eomonth(dateadd(month,-8,@staticpooldate)),112),6),left(convert(varchar ,eomonth(dateadd(month,-7,@staticpooldate)),112),6)) then 'Q3'
		    when extract_datepart in (left(convert(varchar  ,eomonth(dateadd(month,-6,@staticpooldate)),112),6),left(convert(varchar ,eomonth(dateadd(month,-5,@staticpooldate)),112),6),left(convert(varchar ,eomonth(dateadd(month,-4,@staticpooldate)),112),6)) then 'Q2'
		    when extract_datepart in (left(convert(varchar  ,eomonth(dateadd(month,-3,@staticpooldate)),112),6),left(convert(varchar ,eomonth(dateadd(month,-2,@staticpooldate)),112),6),left(convert(varchar ,eomonth(dateadd(month,-1,@staticpooldate)),112),6)) then 'Q1'
		    when extract_datepart in (left(convert(varchar,@staticpooldate,112),6)) then 'Staticpool' end Quarters
       ,[Social Security Number]
      ,[Credit Limit]
      ,[Extract Date]
       ,[AGE]
      ,[Account System Entry Date]
      ,[Card Account Debit Activity Code]
      ,[Last Statement Payment Count]
      ,[Last Statement Payment Amount]
      ,[Last Statement Sale Amount]
      ,[Last Statement Cash Amount]
      ,[Last Statement Return Amount]
      ,[Last Statment Sale Count]
      ,[Last Statement Cash Advance Count]
      ,[Last Statement Return Count]
      ,[Last Statement External Fee Amount]
      ,[Last Statement Credit Life Change Amount]
      ,[Last Statement Charge Late Amount]
      ,[Last Statement Charge Cash Amount]
      ,[Last Statement Charge Overlimit Amount]
      ,[Last Statement Charge Sale Amount]
      ,[Last Statement Merchandise Average Daily Balance Amount]
      ,[Last Statement Cash Average Daily Balance Amount]
      ,[Last Statement Average Daily Balance Amount]
      ,[Calc Norm Cash Annual Rate]
      ,[Calc Norm Mrch Annual Rate]
      ,[Charge-Off Amount]
      ,[Card Account Charge-Off Date]
      ,[Card Description]
      ,[Card Account Delinquent Day Account]
      ,[Total Amount Account Delinquency]
      ,[Last Statement Cash Interest Amount]
      ,[Accumulated Merchandise Interest Amount]
      ,[Last Statement Balance Amount]
	  ,CASE WHEN [Credit Limit] in (0,NULL) THEN [Last Statement Balance Amount] ELSE ([Last Statement Balance Amount]/[Credit Limit]) END [UTILIZATION_RATE_CC]
      ,[Last Statement Revolving Merchandise Amount]
      ,[extract_datepart]
      ,[Extract_ACCOUNT_OPEN_DATE]
      ,[spend]
      ,[Protected_Balance]
      ,[Promo_Balance]
      ,[Protected_Current_Interest]
      ,[Promo_Current_Interest]
      ,[RevolvingBalance]
      ,[Closed_account_flag]
      ,[mob]
      ,[ChargeoffAmount_final]
      ,[ChargeOff_Extract_DatePart]
	   ,TRIPFLAG
  FROM TMGData.dbo.cardholder 	-- Changed 042222
  where [Social Security Number] in (select [Social Security Number] from #CC_Members_Static)
  and Active_Flag=1
   ) a
    where  quarters is not null 
  ----and mob>=12  ---commented by nikita on 05/10/2022

--- Drift of CC data

		 Drop table if exists #Credit_Card_data
		select 
		SSN_CC
		,CASE WHEN PRODUCT_CC_STATICPOOL > 0 THEN 1 ELSE 0 END [CreditCard_StaticpoolFlag]
		,CASE WHEN PRODUCT_CC_Q1 > 0 THEN 1 ELSE 0 END [CreditCard_Q1Flag]
		,PRODUCT_CC_Q1
		,CASE WHEN PRODUCT_CC_Q1 IS NULL AND PRODUCT_CC_Q2 IS NULL THEN PRODUCT_CC_Q1 ELSE (ISNULL(PRODUCT_CC_Q1,0)-ISNULL(PRODUCT_CC_Q2,0)) END [DFT_PRODUCT_CC_Q1_Q2]
		,CASE WHEN PRODUCT_CC_Q1 IS NULL AND PRODUCT_CC_Q3 IS NULL THEN PRODUCT_CC_Q1 ELSE (ISNULL(PRODUCT_CC_Q1,0)-ISNULL(PRODUCT_CC_Q3,0)) END [DFT_PRODUCT_CC_Q1_Q3]
		--,CASE WHEN PRODUCT_CC_Q1 IS NULL AND PRODUCT_CC_Q4 IS NULL THEN PRODUCT_CC_Q1 ELSE (ISNULL(PRODUCT_CC_Q1,0)-ISNULL(PRODUCT_CC_Q4,0)) END [DFT_PRODUCT_CC_Q1_Q4]
		--,[Last Statement Payment Count_CC_Staticpool]
		,[Last Statement Payment Count_CC_Q1]
		,CASE WHEN ([Last Statement Payment Count_CC_Q1] IS NULL AND [Last Statement Payment Count_CC_Q2] IS  NULL ) THEN [Last Statement Payment Count_CC_Q1] else (ISNULL([Last Statement Payment Count_CC_Q1],0)-ISNULL([Last Statement Payment Count_CC_Q2],0)) end [DFT_Last Statement Payment Count_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Payment Count_CC_Q1] IS NULL AND [Last Statement Payment Count_CC_Q3] IS  NULL ) THEN [Last Statement Payment Count_CC_Q1] else (ISNULL([Last Statement Payment Count_CC_Q1],0)-ISNULL([Last Statement Payment Count_CC_Q3],0)) end [DFT_Last Statement Payment Count_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Payment Count_CC_Q1] IS NULL AND [Last Statement Payment Count_CC_Q4] IS  NULL ) THEN [Last Statement Payment Count_CC_Q1] else (ISNULL([Last Statement Payment Count_CC_Q1],0)-ISNULL([Last Statement Payment Count_CC_Q4],0)) end [DFT_Last Statement Payment Count_CC_Q1_Q4]
		--,[Last Statement Payment Amount)_CC_Staticpool]
		,[Last Statement Payment Amount_CC_Q1]
		,CASE WHEN ([Last Statement Payment Amount_CC_Q1] IS NULL AND [Last Statement Payment Amount_CC_Q2] IS  NULL ) THEN [Last Statement Payment Amount_CC_Q1] else (ISNULL([Last Statement Payment Amount_CC_Q1],0)-ISNULL([Last Statement Payment Amount_CC_Q2],0)) end [DFT_Last Statement Payment Amount_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Payment Amount_CC_Q1] IS NULL AND [Last Statement Payment Amount_CC_Q3] IS  NULL ) THEN [Last Statement Payment Amount_CC_Q1] else (ISNULL([Last Statement Payment Amount_CC_Q1],0)-ISNULL([Last Statement Payment Amount_CC_Q3],0)) end [DFT_Last Statement Payment Amount_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Payment Amount_CC_Q1] IS NULL AND [Last Statement Payment Amount_CC_Q4] IS  NULL ) THEN [Last Statement Payment Amount_CC_Q1] else (ISNULL([Last Statement Payment Amount_CC_Q1],0)-ISNULL([Last Statement Payment Amount_CC_Q4],0)) end [DFT_Last Statement Payment Amount_CC_Q1_Q4]
		--,[Last Statement Sale Amount_CC_Staticpool]
		,[Last Statement Sale Amount_CC_Q1]
		,CASE WHEN ([Last Statement Sale Amount_CC_Q1] IS NULL AND [Last Statement Sale Amount_CC_Q2] IS  NULL ) THEN [Last Statement Sale Amount_CC_Q1] else (ISNULL([Last Statement Sale Amount_CC_Q1],0)-ISNULL([Last Statement Sale Amount_CC_Q2],0)) end [DFT_Last Statement Sale Amount_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Sale Amount_CC_Q1] IS NULL AND [Last Statement Sale Amount_CC_Q3] IS  NULL ) THEN [Last Statement Sale Amount_CC_Q1] else (ISNULL([Last Statement Sale Amount_CC_Q1],0)-ISNULL([Last Statement Sale Amount_CC_Q3],0)) end [DFT_Last Statement Sale Amount_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Sale Amount_CC_Q1] IS NULL AND [Last Statement Sale Amount_CC_Q4] IS  NULL ) THEN [Last Statement Sale Amount_CC_Q1] else (ISNULL([Last Statement Sale Amount_CC_Q1],0)-ISNULL([Last Statement Sale Amount_CC_Q4],0)) end [DFT_Last Statement Sale Amount_CC_Q1_Q4]
		--,[Last Statement Cash Amount_CC_Staticpool]
		,[Last Statement Cash Amount_CC_Q1]
		,CASE WHEN ([Last Statement Cash Amount_CC_Q1] IS NULL AND [Last Statement Cash Amount_CC_Q2] IS  NULL ) THEN [Last Statement Cash Amount_CC_Q1] else (ISNULL([Last Statement Cash Amount_CC_Q1],0)-ISNULL([Last Statement Cash Amount_CC_Q2],0)) end [DFT_Last Statement Cash Amount_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Cash Amount_CC_Q1] IS NULL AND [Last Statement Cash Amount_CC_Q3] IS  NULL ) THEN [Last Statement Cash Amount_CC_Q1] else (ISNULL([Last Statement Cash Amount_CC_Q1],0)-ISNULL([Last Statement Cash Amount_CC_Q3],0)) end [DFT_Last Statement Cash Amount_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Cash Amount_CC_Q1] IS NULL AND [Last Statement Cash Amount_CC_Q4] IS  NULL ) THEN [Last Statement Cash Amount_CC_Q1] else (ISNULL([Last Statement Cash Amount_CC_Q1],0)-ISNULL([Last Statement Cash Amount_CC_Q4],0)) end [DFT_Last Statement Cash Amount_CC_Q1_Q4]
		--,[Last Statement Return Amount_CC_Staticpool]
		,[Last Statement Return Amount_CC_Q1]
		,CASE WHEN ([Last Statement Return Amount_CC_Q1] IS NULL AND [Last Statement Return Amount_CC_Q2] IS  NULL ) THEN [Last Statement Return Amount_CC_Q1] else (ISNULL([Last Statement Return Amount_CC_Q1],0)-ISNULL([Last Statement Return Amount_CC_Q2],0)) end [DFT_Last Statement Return Amount_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Return Amount_CC_Q1] IS NULL AND [Last Statement Return Amount_CC_Q3] IS  NULL ) THEN [Last Statement Return Amount_CC_Q1] else (ISNULL([Last Statement Return Amount_CC_Q1],0)-ISNULL([Last Statement Return Amount_CC_Q3],0)) end [DFT_Last Statement Return Amount_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Return Amount_CC_Q1] IS NULL AND [Last Statement Return Amount_CC_Q4] IS  NULL ) THEN [Last Statement Return Amount_CC_Q1] else (ISNULL([Last Statement Return Amount_CC_Q1],0)-ISNULL([Last Statement Return Amount_CC_Q4],0)) end [DFT_Last Statement Return Amount_CC_Q1_Q4]
		--,[Last Statement Sale Count_CC_Staticpool]
		,[Last Statement Sale Count_CC_Q1]
		,CASE WHEN ([Last Statement Sale Count_CC_Q1] IS NULL AND [Last Statement Sale Count_CC_Q2] IS  NULL ) THEN [Last Statement Sale Count_CC_Q1] else (ISNULL([Last Statement Sale Count_CC_Q1],0)-ISNULL([Last Statement Sale Count_CC_Q2],0)) end [DFT_Last Statement Sale Count_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Sale Count_CC_Q1] IS NULL AND [Last Statement Sale Count_CC_Q3] IS  NULL ) THEN [Last Statement Sale Count_CC_Q1] else (ISNULL([Last Statement Sale Count_CC_Q1],0)-ISNULL([Last Statement Sale Count_CC_Q3],0)) end [DFT_Last Statement Sale Count_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Sale Count_CC_Q1] IS NULL AND [Last Statement Sale Count_CC_Q4] IS  NULL ) THEN [Last Statement Sale Count_CC_Q1] else (ISNULL([Last Statement Sale Count_CC_Q1],0)-ISNULL([Last Statement Sale Count_CC_Q4],0)) end [DFT_Last Statement Sale Count_CC_Q1_Q4]
		--,[Last Statement Cash Advance Count_CC_Staticpool]
		,[Last Statement Cash Advance Count_CC_Q1]
		,CASE WHEN ([Last Statement Cash Advance Count_CC_Q1] IS NULL AND [Last Statement Cash Advance Count_CC_Q2] IS  NULL ) THEN [Last Statement Cash Advance Count_CC_Q1] else (ISNULL([Last Statement Cash Advance Count_CC_Q1],0)-ISNULL([Last Statement Cash Advance Count_CC_Q2],0)) end [DFT_Last Statement Cash Advance Count_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Cash Advance Count_CC_Q1] IS NULL AND [Last Statement Cash Advance Count_CC_Q3] IS  NULL ) THEN [Last Statement Cash Advance Count_CC_Q1] else (ISNULL([Last Statement Cash Advance Count_CC_Q1],0)-ISNULL([Last Statement Cash Advance Count_CC_Q3],0)) end [DFT_Last Statement Cash Advance Count_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Cash Advance Count_CC_Q1] IS NULL AND [Last Statement Cash Advance Count_CC_Q4] IS  NULL ) THEN [Last Statement Cash Advance Count_CC_Q1] else (ISNULL([Last Statement Cash Advance Count_CC_Q1],0)-ISNULL([Last Statement Cash Advance Count_CC_Q4],0)) end [DFT_Last Statement Cash Advance Count_CC_Q1_Q4]
		--,[Last Statement Return Count_CC_Staticpool]
		,[Last Statement Return Count_CC_Q1]
		,CASE WHEN ([Last Statement Return Count_CC_Q1] IS NULL AND [Last Statement Return Count_CC_Q2] IS  NULL ) THEN [Last Statement Return Count_CC_Q1] else  (ISNULL([Last Statement Return Count_CC_Q1],0)-ISNULL([Last Statement Return Count_CC_Q2],0)) end [DFT_Last Statement Return Count_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Return Count_CC_Q1] IS NULL AND [Last Statement Return Count_CC_Q3] IS  NULL ) THEN [Last Statement Return Count_CC_Q1] else  (ISNULL([Last Statement Return Count_CC_Q1],0)-ISNULL([Last Statement Return Count_CC_Q3],0)) end [DFT_Last Statement Return Count_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Return Count_CC_Q1] IS NULL AND [Last Statement Return Count_CC_Q4] IS  NULL ) THEN [Last Statement Return Count_CC_Q1] else  (ISNULL([Last Statement Return Count_CC_Q1],0)-ISNULL([Last Statement Return Count_CC_Q4],0)) end [DFT_Last Statement Return Count_CC_Q1_Q4]
		--,[Last Statement External Fee Amount_CC_Staticpool]
		,[Last Statement External Fee Amount_CC_Q1]
		,CASE WHEN ([Last Statement External Fee Amount_CC_Q1] IS NULL AND [Last Statement External Fee Amount_CC_Q2] IS  NULL ) THEN [Last Statement External Fee Amount_CC_Q1] else (ISNULL([Last Statement External Fee Amount_CC_Q1],0)-ISNULL([Last Statement External Fee Amount_CC_Q2],0)) end [DFT_Last Statement External Fee Amount_CC_Q1_Q2]
		,CASE WHEN ([Last Statement External Fee Amount_CC_Q1] IS NULL AND [Last Statement External Fee Amount_CC_Q3] IS  NULL ) THEN [Last Statement External Fee Amount_CC_Q1] else (ISNULL([Last Statement External Fee Amount_CC_Q1],0)-ISNULL([Last Statement External Fee Amount_CC_Q3],0)) end [DFT_Last Statement External Fee Amount_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement External Fee Amount_CC_Q1] IS NULL AND [Last Statement External Fee Amount_CC_Q4] IS  NULL ) THEN [Last Statement External Fee Amount_CC_Q1] else (ISNULL([Last Statement External Fee Amount_CC_Q1],0)-ISNULL([Last Statement External Fee Amount_CC_Q4],0)) end [DFT_Last Statement External Fee Amount_CC_Q1_Q4]
		--,[Last Statement Credit Life Change Amount_CC_Staticpool]
		,[Last Statement Credit Life Change Amount_CC_Q1]
		,CASE WHEN ([Last Statement Credit Life Change Amount_CC_Q1] IS NULL AND [Last Statement Credit Life Change Amount_CC_Q2] IS  NULL ) THEN [Last Statement Credit Life Change Amount_CC_Q1] else (ISNULL([Last Statement Credit Life Change Amount_CC_Q1],0)-ISNULL([Last Statement Credit Life Change Amount_CC_Q2],0)) end [DFT_Last Statement Credit Life Change Amount_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Credit Life Change Amount_CC_Q1] IS NULL AND [Last Statement Credit Life Change Amount_CC_Q3] IS  NULL ) THEN [Last Statement Credit Life Change Amount_CC_Q1] else (ISNULL([Last Statement Credit Life Change Amount_CC_Q1],0)-ISNULL([Last Statement Credit Life Change Amount_CC_Q3],0)) end [DFT_Last Statement Credit Life Change Amount_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Credit Life Change Amount_CC_Q1] IS NULL AND [Last Statement Credit Life Change Amount_CC_Q4] IS  NULL ) THEN [Last Statement Credit Life Change Amount_CC_Q1] else (ISNULL([Last Statement Credit Life Change Amount_CC_Q1],0)-ISNULL([Last Statement Credit Life Change Amount_CC_Q4],0)) end [DFT_Last Statement Credit Life Change Amount_CC_Q1_Q4]
		--,[Last Statement Charge Late Amount_CC_Staticpool]
		,[Last Statement Charge Late Amount_CC_Q1]
		,CASE WHEN ([Last Statement Charge Late Amount_CC_Q1] IS NULL AND [Last Statement Charge Late Amount_CC_Q2] IS  NULL ) THEN [Last Statement Charge Late Amount_CC_Q2] else (ISNULL([Last Statement Charge Late Amount_CC_Q1],0)-ISNULL([Last Statement Charge Late Amount_CC_Q2],0)) end [DFT_Last Statement Charge Late Amount_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Charge Late Amount_CC_Q1] IS NULL AND [Last Statement Charge Late Amount_CC_Q3] IS  NULL ) THEN [Last Statement Charge Late Amount_CC_Q3] else (ISNULL([Last Statement Charge Late Amount_CC_Q1],0)-ISNULL([Last Statement Charge Late Amount_CC_Q3],0)) end [DFT_Last Statement Charge Late Amount_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Charge Late Amount_CC_Q1] IS NULL AND [Last Statement Charge Late Amount_CC_Q4] IS  NULL ) THEN [Last Statement Charge Late Amount_CC_Q4] else (ISNULL([Last Statement Charge Late Amount_CC_Q1],0)-ISNULL([Last Statement Charge Late Amount_CC_Q4],0)) end [DFT_Last Statement Charge Late Amount_CC_Q1_Q4]
		--,[Last Statement Charge Cash Amount_CC_Staticpool]
		,[Last Statement Charge Cash Amount_CC_Q1]
		,CASE WHEN ([Last Statement Charge Cash Amount_CC_Q1] IS NULL AND [Last Statement Charge Cash Amount_CC_Q2] IS  NULL ) THEN [Last Statement Charge Cash Amount_CC_Q1] else (ISNULL([Last Statement Charge Cash Amount_CC_Q1],0)-ISNULL([Last Statement Charge Cash Amount_CC_Q2],0)) end [DFT_Last Statement Charge Cash Amount_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Charge Cash Amount_CC_Q1] IS NULL AND [Last Statement Charge Cash Amount_CC_Q3] IS  NULL ) THEN [Last Statement Charge Cash Amount_CC_Q1] else (ISNULL([Last Statement Charge Cash Amount_CC_Q1],0)-ISNULL([Last Statement Charge Cash Amount_CC_Q3],0)) end [DFT_Last Statement Charge Cash Amount_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Charge Cash Amount_CC_Q1] IS NULL AND [Last Statement Charge Cash Amount_CC_Q4] IS  NULL ) THEN [Last Statement Charge Cash Amount_CC_Q1] else (ISNULL([Last Statement Charge Cash Amount_CC_Q1],0)-ISNULL([Last Statement Charge Cash Amount_CC_Q4],0)) end [DFT_Last Statement Charge Cash Amount_CC_Q1_Q4]
		--,[Last Statement Charge Overlimit Amount_CC_Staticpool]
		,[Last Statement Charge Overlimit Amount_CC_Q1]
		,CASE WHEN ([Last Statement Charge Overlimit Amount_CC_Q1] IS NULL AND [Last Statement Charge Overlimit Amount_CC_Q2] IS  NULL ) THEN [Last Statement Charge Overlimit Amount_CC_Q1] else (ISNULL([Last Statement Charge Overlimit Amount_CC_Q1],0)-ISNULL([Last Statement Charge Overlimit Amount_CC_Q2],0)) end [DFT_Last Statement Charge Overlimit Amount_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Charge Overlimit Amount_CC_Q1] IS NULL AND [Last Statement Charge Overlimit Amount_CC_Q3] IS  NULL ) THEN [Last Statement Charge Overlimit Amount_CC_Q1] else (ISNULL([Last Statement Charge Overlimit Amount_CC_Q1],0)-ISNULL([Last Statement Charge Overlimit Amount_CC_Q3],0)) end [DFT_Last Statement Charge Overlimit Amount_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Charge Overlimit Amount_CC_Q1] IS NULL AND [Last Statement Charge Overlimit Amount_CC_Q4] IS  NULL ) THEN [Last Statement Charge Overlimit Amount_CC_Q1] else (ISNULL([Last Statement Charge Overlimit Amount_CC_Q1],0)-ISNULL([Last Statement Charge Overlimit Amount_CC_Q4],0)) end [DFT_Last Statement Charge Overlimit Amount_CC_Q1_Q4]
		--,[Last Statement Charge Sale Amount_CC_Staticpool]
		,[Last Statement Charge Sale Amount_CC_Q1]
		,CASE WHEN ([Last Statement Charge Sale Amount_CC_Q1] IS NULL AND [Last Statement Charge Sale Amount_CC_Q2] IS  NULL ) THEN [Last Statement Charge Sale Amount_CC_Q1] else (ISNULL([Last Statement Charge Sale Amount_CC_Q1],0) - ISNULL([Last Statement Charge Sale Amount_CC_Q2],0)) end [DFT_Last Statement Charge Sale Amount_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Charge Sale Amount_CC_Q1] IS NULL AND [Last Statement Charge Sale Amount_CC_Q3] IS  NULL ) THEN [Last Statement Charge Sale Amount_CC_Q1] else (ISNULL([Last Statement Charge Sale Amount_CC_Q1],0) - ISNULL([Last Statement Charge Sale Amount_CC_Q3],0)) end [DFT_Last Statement Charge Sale Amount_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Charge Sale Amount_CC_Q1] IS NULL AND [Last Statement Charge Sale Amount_CC_Q4] IS  NULL ) THEN [Last Statement Charge Sale Amount_CC_Q1] else (ISNULL([Last Statement Charge Sale Amount_CC_Q1],0) - ISNULL([Last Statement Charge Sale Amount_CC_Q4],0)) end [DFT_Last Statement Charge Sale Amount_CC_Q1_Q4]
		--,[Last Statement Merchandise Average Daily Balance Amount_CC_Staticpool]
		,[Last Statement Merchandise Average Daily Balance Amount_CC_Q1]
		,CASE WHEN ([Last Statement Merchandise Average Daily Balance Amount_CC_Q1] IS NULL AND [Last Statement Merchandise Average Daily Balance Amount_CC_Q2] IS  NULL ) THEN [Last Statement Merchandise Average Daily Balance Amount_CC_Q1] else (ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_Q1],0) - ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_Q2],0)) end [DFT_Last Statement Merchandise Average Daily Balance Amount_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Merchandise Average Daily Balance Amount_CC_Q1] IS NULL AND [Last Statement Merchandise Average Daily Balance Amount_CC_Q3] IS  NULL ) THEN [Last Statement Merchandise Average Daily Balance Amount_CC_Q1] else (ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_Q1],0) - ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_Q3],0)) end [DFT_Last Statement Merchandise Average Daily Balance Amount_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Merchandise Average Daily Balance Amount_CC_Q1] IS NULL AND [Last Statement Merchandise Average Daily Balance Amount_CC_Q4] IS  NULL ) THEN [Last Statement Merchandise Average Daily Balance Amount_CC_Q1] else (ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_Q1],0) - ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_Q4],0)) end [DFT_Last Statement Merchandise Average Daily Balance Amount_CC_Q1_Q4]
		,[Last Statement Cash Average Daily Balance Amount_CC_Staticpool]
		,[Last Statement Cash Average Daily Balance Amount_CC_Q1]
		,CASE WHEN ([Last Statement Cash Average Daily Balance Amount_CC_Q1] IS NULL AND [Last Statement Cash Average Daily Balance Amount_CC_Q2] IS  NULL ) THEN [Last Statement Cash Average Daily Balance Amount_CC_Q1] else (ISNULL([Last Statement Cash Average Daily Balance Amount_CC_Q1],0)- ISNULL([Last Statement Cash Average Daily Balance Amount_CC_Q2],0)) end [DFT_Last Statement Cash Average Daily Balance Amount_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Cash Average Daily Balance Amount_CC_Q1] IS NULL AND [Last Statement Cash Average Daily Balance Amount_CC_Q3] IS  NULL ) THEN [Last Statement Cash Average Daily Balance Amount_CC_Q1] else (ISNULL([Last Statement Cash Average Daily Balance Amount_CC_Q1],0)- ISNULL([Last Statement Cash Average Daily Balance Amount_CC_Q3],0)) end [DFT_Last Statement Cash Average Daily Balance Amount_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Cash Average Daily Balance Amount_CC_Q1] IS NULL AND [Last Statement Cash Average Daily Balance Amount_CC_Q4] IS  NULL ) THEN [Last Statement Cash Average Daily Balance Amount_CC_Q1] else (ISNULL([Last Statement Cash Average Daily Balance Amount_CC_Q1],0)- ISNULL([Last Statement Cash Average Daily Balance Amount_CC_Q4],0)) end [DFT_Last Statement Cash Average Daily Balance Amount_CC_Q1_Q4]
		--,[Last Statement Average Daily Balance Amount_CC_Staticpool]
		,[Last Statement Average Daily Balance Amount_CC_Q1]
		,CASE WHEN ([Last Statement Average Daily Balance Amount_CC_Q1] IS NULL AND [Last Statement Average Daily Balance Amount_CC_Q2] IS  NULL ) THEN [Last Statement Average Daily Balance Amount_CC_Q1] else (ISNULL([Last Statement Average Daily Balance Amount_CC_Q1],0)-ISNULL([Last Statement Average Daily Balance Amount_CC_Q2],0)) end [DFT_Last Statement Average Daily Balance Amount_CC_Q1_Q2]
		,CASE WHEN ([Last Statement Average Daily Balance Amount_CC_Q1] IS NULL AND [Last Statement Average Daily Balance Amount_CC_Q3] IS  NULL ) THEN [Last Statement Average Daily Balance Amount_CC_Q1] else (ISNULL([Last Statement Average Daily Balance Amount_CC_Q1],0)-ISNULL([Last Statement Average Daily Balance Amount_CC_Q3],0)) end [DFT_Last Statement Average Daily Balance Amount_CC_Q1_Q3]
		--,CASE WHEN ([Last Statement Average Daily Balance Amount_CC_Q1] IS NULL AND [Last Statement Average Daily Balance Amount_CC_Q4] IS  NULL ) THEN [Last Statement Average Daily Balance Amount_CC_Q1] else (ISNULL([Last Statement Average Daily Balance Amount_CC_Q1],0)-ISNULL([Last Statement Average Daily Balance Amount_CC_Q4],0)) end [DFT_Last Statement Average Daily Balance Amount_CC_Q1_Q4]
		--,[spend_CC_Staticpool]
		,[spend_CC_Q1]
		,CASE WHEN ([spend_CC_Q1] IS NULL AND [spend_CC_Q2] IS  NULL ) THEN [spend_CC_Q1] else (ISNULL(spend_CC_Q1,0)- ISNULL(spend_CC_Q2,0)) end [DFT_spend_CC_Q1_Q2]
		,CASE WHEN ([spend_CC_Q1] IS NULL AND [spend_CC_Q3] IS  NULL ) THEN [spend_CC_Q1] else (ISNULL(spend_CC_Q1,0)- ISNULL(spend_CC_Q3,0)) end [DFT_spend_CC_Q1_Q3]
		--,CASE WHEN ([spend_CC_Q1] IS NULL AND [spend_CC_Q4] IS  NULL ) THEN [spend_CC_Q1] else (ISNULL(spend_CC_Q1,0)- ISNULL(spend_CC_Q4,0)) end [DFT_spend_CC_Q1_Q4]
		--,[Protected_Balance_CC_Staticpool]
		,[Protected_Balance_CC_Q1]
		,CASE WHEN ([Protected_Balance_CC_Q1] IS NULL AND [Protected_Balance_CC_Q2] IS  NULL ) THEN [Protected_Balance_CC_Q1] else (ISNULL([Protected_Balance_CC_Q1],0)-ISNULL([Protected_Balance_CC_Q2],0)) end [DFT_Protected_Balance_CC_Q1_Q2]
		,CASE WHEN ([Protected_Balance_CC_Q1] IS NULL AND [Protected_Balance_CC_Q3] IS  NULL ) THEN [Protected_Balance_CC_Q1] else (ISNULL([Protected_Balance_CC_Q1],0)-ISNULL([Protected_Balance_CC_Q3],0)) end [DFT_Protected_Balance_CC_Q1_Q3]
		--,CASE WHEN ([Protected_Balance_CC_Q1] IS NULL AND [Protected_Balance_CC_Q4] IS  NULL ) THEN [Protected_Balance_CC_Q1] else (ISNULL([Protected_Balance_CC_Q1],0)-ISNULL([Protected_Balance_CC_Q4],0)) end [DFT_Protected_Balance_CC_Q1_Q4]
		--,[Promo_Balance_CC_Staticpool]
		,[Promo_Balance_CC_Q1]
		,CASE WHEN ([Promo_Balance_CC_Q1] IS NULL AND [Promo_Balance_CC_Q2] IS  NULL ) THEN [Promo_Balance_CC_Q1] else (ISNULL([Promo_Balance_CC_Q1],0)-ISNULL([Promo_Balance_CC_Q2],0)) end [DFT_Promo_Balance_CC_Q1_Q2]
		,CASE WHEN ([Promo_Balance_CC_Q1] IS NULL AND [Promo_Balance_CC_Q3] IS  NULL ) THEN [Promo_Balance_CC_Q1] else (ISNULL([Promo_Balance_CC_Q1],0)-ISNULL([Promo_Balance_CC_Q3],0)) end [DFT_Promo_Balance_CC_Q1_Q3]
		--,CASE WHEN ([Promo_Balance_CC_Q1] IS NULL AND [Promo_Balance_CC_Q4] IS  NULL ) THEN [Promo_Balance_CC_Q1] else (ISNULL([Promo_Balance_CC_Q1],0)-ISNULL([Promo_Balance_CC_Q4],0)) end [DFT_Promo_Balance_CC_Q1_Q4]
		--,[Protected_Current_Interest_CC_Staticpool]
		,[Protected_Current_Interest_CC_Q1]
		,CASE WHEN ([Protected_Current_Interest_CC_Q1] IS NULL AND [Protected_Current_Interest_CC_Q2] IS  NULL ) THEN [Protected_Current_Interest_CC_Q1] else (ISNULL([Protected_Current_Interest_CC_Q1],0)- ISNULL([Protected_Current_Interest_CC_Q2],0)) end [DFT_Protected_Current_Interest_CC_Q1_Q2]
		,CASE WHEN ([Protected_Current_Interest_CC_Q1] IS NULL AND [Protected_Current_Interest_CC_Q3] IS  NULL ) THEN [Protected_Current_Interest_CC_Q1] else (ISNULL([Protected_Current_Interest_CC_Q1],0)- ISNULL([Protected_Current_Interest_CC_Q3],0)) end [DFT_Protected_Current_Interest_CC_Q1_Q3]
		--,CASE WHEN ([Protected_Current_Interest_CC_Q1] IS NULL AND [Protected_Current_Interest_CC_Q4] IS  NULL ) THEN [Protected_Current_Interest_CC_Q1] else (ISNULL([Protected_Current_Interest_CC_Q1],0)- ISNULL([Protected_Current_Interest_CC_Q4],0)) end [DFT_Protected_Current_Interest_CC_Q1_Q4]
		--,[Promo_Current_Interest_CC_Staticpool]
		,[Promo_Current_Interest_CC_Q1]
		,CASE WHEN ([Promo_Current_Interest_CC_Q1] IS NULL AND [Promo_Current_Interest_CC_Q2] IS  NULL ) THEN [Promo_Current_Interest_CC_Q1] else (ISNULL([Promo_Current_Interest_CC_Q1],0)- ISNULL([Promo_Current_Interest_CC_Q2],0)) end [DFT_Promo_Current_Interest_CC_Q1_Q2]
		,CASE WHEN ([Promo_Current_Interest_CC_Q1] IS NULL AND [Promo_Current_Interest_CC_Q3] IS  NULL ) THEN [Promo_Current_Interest_CC_Q1] else (ISNULL([Promo_Current_Interest_CC_Q1],0)- ISNULL([Promo_Current_Interest_CC_Q3],0)) end [DFT_Promo_Current_Interest_CC_Q1_Q3]
		--,CASE WHEN ([Promo_Current_Interest_CC_Q1] IS NULL AND [Promo_Current_Interest_CC_Q4] IS  NULL ) THEN [Promo_Current_Interest_CC_Q1] else (ISNULL([Promo_Current_Interest_CC_Q1],0)- ISNULL([Promo_Current_Interest_CC_Q4],0)) end [DFT_Promo_Current_Interest_CC_Q1_Q4]
		--,[RevolvingBalance_CC_Staticpool]
		,[RevolvingBalance_CC_Q1]
		,CASE WHEN ([RevolvingBalance_CC_Q1] IS NULL AND [RevolvingBalance_CC_Q2] IS  NULL ) THEN [RevolvingBalance_CC_Q1] else (ISNULL([RevolvingBalance_CC_Q1],0)-ISNULL([RevolvingBalance_CC_Q2],0)) end [DFT_RevolvingBalance_CC_Q1_Q2]
		,CASE WHEN ([RevolvingBalance_CC_Q1] IS NULL AND [RevolvingBalance_CC_Q3] IS  NULL ) THEN [RevolvingBalance_CC_Q1] else (ISNULL([RevolvingBalance_CC_Q1],0)-ISNULL([RevolvingBalance_CC_Q3],0)) end [DFT_RevolvingBalance_CC_Q1_Q3]
		--,CASE WHEN ([RevolvingBalance_CC_Q1] IS NULL AND [RevolvingBalance_CC_Q4] IS  NULL ) THEN [RevolvingBalance_CC_Q1] else (ISNULL([RevolvingBalance_CC_Q1],0)-ISNULL([RevolvingBalance_CC_Q4],0)) end [DFT_RevolvingBalance_CC_Q1_Q4]
		,[AVG_UTILIZATION_RATE_CC_Q1]
		,CASE WHEN ([AVG_UTILIZATION_RATE_CC_Q1] IS NULL AND [AVG_UTILIZATION_RATE_CC_Q2] IS  NULL ) THEN [AVG_UTILIZATION_RATE_CC_Q1] else (ISNULL(AVG_UTILIZATION_RATE_CC_Q1,0)- ISNULL(AVG_UTILIZATION_RATE_CC_Q2,0)) end [DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2]
		,CASE WHEN ([AVG_UTILIZATION_RATE_CC_Q1] IS NULL AND [AVG_UTILIZATION_RATE_CC_Q3] IS  NULL ) THEN [AVG_UTILIZATION_RATE_CC_Q1] else (ISNULL(AVG_UTILIZATION_RATE_CC_Q1,0)- ISNULL(AVG_UTILIZATION_RATE_CC_Q3,0)) end [DFT_AVG_UTILIZATION_RATE_CC_Q1_Q3]
		--,CASE WHEN ([AVG_UTILIZATION_RATE_CC_Q1] IS NULL AND [AVG_UTILIZATION_RATE_CC_Q4] IS  NULL ) THEN [AVG_UTILIZATION_RATE_CC_Q1] else (ISNULL(AVG_UTILIZATION_RATE_CC_Q1,0)- ISNULL(AVG_UTILIZATION_RATE_CC_Q4,0)) end [DFT_AVG_UTILIZATION_RATE_CC_Q1_Q4]

		--,[Social Security Number_CC]
		,Count_Durable_CC
		,max_credit_Limit
		,max_age_member_CC
		,[Max_Extract_ACCOUNT_OPEN_DATE_CC]
		,[Max_Closed_account_flag_CC]
		,Max_MOB_CC
		,ChargeoffAmount_final_CC
		,Max_chargoff_date_CC

		--,SSN_00
		,CL_CC_StaticPool
		,MOB_CC_staticPool
		,TRIP_FLAG_staticpool

		,(CL_CC_StaticPool-CreditLimit_CC_Q1) CL_DIFF_past_oneyear
		into #Credit_Card_data
		from 
		(
		select [Social Security Number] SSN_CC
		    
			,COUNT(DISTINCT CASE WHEN Quarters = 'Q1' THEN Durable_Key END) [PRODUCT_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q1]
			,SUM(case when Quarters='Q1' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then [spend] END) [spend_CC_Q1]
			,SUM(case when Quarters='Q1' then [Protected_Balance] END) [Protected_Balance_CC_Q1]
			,SUM(case when Quarters='Q1' then [Promo_Balance] END) [Promo_Balance_CC_Q1]
			,SUM(case when Quarters='Q1' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q1]
			,SUM(case when Quarters='Q1' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q1]
			,SUM(case when Quarters='Q1' then [RevolvingBalance] END) [RevolvingBalance_CC_Q1]
			,max(case when Quarters='Q1' then [Credit Limit] end ) [CreditLimit_CC_Q1]
			,AVG(case when Quarters='Q1' then UTILIZATION_RATE_CC END) [AVG_UTILIZATION_RATE_CC_Q1]

			,COUNT(DISTINCT CASE WHEN Quarters = 'Q2' THEN Durable_Key END) [PRODUCT_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q2]
			,SUM(case when Quarters='Q2' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then [spend] END) [spend_CC_Q2]
			,SUM(case when Quarters='Q2' then [Protected_Balance] END) [Protected_Balance_CC_Q2]
			,SUM(case when Quarters='Q2' then [Promo_Balance] END) [Promo_Balance_CC_Q2]
			,SUM(case when Quarters='Q2' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q2]
			,SUM(case when Quarters='Q2' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q2]
			,SUM(case when Quarters='Q2' then [RevolvingBalance] END) [RevolvingBalance_CC_Q2]
			,AVG(case when Quarters='Q2' then UTILIZATION_RATE_CC END) [AVG_UTILIZATION_RATE_CC_Q2]

			,COUNT(DISTINCT CASE WHEN Quarters = 'Q2' THEN Durable_Key END) [PRODUCT_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q3]
			,SUM(case when Quarters='Q3' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then [spend] END) [spend_CC_Q3]
			,SUM(case when Quarters='Q3' then [Protected_Balance] END) [Protected_Balance_CC_Q3]
			,SUM(case when Quarters='Q3' then [Promo_Balance] END) [Promo_Balance_CC_Q3]
			,SUM(case when Quarters='Q3' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q3]
			,SUM(case when Quarters='Q3' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q3]
			,SUM(case when Quarters='Q3' then [RevolvingBalance] END) [RevolvingBalance_CC_Q3]
			,AVG(case when Quarters='Q3' then UTILIZATION_RATE_CC END) [AVG_UTILIZATION_RATE_CC_Q3]

			,COUNT(DISTINCT CASE WHEN Quarters = 'Q4' THEN Durable_Key END) [PRODUCT_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q4]
			,SUM(case when Quarters='Q4' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then [spend] END) [spend_CC_Q4]
			,SUM(case when Quarters='Q4' then [Protected_Balance] END) [Protected_Balance_CC_Q4]
			,SUM(case when Quarters='Q4' then [Promo_Balance] END) [Promo_Balance_CC_Q4]
			,SUM(case when Quarters='Q4' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q4]
			,SUM(case when Quarters='Q4' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q4]
			,SUM(case when Quarters='Q4' then [RevolvingBalance] END) [RevolvingBalance_CC_Q4]
			,AVG(case when Quarters='Q4' then UTILIZATION_RATE_CC END) [AVG_UTILIZATION_RATE_CC_Q4]

			,COUNT(DISTINCT CASE WHEN Quarters = 'Staticpool' THEN Durable_Key END) [PRODUCT_CC_STATICPOOL]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Last Statement Payment Amount] END) [Last Statement Payment Amount)_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [spend] END) [spend_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Protected_Balance] END) [Protected_Balance_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Promo_Balance] END) [Promo_Balance_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [RevolvingBalance] END) [RevolvingBalance_CC_Staticpool]
			,AVG(case when Quarters='Staticpool' then UTILIZATION_RATE_CC END) [AVG_UTILIZATION_RATE_CC_Staticpool]
			
			  from #CC_data
			  group by [Social Security Number]
			  ) a

		  left join (     
					  select [Social Security Number]  [Social Security Number_CC]
							,count(distinct Durable_Key) Count_Durable_CC
							,Max([Credit Limit]) max_credit_Limit
							,max(AGE) max_age_member_CC
							,max([Extract_ACCOUNT_OPEN_DATE]) [Max_Extract_ACCOUNT_OPEN_DATE_CC]
							,max([Closed_account_flag]) [Max_Closed_account_flag_CC]
						    ,max([mob]) Max_MOB_CC
					        ,sum([ChargeoffAmount_final]) ChargeoffAmount_final_CC
						    ,max([ChargeOff_Extract_DatePart]) Max_chargoff_date_CC
						 from #CC_data
						 group by [Social Security Number]
					 ) b
					 on a.SSN_CC=b.[Social Security Number_CC]
			 left join 			
					 (
					 select [Social Security Number] SSN_00,max([Credit Limit]) CL_CC_StaticPool
					 ,max(mob) MOB_CC_staticPool
					 ,max(case when TRIPFLAG='T' then 1
					 when TRIPFLAG='R' then 2
					 when TRIPFLAG='I' then 3
					 when TRIPFLAG='P' then 4 else null end) TRIP_FLAG_staticpool from #cc_data
					 where Quarters='staticpool'
					 group by [Social Security Number]
					 ) w
			 on a.ssn_cc=w.SSN_00	
			 
			 
			 DROP TABLE IF EXISTS #loan_product_master		   

			 SELECT a.* ,b.*
			 INTO #loan_product_master
			 FROM #loan_product_summary A
			 LEFT JOIN
			 #Credit_Card_data B
			 on A.SSN001 = B.SSN_CC --157375

			 --DROP TABLE IF EXISTS #updated_loan_product_master		   

			 --SELECT CASE WHEN A.SSN_LOAN = B.SSN_CC THEN SSN_LOAN
			 --            WHEN A.SSN_LOAN IS NULL THEN B.SSN_CC
			 --		       WHEN B.SSN_CC IS NULL THEN A.SSN_LOAN END [SSN_L],
			 --A.* ,B.*
			 --INTO #updated_loan_product_master	
			 --FROM #updated_loan_product_summary A
			 --FULL OUTER JOIN
			 --#Credit_Card_data B
			 --on A.SSN_LOAN = B.SSN_CC

			 --SELECT  SSN_CC FROM  #Credit_Card_data
			 --where SSN_CC not in (SELECT SSN FROM #loan_product_summary ) --0
			 --SELECT TOP 10 * into Analytics.dbo.SNSN FROM #loan_product_master

------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** DEPOSITS ***\\\-------------------------------------------------------------------

		--	  drop table if exists #groupproducttype_Deposits  ---grouping table updated by Nikita 03/06/2022
		--select *
		--,case when productname like '%business%' or  productname like '%commercial%'
		-- or productname like '%professional%' or productcode in  ('143','5080','105','149','5013')
	 --then 1 else 0 end Businessflag 
		--into #groupproducttype_Deposits
		--from
		--	(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName,ApplicationDescription,ApplicationTableName
		--	 from [AE_EDW].[tempods].[S_CRMProductType] a
		--	left join [AE_EDW].[tempods].[S_CRMApplicationType] b
		--	on a.ApplicationTypeID=b.ApplicationTypeID
		--	where ApplicationDescription is not null and ProductName!='IRA Savings'
		--	and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a

  --       DROP TABLE IF EXISTS #ShareCategory
  --       SELECT * 
  --       INTO #ShareCategory
  --       FROM
  --       (SELECT B.*,A.Businessflag 
		-- ,CASE WHEN A.ProductName = B.ShareTypeDescription THEN 1 ELSE 0 END [Description Flag]
		-- FROM #groupproducttype_Deposits A
  --       left Join 
        --SELECT * from ARCUSYM000.ARCU.ARCUShareCategory B where ShareCategory1 = 'Consumer' and ShareCategory2 = 'savings'
  --       on A.ProductName = B.ShareTypeDescription) W
  --       where [Description Flag] = 1
  --       and ShareCategory3 not in ('IRA','HSA')

	  DROP TABLE IF EXISTS #ShareCategory
	 -- Consumer & Commercial Category in Money Market
		SELECT *
		into #ShareCategory
		FROM
		(
  		SELECT *,CASE WHEN ShareCategory2 ='Savings' and ShareCategory3='IRA' then 1 else 0 end [IRA_SAVINGS_FLAG]  
		from ARCUSYM000.ARCU.ARCUShareCategory
		) S
		where 1=1
			--and ShareCategory3 not in ('HSA','IRA') 
			and ShareCategory1 <> 'Non-Member'
			and ShareType <> '9997'   --(excluding Greenstate Corporate Checking)
			and IRA_SAVINGS_FLAG = 0
   
--    select *from #deposits_account_data order by 1 where processdate between '20220331' and '20220531'
	--select distinct saving_sub_flag from #deposits_account_data
--------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Membership Data (ShareCategorywise) ***\\\-------------------------------------------------------------------
		--DECLARE @staticpooldate date
		--set @staticpooldate = '2023-03-31'
    DROP TABLE IF EXISTS #deposits_account_data

		select SSN
		      ,UNID
			  ,ProcessDate
			  ,PARENTACCOUNT
			  ,id
			  ,TYPE
			  ,LASTDIVAMOUNT
			  ,BALANCE Month_end_balance
		      ,CHARGEOFFAMOUNT
			  ,CHARGEOFFDATE
			  ,CHARGEOFFTYPE
			  ,Closed_flag
			  ,left(ProcessDate,6) ProcessDate_v
		      ,close_date,open_date
			  ,process_date 
			  ,Quarters
			  ,MOB
			  ,
			  --,StaticPool_Saving_flag
			  CASE WHEN (ShareCategory2 = 'Savings' and ShareCategory3 not in ('IRA','HSA')) then 'Savings'
			         WHEN (ShareCategory2 = 'Checking' and ShareCategory3 not in ('IRA','HSA')) then 'Checking'
					 WHEN (ShareCategory2 = 'CD' and ShareCategory3 not in ('IRA','HSA'))  then 'Certificates'
					 WHEN (ShareCategory2 = 'Money Market' and ShareCategory3 not in ('IRA','HSA')) then 'MoneyMarket' 
					 WHEN (ShareCategory2 in ('CD','Money Market') and ShareCategory3 = 'IRA')  then 'IRA'
					 WHEN (ShareCategory2 in ('Checking','Savings') and ShareCategory3 = 'HSA')  then 'HSA'
					 ELSE 'OTHERS' END [Deposit_Flag] --GREENSTATE CORPORATE CHECKING is the only in others

			,case when ShareTypeDescription in ('BUSINESS NON-INT SAVINGS','BUSINESS SAVINGS','BUSINESS PLATINUM PLUS SAVINGS') then 'BUSINESS_SAVINGS'
				when   ShareTypeDescription in ('STUDENT BANK SAVINGS','STUDENT SAVINGS','YOUTH SAVINGS') then  'STUDENT_SAVINGS'
				when   ShareTypeDescription in ('NON-INT EARNING SAVINGS') then  'NON_INT_EARNING_SAVINGS'
				ELSE 'OTHERS' END [saving_sub_Flag]
			 
		into #deposits_account_data 
		from 
		(
		select  
		d.SSN
		,case when Process_Date in (eomonth(DATEADD(month,-12,@staticpooldate )),eomonth(DATEADD(month,-11,@staticpooldate)),eomonth(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		   when Process_Date in (eomonth(DATEADD(month,-9,@staticpooldate )),eomonth(DATEADD(month,-8,@staticpooldate)),eomonth(DATEADD(month,-7,@staticpooldate )))  then 'Q3'
		   when Process_Date in (eomonth(DATEADD(month,-6,@staticpooldate )),eomonth(DATEADD(month,-5,@staticpooldate)),eomonth(DATEADD(month,-4,@staticpooldate ))) then 'Q2'
		   when Process_Date in (eomonth(DATEADD(month,-3,@staticpooldate )),eomonth(DATEADD(month,-2,@staticpooldate)),eomonth(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		   when Process_Date in (@staticpooldate) then 'Staticpool'
		  end Quarters
		   ,DATEDIFF(MONTH,OPEN_DATE,@staticpooldate) MOB
		   --,case when ShareCategory2='savings' and Process_Date =@staticpooldate then 1 else 0 end StaticPool_Saving_flag
		,aa.*,c.Closed_flag
		,case when aa.close_date is null then '' 
		when len(month(aa.close_date))=1 then CONCAT(year(aa.close_date),0,month(aa.close_date))
		else CONCAT(year(aa.close_date),month(aa.close_date)) end  Closed_date_INT
		,case when len(month(aa.open_date))=1 then CONCAT(year(aa.open_date),0,month(aa.open_date))
		else CONCAT(year(aa.open_date),month(aa.open_date)) end  OPEN_date_INT_INT
		,E.ShareTypeDescription,E.ShareCategory2,E.ShareCategory3
		,case when ShareCategory2='CD' and BALANCE=0 then 0 else 1 end carryforward_flag ----not understood
		from 
					(select * from
							(	select *,case when [EOM_Process Date]=[Process Date] then 1 else 0 end EOM_flag 
										,case when (closedate is null and CHARGEOFFDATE is null) or ProcessDate_v=Close_date_v 
										or ProcessDate_v=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
										,case when OPEN_DATE=CLOSE_DATE then 0 else 1 end Funded_loan_flag
										,lag(Open_date,1) over (partition by Concat(parentaccount,id) order by processdate) Lag_opendate
											,lag(type,1) over (partition by Concat(parentaccount,id) order by processdate) Lag_Type
											,concat(PARENTACCOUNT,ID) UNID
										from
											(select a.*,EOMONTH([Process Date]) [EOM_Process Date]
											,case when ProcessDate_v=CHARGEOFFDATE_v then CHARGEOFFAMOUNT else 0 end CHARGEOFFAMOUNT_v
											,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
											else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date_v
											,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
											,cast(OPENDATE as date) Open_date
											,cast(CLOSEDATE as date) Close_date
											 from 
												 ( select * ,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
												 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v
												 ,left(ProcessDate,6) ProcessDate_v
												,datefromparts(left(processdate,4),right(left(processdate,6),2),right(processdate,2)) [Process Date] 
												from arcusym000.dbo.SAVINGS
												--where (chargeoffdate is null or chargeoffdate>='2021-11-01')
												) a
												 
											) F
								 ) aaa
								  where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
					 ) aa
		left join 
				(select UNID,max(closed_flag) Closed_flag
				from
						(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when CLOSEDATE is null then 0 else 1 end closed_flag
						from 
								(select distinct PARENTACCOUNT,ID,CLOSEDATE 
								from [ARCUSYM000].dbo.SAVINGS
								 where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
								 ) a 
						 )b
				group by UNID
				) c
		on aa.UNID=c.UNID
		left join #Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join #ShareCategory E
		on e.ShareType=aa.TYPE
		where Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate))
		and PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
		) ZZ
		where 1 = 1
		--and ShareCategory2 ='Savings'  
		and open_date<@staticpooldate and (close_date is null or close_date>@staticpooldate)
		and Funded_loan_flag=1 and Quarters is not null and Open_Flag=1 and carryforward_flag=1
		order by UNID,ProcessDate,TYPE

		--SELECT * FROM #deposits_account_data where Process_Date = '2021-08-31' -- 321868

		DROP TABLE IF EXISTS #membership_deposits

		SELECT A.SSN [SSN003]
		      ,PRODUCT_SAVINGS_SP [PRODUCT_SAVINGS_SP]
			  ,BUSINESS_SAVINGS_SP
			  ,NON_INT_EARNING_SAVINGS_SP
			  ,STUDENT_SAVINGS_SP
		      ,PRODUCT_SAVINGS_Q1 [PRODUCT_SAVINGS_Q1]
			  ,BUSINESS_SAVINGS_Q1
			  ,NON_INT_EARNING_SAVINGS_Q1
			  ,STUDENT_SAVINGS_Q1
			  ,CASE WHEN (PRODUCT_SAVINGS_Q1 IS NULL AND PRODUCT_SAVINGS_Q2 IS  NULL ) THEN PRODUCT_SAVINGS_Q1 else (ISNULL(PRODUCT_SAVINGS_Q1,0) - ISNULL(PRODUCT_SAVINGS_Q2,0)) end [DFT_PRODUCT_SAVINGS_Q1_Q2]
			  ,CASE WHEN (PRODUCT_SAVINGS_Q1 IS NULL AND PRODUCT_SAVINGS_Q3 IS  NULL ) THEN PRODUCT_SAVINGS_Q1 else (ISNULL(PRODUCT_SAVINGS_Q1,0) - ISNULL(PRODUCT_SAVINGS_Q3,0)) end [DFT_PRODUCT_SAVINGS_Q1_Q3]

			  ,CASE WHEN (BUSINESS_SAVINGS_Q1 IS NULL AND BUSINESS_SAVINGS_Q2 IS  NULL ) THEN BUSINESS_SAVINGS_Q1 else (ISNULL(BUSINESS_SAVINGS_Q1,0) - ISNULL(BUSINESS_SAVINGS_Q2,0)) end [DFT_BUSINESS_SAVINGS_Q1_Q2]
			  ,CASE WHEN (BUSINESS_SAVINGS_Q1 IS NULL AND BUSINESS_SAVINGS_Q3 IS  NULL ) THEN BUSINESS_SAVINGS_Q1 else (ISNULL(BUSINESS_SAVINGS_Q1,0) - ISNULL(BUSINESS_SAVINGS_Q3,0)) end [DFT_BUSINESS_SAVINGS_Q1_Q3]

			  ,CASE WHEN (NON_INT_EARNING_SAVINGS_Q1 IS NULL AND NON_INT_EARNING_SAVINGS_Q2 IS  NULL ) THEN NON_INT_EARNING_SAVINGS_Q1 else (ISNULL(NON_INT_EARNING_SAVINGS_Q1,0) - ISNULL(NON_INT_EARNING_SAVINGS_Q2,0)) end [DFT_NON_INT_EARNING_SAVINGS_Q1_Q2]
			  ,CASE WHEN (NON_INT_EARNING_SAVINGS_Q1 IS NULL AND NON_INT_EARNING_SAVINGS_Q3 IS  NULL ) THEN NON_INT_EARNING_SAVINGS_Q1 else (ISNULL(NON_INT_EARNING_SAVINGS_Q1,0) - ISNULL(NON_INT_EARNING_SAVINGS_Q3,0)) end [DFT_NON_INT_EARNING_SAVINGS_Q1_Q3]

			  ,CASE WHEN (STUDENT_SAVINGS_Q1 IS NULL AND STUDENT_SAVINGS_Q2 IS  NULL ) THEN STUDENT_SAVINGS_Q1 else (ISNULL(STUDENT_SAVINGS_Q1,0) - ISNULL(STUDENT_SAVINGS_Q2,0)) end [DFT_STUDENT_SAVINGS_Q1_Q2]
			  ,CASE WHEN (STUDENT_SAVINGS_Q1 IS NULL AND STUDENT_SAVINGS_Q3 IS  NULL ) THEN STUDENT_SAVINGS_Q1 else (ISNULL(STUDENT_SAVINGS_Q1,0) - ISNULL(STUDENT_SAVINGS_Q3,0)) end [DFT_STUDENT_SAVINGS_Q1_Q3]
			  --,CASE WHEN (PRODUCT_SAVINGS_Q1 IS NULL AND PRODUCT_SAVINGS_Q4 IS  NULL ) THEN PRODUCT_SAVINGS_Q1 else (ISNULL(PRODUCT_SAVINGS_Q1,0) - ISNULL(PRODUCT_SAVINGS_Q4,0)) end [DFT_PRODUCT_SAVINGS_Q1_Q4]
			  ,TYPE_SAVINGS_SP [TYPE_SAVINGS_SP]
			  ,TYPE_SAVINGS_Q1 [TYPE_SAVINGS_Q1]
			  ,CASE WHEN (TYPE_SAVINGS_Q1 IS NULL AND TYPE_SAVINGS_Q2 IS  NULL ) THEN TYPE_SAVINGS_Q1 else (ISNULL(TYPE_SAVINGS_Q1,0) - ISNULL(TYPE_SAVINGS_Q2,0)) end [DFT_TYPE_SAVINGS_Q1_Q2]
			  ,CASE WHEN (TYPE_SAVINGS_Q1 IS NULL AND TYPE_SAVINGS_Q3 IS  NULL ) THEN TYPE_SAVINGS_Q1 else (ISNULL(TYPE_SAVINGS_Q1,0) - ISNULL(TYPE_SAVINGS_Q3,0)) end [DFT_TYPE_SAVINGS_Q1_Q3]
			  --,CASE WHEN (TYPE_SAVINGS_Q1 IS NULL AND TYPE_SAVINGS_Q4 IS  NULL ) THEN TYPE_SAVINGS_Q1 else (ISNULL(TYPE_SAVINGS_Q1,0) - ISNULL(TYPE_SAVINGS_Q4,0)) end [DFT_TYPE_SAVINGS_Q1_Q4]		
			  ,MOB_SAVINGS
			  --,SUM_MONTH_END_BALANCE_SAVINGS_Q1
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_SAVINGS_Q1 IS NULL AND SUM_MONTH_END_BALANCE_SAVINGS_Q2 IS  NULL ) THEN SUM_MONTH_END_BALANCE_SAVINGS_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_SAVINGS_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_SAVINGS_Q2,0)) [DFT_SUM_MONTH_END_BALANCE_SAVINGS_Q1_Q2] 
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_SAVINGS_Q1 IS NULL AND SUM_MONTH_END_BALANCE_SAVINGS_Q3 IS  NULL ) THEN SUM_MONTH_END_BALANCE_SAVINGS_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_SAVINGS_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_SAVINGS_Q3,0)) [DFT_SUM_MONTH_END_BALANCE_SAVINGS_Q1_Q3]
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_SAVINGS_Q1 IS NULL AND SUM_MONTH_END_BALANCE_SAVINGS_Q4 IS  NULL ) THEN SUM_MONTH_END_BALANCE_SAVINGS_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_SAVINGS_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_SAVINGS_Q4,0)) [DFT_SUM_MONTH_END_BALANCE_SAVINGS_Q1_Q4]
			  ,AVG_MONTH_END_BALANCE_SAVINGS_Q1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_SAVINGS_Q1 IS NULL AND AVG_MONTH_END_BALANCE_SAVINGS_Q2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_SAVINGS_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_Q2,0)) end [DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2] 
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_SAVINGS_Q1 IS NULL AND AVG_MONTH_END_BALANCE_SAVINGS_Q3 IS  NULL ) THEN AVG_MONTH_END_BALANCE_SAVINGS_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_Q3,0)) end [DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3]
			  --,CASE WHEN (AVG_MONTH_END_BALANCE_SAVINGS_Q1 IS NULL AND AVG_MONTH_END_BALANCE_SAVINGS_Q4 IS  NULL ) THEN AVG_MONTH_END_BALANCE_SAVINGS_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_Q4,0)) end [DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q4]
			  ,SUM_LASTDIVAMOUNT_SAVINGS_Q1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_SAVINGS_Q1 IS NULL AND SUM_LASTDIVAMOUNT_SAVINGS_Q2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_SAVINGS_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_Q2,0)) end [DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2]
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_SAVINGS_Q1 IS NULL AND SUM_LASTDIVAMOUNT_SAVINGS_Q3 IS  NULL ) THEN SUM_LASTDIVAMOUNT_SAVINGS_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_Q3,0)) end [DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3]
			  --,CASE WHEN (SUM_LASTDIVAMOUNT_SAVINGS_Q1 IS NULL AND SUM_LASTDIVAMOUNT_SAVINGS_Q4 IS  NULL ) THEN SUM_LASTDIVAMOUNT_SAVINGS_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_Q4,0)) end [DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q4]
			  ,AVG_CHARGEOFFAMOUNT_SAVINGS_SP
			  ,AVG_CHARGEOFFAMOUNT_SAVINGS_Q1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_SAVINGS_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_SAVINGS_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_SAVINGS_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_SAVINGS_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_SAVINGS_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q2]
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_SAVINGS_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_SAVINGS_Q3 IS NULL) THEN AVG_CHARGEOFFAMOUNT_SAVINGS_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_SAVINGS_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_SAVINGS_Q3,0)) end [DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q3]
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_SAVINGS_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_SAVINGS_Q4 IS NULL) THEN AVG_CHARGEOFFAMOUNT_SAVINGS_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_SAVINGS_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_SAVINGS_Q4,0)) end [DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q4]

		      ,PRODUCT_CHECKING_SP [PRODUCT_CHECKING_SP]
		      ,PRODUCT_CHECKING_Q1 [PRODUCT_CHECKING_Q1]
			  ,CASE WHEN (PRODUCT_CHECKING_Q1 IS NULL AND PRODUCT_CHECKING_Q2 IS  NULL ) THEN PRODUCT_CHECKING_Q1 else (ISNULL(PRODUCT_CHECKING_Q1,0) - ISNULL(PRODUCT_CHECKING_Q2,0)) end [DFT_PRODUCT_CHECKING_Q1_Q2]
			  ,CASE WHEN (PRODUCT_CHECKING_Q1 IS NULL AND PRODUCT_CHECKING_Q3 IS  NULL ) THEN PRODUCT_CHECKING_Q1 else (ISNULL(PRODUCT_CHECKING_Q1,0) - ISNULL(PRODUCT_CHECKING_Q3,0)) end [DFT_PRODUCT_CHECKING_Q1_Q3]
			  --,CASE WHEN (PRODUCT_CHECKING_Q1 IS NULL AND PRODUCT_CHECKING_Q4 IS  NULL ) THEN PRODUCT_CHECKING_Q1 else (ISNULL(PRODUCT_CHECKING_Q1,0) - ISNULL(PRODUCT_CHECKING_Q4,0)) end [DFT_PRODUCT_CHECKING_Q1_Q4]
			  ,TYPE_CHECKING_SP[TYPE_CHECKING_SP]
			  ,TYPE_CHECKING_Q1 [TYPE_CHECKING_Q1]
			  ,CASE WHEN (TYPE_CHECKING_Q1 IS NULL AND TYPE_CHECKING_Q2 IS  NULL ) THEN TYPE_CHECKING_Q1 else (ISNULL(TYPE_CHECKING_Q1,0) - ISNULL(TYPE_CHECKING_Q2,0)) end [DFT_TYPE_CHECKING_Q1_Q2]
			  ,CASE WHEN (TYPE_CHECKING_Q1 IS NULL AND TYPE_CHECKING_Q3 IS  NULL ) THEN TYPE_CHECKING_Q1 else (ISNULL(TYPE_CHECKING_Q1,0) - ISNULL(TYPE_CHECKING_Q3,0)) end [DFT_TYPE_CHECKING_Q1_Q3]
			  --,CASE WHEN (TYPE_CHECKING_Q1 IS NULL AND TYPE_CHECKING_Q4 IS  NULL ) THEN TYPE_CHECKING_Q1 else (ISNULL(TYPE_CHECKING_Q1,0) - ISNULL(TYPE_CHECKING_Q4,0)) end [DFT_TYPE_CHECKING_Q1_Q4]		
			  ,MOB_CHECKING
			  --,SUM_MONTH_END_BALANCE_CHECKING_Q1
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_CHECKING_Q1 IS NULL AND SUM_MONTH_END_BALANCE_CHECKING_Q2 IS  NULL ) THEN SUM_MONTH_END_BALANCE_CHECKING_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_CHECKING_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_CHECKING_Q2,0)) [DFT_SUM_MONTH_END_BALANCE_CHECKING_Q1_Q2] 
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_CHECKING_Q1 IS NULL AND SUM_MONTH_END_BALANCE_CHECKING_Q3 IS  NULL ) THEN SUM_MONTH_END_BALANCE_CHECKING_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_CHECKING_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_CHECKING_Q3,0)) [DFT_SUM_MONTH_END_BALANCE_CHECKING_Q1_Q3]
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_CHECKING_Q1 IS NULL AND SUM_MONTH_END_BALANCE_CHECKING_Q4 IS  NULL ) THEN SUM_MONTH_END_BALANCE_CHECKING_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_CHECKING_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_CHECKING_Q4,0)) [DFT_SUM_MONTH_END_BALANCE_CHECKING_Q1_Q4]
			  ,AVG_MONTH_END_BALANCE_CHECKING_Q1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_CHECKING_Q1 IS NULL AND AVG_MONTH_END_BALANCE_CHECKING_Q2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_CHECKING_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_CHECKING_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_CHECKING_Q2,0)) end [DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2] 
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_CHECKING_Q1 IS NULL AND AVG_MONTH_END_BALANCE_CHECKING_Q3 IS  NULL ) THEN AVG_MONTH_END_BALANCE_CHECKING_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_CHECKING_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_CHECKING_Q3,0)) end [DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3]
			  --,CASE WHEN (AVG_MONTH_END_BALANCE_CHECKING_Q1 IS NULL AND AVG_MONTH_END_BALANCE_CHECKING_Q4 IS  NULL ) THEN AVG_MONTH_END_BALANCE_CHECKING_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_CHECKING_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_CHECKING_Q4,0)) end [DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q4]
			  ,SUM_LASTDIVAMOUNT_CHECKING_Q1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_CHECKING_Q1 IS NULL AND SUM_LASTDIVAMOUNT_CHECKING_Q2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_CHECKING_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_CHECKING_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_CHECKING_Q2,0)) end [DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2]
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_CHECKING_Q1 IS NULL AND SUM_LASTDIVAMOUNT_CHECKING_Q3 IS  NULL ) THEN SUM_LASTDIVAMOUNT_CHECKING_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_CHECKING_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_CHECKING_Q3,0)) end [DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q3]
			  --,CASE WHEN (SUM_LASTDIVAMOUNT_CHECKING_Q1 IS NULL AND SUM_LASTDIVAMOUNT_CHECKING_Q4 IS  NULL ) THEN SUM_LASTDIVAMOUNT_CHECKING_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_CHECKING_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_CHECKING_Q4,0)) end [DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q4]
			  ,AVG_CHARGEOFFAMOUNT_CHECKING_SP
			  ,AVG_CHARGEOFFAMOUNT_CHECKING_Q1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_CHECKING_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_CHECKING_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_CHECKING_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_CHECKING_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_CHECKING_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q2]
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_CHECKING_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_CHECKING_Q3 IS NULL) THEN AVG_CHARGEOFFAMOUNT_CHECKING_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_CHECKING_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_CHECKING_Q3,0)) end [DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q3]
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_CHECKING_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_CHECKING_Q4 IS NULL) THEN AVG_CHARGEOFFAMOUNT_CHECKING_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_CHECKING_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_CHECKING_Q4,0)) end [DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q4]

		      ,PRODUCT_CERTIFICATES_SP [PRODUCT_CERTIFICATES_SP]
		      ,PRODUCT_CERTIFICATES_Q1 [PRODUCT_CERTIFICATES_Q1]
			  ,CASE WHEN (PRODUCT_CERTIFICATES_Q1 IS NULL AND PRODUCT_CERTIFICATES_Q2 IS  NULL ) THEN PRODUCT_CERTIFICATES_Q1 else (ISNULL(PRODUCT_CERTIFICATES_Q1,0) - ISNULL(PRODUCT_CERTIFICATES_Q2,0)) end [DFT_PRODUCT_CERTIFICATES_Q1_Q2]
			  ,CASE WHEN (PRODUCT_CERTIFICATES_Q1 IS NULL AND PRODUCT_CERTIFICATES_Q3 IS  NULL ) THEN PRODUCT_CERTIFICATES_Q1 else (ISNULL(PRODUCT_CERTIFICATES_Q1,0) - ISNULL(PRODUCT_CERTIFICATES_Q3,0)) end [DFT_PRODUCT_CERTIFICATES_Q1_Q3]
			  --,CASE WHEN (PRODUCT_CERTIFICATES_Q1 IS NULL AND PRODUCT_CERTIFICATES_Q4 IS  NULL ) THEN PRODUCT_CERTIFICATES_Q1 else (ISNULL(PRODUCT_CERTIFICATES_Q1,0) - ISNULL(PRODUCT_CERTIFICATES_Q4,0)) end [DFT_PRODUCT_CERTIFICATES_Q1_Q4]
			  ,TYPE_CERTIFICATES_SP [TYPE_CERTIFICATES_SP]
			  ,TYPE_CERTIFICATES_Q1 [TYPE_CERTIFICATES_Q1]
			  ,CASE WHEN (TYPE_CERTIFICATES_Q1 IS NULL AND TYPE_CERTIFICATES_Q2 IS  NULL ) THEN TYPE_CERTIFICATES_Q1 else (ISNULL(TYPE_CERTIFICATES_Q1,0) - ISNULL(TYPE_CERTIFICATES_Q2,0)) end [DFT_TYPE_CERTIFICATES_Q1_Q2]
			  ,CASE WHEN (TYPE_CERTIFICATES_Q1 IS NULL AND TYPE_CERTIFICATES_Q3 IS  NULL ) THEN TYPE_CERTIFICATES_Q1 else (ISNULL(TYPE_CERTIFICATES_Q1,0) - ISNULL(TYPE_CERTIFICATES_Q3,0)) end [DFT_TYPE_CERTIFICATES_Q1_Q3]
			  --,CASE WHEN (TYPE_CERTIFICATES_Q1 IS NULL AND TYPE_CERTIFICATES_Q4 IS  NULL ) THEN TYPE_CERTIFICATES_Q1 else (ISNULL(TYPE_CERTIFICATES_Q1,0) - ISNULL(TYPE_CERTIFICATES_Q4,0)) end [DFT_TYPE_CERTIFICATES_Q1_Q4]		
			  ,MOB_CERTIFICATES
			  --,SUM_MONTH_END_BALANCE_CERTIFICATES_Q1
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_CERTIFICATES_Q1 IS NULL AND SUM_MONTH_END_BALANCE_CERTIFICATES_Q2 IS  NULL ) THEN SUM_MONTH_END_BALANCE_CERTIFICATES_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_CERTIFICATES_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_CERTIFICATES_Q2,0)) [DFT_SUM_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2] 
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_CERTIFICATES_Q1 IS NULL AND SUM_MONTH_END_BALANCE_CERTIFICATES_Q3 IS  NULL ) THEN SUM_MONTH_END_BALANCE_CERTIFICATES_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_CERTIFICATES_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_CERTIFICATES_Q3,0)) [DFT_SUM_MONTH_END_BALANCE_CERTIFICATES_Q1_Q3]
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_CERTIFICATES_Q1 IS NULL AND SUM_MONTH_END_BALANCE_CERTIFICATES_Q4 IS  NULL ) THEN SUM_MONTH_END_BALANCE_CERTIFICATES_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_CERTIFICATES_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_CERTIFICATES_Q4,0)) [DFT_SUM_MONTH_END_BALANCE_CERTIFICATES_Q1_Q4]
			  ,AVG_MONTH_END_BALANCE_CERTIFICATES_Q1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_CERTIFICATES_Q1 IS NULL AND AVG_MONTH_END_BALANCE_CERTIFICATES_Q2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_CERTIFICATES_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_Q2,0)) end [DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2] 
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_CERTIFICATES_Q1 IS NULL AND AVG_MONTH_END_BALANCE_CERTIFICATES_Q3 IS  NULL ) THEN AVG_MONTH_END_BALANCE_CERTIFICATES_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_Q3,0)) end [DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q3]
			  --,CASE WHEN (AVG_MONTH_END_BALANCE_CERTIFICATES_Q1 IS NULL AND AVG_MONTH_END_BALANCE_CERTIFICATES_Q4 IS  NULL ) THEN AVG_MONTH_END_BALANCE_CERTIFICATES_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_Q4,0)) end [DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q4]
			  ,SUM_LASTDIVAMOUNT_CERTIFICATES_Q1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_CERTIFICATES_Q1 IS NULL AND SUM_LASTDIVAMOUNT_CERTIFICATES_Q2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_CERTIFICATES_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_Q2,0)) end [DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q2]
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_CERTIFICATES_Q1 IS NULL AND SUM_LASTDIVAMOUNT_CERTIFICATES_Q3 IS  NULL ) THEN SUM_LASTDIVAMOUNT_CERTIFICATES_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_Q3,0)) end [DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q3]
			  --,CASE WHEN (SUM_LASTDIVAMOUNT_CERTIFICATES_Q1 IS NULL AND SUM_LASTDIVAMOUNT_CERTIFICATES_Q4 IS  NULL ) THEN SUM_LASTDIVAMOUNT_CERTIFICATES_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_Q4,0)) end [DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q4]
			  ,AVG_CHARGEOFFAMOUNT_CERTIFICATES_SP
			  ,AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q2]
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q3 IS NULL) THEN AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q3,0)) end [DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q3]
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q4 IS NULL) THEN AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q4,0)) end [DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q4]

		      ,PRODUCT_MONEYMARKET_SP [PRODUCT_MONEYMARKET_SP]
		      ,PRODUCT_MONEYMARKET_Q1 [PRODUCT_MONEYMARKET_Q1]
			  ,CASE WHEN (PRODUCT_MONEYMARKET_Q1 IS NULL AND PRODUCT_MONEYMARKET_Q2 IS  NULL ) THEN PRODUCT_MONEYMARKET_Q1 else (ISNULL(PRODUCT_MONEYMARKET_Q1,0) - ISNULL(PRODUCT_MONEYMARKET_Q2,0)) end [DFT_PRODUCT_MONEYMARKET_Q1_Q2]
			  ,CASE WHEN (PRODUCT_MONEYMARKET_Q1 IS NULL AND PRODUCT_MONEYMARKET_Q3 IS  NULL ) THEN PRODUCT_MONEYMARKET_Q1 else (ISNULL(PRODUCT_MONEYMARKET_Q1,0) - ISNULL(PRODUCT_MONEYMARKET_Q3,0)) end [DFT_PRODUCT_MONEYMARKET_Q1_Q3]
			  --,CASE WHEN (PRODUCT_MONEYMARKET_Q1 IS NULL AND PRODUCT_MONEYMARKET_Q4 IS  NULL ) THEN PRODUCT_MONEYMARKET_Q1 else (ISNULL(PRODUCT_MONEYMARKET_Q1,0) - ISNULL(PRODUCT_MONEYMARKET_Q4,0)) end [DFT_PRODUCT_MONEYMARKET_Q1_Q4]
			  ,TYPE_MONEYMARKET_SP [TYPE_MONEYMARKET_SP]
			  ,TYPE_MONEYMARKET_Q1 [TYPE_MONEYMARKET_Q1]
			  ,CASE WHEN (TYPE_MONEYMARKET_Q1 IS NULL AND TYPE_MONEYMARKET_Q2 IS  NULL ) THEN TYPE_MONEYMARKET_Q1 else (ISNULL(TYPE_MONEYMARKET_Q1,0) - ISNULL(TYPE_MONEYMARKET_Q2,0)) end [DFT_TYPE_MONEYMARKET_Q1_Q2]
			  ,CASE WHEN (TYPE_MONEYMARKET_Q1 IS NULL AND TYPE_MONEYMARKET_Q3 IS  NULL ) THEN TYPE_MONEYMARKET_Q1 else (ISNULL(TYPE_MONEYMARKET_Q1,0) - ISNULL(TYPE_MONEYMARKET_Q3,0)) end [DFT_TYPE_MONEYMARKET_Q1_Q3]
			  --,CASE WHEN (TYPE_MONEYMARKET_Q1 IS NULL AND TYPE_MONEYMARKET_Q4 IS  NULL ) THEN TYPE_MONEYMARKET_Q1 else (ISNULL(TYPE_MONEYMARKET_Q1,0) - ISNULL(TYPE_MONEYMARKET_Q4,0)) end [DFT_TYPE_MONEYMARKET_Q1_Q4]		
			  ,MOB_MONEYMARKET
			  --,SUM_MONTH_END_BALANCE_MONEYMARKET_Q1
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_MONEYMARKET_Q1 IS NULL AND SUM_MONTH_END_BALANCE_MONEYMARKET_Q2 IS  NULL ) THEN SUM_MONTH_END_BALANCE_MONEYMARKET_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_MONEYMARKET_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_MONEYMARKET_Q2,0)) [DFT_SUM_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2] 
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_MONEYMARKET_Q1 IS NULL AND SUM_MONTH_END_BALANCE_MONEYMARKET_Q3 IS  NULL ) THEN SUM_MONTH_END_BALANCE_MONEYMARKET_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_MONEYMARKET_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_MONEYMARKET_Q3,0)) [DFT_SUM_MONTH_END_BALANCE_MONEYMARKET_Q1_Q3]
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_MONEYMARKET_Q1 IS NULL AND SUM_MONTH_END_BALANCE_MONEYMARKET_Q4 IS  NULL ) THEN SUM_MONTH_END_BALANCE_MONEYMARKET_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_MONEYMARKET_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_MONEYMARKET_Q4,0)) [DFT_SUM_MONTH_END_BALANCE_MONEYMARKET_Q1_Q4]
			  ,AVG_MONTH_END_BALANCE_MONEYMARKET_Q1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_MONEYMARKET_Q1 IS NULL AND AVG_MONTH_END_BALANCE_MONEYMARKET_Q2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_MONEYMARKET_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_Q2,0)) end [DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2] 
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_MONEYMARKET_Q1 IS NULL AND AVG_MONTH_END_BALANCE_MONEYMARKET_Q3 IS  NULL ) THEN AVG_MONTH_END_BALANCE_MONEYMARKET_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_Q3,0)) end [DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q3]
			  --,CASE WHEN (AVG_MONTH_END_BALANCE_MONEYMARKET_Q1 IS NULL AND AVG_MONTH_END_BALANCE_MONEYMARKET_Q4 IS  NULL ) THEN AVG_MONTH_END_BALANCE_MONEYMARKET_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_Q4,0)) end [DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q4]
			  ,SUM_LASTDIVAMOUNT_MONEYMARKET_Q1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 IS NULL AND SUM_LASTDIVAMOUNT_MONEYMARKET_Q2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q2,0)) end [DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2]
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 IS NULL AND SUM_LASTDIVAMOUNT_MONEYMARKET_Q3 IS  NULL ) THEN SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q3,0)) end [DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q3]
			  --,CASE WHEN (SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 IS NULL AND SUM_LASTDIVAMOUNT_MONEYMARKET_Q4 IS  NULL ) THEN SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q4,0)) end [DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q4]
			  ,AVG_CHARGEOFFAMOUNT_MONEYMARKET_SP
			  ,AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1_Q2]
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q3 IS NULL) THEN AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q3,0)) end [DFT_AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1_Q3]
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q4 IS NULL) THEN AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q4,0)) end [DFT_AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1_Q4]

		      ,PRODUCT_IRA_SP [PRODUCT_IRA_SP]
		      ,PRODUCT_IRA_Q1 [PRODUCT_IRA_Q1]
			  ,CASE WHEN (PRODUCT_IRA_Q1 IS NULL AND PRODUCT_IRA_Q2 IS  NULL ) THEN PRODUCT_IRA_Q1 else (ISNULL(PRODUCT_IRA_Q1,0) - ISNULL(PRODUCT_IRA_Q2,0)) end [DFT_PRODUCT_IRA_Q1_Q2]
			  ,CASE WHEN (PRODUCT_IRA_Q1 IS NULL AND PRODUCT_IRA_Q3 IS  NULL ) THEN PRODUCT_IRA_Q1 else (ISNULL(PRODUCT_IRA_Q1,0) - ISNULL(PRODUCT_IRA_Q3,0)) end [DFT_PRODUCT_IRA_Q1_Q3]
			  --,CASE WHEN (PRODUCT_IRA_Q1 IS NULL AND PRODUCT_IRA_Q4 IS  NULL ) THEN PRODUCT_IRA_Q1 else (ISNULL(PRODUCT_IRA_Q1,0) - ISNULL(PRODUCT_IRA_Q4,0)) end [DFT_PRODUCT_IRA_Q1_Q4]
			  ,TYPE_IRA_SP [TYPE_IRA_SP]
			  ,TYPE_IRA_Q1 [TYPE_IRA_Q1]
			  ,CASE WHEN (TYPE_IRA_Q1 IS NULL AND TYPE_IRA_Q2 IS  NULL ) THEN TYPE_IRA_Q1 else (ISNULL(TYPE_IRA_Q1,0) - ISNULL(TYPE_IRA_Q2,0)) end [DFT_TYPE_IRA_Q1_Q2]
			  ,CASE WHEN (TYPE_IRA_Q1 IS NULL AND TYPE_IRA_Q3 IS  NULL ) THEN TYPE_IRA_Q1 else (ISNULL(TYPE_IRA_Q1,0) - ISNULL(TYPE_IRA_Q3,0)) end [DFT_TYPE_IRA_Q1_Q3]
			  --,CASE WHEN (TYPE_IRA_Q1 IS NULL AND TYPE_IRA_Q4 IS  NULL ) THEN TYPE_IRA_Q1 else (ISNULL(TYPE_IRA_Q1,0) - ISNULL(TYPE_IRA_Q4,0)) end [DFT_TYPE_IRA_Q1_Q4]		
			  ,MOB_IRA
			  --,SUM_MONTH_END_BALANCE_IRA_Q1
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_IRA_Q1 IS NULL AND SUM_MONTH_END_BALANCE_IRA_Q2 IS  NULL ) THEN SUM_MONTH_END_BALANCE_IRA_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_IRA_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_IRA_Q2,0)) [DFT_SUM_MONTH_END_BALANCE_IRA_Q1_Q2] 
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_IRA_Q1 IS NULL AND SUM_MONTH_END_BALANCE_IRA_Q3 IS  NULL ) THEN SUM_MONTH_END_BALANCE_IRA_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_IRA_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_IRA_Q3,0)) [DFT_SUM_MONTH_END_BALANCE_IRA_Q1_Q3]
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_IRA_Q1 IS NULL AND SUM_MONTH_END_BALANCE_IRA_Q4 IS  NULL ) THEN SUM_MONTH_END_BALANCE_IRA_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_IRA_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_IRA_Q4,0)) [DFT_SUM_MONTH_END_BALANCE_IRA_Q1_Q4]
			  ,AVG_MONTH_END_BALANCE_IRA_Q1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_IRA_Q1 IS NULL AND AVG_MONTH_END_BALANCE_IRA_Q2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_IRA_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_IRA_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_IRA_Q2,0)) end [DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q2] 
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_IRA_Q1 IS NULL AND AVG_MONTH_END_BALANCE_IRA_Q3 IS  NULL ) THEN AVG_MONTH_END_BALANCE_IRA_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_IRA_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_IRA_Q3,0)) end [DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q3]
			  --,CASE WHEN (AVG_MONTH_END_BALANCE_IRA_Q1 IS NULL AND AVG_MONTH_END_BALANCE_IRA_Q4 IS  NULL ) THEN AVG_MONTH_END_BALANCE_IRA_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_IRA_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_IRA_Q4,0)) end [DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q4]
			  ,SUM_LASTDIVAMOUNT_IRA_Q1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_IRA_Q1 IS NULL AND SUM_LASTDIVAMOUNT_IRA_Q2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_IRA_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_IRA_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_IRA_Q2,0)) end [DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q2]
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_IRA_Q1 IS NULL AND SUM_LASTDIVAMOUNT_IRA_Q3 IS  NULL ) THEN SUM_LASTDIVAMOUNT_IRA_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_IRA_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_IRA_Q3,0)) end [DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q3]
			  --,CASE WHEN (SUM_LASTDIVAMOUNT_IRA_Q1 IS NULL AND SUM_LASTDIVAMOUNT_IRA_Q4 IS  NULL ) THEN SUM_LASTDIVAMOUNT_IRA_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_IRA_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_IRA_Q4,0)) end [DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q4]
			  --,AVG_CHARGEOFFAMOUNT_IRA_SP
			  ,AVG_CHARGEOFFAMOUNT_IRA_Q1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_IRA_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_IRA_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_IRA_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_IRA_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_IRA_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_IRA_Q1_Q2]
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_IRA_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_IRA_Q3 IS NULL) THEN AVG_CHARGEOFFAMOUNT_IRA_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_IRA_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_IRA_Q3,0)) end [DFT_AVG_CHARGEOFFAMOUNT_IRA_Q1_Q3]
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_IRA_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_IRA_Q4 IS NULL) THEN AVG_CHARGEOFFAMOUNT_IRA_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_IRA_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_IRA_Q4,0)) end [DFT_AVG_CHARGEOFFAMOUNT_IRA_Q1_Q4]

		      ,PRODUCT_HSA_SP [PRODUCT_HSA_SP]
		      ,PRODUCT_HSA_Q1 [PRODUCT_HSA_Q1]
			  ,CASE WHEN (PRODUCT_HSA_Q1 IS NULL AND PRODUCT_HSA_Q2 IS  NULL ) THEN PRODUCT_HSA_Q1 else (ISNULL(PRODUCT_HSA_Q1,0) - ISNULL(PRODUCT_HSA_Q2,0)) end [DFT_PRODUCT_HSA_Q1_Q2]
			  ,CASE WHEN (PRODUCT_HSA_Q1 IS NULL AND PRODUCT_HSA_Q3 IS  NULL ) THEN PRODUCT_HSA_Q1 else (ISNULL(PRODUCT_HSA_Q1,0) - ISNULL(PRODUCT_HSA_Q3,0)) end [DFT_PRODUCT_HSA_Q1_Q3]
			  --,CASE WHEN (PRODUCT_HSA_Q1 IS NULL AND PRODUCT_HSA_Q4 IS  NULL ) THEN PRODUCT_HSA_Q1 else (ISNULL(PRODUCT_HSA_Q1,0) - ISNULL(PRODUCT_HSA_Q4,0)) end [DFT_PRODUCT_HSA_Q1_Q4]
			  ,TYPE_HSA_SP [TYPE_HSA_SP]
			  ,TYPE_HSA_Q1 [TYPE_HSA_Q1]
			  ,CASE WHEN (TYPE_HSA_Q1 IS NULL AND TYPE_HSA_Q2 IS  NULL ) THEN TYPE_HSA_Q1 else (ISNULL(TYPE_HSA_Q1,0) - ISNULL(TYPE_HSA_Q2,0)) end [DFT_TYPE_HSA_Q1_Q2]
			  ,CASE WHEN (TYPE_HSA_Q1 IS NULL AND TYPE_HSA_Q3 IS  NULL ) THEN TYPE_HSA_Q1 else (ISNULL(TYPE_HSA_Q1,0) - ISNULL(TYPE_HSA_Q3,0)) end [DFT_TYPE_HSA_Q1_Q3]
			  --,CASE WHEN (TYPE_HSA_Q1 IS NULL AND TYPE_HSA_Q4 IS  NULL ) THEN TYPE_HSA_Q1 else (ISNULL(TYPE_HSA_Q1,0) - ISNULL(TYPE_HSA_Q4,0)) end [DFT_TYPE_HSA_Q1_Q4]		
			  ,MOB_HSA
			  --,SUM_MONTH_END_BALANCE_HSA_Q1
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_HSA_Q1 IS NULL AND SUM_MONTH_END_BALANCE_HSA_Q2 IS  NULL ) THEN SUM_MONTH_END_BALANCE_HSA_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_HSA_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_HSA_Q2,0)) [DFT_SUM_MONTH_END_BALANCE_HSA_Q1_Q2] 
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_HSA_Q1 IS NULL AND SUM_MONTH_END_BALANCE_HSA_Q3 IS  NULL ) THEN SUM_MONTH_END_BALANCE_HSA_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_HSA_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_HSA_Q3,0)) [DFT_SUM_MONTH_END_BALANCE_HSA_Q1_Q3]
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_HSA_Q1 IS NULL AND SUM_MONTH_END_BALANCE_HSA_Q4 IS  NULL ) THEN SUM_MONTH_END_BALANCE_HSA_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_HSA_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_HSA_Q4,0)) [DFT_SUM_MONTH_END_BALANCE_HSA_Q1_Q4]
			  ,AVG_MONTH_END_BALANCE_HSA_Q1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_HSA_Q1 IS NULL AND AVG_MONTH_END_BALANCE_HSA_Q2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_HSA_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_HSA_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_HSA_Q2,0)) end [DFT_AVG_MONTH_END_BALANCE_HSA_Q1_Q2] 
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_HSA_Q1 IS NULL AND AVG_MONTH_END_BALANCE_HSA_Q3 IS  NULL ) THEN AVG_MONTH_END_BALANCE_HSA_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_HSA_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_HSA_Q3,0)) end [DFT_AVG_MONTH_END_BALANCE_HSA_Q1_Q3]
			  --,CASE WHEN (AVG_MONTH_END_BALANCE_HSA_Q1 IS NULL AND AVG_MONTH_END_BALANCE_HSA_Q4 IS  NULL ) THEN AVG_MONTH_END_BALANCE_HSA_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_HSA_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_HSA_Q4,0)) end [DFT_AVG_MONTH_END_BALANCE_HSA_Q1_Q4]
			  ,SUM_LASTDIVAMOUNT_HSA_Q1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_HSA_Q1 IS NULL AND SUM_LASTDIVAMOUNT_HSA_Q2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_HSA_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_HSA_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_HSA_Q2,0)) end [DFT_SUM_LASTDIVAMOUNT_HSA_Q1_Q2]
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_HSA_Q1 IS NULL AND SUM_LASTDIVAMOUNT_HSA_Q3 IS  NULL ) THEN SUM_LASTDIVAMOUNT_HSA_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_HSA_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_HSA_Q3,0)) end [DFT_SUM_LASTDIVAMOUNT_HSA_Q1_Q3]
			  --,CASE WHEN (SUM_LASTDIVAMOUNT_HSA_Q1 IS NULL AND SUM_LASTDIVAMOUNT_HSA_Q4 IS  NULL ) THEN SUM_LASTDIVAMOUNT_HSA_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_HSA_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_HSA_Q4,0)) end [DFT_SUM_LASTDIVAMOUNT_HSA_Q1_Q4]
			  --,AVG_CHARGEOFFAMOUNT_HSA_SP
			  ,AVG_CHARGEOFFAMOUNT_HSA_Q1
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_HSA_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_HSA_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_HSA_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_HSA_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_HSA_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_HSA_Q1_Q2]
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_HSA_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_HSA_Q3 IS NULL) THEN AVG_CHARGEOFFAMOUNT_HSA_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_HSA_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_HSA_Q3,0)) end [DFT_AVG_CHARGEOFFAMOUNT_HSA_Q1_Q3]
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_HSA_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_HSA_Q4 IS NULL) THEN AVG_CHARGEOFFAMOUNT_HSA_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_HSA_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_HSA_Q4,0)) end [DFT_AVG_CHARGEOFFAMOUNT_HSA_Q1_Q4]

		      ,PRODUCT_DEPOSITS_SP [PRODUCT_DEPOSITS_SP]
		      ,PRODUCT_DEPOSITS_Q1 [PRODUCT_DEPOSITS_Q1]
			  ,CASE WHEN (PRODUCT_DEPOSITS_Q1 IS NULL AND PRODUCT_DEPOSITS_Q2 IS  NULL ) THEN PRODUCT_DEPOSITS_Q1 else (ISNULL(PRODUCT_DEPOSITS_Q1,0) - ISNULL(PRODUCT_DEPOSITS_Q2,0)) end [DFT_PRODUCT_DEPOSITS_Q1_Q2]
			  ,CASE WHEN (PRODUCT_DEPOSITS_Q1 IS NULL AND PRODUCT_DEPOSITS_Q3 IS  NULL ) THEN PRODUCT_DEPOSITS_Q1 else (ISNULL(PRODUCT_DEPOSITS_Q1,0) - ISNULL(PRODUCT_DEPOSITS_Q3,0)) end [DFT_PRODUCT_DEPOSITS_Q1_Q3]
			  --,CASE WHEN (PRODUCT_DEPOSITS_Q1 IS NULL AND PRODUCT_DEPOSITS_Q4 IS  NULL ) THEN PRODUCT_DEPOSITS_Q1 else (ISNULL(PRODUCT_DEPOSITS_Q1,0) - ISNULL(PRODUCT_DEPOSITS_Q4,0)) end [DFT_PRODUCT_DEPOSITS_Q1_Q4]
			  --,ISNULL(TYPE_DEPOSITS_SP,0) [TYPE_DEPOSITS_SP]
			  ,TYPE_DEPOSITS_Q1 [TYPE_DEPOSITS_Q1]
			  ,CASE WHEN (TYPE_DEPOSITS_Q1 IS NULL AND TYPE_DEPOSITS_Q2 IS  NULL ) THEN TYPE_DEPOSITS_Q1 else (ISNULL(TYPE_DEPOSITS_Q1,0) - ISNULL(TYPE_DEPOSITS_Q2,0)) end [DFT_TYPE_DEPOSITS_Q1_Q2]
			  ,CASE WHEN (TYPE_DEPOSITS_Q1 IS NULL AND TYPE_DEPOSITS_Q3 IS  NULL ) THEN TYPE_DEPOSITS_Q1 else (ISNULL(TYPE_DEPOSITS_Q1,0) - ISNULL(TYPE_DEPOSITS_Q3,0)) end [DFT_TYPE_DEPOSITS_Q1_Q3]
			  --,CASE WHEN (TYPE_DEPOSITS_Q1 IS NULL AND TYPE_DEPOSITS_Q4 IS  NULL ) THEN TYPE_DEPOSITS_Q1 else (ISNULL(TYPE_DEPOSITS_Q1,0) - ISNULL(TYPE_DEPOSITS_Q4,0)) end [DFT_TYPE_DEPOSITS_Q1_Q4]		
			  ,MOB_DEPOSITS
			  --,SUM_MONTH_END_BALANCE_DEPOSITS_Q1
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_DEPOSITS_Q1 IS NULL AND SUM_MONTH_END_BALANCE_DEPOSITS_Q2 IS  NULL ) THEN SUM_MONTH_END_BALANCE_DEPOSITS_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_DEPOSITS_Q2,0)) [DFT_SUM_MONTH_END_BALANCE_DEPOSITS_Q1_Q2] 
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_DEPOSITS_Q1 IS NULL AND SUM_MONTH_END_BALANCE_DEPOSITS_Q3 IS  NULL ) THEN SUM_MONTH_END_BALANCE_DEPOSITS_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_DEPOSITS_Q3,0)) [DFT_SUM_MONTH_END_BALANCE_DEPOSITS_Q1_Q3]
			  --,CASE WHEN (SUM_MONTH_END_BALANCE_DEPOSITS_Q1 IS NULL AND SUM_MONTH_END_BALANCE_DEPOSITS_Q4 IS  NULL ) THEN SUM_MONTH_END_BALANCE_DEPOSITS_Q1 else (ISNULL(SUM_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_DEPOSITS_Q4,0)) [DFT_SUM_MONTH_END_BALANCE_DEPOSITS_Q1_Q4]
			  ,AVG_MONTH_END_BALANCE_DEPOSITS_Q1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_DEPOSITS_Q1 IS NULL AND AVG_MONTH_END_BALANCE_DEPOSITS_Q2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_DEPOSITS_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q2,0)) end [DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2] 
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_DEPOSITS_Q1 IS NULL AND AVG_MONTH_END_BALANCE_DEPOSITS_Q3 IS  NULL ) THEN AVG_MONTH_END_BALANCE_DEPOSITS_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q3,0)) end [DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3]
			  --,CASE WHEN (AVG_MONTH_END_BALANCE_DEPOSITS_Q1 IS NULL AND AVG_MONTH_END_BALANCE_DEPOSITS_Q4 IS  NULL ) THEN AVG_MONTH_END_BALANCE_DEPOSITS_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q4,0)) end [DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q4]
			  ,SUM_LASTDIVAMOUNT_DEPOSITS_Q1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_DEPOSITS_Q1 IS NULL AND SUM_LASTDIVAMOUNT_DEPOSITS_Q2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_DEPOSITS_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_Q2,0)) end [DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2]
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_DEPOSITS_Q1 IS NULL AND SUM_LASTDIVAMOUNT_DEPOSITS_Q3 IS  NULL ) THEN SUM_LASTDIVAMOUNT_DEPOSITS_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_Q3,0)) end [DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3]
			  --,CASE WHEN (SUM_LASTDIVAMOUNT_DEPOSITS_Q1 IS NULL AND SUM_LASTDIVAMOUNT_DEPOSITS_Q4 IS  NULL ) THEN SUM_LASTDIVAMOUNT_DEPOSITS_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_Q4,0)) end [DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q4]
			  ,AVG_CHARGEOFFAMOUNT_DEPOSITS_SP
			  ,AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_DEPOSITS_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_DEPOSITS_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q2]
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_DEPOSITS_Q3 IS NULL) THEN AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_DEPOSITS_Q3,0)) end [DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q3]
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_DEPOSITS_Q4 IS NULL) THEN AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_DEPOSITS_Q4,0)) end [DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q4]
			  ,[SAVINGS_StaticpoolFlag]
			  ,[BUSINESS_StaticpoolFlag]
			  ,[NON_INT_EARNING_StaticpoolFlag]
			  ,[STUDENT_StaticpoolFlag]
			  ,[CHECKING_StaticpoolFlag]
			  ,[CERTIFICATES_StaticpoolFlag]
			  ,[MONEYMARKET_StaticpoolFlag]
			  ,[IRA_StaticpoolFlag]
			  ,[HSA_StaticpoolFlag]

			  ,[SAVINGS_Q1Flag]
			  ,[CHECKING_Q1Flag]
			  ,[CERTIFICATES_Q1Flag]
			  ,[MONEYMARKET_Q1Flag]
			  ,[IRA_Q1Flag]
			  ,[HSA_Q1Flag]

		into #membership_deposits
		FROM 
		(
	     (SELECT * 
		         ,CASE WHEN PRODUCT_SAVINGS_SP > 0 THEN 1 ELSE 0 END [SAVINGS_StaticpoolFlag]
				 ,CASE WHEN BUSINESS_SAVINGS_SP > 0 THEN 1 ELSE 0 END [BUSINESS_StaticpoolFlag]
				 ,CASE WHEN NON_INT_EARNING_SAVINGS_SP > 0 THEN 1 ELSE 0 END [NON_INT_EARNING_StaticpoolFlag]
				 ,CASE WHEN STUDENT_SAVINGS_SP > 0 THEN 1 ELSE 0 END [STUDENT_StaticpoolFlag]
				 ,CASE WHEN PRODUCT_CHECKING_SP > 0 THEN 1 ELSE 0 END [CHECKING_StaticpoolFlag]
				 ,CASE WHEN PRODUCT_CERTIFICATES_SP > 0 THEN 1 ELSE 0 END [CERTIFICATES_StaticpoolFlag]
				 ,CASE WHEN PRODUCT_MONEYMARKET_SP > 0 THEN 1 ELSE 0 END [MONEYMARKET_StaticpoolFlag]
				 ,CASE WHEN PRODUCT_IRA_SP > 0 THEN 1 ELSE 0 END [IRA_StaticpoolFlag]
				 ,CASE WHEN PRODUCT_HSA_SP > 0 THEN 1 ELSE 0 END [HSA_StaticpoolFlag]

		         ,CASE WHEN PRODUCT_SAVINGS_Q1 > 0 THEN 1 ELSE 0 END [SAVINGS_Q1Flag]
				 ,CASE WHEN BUSINESS_SAVINGS_Q1 > 0 THEN 1 ELSE 0 END [BUSINESS_Q1Flag]
				 ,CASE WHEN NON_INT_EARNING_SAVINGS_Q1 > 0 THEN 1 ELSE 0 END [NON_INT_EARNING_Q1Flag]
				 ,CASE WHEN STUDENT_SAVINGS_Q1 > 0 THEN 1 ELSE 0 END [STUDENT_Q1Flag]
				 ,CASE WHEN PRODUCT_CHECKING_Q1 > 0 THEN 1 ELSE 0 END [CHECKING_Q1Flag]
				 ,CASE WHEN PRODUCT_CERTIFICATES_Q1 > 0 THEN 1 ELSE 0 END [CERTIFICATES_Q1Flag]
				 ,CASE WHEN PRODUCT_MONEYMARKET_Q1 > 0 THEN 1 ELSE 0 END [MONEYMARKET_Q1Flag]
				 ,CASE WHEN PRODUCT_IRA_Q1 > 0 THEN 1 ELSE 0 END [IRA_Q1Flag]
				 ,CASE WHEN PRODUCT_HSA_Q1 > 0 THEN 1 ELSE 0 END [HSA_Q1Flag]
		   FROM
		  (
			 SELECT SSN
              ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Staticpool') then UNID END) [PRODUCT_SAVINGS_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then UNID END) [PRODUCT_SAVINGS_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then UNID END) [PRODUCT_SAVINGS_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then UNID END) [PRODUCT_SAVINGS_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then UNID END) [PRODUCT_SAVINGS_Q4]

			  ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'BUSINESS_SAVINGS' and Quarters = 'Staticpool') then UNID END) [BUSINESS_SAVINGS_SP]
		      ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'BUSINESS_SAVINGS' and Quarters = 'Q1') then UNID END) [BUSINESS_SAVINGS_Q1]
			  ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'BUSINESS_SAVINGS' and Quarters = 'Q2') then UNID END) [BUSINESS_SAVINGS_Q2]
			  ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'BUSINESS_SAVINGS' and Quarters = 'Q3') then UNID END) [BUSINESS_SAVINGS_Q3]
			  ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'BUSINESS_SAVINGS' and Quarters = 'Q4') then UNID END) [BUSINESS_SAVINGS_Q4]

			  ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'NON_INT_EARNING_SAVINGS' and Quarters = 'Staticpool') then UNID END) [NON_INT_EARNING_SAVINGS_SP]
		      ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'NON_INT_EARNING_SAVINGS' and Quarters = 'Q1') then UNID END) [NON_INT_EARNING_SAVINGS_Q1]
			  ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'NON_INT_EARNING_SAVINGS' and Quarters = 'Q2') then UNID END) [NON_INT_EARNING_SAVINGS_Q2]
			  ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'NON_INT_EARNING_SAVINGS' and Quarters = 'Q3') then UNID END) [NON_INT_EARNING_SAVINGS_Q3]
			  ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'NON_INT_EARNING_SAVINGS' and Quarters = 'Q4') then UNID END) [NON_INT_EARNING_SAVINGS_Q4]

			  ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'STUDENT_SAVINGS' and Quarters = 'Staticpool') then UNID END) [STUDENT_SAVINGS_SP]
		      ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'STUDENT_SAVINGS' and Quarters = 'Q1') then UNID END) [STUDENT_SAVINGS_Q1]
			  ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'STUDENT_SAVINGS' and Quarters = 'Q2') then UNID END) [STUDENT_SAVINGS_Q2]
			  ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'STUDENT_SAVINGS' and Quarters = 'Q3') then UNID END) [STUDENT_SAVINGS_Q3]
			  ,COUNT(DISTINCT CASE WHEN (saving_sub_Flag = 'STUDENT_SAVINGS' and Quarters = 'Q4') then UNID END) [STUDENT_SAVINGS_Q4]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Staticpool') then TYPE END) [TYPE_SAVINGS_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then TYPE END) [TYPE_SAVINGS_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then TYPE END) [TYPE_SAVINGS_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then TYPE END) [TYPE_SAVINGS_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then TYPE END) [TYPE_SAVINGS_Q4]
			  ,MIN(CASE WHEN Deposit_Flag = 'Savings' then Open_date END) [OPENDATE_SAVINGS]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' then Close_date END) [CLOSEDATE_SAVINGS]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' then MOB END) [MOB_SAVINGS]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_SAVINGS_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_SAVINGS_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_SAVINGS_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_SAVINGS_Q4]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_SAVINGS_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_SAVINGS_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_SAVINGS_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_SAVINGS_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_SAVINGS_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_SAVINGS_Q4]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_SAVINGS_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_SAVINGS_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_SAVINGS_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_SAVINGS_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_SAVINGS_Q4]

					       --- Previously only SUM_LASTDIVAMOUNT_SAVINGS_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SAVINGS_SP]
			  ,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SAVINGS_Q1]
			  ,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SAVINGS_Q2]
			  ,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SAVINGS_Q3]
			  ,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SAVINGS_Q4]

			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Staticpool') then UNID END) [PRODUCT_CHECKING_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then UNID END) [PRODUCT_CHECKING_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then UNID END) [PRODUCT_CHECKING_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then UNID END) [PRODUCT_CHECKING_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then UNID END) [PRODUCT_CHECKING_Q4]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Staticpool') then TYPE END) [TYPE_CHECKING_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then TYPE END) [TYPE_CHECKING_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then TYPE END) [TYPE_CHECKING_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then TYPE END) [TYPE_CHECKING_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then TYPE END) [TYPE_CHECKING_Q4]

			  ,MIN(CASE WHEN Deposit_Flag = 'Checking' then Open_date END) [OPENDATE_CHECKING]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' then Close_date END) [CLOSEDATE_CHECKING]

			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' then MOB END) [MOB_CHECKING]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CHECKING_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CHECKING_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CHECKING_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CHECKING_Q4]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_CHECKING_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_CHECKING_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CHECKING_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CHECKING_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CHECKING_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CHECKING_Q4]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_CHECKING_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CHECKING_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CHECKING_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CHECKING_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CHECKING_Q4]

					       --- Previously only SUM_LASTDIVAMOUNT_CHECKING_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CHECKING_SP]
			  ,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CHECKING_Q1]
			  ,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CHECKING_Q2]
			  ,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CHECKING_Q3]
			  ,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CHECKING_Q4]

              ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Staticpool') then UNID END) [PRODUCT_CERTIFICATES_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then UNID END) [PRODUCT_CERTIFICATES_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then UNID END) [PRODUCT_CERTIFICATES_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then UNID END) [PRODUCT_CERTIFICATES_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then UNID END) [PRODUCT_CERTIFICATES_Q4]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Staticpool') then TYPE END) [TYPE_CERTIFICATES_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then TYPE END) [TYPE_CERTIFICATES_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then TYPE END) [TYPE_CERTIFICATES_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then TYPE END) [TYPE_CERTIFICATES_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then TYPE END) [TYPE_CERTIFICATES_Q4]

			  ,MIN(CASE WHEN Deposit_Flag = 'Certificates' then Open_date END) [OPENDATE_CERTIFICATES]
			  ,MAX(CASE WHEN Deposit_Flag = 'Certificates' then Close_date END) [CLOSEDATE_CERTIFICATES]

			  ,MAX(CASE WHEN Deposit_Flag = 'Certificates' then MOB END) [MOB_CERTIFICATES]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CERTIFICATES_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CERTIFICATES_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CERTIFICATES_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CERTIFICATES_Q4]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_CERTIFICATES_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CERTIFICATES_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CERTIFICATES_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CERTIFICATES_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CERTIFICATES_Q4]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_CERTIFICATES_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CERTIFICATES_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CERTIFICATES_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CERTIFICATES_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CERTIFICATES_Q4]

					       --- Previously only SUM_LASTDIVAMOUNT_CERTIFICATES_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CERTIFICATES_SP]
			  ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1]
			  ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q2]
			  ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q3]
			  ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q4]

              ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Staticpool') then UNID END) [PRODUCT_MONEYMARKET_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then UNID END) [PRODUCT_MONEYMARKET_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then UNID END) [PRODUCT_MONEYMARKET_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then UNID END) [PRODUCT_MONEYMARKET_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then UNID END) [PRODUCT_MONEYMARKET_Q4]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Staticpool') then TYPE END) [TYPE_MONEYMARKET_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then TYPE END) [TYPE_MONEYMARKET_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then TYPE END) [TYPE_MONEYMARKET_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then TYPE END) [TYPE_MONEYMARKET_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then TYPE END) [TYPE_MONEYMARKET_Q4]
			  ,MIN(CASE WHEN Deposit_Flag = 'MoneyMarket' then Open_date END) [OPENDATE_MONEYMARKET]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' then Close_date END) [CLOSEDATE_MONEYMARKET]

			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' then MOB END) [MOB_MONEYMARKET]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_MONEYMARKET_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_MONEYMARKET_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_MONEYMARKET_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_MONEYMARKET_Q4]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_MONEYMARKET_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_MONEYMARKET_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_MONEYMARKET_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_MONEYMARKET_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_MONEYMARKET_Q4]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_MONEYMARKET_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q4]

					       --- Previously only SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_MONEYMARKET_SP]
			  ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1]
			  ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q2]
			  ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q3]
			  ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q4]

              ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Staticpool') then UNID END) [PRODUCT_IRA_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q1') then UNID END) [PRODUCT_IRA_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q2') then UNID END) [PRODUCT_IRA_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q3') then UNID END) [PRODUCT_IRA_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q4') then UNID END) [PRODUCT_IRA_Q4]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Staticpool') then TYPE END) [TYPE_IRA_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q1') then TYPE END) [TYPE_IRA_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q2') then TYPE END) [TYPE_IRA_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q3') then TYPE END) [TYPE_IRA_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q4') then TYPE END) [TYPE_IRA_Q4]
			  ,MIN(CASE WHEN Deposit_Flag = 'IRA' then Open_date END) [OPENDATE_IRA]
			  ,MAX(CASE WHEN Deposit_Flag = 'IRA' then Close_date END) [CLOSEDATE_IRA]

			  ,MAX(CASE WHEN Deposit_Flag = 'IRA' then MOB END) [MOB_IRA]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_IRA_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_IRA_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_IRA_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_IRA_Q4]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_IRA_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_IRA_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_IRA_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_IRA_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_IRA_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_IRA_Q4]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_IRA_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_IRA_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_IRA_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_IRA_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_IRA_Q4]

					       --- Previously only SUM_LASTDIVAMOUNT_IRA_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_IRA_SP]
			  ,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_IRA_Q1]
			  ,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_IRA_Q2]
			  ,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_IRA_Q3]
			  ,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_IRA_Q4]

              ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Staticpool') then UNID END) [PRODUCT_HSA_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q1') then UNID END) [PRODUCT_HSA_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q2') then UNID END) [PRODUCT_HSA_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q3') then UNID END) [PRODUCT_HSA_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q4') then UNID END) [PRODUCT_HSA_Q4]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Staticpool') then TYPE END) [TYPE_HSA_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q1') then TYPE END) [TYPE_HSA_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q2') then TYPE END) [TYPE_HSA_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q3') then TYPE END) [TYPE_HSA_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q4') then TYPE END) [TYPE_HSA_Q4]
			  ,MIN(CASE WHEN Deposit_Flag = 'HSA' then Open_date END) [OPENDATE_HSA]
			  ,MAX(CASE WHEN Deposit_Flag = 'HSA' then Close_date END) [CLOSEDATE_HSA]

			  ,MAX(CASE WHEN Deposit_Flag = 'HSA' then MOB END) [MOB_HSA]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_HSA_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_HSA_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_HSA_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_HSA_Q4]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_HSA_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_HSA_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_HSA_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_HSA_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_HSA_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_HSA_Q4]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_HSA_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_HSA_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_HSA_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_HSA_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_HSA_Q4]

					       --- Previously only SUM_LASTDIVAMOUNT_HSA_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_HSA_SP]
			  ,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_HSA_Q1]
			  ,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_HSA_Q2]
			  ,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_HSA_Q3]
			  ,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_HSA_Q4]

		    FROM #deposits_account_data
		    group by SSN
			 ) P
			) A
			LEFT JOIN 
			(
			SELECT SSN
              ,COUNT(DISTINCT CASE WHEN Quarters = 'Staticpool' then UNID END) [PRODUCT_DEPOSITS_SP]
		      ,COUNT(DISTINCT CASE WHEN Quarters = 'Q1'then UNID END) [PRODUCT_DEPOSITS_Q1]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q2'then UNID END) [PRODUCT_DEPOSITS_Q2]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q3'then UNID END) [PRODUCT_DEPOSITS_Q3]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q4'then UNID END) [PRODUCT_DEPOSITS_Q4]
					
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Staticpool' then TYPE END) [TYPE_DEPOSITS_SP]
		      ,COUNT(DISTINCT CASE WHEN Quarters = 'Q1' then TYPE END) [TYPE_DEPOSITS_Q1]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q2' then TYPE END) [TYPE_DEPOSITS_Q2]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q3' then TYPE END) [TYPE_DEPOSITS_Q3]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q4' then TYPE END) [TYPE_DEPOSITS_Q4]
			  ,MIN(Open_date) [MIN_OPENDATE_DEPOSITS]
			  ,MAX(Close_date) [MAX_CLOSEDATE_DEPOSITS]

			  ,MAX( MOB ) [MOB_DEPOSITS]
			  
			  ,SUM(CASE WHEN Quarters = 'Q1' then Month_end_balance END) [SUM_MONTH_END_BALANCE_DEPOSITS_Q1]
			  ,SUM(CASE WHEN Quarters = 'Q2' then Month_end_balance END) [SUM_MONTH_END_BALANCE_DEPOSITS_Q2]
			  ,SUM(CASE WHEN Quarters = 'Q3' then Month_end_balance END) [SUM_MONTH_END_BALANCE_DEPOSITS_Q3]
			  ,SUM(CASE WHEN Quarters = 'Q4' then Month_end_balance END) [SUM_MONTH_END_BALANCE_DEPOSITS_Q4]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_DEPOSITS_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_DEPOSITS_Q1_Q4 was taken 

			  ,AVG(CASE WHEN Quarters = 'Q1' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q1]
			  ,AVG(CASE WHEN Quarters = 'Q2' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q2]
			  ,AVG(CASE WHEN Quarters = 'Q3' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q3]
			  ,AVG(CASE WHEN Quarters = 'Q4' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q4]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_DEPOSITS_Q1 was taken 

              ,SUM(CASE WHEN Quarters = 'Q1' then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_DEPOSITS_Q1]
			  ,SUM(CASE WHEN Quarters = 'Q2' then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_DEPOSITS_Q2]
			  ,SUM(CASE WHEN Quarters = 'Q3' then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_DEPOSITS_Q3]
			  ,SUM(CASE WHEN Quarters = 'Q4' then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_DEPOSITS_Q4]

					       --- Previously only SUM_LASTDIVAMOUNT_DEPOSITS_Q1 was taken

              ,AVG(CASE WHEN  Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_DEPOSITS_SP]	
			  ,AVG(CASE WHEN  Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1]	
			  ,AVG(CASE WHEN  Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_DEPOSITS_Q2]	
			  ,AVG(CASE WHEN  Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_DEPOSITS_Q3]		
			  ,AVG(CASE WHEN  Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_DEPOSITS_Q4]		
			FROM #deposits_account_data
			group by SSN
			) B
			ON A.SSN = B.SSN
		 
		) 

		---Refer 5199 line of Previous Data Creation

		--SELECT TOP 100 * FROM #membership_deposits

		--SELECT TOP 100 * FROM #static_unid_deposits
		
		--SELECT TOP 100 * FROM #deposits_account_data
		 
		--SELECT distinct aa.parentaccount,bb.AccountPrimeNameSSN SSN--*--distinct 
		--FROM #static_unid_deposits aa
		--left join ARCUSYM000.arcu.ARCUAccountDetailed bb
		--on aa.parentaccount = bb.AccountNumber
		--group by process_date
		--where process_date = '2022-03-31'
------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Transaction Data (ShareCategorywise) ***\\\-----------------------------------------------

     DROP TABLE IF EXISTS #static_unid_deposits
     
     SELECT UNID,PARENTACCOUNT,Deposit_Flag,saving_sub_Flag,Process_Date
     into #static_unid_deposits
     from #deposits_account_data
	 
		--DECLARE @staticpooldate date
		--set @staticpooldate = '2023-03-31'

     DROP TABLE IF EXISTS #deposit_transaction_temp1
     SELECT B.Deposit_Flag,saving_sub_Flag
	  ,case when A.EFFECTIVEDATE_v1 in ((left(convert(varchar,eomonth(dateadd(month,-10,@staticpooldate)),112),6)),(left(convert(varchar,eomonth(dateadd(month,-11,@staticpooldate)),112),6)),(left(convert(varchar,eomonth(dateadd(month,-12,@staticpooldate)),112),6))) then 'Q4'
		    when A.EFFECTIVEDATE_v1 in ((left(convert(varchar,eomonth(dateadd(month,-7,@staticpooldate)),112),6)),(left(convert(varchar, eomonth(dateadd(month,-8,@staticpooldate)),112),6)),(left(convert(varchar, eomonth(dateadd(month,-9,@staticpooldate)),112),6))) then 'Q3'
		    when A.EFFECTIVEDATE_v1 in ((left(convert(varchar,eomonth(dateadd(month,-4,@staticpooldate)),112),6)),(left(convert(varchar, eomonth(dateadd(month,-5,@staticpooldate)),112),6)),(left(convert(varchar, eomonth(dateadd(month,-6,@staticpooldate)),112),6))) then 'Q2'
		    when A.EFFECTIVEDATE_v1 in ((left(convert(varchar,eomonth(dateadd(month,-3,@staticpooldate)),112),6)),(left(convert(varchar, eomonth(dateadd(month,-2,@staticpooldate)),112),6)),(left(convert(varchar, eomonth(dateadd(month,-1,@staticpooldate)),112),6))) then 'Q1'
		    when A.EFFECTIVEDATE_v1 in (left(convert(varchar,@staticpooldate,112),6)) then 'Staticpool' end Quarters
	 ,A.*
	 ,C.SSN
	    into #deposit_transaction_temp1
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      ,[COMMENTCODE]
      ,[TRANSFERCODE]
      ,[ADJUSTMENTCODE]
      ,[REGECODE]
      ,[REGDCHECKCODE]
      ,[REGDTRANSFERCODE]
      ,[VOIDCODE]
      ,[SUBACTIONCODE]
      ,[SEQUENCENUMBER]
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      ,[POSTDATE]
      ,[POSTTIME]
      ,[USERNUMBER]
      ,[USEROVERRIDE]
      ,[SECURITYLEVELS]
      ,[DESCRIPTION]
      ,[ACTIONCODE]
      ,[SOURCECODE]
      ,[BALANCECHANGE]
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	  ,[INTEREST]
      ,[NEWBALANCE]
      ,[FEEAMOUNT]
      ,[ESCROWAMOUNT]
      ,[LASTTRANDATE]
      ,[MATURITYLOANDUEDATE]
      ,[COMMENT]
      ,[BRANCH]
      ,[CONSOLENUMBER]
      ,[BATCHSEQUENCE]
      ,[SALESTAXAMOUNT]
      ,[ACTIVITYDATE]
      ,[BILLEDFEEAMOUNT]
      ,[PROCESSORUSER]
      ,[MEMBERBRANCH]
      ,[PREVAVAILBALANCE]
      ,[SUBSOURCE]
      ,[CONFIRMATIONSEQ]
      ,[MICRACCTNUM]
      ,[MICRRT]
      ,[RECURRINGTRAN]
      ,[FEEEXMTCRTSYAMT]
      ,[ESCROWUNPAIDBALCHG]
      ,[ESCROWAPPLIEDBALCHG]
      ,[UNAPPLIEDPARTIALPMTCHG]
      ,[FEECOUNTBY]
      ,[BALSEGCOUNT]
      ,[LATECHGWAIVEDAMT]
      ,[LATECHGUNPAIDCHGAMT]
      ,[PREVLATECHGDATE]
      ,[PREVLATECHGACCRUED]
      ,[LATECHGFIELDSVALID]
      ,[BALSEGID1]
      ,[BALSEGPMTCHANGEDATE1]
      ,[INTEFFECTDATE]
      ,[BALSEGPREVFIRSTPMTDATE1]
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
	 FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
	  WHERE  ACTIONCODE!='C') A
	 left join #static_unid_deposits B
	 ON A.UNID = B.UNID
	 left join #Static_SSN_account C
	 on A.PARENTACCOUNT = C.AccountNumber
	 --and A.EFFECTIVEDATE_v1 = B.Process_Date
	-- day wise data include all dates 
	where EFFECTIVEDATE_v1 between left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6) and left(convert(varchar,@staticpooldate,112),6)
  
select distinct  saving_sub_Flag  from #deposit_transaction_temp1
  
  

        DROP TABLE IF EXISTS #deposit_transaction_temp2
            
  --      SELECT B.SSN
  --              ,A.*
  --      INTO #deposit_transaction_temp2 
  --      From
		--(
		 SELECT * 
		 INTO #deposit_transaction_temp2 
		 FROM
          (SELECT  SSN 
		        --,PARENTACCOUNT
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_SAVINGS_Q4]

                ,SUM(CASE WHEN saving_sub_Flag = 'BUSINESS_SAVINGS' and Quarters = 'Q1' THEN 1 END) [TRAN_BUSINESS_SAVINGS_COUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN saving_sub_Flag = 'BUSINESS_SAVINGS' and Quarters = 'Q2' THEN 1 END) [TRAN_BUSINESS_SAVINGS_COUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN saving_sub_Flag = 'BUSINESS_SAVINGS' and Quarters = 'Q3' THEN 1 END) [TRAN_BUSINESS_SAVINGS_COUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN saving_sub_Flag = 'BUSINESS_SAVINGS' and Quarters = 'Q4' THEN 1 END) [TRAN_BUSINESS_SAVINGS_COUNT_SAVINGS_Q4]

				,SUM(CASE WHEN saving_sub_Flag = 'NON_INT_EARNING_SAVINGS' and Quarters = 'Q1' THEN 1 END) [TRAN_NON_INT_EARNING_SAVINGS_COUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN saving_sub_Flag = 'NON_INT_EARNING_SAVINGS' and Quarters = 'Q2' THEN 1 END) [TRAN_NON_INT_EARNING_SAVINGS_COUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN saving_sub_Flag = 'NON_INT_EARNING_SAVINGS' and Quarters = 'Q3' THEN 1 END) [TRAN_NON_INT_EARNING_SAVINGS_COUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN saving_sub_Flag = 'NON_INT_EARNING_SAVINGS' and Quarters = 'Q4' THEN 1 END) [TRAN_NON_INT_EARNING_SAVINGS_COUNT_SAVINGS_Q4]
            
                ,SUM(CASE WHEN saving_sub_Flag = 'STUDENT_SAVINGS' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRAN_STUDENT_SAVINGS_AMOUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN saving_sub_Flag = 'STUDENT_SAVINGS' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRAN_STUDENT_SAVINGS_AMOUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN saving_sub_Flag = 'STUDENT_SAVINGS' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRAN_STUDENT_SAVINGS_AMOUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN saving_sub_Flag = 'STUDENT_SAVINGS' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRAN_STUDENT_SAVINGS_AMOUNT_SAVINGS_Q4]

                ,SUM(CASE WHEN saving_sub_Flag = 'STUDENT_SAVINGS' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN saving_sub_Flag = 'STUDENT_SAVINGS' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN saving_sub_Flag = 'STUDENT_SAVINGS' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN saving_sub_Flag = 'STUDENT_SAVINGS' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_SAVINGS_Q4]
            
                ,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_TRANSACTION_SAVINGS_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_TRANSACTION_SAVINGS_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_TRANSACTION_SAVINGS_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_TRANSACTION_SAVINGS_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_SAVINGS_Q4]	
            		
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN 1 END) [DEPOSITED_COUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN 1 END) [DEPOSITED_COUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN 1 END) [DEPOSITED_COUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN 1 END) [DEPOSITED_COUNT_SAVINGS_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_SAVINGS_Q4]
            
                ,COUNT(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_SAVINGS_Q1]
            	,COUNT(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_SAVINGS_Q2]
            	,COUNT(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_SAVINGS_Q3]
            	,COUNT(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_SAVINGS_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_SAVINGS_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_CHECKING_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CHECKING_Q4]
            
                ,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_TRANSACTION_CHECKING_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_TRANSACTION_CHECKING_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_TRANSACTION_CHECKING_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_TRANSACTION_CHECKING_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CHECKING_Q4]	
            		
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_COUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_COUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_COUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_COUNT_CHECKING_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CHECKING_Q4]

				,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN 1 END) [WITHDRAWAL_COUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN 1 END) [WITHDRAWAL_COUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN 1 END) [WITHDRAWAL_COUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN 1 END) [WITHDRAWAL_COUNT_CHECKING_Q4]
            
             --   ,COUNT(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_CHECKING_Q1]
            	--,COUNT(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_CHECKING_Q2]
            	--,COUNT(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_CHECKING_Q3]
            	--,COUNT(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_CHECKING_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_CHECKING_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_CERTIFICATES_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_Q4]
            
                ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_TRANSACTION_CERTIFICATES_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_TRANSACTION_CERTIFICATES_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_TRANSACTION_CERTIFICATES_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_TRANSACTION_CERTIFICATES_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CERTIFICATES_Q4]	
            		
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN 1 END) [DEPOSITED_COUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN 1 END) [DEPOSITED_COUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN 1 END) [DEPOSITED_COUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN 1 END) [DEPOSITED_COUNT_CERTIFICATES_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CERTIFICATES_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN 1 END) [WITHDRAWAL_COUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN 1 END) [WITHDRAWAL_COUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN 1 END) [WITHDRAWAL_COUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN 1 END) [WITHDRAWAL_COUNT_CERTIFICATES_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_CERTIFICATES_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_MONEYMARKET_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_MONEYMARKET_Q4]
            
                ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_TRANSACTION_MONEYMARKET_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_TRANSACTION_MONEYMARKET_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_TRANSACTION_MONEYMARKET_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_TRANSACTION_MONEYMARKET_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_MONEYMARKET_Q4]	
            		
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN 1 END) [DEPOSITED_COUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN 1 END) [DEPOSITED_COUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN 1 END) [DEPOSITED_COUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN 1 END) [DEPOSITED_COUNT_MONEYMARKET_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_MONEYMARKET_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN 1 END) [WITHDRAWAL_COUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN 1 END) [WITHDRAWAL_COUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN 1 END) [WITHDRAWAL_COUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN 1 END) [WITHDRAWAL_COUNT_MONEYMARKET_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_MONEYMARKET_Q4]

                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_IRA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_IRA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_IRA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_IRA_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_IRA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_IRA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_IRA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_IRA_Q4]
            
                ,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_TRANSACTION_IRA_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_TRANSACTION_IRA_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_TRANSACTION_IRA_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_TRANSACTION_IRA_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_IRA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_IRA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_IRA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_IRA_Q4]	
            		
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN 1 END) [DEPOSITED_COUNT_IRA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN 1 END) [DEPOSITED_COUNT_IRA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN 1 END) [DEPOSITED_COUNT_IRA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN 1 END) [DEPOSITED_COUNT_IRA_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_IRA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_IRA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_IRA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_IRA_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN 1 END) [WITHDRAWAL_COUNT_IRA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN 1 END) [WITHDRAWAL_COUNT_IRA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN 1 END) [WITHDRAWAL_COUNT_IRA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN 1 END) [WITHDRAWAL_COUNT_IRA_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_IRA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_IRA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_IRA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_IRA_Q4]

                ,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_HSA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_HSA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_HSA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_HSA_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_HSA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_HSA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_HSA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_HSA_Q4]
            
                ,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_TRANSACTION_HSA_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_TRANSACTION_HSA_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_TRANSACTION_HSA_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_TRANSACTION_HSA_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_HSA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_HSA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_HSA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_HSA_Q4]	
            		
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN 1 END) [DEPOSITED_COUNT_HSA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN 1 END) [DEPOSITED_COUNT_HSA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN 1 END) [DEPOSITED_COUNT_HSA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN 1 END) [DEPOSITED_COUNT_HSA_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_HSA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_HSA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_HSA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_HSA_Q4]
            
                ,COUNT(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_HSA_Q1]
            	,COUNT(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_HSA_Q2]
            	,COUNT(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_HSA_Q3]
            	,COUNT(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_HSA_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_HSA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_HSA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_HSA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_HSA_Q4]

        from #deposit_transaction_temp1
        --group by PARENTACCOUNT
		group by SSN ) P
		LEFT JOIN 
		(SELECT SSN [SSN_D]
		 --PARENTACCOUNT [P_D]
                ,SUM(CASE WHEN Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q4]
            
                ,SUM(CASE WHEN Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_DEPOSITS_Q4]
            
                ,AVG(CASE WHEN Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_TRANSACTION_DEPOSITS_Q1]
            	,AVG(CASE WHEN Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_TRANSACTION_DEPOSITS_Q2]
            	,AVG(CASE WHEN Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_TRANSACTION_DEPOSITS_Q3]
            	,AVG(CASE WHEN Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_TRANSACTION_DEPOSITS_Q4]
            
                ,SUM(CASE WHEN Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_DEPOSITS_Q4]	
            		
            	,SUM(CASE WHEN Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_COUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_COUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_COUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_COUNT_DEPOSITS_Q4]
            
                ,SUM(CASE WHEN Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q4]
            
                ,COUNT(CASE WHEN Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_DEPOSITS_Q1]
            	,COUNT(CASE WHEN Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_DEPOSITS_Q2]
            	,COUNT(CASE WHEN Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_DEPOSITS_Q3]
            	,COUNT(CASE WHEN Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_DEPOSITS_Q4]
            
                ,SUM(CASE WHEN Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_DEPOSITS_Q4]		
		FROM #deposit_transaction_temp1
		--group by PARENTACCOUNT 
		group by SSN) Q
		ON P.ssn = Q.SSN_D
		
  --      left join #Static_SSN_account B
  --      on A.PARENTACCOUNT = B.AccountNumber

		DROP TABLE IF EXISTS #deposits_transaction

		SELECT SSN [SSN004]
		      , [TRANSACTION_COUNT_SAVINGS_Q1] 
			  , CASE WHEN ( TRANSACTION_COUNT_SAVINGS_Q1 IS NULL AND TRANSACTION_COUNT_SAVINGS_Q2 IS  NULL ) THEN TRANSACTION_COUNT_SAVINGS_Q1 else (ISNULL(TRANSACTION_COUNT_SAVINGS_Q1,0) - ISNULL(TRANSACTION_COUNT_SAVINGS_Q2,0)) end DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2
			  , CASE WHEN ( TRANSACTION_COUNT_SAVINGS_Q1 IS NULL AND TRANSACTION_COUNT_SAVINGS_Q3 IS  NULL ) THEN TRANSACTION_COUNT_SAVINGS_Q1 else (ISNULL(TRANSACTION_COUNT_SAVINGS_Q1,0) - ISNULL(TRANSACTION_COUNT_SAVINGS_Q3,0)) end DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3
			  --, CASE WHEN ( TRANSACTION_COUNT_SAVINGS_Q1 IS NULL AND TRANSACTION_COUNT_SAVINGS_Q4 IS  NULL ) THEN TRANSACTION_COUNT_SAVINGS_Q1 else (ISNULL(TRANSACTION_COUNT_SAVINGS_Q1,0) - ISNULL(TRANSACTION_COUNT_SAVINGS_Q4,0)) end DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q4
			  , [TRANSACTION_AMOUNT_SAVINGS_Q1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_SAVINGS_Q1 IS NULL AND TRANSACTION_AMOUNT_SAVINGS_Q2 IS  NULL ) THEN TRANSACTION_AMOUNT_SAVINGS_Q1 else (ISNULL(TRANSACTION_AMOUNT_SAVINGS_Q1,0) - ISNULL(TRANSACTION_AMOUNT_SAVINGS_Q2,0)) end DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2
			  , CASE WHEN (TRANSACTION_AMOUNT_SAVINGS_Q1 IS NULL AND TRANSACTION_AMOUNT_SAVINGS_Q3 IS  NULL ) THEN TRANSACTION_AMOUNT_SAVINGS_Q1 else (ISNULL(TRANSACTION_AMOUNT_SAVINGS_Q1,0) - ISNULL(TRANSACTION_AMOUNT_SAVINGS_Q3,0)) end DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3
			  --, CASE WHEN (TRANSACTION_AMOUNT_SAVINGS_Q1 IS NULL AND TRANSACTION_AMOUNT_SAVINGS_Q4 IS  NULL ) THEN TRANSACTION_AMOUNT_SAVINGS_Q1 else (ISNULL(TRANSACTION_AMOUNT_SAVINGS_Q1,0) - ISNULL(TRANSACTION_AMOUNT_SAVINGS_Q4,0)) end DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q4
			  , [AVG_TRANSACTION_SAVINGS_Q1]
			  , CASE WHEN (AVG_TRANSACTION_SAVINGS_Q1 IS NULL AND AVG_TRANSACTION_SAVINGS_Q2 IS  NULL ) THEN AVG_TRANSACTION_SAVINGS_Q1 else (ISNULL(AVG_TRANSACTION_SAVINGS_Q1,0)  - ISNULL(AVG_TRANSACTION_SAVINGS_Q2,0)) end DFT_AVG_TRANSACTION_SAVINGS_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_SAVINGS_Q1 IS NULL AND AVG_TRANSACTION_SAVINGS_Q3 IS  NULL ) THEN AVG_TRANSACTION_SAVINGS_Q1 else (ISNULL(AVG_TRANSACTION_SAVINGS_Q1,0)  - ISNULL(AVG_TRANSACTION_SAVINGS_Q3,0)) end DFT_AVG_TRANSACTION_SAVINGS_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_SAVINGS_Q1 IS NULL AND AVG_TRANSACTION_SAVINGS_Q4 IS  NULL ) THEN AVG_TRANSACTION_SAVINGS_Q1 else (ISNULL(AVG_TRANSACTION_SAVINGS_Q1,0)  - ISNULL(AVG_TRANSACTION_SAVINGS_Q4,0)) end DFT_AVG_TRANSACTION_SAVINGS_Q1_Q4
			  , [DEPOSITED_AMOUNT_SAVINGS_Q1] 
			  , CASE WHEN (AVG_TRANSACTION_SAVINGS_Q1 IS NULL AND AVG_TRANSACTION_SAVINGS_Q2 IS  NULL ) THEN AVG_TRANSACTION_SAVINGS_Q1 else (ISNULL(DEPOSITED_AMOUNT_SAVINGS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_SAVINGS_Q2,0)) end DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_SAVINGS_Q1 IS NULL AND AVG_TRANSACTION_SAVINGS_Q3 IS  NULL ) THEN AVG_TRANSACTION_SAVINGS_Q1 else (ISNULL(DEPOSITED_AMOUNT_SAVINGS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_SAVINGS_Q3,0)) end DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_SAVINGS_Q1 IS NULL AND AVG_TRANSACTION_SAVINGS_Q4 IS  NULL ) THEN AVG_TRANSACTION_SAVINGS_Q1 else (ISNULL(DEPOSITED_AMOUNT_SAVINGS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_SAVINGS_Q4,0)) end DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q4
			  , [DEPOSITED_COUNT_SAVINGS_Q1]
			  , CASE WHEN (DEPOSITED_COUNT_SAVINGS_Q1 IS NULL AND DEPOSITED_COUNT_SAVINGS_Q2 IS  NULL ) THEN DEPOSITED_COUNT_SAVINGS_Q1 else (ISNULL(DEPOSITED_COUNT_SAVINGS_Q1,0) - ISNULL(DEPOSITED_COUNT_SAVINGS_Q2,0)) end [DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2]
			  , CASE WHEN (DEPOSITED_COUNT_SAVINGS_Q1 IS NULL AND DEPOSITED_COUNT_SAVINGS_Q3 IS  NULL ) THEN DEPOSITED_COUNT_SAVINGS_Q1 else (ISNULL(DEPOSITED_COUNT_SAVINGS_Q1,0) - ISNULL(DEPOSITED_COUNT_SAVINGS_Q3,0)) end [DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3]
			  --, CASE WHEN (DEPOSITED_COUNT_SAVINGS_Q1 IS NULL AND DEPOSITED_COUNT_SAVINGS_Q4 IS  NULL ) THEN DEPOSITED_COUNT_SAVINGS_Q1 else (ISNULL(DEPOSITED_COUNT_SAVINGS_Q1,0) - ISNULL(DEPOSITED_COUNT_SAVINGS_Q4,0)) end [DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q4]
			  , [WITHDRAWAL_AMOUNT_SAVINGS_Q1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_SAVINGS_Q1 IS NULL AND WITHDRAWAL_AMOUNT_SAVINGS_Q2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_SAVINGS_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q2,0)) end [DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_SAVINGS_Q1 IS NULL AND WITHDRAWAL_AMOUNT_SAVINGS_Q3 IS  NULL ) THEN WITHDRAWAL_AMOUNT_SAVINGS_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q3,0)) end [DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_AMOUNT_SAVINGS_Q1 IS NULL AND WITHDRAWAL_AMOUNT_SAVINGS_Q4 IS  NULL ) THEN WITHDRAWAL_AMOUNT_SAVINGS_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q4,0)) end [DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q4]
			  , [WITHDRAWAL_COUNT_SAVINGS_Q1]
			  , CASE WHEN (WITHDRAWAL_COUNT_SAVINGS_Q1 IS NULL AND WITHDRAWAL_COUNT_SAVINGS_Q2 IS  NULL ) THEN WITHDRAWAL_COUNT_SAVINGS_Q1 else (ISNULL(WITHDRAWAL_COUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_COUNT_SAVINGS_Q2,0)) end [DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_COUNT_SAVINGS_Q1 IS NULL AND WITHDRAWAL_COUNT_SAVINGS_Q3 IS  NULL ) THEN WITHDRAWAL_COUNT_SAVINGS_Q1 else (ISNULL(WITHDRAWAL_COUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_COUNT_SAVINGS_Q3,0)) end [DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_COUNT_SAVINGS_Q1 IS NULL AND WITHDRAWAL_COUNT_SAVINGS_Q4 IS  NULL ) THEN WITHDRAWAL_COUNT_SAVINGS_Q1 else (ISNULL(WITHDRAWAL_COUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_COUNT_SAVINGS_Q4,0)) end [DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q4]
			  , [SUM_INTEREST_SAVINGS_Q1]
			  , CASE WHEN (SUM_INTEREST_SAVINGS_Q1 IS NULL AND SUM_INTEREST_SAVINGS_Q2 IS  NULL ) THEN SUM_INTEREST_SAVINGS_Q1 else (ISNULL(SUM_INTEREST_SAVINGS_Q1,0) - ISNULL(SUM_INTEREST_SAVINGS_Q2,0)) end [DFT_SUM_INTEREST_SAVINGS_Q1_Q2]
			  , CASE WHEN (SUM_INTEREST_SAVINGS_Q1 IS NULL AND SUM_INTEREST_SAVINGS_Q3 IS  NULL ) THEN SUM_INTEREST_SAVINGS_Q1 else (ISNULL(SUM_INTEREST_SAVINGS_Q1,0) - ISNULL(SUM_INTEREST_SAVINGS_Q3,0)) end [DFT_SUM_INTEREST_SAVINGS_Q1_Q3]
			  --, CASE WHEN (SUM_INTEREST_SAVINGS_Q1 IS NULL AND SUM_INTEREST_SAVINGS_Q4 IS  NULL ) THEN SUM_INTEREST_SAVINGS_Q1 else (ISNULL(SUM_INTEREST_SAVINGS_Q1,0) - ISNULL(SUM_INTEREST_SAVINGS_Q4,0)) end [DFT_SUM_INTEREST_SAVINGS_Q1_Q4]

		      , [TRANSACTION_COUNT_CHECKING_Q1] 
			  , CASE WHEN ( TRANSACTION_COUNT_CHECKING_Q1 IS NULL AND TRANSACTION_COUNT_CHECKING_Q2 IS  NULL ) THEN TRANSACTION_COUNT_CHECKING_Q1 else (ISNULL(TRANSACTION_COUNT_CHECKING_Q1,0) - ISNULL(TRANSACTION_COUNT_CHECKING_Q2,0)) end DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2
			  , CASE WHEN ( TRANSACTION_COUNT_CHECKING_Q1 IS NULL AND TRANSACTION_COUNT_CHECKING_Q3 IS  NULL ) THEN TRANSACTION_COUNT_CHECKING_Q1 else (ISNULL(TRANSACTION_COUNT_CHECKING_Q1,0) - ISNULL(TRANSACTION_COUNT_CHECKING_Q3,0)) end DFT_TRANSACTION_COUNT_CHECKING_Q1_Q3
			  --, CASE WHEN ( TRANSACTION_COUNT_CHECKING_Q1 IS NULL AND TRANSACTION_COUNT_CHECKING_Q4 IS  NULL ) THEN TRANSACTION_COUNT_CHECKING_Q1 else (ISNULL(TRANSACTION_COUNT_CHECKING_Q1,0) - ISNULL(TRANSACTION_COUNT_CHECKING_Q4,0)) end DFT_TRANSACTION_COUNT_CHECKING_Q1_Q4
			  , [TRANSACTION_AMOUNT_CHECKING_Q1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_CHECKING_Q1 IS NULL AND TRANSACTION_AMOUNT_CHECKING_Q2 IS  NULL ) THEN TRANSACTION_AMOUNT_CHECKING_Q1 else (ISNULL(TRANSACTION_AMOUNT_CHECKING_Q1,0) - ISNULL(TRANSACTION_AMOUNT_CHECKING_Q2,0)) end DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2
			  , CASE WHEN (TRANSACTION_AMOUNT_CHECKING_Q1 IS NULL AND TRANSACTION_AMOUNT_CHECKING_Q3 IS  NULL ) THEN TRANSACTION_AMOUNT_CHECKING_Q1 else (ISNULL(TRANSACTION_AMOUNT_CHECKING_Q1,0) - ISNULL(TRANSACTION_AMOUNT_CHECKING_Q3,0)) end DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3
			  --, CASE WHEN (TRANSACTION_AMOUNT_CHECKING_Q1 IS NULL AND TRANSACTION_AMOUNT_CHECKING_Q4 IS  NULL ) THEN TRANSACTION_AMOUNT_CHECKING_Q1 else (ISNULL(TRANSACTION_AMOUNT_CHECKING_Q1,0) - ISNULL(TRANSACTION_AMOUNT_CHECKING_Q4,0)) end DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q4
			  , [AVG_TRANSACTION_CHECKING_Q1]
			  , CASE WHEN (AVG_TRANSACTION_CHECKING_Q1 IS NULL AND AVG_TRANSACTION_CHECKING_Q2 IS  NULL ) THEN AVG_TRANSACTION_CHECKING_Q1 else (ISNULL(AVG_TRANSACTION_CHECKING_Q1,0)  - ISNULL(AVG_TRANSACTION_CHECKING_Q2,0)) end DFT_AVG_TRANSACTION_CHECKING_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_CHECKING_Q1 IS NULL AND AVG_TRANSACTION_CHECKING_Q3 IS  NULL ) THEN AVG_TRANSACTION_CHECKING_Q1 else (ISNULL(AVG_TRANSACTION_CHECKING_Q1,0)  - ISNULL(AVG_TRANSACTION_CHECKING_Q3,0)) end DFT_AVG_TRANSACTION_CHECKING_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_CHECKING_Q1 IS NULL AND AVG_TRANSACTION_CHECKING_Q4 IS  NULL ) THEN AVG_TRANSACTION_CHECKING_Q1 else (ISNULL(AVG_TRANSACTION_CHECKING_Q1,0)  - ISNULL(AVG_TRANSACTION_CHECKING_Q4,0)) end DFT_AVG_TRANSACTION_CHECKING_Q1_Q4
			  , [DEPOSITED_AMOUNT_CHECKING_Q1] 
			  , CASE WHEN (AVG_TRANSACTION_CHECKING_Q1 IS NULL AND AVG_TRANSACTION_CHECKING_Q2 IS  NULL ) THEN AVG_TRANSACTION_CHECKING_Q1 else (ISNULL(DEPOSITED_AMOUNT_CHECKING_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_CHECKING_Q2,0)) end DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_CHECKING_Q1 IS NULL AND AVG_TRANSACTION_CHECKING_Q3 IS  NULL ) THEN AVG_TRANSACTION_CHECKING_Q1 else (ISNULL(DEPOSITED_AMOUNT_CHECKING_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_CHECKING_Q3,0)) end DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_CHECKING_Q1 IS NULL AND AVG_TRANSACTION_CHECKING_Q4 IS  NULL ) THEN AVG_TRANSACTION_CHECKING_Q1 else (ISNULL(DEPOSITED_AMOUNT_CHECKING_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_CHECKING_Q4,0)) end DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q4
			  , [DEPOSITED_COUNT_CHECKING_Q1]
			  , CASE WHEN (DEPOSITED_COUNT_CHECKING_Q1 IS NULL AND DEPOSITED_COUNT_CHECKING_Q2 IS  NULL ) THEN DEPOSITED_COUNT_CHECKING_Q1 else (ISNULL(DEPOSITED_COUNT_CHECKING_Q1,0) - ISNULL(DEPOSITED_COUNT_CHECKING_Q2,0)) end [DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2]
			  , CASE WHEN (DEPOSITED_COUNT_CHECKING_Q1 IS NULL AND DEPOSITED_COUNT_CHECKING_Q3 IS  NULL ) THEN DEPOSITED_COUNT_CHECKING_Q1 else (ISNULL(DEPOSITED_COUNT_CHECKING_Q1,0) - ISNULL(DEPOSITED_COUNT_CHECKING_Q3,0)) end [DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3]
			  --, CASE WHEN (DEPOSITED_COUNT_CHECKING_Q1 IS NULL AND DEPOSITED_COUNT_CHECKING_Q4 IS  NULL ) THEN DEPOSITED_COUNT_CHECKING_Q1 else (ISNULL(DEPOSITED_COUNT_CHECKING_Q1,0) - ISNULL(DEPOSITED_COUNT_CHECKING_Q4,0)) end [DFT_DEPOSITED_COUNT_CHECKING_Q1_Q4]
			  , [WITHDRAWAL_AMOUNT_CHECKING_Q1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_CHECKING_Q1 IS NULL AND WITHDRAWAL_AMOUNT_CHECKING_Q2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_CHECKING_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_CHECKING_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_CHECKING_Q2,0)) end [DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_CHECKING_Q1 IS NULL AND WITHDRAWAL_AMOUNT_CHECKING_Q3 IS  NULL ) THEN WITHDRAWAL_AMOUNT_CHECKING_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_CHECKING_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_CHECKING_Q3,0)) end [DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_AMOUNT_CHECKING_Q1 IS NULL AND WITHDRAWAL_AMOUNT_CHECKING_Q4 IS  NULL ) THEN WITHDRAWAL_AMOUNT_CHECKING_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_CHECKING_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_CHECKING_Q4,0)) end [DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q4]
			  , [WITHDRAWAL_COUNT_CHECKING_Q1]
			  , CASE WHEN (WITHDRAWAL_COUNT_CHECKING_Q1 IS NULL AND WITHDRAWAL_COUNT_CHECKING_Q2 IS  NULL ) THEN WITHDRAWAL_COUNT_CHECKING_Q1 else (ISNULL(WITHDRAWAL_COUNT_CHECKING_Q1,0) - ISNULL(WITHDRAWAL_COUNT_CHECKING_Q2,0)) end [DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_COUNT_CHECKING_Q1 IS NULL AND WITHDRAWAL_COUNT_CHECKING_Q3 IS  NULL ) THEN WITHDRAWAL_COUNT_CHECKING_Q1 else (ISNULL(WITHDRAWAL_COUNT_CHECKING_Q1,0) - ISNULL(WITHDRAWAL_COUNT_CHECKING_Q3,0)) end [DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_COUNT_CHECKING_Q1 IS NULL AND WITHDRAWAL_COUNT_CHECKING_Q4 IS  NULL ) THEN WITHDRAWAL_COUNT_CHECKING_Q1 else (ISNULL(WITHDRAWAL_COUNT_CHECKING_Q1,0) - ISNULL(WITHDRAWAL_COUNT_CHECKING_Q4,0)) end [DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q4]
			  , [SUM_INTEREST_CHECKING_Q1]
			  , CASE WHEN (SUM_INTEREST_CHECKING_Q1 IS NULL AND SUM_INTEREST_CHECKING_Q2 IS  NULL ) THEN SUM_INTEREST_CHECKING_Q1 else (ISNULL(SUM_INTEREST_CHECKING_Q1,0) - ISNULL(SUM_INTEREST_CHECKING_Q2,0)) end [DFT_SUM_INTEREST_CHECKING_Q1_Q2]
			  , CASE WHEN (SUM_INTEREST_CHECKING_Q1 IS NULL AND SUM_INTEREST_CHECKING_Q3 IS  NULL ) THEN SUM_INTEREST_CHECKING_Q1 else (ISNULL(SUM_INTEREST_CHECKING_Q1,0) - ISNULL(SUM_INTEREST_CHECKING_Q3,0)) end [DFT_SUM_INTEREST_CHECKING_Q1_Q3]
			  --, CASE WHEN (SUM_INTEREST_CHECKING_Q1 IS NULL AND SUM_INTEREST_CHECKING_Q4 IS  NULL ) THEN SUM_INTEREST_CHECKING_Q1 else (ISNULL(SUM_INTEREST_CHECKING_Q1,0) - ISNULL(SUM_INTEREST_CHECKING_Q4,0)) end [DFT_SUM_INTEREST_CHECKING_Q1_Q4]

		      , [TRANSACTION_COUNT_CERTIFICATES_Q1] 
			  , CASE WHEN ( TRANSACTION_COUNT_CERTIFICATES_Q1 IS NULL AND TRANSACTION_COUNT_CERTIFICATES_Q2 IS  NULL ) THEN TRANSACTION_COUNT_CERTIFICATES_Q1 else (ISNULL(TRANSACTION_COUNT_CERTIFICATES_Q1,0) - ISNULL(TRANSACTION_COUNT_CERTIFICATES_Q2,0)) end DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q2
			  , CASE WHEN ( TRANSACTION_COUNT_CERTIFICATES_Q1 IS NULL AND TRANSACTION_COUNT_CERTIFICATES_Q3 IS  NULL ) THEN TRANSACTION_COUNT_CERTIFICATES_Q1 else (ISNULL(TRANSACTION_COUNT_CERTIFICATES_Q1,0) - ISNULL(TRANSACTION_COUNT_CERTIFICATES_Q3,0)) end DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q3
			  --, CASE WHEN ( TRANSACTION_COUNT_CERTIFICATES_Q1 IS NULL AND TRANSACTION_COUNT_CERTIFICATES_Q4 IS  NULL ) THEN TRANSACTION_COUNT_CERTIFICATES_Q1 else (ISNULL(TRANSACTION_COUNT_CERTIFICATES_Q1,0) - ISNULL(TRANSACTION_COUNT_CERTIFICATES_Q4,0)) end DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q4
			  , [TRANSACTION_AMOUNT_CERTIFICATES_Q1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_CERTIFICATES_Q1 IS NULL AND TRANSACTION_AMOUNT_CERTIFICATES_Q2 IS  NULL ) THEN TRANSACTION_AMOUNT_CERTIFICATES_Q1 else (ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_Q1,0) - ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_Q2,0)) end DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q2
			  , CASE WHEN (TRANSACTION_AMOUNT_CERTIFICATES_Q1 IS NULL AND TRANSACTION_AMOUNT_CERTIFICATES_Q3 IS  NULL ) THEN TRANSACTION_AMOUNT_CERTIFICATES_Q1 else (ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_Q1,0) - ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_Q3,0)) end DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q3
			  --, CASE WHEN (TRANSACTION_AMOUNT_CERTIFICATES_Q1 IS NULL AND TRANSACTION_AMOUNT_CERTIFICATES_Q4 IS  NULL ) THEN TRANSACTION_AMOUNT_CERTIFICATES_Q1 else (ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_Q1,0) - ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_Q4,0)) end DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q4
			  , [AVG_TRANSACTION_CERTIFICATES_Q1]
			  , CASE WHEN (AVG_TRANSACTION_CERTIFICATES_Q1 IS NULL AND AVG_TRANSACTION_CERTIFICATES_Q2 IS  NULL ) THEN AVG_TRANSACTION_CERTIFICATES_Q1 else (ISNULL(AVG_TRANSACTION_CERTIFICATES_Q1,0)  - ISNULL(AVG_TRANSACTION_CERTIFICATES_Q2,0)) end DFT_AVG_TRANSACTION_CERTIFICATES_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_CERTIFICATES_Q1 IS NULL AND AVG_TRANSACTION_CERTIFICATES_Q3 IS  NULL ) THEN AVG_TRANSACTION_CERTIFICATES_Q1 else (ISNULL(AVG_TRANSACTION_CERTIFICATES_Q1,0)  - ISNULL(AVG_TRANSACTION_CERTIFICATES_Q3,0)) end DFT_AVG_TRANSACTION_CERTIFICATES_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_CERTIFICATES_Q1 IS NULL AND AVG_TRANSACTION_CERTIFICATES_Q4 IS  NULL ) THEN AVG_TRANSACTION_CERTIFICATES_Q1 else (ISNULL(AVG_TRANSACTION_CERTIFICATES_Q1,0)  - ISNULL(AVG_TRANSACTION_CERTIFICATES_Q4,0)) end DFT_AVG_TRANSACTION_CERTIFICATES_Q1_Q4
			  , [DEPOSITED_AMOUNT_CERTIFICATES_Q1] 
			  , CASE WHEN (AVG_TRANSACTION_CERTIFICATES_Q1 IS NULL AND AVG_TRANSACTION_CERTIFICATES_Q2 IS  NULL ) THEN AVG_TRANSACTION_CERTIFICATES_Q1 else (ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_Q2,0)) end DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_CERTIFICATES_Q1 IS NULL AND AVG_TRANSACTION_CERTIFICATES_Q3 IS  NULL ) THEN AVG_TRANSACTION_CERTIFICATES_Q1 else (ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_Q3,0)) end DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_CERTIFICATES_Q1 IS NULL AND AVG_TRANSACTION_CERTIFICATES_Q4 IS  NULL ) THEN AVG_TRANSACTION_CERTIFICATES_Q1 else (ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_Q4,0)) end DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q4
			  , [DEPOSITED_COUNT_CERTIFICATES_Q1]
			  , CASE WHEN (DEPOSITED_COUNT_CERTIFICATES_Q1 IS NULL AND DEPOSITED_COUNT_CERTIFICATES_Q2 IS  NULL ) THEN DEPOSITED_COUNT_CERTIFICATES_Q1 else (ISNULL(DEPOSITED_COUNT_CERTIFICATES_Q1,0) - ISNULL(DEPOSITED_COUNT_CERTIFICATES_Q2,0)) end [DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q2]
			  , CASE WHEN (DEPOSITED_COUNT_CERTIFICATES_Q1 IS NULL AND DEPOSITED_COUNT_CERTIFICATES_Q3 IS  NULL ) THEN DEPOSITED_COUNT_CERTIFICATES_Q1 else (ISNULL(DEPOSITED_COUNT_CERTIFICATES_Q1,0) - ISNULL(DEPOSITED_COUNT_CERTIFICATES_Q3,0)) end [DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q3]
			  --, CASE WHEN (DEPOSITED_COUNT_CERTIFICATES_Q1 IS NULL AND DEPOSITED_COUNT_CERTIFICATES_Q4 IS  NULL ) THEN DEPOSITED_COUNT_CERTIFICATES_Q1 else (ISNULL(DEPOSITED_COUNT_CERTIFICATES_Q1,0) - ISNULL(DEPOSITED_COUNT_CERTIFICATES_Q4,0)) end [DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q4]
			  , [WITHDRAWAL_AMOUNT_CERTIFICATES_Q1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_CERTIFICATES_Q1 IS NULL AND WITHDRAWAL_AMOUNT_CERTIFICATES_Q2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_CERTIFICATES_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_Q2,0)) end [DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_CERTIFICATES_Q1 IS NULL AND WITHDRAWAL_AMOUNT_CERTIFICATES_Q3 IS  NULL ) THEN WITHDRAWAL_AMOUNT_CERTIFICATES_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_Q3,0)) end [DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_AMOUNT_CERTIFICATES_Q1 IS NULL AND WITHDRAWAL_AMOUNT_CERTIFICATES_Q4 IS  NULL ) THEN WITHDRAWAL_AMOUNT_CERTIFICATES_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_Q4,0)) end [DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q4]
			  , [WITHDRAWAL_COUNT_CERTIFICATES_Q1]
			  , CASE WHEN (WITHDRAWAL_COUNT_CERTIFICATES_Q1 IS NULL AND WITHDRAWAL_COUNT_CERTIFICATES_Q2 IS  NULL ) THEN WITHDRAWAL_COUNT_CERTIFICATES_Q1 else (ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_Q1,0) - ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_Q2,0)) end [DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_COUNT_CERTIFICATES_Q1 IS NULL AND WITHDRAWAL_COUNT_CERTIFICATES_Q3 IS  NULL ) THEN WITHDRAWAL_COUNT_CERTIFICATES_Q1 else (ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_Q1,0) - ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_Q3,0)) end [DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_COUNT_CERTIFICATES_Q1 IS NULL AND WITHDRAWAL_COUNT_CERTIFICATES_Q4 IS  NULL ) THEN WITHDRAWAL_COUNT_CERTIFICATES_Q1 else (ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_Q1,0) - ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_Q4,0)) end [DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q4]
			  , [SUM_INTEREST_CERTIFICATES_Q1]
			  , CASE WHEN (SUM_INTEREST_CERTIFICATES_Q1 IS NULL AND SUM_INTEREST_CERTIFICATES_Q2 IS  NULL ) THEN SUM_INTEREST_CERTIFICATES_Q1 else (ISNULL(SUM_INTEREST_CERTIFICATES_Q1,0) - ISNULL(SUM_INTEREST_CERTIFICATES_Q2,0)) end [DFT_SUM_INTEREST_CERTIFICATES_Q1_Q2]
			  , CASE WHEN (SUM_INTEREST_CERTIFICATES_Q1 IS NULL AND SUM_INTEREST_CERTIFICATES_Q3 IS  NULL ) THEN SUM_INTEREST_CERTIFICATES_Q1 else (ISNULL(SUM_INTEREST_CERTIFICATES_Q1,0) - ISNULL(SUM_INTEREST_CERTIFICATES_Q3,0)) end [DFT_SUM_INTEREST_CERTIFICATES_Q1_Q3]
			  --, CASE WHEN (SUM_INTEREST_CERTIFICATES_Q1 IS NULL AND SUM_INTEREST_CERTIFICATES_Q4 IS  NULL ) THEN SUM_INTEREST_CERTIFICATES_Q1 else (ISNULL(SUM_INTEREST_CERTIFICATES_Q1,0) - ISNULL(SUM_INTEREST_CERTIFICATES_Q4,0)) end [DFT_SUM_INTEREST_CERTIFICATES_Q1_Q4]

		      , [TRANSACTION_COUNT_MONEYMARKET_Q1] 
			  , CASE WHEN ( TRANSACTION_COUNT_MONEYMARKET_Q1 IS NULL AND TRANSACTION_COUNT_MONEYMARKET_Q2 IS  NULL ) THEN TRANSACTION_COUNT_MONEYMARKET_Q1 else (ISNULL(TRANSACTION_COUNT_MONEYMARKET_Q1,0) - ISNULL(TRANSACTION_COUNT_MONEYMARKET_Q2,0)) end DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q2
			  , CASE WHEN ( TRANSACTION_COUNT_MONEYMARKET_Q1 IS NULL AND TRANSACTION_COUNT_MONEYMARKET_Q3 IS  NULL ) THEN TRANSACTION_COUNT_MONEYMARKET_Q1 else (ISNULL(TRANSACTION_COUNT_MONEYMARKET_Q1,0) - ISNULL(TRANSACTION_COUNT_MONEYMARKET_Q3,0)) end DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q3
			  --, CASE WHEN ( TRANSACTION_COUNT_MONEYMARKET_Q1 IS NULL AND TRANSACTION_COUNT_MONEYMARKET_Q4 IS  NULL ) THEN TRANSACTION_COUNT_MONEYMARKET_Q1 else (ISNULL(TRANSACTION_COUNT_MONEYMARKET_Q1,0) - ISNULL(TRANSACTION_COUNT_MONEYMARKET_Q4,0)) end DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q4
			  , [TRANSACTION_AMOUNT_MONEYMARKET_Q1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_MONEYMARKET_Q1 IS NULL AND TRANSACTION_AMOUNT_MONEYMARKET_Q2 IS  NULL ) THEN TRANSACTION_AMOUNT_MONEYMARKET_Q1 else (ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_Q1,0) - ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_Q2,0)) end DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q2
			  , CASE WHEN (TRANSACTION_AMOUNT_MONEYMARKET_Q1 IS NULL AND TRANSACTION_AMOUNT_MONEYMARKET_Q3 IS  NULL ) THEN TRANSACTION_AMOUNT_MONEYMARKET_Q1 else (ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_Q1,0) - ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_Q3,0)) end DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q3
			  --, CASE WHEN (TRANSACTION_AMOUNT_MONEYMARKET_Q1 IS NULL AND TRANSACTION_AMOUNT_MONEYMARKET_Q4 IS  NULL ) THEN TRANSACTION_AMOUNT_MONEYMARKET_Q1 else (ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_Q1,0) - ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_Q4,0)) end DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q4
			  , [AVG_TRANSACTION_MONEYMARKET_Q1]
			  , CASE WHEN (AVG_TRANSACTION_MONEYMARKET_Q1 IS NULL AND AVG_TRANSACTION_MONEYMARKET_Q2 IS  NULL ) THEN AVG_TRANSACTION_MONEYMARKET_Q1 else (ISNULL(AVG_TRANSACTION_MONEYMARKET_Q1,0)  - ISNULL(AVG_TRANSACTION_MONEYMARKET_Q2,0)) end DFT_AVG_TRANSACTION_MONEYMARKET_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_MONEYMARKET_Q1 IS NULL AND AVG_TRANSACTION_MONEYMARKET_Q3 IS  NULL ) THEN AVG_TRANSACTION_MONEYMARKET_Q1 else (ISNULL(AVG_TRANSACTION_MONEYMARKET_Q1,0)  - ISNULL(AVG_TRANSACTION_MONEYMARKET_Q3,0)) end DFT_AVG_TRANSACTION_MONEYMARKET_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_MONEYMARKET_Q1 IS NULL AND AVG_TRANSACTION_MONEYMARKET_Q4 IS  NULL ) THEN AVG_TRANSACTION_MONEYMARKET_Q1 else (ISNULL(AVG_TRANSACTION_MONEYMARKET_Q1,0)  - ISNULL(AVG_TRANSACTION_MONEYMARKET_Q4,0)) end DFT_AVG_TRANSACTION_MONEYMARKET_Q1_Q4
			  , [DEPOSITED_AMOUNT_MONEYMARKET_Q1] 
			  , CASE WHEN (AVG_TRANSACTION_MONEYMARKET_Q1 IS NULL AND AVG_TRANSACTION_MONEYMARKET_Q2 IS  NULL ) THEN AVG_TRANSACTION_MONEYMARKET_Q1 else (ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_Q2,0)) end DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_MONEYMARKET_Q1 IS NULL AND AVG_TRANSACTION_MONEYMARKET_Q3 IS  NULL ) THEN AVG_TRANSACTION_MONEYMARKET_Q1 else (ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_Q3,0)) end DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_MONEYMARKET_Q1 IS NULL AND AVG_TRANSACTION_MONEYMARKET_Q4 IS  NULL ) THEN AVG_TRANSACTION_MONEYMARKET_Q1 else (ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_Q4,0)) end DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q4
			  , [DEPOSITED_COUNT_MONEYMARKET_Q1]
			  , CASE WHEN (DEPOSITED_COUNT_MONEYMARKET_Q1 IS NULL AND DEPOSITED_COUNT_MONEYMARKET_Q2 IS  NULL ) THEN DEPOSITED_COUNT_MONEYMARKET_Q1 else (ISNULL(DEPOSITED_COUNT_MONEYMARKET_Q1,0) - ISNULL(DEPOSITED_COUNT_MONEYMARKET_Q2,0)) end [DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q2]
			  , CASE WHEN (DEPOSITED_COUNT_MONEYMARKET_Q1 IS NULL AND DEPOSITED_COUNT_MONEYMARKET_Q3 IS  NULL ) THEN DEPOSITED_COUNT_MONEYMARKET_Q1 else (ISNULL(DEPOSITED_COUNT_MONEYMARKET_Q1,0) - ISNULL(DEPOSITED_COUNT_MONEYMARKET_Q3,0)) end [DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q3]
			  --, CASE WHEN (DEPOSITED_COUNT_MONEYMARKET_Q1 IS NULL AND DEPOSITED_COUNT_MONEYMARKET_Q4 IS  NULL ) THEN DEPOSITED_COUNT_MONEYMARKET_Q1 else (ISNULL(DEPOSITED_COUNT_MONEYMARKET_Q1,0) - ISNULL(DEPOSITED_COUNT_MONEYMARKET_Q4,0)) end [DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q4]
			  , [WITHDRAWAL_AMOUNT_MONEYMARKET_Q1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_MONEYMARKET_Q1 IS NULL AND WITHDRAWAL_AMOUNT_MONEYMARKET_Q2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_MONEYMARKET_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_Q2,0)) end [DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_MONEYMARKET_Q1 IS NULL AND WITHDRAWAL_AMOUNT_MONEYMARKET_Q3 IS  NULL ) THEN WITHDRAWAL_AMOUNT_MONEYMARKET_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_Q3,0)) end [DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_AMOUNT_MONEYMARKET_Q1 IS NULL AND WITHDRAWAL_AMOUNT_MONEYMARKET_Q4 IS  NULL ) THEN WITHDRAWAL_AMOUNT_MONEYMARKET_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_Q4,0)) end [DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q4]
			  , [WITHDRAWAL_COUNT_MONEYMARKET_Q1]
			  , CASE WHEN (WITHDRAWAL_COUNT_MONEYMARKET_Q1 IS NULL AND WITHDRAWAL_COUNT_MONEYMARKET_Q2 IS  NULL ) THEN WITHDRAWAL_COUNT_MONEYMARKET_Q1 else (ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_Q1,0) - ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_Q2,0)) end [DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_COUNT_MONEYMARKET_Q1 IS NULL AND WITHDRAWAL_COUNT_MONEYMARKET_Q3 IS  NULL ) THEN WITHDRAWAL_COUNT_MONEYMARKET_Q1 else (ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_Q1,0) - ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_Q3,0)) end [DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_COUNT_MONEYMARKET_Q1 IS NULL AND WITHDRAWAL_COUNT_MONEYMARKET_Q4 IS  NULL ) THEN WITHDRAWAL_COUNT_MONEYMARKET_Q1 else (ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_Q1,0) - ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_Q4,0)) end [DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q4]
			  , [SUM_INTEREST_MONEYMARKET_Q1]
			  , CASE WHEN (SUM_INTEREST_MONEYMARKET_Q1 IS NULL AND SUM_INTEREST_MONEYMARKET_Q2 IS  NULL ) THEN SUM_INTEREST_MONEYMARKET_Q1 else (ISNULL(SUM_INTEREST_MONEYMARKET_Q1,0) - ISNULL(SUM_INTEREST_MONEYMARKET_Q2,0)) end [DFT_SUM_INTEREST_MONEYMARKET_Q1_Q2]
			  , CASE WHEN (SUM_INTEREST_MONEYMARKET_Q1 IS NULL AND SUM_INTEREST_MONEYMARKET_Q3 IS  NULL ) THEN SUM_INTEREST_MONEYMARKET_Q1 else (ISNULL(SUM_INTEREST_MONEYMARKET_Q1,0) - ISNULL(SUM_INTEREST_MONEYMARKET_Q3,0)) end [DFT_SUM_INTEREST_MONEYMARKET_Q1_Q3]
			  --, CASE WHEN (SUM_INTEREST_MONEYMARKET_Q1 IS NULL AND SUM_INTEREST_MONEYMARKET_Q4 IS  NULL ) THEN SUM_INTEREST_MONEYMARKET_Q1 else (ISNULL(SUM_INTEREST_MONEYMARKET_Q1,0) - ISNULL(SUM_INTEREST_MONEYMARKET_Q4,0)) end [DFT_SUM_INTEREST_MONEYMARKET_Q1_Q4]

		      , [TRANSACTION_COUNT_IRA_Q1] 
			  , CASE WHEN ( TRANSACTION_COUNT_IRA_Q1 IS NULL AND TRANSACTION_COUNT_IRA_Q2 IS  NULL ) THEN TRANSACTION_COUNT_IRA_Q1 else (ISNULL(TRANSACTION_COUNT_IRA_Q1,0) - ISNULL(TRANSACTION_COUNT_IRA_Q2,0)) end DFT_TRANSACTION_COUNT_IRA_Q1_Q2
			  , CASE WHEN ( TRANSACTION_COUNT_IRA_Q1 IS NULL AND TRANSACTION_COUNT_IRA_Q3 IS  NULL ) THEN TRANSACTION_COUNT_IRA_Q1 else (ISNULL(TRANSACTION_COUNT_IRA_Q1,0) - ISNULL(TRANSACTION_COUNT_IRA_Q3,0)) end DFT_TRANSACTION_COUNT_IRA_Q1_Q3
			  --, CASE WHEN ( TRANSACTION_COUNT_IRA_Q1 IS NULL AND TRANSACTION_COUNT_IRA_Q4 IS  NULL ) THEN TRANSACTION_COUNT_IRA_Q1 else (ISNULL(TRANSACTION_COUNT_IRA_Q1,0) - ISNULL(TRANSACTION_COUNT_IRA_Q4,0)) end DFT_TRANSACTION_COUNT_IRA_Q1_Q4
			  , [TRANSACTION_AMOUNT_IRA_Q1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_IRA_Q1 IS NULL AND TRANSACTION_AMOUNT_IRA_Q2 IS  NULL ) THEN TRANSACTION_AMOUNT_IRA_Q1 else (ISNULL(TRANSACTION_AMOUNT_IRA_Q1,0) - ISNULL(TRANSACTION_AMOUNT_IRA_Q2,0)) end DFT_TRANSACTION_AMOUNT_IRA_Q1_Q2
			  , CASE WHEN (TRANSACTION_AMOUNT_IRA_Q1 IS NULL AND TRANSACTION_AMOUNT_IRA_Q3 IS  NULL ) THEN TRANSACTION_AMOUNT_IRA_Q1 else (ISNULL(TRANSACTION_AMOUNT_IRA_Q1,0) - ISNULL(TRANSACTION_AMOUNT_IRA_Q3,0)) end DFT_TRANSACTION_AMOUNT_IRA_Q1_Q3
			  --, CASE WHEN (TRANSACTION_AMOUNT_IRA_Q1 IS NULL AND TRANSACTION_AMOUNT_IRA_Q4 IS  NULL ) THEN TRANSACTION_AMOUNT_IRA_Q1 else (ISNULL(TRANSACTION_AMOUNT_IRA_Q1,0) - ISNULL(TRANSACTION_AMOUNT_IRA_Q4,0)) end DFT_TRANSACTION_AMOUNT_IRA_Q1_Q4
			  , [AVG_TRANSACTION_IRA_Q1]
			  , CASE WHEN (AVG_TRANSACTION_IRA_Q1 IS NULL AND AVG_TRANSACTION_IRA_Q2 IS  NULL ) THEN AVG_TRANSACTION_IRA_Q1 else (ISNULL(AVG_TRANSACTION_IRA_Q1,0)  - ISNULL(AVG_TRANSACTION_IRA_Q2,0)) end DFT_AVG_TRANSACTION_IRA_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_IRA_Q1 IS NULL AND AVG_TRANSACTION_IRA_Q3 IS  NULL ) THEN AVG_TRANSACTION_IRA_Q1 else (ISNULL(AVG_TRANSACTION_IRA_Q1,0)  - ISNULL(AVG_TRANSACTION_IRA_Q3,0)) end DFT_AVG_TRANSACTION_IRA_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_IRA_Q1 IS NULL AND AVG_TRANSACTION_IRA_Q4 IS  NULL ) THEN AVG_TRANSACTION_IRA_Q1 else (ISNULL(AVG_TRANSACTION_IRA_Q1,0)  - ISNULL(AVG_TRANSACTION_IRA_Q4,0)) end DFT_AVG_TRANSACTION_IRA_Q1_Q4
			  , [DEPOSITED_AMOUNT_IRA_Q1] 
			  , CASE WHEN (AVG_TRANSACTION_IRA_Q1 IS NULL AND AVG_TRANSACTION_IRA_Q2 IS  NULL ) THEN AVG_TRANSACTION_IRA_Q1 else (ISNULL(DEPOSITED_AMOUNT_IRA_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_IRA_Q2,0)) end DFT_DEPOSITED_AMOUNT_IRA_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_IRA_Q1 IS NULL AND AVG_TRANSACTION_IRA_Q3 IS  NULL ) THEN AVG_TRANSACTION_IRA_Q1 else (ISNULL(DEPOSITED_AMOUNT_IRA_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_IRA_Q3,0)) end DFT_DEPOSITED_AMOUNT_IRA_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_IRA_Q1 IS NULL AND AVG_TRANSACTION_IRA_Q4 IS  NULL ) THEN AVG_TRANSACTION_IRA_Q1 else (ISNULL(DEPOSITED_AMOUNT_IRA_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_IRA_Q4,0)) end DFT_DEPOSITED_AMOUNT_IRA_Q1_Q4
			  , [DEPOSITED_COUNT_IRA_Q1]
			  , CASE WHEN (DEPOSITED_COUNT_IRA_Q1 IS NULL AND DEPOSITED_COUNT_IRA_Q2 IS  NULL ) THEN DEPOSITED_COUNT_IRA_Q1 else (ISNULL(DEPOSITED_COUNT_IRA_Q1,0) - ISNULL(DEPOSITED_COUNT_IRA_Q2,0)) end [DFT_DEPOSITED_COUNT_IRA_Q1_Q2]
			  , CASE WHEN (DEPOSITED_COUNT_IRA_Q1 IS NULL AND DEPOSITED_COUNT_IRA_Q3 IS  NULL ) THEN DEPOSITED_COUNT_IRA_Q1 else (ISNULL(DEPOSITED_COUNT_IRA_Q1,0) - ISNULL(DEPOSITED_COUNT_IRA_Q3,0)) end [DFT_DEPOSITED_COUNT_IRA_Q1_Q3]
			  --, CASE WHEN (DEPOSITED_COUNT_IRA_Q1 IS NULL AND DEPOSITED_COUNT_IRA_Q4 IS  NULL ) THEN DEPOSITED_COUNT_IRA_Q1 else (ISNULL(DEPOSITED_COUNT_IRA_Q1,0) - ISNULL(DEPOSITED_COUNT_IRA_Q4,0)) end [DFT_DEPOSITED_COUNT_IRA_Q1_Q4]
			  , [WITHDRAWAL_AMOUNT_IRA_Q1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_IRA_Q1 IS NULL AND WITHDRAWAL_AMOUNT_IRA_Q2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_IRA_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_IRA_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_IRA_Q2,0)) end [DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_IRA_Q1 IS NULL AND WITHDRAWAL_AMOUNT_IRA_Q3 IS  NULL ) THEN WITHDRAWAL_AMOUNT_IRA_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_IRA_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_IRA_Q3,0)) end [DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_AMOUNT_IRA_Q1 IS NULL AND WITHDRAWAL_AMOUNT_IRA_Q4 IS  NULL ) THEN WITHDRAWAL_AMOUNT_IRA_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_IRA_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_IRA_Q4,0)) end [DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q4]
			  , [WITHDRAWAL_COUNT_IRA_Q1]
			  , CASE WHEN (WITHDRAWAL_COUNT_IRA_Q1 IS NULL AND WITHDRAWAL_COUNT_IRA_Q2 IS  NULL ) THEN WITHDRAWAL_COUNT_IRA_Q1 else (ISNULL(WITHDRAWAL_COUNT_IRA_Q1,0) - ISNULL(WITHDRAWAL_COUNT_IRA_Q2,0)) end [DFT_WITHDRAWAL_COUNT_IRA_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_COUNT_IRA_Q1 IS NULL AND WITHDRAWAL_COUNT_IRA_Q3 IS  NULL ) THEN WITHDRAWAL_COUNT_IRA_Q1 else (ISNULL(WITHDRAWAL_COUNT_IRA_Q1,0) - ISNULL(WITHDRAWAL_COUNT_IRA_Q3,0)) end [DFT_WITHDRAWAL_COUNT_IRA_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_COUNT_IRA_Q1 IS NULL AND WITHDRAWAL_COUNT_IRA_Q4 IS  NULL ) THEN WITHDRAWAL_COUNT_IRA_Q1 else (ISNULL(WITHDRAWAL_COUNT_IRA_Q1,0) - ISNULL(WITHDRAWAL_COUNT_IRA_Q4,0)) end [DFT_WITHDRAWAL_COUNT_IRA_Q1_Q4]
			  , [SUM_INTEREST_IRA_Q1]
			  , CASE WHEN (SUM_INTEREST_IRA_Q1 IS NULL AND SUM_INTEREST_IRA_Q2 IS  NULL ) THEN SUM_INTEREST_IRA_Q1 else (ISNULL(SUM_INTEREST_IRA_Q1,0) - ISNULL(SUM_INTEREST_IRA_Q2,0)) end [DFT_SUM_INTEREST_IRA_Q1_Q2]
			  , CASE WHEN (SUM_INTEREST_IRA_Q1 IS NULL AND SUM_INTEREST_IRA_Q3 IS  NULL ) THEN SUM_INTEREST_IRA_Q1 else (ISNULL(SUM_INTEREST_IRA_Q1,0) - ISNULL(SUM_INTEREST_IRA_Q3,0)) end [DFT_SUM_INTEREST_IRA_Q1_Q3]
			  --, CASE WHEN (SUM_INTEREST_IRA_Q1 IS NULL AND SUM_INTEREST_IRA_Q4 IS  NULL ) THEN SUM_INTEREST_IRA_Q1 else (ISNULL(SUM_INTEREST_IRA_Q1,0) - ISNULL(SUM_INTEREST_IRA_Q4,0)) end [DFT_SUM_INTEREST_IRA_Q1_Q4]

		      , [TRANSACTION_COUNT_HSA_Q1] 
			  , CASE WHEN ( TRANSACTION_COUNT_HSA_Q1 IS NULL AND TRANSACTION_COUNT_HSA_Q2 IS  NULL ) THEN TRANSACTION_COUNT_HSA_Q1 else (ISNULL(TRANSACTION_COUNT_HSA_Q1,0) - ISNULL(TRANSACTION_COUNT_HSA_Q2,0)) end DFT_TRANSACTION_COUNT_HSA_Q1_Q2
			  , CASE WHEN ( TRANSACTION_COUNT_HSA_Q1 IS NULL AND TRANSACTION_COUNT_HSA_Q3 IS  NULL ) THEN TRANSACTION_COUNT_HSA_Q1 else (ISNULL(TRANSACTION_COUNT_HSA_Q1,0) - ISNULL(TRANSACTION_COUNT_HSA_Q3,0)) end DFT_TRANSACTION_COUNT_HSA_Q1_Q3
			  --, CASE WHEN ( TRANSACTION_COUNT_HSA_Q1 IS NULL AND TRANSACTION_COUNT_HSA_Q4 IS  NULL ) THEN TRANSACTION_COUNT_HSA_Q1 else (ISNULL(TRANSACTION_COUNT_HSA_Q1,0) - ISNULL(TRANSACTION_COUNT_HSA_Q4,0)) end DFT_TRANSACTION_COUNT_HSA_Q1_Q4
			  , [TRANSACTION_AMOUNT_HSA_Q1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_HSA_Q1 IS NULL AND TRANSACTION_AMOUNT_HSA_Q2 IS  NULL ) THEN TRANSACTION_AMOUNT_HSA_Q1 else (ISNULL(TRANSACTION_AMOUNT_HSA_Q1,0) - ISNULL(TRANSACTION_AMOUNT_HSA_Q2,0)) end DFT_TRANSACTION_AMOUNT_HSA_Q1_Q2
			  , CASE WHEN (TRANSACTION_AMOUNT_HSA_Q1 IS NULL AND TRANSACTION_AMOUNT_HSA_Q3 IS  NULL ) THEN TRANSACTION_AMOUNT_HSA_Q1 else (ISNULL(TRANSACTION_AMOUNT_HSA_Q1,0) - ISNULL(TRANSACTION_AMOUNT_HSA_Q3,0)) end DFT_TRANSACTION_AMOUNT_HSA_Q1_Q3
			  --, CASE WHEN (TRANSACTION_AMOUNT_HSA_Q1 IS NULL AND TRANSACTION_AMOUNT_HSA_Q4 IS  NULL ) THEN TRANSACTION_AMOUNT_HSA_Q1 else (ISNULL(TRANSACTION_AMOUNT_HSA_Q1,0) - ISNULL(TRANSACTION_AMOUNT_HSA_Q4,0)) end DFT_TRANSACTION_AMOUNT_HSA_Q1_Q4
			  , [AVG_TRANSACTION_HSA_Q1]
			  , CASE WHEN (AVG_TRANSACTION_HSA_Q1 IS NULL AND AVG_TRANSACTION_HSA_Q2 IS  NULL ) THEN AVG_TRANSACTION_HSA_Q1 else (ISNULL(AVG_TRANSACTION_HSA_Q1,0)  - ISNULL(AVG_TRANSACTION_HSA_Q2,0)) end DFT_AVG_TRANSACTION_HSA_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_HSA_Q1 IS NULL AND AVG_TRANSACTION_HSA_Q3 IS  NULL ) THEN AVG_TRANSACTION_HSA_Q1 else (ISNULL(AVG_TRANSACTION_HSA_Q1,0)  - ISNULL(AVG_TRANSACTION_HSA_Q3,0)) end DFT_AVG_TRANSACTION_HSA_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_HSA_Q1 IS NULL AND AVG_TRANSACTION_HSA_Q4 IS  NULL ) THEN AVG_TRANSACTION_HSA_Q1 else (ISNULL(AVG_TRANSACTION_HSA_Q1,0)  - ISNULL(AVG_TRANSACTION_HSA_Q4,0)) end DFT_AVG_TRANSACTION_HSA_Q1_Q4
			  , [DEPOSITED_AMOUNT_HSA_Q1] 
			  , CASE WHEN (AVG_TRANSACTION_HSA_Q1 IS NULL AND AVG_TRANSACTION_HSA_Q2 IS  NULL ) THEN AVG_TRANSACTION_HSA_Q1 else (ISNULL(DEPOSITED_AMOUNT_HSA_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_HSA_Q2,0)) end DFT_DEPOSITED_AMOUNT_HSA_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_HSA_Q1 IS NULL AND AVG_TRANSACTION_HSA_Q3 IS  NULL ) THEN AVG_TRANSACTION_HSA_Q1 else (ISNULL(DEPOSITED_AMOUNT_HSA_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_HSA_Q3,0)) end DFT_DEPOSITED_AMOUNT_HSA_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_HSA_Q1 IS NULL AND AVG_TRANSACTION_HSA_Q4 IS  NULL ) THEN AVG_TRANSACTION_HSA_Q1 else (ISNULL(DEPOSITED_AMOUNT_HSA_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_HSA_Q4,0)) end DFT_DEPOSITED_AMOUNT_HSA_Q1_Q4
			  , [DEPOSITED_COUNT_HSA_Q1]
			  , CASE WHEN (DEPOSITED_COUNT_HSA_Q1 IS NULL AND DEPOSITED_COUNT_HSA_Q2 IS  NULL ) THEN DEPOSITED_COUNT_HSA_Q1 else (ISNULL(DEPOSITED_COUNT_HSA_Q1,0) - ISNULL(DEPOSITED_COUNT_HSA_Q2,0)) end [DFT_DEPOSITED_COUNT_HSA_Q1_Q2]
			  , CASE WHEN (DEPOSITED_COUNT_HSA_Q1 IS NULL AND DEPOSITED_COUNT_HSA_Q3 IS  NULL ) THEN DEPOSITED_COUNT_HSA_Q1 else (ISNULL(DEPOSITED_COUNT_HSA_Q1,0) - ISNULL(DEPOSITED_COUNT_HSA_Q3,0)) end [DFT_DEPOSITED_COUNT_HSA_Q1_Q3]
			  --, CASE WHEN (DEPOSITED_COUNT_HSA_Q1 IS NULL AND DEPOSITED_COUNT_HSA_Q4 IS  NULL ) THEN DEPOSITED_COUNT_HSA_Q1 else (ISNULL(DEPOSITED_COUNT_HSA_Q1,0) - ISNULL(DEPOSITED_COUNT_HSA_Q4,0)) end [DFT_DEPOSITED_COUNT_HSA_Q1_Q4]
			  , [WITHDRAWAL_AMOUNT_HSA_Q1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_HSA_Q1 IS NULL AND WITHDRAWAL_AMOUNT_HSA_Q2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_HSA_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_HSA_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_HSA_Q2,0)) end [DFT_WITHDRAWAL_AMOUNT_HSA_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_HSA_Q1 IS NULL AND WITHDRAWAL_AMOUNT_HSA_Q3 IS  NULL ) THEN WITHDRAWAL_AMOUNT_HSA_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_HSA_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_HSA_Q3,0)) end [DFT_WITHDRAWAL_AMOUNT_HSA_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_AMOUNT_HSA_Q1 IS NULL AND WITHDRAWAL_AMOUNT_HSA_Q4 IS  NULL ) THEN WITHDRAWAL_AMOUNT_HSA_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_HSA_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_HSA_Q4,0)) end [DFT_WITHDRAWAL_AMOUNT_HSA_Q1_Q4]
			  , [WITHDRAWAL_COUNT_HSA_Q1]
			  , CASE WHEN (WITHDRAWAL_COUNT_HSA_Q1 IS NULL AND WITHDRAWAL_COUNT_HSA_Q2 IS  NULL ) THEN WITHDRAWAL_COUNT_HSA_Q1 else (ISNULL(WITHDRAWAL_COUNT_HSA_Q1,0) - ISNULL(WITHDRAWAL_COUNT_HSA_Q2,0)) end [DFT_WITHDRAWAL_COUNT_HSA_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_COUNT_HSA_Q1 IS NULL AND WITHDRAWAL_COUNT_HSA_Q3 IS  NULL ) THEN WITHDRAWAL_COUNT_HSA_Q1 else (ISNULL(WITHDRAWAL_COUNT_HSA_Q1,0) - ISNULL(WITHDRAWAL_COUNT_HSA_Q3,0)) end [DFT_WITHDRAWAL_COUNT_HSA_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_COUNT_HSA_Q1 IS NULL AND WITHDRAWAL_COUNT_HSA_Q4 IS  NULL ) THEN WITHDRAWAL_COUNT_HSA_Q1 else (ISNULL(WITHDRAWAL_COUNT_HSA_Q1,0) - ISNULL(WITHDRAWAL_COUNT_HSA_Q4,0)) end [DFT_WITHDRAWAL_COUNT_HSA_Q1_Q4]
			  , [SUM_INTEREST_HSA_Q1]
			  , CASE WHEN (SUM_INTEREST_HSA_Q1 IS NULL AND SUM_INTEREST_HSA_Q2 IS  NULL ) THEN SUM_INTEREST_HSA_Q1 else (ISNULL(SUM_INTEREST_HSA_Q1,0) - ISNULL(SUM_INTEREST_HSA_Q2,0)) end [DFT_SUM_INTEREST_HSA_Q1_Q2]
			  , CASE WHEN (SUM_INTEREST_HSA_Q1 IS NULL AND SUM_INTEREST_HSA_Q3 IS  NULL ) THEN SUM_INTEREST_HSA_Q1 else (ISNULL(SUM_INTEREST_HSA_Q1,0) - ISNULL(SUM_INTEREST_HSA_Q3,0)) end [DFT_SUM_INTEREST_HSA_Q1_Q3]
			  --, CASE WHEN (SUM_INTEREST_HSA_Q1 IS NULL AND SUM_INTEREST_HSA_Q4 IS  NULL ) THEN SUM_INTEREST_HSA_Q1 else (ISNULL(SUM_INTEREST_HSA_Q1,0) - ISNULL(SUM_INTEREST_HSA_Q4,0)) end [DFT_SUM_INTEREST_HSA_Q1_Q4]

		      , [TRANSACTION_COUNT_DEPOSITS_Q1] 
			  , CASE WHEN ( TRANSACTION_COUNT_DEPOSITS_Q1 IS NULL AND TRANSACTION_COUNT_DEPOSITS_Q2 IS  NULL ) THEN TRANSACTION_COUNT_DEPOSITS_Q1 else (ISNULL(TRANSACTION_COUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_COUNT_DEPOSITS_Q2,0)) end DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q2
			  , CASE WHEN ( TRANSACTION_COUNT_DEPOSITS_Q1 IS NULL AND TRANSACTION_COUNT_DEPOSITS_Q3 IS  NULL ) THEN TRANSACTION_COUNT_DEPOSITS_Q1 else (ISNULL(TRANSACTION_COUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_COUNT_DEPOSITS_Q3,0)) end DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3
			  --, CASE WHEN ( TRANSACTION_COUNT_DEPOSITS_Q1 IS NULL AND TRANSACTION_COUNT_DEPOSITS_Q4 IS  NULL ) THEN TRANSACTION_COUNT_DEPOSITS_Q1 else (ISNULL(TRANSACTION_COUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_COUNT_DEPOSITS_Q4,0)) end DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q4
			  , [TRANSACTION_AMOUNT_DEPOSITS_Q1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_DEPOSITS_Q1 IS NULL AND TRANSACTION_AMOUNT_DEPOSITS_Q2 IS  NULL ) THEN TRANSACTION_AMOUNT_DEPOSITS_Q1 else (ISNULL(TRANSACTION_AMOUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_AMOUNT_DEPOSITS_Q2,0)) end DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2
			  , CASE WHEN (TRANSACTION_AMOUNT_DEPOSITS_Q1 IS NULL AND TRANSACTION_AMOUNT_DEPOSITS_Q3 IS  NULL ) THEN TRANSACTION_AMOUNT_DEPOSITS_Q1 else (ISNULL(TRANSACTION_AMOUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_AMOUNT_DEPOSITS_Q3,0)) end DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3
			  --, CASE WHEN (TRANSACTION_AMOUNT_DEPOSITS_Q1 IS NULL AND TRANSACTION_AMOUNT_DEPOSITS_Q4 IS  NULL ) THEN TRANSACTION_AMOUNT_DEPOSITS_Q1 else (ISNULL(TRANSACTION_AMOUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_AMOUNT_DEPOSITS_Q4,0)) end DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q4
			  , [AVG_TRANSACTION_DEPOSITS_Q1]
			  , CASE WHEN (AVG_TRANSACTION_DEPOSITS_Q1 IS NULL AND AVG_TRANSACTION_DEPOSITS_Q2 IS  NULL ) THEN AVG_TRANSACTION_DEPOSITS_Q1 else (ISNULL(AVG_TRANSACTION_DEPOSITS_Q1,0)  - ISNULL(AVG_TRANSACTION_DEPOSITS_Q2,0)) end DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_DEPOSITS_Q1 IS NULL AND AVG_TRANSACTION_DEPOSITS_Q3 IS  NULL ) THEN AVG_TRANSACTION_DEPOSITS_Q1 else (ISNULL(AVG_TRANSACTION_DEPOSITS_Q1,0)  - ISNULL(AVG_TRANSACTION_DEPOSITS_Q3,0)) end DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_DEPOSITS_Q1 IS NULL AND AVG_TRANSACTION_DEPOSITS_Q4 IS  NULL ) THEN AVG_TRANSACTION_DEPOSITS_Q1 else (ISNULL(AVG_TRANSACTION_DEPOSITS_Q1,0)  - ISNULL(AVG_TRANSACTION_DEPOSITS_Q4,0)) end DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q4
			  , [DEPOSITED_AMOUNT_DEPOSITS_Q1] 
			  , CASE WHEN (AVG_TRANSACTION_DEPOSITS_Q1 IS NULL AND AVG_TRANSACTION_DEPOSITS_Q2 IS  NULL ) THEN AVG_TRANSACTION_DEPOSITS_Q1 else (ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q2,0)) end DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_DEPOSITS_Q1 IS NULL AND AVG_TRANSACTION_DEPOSITS_Q3 IS  NULL ) THEN AVG_TRANSACTION_DEPOSITS_Q1 else (ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q3,0)) end DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_DEPOSITS_Q1 IS NULL AND AVG_TRANSACTION_DEPOSITS_Q4 IS  NULL ) THEN AVG_TRANSACTION_DEPOSITS_Q1 else (ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q4,0)) end DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q4
			  , [DEPOSITED_COUNT_DEPOSITS_Q1]
			  , CASE WHEN (DEPOSITED_COUNT_DEPOSITS_Q1 IS NULL AND DEPOSITED_COUNT_DEPOSITS_Q2 IS  NULL ) THEN DEPOSITED_COUNT_DEPOSITS_Q1 else (ISNULL(DEPOSITED_COUNT_DEPOSITS_Q1,0) - ISNULL(DEPOSITED_COUNT_DEPOSITS_Q2,0)) end [DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2]
			  , CASE WHEN (DEPOSITED_COUNT_DEPOSITS_Q1 IS NULL AND DEPOSITED_COUNT_DEPOSITS_Q3 IS  NULL ) THEN DEPOSITED_COUNT_DEPOSITS_Q1 else (ISNULL(DEPOSITED_COUNT_DEPOSITS_Q1,0) - ISNULL(DEPOSITED_COUNT_DEPOSITS_Q3,0)) end [DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q3]
			  --, CASE WHEN (DEPOSITED_COUNT_DEPOSITS_Q1 IS NULL AND DEPOSITED_COUNT_DEPOSITS_Q4 IS  NULL ) THEN DEPOSITED_COUNT_DEPOSITS_Q1 else (ISNULL(DEPOSITED_COUNT_DEPOSITS_Q1,0) - ISNULL(DEPOSITED_COUNT_DEPOSITS_Q4,0)) end [DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q4]
			  , [WITHDRAWAL_AMOUNT_DEPOSITS_Q1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_DEPOSITS_Q1 IS NULL AND WITHDRAWAL_AMOUNT_DEPOSITS_Q2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_DEPOSITS_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q2,0)) end [DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_DEPOSITS_Q1 IS NULL AND WITHDRAWAL_AMOUNT_DEPOSITS_Q3 IS  NULL ) THEN WITHDRAWAL_AMOUNT_DEPOSITS_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q3,0)) end [DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_AMOUNT_DEPOSITS_Q1 IS NULL AND WITHDRAWAL_AMOUNT_DEPOSITS_Q4 IS  NULL ) THEN WITHDRAWAL_AMOUNT_DEPOSITS_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q4,0)) end [DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q4]
			  , [WITHDRAWAL_COUNT_DEPOSITS_Q1]
			  , CASE WHEN (WITHDRAWAL_COUNT_DEPOSITS_Q1 IS NULL AND WITHDRAWAL_COUNT_DEPOSITS_Q2 IS  NULL ) THEN WITHDRAWAL_COUNT_DEPOSITS_Q1 else (ISNULL(WITHDRAWAL_COUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_COUNT_DEPOSITS_Q2,0)) end [DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_COUNT_DEPOSITS_Q1 IS NULL AND WITHDRAWAL_COUNT_DEPOSITS_Q3 IS  NULL ) THEN WITHDRAWAL_COUNT_DEPOSITS_Q1 else (ISNULL(WITHDRAWAL_COUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_COUNT_DEPOSITS_Q3,0)) end [DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_COUNT_DEPOSITS_Q1 IS NULL AND WITHDRAWAL_COUNT_DEPOSITS_Q4 IS  NULL ) THEN WITHDRAWAL_COUNT_DEPOSITS_Q1 else (ISNULL(WITHDRAWAL_COUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_COUNT_DEPOSITS_Q4,0)) end [DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q4]
			  , [SUM_INTEREST_DEPOSITS_Q1]
			  , CASE WHEN (SUM_INTEREST_DEPOSITS_Q1 IS NULL AND SUM_INTEREST_DEPOSITS_Q2 IS  NULL ) THEN SUM_INTEREST_DEPOSITS_Q1 else (ISNULL(SUM_INTEREST_DEPOSITS_Q1,0) - ISNULL(SUM_INTEREST_DEPOSITS_Q2,0)) end [DFT_SUM_INTEREST_DEPOSITS_Q1_Q2]
			  , CASE WHEN (SUM_INTEREST_DEPOSITS_Q1 IS NULL AND SUM_INTEREST_DEPOSITS_Q3 IS  NULL ) THEN SUM_INTEREST_DEPOSITS_Q1 else (ISNULL(SUM_INTEREST_DEPOSITS_Q1,0) - ISNULL(SUM_INTEREST_DEPOSITS_Q3,0)) end [DFT_SUM_INTEREST_DEPOSITS_Q1_Q3]
			  --, CASE WHEN (SUM_INTEREST_DEPOSITS_Q1 IS NULL AND SUM_INTEREST_DEPOSITS_Q4 IS  NULL ) THEN SUM_INTEREST_DEPOSITS_Q1 else (ISNULL(SUM_INTEREST_DEPOSITS_Q1,0) - ISNULL(SUM_INTEREST_DEPOSITS_Q4,0)) end [DFT_SUM_INTEREST_DEPOSITS_Q1_Q4]


		into #deposits_transaction
		from #deposit_transaction_temp2

		DROP TABLE IF EXISTS #deposits_summary
		SELECT * 
		into #deposits_summary 
		FROM #membership_deposits A
		left join #deposits_transaction B
		on A.SSN003  = B.SSN004

		
		--DROP TABLE IF EXISTS #updated_deposits_summary
		--SELECT CASE WHEN A.SSN003  = B.SSN004 THEN A.SSN003 
		--            WHEN A.SSN003 is NULL THEN B.SSN004
		--			WHEN B.SSN004 is NULL THEN A.SSN003 END [SSN_Dep]
		--			,A.*,B.*
		--into #updated_deposits_summary 
		--FROM #membership_deposits A
		--full outer join #deposits_transaction B
		--on A.SSN003  = B.SSN004

		-- Merging the Loan Product Summary and Deposits Summary

		DROP TABLE IF EXISTS #merged_loan_deposits_summary
		SELECT * 
		into #merged_loan_deposits_summary
		FROM #deposits_summary A
		left join 
		#loan_product_master B
		on A.SSN003 = B.SSN001

		--DROP TABLE IF EXISTS #updated_merged_loan_deposits_summary
		--SELECT CASE WHEN A.SSN_Dep = B.SSN_L THEN SSN_Dep
		--            WHEN A.SSN_Dep IS NULL THEN B.SSN_L
		--			WHEN B.SSN_L IS NULL THEN A.SSN_Dep END [FINAL_SSN]
		--into #updated_merged_loan_deposits_summary
		--FROM #updated_deposits_summary A
		--full outer join 
		--#updated_loan_product_master B
		--on A.SSN_Dep = B.SSN_L

		--DROP TABLE IF EXISTS Analytics.dbo.SN_depositsLOAN 
		--SELECT TOP 10 *
		--into Analytics.dbo.SN_depositsLOAN
		--FROM #merged_loan_deposits_summary

	/* Appending OnlineBanking data to Master data  */
		DECLARE @staticpooldate date
		set @staticpooldate = '2022-04-30'

	drop table if exists #loan_dep_onlinebanking
	select  A.*,DATEDIFF ( day, LastLogon, @staticpooldate) AS "Days Since Last Login" 
	into #loan_dep_onlinebanking -- new copy of master data
	from #merged_loan_deposits_summary as A
	LEFT join Q2EVE.[dbo].[vwMemberOnlineBankingSummary] as B
	on A.SSN003 = B.SSN


	 /*** final table for CLD ****/
	 drop table if exists #CLD_final 
	 select 
	 [SSN003]
      ,[PRODUCT_SAVINGS_SP]
      ,[BUSINESS_SAVINGS_SP]
      ,[NON_INT_EARNING_SAVINGS_SP]
      ,[STUDENT_SAVINGS_SP]
      ,[PRODUCT_SAVINGS_Q1]
      ,[BUSINESS_SAVINGS_Q1]
      ,[NON_INT_EARNING_SAVINGS_Q1]
      ,[STUDENT_SAVINGS_Q1]
      ,[DFT_PRODUCT_SAVINGS_Q1_Q2]
      ,[DFT_PRODUCT_SAVINGS_Q1_Q3]
      ,[DFT_BUSINESS_SAVINGS_Q1_Q2]
      ,[DFT_BUSINESS_SAVINGS_Q1_Q3]
      ,[DFT_NON_INT_EARNING_SAVINGS_Q1_Q2]
      ,[DFT_NON_INT_EARNING_SAVINGS_Q1_Q3]
      ,[DFT_STUDENT_SAVINGS_Q1_Q2]
      ,[DFT_STUDENT_SAVINGS_Q1_Q3]
      ,[TYPE_SAVINGS_SP]
      ,[TYPE_SAVINGS_Q1]
      ,[DFT_TYPE_SAVINGS_Q1_Q2]
      ,[DFT_TYPE_SAVINGS_Q1_Q3]
      ,[MOB_SAVINGS]
      ,[AVG_MONTH_END_BALANCE_SAVINGS_Q1]
      ,[DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2]
      ,[DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3]
      ,[SUM_LASTDIVAMOUNT_SAVINGS_Q1]
      ,[DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2]
      ,[DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3]
      ,[AVG_CHARGEOFFAMOUNT_SAVINGS_SP]
      ,[AVG_CHARGEOFFAMOUNT_SAVINGS_Q1]
      ,[DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q2]
      ,[DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q3]
      ,[PRODUCT_CHECKING_SP]
      ,[PRODUCT_CHECKING_Q1]
      ,[DFT_PRODUCT_CHECKING_Q1_Q2]
      ,[DFT_PRODUCT_CHECKING_Q1_Q3]
      ,[TYPE_CHECKING_SP]
      ,[TYPE_CHECKING_Q1]
      ,[DFT_TYPE_CHECKING_Q1_Q2]
      ,[DFT_TYPE_CHECKING_Q1_Q3]
      ,[MOB_CHECKING]
      ,[AVG_MONTH_END_BALANCE_CHECKING_Q1]
      ,[DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2]
      ,[DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3]
      ,[SUM_LASTDIVAMOUNT_CHECKING_Q1]
      ,[DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2]
      ,[DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q3]
      ,[AVG_CHARGEOFFAMOUNT_CHECKING_SP]
      ,[AVG_CHARGEOFFAMOUNT_CHECKING_Q1]
      ,[DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q2]
      ,[DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q3]
      ,[PRODUCT_CERTIFICATES_SP]
      ,[PRODUCT_CERTIFICATES_Q1]
      ,[DFT_PRODUCT_CERTIFICATES_Q1_Q2]
      ,[DFT_PRODUCT_CERTIFICATES_Q1_Q3]
      ,[TYPE_CERTIFICATES_SP]
      ,[TYPE_CERTIFICATES_Q1]
      ,[DFT_TYPE_CERTIFICATES_Q1_Q2]
      ,[DFT_TYPE_CERTIFICATES_Q1_Q3]
      ,[MOB_CERTIFICATES]
      ,[AVG_MONTH_END_BALANCE_CERTIFICATES_Q1]
      ,[DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2]
      ,[DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q3]
      ,[SUM_LASTDIVAMOUNT_CERTIFICATES_Q1]
      ,[DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q2]
      ,[DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q3]
      ,[AVG_CHARGEOFFAMOUNT_CERTIFICATES_SP]
      ,[AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1]
      ,[DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q2]
      ,[DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q3]
      ,[PRODUCT_MONEYMARKET_SP]
      ,[PRODUCT_MONEYMARKET_Q1]
      ,[DFT_PRODUCT_MONEYMARKET_Q1_Q2]
      ,[DFT_PRODUCT_MONEYMARKET_Q1_Q3]
      ,[TYPE_MONEYMARKET_SP]
      ,[TYPE_MONEYMARKET_Q1]
      ,[DFT_TYPE_MONEYMARKET_Q1_Q2]
      ,[DFT_TYPE_MONEYMARKET_Q1_Q3]
      ,[MOB_MONEYMARKET]
      ,[AVG_MONTH_END_BALANCE_MONEYMARKET_Q1]
      ,[DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2]
      ,[DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q3]
      ,[SUM_LASTDIVAMOUNT_MONEYMARKET_Q1]
      ,[DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2]
      ,[DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q3]
      ,[AVG_CHARGEOFFAMOUNT_MONEYMARKET_SP]
      ,[AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1]
      ,[DFT_AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1_Q2]
      ,[DFT_AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1_Q3]
      ,[PRODUCT_IRA_SP]
      ,[PRODUCT_IRA_Q1]
      ,[DFT_PRODUCT_IRA_Q1_Q2]
      ,[DFT_PRODUCT_IRA_Q1_Q3]
      ,[TYPE_IRA_SP]
      ,[TYPE_IRA_Q1]
      ,[DFT_TYPE_IRA_Q1_Q2]
      ,[DFT_TYPE_IRA_Q1_Q3]
      ,[MOB_IRA]
      ,[AVG_MONTH_END_BALANCE_IRA_Q1]
      ,[DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q2]
      ,[DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q3]
      ,[SUM_LASTDIVAMOUNT_IRA_Q1]
      ,[DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q2]
      ,[DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q3]
      ,[AVG_CHARGEOFFAMOUNT_IRA_Q1]
      ,[DFT_AVG_CHARGEOFFAMOUNT_IRA_Q1_Q2]
      ,[PRODUCT_HSA_SP]
      ,[PRODUCT_HSA_Q1]
      ,[DFT_PRODUCT_HSA_Q1_Q2]
      ,[DFT_PRODUCT_HSA_Q1_Q3]
      ,[TYPE_HSA_SP]
      ,[TYPE_HSA_Q1]
      ,[DFT_TYPE_HSA_Q1_Q2]
      ,[DFT_TYPE_HSA_Q1_Q3]
      ,[MOB_HSA]
      ,[AVG_MONTH_END_BALANCE_HSA_Q1]
      ,[DFT_AVG_MONTH_END_BALANCE_HSA_Q1_Q2]
      ,[DFT_AVG_MONTH_END_BALANCE_HSA_Q1_Q3]
      ,[SUM_LASTDIVAMOUNT_HSA_Q1]
      ,[DFT_SUM_LASTDIVAMOUNT_HSA_Q1_Q2]
      ,[DFT_SUM_LASTDIVAMOUNT_HSA_Q1_Q3]
      ,[AVG_CHARGEOFFAMOUNT_HSA_Q1]
      ,[PRODUCT_DEPOSITS_SP]
      ,[PRODUCT_DEPOSITS_Q1]
      ,[DFT_PRODUCT_DEPOSITS_Q1_Q2]
      ,[DFT_PRODUCT_DEPOSITS_Q1_Q3]
      ,[TYPE_DEPOSITS_Q1]
      ,[DFT_TYPE_DEPOSITS_Q1_Q2]
      ,[DFT_TYPE_DEPOSITS_Q1_Q3]
      ,[MOB_DEPOSITS]
      ,[AVG_MONTH_END_BALANCE_DEPOSITS_Q1]
      ,[DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2]
      ,[DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3]
      ,[SUM_LASTDIVAMOUNT_DEPOSITS_Q1]
      ,[DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2]
      ,[DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3]
      ,[AVG_CHARGEOFFAMOUNT_DEPOSITS_SP]
      ,[AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1]
      ,[DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q2]
      ,[DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q3]
      ,[SAVINGS_StaticpoolFlag]
      ,[BUSINESS_StaticpoolFlag]
      ,[NON_INT_EARNING_StaticpoolFlag]
      ,[STUDENT_StaticpoolFlag]
      ,[CHECKING_StaticpoolFlag]
      ,[CERTIFICATES_StaticpoolFlag]
      ,[MONEYMARKET_StaticpoolFlag]
      ,[IRA_StaticpoolFlag]
      ,[HSA_StaticpoolFlag]
      ,[SAVINGS_Q1Flag]
      ,[CHECKING_Q1Flag]
      ,[CERTIFICATES_Q1Flag]
      ,[MONEYMARKET_Q1Flag]
      ,[IRA_Q1Flag]
      ,[HSA_Q1Flag]
      ,[SSN004]
      ,[TRANSACTION_COUNT_SAVINGS_Q1]
      ,[DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2]
      ,[DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3]
      ,[TRANSACTION_AMOUNT_SAVINGS_Q1]
      ,[DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2]
      ,[DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3]
      ,[AVG_TRANSACTION_SAVINGS_Q1]
      ,[DFT_AVG_TRANSACTION_SAVINGS_Q1_Q2]
      ,[DFT_AVG_TRANSACTION_SAVINGS_Q1_Q3]
      ,[DEPOSITED_AMOUNT_SAVINGS_Q1]
      ,[DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2]
      ,[DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3]
      ,[DEPOSITED_COUNT_SAVINGS_Q1]
      ,[DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2]
      ,[DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3]
      ,[WITHDRAWAL_AMOUNT_SAVINGS_Q1]
      ,[DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2]
      ,[DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3]
      ,[WITHDRAWAL_COUNT_SAVINGS_Q1]
      ,[DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2]
      ,[DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q3]
      ,[SUM_INTEREST_SAVINGS_Q1]
      ,[DFT_SUM_INTEREST_SAVINGS_Q1_Q2]
      ,[DFT_SUM_INTEREST_SAVINGS_Q1_Q3]
      ,[TRANSACTION_COUNT_CHECKING_Q1]
      ,[DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2]
      ,[DFT_TRANSACTION_COUNT_CHECKING_Q1_Q3]
      ,[TRANSACTION_AMOUNT_CHECKING_Q1]
      ,[DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2]
      ,[DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3]
      ,[AVG_TRANSACTION_CHECKING_Q1]
      ,[DFT_AVG_TRANSACTION_CHECKING_Q1_Q2]
      ,[DFT_AVG_TRANSACTION_CHECKING_Q1_Q3]
      ,[DEPOSITED_AMOUNT_CHECKING_Q1]
      ,[DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2]
      ,[DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3]
      ,[DEPOSITED_COUNT_CHECKING_Q1]
      ,[DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2]
      ,[DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3]
      ,[WITHDRAWAL_AMOUNT_CHECKING_Q1]
      ,[DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2]
      ,[DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q3]
      ,[WITHDRAWAL_COUNT_CHECKING_Q1]
      ,[DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2]
      ,[DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q3]
      ,[SUM_INTEREST_CHECKING_Q1]
      ,[DFT_SUM_INTEREST_CHECKING_Q1_Q2]
      ,[DFT_SUM_INTEREST_CHECKING_Q1_Q3]
      ,[TRANSACTION_COUNT_CERTIFICATES_Q1]
      ,[DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q2]
      ,[DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q3]
      ,[TRANSACTION_AMOUNT_CERTIFICATES_Q1]
      ,[DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q2]
      ,[DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q3]
      ,[AVG_TRANSACTION_CERTIFICATES_Q1]
      ,[DFT_AVG_TRANSACTION_CERTIFICATES_Q1_Q2]
      ,[DFT_AVG_TRANSACTION_CERTIFICATES_Q1_Q3]
      ,[DEPOSITED_AMOUNT_CERTIFICATES_Q1]
      ,[DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q2]
      ,[DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q3]
      ,[DEPOSITED_COUNT_CERTIFICATES_Q1]
      ,[DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q2]
      ,[DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q3]
      ,[WITHDRAWAL_AMOUNT_CERTIFICATES_Q1]
      ,[DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q2]
      ,[DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q3]
      ,[WITHDRAWAL_COUNT_CERTIFICATES_Q1]
      ,[DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q2]
      ,[DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q3]
      ,[SUM_INTEREST_CERTIFICATES_Q1]
      ,[DFT_SUM_INTEREST_CERTIFICATES_Q1_Q2]
      ,[DFT_SUM_INTEREST_CERTIFICATES_Q1_Q3]
      ,[TRANSACTION_COUNT_MONEYMARKET_Q1]
      ,[DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q2]
      ,[DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q3]
      ,[TRANSACTION_AMOUNT_MONEYMARKET_Q1]
      ,[DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q2]
      ,[DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q3]
      ,[AVG_TRANSACTION_MONEYMARKET_Q1]
      ,[DFT_AVG_TRANSACTION_MONEYMARKET_Q1_Q2]
      ,[DFT_AVG_TRANSACTION_MONEYMARKET_Q1_Q3]
      ,[DEPOSITED_AMOUNT_MONEYMARKET_Q1]
      ,[DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q2]
      ,[DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q3]
      ,[DEPOSITED_COUNT_MONEYMARKET_Q1]
      ,[DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q2]
      ,[DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q3]
      ,[WITHDRAWAL_AMOUNT_MONEYMARKET_Q1]
      ,[DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q2]
      ,[DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q3]
      ,[WITHDRAWAL_COUNT_MONEYMARKET_Q1]
      ,[DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q2]
      ,[DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q3]
      ,[SUM_INTEREST_MONEYMARKET_Q1]
      ,[DFT_SUM_INTEREST_MONEYMARKET_Q1_Q2]
      ,[DFT_SUM_INTEREST_MONEYMARKET_Q1_Q3]
      ,[TRANSACTION_COUNT_IRA_Q1]
      ,[DFT_TRANSACTION_COUNT_IRA_Q1_Q2]
      ,[DFT_TRANSACTION_COUNT_IRA_Q1_Q3]
      ,[TRANSACTION_AMOUNT_IRA_Q1]
      ,[DFT_TRANSACTION_AMOUNT_IRA_Q1_Q2]
      ,[DFT_TRANSACTION_AMOUNT_IRA_Q1_Q3]
      ,[AVG_TRANSACTION_IRA_Q1]
      ,[DFT_AVG_TRANSACTION_IRA_Q1_Q2]
      ,[DFT_AVG_TRANSACTION_IRA_Q1_Q3]
      ,[DEPOSITED_AMOUNT_IRA_Q1]
      ,[DFT_DEPOSITED_AMOUNT_IRA_Q1_Q2]
      ,[DFT_DEPOSITED_AMOUNT_IRA_Q1_Q3]
      ,[DEPOSITED_COUNT_IRA_Q1]
      ,[DFT_DEPOSITED_COUNT_IRA_Q1_Q2]
      ,[DFT_DEPOSITED_COUNT_IRA_Q1_Q3]
      ,[WITHDRAWAL_AMOUNT_IRA_Q1]
      ,[DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q2]
      ,[DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q3]
      ,[WITHDRAWAL_COUNT_IRA_Q1]
      ,[DFT_WITHDRAWAL_COUNT_IRA_Q1_Q2]
      ,[DFT_WITHDRAWAL_COUNT_IRA_Q1_Q3]
      ,[SUM_INTEREST_IRA_Q1]
      ,[DFT_SUM_INTEREST_IRA_Q1_Q2]
      ,[DFT_SUM_INTEREST_IRA_Q1_Q3]
      ,[TRANSACTION_COUNT_HSA_Q1]
      ,[DFT_TRANSACTION_COUNT_HSA_Q1_Q2]
      ,[DFT_TRANSACTION_COUNT_HSA_Q1_Q3]
      ,[TRANSACTION_AMOUNT_HSA_Q1]
      ,[DFT_TRANSACTION_AMOUNT_HSA_Q1_Q2]
      ,[DFT_TRANSACTION_AMOUNT_HSA_Q1_Q3]
      ,[AVG_TRANSACTION_HSA_Q1]
      ,[DFT_AVG_TRANSACTION_HSA_Q1_Q2]
      ,[DFT_AVG_TRANSACTION_HSA_Q1_Q3]
      ,[DEPOSITED_AMOUNT_HSA_Q1]
      ,[DFT_DEPOSITED_AMOUNT_HSA_Q1_Q2]
      ,[DFT_DEPOSITED_AMOUNT_HSA_Q1_Q3]
      ,[DEPOSITED_COUNT_HSA_Q1]
      ,[DFT_DEPOSITED_COUNT_HSA_Q1_Q2]
      ,[DFT_DEPOSITED_COUNT_HSA_Q1_Q3]
      ,[WITHDRAWAL_AMOUNT_HSA_Q1]
      ,[DFT_WITHDRAWAL_AMOUNT_HSA_Q1_Q2]
      ,[DFT_WITHDRAWAL_AMOUNT_HSA_Q1_Q3]
      ,[WITHDRAWAL_COUNT_HSA_Q1]
      ,[DFT_WITHDRAWAL_COUNT_HSA_Q1_Q2]
      ,[DFT_WITHDRAWAL_COUNT_HSA_Q1_Q3]
      ,[SUM_INTEREST_HSA_Q1]
      ,[DFT_SUM_INTEREST_HSA_Q1_Q2]
      ,[DFT_SUM_INTEREST_HSA_Q1_Q3]
      ,[TRANSACTION_COUNT_DEPOSITS_Q1]
      ,[DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q2]
      ,[DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3]
      ,[TRANSACTION_AMOUNT_DEPOSITS_Q1]
      ,[DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2]
      ,[DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3]
      ,[AVG_TRANSACTION_DEPOSITS_Q1]
      ,[DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q2]
      ,[DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q3]
      ,[DEPOSITED_AMOUNT_DEPOSITS_Q1]
      ,[DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2]
      ,[DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3]
      ,[DEPOSITED_COUNT_DEPOSITS_Q1]
      ,[DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2]
      ,[DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q3]
      ,[WITHDRAWAL_AMOUNT_DEPOSITS_Q1]
      ,[DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2]
      ,[DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q3]
      ,[WITHDRAWAL_COUNT_DEPOSITS_Q1]
      ,[DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2]
      ,[DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3]
      ,[SUM_INTEREST_DEPOSITS_Q1]
      ,[DFT_SUM_INTEREST_DEPOSITS_Q1_Q2]
      ,[DFT_SUM_INTEREST_DEPOSITS_Q1_Q3]
      ,[SSN001]
      ,[PRODUCT_CommercialLoan_Q1]
      ,[DFT_PRODUCT_CommercialLoan_Q1_Q2]
      ,[DFT_PRODUCT_CommercialLoan_Q1_Q3]
      ,[PRODUCT_RealEstate_Q1]
      ,[DFT_PRODUCT_RealEstate_Q1_Q2]
      ,[DFT_PRODUCT_RealEstate_Q1_Q3]
      ,[PRODUCT_SecuredLoan_Q1]
      ,[DFT_PRODUCT_SecuredLoan_Q1_Q2]
      ,[DFT_PRODUCT_SecuredLoan_Q1_Q3]
      ,[PRODUCT_UnsecuredLoan_Q1]
      ,[DFT_PRODUCT_UnsecuredLoan_Q1_Q2]
      ,[DFT_PRODUCT_UnsecuredLoan_Q1_Q3]
      ,[PRODUCT_VehicleLoan_Q1]
      ,[DFT_PRODUCT_VehicleLoan_Q1_Q2]
      ,[DFT_PRODUCT_VehicleLoan_Q1_Q3]
      ,[PRODUCT_Others_Q1]
      ,[DFT_PRODUCT_Others_Q1_Q2]
      ,[DFT_PRODUCT_Others_Q1_Q3]
      ,[PRODUCT_Loan_Q1]
      ,[DFT_PRODUCT_Loan_Q1_Q2]
      ,[DFT_PRODUCT_Loan_Q1_Q3]
      ,[RealEstate_MOB]
      ,[SecuredLoan_MOB]
      ,[UnsecuredLoan_MOB]
      ,[Vehicleloan_MOB]
      ,[Others_MOB]
      ,[MAX_Loan_MOB]
      ,[PAYMENTCOUNT_RealEstate_Q1]
      ,[DFT_PAYMENTCOUNT_RealEstate_Q1_Q2]
      ,[DFT_PAYMENTCOUNT_RealEstate_Q1_Q3]
      ,[PAYMENTCOUNT_SecuredLoan_Q1]
      ,[DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q2]
      ,[DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q3]
      ,[PAYMENTCOUNT_UnsecuredLoan_Q1]
      ,[DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q2]
      ,[DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q3]
      ,[PAYMENTCOUNT_VehicleLoan_Q1]
      ,[DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q2]
      ,[DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q3]
      ,[PAYMENTCOUNT_Others_Q1]
      ,[DFT_PAYMENTCOUNT_Others_Q1_Q2]
      ,[DFT_PAYMENTCOUNT_Others_Q1_Q3]
      ,[PAYMENTCOUNT_Loan_Q1]
      ,[DFT_PAYMENTCOUNT_Loan_Q1_Q2]
      ,[DFT_PAYMENTCOUNT_Loan_Q1_Q3]
      ,[SUM_OriginalBalance_RealEstate_Q1]
      ,[DFT_SUM_OriginalBalance_RealEstate_Q1_Q2]
      ,[DFT_SUM_OriginalBalance_RealEstate_Q1_Q3]
      ,[SUM_OriginalBalance_SecuredLoan_Q1]
      ,[DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q2]
      ,[DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q3]
      ,[SUM_OriginalBalance_UnsecuredLoan_Q1]
      ,[DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q2]
      ,[DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q3]
      ,[SUM_OriginalBalance_VehicleLoan_Q1]
      ,[DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q2]
      ,[DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q3]
      ,[SUM_OriginalBalance_Others_Q1]
      ,[DFT_SUM_OriginalBalance_Others_Q1_Q2]
      ,[DFT_SUM_OriginalBalance_Others_Q1_Q3]
      ,[SUM_OriginalBalance_Loan_Q1]
      ,[DFT_SUM_OriginalBalance_Loan_Q1_Q2]
      ,[DFT_SUM_OriginalBalance_Loan_Q1_Q3]
      ,[SUM_PAYMENT_RealEstate_Q1]
      ,[DFT_SUM_PAYMENT_RealEstate_Q1_Q2]
      ,[DFT_SUM_PAYMENT_RealEstate_Q1_Q3]
      ,[SUM_PAYMENT_SecuredLoan_Q1]
      ,[DFT_SUM_PAYMENT_SecuredLoan_Q1_Q2]
      ,[DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3]
      ,[SUM_PAYMENT_UnsecuredLoan_Q1]
      ,[DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q2]
      ,[DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q3]
      ,[SUM_PAYMENT_VehicleLoan_Q1]
      ,[DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2]
      ,[DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3]
      ,[SUM_PAYMENT_Others_Q1]
      ,[DFT_SUM_PAYMENT_Others_Q1_Q2]
      ,[DFT_SUM_PAYMENT_Others_Q1_Q3]
      ,[SUM_PAYMENT_Loan_Q1]
      ,[DFT_SUM_PAYMENT_Loan_Q1_Q2]
      ,[DFT_SUM_PAYMENT_Loan_Q1_Q3]
      ,[MAX_INTERESTRATE_RealEstate_Q1]
      ,[DFT_MAX_INTERESTRATE_RealEstate_Q1_Q2]
      ,[DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3]
      ,[MAX_INTERESTRATE_SecuredLoan_Q1]
      ,[DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q2]
      ,[DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3]
      ,[MAX_INTERESTRATE_UnsecuredLoan_Q1]
      ,[DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q2]
      ,[DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q3]
      ,[MAX_INTERESTRATE_VehicleLoan_Q1]
      ,[DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q2]
      ,[DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q3]
      ,[MAX_INTERESTRATE_Others_Q1]
      ,[DFT_MAX_INTERESTRATE_Others_Q1_Q2]
      ,[DFT_MAX_INTERESTRATE_Others_Q1_Q3]
      ,[MAX_INTERESTRATE_Loan_Q1]
      ,[DFT_MAX_INTERESTRATE_Loan_Q1_Q2]
      ,[DFT_MAX_INTERESTRATE_Loan_Q1_Q3]
      ,[MAX_CREDITLIMIT_RealEstate_Q1]
      ,[DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q2]
      ,[DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q3]
      ,[MAX_CREDITLIMIT_SecuredLoan_Q1]
      ,[DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q2]
      ,[DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q3]
      ,[MAX_CREDITLIMIT_UnsecuredLoan_Q1]
      ,[DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q2]
      ,[DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q3]
      ,[MAX_CREDITLIMIT_VehicleLoan_Q1]
      ,[DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q2]
      ,[DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q3]
      ,[MAX_CREDITLIMIT_Others_Q1]
      ,[DFT_MAX_CREDITLIMIT_Others_Q1_Q2]
      ,[DFT_MAX_CREDITLIMIT_Others_Q1_Q3]
      ,[MAX_CREDITLIMIT_Loan_Q1]
      ,[DFT_MAX_CREDITLIMIT_Loan_Q1_Q2]
      ,[DFT_MAX_CREDITLIMIT_Loan_Q1_Q3]
      ,[COUNT_DUEDAY1_CommercialLoan_Q1]
      ,[COUNT_DUEDAY1_CommercialLoan_Q2]
      ,[COUNT_DUEDAY1_CommercialLoan_Q3]
      ,[COUNT_DUEDAY1_RealEstate_Q1]
      ,[COUNT_DUEDAY1_RealEstate_Q2]
      ,[COUNT_DUEDAY1_RealEstate_Q3]
      ,[COUNT_DUEDAY1_SecuredLoan_Q1]
      ,[COUNT_DUEDAY1_SecuredLoan_Q2]
      ,[COUNT_DUEDAY1_SecuredLoan_Q3]
      ,[COUNT_DUEDAY1_UnsecuredLoan_Q1]
      ,[COUNT_DUEDAY1_UnsecuredLoan_Q2]
      ,[COUNT_DUEDAY1_UnsecuredLoan_Q3]
      ,[COUNT_DUEDAY1_VehicleLoan_Q1]
      ,[COUNT_DUEDAY1_VehicleLoan_Q2]
      ,[COUNT_DUEDAY1_VehicleLoan_Q3]
      ,[COUNT_DUEDAY1_Others_Q1]
      ,[COUNT_DUEDAY1_Others_Q2]
      ,[COUNT_DUEDAY1_Others_Q3]
      ,[COUNT_DUEDAY2_CommercialLoan_Q1]
      ,[COUNT_DUEDAY2_CommercialLoan_Q2]
      ,[COUNT_DUEDAY2_CommercialLoan_Q3]
      ,[COUNT_DUEDAY2_RealEstate_Q1]
      ,[COUNT_DUEDAY2_RealEstate_Q2]
      ,[COUNT_DUEDAY2_RealEstate_Q3]
      ,[COUNT_DUEDAY2_SecuredLoan_Q1]
      ,[COUNT_DUEDAY2_SecuredLoan_Q2]
      ,[COUNT_DUEDAY2_SecuredLoan_Q3]
      ,[COUNT_DUEDAY2_UnsecuredLoan_Q1]
      ,[COUNT_DUEDAY2_UnsecuredLoan_Q2]
      ,[COUNT_DUEDAY2_UnsecuredLoan_Q3]
      ,[COUNT_DUEDAY2_VehicleLoan_Q1]
      ,[COUNT_DUEDAY2_VehicleLoan_Q2]
      ,[COUNT_DUEDAY2_VehicleLoan_Q3]
      ,[COUNT_DUEDAY2_Others_Q1]
      ,[COUNT_DUEDAY2_Others_Q2]
      ,[COUNT_DUEDAY2_Others_Q3]
      ,[RealEstate_Month_to_Maturity]
      ,[SecuredLoan_Month_to_Maturity]
      ,[UnsecuredLoan_Month_to_Maturity]
      ,[Vehicleloan_Month_to_Maturity]
      ,[Others_Month_to_Maturity]
      ,[Max_Loan_Month_to_Maturity]
      ,[Delinquency_RealEstate_SP]
      ,[Delinquency_SecuredLoan_SP]
      ,[Delinquency_UnsecuredLoan_SP]
      ,[Delinquency_Vehicleloan_SP]
      ,[Delinquency_Others_SP]
      ,[Delinquency_Loan_SP]
      ,[RealEstate_OPENDATE]
      ,[SecuredLoan_OPENDATE]
      ,[UnsecuredLoan_OPENDATE]
      ,[Vehicleloan_OPENDATE]
      ,[Others_OPENDATE]
      ,[Min_Loan_OPENDATE]
      ,[CommercialLoan_StaticPoolFlag]
      ,[RealEstate_StaticPoolFlag]
      ,[SecuredLoan_StaticPoolFlag]
      ,[UnsecuredLoan_StaticPoolFlag]
      ,[VehicleLoan_StaticPoolFlag]
      ,[CREDIT_SCORE_SP]
      ,[DFT_CREDIT_SCORE_SP_Q4]
      ,[SSN_CC]
      ,[CreditCard_StaticpoolFlag]
      ,[CreditCard_Q1Flag]
      ,[PRODUCT_CC_Q1]
      ,[DFT_PRODUCT_CC_Q1_Q2]
      ,[DFT_PRODUCT_CC_Q1_Q3]
      ,[Last Statement payment Count_CC_Q1]
      ,[DFT_Last Statement payment Count_CC_Q1_Q2]
      ,[DFT_Last Statement payment Count_CC_Q1_Q3]
      ,[Last Statement payment Amount_CC_Q1]
      ,[DFT_Last Statement payment Amount_CC_Q1_Q2]
      ,[DFT_Last Statement payment Amount_CC_Q1_Q3]
      ,[Last Statement Sale Amount_CC_Q1]
      ,[DFT_Last Statement Sale Amount_CC_Q1_Q2]
      ,[DFT_Last Statement Sale Amount_CC_Q1_Q3]
      ,[Last Statement Cash Amount_CC_Q1]
      ,[DFT_Last Statement Cash amount_CC_Q1_Q2]
      ,[DFT_Last Statement Cash amount_CC_Q1_Q3]
      ,[Last Statement Return amount_CC_Q1]
      ,[DFT_Last Statement Return amount_CC_Q1_Q2]
      ,[DFT_Last Statement Return amount_CC_Q1_Q3]
      ,[Last Statement Sale Count_CC_Q1]
      ,[DFT_Last Statement Sale Count_CC_Q1_Q2]
      ,[DFT_Last Statement Sale Count_CC_Q1_Q3]
      ,[Last Statement Cash Advance Count_CC_Q1]
      ,[DFT_Last Statement Cash Advance Count_CC_Q1_Q2]
      ,[DFT_Last Statement Cash Advance Count_CC_Q1_Q3]
      ,[Last Statement Return count_CC_Q1]
      ,[DFT_Last Statement Return count_CC_Q1_Q2]
      ,[DFT_Last Statement Return count_CC_Q1_Q3]
      ,[Last Statement External Fee amount_CC_Q1]
      ,[DFT_Last Statement External Fee amount_CC_Q1_Q2]
      ,[DFT_Last Statement External Fee amount_CC_Q1_Q3]
      ,[Last Statement Credit Life Change amount_CC_Q1]
      ,[DFT_Last Statement Credit Life Change amount_CC_Q1_Q2]
      ,[DFT_Last Statement Credit Life Change amount_CC_Q1_Q3]
      ,[Last Statement Charge Late amount_CC_Q1]
      ,[DFT_Last Statement Charge late amount_CC_Q1_Q2]
      ,[DFT_Last Statement Charge late amount_CC_Q1_Q3]
      ,[Last Statement Charge cash amount_CC_Q1]
      ,[DFT_Last Statement Charge cash amount_CC_Q1_Q2]
      ,[DFT_Last Statement Charge cash amount_CC_Q1_Q3]
      ,[Last Statement Charge Overlimit amount_CC_Q1]
      ,[DFT_Last Statement Charge Overlimit amount_CC_Q1_Q2]
      ,[DFT_Last Statement Charge Overlimit amount_CC_Q1_Q3]
      ,[Last Statement Charge Sale amount_CC_Q1]
      ,[DFT_Last Statement Charge Sale amount_CC_Q1_Q2]
      ,[DFT_Last Statement Charge Sale amount_CC_Q1_Q3]
      ,[Last Statement Merchandise Average Daily Balance amount_CC_Q1]
      ,[DFT_Last Statement Merchandise Average Daily Balance amount_CC_Q1_Q2]
      ,[DFT_Last Statement Merchandise Average Daily Balance amount_CC_Q1_Q3]
      ,[Last Statement cash Average Daily Balance amount_CC_Staticpool]
      ,[Last Statement cash Average Daily Balance amount_CC_Q1]
      ,[DFT_Last Statement cash Average Daily Balance amount_CC_Q1_Q2]
      ,[DFT_Last Statement cash Average Daily Balance amount_CC_Q1_Q3]
      ,[Last Statement Average Daily Balance amount_CC_Q1]
      ,[DFT_Last Statement Average Daily Balance amount_CC_Q1_Q2]
      ,[DFT_Last Statement Average Daily Balance Amount_CC_Q1_Q3]
      ,[spend_CC_Q1]
      ,[DFT_spend_CC_Q1_Q2]
      ,[DFT_spend_CC_Q1_Q3]
      ,[Protected_Balance_CC_Q1]
      ,[DFT_Protected_Balance_CC_Q1_Q2]
      ,[DFT_Protected_Balance_CC_Q1_Q3]
      ,[Promo_Balance_CC_Q1]
      ,[DFT_Promo_Balance_CC_Q1_Q2]
      ,[DFT_Promo_Balance_CC_Q1_Q3]
      ,[Protected_Current_Interest_CC_Q1]
      ,[DFT_Protected_Current_Interest_CC_Q1_Q2]
      ,[DFT_Protected_Current_Interest_CC_Q1_Q3]
      ,[Promo_Current_Interest_CC_Q1]
      ,[DFT_Promo_Current_Interest_CC_Q1_Q2]
      ,[DFT_Promo_Current_Interest_CC_Q1_Q3]
      ,[RevolvingBalance_CC_Q1]
      ,[DFT_RevolvingBalance_CC_Q1_Q2]
      ,[DFT_RevolvingBalance_CC_Q1_Q3]
      ,[AVG_UTILIZATION_RATE_CC_Q1]
      ,[DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2]
      ,[DFT_AVG_UTILIZATION_RATE_CC_Q1_Q3]
      ,[Count_Durable_CC]
      ,[max_credit_Limit]
      ,[max_age_member_CC]
      ,[Max_Extract_ACCOUNT_OPEN_DATE_CC]
      ,[Max_Closed_account_flag_CC]
      ,[Max_MOB_CC]
      ,[ChargeoffAmount_final_CC]
      ,[Max_chargoff_date_CC]
      ,[CL_CC_StaticPool]
      ,[MOB_CC_staticPool]
      ,[TRIP_FLAG_staticpool]
      ,[CL_DIFF_past_oneyear]
      ,[Days Since Last Login]
	  into #CLD_final
	  from #loan_dep_onlinebanking aa


/*** monthly bureua data *****/ 
drop table if exists #CLD_final1
select aa.*
,BB.FICO,
BB.CCAPREstimate,
BB.AggregatedSpendPast3Months,
BB.TopOfWalletCCAnnualSpend,
BB.TopOfWalletCCCurrentBalance,
BB.OpenTradeCount,
BB.OpenTradeBalance,
BB.AutoOpenTradeCount,
BB.AutoLoanOrgBalanceP12Months,
BB.AutoOpenTradeBalance,
BB.CCCount,
BB.CCOpenCount,
BB.CCTotalAvailableLOC,
BB.CCOpenBalance,
BB.ChargeOffTradeCountP12Months,
BB.ChargeOffTotalBalance,
BB.ForeclosureCountP12Months,
BB.ForeclosureTotalBalance,
BB.BankruptcyCount,
BB.NumberInquiriesP6Months,
BB.CCWorstRatingP12Months,
BB.AutoWorstRatingP12Months,
BB.MortgageWorstRatingP12Months,
BB.HELOCWorstRatingP12Months,
BB.HEWorstRatingP12Months,
BB.HEOpenCount,
BB.HETotalAvailableLOC,
BB.HEOpenBalance,
BB.HELOCOpenCount,
BB.HELOCTotalAvailableLOC,
BB.HELOCOpenBalance,
BB.MortgageOpenCount,
BB.MortgageOpenBalance,
BB.RevolvingAccountCount,
BB.CCRevolvingBalance,
BB.CCTripTypeP6Months,
BB.StudentLoanOpenCount,
BB.StudentLoanOpenBalance,
BB.IncomeEstimator,
BB.IncomeToDebtEstimator,
BB.AccountManagementScore,
BB.BankcardPropensity,
BB.AutoPropensity,
BB.AutoRefiPropensity,
BB.HELOCPropensity,
BB.MortgagePropensity
into #CLD_final1
from #CLD_final aa
left join (SELECT * FROM OPENQUERY([GSDWSQL01],'SELECT * FROM [BureauData].[dbo].[TransUnionAttributeHistory] where Date = ''202204'' ')) BB
on aa.SSN003 = BB.ssn

/**** StaticPool Scenario Flag *****/
DECLARE @staticpooldate date
set @staticpooldate = '2022-04-01'

drop table if exists  #static_CC
select DISTINCT [Social Security Number]
--,CASE WHEN ChargeoffAmount_final > 0 THEN 1 ELSE 0 END AS tARGET_fLAG
into #static_CC
from TMGData..cardholder
where 1 = 1
and [External Status Code] not in ('c','z')
and fullExtractdate = @staticpooldate --between DATEADD(MM,1,@staticpooldate) AND  DATEADD(MM,12,@staticpooldate)
--and [Social Security Number] in (select distinct SSN003 from #CLD_final1)


/*** creating Master for credit card ****/
select * 
into #creditMaster
from #CLD_final1
where SSN003 in (select [Social Security Number] from #static_CC)

/**** StaticPool Scenario Flag *****/
DECLARE @staticpooldate date
set @staticpooldate = '2022-04-01'

drop table if exists #targetFlag
select distinct aa.[Social Security Number],
case when bb.ChargeoffAmount_final > 0 then 1 else 0 end as Target_flag
into #targetFlag
from #static_CC aa
left join TMGData..cardholder bb
on aa.[Social Security Number] = bb.[Social Security Number]
where 1 = 1
and aa.[Social Security Number] in (select distinct SSN003 from #CLD_final1)
and fullExtractdate between DATEADD(MM,1,@staticpooldate) AND  DATEADD(MM,12,@staticpooldate)


/**** Merging Target Flag with Master Data ****/
drop table if exists Analytics.dbo.CLD_Final_Data 
select aa.* ,bb.Target_flag
into Analytics.dbo.CLD_Final_Data 
from #creditMaster aa
left join #targetFlag bb
on aa.SSN003 = bb.[Social Security Number]
where Target_flag is not null

select Target_flag,count(SSN003)
from Analytics.dbo.CLD_Final_Data 
group by Target_flag




--static pool__savings balance

   --   ,[AVG_CHARGEOFFAMOUNT_SAVINGS_SP]
   --   ,[AVG_CHARGEOFFAMOUNT_SAVINGS_Q1]
   --   ,[DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q2]
   --   ,[DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q3]
	  ----instead of average we need sum


	  --  ,[AVG_TRANSACTION_SAVINGS_Q1]
   --   ,[DFT_AVG_TRANSACTION_SAVINGS_Q1_Q2]
   --   ,[DFT_AVG_TRANSACTION_SAVINGS_Q1_Q3]
	  ----instead of average we need sum

	  --MAX_CREDITLIMIT
	  ----instead of Max we need sum
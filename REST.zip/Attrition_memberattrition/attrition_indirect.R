rm(list=ls()) #removingobjects from the background
getwd()   #get directory
library(RODBC)
databaseConnection <- odbcDriverConnect("Driver={SQL Server};server=ACARCU01")

Checking_Data <- sqlQuery(databaseConnection, "select  *  from analytics.[UICCU\\sadamhuseni].Indirect_Member_attrition_data_20220120")
Checking_dataframe <- data.frame(Checking_Data,stringsAsFactors=FALSE)
View(Checking_dataframe)
unique(Checking_Data$Diff_Month_end_balance_Money_Market_Q1_Q2)
# Column_type <- sapply(Checking_dataframe,class)
# write.csv(Column_type,"Columnnames.csv")
index_number <- colnames(Checking_dataframe)
write.csv(index_number,"index_number.csv")
# Checking_dataframe_colnames<- colnames(Checking_dataframe)
# write.csv(Checking_dataframe_colnames,"Checking_dataframe_colnames.csv")
Checking_dataframe_1<- Checking_dataframe[,c(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,29,30,31,32,33,34,35,36,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,174,175,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,232,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,318,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,401,411,416,418,422,427,429,433,438,440,444,449,451,455,460,462,463,464,465,467,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,523,524,525,526,527,528,529,530,531,532,533,534,535,536,537,538,539,540,541,542,545,546,547,548,549,550,551,552,553,554,555,556,557,580,581,582,583,584,585,586,587,588,589,590,591,592,595,596,597,598,599,600,601,602,603,604,605,606,607,630,631,632,633,634,635,636,637,638,639,640,641,642,645,646,647,648,649,650,651,652,653,654,655,656,657,680,681,682,683,684,685,686,687,688,689,690,691,692,695,696,697,698,699,700,701,702,703,704,705,706,707,730,731,732,733,734,735,736,737,738,739,740,741,742,743,744,745,746,747,748,749,750,751,752,753,754,755,756,757,758,759,760,761,762,763,764,765,766,767,768,769,770,771,772,773,774,775,776,777,778,779,780,781,782,783,784,785,786,787,788,789,790,791,792,793,794,795,796,797,798,799,800,801,802,803,804,805,806,807,808,809,810,811,812,813,814,815,816,817,818,819,820,821,822,823,824,825,826,827,828,829,830,831,832,833,834,835,836,837,838,839,840,841,842,843,844,845,846,847,848,849,850,851,852,853,854,855,856,857,858,859,860,861,862,863,864,865,866,867,868,869,870,871,872,873,874,875,876,877,878,879,880,881,884,885,886,887,888,891,893,896,898,899,902,903,904,905,906,909,911,914,916,917,920,921,922,923,924,927,929,932,934,935,938,939,940,941,942,945,947,950,952,953,956,957,958,959,960,961,962,963,964,965,966,967,968,969,970,973,974,975,976,977,978,979,980,981,982,983,984,985,987,988,989,991)]
ncol(Checking_dataframe_1)
#Checking_dataframe_1 <- Filter(function(x)sd(x) !=0,Checking_dataframe)
#library(pastecs)
#Summary_file <- stat.desc(Checking_dataframe)
#write.csv(Summary_file,"Statistics_summary.csv")
#
Myfunction1 <- function(data)
{
  a <- data.frame()
  e <- data.frame()
  f <- data.frame()
  G <- data.frame()
  H <- data.frame()
  I <- data.frame()
  J <- data.frame()
  K <- data.frame()
  L <- data.frame()
  M <- data.frame()
  N <- data.frame()
  Col_bined <- data.frame()
  
  for (i in 1:ncol(data))
  {
    if(class(data[,c(i)])!="factor") {
      Total_count <- NROW(data)-(sum(is.na(data[,c(i)]))+sum(data[,c(i)]==0,na.rm = TRUE))
      Count_NA <- data.frame(sum(is.na(data[,c(i)])))
      Count_zero <- data.frame(sum(data[,c(i)]==0,na.rm = TRUE))
      Mean_1 <- data.frame(mean(data[,c(i)],na.rm = TRUE))
      Median_1 <- data.frame(median(data[,c(i)],na.rm = TRUE))
      std <- data.frame(sd(data[,c(i)],na.rm = TRUE))
      Max_1 <- data.frame(max(data[,c(i)],na.rm = TRUE))
      Min_1 <- data.frame(min(data[,c(i)],na.rm = TRUE))
      b <-data.frame(colnames(data)[i],quantile(data[,c(i)],.25,na.rm = TRUE))
      c <-data.frame(quantile(data[,c(i)],.75,na.rm = TRUE))
      d <-data.frame(quantile(data[,c(i)],.99,na.rm = TRUE))
      row.names(Count_NA) <- NULL
      row.names(Count_zero) <- NULL
      row.names(Mean_1) <- NULL
      row.names(Median_1) <- NULL
      row.names(std) <- NULL
      row.names(Max_1) <- NULL
      row.names(Min_1) <- NULL
      row.names(Total_count) <- NULL
      row.names(b) <- NULL
      row.names(c) <- NULL
      row.names(d) <- NULL
      
      a <- rbind(b,a)
      e <- rbind(c,e)
      f <- rbind(d,f)
      
      G <- rbind(Count_NA,G)
      H <- rbind(Count_zero,H)
      I <- rbind(Mean_1,I)
      J <- rbind(Median_1,J)
      K <- rbind(Max_1,K)
      L <- rbind(Min_1,L)
      M <- rbind(std,M)
      N <- rbind(Total_count,N)
      Col_bined <- data.frame(cbind(a,e,f,N,G,H,I,J,M,K,L))
      colnames(Col_bined) <- c("Variables","Percentile 25%","Percentile 75%","Percentile 99%"
                               ,"Total_No_obs","Count_NA","Count_zero","Mean","Median","Standard_Deviation","Max","Min")
      
    }
    
  }
  
  Col_bined1<- data.frame(apply(Col_bined,2,rev))
  
  write.csv(Col_bined1,"Summary_checking_attrition.csv")
}

Myfunction1(Checking_dataframe_1)

# column_name <- colnames(Checking_dataframe_1)
# write.csv(column_name,"colname_datafrma1.csv")
#
Checking_dataframe_2 <- Checking_dataframe_1[,c(780,20,21,22,24,25,26,28,29,30,31,32,33,35,38,42,43,44,45,46,48,50,51,52,53,54,55,56,57,58,59,62,63,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,85,86,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,108,109,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,131,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,150,153,154,155,156,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,183,184,185,186,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,297,298,299,300,301,305,306,307,308,309,310,311,312,313,314,315,319,320,321,322,323,324,325,326,327,328,329,333,334,335,336,337,338,339,340,341,342,343,348,349,350,351,352,353,354,355,356,357,358,363,364,365,366,367,368,369,370,371,391,392,393,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,607,608,609,610,611,612,613,614,615,616,618,620,621,622,623,624,625,626,627,628,629,630,631,633,635,636,637,638,639,640,641,642,643,644,645,646,647,648,649,650,651,652,653,654,655,656,662,664,666,670,677,679,681,685,692,693,694,696,697,698,699,701,702,703,704,706,762,763,764,765,766,767,768,769,770,771,773,774,775,776,777,778)]
index_number2 <- colnames(Checking_dataframe_2)
write.csv(index_number2,"index_number2.csv") 
Checking_dataframe_3 <- Checking_dataframe_2[,c(1,152,163,155,159,154,162,158,157,181,237,241,182,184,197,199,183,156,242,244,212,214,196,192,8,89,86,177,85,97,198,10,19,243,37,13,35,160,178,207,161,179,170,213,227,229,104,106,105,107,108,103,211,110,96,30,90,27,87,36,95,33,32,92,34,93,94,25,24,84,28,88,31,91,26,29,111,40,99,42,101,39,98,41,100,43,102,38,109,112,57,50,47,56,53,52,54,55,45,44,48,51,46,49,60,62,59,61,63,58,23,18,11,17,15,16,9,12,14,20,21,22,5,7,6,2,4,3,222,185,191,180,176,239,206,215,168,77,70,67,76,73,72,74,75,65,64,68,71,66,69,80,82,79,81,83,78,334,221,238,169,345,228,323,195,171,194,193,172,226,314,336,347,309,200,312,210,209,208,335,346,173,174,175,325,310,186,188,187,189,190,311,201,324,203,202,204,205,225,240,224,223,313,216,218,217,219,220,232,231
)]
Checking_dataframe_2$Attrition_flag
NAReplace_data <- replace(Checking_dataframe_3,is.na(Checking_dataframe_3),-99999999)
index_number3 <- colnames(NAReplace_data)
write.csv(index_number3,"index_number3.csv") 
library(woeBinning)
binning <- woe.binning(NAReplace_data,'Attrition_flag',NAReplace_data)
tabulate.binning <- woe.binning.table(binning)

library(woeBinning)
Binning.Data <- woe.binning(NAReplace_data,'Attrition_flag',NAReplace_data)
Dataset_woe <- woe.binning.deploy(NAReplace_data,Binning.Data,add.woe.or.dum.var = "woe")

WOE_Data_Frame01 <- Dataset_woe[,c(1,420,346,354,324,264,366,334,306,228,218,358,326,300,226,372,310,280,242,374,312,282,244,386,348,340,336,240,376,314,284,248,614,612,610,608,384,320,292,254,382,322,290,252,338,404,378,316,286,246,212,422,392,566,526,488,482,408,624,424,568,528,490,456,394,570,530,492,458,396,572,532,494,460,426,574,534,496,428,576,536,498,616,430,410,412,414,416,388,578,538,500,480,390,580,540,502,484,432,582,542,504,462,434,584,544,506,464,436,586,546,508,486,466,454,588,548,510,438,590,550,402,468,440,592,552,512,442,594,554,514,470,596,556,516,444,598,558,518,472,446,600,560,520,474,448,602,562,522,450,604,564,400,476,524,606,266,220,478,418,452,626,628,294,258,368,270,274,232,352,256,298,268,278,230,344,216,360,328,302,224,398,356,350,342,238,380,318,288,250,296,260,370,272,276,234,406,262,364,332,308,236,214,362,330,304,222
)]

WOE_Data_Frame02<-WOE_Data_Frame01[,c(1,51,83,155,156,33,4,170,26,25,158,36,183,184,27,185,197,45,24,35,28,34,174,46,182,191,207,5,32,176,164,70,3,177,172,186,190,203,44,153,195,38,157,59,122,65,53,168,42,11,94,37,192,163,21,205,162,201,200,181,41,166,23,167,173,89,187,198,188,13,12,204,30,196,171
)]

index_number5 <- colnames(Dataset_woe)
write.csv(index_number5,"index_number5.csv") 

index_number6 <- colnames(WOE_Data_Frame01)
write.csv(index_number6,"index_number6.csv") 

WOEsumm <-data.matrix(tabulate.binning, rownames.force = NA)
write.csv(WOEsumm,"WOE&IV_memberattrition.csv")

library(randomForest)
library(e1071)
library(caret)
library(ROCR)
set.seed(2017)
WOE_Data_Frame01$Attrition_flag <- as.factor(WOE_Data_Frame01$Attrition_flag)
RF <- randomForest(Attrition_flag ~.,data = WOE_Data_Frame01,ntree=50)
unique(WOE_Data_Frame01$Attrition_flag)
Important_vr <- importance(RF)
write.csv(Important_vr,"Imp_VR100_all_Indirect_Member_Attrition.csv")
install.packages("digest")
library(digest)
library(randomForestExplainer)
min_depth_frame <- min_depth_distribution(RF)
plot_min_depth_distribution(min_depth_frame)

importance_frame <- measure_importance(RF)
save(importance_frame, file = "importance_frame_CheckingAttrition.rda")
load("importance_frame_Unsecured.rda")
importance_frame
write.csv(importance_frame,"Importance_frame_all_CheckingAttrition.csv")


Checking_dataframe_4 <- NAReplace_data[,c(1,2,171,203,194,172,180,192,185,181,174,173,186,18,9,41,164,4,38,5,162,158,209,210,6,176,8,3,134,200,160,12,34,7,169,204,166,196,187,193,206,189,163,199,179,170,177,178,161,17,201,11,19,132,129,137,20,31,39,42,168,167,10,45,46,53,44,202,165,23,21,40
)]



library(My.stepwise)

Checking_dataframe_4$Attrition_flag <- as.numeric(Checking_dataframe_4$Attrition_flag)
Checking_dataframe_4$Attrition_flag[Checking_dataframe_4$Attrition_flag==1]<-0
Checking_dataframe_4$Attrition_flag[Checking_dataframe_4$Attrition_flag==2]<-1
unique((WOE_Data_Frame02$Attrition_flag))
sum(WOE_Data_Frame02$Attrition_flag)
my.variable.list <- colnames(subset(WOE_Data_Frame02,select = -Attrition_flag))

summary(WOE_Data_Frame02$Attrition_flag)


My.stepwise.glm.results <- My.stepwise.glm(Y = "Attrition_flag", my.variable.list, data = WOE_Data_Frame02, sle = 0.05,
                                           sls = 0.05, myfamily="binomial")



# Final Model

GLM_Model <- glm(Attrition_flag~
                   SUM_Closed_flag_Total_Deposit_ACCT
                 +Sum_transaction_amount_checkings_Q2
                 +sum_Month_end_balance_savings_Q3
                 +Sum_transaction_amount_checkings_Staticpool
                 +Sum_LASTDIVAMOUNT_savings_Q3
                 +Avg_Month_end_balance_Checkings_Staticpool
                 ,data = Train_data,family = "binomial")



summary(GLM_Model)
library(car)
library(carData)
Anova(GLM_Model, type="II", test="Wald")
vif(GLM_Model)
alias.result <- alias(GLM_Model)


set.seed(1701)
sample_1 <- sample.int(n= nrow(WOE_Data_Frame02)
                       ,size = floor(.60*nrow(WOE_Data_Frame02)),replace = F)
Train_data <- WOE_Data_Frame02[sample_1,]
Test_data <- WOE_Data_Frame02[-sample_1,]
# Train_data$Checking_Attrition_Flag <- as.factor(Train_data$Checking_Attrition_Flag)

GLM_Model <- glm(Attrition_flag~
                   woe.SUM_Closed_flag_Total_Deposit_ACCT.binned
                 +woe.sum_Month_end_balance_Checkings_Staticpool.binned
                 +woe.sum_Month_end_balance_savings_Q1.binned
                 +woe.Last.Statment.Sale.Count_CC_Staticpool.binned
                 +woe.Sum_LASTDIVAMOUNT_savings_Q4.binned
                 +woe.Savings_ACCT_Flag.binned
                 ,data = Train_data,family = "binomial")

fitted.results <- predict(GLM_Model,Train_data,type='response')

score_train <- data.frame(Train_data[,c("Attrition_flag","woe.SUM_Closed_flag_Total_Deposit_ACCT.binned"
                                        ,"woe.sum_Month_end_balance_Checkings_Staticpool.binned"
                                        ,"woe.sum_Month_end_balance_savings_Q1.binned"
                                        ,"woe.Last.Statment.Sale.Count_CC_Staticpool.binned"
                                        ,"woe.Sum_LASTDIVAMOUNT_savings_Q4.binned"
                                        ,"woe.Savings_ACCT_Flag.binned"
)],fitted.results)
write.csv(score_train,"score_train_Indirect_Member_attrition1.csv")


library(gplots)
library(ROCR)
library(pROC)
pdata3 <- as.numeric(format(round(predict(GLM_Model,data = Train_data,type='response',na.action = na.pass))))

fitpreds = predict(GLM_Model,Train_data,type="response")
fitpred = prediction(fitpreds,Train_data$Attrition_flag)
fitperf = performance(fitpred,"tpr","fpr")
plot(fitperf,col="green",lwd=2,main="ROC Curve for Logistic:  Adult")
abline(a=0,b=1,lwd=2,lty=2,col="gray")
library(AUC)
auc(fitpreds,(Train_data$Attrition_flag))

predictions <- as.numeric(predict(GLM_Model, Train_data, type = 'response'))
multiclass.roc(Train_data$Attrition_flag, predictions)


##************ Test ****************************



fitted.test.results <- predict(GLM_Model,Test_data,type='response')
score_test <- data.frame(Test_data[,c("Attrition_flag","woe.SUM_Closed_flag_Total_Deposit_ACCT.binned"
                                      ,"woe.sum_Month_end_balance_Checkings_Staticpool.binned"
                                      ,"woe.sum_Month_end_balance_savings_Q1.binned"
                                      ,"woe.Last.Statment.Sale.Count_CC_Staticpool.binned"
                                      ,"woe.Sum_LASTDIVAMOUNT_savings_Q4.binned"
                                      ,"woe.Savings_ACCT_Flag.binned")],fitted.test.results)
write.csv(score_test,"score_test_Indirect_Member_attrition1.csv")

pdata4 <- as.numeric(format(round(predict(GLM_Model,data = Test_data,type='response',na.action = na.pass))))

fitpreds1 = predict(GLM_Model,Test_data,type="response")
fitpred1 = prediction(fitpreds1,Test_data$Attrition_flag)
fitperf1 = performance(fitpred1,"tpr","fpr")
plot(fitperf1,col="green",lwd=2,main="ROC Curve for Logistic:  Adult")
abline(a=0,b=1,lwd=2,lty=2,col="gray")
library(AUC)
auc(fitpreds1,(Test_data$Attrition_flag))

predictions1 <- as.numeric(predict(GLM_Model, Test_data, type = 'response'))
multiclass.roc(Test_data$Attrition_flag, predictions1)








---Finding active account at staticpool 

--drop table if exists #processdate 
--	select max(ProcessDate) ProcessDate,Process_Date
--	into #processdate
--	from (select ProcessDate,left(ProcessDate,6) Process_Date from ARCUSYM000..ACCOUNT group by ProcessDate) A
--	where Process_Date>=202209
--	group by Process_Date


--Savings Flag
	
	DECLARE @staticpooldate date
		set @staticpooldate = '2022-11-30'
	--set @staticpooldate = eomonth(dateadd(MM,3,@staticpooldate))


	--print @staticpooldate
	drop table if exists #Static_savings
	select distinct ssn
	into #Static_savings
	from arcusym000.dbo.SAVINGS aa
	left join ARCUSYM000.dbo.name b
						on aa.PARENTACCOUNT=b.PARENTACCOUNT
	                    and aa.processdate=b.ProcessDate 
						 where b.type=0 and
	                    b.EXPIRATIONDATE is null
						and (CLOSEDATE >= @staticpooldate or closedate is null )
						--and aa.ProcessDate=20220930	
						and Eomonth(datefromparts(left(aa.ProcessDate ,4),right(left(aa.ProcessDate,6),2),right(aa.ProcessDate,2)))	= @staticpooldate--DATEADD(mm,3,@staticpooldate)			
						--group by ssn --386347
	
	drop table if exists #ATR_3MONTH
	select SSN 
	into #ATR_3MONTH
	from 
	(select ssn,
	case when min(isnull(Closedate,1900-01-01))=1900-01-01 then 0 else 1 end as atrflag
	from arcusym000.dbo.SAVINGS aa
	left join ARCUSYM000.dbo.name b
						on aa.PARENTACCOUNT=b.PARENTACCOUNT
	                    and aa.processdate=b.ProcessDate 
						 where b.type=0 and
	                    b.EXPIRATIONDATE is null
						and ssn in (select distinct ssn from #Static_savings )
						--(CLOSEDATE >= @staticpooldate or closedate is null )
						--and aa.ProcessDate=20221231
						and Eomonth(datefromparts(left(aa.ProcessDate ,4),right(left(aa.ProcessDate,6),2),right(aa.ProcessDate,2)))	= Eomonth(DATEADD(MM,3,@staticpooldate)	)	
						group by ssn				
						) a
						where atrflag=1 --3806

		--DECLARE @staticpooldate date
		--set @staticpooldate = '2022-09-30'

		--PRINT Eomonth(DATEADD(MM,9,@staticpooldate)	)

drop table if exists #ATR_9MONTH
	select SSN 
	into #ATR_9MONTH
	from 
	(select ssn,
	case when min(isnull(Closedate,1900-01-01))=1900-01-01 then 0 else 1 end as atrflag
	from arcusym000.dbo.SAVINGS aa
	left join ARCUSYM000.dbo.name b
						on aa.PARENTACCOUNT=b.PARENTACCOUNT
	                    and aa.processdate=b.ProcessDate 
						 where b.type=0 and
	                    b.EXPIRATIONDATE is null
						and ssn in (select distinct ssn from #Static_savings )
						and ssn not in (select distinct ssn from #ATR_3MONTH )
						--(CLOSEDATE >= @staticpooldate or closedate is null )
						--and aa.ProcessDate=20230630	
						AND (datefromparts(left(aa.ProcessDate ,4),right(left(aa.ProcessDate,6),2),right(aa.ProcessDate,2)))	= Eomonth(DATEADD(MM,9,@staticpooldate)	)	
						group by ssn				
						) a
						where atrflag=1 --4960

---Final flag
drop table if exists #saving_Final
Select SSN,case when ssn in(Select ssn from #ATR_9MONTH) then 1 else 0 end as Saving_Attrition
into #saving_Final
from #Static_savings --386347


--select * from #saving_Final where Saving_Attrition=1




--Loan Attrition FLag

--DECLARE @staticpooldate date
--		set @staticpooldate = '2022-09-30'
	--set @staticpooldate = eomonth(dateadd(MM,3,@staticpooldate))
	--DECLARE @staticpooldate date
	--	set @staticpooldate = '2022-07-31'

	--print @staticpooldate
	drop table if exists #Static_Loan
	select distinct ssn
	into #Static_Loan
	from arcusym000.dbo.loan aa
	left join ARCUSYM000.dbo.name b
						on aa.PARENTACCOUNT=b.PARENTACCOUNT
	                    and aa.processdate=b.ProcessDate 
						 where b.type=0 and
	                    b.EXPIRATIONDATE is null
						and (aa.CHARGEOFFDATE>= @staticpooldate or closedate is null)
						and (CLOSEDATE >= @staticpooldate or closedate is null )
						--and aa.ProcessDate=20220930
						and Eomonth(datefromparts(left(aa.ProcessDate ,4),right(left(aa.ProcessDate,6),2),right(aa.ProcessDate,2)))= @staticpooldate--DATEADD(mm,3,@staticpooldate)			
					
						group by ssn --148799


drop table if exists #ATR_3MONTH_loan
	select distinct SSN 
	into #ATR_3MONTH_loan
	from 
	(select ssn,
	case when min(isnull(Closedate,1900-01-01))=1900-01-01 then 0 else 1 end as atrflag
	from arcusym000.dbo.loan aa
	left join ARCUSYM000.dbo.name b
						on aa.PARENTACCOUNT=b.PARENTACCOUNT
	                    and aa.processdate=b.ProcessDate 
						 where b.type=0 and
	                    b.EXPIRATIONDATE is null
						--and (aa.CHARGEOFFDATE>= @staticpooldate or closedate is null)
						and ssn in (select distinct ssn from #Static_Loan )
						--(CLOSEDATE >= @staticpooldate or closedate is null )
						--and aa.ProcessDate=20221231
						and Eomonth(datefromparts(left(aa.ProcessDate ,4),right(left(aa.ProcessDate,6),2),right(aa.ProcessDate,2)))	= Eomonth(DATEADD(MM,3,@staticpooldate)	)
						group by ssn				
						) a
						where atrflag=1 --5852


drop table if exists #ATR_9MONTH_Loan
	select SSN 
	into #ATR_9MONTH_Loan
	from 
	(select ssn,
		case when min(isnull(Closedate,1900-01-01))=1900-01-01 then 0 else 1 end as atrflag
	from arcusym000.dbo.loan aa
	left join ARCUSYM000.dbo.name b
						on aa.PARENTACCOUNT=b.PARENTACCOUNT
	                    and aa.processdate=b.ProcessDate 
						 where b.type=0 and
	                    b.EXPIRATIONDATE is null
						--and (aa.CHARGEOFFDATE>= @staticpooldate or closedate is null)
						and ssn in (select distinct ssn from #Static_Loan )
						and ssn not in (select distinct ssn from #ATR_3MONTH_loan )
						--(CLOSEDATE >= @staticpooldate or closedate is null )
						--and aa.ProcessDate=2023063
						
						AND (datefromparts(left(aa.ProcessDate ,4),right(left(aa.ProcessDate,6),2),right(aa.ProcessDate,2)))	= Eomonth(DATEADD(MM,9,@staticpooldate)	)	
						group by ssn				
						) a
						where atrflag=1
						--9359

---Final flag
drop table if exists #loan_Final
Select SSN,case when ssn in(Select ssn from #ATR_9MONTH_Loan) then 1 else 0 end as loan_Attrition
into #loan_Final

from #Static_loan



--(151858 rows affected)

--(4987 rows affected)

--(10274 rows affected)

--(151858 rows affected)

--External loan
--DECLARE @staticpooldate date
--		set @staticpooldate = '2022-09-30'
	--set @staticpooldate = eomonth(dateadd(MM,3,@staticpooldate))


	--print @staticpooldate
	drop table if exists #Static_ELoan
	select distinct ssn
	into #Static_ELoan
	from arcusym000.dbo.EXTERNALLOAN aa
	left join ARCUSYM000.dbo.NAME b
						on aa.PARENTACCOUNT=b.PARENTACCOUNT
	                    and aa.processdate=b.ProcessDate 
						 where b.type=0
						  and
	                    b.EXPIRATIONDATE is null
						--and (aa.c>= @staticpooldate or Chargoff is null)
						and (CLOSEDATE >= @staticpooldate or closedate is null )
						--and aa.ProcessDate=20220930	
						and Eomonth(datefromparts(left(aa.ProcessDate ,4),right(left(aa.ProcessDate,6),2),right(aa.ProcessDate,2)))= @staticpooldate--DATEADD(mm,3,@staticpooldate)			
						group by ssn


drop table if exists #ATR_3MONTH_eloan
	select distinct SSN 
	into #ATR_3MONTH_eloan
	from 
	(select ssn,
		case when min(isnull(Closedate,1900-01-01))=1900-01-01 then 0 else 1 end as atrflag
	from arcusym000.dbo.EXTERNALLOAN aa
	left join ARCUSYM000.dbo.name b
						on aa.PARENTACCOUNT=b.PARENTACCOUNT
	                    and aa.processdate=b.ProcessDate 
						 where b.type=0 and
	                    --b.EXPIRATIONDATE is null
						--and (aa.CHARGEOFFDATE>= @staticpooldate or closedate is null)
						 ssn in (select distinct ssn from #Static_ELoan )
						--(CLOSEDATE >= @staticpooldate or closedate is null )
						--and aa.ProcessDate=20221231
							
						and Eomonth(datefromparts(left(aa.ProcessDate ,4),right(left(aa.ProcessDate,6),2),right(aa.ProcessDate,2)))	= Eomonth(DATEADD(MM,3,@staticpooldate)	)
	
						group by ssn				
						) a
						where atrflag=1


drop table if exists #ATR_9MONTH_ELoan
	select   SSN 
	into #ATR_9MONTH_ELoan
	from 
	(select DISTINCT ssn,
		case when min(isnull(Closedate,1900-01-01))=1900-01-01 then 0 else 1 end as atrflag
	from arcusym000.dbo.EXTERNALLOAN aa
	left join ARCUSYM000.dbo.name b
						on aa.PARENTACCOUNT=b.PARENTACCOUNT
	                    and aa.processdate=b.ProcessDate 
						 where b.type=0
						  and
	                    --b.EXPIRATIONDATE is null
						--and (aa.CHARGEOFFDATE>= @staticpooldate or closedate is null)
						 ssn in (select distinct ssn from #Static_ELoan)
						--and ssn not in (select distinct ssn from #ATR_3MONTH_eloan )
						--(CLOSEDATE >= @staticpooldate or closedate is null )
						--and aa.ProcessDate=20230630	
						
						AND (datefromparts(left(aa.ProcessDate ,4),right(left(aa.ProcessDate,6),2),right(aa.ProcessDate,2)))	= Eomonth(DATEADD(MM,9,@staticpooldate)	)	
						group by ssn				
						) a
						where atrflag=1

---Final flag
drop table if exists #eloan_Final
Select SSN,case when ssn in(Select ssn from #ATR_9MONTH_ELoan) then 1 else 0 end as eloan_Attrition
into #eloan_Final
--,1 as Attritionflag 
from #Static_eloan
--where ssn not in (Select ssn from #ATR_3MONTH_eloan)


select * from #loan_Final where loan_Attrition=1

---Credit card 


drop table if exists #CC_staticpool 
select distinct [Social Security Number] 
into #CC_staticpool
from TMGData.dbo.cardholder 
where 
extract_datepart=202211
and Active_Flag=1
and [External Status Code] not in ('C','Z')
and [Internal Status Code] in ('')


drop table if exists #CC_atr3

Select * into 
#CC_atr3 from 
(select distinct [Social Security Number],
	case when min(Closed_account_flag) = 0 then 0 else 1 end as atrflag
from TMGData.dbo.cardholder 
where 
extract_datepart=202302
and [Social Security Number] in (select * from #CC_staticpool)
--and Active_Flag=1
and Closed_account_flag<> 'NA'
group by [Social Security Number]) a
where atrflag=1	
--and [External Status Code] not in ('C','Z')
--and [Internal Status Code] in (''))


drop table if exists #CC_atr9
Select * into 
#CC_atr9 from
(select distinct [Social Security Number]
,case when min(Closed_account_flag) = 0 then 0 else 1 end as atrflag

from TMGData.dbo.cardholder 
where 
extract_datepart=202308
and [Social Security Number] in (select * from #CC_staticpool)
and [Social Security Number] not in (select [Social Security Number] from #CC_atr3)
and Closed_account_flag<>'na'
group by [Social Security Number]
) a
where  atrflag = 1	

drop table if exists #cc_final 
select [Social Security Number],case when [Social Security Number] in
(Select [Social Security Number] from #CC_atr9) then 1 else 0 end as CC_Attrition
into #cc_final
from #CC_staticpool
--where  [Social Security Number] not in (Select [Social Security Number] from #CC_atr3)



---ssn combine

Drop table if exists #allssn
Select distinct ssn
into #allssn
 from (
select ssn from #Static_savings
union 
select ssn from #Static_Loan
union
select ssn from #Static_ELoan
union
select [Social Security Number] ssn from #CC_final
) a


drop table if exists #final
select ssn,
1 as attrition_flag
into #final
from 
(select E.* ,ISNULL(A.Saving_Attrition,1) Saving_Attrition ,
ISNULL(B.loan_Attrition,1) loan_Attrition,
ISNULL(C.eloan_Attrition,1) eloan_Attrition
,ISNULL(D.CC_Attrition,1) CC_Attrition
 
from #allssn e
left join  
#saving_Final a
on e.SSN=a.SSN
left join 
#loan_Final b
on e.SSN=b.SSN
left join 
 #eloan_Final c
 on e.SSN=c.SSN
 left join 
 #cc_final d
 on e.SSN=d.[Social Security Number]) a
 where 1=1 
and Saving_Attrition=1
 and loan_Attrition=1
 and eloan_Attrition=1
 and CC_Attrition=1


 ---Final data creation 

 drop table if exists analytics.dbo.Member_Attrition_MOdel_2911
 Select a.*,case when SSN003  in (select ssn from #final) then 1 else 0 end attrition_flag
 --isnull(b.attrition_flag,0) attrition_flag1 
 into analytics.dbo.Member_Attrition_MOdel_2911
 from  Analytics.dbo.REVISED_MASTER_DATA_Nov_2022 a
 

 SELECT * FROM Analytics.dbo.AttrtionFlag

 sELECT COUNT(*) FROM analytics.dbo.Member_Attrition_MOdel      wHERE attrition_flag=1
 sELECT COUNT(*) FROM analytics.dbo.Member_Attrition_MOdel_2911	wHERE attrition_flag=1


 --Splitting the data 

 /************ SPLITTING INTO TRAIN AND TEST **************/


 	DROP TABLE IF EXISTS #SPLIT

			SELECT *,(CASE WHEN NTILE(10) OVER (ORDER BY RAND()) <= 7 THEN 'TRAIN' ELSE 'TEST' END) SPLIT
			INTO #SPLIT
			FROM Analytics.dbo.Member_Attrition_MOdel_2911

			/************ TRAIN DATA ************/

			DROP TABLE IF EXISTS  Analytics.dbo.Member_Attrition_MOdel_2911_TRAIN

			SELECT WITHDRAWAL_COUNT_CHECKING_Q1,
                               DFT_CREDIT_SCORE_SP_Q4,
                               DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2,
                               TOTAL_PRODUCT_Q1,
                               MOB_SAVINGS,
                               CCOpenBalance,
                               DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3,
                               DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3,
                               AutoOpenTradeCount,
                               Max_Loan_Month_to_Maturity,
                               OpenTradeCount,
                               TopOfWalletCCAnnualSpend,
                               -- MortgageOpenCount,
                               New_product_Loan_Past_3month,
                               New_product_Loan_Past_6month,
                               Closed_product_Loan_Past_3month,
                               Closed_product_Loan_Past_6month,
                               New_product_Deposit_Past_3month,
                               New_product_Deposit_Past_6month,
                               Closed_product_Deposit_Past_3month,
                               Closed_product_Deposit_Past_6month,
                               attrition_flag ,ROW_NUMBER() OVER ( ORDER BY ssn003 DESC) RowNo
			INTO Analytics.dbo.Member_Attrition_MOdel_2911_TRAIN
			FROM #SPLIT
			WHERE SPLIT = 'TRAIN'    --43257

			
			

			/************ TEST DATA ************/

			DROP TABLE IF EXISTS Analytics.dbo.Member_Attrition_MOdel_2911_TEST

			SELECT WITHDRAWAL_COUNT_CHECKING_Q1,
                               DFT_CREDIT_SCORE_SP_Q4,
                               DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2,
                               TOTAL_PRODUCT_Q1,
                               MOB_SAVINGS,
                               CCOpenBalance,
                               DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3,
                               DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3,
                               AutoOpenTradeCount,
                               Max_Loan_Month_to_Maturity,
                               OpenTradeCount,
                               TopOfWalletCCAnnualSpend,
                               -- MortgageOpenCount,
                               New_product_Loan_Past_3month,
                               New_product_Loan_Past_6month,
                               Closed_product_Loan_Past_3month,
                               Closed_product_Loan_Past_6month,
                               New_product_Deposit_Past_3month,
                               New_product_Deposit_Past_6month,
                               Closed_product_Deposit_Past_3month,
                               Closed_product_Deposit_Past_6month,
                               attrition_flag ,ROW_NUMBER() OVER ( ORDER BY ssn003 DESC) RowNo2
			INTO Analytics.dbo.Member_Attrition_MOdel_2911_TEST
			FROM #SPLIT
			WHERE SPLIT = 'TEST'     --389312

			


			Select Count(*) from Analytics.dbo.Member_Attrition_MOdel_2911_TRAIN 

			Select Count(*) from Analytics.dbo.Member_Attrition_MOdel_2911_test 









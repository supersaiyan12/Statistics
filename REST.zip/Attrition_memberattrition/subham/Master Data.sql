--	exec [dbo].[Dynamic_Master_data  MEMBER_ATTRITION_040822] '2021-03-31'
	

USE [Analytics]
GO
/****** Object:  StoredProcedure [dbo].[Dynamic_Master_data 20211212]    Script Date: 4/8/2022 2:16:41 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 

	CREATE procedure [dbo].[Dynamic_Master_data MEMBER_ATTRITION_040822] @staticpooldate as date
		as 
	begin 		
				
		--Fresh Start
				--Real Estate
				--Secured
				--Unsecured
				--Vehicles
				--Wealth Management
				--Work Out
		--DECLARE @STATICPOOLDATE DATE
		--SET @STATICPOOLDATE='2020-05-31'

		drop table if exists #Temp_1
		drop table if exists #Temp_multi_SSN
		drop table if exists #Temp_11
		drop table if exists #Temp_2
		drop table if exists #Temp_3
		drop table if exists #Temp_22
		drop table if exists #NAME
		drop table if exists #Static_SSN_account_final
		drop table if exists #Static_SSN_account
		drop table if exists #Account_SSN_Name
		drop table if exists #commercial_loan
		drop table if exists #Real_Estate
		drop table if exists #Real_Estate2
		drop table if exists #Secured
		drop table if exists #Unsecured
		drop table if exists #Vehicles
		drop table if exists #Wealth_Management
		drop table if exists #Work_Out
		drop table if exists  #LOAN_TRANSACITON_DATA
		drop table if exists  #loan_transaction_data_0
		drop table if exists  #groupproducttype_Deposits
		drop table if exists  #CC_Target_Flag
		drop table if exists  #desposit_Target_variable
		drop table if exists  #Loan_target_variable
		drop table if exists  #savings_account
		drop table if exists  ##Saving_transaction
		drop table if exists  #Saving_account_data
		drop table if exists  #Loan_product_summary
		drop table if exists  #Deposit_account_data
		drop table if exists  ##Deposit_transaction
		drop table if exists  #Deposit_Product_all_data
		drop table if exists  #Deposit_summary
		drop table if exists  ##Checkings_transaction
		drop table if exists  #Checkings_account_data
		drop table if exists  #Certificates_account
		drop table if exists  ##Certificates_transaction
		drop table if exists  #Certificates_account_data
		drop table if exists  ##Money_Market_transaction
		drop table if exists  #Money_Market_account_data
		drop table if exists  #CC_Members_Static
		drop table if exists  #CC_data
		drop table if exists  #Credit_Card_data
		drop table if exists ##masterdata



		--		 -- drop table if exists #Temp_1
		--select distinct  SSN,AccountNumber PARENTACCOUNT  
		--into #Temp_1 
		--from AE_EDW..D_Member
		--where SSN is not null	

		

		---- drop table if exists #Temp_multi_SSN
		--select PARENTACCOUNT,count(distinct SSN) Counts 
		--into #Temp_multi_SSN
		--from #Temp_1
		--group by PARENTACCOUNT
		--having count(distinct SSN)>1

		
		----	drop table if exists #Temp_11
		--select * 
		--into #Temp_11
		--from #Temp_1
		--where PARENTACCOUNT not in (select PARENTACCOUNT from #Temp_multi_SSN)

		
		
		----	drop table if exists #Temp_2
		--select distinct SSN,PARENTACCOUNT 
		--into #Temp_2
		--from
		--(select distinct  SSN,PARENTACCOUNT
		 
		-- from ARCUSYM000..NAME
		-- where PARENTACCOUNT not in (select PARENTACCOUNT from #Temp_11) 
		-- and SSN is not null) a
		-- where 
		--  SSN not in (select SSN from #Temp_11)
			
			

		--	-- drop table if exists #temp_3
		--	select distinct max(ProcessDate) Max_processdate,PARENTACCOUNT,SSN 
		--	into #Temp_333
		--	from ARCUSYM000..name
		--	where PARENTACCOUNT in 
		--	 ( select PARENTACCOUNT from (select PARENTACCOUNT,count(distinct SSN) Counts 
		--	--into #Temp_3
		--	from #Temp_2
		--	group by PARENTACCOUNT
		--having count(distinct SSN)>1 ) a ) and ORDINAL=0
		--group by PARENTACCOUNT,SSN
		--order by PARENTACCOUNT,SSN

		--select max(Max_processdate) Max_processdate,PARENTACCOUNT 
		--into #temp_33
		--from #Temp_333
		--group by PARENTACCOUNT
		--order by PARENTACCOUNT

		--select a.PARENTACCOUNT,a.SSN 
		--into #Temp_3333
		--from #Temp_333 a
		--inner join #temp_33 b
		--on a.Max_processdate=b.Max_processdate
		--and a.PARENTACCOUNT=b.PARENTACCOUNT
		---- drop table if exists #Temp_3
		--select * 
		--into #Temp_3
		--from #Temp_3333
		--where ssn not in (select ssn from 
		--(select SSN,count(distinct PARENTACCOUNT) counts from #Temp_3333
		--group by SSN
		--having count(distinct PARENTACCOUNT) >1 ) sa )

			

		--	-- drop table if exists analytics..R2_CC_Member
		--	--select * 
		--	--into analytics..R2_CC_Member
		--	--from
		--	--(select * from #NAME3
		--	--union
		--	--select * from #member_ssn ) A

			
		--	-- drop table if exists #NAME
		--	select * 
		--	into #NAME
		--	from
		--	(select * from #Temp_11
		--	union
		--	select * from #Temp_3 ) A
		--	-- drop table if exists analytics..R2_CC_Member
		--	--select * 
		--	--into analytics..R2_CC_Member
		--	--from
		--	--(select * from #NAME3
		--	--union
		--	--select * from #member_ssn ) A
			
		---- drop table if exists #Static_SSN_account_final
		--select distinct  SSN 
		--into ##Static_SSN_account_final
		-- from
		--(select b.SSN,a.PARENTACCOUNT,id
		--,cast(OPENDATE as date) OPEN_DATE
		--,cast(CLOSEDATE as date) CLOSE_DATE
		--,cast(CHARGEOFFDATE as date) CHARGEOFFDATE
		--,left(a.ProcessDate,6) ProcessDate_V
		--,datefromparts(left(a.ProcessDate ,4),right(left(a.ProcessDate,6),2),right(a.ProcessDate,2)) Process_date
		--,case when len(month(closedate))=1 then CONCAT(year(closedate),0,month(closedate)) 
		--else CONCAT(year(closedate),month(closedate)) end closed_date_Savings 
		--,case when len(month(OpenDate))=1 then CONCAT(year(OpenDate),0,month(OpenDate)) 
		--else CONCAT(year(OpenDate),month(OpenDate))end  OPEN_date_INT_Savings
		--,case when len(month(CHARGEOFFDATE))=1 then CONCAT(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE)) 
		--else CONCAT(year(CHARGEOFFDATE),month(CHARGEOFFDATE))end  Chargeoff_date_Savings
		
		--from ARCUSYM000..SAVINGS a
		--left join #NAME b
		--on a.PARENTACCOUNT=b.PARENTACCOUNT
		--) aa
		--left join 
		--(select ssn SSN1,DATEDIFF(month,min_opendate,@staticpooldate) Savings_ACCT_MOB from(
		--select ssn,min(Min_Opendate) Min_Opendate from
		--(
		--select PARENTACCOUNT,id,MIn(cast(OPENDATE as date)) Min_Opendate
		--from ARCUSYM000..SAVINGS
		--group by PARENTACCOUNT,ID ) F
		--left join ARCUSYM000..name G
		--on f.PARENTACCOUNT=g.PARENTACCOUNT 
		--group by ssn ) A ) AB
		--on aa.SSN=ab.SSN1
		--where ssn is not null and Savings_ACCT_MOB>=12 and 
		-- OPEN_DATE<@staticpooldate  
		-- and (CLOSE_DATE is null or CLOSE_DATE>@staticpooldate)
		--and (CHARGEOFFDATE is null or CHARGEOFFDATE>@staticpooldate)  
		--and Process_date=@staticpooldate 
		
	
		
		--	--	go
		
		--	-- drop table if exists #Static_SSN_account
	
		--	select distinct 
		--	PARENTACCOUNT AccountNumber,SSN
		--	into #Static_SSN_account
		--	from #NAME
		
				select distinct a.PARENTACCOUNT,SSN 
		into #NAME
		from 
		(select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date from ARCUSYM000..NAME) a
		left join ARCUSYM000..SAVINGS b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		and a.ProcessDate=b.ProcessDate
		where a.TYPE=0
		and a.Process_date=@staticpooldate
		
			
		-- drop table if exists #Static_SSN_account_final
		select distinct  SSN 
		into #Static_SSN_account_final
		 from
		(select b.SSN,a.PARENTACCOUNT,id
		,cast(OPENDATE as date) OPEN_DATE
		,cast(CLOSEDATE as date) CLOSE_DATE
		,cast(CHARGEOFFDATE as date) CHARGEOFFDATE
		,left(a.ProcessDate,6) ProcessDate_V
		,datefromparts(left(a.ProcessDate ,4),right(left(a.ProcessDate,6),2),right(a.ProcessDate,2)) Process_date
		,case when len(month(closedate))=1 then CONCAT(year(closedate),0,month(closedate)) 
		else CONCAT(year(closedate),month(closedate)) end closed_date_Savings 
		,case when len(month(OpenDate))=1 then CONCAT(year(OpenDate),0,month(OpenDate)) 
		else CONCAT(year(OpenDate),month(OpenDate))end  OPEN_date_INT_Savings
		,case when len(month(CHARGEOFFDATE))=1 then CONCAT(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE)) 
		else CONCAT(year(CHARGEOFFDATE),month(CHARGEOFFDATE))end  Chargeoff_date_Savings
		
		from ARCUSYM000..SAVINGS a
		left join #NAME b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		) aa
			left join 
			(select ssn SSN1,DATEDIFF(month,min_opendate,@staticpooldate) Savings_ACCT_MOB 
			from
				(select ssn,min(Min_Opendate) Min_Opendate from
					(
					select PARENTACCOUNT,id,MIn(cast(OPENDATE as date)) Min_Opendate
					from ARCUSYM000..SAVINGS
					group by PARENTACCOUNT,ID ) F
							left join ARCUSYM000..name G
							on f.PARENTACCOUNT=g.PARENTACCOUNT 
							group by ssn ) A 
											) AB
			on aa.SSN=ab.SSN1
			where ssn is not null and Savings_ACCT_MOB>=12 and 
			 OPEN_DATE<@staticpooldate  
			 and (CLOSE_DATE is null or CLOSE_DATE>@staticpooldate)
			and (CHARGEOFFDATE is null or CHARGEOFFDATE>@staticpooldate)  
			and Process_date=@staticpooldate 
		

	
	
			select distinct 
			PARENTACCOUNT AccountNumber,SSN
			into #Static_SSN_account
			from #NAME


	-----------------------------------------------------------------------------------------
	-- drop table if exists #Account_SSN_Name
			select distinct  PARENTACCOUNT,ssn 
			Into #Account_SSN_Name
			from #NAME
			
		
		
		


			-----  loan

			-------   LoanCategory1 -----------
				--Closed Loan Types
				--Collections
				--Commercial
				--Fresh Start
				--Real Estate
				--Secured
				--Unsecured
				--Vehicles
				--Wealth Management
				--Work Out


			-----------------------------------
			----------------------------------
			-----///*** commercial ***\\\---
			--  drop table if exists #commercial_loan
			
			
			
			
			select 
			*
			,case when LoanCategory1='Commercial' and Quarters='Staticpool' then 1 else 0 end Staticpool_Commercial_loan_flag
			 into #commercial_loan
			from
			(
			select [ProcessDate],left(ProcessDate,6) ProcessDate_V,Process_Date,Open_date,Close_date
			,case when Process_Date in ((DATEADD(month,-12,@staticpooldate)),(DATEADD(month,-11,@staticpooldate)),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    
			when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    
			when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
			,d.SSN
			,[PARENTACCOUNT]
			,[ID]
			,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
			,case when len(month(a.closedate))=1 then CONCAT(year(a.closedate),0,month(a.closedate))
			else CONCAT(year(a.closedate),month(a.closedate)) end  Closed_date_INT
			,case when len(month(a.opendate))=1 then CONCAT(year(a.opendate),0,month(a.opendate))
			else CONCAT(year(a.opendate),month(a.opendate)) end  OPEN_date_INT
			,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
			,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
			,[TYPE]
			,[LASTFMDATE]
			,[LASTTRANDATE]
			,[ORIGINALDATE]
			,a.[OPENDATE]
			,a.[CLOSEDATE]
			,[LOANCODE]
			,[APPROVALCODE]
			,[APPROVALDATE]
			,[PAYMENTFREQUENCY]
			,[PARTIALPAYMENT]
			,[PAYMENT]
			,[PAYMENTCOUNT]
			,[DUEDAY1]
			,[INTERESTRATE]
			,[ORIGINALBALANCE]
			,[CREDITLIMIT]
			,[DESCRIPTION]
			,[NSFMONTHTODATE]
			,[MATURITYDATE]
			,[APR]
			,[CREDITSCORE]
			,[ADVANCEAMOUNT]
			,b.LoanCategory1
			,b.LoanTypeDescription,CRPMTCURRENT
			from 
			 (select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date,cast(OPENDATE as date) Open_date
			 ,cast(CLOSEDATE as date) Close_date,cast(MATURITYDATE as date) as MATURITY_DATE from ARCUSYM000..LOAN) a
			
			left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
		on b.loantype=a.TYPE
		left join  #Static_SSN_account d
		on a.PARENTACCOUNT=d.AccountNumber

		
			where  ORIGINALDATE is not null and a.OpenDate is not null and a.Open_date < @staticpooldate  and
		(a.CLOSEDATE is null or a.Close_date>@staticpooldate )   
			and  Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate)) 
		and  PARENTACCOUNT in (select AccountNumber from #Static_SSN_account )
		) AA
		where  LoanCategory1='Commercial'  and OPEN_DATE<@staticpooldate
		 and (Close_date is null or Close_date>@staticpooldate) and ORIGINALDATE>= Open_date and Quarters is not null
		--print @staticpool
		

		
		
		
			-----------------------------------
			----------------------------------
			-----///*** Real Estate ***\\\---
			--  drop table if exists #Real_Estate
			
				--Secured
				--Unsecured
				--Vehicles
				--Wealth Management
				--Work Out
			
			

			select 
			*
			,case when LoanType in (1023,1024,1025,1026,1028) then 1 else 0 end Staticpool_Real_Estate_loan_flag
			 into #Real_Estate
			from
			(
			select [ProcessDate],left(ProcessDate,6) ProcessDate_V,Process_Date,Open_date,Close_date
			,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
			,d.SSN
			,[PARENTACCOUNT]
			,[ID]
			,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
			,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
			,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
			,[TYPE]
,[LASTFMDATE]
,[LASTTRANDATE]
,[ORIGINALDATE]
,a.[OPENDATE]
,[CHARGEOFFDATE]
,a.[CLOSEDATE]
,[LOANCODE]
,[APPROVALCODE]
,[APPROVALDATE]
,[PURPOSECODE]
,[PAYMENTFREQUENCY]
,[PARTIALPAYMENT]
,[PAYMENT]
,[PAYMENTCOUNT]
,[PAYMENTHISTORY1]
,[PAYMENTHISTORY2]
,[PAYMENTHISTORY3]
,[PAYMENTHISTORY4]
,[PAYMENTHISTORY5]
,[PAYMENTHISTORY6]
,[DUEDAY1]

,[INTERESTRATE]
,[BALANCE]
,[ORIGINALBALANCE]
,[CREDITLIMIT]
,[CHARGEOFFAMOUNT]
,[DESCRIPTION]
,[NSFMONTHTODATE]
,[MATURITYDATE]

,[RISKRATE]
,[APR]
,[CREDITSCORE]
,[ADVANCEAMOUNT],CRPMTCURRENT

			,b.LoanType
			,b.LoanCategory1
			,b.LoanTypeDescription
		from (select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
		,cast(OPENDATE as date) Open_date,cast(CLOSEDATE as date) Close_date,cast(MATURITYDATE as date) as MATURITY_DATE from ARCUSYM000..LOAN) a
			left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
		on b.loantype=a.TYPE
		left join  #Static_SSN_account d
		on a.PARENTACCOUNT=d.AccountNumber
		
			where  ORIGINALDATE is not null and a.OpenDate is not null and a.Open_date < @staticpooldate and
		(a.CLOSEDATE is null or a.Close_date>@staticpooldate)   
			and  Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate))
		and  PARENTACCOUNT in (select AccountNumber from #Static_SSN_account )
		) AA
		where  LoanType in (1023,1024,1025,1026,1028)  and OPEN_DATE<@staticpooldate 
		and (Close_date is null or Close_date>@staticpooldate) and ORIGINALDATE>= Open_date and Quarters is not null

			
			
			---///*** Real Estate 2st Mortgage ***\\\---
			 -- drop table if exists #Real_Estate2

				

			select 
			*
			,case when LoanType in (100,101,102,150,151,152,501,1020,1030) and Quarters='Staticpool' then 1 else 0 end Staticpool_Real_Estate2_loan_flag
			 into #Real_Estate2
			from
			(
			select [ProcessDate],left(ProcessDate,6) ProcessDate_V,Process_Date,Open_date,Close_date
			,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
			,d.SSN
			,[PARENTACCOUNT]
			,[ID]
			,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
			,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
			,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
			,[TYPE]
,[LASTFMDATE]
,[LASTTRANDATE]
,[ORIGINALDATE]
,a.[OPENDATE]
,[CHARGEOFFDATE]
,a.[CLOSEDATE]
,[LOANCODE]
,[APPROVALCODE]
,[APPROVALDATE]
,[PURPOSECODE]
,[PAYMENTFREQUENCY]
,[PARTIALPAYMENT]
,[PAYMENT]
,[PAYMENTCOUNT]
,[PAYMENTHISTORY1]
,[PAYMENTHISTORY2]
,[PAYMENTHISTORY3]
,[PAYMENTHISTORY4]
,[PAYMENTHISTORY5]
,[PAYMENTHISTORY6]
,[DUEDAY1]

,[INTERESTRATE]
,[BALANCE]
,[ORIGINALBALANCE]
,[CREDITLIMIT]
,[CHARGEOFFAMOUNT]
,[DESCRIPTION]
,[NSFMONTHTODATE]
,[MATURITYDATE]

,[RISKRATE]
,[APR]
,[CREDITSCORE]
,[ADVANCEAMOUNT],CRPMTCURRENT

			,b.LoanCategory1
			,b.LoanCategory2
			,b.LoanTypeDescription
			,b.LoanType
		from (select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
		,cast(OPENDATE as date) Open_date,cast(CLOSEDATE as date) Close_date,cast(MATURITYDATE as date) as MATURITY_DATE from ARCUSYM000..LOAN) a
			left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
		on b.loantype=a.TYPE
		left join  #Static_SSN_account d
		on a.PARENTACCOUNT=d.AccountNumber
		
			where  ORIGINALDATE is not null and a.OpenDate is not null and a.Open_date < @staticpooldate and
		(a.CLOSEDATE is null or a.Close_date>@staticpooldate)   
			and  Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate))
		and  PARENTACCOUNT in (select AccountNumber from #Static_SSN_account )
		) AA
		where  LoanType in (100,101,102,150,151,152,501,1020,1030)  and OPEN_DATE<@staticpooldate 
		and (Close_date is null or Close_date>@staticpooldate) and ORIGINALDATE>= Open_date and Quarters is not null

		

			-----------------------------------
			----------------------------------
			-----///*** Secured ***\\\---
			--  drop table if exists #Secured
			
				
				--Unsecured
				--Vehicles
				--Wealth Management
				--Work Out
			

			select 
			*
			 into #Secured
			from
			(
			select [ProcessDate],left(ProcessDate,6) ProcessDate_V,Process_Date,Open_date,Close_date
			,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
			,case when Process_Date=@staticpooldate then 1 else 0 end Staticpool_Secured_loan_flag
			,d.SSN
			,[PARENTACCOUNT]
			,[ID]
			,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
			,case when len(month(a.closedate))=1 then CONCAT(year(a.closedate),0,month(a.closedate))
			else CONCAT(year(a.closedate),month(a.closedate)) end  Closed_date_INT
			,case when len(month(a.opendate))=1 then CONCAT(year(a.opendate),0,month(a.opendate))
			else CONCAT(year(a.opendate),month(a.opendate)) end  OPEN_date_INT_INT
			,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
			,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
			,[TYPE]
,[LASTFMDATE]
,[LASTTRANDATE]
,[ORIGINALDATE]
,a.[OPENDATE]
,[CHARGEOFFDATE]
,a.[CLOSEDATE]
,[LOANCODE]
,[APPROVALCODE]
,[APPROVALDATE]
,[PURPOSECODE]
,[PAYMENTFREQUENCY]
,[PARTIALPAYMENT]
,[PAYMENT]
,[PAYMENTCOUNT]
,[PAYMENTHISTORY1]
,[PAYMENTHISTORY2]
,[PAYMENTHISTORY3]
,[PAYMENTHISTORY4]
,[PAYMENTHISTORY5]
,[PAYMENTHISTORY6]
,[DUEDAY1]
,[DUEDAY2]
,[INTERESTRATE]
,[BALANCE]
,[ORIGINALBALANCE]
,[CREDITLIMIT]
,[CHARGEOFFAMOUNT]
,[DESCRIPTION]
,[NSFMONTHTODATE]
,[MATURITYDATE]

,[APR]
,[CREDITSCORE]
,[ADVANCEAMOUNT],CRPMTCURRENT
			,b.LoanCategory1
			,b.LoanTypeDescription
			from (select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
			,cast(OPENDATE as date) Open_date,cast(CLOSEDATE as date) Close_date,cast(MATURITYDATE as date) as MATURITY_DATE from ARCUSYM000..LOAN) a
			left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
		on b.loantype=a.TYPE
		left join  #Static_SSN_account d
		on a.PARENTACCOUNT=d.AccountNumber
		
			where  ORIGINALDATE is not null and a.OpenDate is not null and a.Open_date < @staticpooldate and
		(a.CLOSEDATE is null or a.Close_date>@staticpooldate)   
			and  Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate))
		and  PARENTACCOUNT in (select AccountNumber from #Static_SSN_account )
		) AA
		where  LoanCategory1='Secured'  and OPEN_DATE<@staticpooldate 
		and (Close_date is null or Close_date>@staticpooldate) and ORIGINALDATE>= Open_date and Quarters is not null

			
			



				-----------------------------------
			----------------------------------
			-----///*** Unsecured ***\\\---
			--  drop table if exists #Secured
			
				
				
				--Vehicles
				--Wealth Management
				--Work Out
			

			select 
			*
			 into #Unsecured
			from
			(
			select [ProcessDate],left(ProcessDate,6) ProcessDate_V,Process_Date,Open_date,Close_date
			,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
			,case when Process_Date =@staticpooldate then 1 else 0 end Staticpool_Unsecured_loan_flag
			,d.SSN
			,[PARENTACCOUNT]
			,[ID]
			,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
			,case when len(month(a.closedate))=1 then CONCAT(year(a.closedate),0,month(a.closedate))
			else CONCAT(year(a.closedate),month(a.closedate)) end  Closed_date_INT
			,case when len(month(a.opendate))=1 then CONCAT(year(a.opendate),0,month(a.opendate))
			else CONCAT(year(a.opendate),month(a.opendate)) end  OPEN_date_INT_INT
			,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
			,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
			,[TYPE]
,[LASTFMDATE]
,[LASTTRANDATE]
,[ORIGINALDATE]
,a.[OPENDATE]
,[CHARGEOFFDATE]
,a.[CLOSEDATE]
,[LOANCODE]
,[APPROVALCODE]
,[APPROVALDATE]
,[PURPOSECODE]
,[PAYMENTFREQUENCY]
,[PARTIALPAYMENT]
,[PAYMENT]
,[PAYMENTCOUNT]
,[PAYMENTHISTORY1]
,[PAYMENTHISTORY2]
,[PAYMENTHISTORY3]
,[PAYMENTHISTORY4]
,[PAYMENTHISTORY5]
,[PAYMENTHISTORY6]
,[DUEDAY1]
,[DUEDAY2]
,[INTERESTRATE]
,[BALANCE]
,[ORIGINALBALANCE]
,[CREDITLIMIT]
,[CHARGEOFFAMOUNT]
,[DESCRIPTION]
,[NSFMONTHTODATE]
,[MATURITYDATE]

,[APR]
,[CREDITSCORE]
,[ADVANCEAMOUNT],CRPMTCURRENT

			,b.LoanCategory1
			,b.LoanTypeDescription
			from (select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
			,cast(OPENDATE as date) Open_date,cast(CLOSEDATE as date) Close_date,cast(MATURITYDATE as date) as MATURITY_DATE from ARCUSYM000..LOAN) a
			left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
		on b.loantype=a.TYPE
		left join  #Static_SSN_account d
		on a.PARENTACCOUNT=d.AccountNumber
		
			where  ORIGINALDATE is not null and a.OpenDate is not null and a.Open_date < @staticpooldate and
		(a.CLOSEDATE is null or a.Close_date>@staticpooldate)   
			and  Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate))
		and  PARENTACCOUNT in (select AccountNumber from #Static_SSN_account )
		) AA
		where  LoanCategory1='Unsecured'  and OPEN_DATE<@staticpooldate 
		and (Close_date is null or Close_date>@staticpooldate) and ORIGINALDATE>= Open_date
		and Quarters is not null
			

			


			
				-----------------------------------
			----------------------------------
			-----///*** Vehicles ***\\\---
			--  drop table if exists #Vehicles
			
				
				
				--
				--Wealth Management
				--Work Out
			
			

			select 
			*
			 into #Vehicles
			from
			(
			select [ProcessDate],left(ProcessDate,6) ProcessDate_V,Process_Date,Open_date,Close_date
			,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
			,case when Process_Date =@staticpooldate then 1 else 0 end Staticpool_Vehicles_loan_flag
			,d.SSN
			,[PARENTACCOUNT]
			,[ID]
			,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
			,case when len(month(a.closedate))=1 then CONCAT(year(a.closedate),0,month(a.closedate))
			else CONCAT(year(a.closedate),month(a.closedate)) end  Closed_date_INT
			,case when len(month(a.opendate))=1 then CONCAT(year(a.opendate),0,month(a.opendate))
			else CONCAT(year(a.opendate),month(a.opendate)) end  OPEN_date_INT_INT
			,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
			,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
			,[TYPE]
,[LASTFMDATE]
,[LASTTRANDATE]
,[ORIGINALDATE]
,a.[OPENDATE]
,[CHARGEOFFDATE]
,a.[CLOSEDATE]
,[LOANCODE]
,[APPROVALCODE]
,[APPROVALDATE]
,[PURPOSECODE]
,[PAYMENTFREQUENCY]
,[PARTIALPAYMENT]
,[PAYMENT]
,[PAYMENTCOUNT]
,[PAYMENTHISTORY1]
,[PAYMENTHISTORY2]
,[PAYMENTHISTORY3]
,[PAYMENTHISTORY4]
,[PAYMENTHISTORY5]
,[PAYMENTHISTORY6]
,[DUEDAY1]
,[DUEDAY2]
,[INTERESTRATE]
,[BALANCE]
,[ORIGINALBALANCE]
,[CREDITLIMIT]
,[CHARGEOFFAMOUNT]
,[DESCRIPTION]
,[NSFMONTHTODATE]
,[MATURITYDATE]

,[APR]
,[CREDITSCORE]
,[ADVANCEAMOUNT],CRPMTCURRENT


			,b.LoanCategory1
			,b.LoanTypeDescription
			from (select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
			,cast(OPENDATE as date) Open_date,cast(CLOSEDATE as date) Close_date,cast(MATURITYDATE as date) as MATURITY_DATE from ARCUSYM000..LOAN) a
			left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
		on b.loantype=a.TYPE
		left join  #Static_SSN_account d
		on a.PARENTACCOUNT=d.AccountNumber
		
			where  ORIGINALDATE is not null and a.OpenDate is not null and a.Open_date < @staticpooldate and
		(a.CLOSEDATE is null or a.Close_date>@staticpooldate)   
			and  Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate))
		and  PARENTACCOUNT in (select AccountNumber from #Static_SSN_account )
		) AA
		where  LoanCategory1='Vehicles'  and OPEN_DATE<@staticpooldate 
		and (Close_date is null or Close_date>@staticpooldate) and ORIGINALDATE>= Open_date
		and Quarters is not null

				
				

				-----------------------------------
			----------------------------------
			-----///*** Wealth Management ***\\\---
			--  drop table if exists #Wealth_Management
			
				
				
			
			
--			select 
--			*
--			 into #Wealth_Management
--			from
--			(
--			select [ProcessDate],left(ProcessDate,6) ProcessDate_V,Process_Date,Open_date,Close_date
--			,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
--		    when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
--		    when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
--		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
--		    when Process_Date in (@staticpooldate) then 'Staticpool'
--		    end Quarters
--			,d.SSN
--			,[PARENTACCOUNT]
--			,[ID]
--			,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
--			,case when len(month(a.closedate))=1 then CONCAT(year(a.closedate),0,month(a.closedate))
--			else CONCAT(year(a.closedate),month(a.closedate)) end  Closed_date_INT
--			,case when len(month(a.opendate))=1 then CONCAT(year(a.opendate),0,month(a.opendate))
--			else CONCAT(year(a.opendate),month(a.opendate)) end  OPEN_date_INT_INT
--			,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
--			,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
--			,[TYPE]
--,[LASTFMDATE]
--,[LASTTRANDATE]
--,[ORIGINALDATE]
--,a.[OPENDATE]
--,[CHARGEOFFDATE]
--,a.[CLOSEDATE]
--,[LOANCODE]
--,[APPROVALCODE]
--,[APPROVALDATE]
--,[PURPOSECODE]
--,[PAYMENTFREQUENCY]
--,[PARTIALPAYMENT]
--,[PAYMENT]
--,[PAYMENTCOUNT]
--,[PAYMENTHISTORY1]
--,[PAYMENTHISTORY2]
--,[PAYMENTHISTORY3]
--,[PAYMENTHISTORY4]
--,[PAYMENTHISTORY5]
--,[PAYMENTHISTORY6]
--,[DUEDAY1]
--,[DUEDAY2]
--,[INTERESTRATE]
--,[BALANCE]
--,[ORIGINALBALANCE]
--,[CREDITLIMIT]
--,[CHARGEOFFAMOUNT]
--,[DESCRIPTION]
--,[NSFMONTHTODATE]
--,[MATURITYDATE]

--,[APR]
--,[CREDITSCORE]
--,[ADVANCEAMOUNT]


--			,b.LoanCategory1
--			,b.LoanTypeDescription
--			from (select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date,cast(OPENDATE as date) Open_date,cast(CLOSEDATE as date) Close_date,cast(MATURITYDATE as date) as MATURITY_DATE from ARCUSYM000..LOAN) a
--			left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
--		on b.loantype=a.TYPE
--		left join  #Static_SSN_account d
--		on a.PARENTACCOUNT=d.AccountNumber
		
--			where  ORIGINALDATE is not null and a.OpenDate is not null and a.Open_date < @staticpooldate and
--		(a.CLOSEDATE is null or a.Close_date>@staticpooldate)   
--			and  Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
--			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
--			,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
--			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate)) 
--		and  PARENTACCOUNT in (select AccountNumber from #Static_SSN_account )
--		) AA
--		where  LoanCategory1='Wealth Management'  and OPEN_DATE<(DATEADD(month,-1,@staticpooldate)) 
--		and (Close_date is null or Close_date>@staticpooldate) and ORIGINALDATE>= Open_date
--		and Quarters is not null

			
			-----------------------------------
			----------------------------------
			-----///*** Work Out ***\\\---
			--  drop table if exists #Work_Out
			
				
				
			select 
			*
			 into #Work_Out
			from
			(
			select [ProcessDate],left(ProcessDate,6) ProcessDate_V,Process_Date,Open_date,Close_date
			,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
			,case when Process_Date =@staticpooldate then 1 else 0 end Staticpool_Work_Out_loan_flag
			,d.SSN
			,[PARENTACCOUNT]
			,[ID]
			,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
			,case when len(month(a.closedate))=1 then CONCAT(year(a.closedate),0,month(a.closedate))
			else CONCAT(year(a.closedate),month(a.closedate)) end  Closed_date_INT
			,case when len(month(a.opendate))=1 then CONCAT(year(a.opendate),0,month(a.opendate))
			else CONCAT(year(a.opendate),month(a.opendate)) end  OPEN_date_INT_INT
			,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
			,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
			,[TYPE]
,[LASTFMDATE]
,[LASTTRANDATE]
,[ORIGINALDATE]
,a.[OPENDATE]
,[CHARGEOFFDATE]
,a.[CLOSEDATE]
,[LOANCODE]
,[APPROVALCODE]
,[APPROVALDATE]
,[PURPOSECODE]
,[PAYMENTFREQUENCY]
,[PARTIALPAYMENT]
,[PAYMENT]
,[PAYMENTCOUNT]
,[PAYMENTHISTORY1]
,[PAYMENTHISTORY2]
,[PAYMENTHISTORY3]
,[PAYMENTHISTORY4]
,[PAYMENTHISTORY5]
,[PAYMENTHISTORY6]
,[DUEDAY1]
,[DUEDAY2]
,[INTERESTRATE]
,[BALANCE]
,[ORIGINALBALANCE]
,[CREDITLIMIT]
,[CHARGEOFFAMOUNT]
,[DESCRIPTION]
,[NSFMONTHTODATE]
,[MATURITYDATE]

,[APR]
,[CREDITSCORE]
,[ADVANCEAMOUNT],CRPMTCURRENT

			,b.LoanCategory2
			,b.LoanCategory1
			,b.LoanTypeDescription
			from (select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
			,cast(OPENDATE as date) Open_date,cast(CLOSEDATE as date) Close_date,cast(MATURITYDATE as date) as MATURITY_DATE from ARCUSYM000..LOAN) a
			left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
		on b.loantype=a.TYPE
		left join  #Static_SSN_account d
		on a.PARENTACCOUNT=d.AccountNumber
		
			where  ORIGINALDATE is not null and a.OpenDate is not null and a.Open_date < @staticpooldate and
		(a.CLOSEDATE is null or a.Close_date>@staticpooldate)   
			and  Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate))
		and  PARENTACCOUNT in (select AccountNumber from #Static_SSN_account )
		) AA
		where  LoanCategory1='Work Out'and LoanCategory2!='Unsecured' and OPEN_DATE<@staticpooldate 
		and (Close_date is null or Close_date>@staticpooldate) and ORIGINALDATE>= Open_date
		and Quarters is not null

		
			
			----
			----/////*** Loan Transaction data

		

			-- DROP TABLE IF EXISTS #LOAN_TRANSACITON_DATA
			

			select 
			UNID
			,PARENTACCOUNT
			,Quarters
			,action_source_code
			,sum(Loan_addon) Sum_count_loan_addon
			,sum(New_loan) Sum_count_New_loan
			,sum(loan_payment) Sum_count_loan_payment
			,sum(CASH) Sum_count_CASH
			,sum(DRAFT) Sum_count_DRAFT
			,sum(ACH) Sum_count_ACH
			,sum(FEE) Sum_count_FEE
			,sum(HOMEBANKING) Sum_count_HOMEBANKING
			,sum(INSURANCE) Sum_count_INSURANCE
			,sum(CHECKS) Sum_count_CHECKS
			,sum(PAYROLL) Sum_count_PAYROLL
			,sum(KIOSK) Sum_count_KIOSK
			,sum(AUDIO_RESPONSE_TELEPHONE) Sum_count_AUDIO_RESPONSE_TELEPHONE
			,avg(Transaction_amount) Avg_Transaction_amount
			,avg(NEWBALANCE) Avg_NEWBALANCE
			,avg(Interest_amount) avg_Interest_amount
			,avg(FEEAMOUNT) avg_FEEAMOUNT
			,sum(Transaction_amount) sum_Transaction_amount
			,sum(Interest_amount) sum_Interest_amount
			,sum(FEEAMOUNT) Sum_FEEAMOUNT
			 INTO #LOAN_TRANSACITON_DATA
			from 
			(
			select unid,PARENTACCOUNT
			,case when EFFECTIVEDATE_v1 in ((left(convert(varchar,dateadd(month,-10,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-11,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6))) then 'Q4'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,dateadd(month,-7,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-8,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-9,@staticpooldate),112),6))) then 'Q3'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,dateadd(month,-4,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-5,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-6,@staticpooldate),112),6))) then 'Q2'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,dateadd(month,-3,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-2,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-1,@staticpooldate),112),6))) then 'Q1'
		    when EFFECTIVEDATE_v1 in (left(convert(varchar,@staticpooldate,112),6)) then 'Staticpool' end Quarters
			,EFFECTIVEDATE_v1
			,ACTIONCODE,SOURCECODE
			,case when ACTIONCODE='A' then 1 else 0 end Loan_addon
			,case when ACTIONCODE='N' then 1 else 0 end New_loan
			,case when ACTIONCODE='N' then 1 else 0 end loan_payment
			,case when SOURCECODE='C' then 1 else 0 end CASH
			,case when SOURCECODE='D' then 1 else 0 end DRAFT
			,case when SOURCECODE='E' then 1 else 0 end ACH
			,case when SOURCECODE='F' then 1 else 0 end FEE
			,case when SOURCECODE='H' then 1 else 0 end HOMEBANKING
			,case when SOURCECODE='I' then 1 else 0 end INSURANCE
			,case when SOURCECODE='K' then 1 else 0 end CHECKS
			,case when SOURCECODE='P' then 1 else 0 end PAYROLL
			,case when SOURCECODE='S' then 1 else 0 end KIOSK
			,case when SOURCECODE='T' then 1 else 0 end  AUDIO_RESPONSE_TELEPHONE
			,CASE WHEN ACTIONCODE='A' AND SOURCECODE='C' THEN 'LOANADDON_CASH'
			WHEN ACTIONCODE='A' AND SOURCECODE='F' THEN 'LOANADDON_FEE'
			WHEN ACTIONCODE='A' AND SOURCECODE='H' THEN 'LOANADDON_HOMEBANKING'
			WHEN ACTIONCODE='A' AND SOURCECODE='I' THEN 'LOANADDON_INSURANCE'
			WHEN ACTIONCODE='A' AND SOURCECODE='K' THEN 'LOANADDON_CHECK'
			WHEN ACTIONCODE='A' AND SOURCECODE='T' THEN 'LOANADDON_RESPONSE_TELEPHONE'
			WHEN ACTIONCODE='A' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'LOANADDON'
			WHEN ACTIONCODE='N' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'NEWLOAN'
			WHEN ACTIONCODE='N' AND SOURCECODE='K' THEN 'NEWLOAN_CHECKS'
			WHEN ACTIONCODE='N' AND SOURCECODE='S' THEN 'NEWLOAN_KIOSK'
			WHEN ACTIONCODE='P' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'LOANPAYMENT'
			
			WHEN ACTIONCODE='P' AND SOURCECODE='C' THEN 'LOANPAYMENT_CASH'
			WHEN ACTIONCODE='P' AND SOURCECODE='D' THEN 'LOANPAYMENT_DRAFT'
			WHEN ACTIONCODE='P' AND SOURCECODE='E' THEN 'LOANPAYMENT_ACH'
			WHEN ACTIONCODE='P' AND SOURCECODE='H' THEN 'LOANPAYMENT_HOMEBANKING'
			WHEN ACTIONCODE='P' AND SOURCECODE='K' THEN 'LOANPAYMENT_CHECKS'
			WHEN ACTIONCODE='P' AND SOURCECODE='P' THEN 'LOANPAYMENT_PAYROLL'
			WHEN ACTIONCODE='P' AND SOURCECODE='S' THEN 'LOANPAYMENT_KIOSK'
			WHEN ACTIONCODE='P' AND SOURCECODE='T' THEN  'LOANPAYMENT_RESPONSE_TELEPHONE' end action_source_code
			,BALANCECHANGE Transaction_amount,NEWBALANCE
			,INTEREST Interest_amount, FEEAMOUNT
			from	(

					select CONCAT(PARENTACCOUNT,PARENTID) UNID
					,PARENTACCOUNT,PARENTID
					,TRANSFERCODE
					,case when len(month(effectivedate))=1 then CONCAT(year(effectivedate),0,month(effectivedate))
					else CONCAT(year(effectivedate),month(effectivedate)) end EFFECTIVEDATE_v1
					,cast(EFFECTIVEDATE as date) EFFECTIVEDATE ,POSTDATE
					,ACTIONCODE,SOURCECODE,BALANCECHANGE,NEWBALANCE,INTEREST,FEEAMOUNT
					from [ARCUSYM000]..LOANTRANSACTION
					where
					ACTIONCODE in ('A','N','P') AND SOURCECODE in ('C','D','E','F','H','I','K','P','S','T')
					 and ACTIONCODE !='C' ) AA
			 )bb
			 where Quarters is not null 
			 and EFFECTIVEDATE_v1 between (Cast((left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6)) as int)) 
			 and cast((left(convert(varchar,@staticpooldate,112),6)) as int)
			 group by UNID,Quarters,action_source_code,PARENTACCOUNT
					
			-- drop table if exists #loan_transaction_data_0
			SELECT 
			*
			Into #loan_transaction_data_0
			FROM 
			(
			SELECT 
			rtrim(ltrim(UNID)) UNID,PARENTACCOUNT
			,SUM(Sum_count_loan_addon) Sum_count_loan_addon
			,SUM(Sum_count_New_loan) Sum_count_New_loan
			,SUM(Sum_count_loan_payment) Sum_count_loan_payment
			,SUM(Sum_count_CASH) Sum_count_CASH
			,SUM(Sum_count_DRAFT) Sum_count_DRAFT
			,SUM(Sum_count_ACH) Sum_count_ACH
			,SUM(Sum_count_FEE) Sum_count_FEE
			,SUM(Sum_count_HOMEBANKING) Sum_count_HOMEBANKING
			,SUM(Sum_count_INSURANCE) Sum_count_INSURANCE
			,SUM(Sum_count_CHECKS) Sum_count_CHECKS
			,SUM(Sum_count_PAYROLL) Sum_count_PAYROLL
			,SUM(Sum_count_KIOSK) Sum_count_KIOSK
			,SUM(Sum_count_AUDIO_RESPONSE_TELEPHONE) Sum_count_AUDIO_RESPONSE_TELEPHONE
			,SUM(SUM_INTEREST_AMOUNT) SUM_INTEREST_AMOUNT
			,SUM(SUM_FEEAMOUNT) SUM_FEEAMOUNT
			 FROM #LOAN_TRANSACITON_DATA
			GROUP BY UNID,PARENTACCOUNT
			) A
			LEFT JOIN 
			(
			select 
			rtrim(ltrim(UNID)) UNID1
			,SUM(case when Quarters='Q1' THEN Avg_Transaction_amount END ) 'Avg_Transaction_amount_Q1'
			,SUM(case when Quarters='Q1' THEN Avg_NEWBALANCE END ) 'Avg_NEWBALANCE_Q1'
			,SUM(case when Quarters='Q1' THEN avg_Interest_amount END ) 'avg_Interest_amount_Q1'
			,SUM(case when Quarters='Q1' THEN avg_FEEAMOUNT END ) 'avg_FEEAMOUNT_Q1'
			,SUM(case when Quarters='Q1' THEN sum_Transaction_amount END ) 'sum_Transaction_amount_Q1'
			,SUM(case when Quarters='Q2' THEN Avg_Transaction_amount END ) 'Avg_Transaction_amount_Q2'
			,SUM(case when Quarters='Q2' THEN Avg_NEWBALANCE END ) 'Avg_NEWBALANCE_Q2'
			,SUM(case when Quarters='Q2' THEN avg_Interest_amount END ) 'avg_Interest_amount_Q2'
			,SUM(case when Quarters='Q2' THEN avg_FEEAMOUNT END ) 'avg_FEEAMOUNT_Q2'
			,SUM(case when Quarters='Q2' THEN sum_Transaction_amount END ) 'sum_Transaction_amount_Q2'
			,SUM(case when Quarters='Q3' THEN Avg_Transaction_amount END ) 'Avg_Transaction_amount_Q3'
			,SUM(case when Quarters='Q3' THEN Avg_NEWBALANCE END ) 'Avg_NEWBALANCE_Q3'
			,SUM(case when Quarters='Q3' THEN avg_Interest_amount END ) 'avg_Interest_amount_Q3'
			,SUM(case when Quarters='Q3' THEN avg_FEEAMOUNT END ) 'avg_FEEAMOUNT_Q3'
			,SUM(case when Quarters='Q3' THEN sum_Transaction_amount END ) 'sum_Transaction_amount_Q3'
			,SUM(case when Quarters='Q4' THEN Avg_Transaction_amount END ) 'Avg_Transaction_amount_Q4'
			,SUM(case when Quarters='Q4' THEN Avg_NEWBALANCE END ) 'Avg_NEWBALANCE_Q4'
			,SUM(case when Quarters='Q4' THEN avg_Interest_amount END ) 'avg_Interest_amount_Q4'
			,SUM(case when Quarters='Q4' THEN avg_FEEAMOUNT END ) 'avg_FEEAMOUNT_Q4'
			,SUM(case when Quarters='Q4' THEN sum_Transaction_amount END ) 'sum_Transaction_amount_Q4'
			from #LOAN_TRANSACITON_DATA
			GROUP BY UNID ) B
			ON A.UNID=B.UNID1
					
			--------------------------------------------------------------------------------------------------------------------------------------
 ---------------------------------------------------------------------------------------------------------------------------------
			
		-----------------------------////////********* Savings table *********************\\\\\\-----------------------------------------------------
		--  Group by product type
		-- drop table if exists #groupproducttype_Deposits
		select *
		,case when ProductName like '%money%'  or ProductName like '% MM %' then 'MoneyMarket'
		when ProductName='Youth Savings' and ApplicationDescription='Certificates' then 'Savings'
		when ProductCode=0 and ApplicationDescription='Certificates' then 'Savings'
		when ProductName='40 Month CD' and ApplicationDescription='Certificates' then 'Checking'
		when ProductName='Certificate' and ApplicationDescription='Certificates' then 'Checking' 
		when ProductName='Public Funds' and ApplicationDescription='Certificates' then 'Certificates'  
		 else ApplicationDescription end Product_Group_wise
		into #groupproducttype_Deposits
		from
		(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName
		,ApplicationDescription,ApplicationTableName
		 from [AE_EDW].[tempods].[S_CRMProductType] a
		left join [AE_EDW].[tempods].[S_CRMApplicationType] b
		on a.ApplicationTypeID=b.ApplicationTypeID
		where ApplicationDescription is not null
		and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a
		------------------------------------------------------------------
		--------------------------/////***** targeted variable for Credit Card
		-- check query
		-- drop table if exists #CC_Target_Flag
		select distinct [Social Security Number] CC_SSN ,max(Extract_ACCOUNT_OPEN_DATE) Opendate_Creditcard,1 CC_Target_flag
		into #CC_Target_Flag
		from  Analytics..cardholder 		 
		 where Extract_ACCOUNT_OPEN_DATE between left(convert(varchar,dateadd(month,1,@staticpooldate),112),6) 
		 and left(convert(varchar,dateadd(month,12,@staticpooldate),112),6)
		 group by [Social Security Number]
		 order by max(Extract_ACCOUNT_OPEN_DATE) 
		
		--------------------------/////***** targeted variable for Deposit account
		
		-- drop table if exists #desposit_Target_variable
		select * ,case when Sum_Target_Certificates>0 then 1 else 0 end Certificates_ACCT_Flag
		,case when Sum_Target_Savings>0 then 1 else 0 end Savings_ACCT_Flag
		,case when Sum_Target_Checking>0 then 1 else 0 end Checking_ACCT_Flag
		,case when Sum_Target_Money_market>0 then 1 else 0 end Money_market_ACCT_Flag
		,case when Sum_Target_Certificates>0 then Min_opendate_target_variable end Opendate_Certificates_ACCT_Flag
		,case when Sum_Target_Savings>0 then Min_opendate_target_variable end Opendate_Savings_ACCT_Flag
		,case when Sum_Target_Checking>0 then Min_opendate_target_variable end Opendate_Checking_ACCT_Flag
		,case when Sum_Target_Money_market>0 then Min_opendate_target_variable  end Opendate_Money_market_ACCT_Flag
		into #desposit_Target_variable
		from
		(
		select b.SSN SSN22 
		,sum(Target_Certificates_flag) Sum_Target_Certificates
		,sum(Target_Savings_Flag) Sum_Target_Savings
		,sum(Target_Checking_flag) Sum_Target_Checking
		,sum(Target_Money_market_flag) Sum_Target_Money_market
		,min(Open_date) Min_opendate_target_variable
		 from
		(select *
		,case when Product_Group_wise='Certificates' then 1 else 0 end Target_Certificates_flag
		,case when Product_Group_wise='Savings' then 1 else 0 end Target_Savings_Flag
		,case when Product_Group_wise='Checking' then 1 else 0 end Target_Checking_flag
		,case when Product_Group_wise='Money Market' then 1 else 0 end Target_Money_market_flag
		 from 
			 ( select  distinct PARENTACCOUNT,id,concat(PARENTACCOUNT,id) UNID,cast(OPENDATE as date) Open_date
			 ,Cast(CLOSEDATE as date) Close_date
			 ,case when len(month(OPENDATE))=1 then CONCAT(year(opendate),0,month(opendate)) 
			 else CONCAT(year(opendate),month(opendate)) end Opendate_V
			  ,case when len(month(CLOSEDATE))=1 then CONCAT(year(CLOSEDATE),0,month(CLOSEDATE))
			   else CONCAT(year(CLOSEDATE),month(CLOSEDATE)) end CLOSEDATE_V
			,type   from ARCUSYM000..savings) a
			 left join 
				 #groupproducttype_Deposits b
				 on a.TYPE=b.ProductCode
				 where Open_date>@staticpooldate and Open_date <=dateadd(month,12,@staticpooldate)
				 and OPENDATE_V!= CLOSEDATE_V
				  ) aa
				  left join #Static_SSN_account b
				  on aa.PARENTACCOUNT=b.AccountNumber
				 where SSN is not null
				  group by b.SSN ) A
		 -------------------------- loan product target variable 
		  -- drop table if exists #Loan_target_variable
				

		select *
		,case when sum_Target_Commercial>0 then 1 else 0 end Commercial_ACCT_Flag
		,case when sum_Target_Fresh_Start>0 then 1 else 0 end Fresh_Start_ACCT_Flag
		,case when sum_Target_Real_estate>0 then 1 else 0 end Real_estate_ACCT_Flag
		,case when sum_Target_Real_estate2>0 then 1 else 0 end Real_estate2_ACCT_Flag
		,case when sum_Target_secured>0 then 1 else 0 end secured_ACCT_Flag
		,case when sum_Target_Unsecured>0 then 1 else 0 end Unsecured_ACCT_Flag
		,case when sum_Target_Vehicles>0 then 1 else 0 end Vehicles_ACCT_Flag
		,case when sum_Target_Wealth_Management>0 then 1 else 0 end Wealth_Management_ACCT_Flag
		,case when sum_Target_Work_Out>0 then 1 else 0 end Work_Out_ACCT_Flag
		,case when sum_Target_Commercial>0 then Min_opendate_target_variable end Opendate_Commercial_ACCT_Flag
		,case when sum_Target_Fresh_Start>0 then Min_opendate_target_variable end Opendate_Fresh_Start_ACCT_Flag
		,case when sum_Target_Real_estate>0 then Min_opendate_target_variable end Opendate_Real_estate_ACCT_Flag
		,case when sum_Target_Real_estate2>0 then Min_opendate_target_variable end Opendate_Real_estate2_ACCT_Flag
		,case when sum_Target_secured>0 then Min_opendate_target_variable end Opendate_secured_ACCT_Flag
		,case when sum_Target_Unsecured>0 then Min_opendate_target_variable end Opendate_Unsecured_ACCT_Flag
		,case when sum_Target_Vehicles>0 then Min_opendate_target_variable end Opendate_Vehicles_ACCT_Flag
		,case when sum_Target_Wealth_Management>0 then Min_opendate_target_variable end Opendate_Wealth_Management_ACCT_Flag
		,case when sum_Target_Work_Out>0 then Min_opendate_target_variable end Opendate_Work_Out_ACCT_Flag
		into #Loan_target_variable
		from
		(select SSN ssn21
		,sum(Target_Commercial) sum_Target_Commercial
		,sum(Target_Fresh_Start) sum_Target_Fresh_Start
		,sum(Target_Real_estate) sum_Target_Real_estate
		,sum(Target_Real_estate2) sum_Target_Real_estate2
		,sum(Target_secured) sum_Target_secured
		,sum(Target_Unsecured) sum_Target_Unsecured
		,sum(Target_Vehicles) sum_Target_Vehicles
		,sum(Target_Wealth_Management) sum_Target_Wealth_Management
		,sum(Target_Work_Out) sum_Target_Work_Out
		,min(Min_opendate_target_variable) Min_opendate_target_variable	
			
		from
		(select distinct  AAA.parentaccount,C.ssn SSN
		,Target_Commercial
		,Target_Fresh_Start
		,Target_Real_estate
		,Target_Real_estate2
		,Target_secured
		,Target_Unsecured
		,Target_Vehicles
		,Target_Wealth_Management
		,Target_Work_Out
		,Min_opendate_target_variable
		from
		(select distinct  a.parentaccount
		,sum(Target_Commercial) Target_Commercial
		,sum(Target_Fresh_Start) Target_Fresh_Start
		,sum(Target_Real_estate) Target_Real_estate
		,sum(Target_Real_estate2) Target_Real_estate2
		,sum(Target_secured) Target_secured
		,sum(Target_Unsecured) Target_Unsecured
		,sum(Target_Vehicles) Target_Vehicles
		,sum(Target_Wealth_Management) Target_Wealth_Management
		,sum(Target_Work_Out) Target_Work_Out
		,MIn(opendate) Min_opendate_target_variable
		 from
		(select distinct  parentaccount,id,b.loancategory1
		,opendate
		,case when len(month(opendate))=1 then CONCAT(year(opendate),0,month(opendate)) 
		else CONCAT(year(opendate),month(opendate)) end Opendate_V
		,case when len(month(closedate))=1 then CONCAT(year(closedate),0,month(closedate)) 
		else CONCAT(year(closedate),month(closedate)) end closedate_V
		,closedate,originaldate
		,case when LoanCategory2='1st Mortgage' then 1 else 0 end Target_Real_estate
		,case when LoanCategory2='2nd Mortgage' then 1 else 0 end Target_Real_estate2
		,case when LoanCategory1='Vehicles' then 1 else 0 end Target_Vehicles
		,case when LoanCategory1='Unsecured' then 1 else 0 end Target_Unsecured
		,case when LoanCategory1='secured' then 1 else 0 end Target_secured
		,case when LoanCategory1='Commercial' then 1 else 0 end Target_Commercial
		,case when LoanCategory1='Fresh Start' then 1 else 0 end Target_Fresh_Start
		,case when LoanCategory1='Wealth Management' then 1 else 0 end Target_Wealth_Management
		,case when LoanCategory1='Work Out' then 1 else 0 end Target_Work_Out
		 from (select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
		 ,cast(OPENDATE as date) Open_date,cast(CLOSEDATE as date) Close_date
		 ,cast(MATURITYDATE as date) as MATURITY_DATE from ARCUSYM000..LOAN) a
		left join  [ARCUSYM000].[arcu].[ARCULoanCategory] b
		on b.loantype=a.TYPE 
		where Open_date > @staticpooldate  and Open_date <= dateadd(month,12,@staticpooldate) and originaldate is not null
		and a.ORIGINALDATE>= a.OPENDATE
		and (Open_date!=close_date)
		) A
		group by a.parentaccount ) AAA
		left join #Static_SSN_account C
		on AAA.PARENTACCOUNT=c.AccountNumber ) BB
		group by ssn ) A


		--  drop table if exists #savings_account

		
				-- closed_flag will remove the account closed account in any time 
		
		select ssn,UNID,ProcessDate,PARENTACCOUNT,id,TYPE,LASTDIVAMOUNT,BALANCE Month_end_balance
		,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE,Closed_flag,left(ProcessDate,6) ProcessDate_v
		,close_date,open_date,process_date ,Quarters,MOB,StaticPool_Saving_flag
		into #savings_account 
		from 
		(
		select  
		d.SSN
		,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		 when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		  when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		   when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		   when Process_Date in (@staticpooldate) then 'Staticpool'
		  end Quarters
		   ,DATEDIFF(MONTH,OPEN_DATE,@staticpooldate) MOB
		   ,case when Product_Group_wise='saving' and Process_Date =@staticpooldate then 1 else 0 end StaticPool_Saving_flag
		,aa.*,c.Closed_flag
		,case when aa.close_date is null then '' 
		when len(month(aa.close_date))=1 then CONCAT(year(aa.close_date),0,month(aa.close_date))
		else CONCAT(year(aa.close_date),month(aa.close_date)) end  Closed_date_INT
		,case when len(month(aa.open_date))=1 then CONCAT(year(aa.open_date),0,month(aa.open_date))
		else CONCAT(year(aa.open_date),month(aa.open_date)) end  OPEN_date_INT_INT
		,E.ProductName,E.Product_Group_wise	
		,case when Product_Group_wise='Certificates' and BALANCE=0 then 0 else 1 end carryforward_flag
		from 
					(select * from
							(	select *,case when [EOM_Process Date]=[Process Date] then 1 else 0 end EOM_flag 
										,case when (closedate is null and CHARGEOFFDATE is null) or ProcessDate_v=Close_date_v 
										or ProcessDate_v=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
										,case when OPEN_DATE=CLOSE_DATE then 0 else 1 end Funded_loan_flag
										,lag(Open_date,1) over (partition by Concat(parentaccount,id) order by processdate) Lag_opendate
											,lag(type,1) over (partition by Concat(parentaccount,id) order by processdate) Lag_Type
											,concat(PARENTACCOUNT,ID) UNID
										from
											(select a.*,EOMONTH([Process Date]) [EOM_Process Date]
											,case when ProcessDate_v=CHARGEOFFDATE_v then CHARGEOFFAMOUNT else 0 end CHARGEOFFAMOUNT_v
											,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
											else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date_v
											,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
											,cast(OPENDATE as date) Open_date
											,cast(CLOSEDATE as date) Close_date
											 from 
												 ( select * ,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
												 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v
												 ,left(ProcessDate,6) ProcessDate_v
												,datefromparts(left(processdate,4),right(left(processdate,6),2),right(processdate,2)) [Process Date] 
												from arcusym000..SAVINGS
												--where (chargeoffdate is null or chargeoffdate>='2020-01-01')
												) a
												 
											) F
								 ) aaa
								  where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
					 ) aa
		left join 
				(select UNID,max(closed_flag) Closed_flag
				from
						(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when CLOSEDATE is null then 0 else 1 end closed_flag
						from 
								(select distinct PARENTACCOUNT,ID,CLOSEDATE 
								from [ARCUSYM000]..SAVINGS
								 where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
								 ) a 
						 )b
				group by UNID
				) c
		on aa.UNID=c.UNID
		left join #Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join #groupproducttype_Deposits E
		on e.ProductCode=aa.TYPE
		where Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate))
		and PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
		) ZZ
		where Product_Group_wise='Savings'  and open_date<@staticpooldate and (close_date is null or close_date>@staticpooldate)
		and Funded_loan_flag=1 and Quarters is not null and Open_Flag=1 and carryforward_flag=1
		order by UNID,ProcessDate,TYPE




		------------------
		------------------   Transaciton data 

			
			-- drop table if exists ##Saving_transaction
		

		select PARENTACCOUNT,PARENTID,UNID
			,count(*) Transaction_COUNT
			,sum(BALANCECHANGE) Transaction_amount
			,AVG(BALANCECHANGE) AVG_BALANCECHANGE
			,sum(Deposited_amount) Deposited_amount
			,count(Deposited_amount) Deposited_count
			,sum(withdrawl_amount) withdrawal_amount
			,count(withdrawl_amount) withdrawal_count
			,EFFECTIVEDATE_v1
		into ##Saving_transaction
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      ,[COMMENTCODE]
      ,[TRANSFERCODE]
      ,[ADJUSTMENTCODE]
      ,[REGECODE]
      ,[REGDCHECKCODE]
      ,[REGDTRANSFERCODE]
      ,[VOIDCODE]
      ,[SUBACTIONCODE]
      ,[SEQUENCENUMBER]
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      ,[POSTDATE]
      ,[POSTTIME]
      ,[USERNUMBER]
      ,[USEROVERRIDE]
      ,[SECURITYLEVELS]
      ,[DESCRIPTION]
      ,[ACTIONCODE]
      ,[SOURCECODE]
      ,[BALANCECHANGE]
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	  
      ,[INTEREST]
      ,[NEWBALANCE]
      ,[FEEAMOUNT]
      ,[ESCROWAMOUNT]
      ,[LASTTRANDATE]
      ,[MATURITYLOANDUEDATE]
      ,[COMMENT]
      ,[BRANCH]
      ,[CONSOLENUMBER]
      ,[BATCHSEQUENCE]
      ,[SALESTAXAMOUNT]
      ,[ACTIVITYDATE]
      ,[BILLEDFEEAMOUNT]
      ,[PROCESSORUSER]
      ,[MEMBERBRANCH]
      ,[PREVAVAILBALANCE]
      ,[SUBSOURCE]
      ,[CONFIRMATIONSEQ]
      ,[MICRACCTNUM]
      ,[MICRRT]
      ,[RECURRINGTRAN]
      ,[FEEEXMTCRTSYAMT]
      ,[ESCROWUNPAIDBALCHG]
      ,[ESCROWAPPLIEDBALCHG]
      ,[UNAPPLIEDPARTIALPMTCHG]
      ,[FEECOUNTBY]
      ,[BALSEGCOUNT]
      ,[LATECHGWAIVEDAMT]
      ,[LATECHGUNPAIDCHGAMT]
      ,[PREVLATECHGDATE]
      ,[PREVLATECHGACCRUED]
      ,[LATECHGFIELDSVALID]
      ,[BALSEGID1]
      ,[BALSEGPMTCHANGEDATE1]
      ,[INTEFFECTDATE]
      ,[BALSEGPREVFIRSTPMTDATE1]
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
  
  FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
  WHERE PARENTACCOUNT IN (SELECT PARENTACCOUNT FROM #savings_account)
  and PARENTID in (select ID from #savings_account) 
   AND ACTIONCODE!='C') A
	where EFFECTIVEDATE_v1 between left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6) and left(convert(varchar,@staticpooldate,112),6)
      group by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1
			order by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1
	 
	 
		
		
		----******///// merging the saving and transaciton table 

		-- drop table if exists #saving_account_data
		

		select a.*
		,b.Transaction_COUNT
		,b.Transaction_amount
		,AVG_BALANCECHANGE
		,b.Deposited_amount
		,Deposited_count
		,withdrawal_amount
		,withdrawal_count
		into #Saving_account_data
		 from #savings_account a
		left join ##Saving_transaction b
		on a.UNID=b.UNID
		and ProcessDate_v=b.EFFECTIVEDATE_v1

		
		---------------------------------------------------------------------------------------------------------------------------------------------
		------------------------------////********Loan Product Summary*******************\\\\\\\\\\--------------------------------------
		-- Droptable if exists #Loan_product_summary
		

		select * 
		into #Loan_product_summary
		from
		(select 
			SSN SSN01
			,count(distinct UNID) Count_Account_Total_loan_ACCT
			,count(distinct TYPE) Total_product_Total_loan_ACCT
			,min(OPENDATE) MIn_opendate_Total_loan_ACCT
			,max(CLOSEDATE) Max_CLOSEDATE_Total_loan_ACCT
			,Max(MOB) MAX_MOB__Total_loan_ACCT
			,max(Month_to_Maturity) Max_Month_to_Maturity_Total_loan_ACCT
			,sum(PAYMENTFREQUENCY) SUM_PAYMENTFREQUENCY_Total_loan_ACCT
			,sum(PAYMENT) SUM_PAYMENT_Total_loan_ACCT
			,sum(PARTIALPAYMENT) SUM_PARTIALPAYMENT_Total_loan_ACCT
			,sum(PAYMENTCOUNT) SUM_PAYMENTCOUNT_Total_loan_ACCT
			,max(DUEDAY1) Max_DUEDAY1_Total_loan_ACCT
			,Sum(ORIGINALBALANCE) SUM_ORIGINALBALANCE_Total_loan_ACCT
			,sum(CREDITLIMIT) SUM_CreditLimit_Total_loan_ACCT
			,max(CREDITSCORE) Max_CreditScore_Total_loan_ACCT
			,min(CREDITSCORE) MIN_CREDITSCORE_Total_loan_ACCT
			,sum(ADVANCEAMOUNT) SUM_ADVANCEAMOUNT_Total_loan_ACCT
			,max(CRPMTCURRENT) Max_Delinquency
			from
			(
			select [ProcessDate],left(ProcessDate,6) ProcessDate_V,Process_Date,Open_date,Close_date
			,d.SSN
			,[PARENTACCOUNT]
			,[ID]
			,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
			,case when len(month(a.closedate))=1 then CONCAT(year(a.closedate),0,month(a.closedate))
			else CONCAT(year(a.closedate),month(a.closedate)) end  Closed_date_INT
			,case when len(month(a.opendate))=1 then CONCAT(year(a.opendate),0,month(a.opendate))
			else CONCAT(year(a.opendate),month(a.opendate)) end  OPEN_date_INT_INT
			,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
			,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
			,[TYPE]
			,[LASTFMDATE]
			,[LASTTRANDATE]
			,[ORIGINALDATE]
			,a.[OPENDATE]
			,a.[CLOSEDATE]
			,[LOANCODE]
			,[APPROVALCODE]
			,[APPROVALDATE]
			,[PAYMENTFREQUENCY]
			,[PARTIALPAYMENT]
			,[PAYMENT]
			,[PAYMENTCOUNT]
			,[DUEDAY1]
			,[INTERESTRATE]
			,[ORIGINALBALANCE]
			,[CREDITLIMIT]
			,[DESCRIPTION]
			,[NSFMONTHTODATE]
			,[MATURITYDATE]
			,[APR]
			,[CREDITSCORE]
			,[ADVANCEAMOUNT],CRPMTCURRENT
			,b.LoanCategory1
			,b.LoanTypeDescription
			from	
					(select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2)
					,right(ProcessDate,2)) Process_Date,cast(OPENDATE as date) Open_date,cast(CLOSEDATE as date) Close_date
					,cast(MATURITYDATE as date) as MATURITY_DATE from ARCUSYM000..LOAN) a
			left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
		on b.loantype=a.TYPE
		left join  #Static_SSN_account d
		on a.PARENTACCOUNT=d.AccountNumber
		
			where  ORIGINALDATE is not null and a.OpenDate is not null and a.Open_date < @staticpooldate and
		(a.CLOSEDATE is null or a.Close_date>@staticpooldate)   
			and  Process_Date =@staticpooldate 
		and  PARENTACCOUNT in (select AccountNumber from #Static_SSN_account )
		) AA
		where  OPEN_DATE<@staticpooldate and (Close_date is null or Close_date>@staticpooldate) and ORIGINALDATE>= Open_date 
		group by SSN
		) aa

		left join 
		(select SSN000,count(UNID) COUNT_Total_loan_ACCT,
		Sum(Sum_count_loan_addon) Sum_count_loan_addon_Total_loan_ACCT
		,Sum(Sum_count_new_loan) Sum_count_new_loan_Total_loan_ACCT
		,Sum(Sum_count_loan_payment) Sum_count_loan_payment_Total_loan_ACCT
		,Sum(Sum_count_cash) Sum_count_cash_Total_loan_ACCT
		,Sum(Sum_count_draft) Sum_count_draft_Total_loan_ACCT
		,Sum(Sum_count_ACH) Sum_count_ACH_Total_loan_ACCT
		,Sum(Sum_count_FEE) Sum_count_FEE_Total_loan_ACCT
		,Sum(Sum_count_HOMEBANKING) Sum_count_HOMEBANKING_Total_loan_ACCT
		,Sum(Sum_count_INSURANCE) Sum_count_INSURANCE_Total_loan_ACCT
		,Sum(Sum_count_CHECKS) Sum_count_CHECKS_Total_loan_ACCT
		,Sum(Sum_count_KIOSK) Sum_count_KIOSK_Total_loan_ACCT
		,Sum(Sum_count_AUDIO_RESPONSE_TELEPHONE) Sum_count_AUDIO_RESPONSE_TELEPHONE_Total_loan_ACCT
		,sum(sum_Transaction_amount) sum_Transaction_amount_Total_loan_ACCT
		,sum(sum_Interest_amount) sum_Interest_amount_Total_loan_ACCT
		,sum(Sum_FEEAMOUNT) Sum_FEEAMOUNT_Total_loan_ACCT
		from
		(select a.*,b.SSN SSN000 from #LOAN_TRANSACITON_DATA a left join #Static_SSN_account b
		on a.PARENTACCOUNT=b.AccountNumber
		where Quarters='staticpool' ) FF
		group by SSN000
		 ) BB
		 on aa.SSN01=bb.SSN000

	

		----------------------------------------------------------------------------------------------------------
		------------------------//////********** Deposit table summary************\\\\\\\\---------------------
		
		

		select ssn,UNID,ProcessDate,PARENTACCOUNT,id,TYPE,OPENDATE,CLOSEDATE,LASTDIVAMOUNT,BALANCE Month_end_balance
		,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE,Closed_flag,Close_date,OPEN_DATE ,left(ProcessDate,6) ProcessDate_v 
		,Process_Date
		   ,DATEDIFF(MONTH,OPEN_DATE,@staticpooldate) MOB
		 into #Deposit_account_data 
		from 
			(
			select  
			d.SSN
			,aa.*,c.Closed_flag
		
			,case when aa.closedate is null then '' 
			when len(month(aa.closedate))=1 then CONCAT(year(aa.closedate),0,month(aa.closedate))
			else CONCAT(year(aa.closedate),month(aa.closedate)) end  Closed_date_INT
			,case when len(month(aa.opendate))=1 then CONCAT(year(aa.OPENDATE),0,month(aa.OPENDATE))
			else CONCAT(year(aa.OPENDATE),month(aa.OPENDATE)) end  OPEN_date_INT_INT
			,case when aa.OPENDATE=aa.CLOSEDATE then 0 else 1 end Funded_loan_flag
			,E.ProductName,E.Product_Group_wise	
			from 
				(select 
				CONCAT(PARENTACCOUNT,id) UNID
				,ProcessDate,PARENTACCOUNT,ID,TYPE,OPENDATE,CLOSEDATE
				,cast(OPENDATE as date) OPEN_DATE,cast(CLOSEDATE as date)  CLOSE_DATE,LASTDIVDATE
				,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2)
							,right(ProcessDate,2)) Process_Date
				,LASTDIVAMOUNT,DIVTYPE,DIVRATE
				,PENALTYTYPE,PENALTYYTD
				,BALANCE,ORIGINALBALANCE,MINIMUMBALANCE,YEARENDBALANCE
				,WITHDRAWNFROMOPEN,WITHDRAWALFEETYPE,WITHDRAWALFEECOUNT
				,DESCRIPTION,NSFMONTHTODATE,nsffeemtd,FEECOUNT1,FEECOUNT2,FEECOUNT3,FEECOUNT4
				,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE,ACTIVITYDATE
				,COURTESYFEELY,COURTESYFEEMTD
				 from [ARCUSYM000]..SAVINGS where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) ) aa
				left join 
				(select UNID,max(closed_flag) Closed_flag
				from
					(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when CLOSEDATE is null then 0 else 1 end closed_flag
		
					from 
						(select distinct PARENTACCOUNT,ID,CLOSEDATE 
						from [ARCUSYM000]..SAVINGS
						 where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
						 ) a
					  )b
				group by UNID
				) c
				on aa.UNID=c.UNID
				left join #Static_SSN_account d
				on aa.PARENTACCOUNT=d.AccountNumber
				left join #groupproducttype_Deposits E
				on e.ProductCode=aa.TYPE
				where aa.Process_Date in (@staticpooldate)
				and PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) ) ZZ
				where OPEN_DATE<@staticpooldate and (Close_date is null or Close_date>@staticpooldate)
				and Funded_loan_flag=1 
				order by UNID,ProcessDate,TYPE

		

		

		------------------
		------------------   Transaciton data 

			
			-- drop table if exists ##Deposit_transaction
		

		select PARENTACCOUNT,PARENTID,UNID
			,count(*) Transaction_COUNT
			,sum(BALANCECHANGE) Transaction_amount
			,AVG(BALANCECHANGE) AVG_BALANCECHANGE
			,sum(Deposited_amount) Deposited_amount
			,sum(Deposited_Count) Deposited_count
			,sum(withdrawl_amount) withdrawal_amount
			,sum(withdrawl_Count) withdrawal_count
			,EFFECTIVEDATE_v1
		into ##Deposit_transaction
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      ,[COMMENTCODE]
      ,[TRANSFERCODE]
      ,[ADJUSTMENTCODE]
      ,[REGECODE]
      ,[REGDCHECKCODE]
      ,[REGDTRANSFERCODE]
      ,[VOIDCODE]
      ,[SUBACTIONCODE]
      ,[SEQUENCENUMBER]
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      ,[POSTDATE]
      ,[POSTTIME]
      ,[USERNUMBER]
      ,[USEROVERRIDE]
      ,[SECURITYLEVELS]
      ,[DESCRIPTION]
      ,[ACTIONCODE]
      ,[SOURCECODE]
      ,[BALANCECHANGE]
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	  ,case when BALANCECHANGE >=0 then 1 else 0 end Deposited_Count
	  , case when BALANCECHANGE <0 then 1 else 0 end withdrawl_Count
      ,[INTEREST]
      ,[NEWBALANCE]
      ,[FEEAMOUNT]
      ,[ESCROWAMOUNT]
      ,[LASTTRANDATE]
      ,[MATURITYLOANDUEDATE]
      ,[COMMENT]
      ,[BRANCH]
      ,[CONSOLENUMBER]
      ,[BATCHSEQUENCE]
      ,[SALESTAXAMOUNT]
      ,[ACTIVITYDATE]
      ,[BILLEDFEEAMOUNT]
      ,[PROCESSORUSER]
      ,[MEMBERBRANCH]
      ,[PREVAVAILBALANCE]
      ,[SUBSOURCE]
      ,[CONFIRMATIONSEQ]
      ,[MICRACCTNUM]
      ,[MICRRT]
      ,[RECURRINGTRAN]
      ,[FEEEXMTCRTSYAMT]
      ,[ESCROWUNPAIDBALCHG]
      ,[ESCROWAPPLIEDBALCHG]
      ,[UNAPPLIEDPARTIALPMTCHG]
      ,[FEECOUNTBY]
      ,[BALSEGCOUNT]
      ,[LATECHGWAIVEDAMT]
      ,[LATECHGUNPAIDCHGAMT]
      ,[PREVLATECHGDATE]
      ,[PREVLATECHGACCRUED]
      ,[LATECHGFIELDSVALID]
      ,[BALSEGID1]
      ,[BALSEGPMTCHANGEDATE1]
      ,[INTEFFECTDATE]
      ,[BALSEGPREVFIRSTPMTDATE1]
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
  
  FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION] 
  WHERE ACTIONCODE!='C') A
	where EFFECTIVEDATE_v1 = cast(left(convert(varchar,@staticpooldate,112),6) as int)
	      group by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1
			order by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1
	 
	 		
		
		

		----
		----******///// merging the saving and transaciton table 

		-- drop table if exists #Deposit_Product_all_data
		

		select a.*
		,b.Transaction_COUNT
		,b.Transaction_amount
		,AVG_BALANCECHANGE
		,b.Deposited_amount
		,Deposited_count
		,withdrawal_amount
		,withdrawal_count
		into #Deposit_Product_all_data
		 from #Deposit_account_data a
		left join ##Deposit_transaction b
		on a.UNID=b.UNID
		and ProcessDate_v=b.EFFECTIVEDATE_v1

		

		-- Drop talbe if exists #Deposit_summary
		

		select ssn ssn00,count(distinct UNID) Count_Total_Deposit_ACCT, count(distinct type) Count_product_Total_Deposit_ACCT 
		,min(opendate) MIN_OPENDATE_Total_Deposit_ACCT,MAX(CLOSEDATE) Max_closedate_Total_Deposit_ACCT
		,Sum(LASTDIVAMOUNT) SUM_LASTDIVAMOUNT_Total_Deposit_ACCT,AVG(LASTDIVAMOUNT) Avg_LASTDIVAMOUNT_Total_Deposit_ACCT
		,SUM(Month_end_balance) SUM_Month_end_balance_Total_Deposit_ACCT,avg(Month_end_balance) AVG_Month_end_balance_Total_Deposit_ACCT
		,sum(CHARGEOFFAMOUNT) SUM_CHARGEOFFAMOUNT_Total_Deposit_ACCT,avg(CHARGEOFFAMOUNT) AVG_CHARGEOFFAMOUNT_Total_Deposit_ACCT
		,sum(Closed_flag) SUM_Closed_flag_Total_Deposit_ACCT
		,max(MOB) MAX_MOB_Total_Deposit_ACCT,SUM(Transaction_COUNT) SUM_Transaction_COUNT_Total_Deposit_ACCT
		,AVg(Transaction_COUNT) AVG_Transaction_COUNT_Total_Deposit_ACCT
		,SUM(Deposited_amount) SUM_Deposited_amount_Total_Deposit_ACCT,avg(Deposited_amount) AVG_Deposited_amount_Total_Deposit_ACCT
		,sum(Deposited_count) SUM_Deposited_count_Total_Deposit_ACCT,avg(Deposited_count) AVG_Deposited_count_Total_Deposit_ACCT
		,sum(withdrawal_amount) SUM_withdrawal_amount_Total_Deposit_ACCT,avg(withdrawal_amount) AVG_withdrawal_amount_Total_Deposit_ACCT
		,sum(withdrawal_count) SUM_withdrawal_count_Total_Deposit_ACCT,avg(withdrawal_count) AVG_withdrawal_count_Total_Deposit_ACCT
		INTO #Deposit_summary
		from #Deposit_Product_all_data
		where Process_Date=@staticpooldate and SSN is not null
		and OPEN_DATE<@staticpooldate and (Close_date>@staticpooldate or Close_date is null)
		group by ssn
		order by SSN

		
		
		-------------------------------------------------------------------------------------------------------------------
		------------------------------------------------------------------------------------------------------------------

		-------------------------------*************Checking Account ***************-----------------------------------
		--Certificates   Money Market               
		
		  drop table if exists #Checkings_account

				-- closed_flag will remove the account closed account in any time 
		

		select ssn,UNID,ProcessDate,PARENTACCOUNT,id,TYPE,OPENDATE,CLOSEDATE,LASTDIVAMOUNT,BALANCE Month_end_balance
		,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE
		,COURTESYFEEMTD Courtesy_fee_count,COURTESYPAYMONTHTODATE,NSFFEEMTD NSF_Fee_count,NSFMONTHTODATE
		,overdraftfeeytd,FEECOUNT1,FEECOUNT2
		,Closed_flag,Close_date,OPEN_DATE ,left(ProcessDate,6) ProcessDate_v 
		,Quarters
		  ,case when Product_Group_wise='checking' and Process_Date=@staticpooldate then 1 else 0 end Staticpool_Checking_flag
		   ,DATEDIFF(MONTH,OPENDATE,@staticpooldate) MOB
		 into #Checkings_account 
		from 
		(
		select  
		d.SSN
		,aa.*,c.Closed_flag
		,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		 when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		  when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		   when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		   when Process_Date in (@staticpooldate) then 'Staticpool'
		  end Quarters
		,case when aa.closedate is null then '' 
		when len(month(aa.closedate))=1 then CONCAT(year(aa.closedate),0,month(aa.closedate))
		else CONCAT(year(aa.closedate),month(aa.closedate)) end  Closed_date_INT
		,case when len(month(aa.opendate))=1 then CONCAT(year(aa.OPENDATE),0,month(aa.OPENDATE))
		else CONCAT(year(aa.OPENDATE),month(aa.OPENDATE)) end  OPEN_date_INT_INT
		,case when aa.OPENDATE=aa.CLOSEDATE then 0 else 1 end Funded_loan_flag
		,E.ProductName,E.Product_Group_wise	
		,case when (closedate is null and CHARGEOFFDATE is null) or ProcessDate_v=close_date_v 
		or ProcessDate_v=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
		,case when Product_Group_wise='Certificates' and BALANCE=0 then 0 else 1 end carryforward_flag
		from 
					(
					select 
					CONCAT(PARENTACCOUNT,id) UNID
					,ProcessDate,PARENTACCOUNT,ID,TYPE
					,LASTDIVDATE,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE)) 
					 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v,left(ProcessDate,6) ProcessDate_v
					,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
					else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date_v
					,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
					,cast(OPENDATE as date) Open_date
					,cast(CLOSEDATE as date) Close_date,closedate,opendate
					,LASTDIVAMOUNT,DIVTYPE,DIVRATE,COURTESYPAYMONTHTODATE
					,PENALTYTYPE,PENALTYYTD
					,BALANCE,ORIGINALBALANCE,MINIMUMBALANCE,YEARENDBALANCE
					,WITHDRAWNFROMOPEN,WITHDRAWALFEETYPE,WITHDRAWALFEECOUNT
					,DESCRIPTION,NSFMONTHTODATE,nsffeemtd,FEECOUNT1,FEECOUNT2,FEECOUNT3,FEECOUNT4
					,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE,ACTIVITYDATE
					,COURTESYFEELY,COURTESYFEEMTD,OVERDRAFTFEEYTD
					 from [ARCUSYM000]..SAVINGS where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
					 ) aa
		left join 
		(select UNID,max(closed_flag) Closed_flag
		from
		(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when CLOSEDATE is null then 0 else 1 end closed_flag
		
		from 
		(select distinct PARENTACCOUNT,ID,CLOSEDATE 
		from [ARCUSYM000]..SAVINGS
		 where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
		 ) a )b
		group by UNID
		) c
		on aa.UNID=c.UNID
		left join #Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join  #groupproducttype_Deposits E
		on e.ProductCode=aa.TYPE
		where Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate))
		and PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) ) ZZ
		where Product_Group_wise='checking'  and OPEN_DATE<@staticpooldate and (Close_date is null or Close_date>@staticpooldate)
		and Funded_loan_flag=1 and Quarters is not null and open_flag=1 and carryforward_flag=1
		order by UNID,ProcessDate,TYPE

		
		------------------
		------------------   Transaciton data 

			
			-- drop table if exists ##Checkings_transaction
		

		select PARENTACCOUNT,PARENTID,UNID
			,count(*) Transaction_COUNT
			,sum(BALANCECHANGE) Transaction_amount
			,AVG(BALANCECHANGE) AVG_BALANCECHANGE
			,sum(Deposited_amount) Deposited_amount
			,count(Deposited_amount) Deposited_count
			,sum(withdrawl_amount) withdrawal_amount
			,count(withdrawl_amount) withdrawal_count
			,sum(INTEREST) Sum_INTEREST
			,EFFECTIVEDATE_v1
		into ##Checkings_transaction
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      ,[COMMENTCODE]
      ,[TRANSFERCODE]
      ,[ADJUSTMENTCODE]
      ,[REGECODE]
      ,[REGDCHECKCODE]
      ,[REGDTRANSFERCODE]
      ,[VOIDCODE]
      ,[SUBACTIONCODE]
      ,[SEQUENCENUMBER]
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      ,[POSTDATE]
      ,[POSTTIME]
      ,[USERNUMBER]
      ,[USEROVERRIDE]
      ,[SECURITYLEVELS]
      ,[DESCRIPTION]
      ,[ACTIONCODE]
      ,[SOURCECODE]
      ,[BALANCECHANGE]
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	  
      ,[INTEREST]
      ,[NEWBALANCE]
      ,[FEEAMOUNT]
      ,[ESCROWAMOUNT]
      ,[LASTTRANDATE]
      ,[MATURITYLOANDUEDATE]
      ,[COMMENT]
      ,[BRANCH]
      ,[CONSOLENUMBER]
      ,[BATCHSEQUENCE]
      ,[SALESTAXAMOUNT]
      ,[ACTIVITYDATE]
      ,[BILLEDFEEAMOUNT]
      ,[PROCESSORUSER]
      ,[MEMBERBRANCH]
      ,[PREVAVAILBALANCE]
      ,[SUBSOURCE]
      ,[CONFIRMATIONSEQ]
      ,[MICRACCTNUM]
      ,[MICRRT]
      ,[RECURRINGTRAN]
      ,[FEEEXMTCRTSYAMT]
      ,[ESCROWUNPAIDBALCHG]
      ,[ESCROWAPPLIEDBALCHG]
      ,[UNAPPLIEDPARTIALPMTCHG]
      ,[FEECOUNTBY]
      ,[BALSEGCOUNT]
      ,[LATECHGWAIVEDAMT]
      ,[LATECHGUNPAIDCHGAMT]
      ,[PREVLATECHGDATE]
      ,[PREVLATECHGACCRUED]
      ,[LATECHGFIELDSVALID]
      ,[BALSEGID1]
      ,[BALSEGPMTCHANGEDATE1]
      ,[INTEFFECTDATE]
      ,[BALSEGPREVFIRSTPMTDATE1]
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
  
  FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
  WHERE PARENTACCOUNT IN (SELECT PARENTACCOUNT FROM #Checkings_account)
  and PARENTID in (select ID from #Checkings_account) 
   AND ACTIONCODE!='C') A
	where EFFECTIVEDATE_v1 between left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6) and left(convert(varchar,@staticpooldate,112),6)
      group by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1
			order by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1
	 
	
		

		----
		----******///// merging the saving and transaciton table 

		-- drop table if exists #Checkings_account_data
		
		select a.*
		,b.Transaction_COUNT
		,b.Transaction_amount
		,AVG_BALANCECHANGE
		,b.Deposited_amount
		,Deposited_count
		,withdrawal_amount
		,withdrawal_count
		,sum_interest
		into #Checkings_account_data
		from #Checkings_account a
		left join ##Checkings_transaction b
		on a.UNID=b.UNID
		and ProcessDate_v=b.EFFECTIVEDATE_v1

		
		
		
		----------------------------------------------------------------------------------------------------
		----------------------------------------------------------------------------------------------------


		-----------------------------/*****Certificates*******\--------------------------------------------------


		--Certificates   Money Market               
		
		--  drop table if exists #Certificates_account

				-- closed_flag will remove the account closed account in any time 
		

		select ssn,UNID,ProcessDate,PARENTACCOUNT,id,TYPE,OPENDATE,CLOSEDATE,LASTDIVAMOUNT,BALANCE Month_end_balance
		,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE
		,COURTESYFEEMTD Courtesy_fee_count,COURTESYPAYMONTHTODATE,NSFFEEMTD NSF_Fee_count,NSFMONTHTODATE
		,overdraftfeeytd,FEECOUNT1,FEECOUNT2
		,Closed_flag,Close_date,OPEN_DATE ,left(ProcessDate,6) ProcessDate_v ,Quarters
		,case when Product_Group_wise='Certificates' and Process_Date=@staticpooldate then 1 else 0 end Staticpool_Certificates_flag
		   ,DATEDIFF(MONTH,OPENDATE,@staticpooldate) MOB
		 into #Certificates_account 
		from 
		(
		select  
		d.SSN
		,aa.*,c.Closed_flag
		,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		 when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		  when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		   when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		   when Process_Date in (@staticpooldate) then 'Staticpool'
		  end Quarters
		,case when aa.closedate is null then '' 
		when len(month(aa.closedate))=1 then CONCAT(year(aa.closedate),0,month(aa.closedate))
		else CONCAT(year(aa.closedate),month(aa.closedate)) end  Closed_date_INT
		,case when len(month(aa.opendate))=1 then CONCAT(year(aa.OPENDATE),0,month(aa.OPENDATE))
		else CONCAT(year(aa.OPENDATE),month(aa.OPENDATE)) end  OPEN_date_INT_INT
		,case when aa.OPENDATE=aa.CLOSEDATE then 0 else 1 end Funded_loan_flag
		,E.ProductName,E.Product_Group_wise		
		,case when (closedate is null and CHARGEOFFDATE is null) or ProcessDate_v=close_date_v 
		or ProcessDate_v=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
		,case when Product_Group_wise='Certificates' and BALANCE=0 then 0 else 1 end carryforward_flag
		from 
					(
					select 
					CONCAT(PARENTACCOUNT,id) UNID
					,ProcessDate,PARENTACCOUNT,ID,TYPE
					,LASTDIVDATE,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE)) 
					 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v,left(ProcessDate,6) ProcessDate_v
					,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
					else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date_v
					,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
					,cast(OPENDATE as date) Open_date
					,cast(CLOSEDATE as date) Close_date,closedate,opendate
					,LASTDIVAMOUNT,DIVTYPE,DIVRATE
					,PENALTYTYPE,PENALTYYTD
					,BALANCE,ORIGINALBALANCE,MINIMUMBALANCE,YEARENDBALANCE
					,WITHDRAWNFROMOPEN,WITHDRAWALFEETYPE,WITHDRAWALFEECOUNT
					,DESCRIPTION,NSFMONTHTODATE,nsffeemtd,FEECOUNT1,FEECOUNT2,FEECOUNT3,FEECOUNT4
					,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE,ACTIVITYDATE
					,COURTESYFEELY,COURTESYFEEMTD,COURTESYPAYMONTHTODATE,overdraftfeeytd
					 from [ARCUSYM000]..SAVINGS where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
					 ) aa
		left join 
		(select UNID,max(closed_flag) Closed_flag
		from
		(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when CLOSEDATE is null then 0 else 1 end closed_flag
		from 
		(select distinct PARENTACCOUNT,ID,CLOSEDATE 
		from [ARCUSYM000]..SAVINGS
		 where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
		 ) a )b
		group by UNID
		) c
		on aa.UNID=c.UNID
		left join #Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join  #groupproducttype_Deposits E
		on e.ProductCode=aa.TYPE
		where Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate))
		and PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) ) ZZ
		where Product_Group_wise='Certificates'  and OPEN_DATE<@staticpooldate and (Close_date is null or Close_date>@staticpooldate)
		and Funded_loan_flag=1 and Quarters is not null and open_flag=1 and carryforward_flag=1
		order by UNID,ProcessDate,TYPE

		
		
		------------------
		------------------   Transaciton data 

			
			-- drop table if exists ##Certificates_transaction
		

		select PARENTACCOUNT,PARENTID,UNID
			,count(*) Transaction_COUNT
			,sum(BALANCECHANGE) Transaction_amount
			,AVG(BALANCECHANGE) AVG_BALANCECHANGE
			,sum(Deposited_amount) Deposited_amount
			,count(Deposited_amount) Deposited_count
			,sum(withdrawl_amount) withdrawal_amount
			,count(withdrawl_amount) withdrawal_count
			,sum(INTEREST) Sum_INTEREST
			,EFFECTIVEDATE_v1
		into ##Certificates_transaction
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      ,[COMMENTCODE]
      ,[TRANSFERCODE]
      ,[ADJUSTMENTCODE]
      ,[REGECODE]
      ,[REGDCHECKCODE]
      ,[REGDTRANSFERCODE]
      ,[VOIDCODE]
      ,[SUBACTIONCODE]
      ,[SEQUENCENUMBER]
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      ,[POSTDATE]
      ,[POSTTIME]
      ,[USERNUMBER]
      ,[USEROVERRIDE]
      ,[SECURITYLEVELS]
      ,[DESCRIPTION]
      ,[ACTIONCODE]
      ,[SOURCECODE]
      ,[BALANCECHANGE]
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	  ,[INTEREST]
      ,[NEWBALANCE]
      ,[FEEAMOUNT]
      ,[ESCROWAMOUNT]
      ,[LASTTRANDATE]
      ,[MATURITYLOANDUEDATE]
      ,[COMMENT]
      ,[BRANCH]
      ,[CONSOLENUMBER]
      ,[BATCHSEQUENCE]
      ,[SALESTAXAMOUNT]
      ,[ACTIVITYDATE]
      ,[BILLEDFEEAMOUNT]
      ,[PROCESSORUSER]
      ,[MEMBERBRANCH]
      ,[PREVAVAILBALANCE]
      ,[SUBSOURCE]
      ,[CONFIRMATIONSEQ]
      ,[MICRACCTNUM]
      ,[MICRRT]
      ,[RECURRINGTRAN]
      ,[FEEEXMTCRTSYAMT]
      ,[ESCROWUNPAIDBALCHG]
      ,[ESCROWAPPLIEDBALCHG]
      ,[UNAPPLIEDPARTIALPMTCHG]
      ,[FEECOUNTBY]
      ,[BALSEGCOUNT]
      ,[LATECHGWAIVEDAMT]
      ,[LATECHGUNPAIDCHGAMT]
      ,[PREVLATECHGDATE]
      ,[PREVLATECHGACCRUED]
      ,[LATECHGFIELDSVALID]
      ,[BALSEGID1]
      ,[BALSEGPMTCHANGEDATE1]
      ,[INTEFFECTDATE]
      ,[BALSEGPREVFIRSTPMTDATE1]
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
	 FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
	  WHERE PARENTACCOUNT IN (SELECT PARENTACCOUNT FROM #Certificates_account)
	  and PARENTID in (select ID from #Certificates_account) 
   AND ACTIONCODE!='C') A
	-- day wise data include all dates 
	where EFFECTIVEDATE_v1 between left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6) and left(convert(varchar,@staticpooldate,112),6)
      group by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1
			order by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1
	 
	
		
		
		----
		----******///// merging the saving and transaciton table 

		-- drop table if exists #Certificates_account_data
		
		select a.*
		,b.Transaction_COUNT
		,b.Transaction_amount
		,AVG_BALANCECHANGE
		,b.Deposited_amount
		,Deposited_count
		,withdrawal_amount
		,withdrawal_count
		,sum_interest
		into #Certificates_account_data
		from #Certificates_account a
		left join ##Certificates_transaction b
		on a.UNID=b.UNID
		and ProcessDate_v=b.EFFECTIVEDATE_v1

		


		----------------------------------------------------------------------------------------------------
		----------------------------------------------------------------------------------------------------


		-----------------------------/*****Money Market*******\--------------------------------------------------


		--Certificates   Money Market               
		
		--  drop table if exists #Money_Market_account

				-- closed_flag will remove the account closed account in any time 
		

		select ssn,UNID,ProcessDate,PARENTACCOUNT,id,TYPE,OPENDATE,CLOSEDATE,LASTDIVAMOUNT,BALANCE Month_end_balance
		,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE
		,Closed_flag,Close_date,OPEN_DATE ,left(ProcessDate,6) ProcessDate_v 
		,Quarters
		  ,case when Product_Group_wise='Money Market' and Process_Date=@staticpooldate then 1 else 0 end StaticPool_Money_market_flag
		   ,DATEDIFF(MONTH,OPENDATE,@staticpooldate) MOB
		 into #Money_Market_account 
		from 
		(
		select  
		d.SSN
		,aa.*,c.Closed_flag
		,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		 when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		  when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		   when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		   when Process_Date in (@staticpooldate) then 'Staticpool'
		  end Quarters
		,case when aa.closedate is null then '' 
		when len(month(aa.closedate))=1 then CONCAT(year(aa.closedate),0,month(aa.closedate))
		else CONCAT(year(aa.closedate),month(aa.closedate)) end  Closed_date_INT
		,case when len(month(aa.opendate))=1 then CONCAT(year(aa.OPENDATE),0,month(aa.OPENDATE))
		else CONCAT(year(aa.OPENDATE),month(aa.OPENDATE)) end  OPEN_date_INT_INT
		,case when aa.OPENDATE=aa.CLOSEDATE then 0 else 1 end Funded_loan_flag
		,E.ProductName,E.Product_Group_wise	
		,case when (closedate is null and CHARGEOFFDATE is null) or ProcessDate_v=close_date_v 
		or ProcessDate_v=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
		,case when Product_Group_wise='Certificates' and BALANCE=0 then 0 else 1 end carryforward_flag
		from 
					(
					select 
					CONCAT(PARENTACCOUNT,id) UNID
					,ProcessDate,PARENTACCOUNT,ID,TYPE
					,LASTDIVDATE,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE)) 
					 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v,left(ProcessDate,6) ProcessDate_v
					,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
					else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date_v
					,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
					,cast(OPENDATE as date) Open_date
					,cast(CLOSEDATE as date) Close_date,closedate,opendate
					,LASTDIVAMOUNT,DIVTYPE,DIVRATE
					,PENALTYTYPE,PENALTYYTD
					,BALANCE,ORIGINALBALANCE,MINIMUMBALANCE,YEARENDBALANCE
					,WITHDRAWNFROMOPEN,WITHDRAWALFEETYPE,WITHDRAWALFEECOUNT
					,DESCRIPTION,NSFMONTHTODATE,nsffeemtd,FEECOUNT1,FEECOUNT2,FEECOUNT3,FEECOUNT4
					,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE,ACTIVITYDATE
					,COURTESYFEELY,COURTESYFEEMTD
					 from [ARCUSYM000]..SAVINGS where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
					 ) aa
		left join 
		(select UNID,max(closed_flag) Closed_flag
		from
		(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when CLOSEDATE is null then 0 else 1 end closed_flag
		
		from 
		(select distinct PARENTACCOUNT,ID,CLOSEDATE 
		from [ARCUSYM000]..SAVINGS
		 where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
		 ) a )b
		group by UNID
		) c
		on aa.UNID=c.UNID
		left join #Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join  #groupproducttype_Deposits E
		on e.ProductCode=aa.TYPE
		where Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate))
		and PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) ) ZZ
		where Product_Group_wise='Money Market'  and OPEN_DATE<@staticpooldate and (Close_date is null or Close_date>@staticpooldate)
		and Funded_loan_flag=1 and Quarters is not null and open_flag=1 and carryforward_flag=1
		order by UNID,ProcessDate,TYPE

		
		
		------------------
		------------------   Transaciton data 
		
			
			-- drop table if exists ##Money_Market_transaction
		

		select PARENTACCOUNT,PARENTID,UNID
			,count(*) Transaction_COUNT
			,sum(BALANCECHANGE) Transaction_amount
			,AVG(BALANCECHANGE) AVG_BALANCECHANGE
			,sum(Deposited_amount) Deposited_amount
			,count(Deposited_amount) Deposited_count
			,sum(withdrawl_amount) withdrawal_amount
			,count(withdrawl_amount) withdrawal_count
			,sum(INTEREST) Sum_INTEREST
			,EFFECTIVEDATE_v1
		into ##Money_Market_transaction
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      ,[COMMENTCODE]
      ,[TRANSFERCODE]
      ,[ADJUSTMENTCODE]
      ,[REGECODE]
      ,[REGDCHECKCODE]
      ,[REGDTRANSFERCODE]
      ,[VOIDCODE]
      ,[SUBACTIONCODE]
      ,[SEQUENCENUMBER]
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      ,[POSTDATE]
      ,[POSTTIME]
      ,[USERNUMBER]
      ,[USEROVERRIDE]
      ,[SECURITYLEVELS]
      ,[DESCRIPTION]
      ,[ACTIONCODE]
      ,[SOURCECODE]
      ,[BALANCECHANGE]
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	  
      ,[INTEREST]
      ,[NEWBALANCE]
      ,[FEEAMOUNT]
      ,[ESCROWAMOUNT]
      ,[LASTTRANDATE]
      ,[MATURITYLOANDUEDATE]
      ,[COMMENT]
      ,[BRANCH]
      ,[CONSOLENUMBER]
      ,[BATCHSEQUENCE]
      ,[SALESTAXAMOUNT]
      ,[ACTIVITYDATE]
      ,[BILLEDFEEAMOUNT]
      ,[PROCESSORUSER]
      ,[MEMBERBRANCH]
      ,[PREVAVAILBALANCE]
      ,[SUBSOURCE]
      ,[CONFIRMATIONSEQ]
      ,[MICRACCTNUM]
      ,[MICRRT]
      ,[RECURRINGTRAN]
      ,[FEEEXMTCRTSYAMT]
      ,[ESCROWUNPAIDBALCHG]
      ,[ESCROWAPPLIEDBALCHG]
      ,[UNAPPLIEDPARTIALPMTCHG]
      ,[FEECOUNTBY]
      ,[BALSEGCOUNT]
      ,[LATECHGWAIVEDAMT]
      ,[LATECHGUNPAIDCHGAMT]
      ,[PREVLATECHGDATE]
      ,[PREVLATECHGACCRUED]
      ,[LATECHGFIELDSVALID]
      ,[BALSEGID1]
      ,[BALSEGPMTCHANGEDATE1]
      ,[INTEFFECTDATE]
      ,[BALSEGPREVFIRSTPMTDATE1]
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
  
  FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
  WHERE PARENTACCOUNT IN (SELECT PARENTACCOUNT FROM #Money_Market_account)
  and PARENTID in (select ID from #Money_Market_account) 
   AND ACTIONCODE!='C') A
	where EFFECTIVEDATE_v1 between left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6) and left(convert(varchar,@staticpooldate,112),6)
      group by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1
			order by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1
	 
	
		
		
		----
		----******///// merging the saving and transaciton table 

		-- drop table if exists #Money_Market_account_data
		
		select a.*
		,b.Transaction_COUNT
		,b.Transaction_amount
		,AVG_BALANCECHANGE
		,b.Deposited_amount
		,Deposited_count
		,withdrawal_amount
		,withdrawal_count
		,sum_interest
		
		
		into #Money_Market_account_data
		from #Money_Market_account a
		left join ##Money_Market_transaction b
		on a.UNID=b.UNID
		and ProcessDate_v=b.EFFECTIVEDATE_v1

		

		---------------------------------------credit cards data 

		
		
  -- drop table if exists #CC_Members_Static
	  select distinct [Social Security Number] 
	  into #CC_Members_Static
	  from analytics..cardholder 
	  where Active_Flag=1 and [External Status Code]='' and [Internal Status Code] in ('N','')
	  and extract_datepart=left(convert(varchar,@staticpooldate,112),6)

			


		-- drop table if exists #CC_data	
		
		
		select * 
		into #CC_data
		from 
		(
		SELECT  [Durable_Key]
		,case when extract_datepart in (left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-11,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-10,@staticpooldate),112),6)) then 'Q4'
		    when extract_datepart in (left(convert(varchar,dateadd(month,-9,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-8,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-7,@staticpooldate),112),6)) then 'Q3'
		    when extract_datepart in (left(convert(varchar,dateadd(month,-6,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-5,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-4,@staticpooldate),112),6)) then 'Q2'
		    when extract_datepart in (left(convert(varchar,dateadd(month,-3,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-2,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-1,@staticpooldate),112),6)) then 'Q1'
		    when extract_datepart in (left(convert(varchar,@staticpooldate,112),6)) then 'Staticpool' end Quarters
       ,[Social Security Number]
      ,[Credit Limit]
      ,[Extract Date]
       ,[AGE]
      ,[Account System Entry Date]
      ,[Card Account Debit Activity Code]
      ,[Last Statement Payment Count]
      ,[Last Statement Payment Amount]
      ,[Last Statement Sale Amount]
      ,[Last Statement Cash Amount]
      ,[Last Statement Return Amount]
      ,[Last Statment Sale Count]
      ,[Last Statement Cash Advance Count]
      ,[Last Statement Return Count]
      ,[Last Statement External Fee Amount]
      ,[Last Statement Credit Life Change Amount]
      ,[Last Statement Charge Late Amount]
      ,[Last Statement Charge Cash Amount]
      ,[Last Statement Charge Overlimit Amount]
      ,[Last Statement Charge Sale Amount]
      ,[Last Statement Merchandise Average Daily Balance Amount]
      ,[Last Statement Cash Average Daily Balance Amount]
      ,[Last Statement Average Daily Balance Amount]
      ,[Calc Norm Cash Annual Rate]
      ,[Calc Norm Mrch Annual Rate]
      ,[Charge-Off Amount]
      ,[Card Account Charge-Off Date]
      ,[Card Description]
      ,[Card Account Delinquent Day Account]
      ,[Total Amount Account Delinquency]
      ,[Last Statement Cash Interest Amount]
      ,[Accumulated Merchandise Interest Amount]
      ,[Last Statement Balance Amount]
      ,[Last Statement Revolving Merchandise Amount]
      ,[extract_datepart]
      ,[Extract_ACCOUNT_OPEN_DATE]
      ,[spend]
      ,[Protected_Balance]
      ,[Promo_Balance]
      ,[Protected_Current_Interest]
      ,[Promo_Current_Interest]
      ,[RevolvingBalance]
      ,[Closed_account_flag]
      ,[mob]
      ,[ChargeoffAmount_final]
      ,[ChargeOff_Extract_DatePart]
	   ,TRIPFLAG
  FROM [Analytics].[dbo].[cardholder]
  where [Social Security Number] in (select [Social Security Number] from #CC_Members_Static)
  and Active_Flag=1 ) a where  quarters is not null and mob>=12

		

		-- Drop table if exists #Credit_Card_data
		select 
		*,(CL_CC_StaticPool-CreditLimit_CC_Q1) CL_DIFF_past_oneyear
		into #Credit_Card_data
		from 
		(
		select [Social Security Number] SSN_CC
		
			,SUM(case when Quarters='Q1' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q1]
			,SUM(case when Quarters='Q1' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statment Sale Count] END) [Last Statment Sale Count_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then [spend] END) [spend_CC_Q1]
			,SUM(case when Quarters='Q1' then [Protected_Balance] END) [Protected_Balance_CC_Q1]
			,SUM(case when Quarters='Q1' then [Promo_Balance] END) [Promo_Balance_CC_Q1]
			,SUM(case when Quarters='Q1' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q1]
			,SUM(case when Quarters='Q1' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q1]
			,SUM(case when Quarters='Q1' then [RevolvingBalance] END) [RevolvingBalance_CC_Q1]
			,max(case when Quarters='Q1' then [Credit Limit] end ) [CreditLimit_CC_Q1]

			,SUM(case when Quarters='Q2' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q2]
			,SUM(case when Quarters='Q2' then [Last Statement Payment Amount] END) [Last Statement Payment Amount)_CC_Q2]
			,SUM(case when Quarters='Q2' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statment Sale Count] END) [Last Statment Sale Count_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then [spend] END) [spend_CC_Q2]
			,SUM(case when Quarters='Q2' then [Protected_Balance] END) [Protected_Balance_CC_Q2]
			,SUM(case when Quarters='Q2' then [Promo_Balance] END) [Promo_Balance_CC_Q2]
			,SUM(case when Quarters='Q2' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q2]
			,SUM(case when Quarters='Q2' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q2]
			,SUM(case when Quarters='Q2' then [RevolvingBalance] END) [RevolvingBalance_CC_Q2]

			,SUM(case when Quarters='Q3' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q3]
			,SUM(case when Quarters='Q3' then [Last Statement Payment Amount] END) [Last Statement Payment Amount)_CC_Q3]
			,SUM(case when Quarters='Q3' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statment Sale Count] END) [Last Statment Sale Count_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then [spend] END) [spend_CC_Q3]
			,SUM(case when Quarters='Q3' then [Protected_Balance] END) [Protected_Balance_CC_Q3]
			,SUM(case when Quarters='Q3' then [Promo_Balance] END) [Promo_Balance_CC_Q3]
			,SUM(case when Quarters='Q3' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q3]
			,SUM(case when Quarters='Q3' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q3]
			,SUM(case when Quarters='Q3' then [RevolvingBalance] END) [RevolvingBalance_CC_Q3]

			,SUM(case when Quarters='Q4' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q4]
			,SUM(case when Quarters='Q4' then [Last Statement Payment Amount] END) [Last Statement Payment Amount)_CC_Q4]
			,SUM(case when Quarters='Q4' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statment Sale Count] END) [Last Statment Sale Count_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then [spend] END) [spend_CC_Q4]
			,SUM(case when Quarters='Q4' then [Protected_Balance] END) [Protected_Balance_CC_Q4]
			,SUM(case when Quarters='Q4' then [Promo_Balance] END) [Promo_Balance_CC_Q4]
			,SUM(case when Quarters='Q4' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q4]
			,SUM(case when Quarters='Q4' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q4]
			,SUM(case when Quarters='Q4' then [RevolvingBalance] END) [RevolvingBalance_CC_Q4]

			,SUM(case when Quarters='Staticpool' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Last Statement Payment Amount] END) [Last Statement Payment Amount)_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statment Sale Count] END) [Last Statment Sale Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [spend] END) [spend_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Protected_Balance] END) [Protected_Balance_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Promo_Balance] END) [Promo_Balance_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [RevolvingBalance] END) [RevolvingBalance_CC_Staticpool]
			
			  from #CC_data
			  group by [Social Security Number]) a

		  left join (     
		  select [Social Security Number]  [Social Security Number_CC]
			,count(distinct Durable_Key) Count_Durable_CC
			,Max([Credit Limit]) max_credit_Limit
			,max(AGE) max_age_member_CC
			,max([Extract_ACCOUNT_OPEN_DATE]) [Max_Extract_ACCOUNT_OPEN_DATE_CC]
			 ,max([Closed_account_flag]) [Max_Closed_account_flag_CC]
			,max([mob]) Max_MOB_CC
		   ,sum([ChargeoffAmount_final]) ChargeoffAmount_final_CC
			 ,max([ChargeOff_Extract_DatePart]) Max_chargoff_date_CC
			 from #CC_data
			 group by [Social Security Number]
			 ) b
			 on a.SSN_CC=b.[Social Security Number_CC]
			 left join 			
			 (
			 select [Social Security Number] SSN_00,max([Credit Limit]) CL_CC_StaticPool
			 ,max(mob) MOB_CC_staticPool
			 ,max(case when TRIPFLAG='T' then 1
			 when TRIPFLAG='R' then 2
			 when TRIPFLAG='I' then 3
			 when TRIPFLAG='P' then 4 else null end) TRIP_FLAG_staticpool from #cc_data
			 where Quarters='staticpool'
			 group by [Social Security Number]) w
			 on a.ssn_cc=w.SSN_00
			 

		--------------------------------------------------------------------------------------------------------------------------------------------
										--  Merging the data
		--------------------------------------------------------------------------------------------------------------------------------------------

		
			---------------------------------------------------------------------------------------------------------------------------
				-------------------MERGING ALL LOAN TALBE---------------------------------------------------------------------------

				-- drop table if exists analytics.dbo.Master_table_data
				-- drop table #masterdata
				
				select AA.SSN
				,V.sum_Target_Commercial
				,V.sum_Target_Fresh_Start
				,V.sum_Target_Real_estate
				,v.sum_Target_Real_estate2
				,V.sum_Target_secured
				,V.sum_Target_Unsecured
				,V.sum_Target_Vehicles
				,V.sum_Target_Wealth_Management
				,V.sum_Target_Work_Out


				,V.Commercial_ACCT_Flag
				,V.Fresh_Start_ACCT_Flag
				,V.Real_estate_ACCT_Flag
				,V.Real_estate2_ACCT_Flag
				,V.secured_ACCT_Flag
				,V.Unsecured_ACCT_Flag
				,V.Vehicles_ACCT_Flag
				,V.Wealth_Management_ACCT_Flag
				,V.Work_Out_ACCT_Flag

				,V.Opendate_Commercial_ACCT_Flag
				,V.Opendate_Fresh_Start_ACCT_Flag
				,V.Opendate_Real_estate_ACCT_Flag
				,V.Opendate_Real_estate2_ACCT_Flag
				,V.Opendate_secured_ACCT_Flag
				,V.Opendate_Unsecured_ACCT_Flag
				,V.Opendate_Vehicles_ACCT_Flag
				,V.Opendate_Wealth_Management_ACCT_Flag
				,V.Opendate_Work_Out_ACCT_Flag


				,W.Sum_Target_Certificates
				,W.Sum_Target_Savings
				,W.Sum_Target_Checking
				,W.Sum_Target_Money_market
				,W.Certificates_ACCT_Flag
				,W.Savings_ACCT_Flag
				,W.Checking_ACCT_Flag
				,W.Money_market_ACCT_Flag
				,W.opendate_Certificates_ACCT_Flag
				,W.opendate_Savings_ACCT_Flag
				,W.opendate_Checking_ACCT_Flag
				,W.opendate_Money_market_ACCT_Flag
				


				,X.[Last Statement Payment Count_CC_Q1]
				,X.[Last Statement Payment Amount_CC_Q1]
				,X.[Last Statement Sale Amount_CC_Q1]
				,X.[Last Statement Cash Amount_CC_Q1]
				,X.[Last Statement Return Amount_CC_Q1]
				,X.[Last Statment Sale Count_CC_Q1]
				,X.[Last Statement Cash Advance Count_CC_Q1]
				,X.[Last Statement Return Count_CC_Q1]
				,X.[Last Statement External Fee Amount_CC_Q1]
				,X.[Last Statement Credit Life Change Amount_CC_Q1]
				,X.[Last Statement Charge Late Amount_CC_Q1]
				,X.[Last Statement Charge Cash Amount_CC_Q1]
				,X.[Last Statement Charge Overlimit Amount_CC_Q1]
				,X.[Last Statement Charge Sale Amount_CC_Q1]
				,X.[Last Statement Merchandise Average Daily Balance Amount_CC_Q1]
				,X.[Last Statement Cash Average Daily Balance Amount_CC_Q1]
				,X.[Last Statement Average Daily Balance Amount_CC_Q1]
				,X.[spend_CC_Q1]
				,X.[Protected_Balance_CC_Q1]
				,X.[Promo_Balance_CC_Q1]
				,X.[Protected_Current_Interest_CC_Q1]
				,X.[Promo_Current_Interest_CC_Q1]
				,X.[RevolvingBalance_CC_Q1]
				,X.[CreditLimit_CC_Q1]
				,X.[Last Statement Payment Count_CC_Q2]
				,X.[Last Statement Payment Amount)_CC_Q2]
				,X.[Last Statement Sale Amount_CC_Q2]
				,X.[Last Statement Cash Amount_CC_Q2]
				,X.[Last Statement Return Amount_CC_Q2]
				,X.[Last Statment Sale Count_CC_Q2]
				,X.[Last Statement Cash Advance Count_CC_Q2]
				,X.[Last Statement Return Count_CC_Q2]
				,X.[Last Statement External Fee Amount_CC_Q2]
				,X.[Last Statement Credit Life Change Amount_CC_Q2]
				,X.[Last Statement Charge Late Amount_CC_Q2]
				,X.[Last Statement Charge Cash Amount_CC_Q2]
				,X.[Last Statement Charge Overlimit Amount_CC_Q2]
				,X.[Last Statement Charge Sale Amount_CC_Q2]
				,X.[Last Statement Merchandise Average Daily Balance Amount_CC_Q2]
				,X.[Last Statement Cash Average Daily Balance Amount_CC_Q2]
				,X.[Last Statement Average Daily Balance Amount_CC_Q2]
				,X.[spend_CC_Q2]
				,X.[Protected_Balance_CC_Q2]
				,X.[Promo_Balance_CC_Q2]
				,X.[Protected_Current_Interest_CC_Q2]
				,X.[Promo_Current_Interest_CC_Q2]
				,X.[RevolvingBalance_CC_Q2]
				,X.[Last Statement Payment Count_CC_Q3]
				,X.[Last Statement Payment Amount)_CC_Q3]
				,X.[Last Statement Sale Amount_CC_Q3]
				,X.[Last Statement Cash Amount_CC_Q3]
				,X.[Last Statement Return Amount_CC_Q3]
				,X.[Last Statment Sale Count_CC_Q3]
				,X.[Last Statement Cash Advance Count_CC_Q3]
				,X.[Last Statement Return Count_CC_Q3]
				,X.[Last Statement External Fee Amount_CC_Q3]
				,X.[Last Statement Credit Life Change Amount_CC_Q3]
				,X.[Last Statement Charge Late Amount_CC_Q3]
				,X.[Last Statement Charge Cash Amount_CC_Q3]
				,X.[Last Statement Charge Overlimit Amount_CC_Q3]
				,X.[Last Statement Charge Sale Amount_CC_Q3]
				,X.[Last Statement Merchandise Average Daily Balance Amount_CC_Q3]
				,X.[Last Statement Cash Average Daily Balance Amount_CC_Q3]
				,X.[Last Statement Average Daily Balance Amount_CC_Q3]
				,X.[spend_CC_Q3]
				,X.[Protected_Balance_CC_Q3]
				,X.[Promo_Balance_CC_Q3]
				,X.[Protected_Current_Interest_CC_Q3]
				,X.[Promo_Current_Interest_CC_Q3]
				,X.[RevolvingBalance_CC_Q3]
				,X.[Last Statement Payment Count_CC_Q4]
				,X.[Last Statement Payment Amount)_CC_Q4]
				,X.[Last Statement Sale Amount_CC_Q4]
				,X.[Last Statement Cash Amount_CC_Q4]
				,X.[Last Statement Return Amount_CC_Q4]
				,X.[Last Statment Sale Count_CC_Q4]
				,X.[Last Statement Cash Advance Count_CC_Q4]
				,X.[Last Statement Return Count_CC_Q4]
				,X.[Last Statement External Fee Amount_CC_Q4]
				,X.[Last Statement Credit Life Change Amount_CC_Q4]
				,X.[Last Statement Charge Late Amount_CC_Q4]
				,X.[Last Statement Charge Cash Amount_CC_Q4]
				,X.[Last Statement Charge Overlimit Amount_CC_Q4]
				,X.[Last Statement Charge Sale Amount_CC_Q4]
				,X.[Last Statement Merchandise Average Daily Balance Amount_CC_Q4]
				,X.[Last Statement Cash Average Daily Balance Amount_CC_Q4]
				,X.[Last Statement Average Daily Balance Amount_CC_Q4]
				,X.[spend_CC_Q4]
				,X.[Protected_Balance_CC_Q4]
				,X.[Promo_Balance_CC_Q4]
				,X.[Protected_Current_Interest_CC_Q4]
				,X.[Promo_Current_Interest_CC_Q4]
				,X.[RevolvingBalance_CC_Q4]
				,X.[Last Statement Payment Count_CC_Staticpool]
				,X.[Last Statement Payment Amount)_CC_Staticpool]
				,X.[Last Statement Sale Amount_CC_Staticpool]
				,X.[Last Statement Cash Amount_CC_Staticpool]
				,X.[Last Statement Return Amount_CC_Staticpool]
				,X.[Last Statment Sale Count_CC_Staticpool]
				,X.[Last Statement Cash Advance Count_CC_Staticpool]
				,X.[Last Statement Return Count_CC_Staticpool]
				,X.[Last Statement External Fee Amount_CC_Staticpool]
				,X.[Last Statement Credit Life Change Amount_CC_Staticpool]
				,X.[Last Statement Charge Late Amount_CC_Staticpool]
				,X.[Last Statement Charge Cash Amount_CC_Staticpool]
				,X.[Last Statement Charge Overlimit Amount_CC_Staticpool]
				,X.[Last Statement Charge Sale Amount_CC_Staticpool]
				,X.[Last Statement Merchandise Average Daily Balance Amount_CC_Staticpool]
				,X.[Last Statement Cash Average Daily Balance Amount_CC_Staticpool]
				,X.[Last Statement Average Daily Balance Amount_CC_Staticpool]
				,X.[spend_CC_Staticpool]
				,X.[Protected_Balance_CC_Staticpool]
				,X.[Promo_Balance_CC_Staticpool]
				,X.[Protected_Current_Interest_CC_Staticpool]
				,X.[Promo_Current_Interest_CC_Staticpool]
				,X.[RevolvingBalance_CC_Staticpool]
				,X.[Social Security Number_CC]
				,X.[Count_Durable_CC]
				,X.[max_credit_Limit]
				,X.[max_age_member_CC]
				,X.[Max_Extract_ACCOUNT_OPEN_DATE_CC]
				,X.[Max_Closed_account_flag_CC]
				,X.[Max_MOB_CC]
				,X.[ChargeoffAmount_final_CC]
				,X.[Max_chargoff_date_CC]
				,X.[SSN_00]
				,X.[CL_CC_StaticPool]
				,X.[MOB_CC_staticPool]
				,X.[TRIP_FLAG_staticpool]
				,X.[CL_DIFF_past_oneyear]
				,Y.CC_Target_flag
				,Y.Opendate_Creditcard
				,Z.Max_Delinquency
				,Z.Count_Account_Total_loan_ACCT
				,Z.Total_product_Total_loan_ACCT
				,Z.MIn_opendate_Total_loan_ACCT
				,Z.Max_CLOSEDATE_Total_loan_ACCT
				,Z.MAX_MOB__Total_loan_ACCT
				,Z.Max_Month_to_Maturity_Total_loan_ACCT
				,Z.SUM_PAYMENTFREQUENCY_Total_loan_ACCT
				,Z.SUM_PAYMENT_Total_loan_ACCT
				,Z.SUM_PARTIALPAYMENT_Total_loan_ACCT
				,Z.SUM_PAYMENTCOUNT_Total_loan_ACCT
				,Z.Max_DUEDAY1_Total_loan_ACCT
				,Z.SUM_ORIGINALBALANCE_Total_loan_ACCT
				,Z.SUM_CreditLimit_Total_loan_ACCT
				,Z.Max_CreditScore_Total_loan_ACCT
				,Z.MIN_CREDITSCORE_Total_loan_ACCT
				,Z.SUM_ADVANCEAMOUNT_Total_loan_ACCT
				,Z.SSN000
				,Z.COUNT_Total_loan_ACCT
				,Z.Sum_count_loan_addon_Total_loan_ACCT
				,Z.Sum_count_new_loan_Total_loan_ACCT
				,Z.Sum_count_loan_payment_Total_loan_ACCT
				,Z.Sum_count_cash_Total_loan_ACCT
				,Z.Sum_count_draft_Total_loan_ACCT
				,Z.Sum_count_ACH_Total_loan_ACCT
				,Z.Sum_count_FEE_Total_loan_ACCT
				,Z.Sum_count_HOMEBANKING_Total_loan_ACCT
				,Z.Sum_count_INSURANCE_Total_loan_ACCT
				,Z.Sum_count_CHECKS_Total_loan_ACCT
				,Z.Sum_count_KIOSK_Total_loan_ACCT
				,Z.Sum_count_AUDIO_RESPONSE_TELEPHONE_Total_loan_ACCT
				,Z.sum_Transaction_amount_Total_loan_ACCT
				,Z.sum_Interest_amount_Total_loan_ACCT
				,Z.Sum_FEEAMOUNT_Total_loan_ACCT
				,ZZ.Count_Total_Deposit_ACCT
				,ZZ.Count_product_Total_Deposit_ACCT
				,ZZ.MIN_OPENDATE_Total_Deposit_ACCT
				,ZZ.Max_closedate_Total_Deposit_ACCT
				,ZZ.SUM_LASTDIVAMOUNT_Total_Deposit_ACCT
				,ZZ.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT
				,ZZ.SUM_Month_end_balance_Total_Deposit_ACCT
				,ZZ.AVG_Month_end_balance_Total_Deposit_ACCT
				,ZZ.SUM_CHARGEOFFAMOUNT_Total_Deposit_ACCT
				,ZZ.AVG_CHARGEOFFAMOUNT_Total_Deposit_ACCT
				,ZZ.SUM_Closed_flag_Total_Deposit_ACCT
				,ZZ.MAX_MOB_Total_Deposit_ACCT
				,ZZ.SUM_Transaction_COUNT_Total_Deposit_ACCT
				,ZZ.AVG_Transaction_COUNT_Total_Deposit_ACCT
				,ZZ.SUM_Deposited_amount_Total_Deposit_ACCT
				,ZZ.AVG_Deposited_amount_Total_Deposit_ACCT
				,ZZ.SUM_Deposited_count_Total_Deposit_ACCT
				,ZZ.AVG_Deposited_count_Total_Deposit_ACCT
				,ZZ.SUM_withdrawal_amount_Total_Deposit_ACCT
				,ZZ.AVG_withdrawal_amount_Total_Deposit_ACCT
				,ZZ.SUM_withdrawal_count_Total_Deposit_ACCT
				,ZZ.AVG_withdrawal_count_Total_Deposit_ACCT

				,U.Total_No_Account_Checkings
				,U.Total_type_account_Checkings
				,U.opendate_Checkings
				,U.MOB_Checkings
				,U.OPEN_DATE_Checkings
				,U.Closed_date_Checkings
				,U.CHARGEOFFDATE_Checkings
				,U.CHARGEOFFAMOUNT_Checkings
				,U.Diff_Month_end_balance_Checkings_Q1_Q2
				,U.Diff_Month_end_balance_Checkings_Q1_Q4
				,U.Sum_LASTDIVAMOUNT_Checkings_Q1
				,U.Avg_Month_end_balance_Checkings_Q1
				,U.sum_Month_end_balance_Checkings_Q1
				,U.sum_COURTESYPAYMONTHTODATE_checkings_Q1
				,U.sum_NSFMONTHTODATE_checkings_Q1
				,U.sum_OVERDRAFTFEEYTD_checkings_Q1
				,U.sum_FEECOUNT1_checkings_Q1
				
				,U.Sum_transaction_count_checkings_Q1
				,U.Sum_transaction_amount_checkings_Q1
				,U.Avg_transaction_amount_checkings_Q1
				,U.AVG_balancechange_Checkings_Q1
				,U.avg_Deposited_amount_Checkings_Q1
				,U.avg_Deposited_count_Checkings_Q1
				,U.avg_withdrawal_amount_Checkings_Q1
				,U.Avg_withdrawal_count_Checkings_Q1
				,U.Sum_LASTDIVAMOUNT_Checkings_Q2
				,U.Avg_Month_end_balance_Checkings_Q2
				,U.sum_Month_end_balance_Checkings_Q2
				,U.sum_COURTESYPAYMONTHTODATE_checkings_Q2
				,U.sum_NSFMONTHTODATE_checkings_Q2
				,U.sum_OVERDRAFTFEEYTD_checkings_Q2
				,U.sum_FEECOUNT1_checkings_Q2
				
				,U.Sum_transaction_count_checkings_Q2
				,U.Sum_transaction_amount_checkings_Q2
				,U.Avg_transaction_amount_checkings_Q2
				,U.AVG_balancechange_Checkings_Q2
				,U.avg_Deposited_amount_Checkings_Q2
				,U.avg_Deposited_count_Checkings_Q2
				,U.avg_withdrawal_amount_Checkings_Q2
				,U.Avg_withdrawal_count_Checkings_Q2
				,U.Sum_LASTDIVAMOUNT_Checkings_Q3
				,U.Avg_Month_end_balance_Checkings_Q3
				,U.sum_Month_end_balance_Checkings_Q3
				,U.sum_COURTESYPAYMONTHTODATE_checkings_Q3
				,U.sum_NSFMONTHTODATE_checkings_Q3
				,U.sum_OVERDRAFTFEEYTD_checkings_Q3
				,U.sum_FEECOUNT1_checkings_Q3
				
				,U.Sum_transaction_count_checkings_Q3
				,U.Sum_transaction_amount_checkings_Q3
				,U.Avg_transaction_amount_checkings_Q3
				,U.AVG_balancechange_Checkings_Q3
				,U.avg_Deposited_amount_Checkings_Q3
				,U.avg_Deposited_count_Checkings_Q3
				,U.avg_withdrawal_amount_Checkings_Q3
				,U.Avg_withdrawal_count_Checkings_Q3
				,U.Sum_LASTDIVAMOUNT_Checkings_Q4
				,U.Avg_Month_end_balance_Checkings_Q4
				,U.sum_Month_end_balance_Checkings_Q4
				,U.sum_COURTESYPAYMONTHTODATE_checkings_Q4
				,U.sum_NSFMONTHTODATE_checkings_Q4
				,U.sum_OVERDRAFTFEEYTD_checkings_Q4
				,U.sum_FEECOUNT1_checkings_Q4
				
				,U.Sum_transaction_count_checkings_Q4
				,U.Sum_transaction_amount_checkings_Q4
				,U.Avg_transaction_amount_checkings_Q4
				,U.AVG_balancechange_Checkings_Q4
				,U.avg_Deposited_amount_Checkings_Q4
				,U.avg_Deposited_count_Checkings_Q4
				,U.avg_withdrawal_amount_Checkings_Q4
				,U.Avg_withdrawal_count_Checkings_Q4
				,U.Sum_LASTDIVAMOUNT_Checkings_Staticpool
				,U.Avg_Month_end_balance_Checkings_Staticpool
				,U.sum_Month_end_balance_Checkings_Staticpool
				,U.sum_COURTESYPAYMONTHTODATE_checkings_Staticpool
				,U.sum_NSFMONTHTODATE_checkings_Staticpool
				,U.sum_OVERDRAFTFEEYTD_checkings_Staticpool
				,U.sum_FEECOUNT1_checkings_Staticpool
				
				,U.Sum_transaction_count_checkings_Staticpool
				,U.Sum_transaction_amount_checkings_Staticpool
				,U.Avg_transaction_amount_checkings_Staticpool
				,U.AVG_balancechange_Checkings_Staticpool
				,U.avg_Deposited_amount_Checkings_Staticpool
				,U.avg_Deposited_count_Checkings_Staticpool
				,U.avg_withdrawal_amount_Checkings_Staticpool
				,U.Avg_withdrawal_count_Checkings_Staticpool
				,u.Staticpool_Checking_flag

				,T.Total_No_Account_Certificates
				,T.Total_type_account_Certificates
				,T.opendate_Certificates
				,T.MOB_Certificates
				,T.OPEN_DATE_Certificates
				,T.Closed_date_Certificates
				,T.CHARGEOFFDATE_Certificates
				,T.CHARGEOFFAMOUNT_Certificates
				,T.Diff_Month_end_balance_Certificates_Q1_Q2
				,T.Diff_Month_end_balance_Certificates_Q1_Q4
				,T.Sum_LASTDIVAMOUNT_Certificates_Q1
				,T.Avg_Month_end_balance_Certificates_Q1
				,T.sum_Month_end_balance_Certificates_Q1
				,T.sum_COURTESYPAYMONTHTODATE_Certificates_Q1
				,T.sum_NSFMONTHTODATE_Certificates_Q1
				,T.sum_OVERDRAFTFEEYTD_Certificates_Q1
				,T.Sum_transaction_count_Certificates_Q1
				,T.Sum_transaction_amount_Certificates_Q1
				,T.Avg_transaction_amount_Certificates_Q1
				,T.AVG_balancechange_Certificates_Q1
				,T.avg_Deposited_amount_Certificates_Q1
				,T.avg_Deposited_count_Certificates_Q1
				,T.avg_withdrawal_amount_Certificates_Q1
				,T.Avg_withdrawal_count_Certificates_Q1
				,T.Sum_LASTDIVAMOUNT_Certificates_Q2
				,T.Avg_Month_end_balance_Certificates_Q2
				,T.sum_Month_end_balance_Certificates_Q2
				,T.sum_COURTESYPAYMONTHTODATE_Certificates_Q2
				,T.sum_NSFMONTHTODATE_Certificates_Q2
				,T.sum_OVERDRAFTFEEYTD_Certificates_Q2
				,T.Sum_transaction_count_Certificates_Q2
				,T.Sum_transaction_amount_Certificates_Q2
				,T.Avg_transaction_amount_Certificates_Q2
				,T.AVG_balancechange_Certificates_Q2
				,T.avg_Deposited_amount_Certificates_Q2
				,T.avg_Deposited_count_Certificates_Q2
				,T.avg_withdrawal_amount_Certificates_Q2
				,T.Avg_withdrawal_count_Certificates_Q2
				,T.Sum_LASTDIVAMOUNT_Certificates_Q3
				,T.Avg_Month_end_balance_Certificates_Q3
				,T.sum_Month_end_balance_Certificates_Q3
				,T.sum_COURTESYPAYMONTHTODATE_Certificates_Q3
				,T.sum_NSFMONTHTODATE_Certificates_Q3
				,T.sum_OVERDRAFTFEEYTD_Certificates_Q3
				,T.Sum_transaction_count_Certificates_Q3
				,T.Sum_transaction_amount_Certificates_Q3
				,T.Avg_transaction_amount_Certificates_Q3
				,T.AVG_balancechange_Certificates_Q3
				,T.avg_Deposited_amount_Certificates_Q3
				,T.avg_Deposited_count_Certificates_Q3
				,T.avg_withdrawal_amount_Certificates_Q3
				,T.Avg_withdrawal_count_Certificates_Q3
				,T.Sum_LASTDIVAMOUNT_Certificates_Q4
				,T.Avg_Month_end_balance_Certificates_Q4
				,T.sum_Month_end_balance_Certificates_Q4
				,T.sum_COURTESYPAYMONTHTODATE_Certificates_Q4
				,T.sum_NSFMONTHTODATE_Certificates_Q4
				,T.sum_OVERDRAFTFEEYTD_Certificates_Q4
				,T.sum_FEECOUNT1_Certificates_Q4
				
				,T.Sum_transaction_count_Certificates_Q4
				,T.Sum_transaction_amount_Certificates_Q4
				,T.Avg_transaction_amount_Certificates_Q4
				,T.AVG_balancechange_Certificates_Q4
				,T.avg_Deposited_amount_Certificates_Q4
				,T.avg_Deposited_count_Certificates_Q4
				,T.avg_withdrawal_amount_Certificates_Q4
				,T.Avg_withdrawal_count_Certificates_Q4
				,T.Sum_LASTDIVAMOUNT_Certificates_Staticpool
				,T.Avg_Month_end_balance_Certificates_Staticpool
				,T.sum_Month_end_balance_Certificates_Staticpool
				,T.sum_COURTESYPAYMONTHTODATE_Certificates_Staticpool
				,T.sum_NSFMONTHTODATE_Certificates_Staticpool
				,T.sum_OVERDRAFTFEEYTD_Certificates_Staticpool
				,T.sum_FEECOUNT1_Certificates_Staticpool
				
				,T.Sum_transaction_count_Certificates_Staticpool
				,T.Sum_transaction_amount_Certificates_Staticpool
				,T.Avg_transaction_amount_Certificates_Staticpool
				,T.AVG_balancechange_Certificates_Staticpool
				,T.avg_Deposited_amount_Certificates_Staticpool
				,T.avg_Deposited_count_Certificates_Staticpool
				,T.avg_withdrawal_amount_Certificates_Staticpool
				,T.Avg_withdrawal_count_Certificates_Staticpool
				,t.Staticpool_Certificates_flag
				,S.Total_No_Account_Money_Market
				,S.Total_type_account_Money_Market
				,S.opendate_Money_Market
				,S.MOB_Money_Market
				,S.OPEN_DATE_Money_Market
				,S.Closed_date_Money_Market
				,S.CHARGEOFFDATE_Money_Market
				,S.CHARGEOFFAMOUNT_Money_Market
				,S.Diff_Month_end_balance_Money_Market_Q1_Q2
				,S.Diff_Month_end_balance_Money_Market_Q1_Q4
				,S.Sum_LASTDIVAMOUNT_Money_Market_Q1
				,S.Avg_Month_end_balance_Money_Market_Q1
				,S.sum_Month_end_balance_Money_Market_Q1
				,S.Sum_transaction_count_Money_Market_Q1
				,S.Sum_transaction_amount_Money_Market_Q1
				,S.Avg_transaction_amount_Money_Market_Q1
				,S.AVG_balancechange_Money_Market_Q1
				,S.avg_Deposited_amount_Money_Market_Q1
				,S.avg_Deposited_count_Money_Market_Q1
				,S.avg_withdrawal_amount_Money_Market_Q1
				,S.Avg_withdrawal_count_Money_Market_Q1
				,S.Sum_LASTDIVAMOUNT_Money_Market_Q2
				,S.Avg_Month_end_balance_Money_Market_Q2
				,S.sum_Month_end_balance_Money_Market_Q2
				,S.Sum_transaction_count_Money_Market_Q2
				,S.Sum_transaction_amount_Money_Market_Q2
				,S.Avg_transaction_amount_Money_Market_Q2
				,S.AVG_balancechange_Money_Market_Q2
				,S.avg_Deposited_amount_Money_Market_Q2
				,S.avg_Deposited_count_Money_Market_Q2
				,S.avg_withdrawal_amount_Money_Market_Q2
				,S.Avg_withdrawal_count_Money_Market_Q2
				,S.Sum_LASTDIVAMOUNT_Money_Market_Q3
				,S.Avg_Month_end_balance_Money_Market_Q3
				,S.sum_Month_end_balance_Money_Market_Q3
				,S.Sum_transaction_count_Money_Market_Q3
				,S.Sum_transaction_amount_Money_Market_Q3
				,S.Avg_transaction_amount_Money_Market_Q3
				,S.AVG_balancechange_Money_Market_Q3
				,S.avg_Deposited_amount_Money_Market_Q3
				,S.avg_Deposited_count_Money_Market_Q3
				,S.avg_withdrawal_amount_Money_Market_Q3
				,S.Avg_withdrawal_count_Money_Market_Q3
				,S.Sum_LASTDIVAMOUNT_Money_Market_Q4
				,S.Avg_Month_end_balance_Money_Market_Q4
				,S.sum_Month_end_balance_Money_Market_Q4
				,S.Sum_transaction_count_Money_Market_Q4
				,S.Sum_transaction_amount_Money_Market_Q4
				,S.Avg_transaction_amount_Money_Market_Q4
				,S.AVG_balancechange_Money_Market_Q4
				,S.avg_Deposited_amount_Money_Market_Q4
				,S.avg_Deposited_count_Money_Market_Q4
				,S.avg_withdrawal_amount_Money_Market_Q4
				,S.Avg_withdrawal_count_Money_Market_Q4
				,S.Sum_LASTDIVAMOUNT_Money_Market_Staticpool
				,S.Avg_Month_end_balance_Money_Market_Staticpool
				,S.sum_Month_end_balance_Money_Market_Staticpool
				,S.Sum_transaction_count_Money_Market_Staticpool
				,S.Sum_transaction_amount_Money_Market_Staticpool
				,S.Avg_transaction_amount_Money_Market_Staticpool
				,S.AVG_balancechange_Money_Market_Staticpool
				,S.avg_Deposited_amount_Money_Market_Staticpool
				,S.avg_Deposited_count_Money_Market_Staticpool
				,S.avg_withdrawal_amount_Money_Market_Staticpool
				,S.Avg_withdrawal_count_Money_Market_Staticpool
				,s.StaticPool_Money_market_flag
				,R.Total_No_Account_Savings
				,R.Total_type_account_Savings
				,R.opendate_Savings
				,R.MOB_Savings
				,R.OPEN_DATE_Savings
				,R.Closed_date_Savings
				,R.CHARGEOFFDATE_Savings
				,R.CHARGEOFFAMOUNT_Savings
				,R.Diff_Month_end_balance_savings_Q1_Q2
				,R.Diff_Month_end_balance_savings_Q1_Q4
				,R.Sum_LASTDIVAMOUNT_savings_Q1
				,R.Avg_Month_end_balance_savings_Q1
				,R.sum_Month_end_balance_savings_Q1
				,R.AVG_balancechange_savings_Q1
				,R.avg_Deposited_amount_savings_Q1
				,R.avg_Deposited_count_savings_Q1
				,R.avg_withdrawal_amount_savings_Q1
				,R.Avg_withdrawal_count_savings_Q1
				,R.Sum_transaction_count_savings_Q1
				,R.Sum_transaction_amount_savings_Q1
				,R.Avg_transaction_amount_savings_Q1
				,R.Sum_LASTDIVAMOUNT_savings_Q2
				,R.Avg_Month_end_balance_savings_Q2
				,R.sum_Month_end_balance_savings_Q2
				,R.AVG_balancechange_savings_Q2
				,R.avg_Deposited_amount_savings_Q2
				,R.avg_Deposited_count_savings_Q2
				,R.avg_withdrawal_amount_savings_Q2
				,R.Avg_withdrawal_count_savings_Q2
				,R.Sum_transaction_count_savings_Q2
				,R.Sum_transaction_amount_savings_Q2
				,R.Avg_transaction_amount_savings_Q2
				,R.Sum_LASTDIVAMOUNT_savings_Q3
				,R.Avg_Month_end_balance_savings_Q3
				,R.sum_Month_end_balance_savings_Q3
				,R.AVG_balancechange_savings_Q3
				,R.avg_Deposited_amount_savings_Q3
				,R.avg_Deposited_count_savings_Q3
				,R.avg_withdrawal_amount_savings_Q3
				,R.Avg_withdrawal_count_savings_Q3
				,R.Sum_transaction_count_savings_Q3
				,R.Sum_transaction_amount_savings_Q3
				,R.Avg_transaction_amount_savings_Q3
				,R.Sum_LASTDIVAMOUNT_savings_Q4
				,R.Avg_Month_end_balance_savings_Q4
				,R.sum_Month_end_balance_savings_Q4
				,R.AVG_balancechange_savings_Q4
				,R.avg_Deposited_amount_savings_Q4
				,R.avg_Deposited_count_savings_Q4
				,R.avg_withdrawal_amount_savings_Q4
				,R.Avg_withdrawal_count_savings_Q4
				,R.Sum_transaction_count_savings_Q4
				,R.Sum_transaction_amount_savings_Q4
				,R.Avg_transaction_amount_savings_Q4
				,R.Sum_LASTDIVAMOUNT_savings_Staticpool
				,R.Avg_Month_end_balance_savings_Staticpool
				,R.sum_Month_end_balance_savings_Staticpool
				,R.AVG_balancechange_savings_Staticpool
				,R.avg_Deposited_amount_savings_Staticpool
				,R.avg_Deposited_count_savings_Staticpool
				,R.avg_withdrawal_amount_savings_Staticpool
				,R.Avg_withdrawal_count_savings_Staticpool
				,R.Sum_transaction_count_savings_Staticpool
				,R.Sum_transaction_amount_savings_Staticpool
				,R.avg_transaction_amount_savings_Staticpool
				,R.StaticPool_Saving_flag
				,Q.Work_Out_Avg_count_loan_addon
				,Q.Work_Out_Avg_count_New_loan
				,Q.Work_Out_Avg_count_loan_payment
				,Q.Work_Out_Avg_count_CASH
				,Q.Work_Out_Avg_count_DRAFT
				,Q.Work_Out_Avg_count_ACH
				,Q.Work_Out_Avg_count_FEE
				,Q.Work_Out_Avg_count_HOMEBANKING
				,Q.Work_Out_Avg_count_INSURANCE
				,Q.Work_Out_Avg_count_CHECKS
				,Q.Work_Out_Avg_count_PAYROLL
				,Q.Work_Out_Avg_count_KIOSK
				,Q.Work_Out_Avg_count_AUDIO_RESPONSE_TELEPHONE
				,Q.Work_Out_Avg_INTEREST_AMOUNT
				,Q.Work_Out_Avg_FEEAMOUNT
				,Q.Work_Out_Sum_count_loan_addon
				,Q.Work_Out_Sum_count_New_loan
				,Q.Work_Out_Sum_count_loan_payment
				,Q.Work_Out_Sum_count_CASH
				,Q.Work_Out_Sum_count_DRAFT
				,Q.Work_Out_Sum_count_ACH
				,Q.Work_Out_Sum_count_FEE
				,Q.Work_Out_Sum_count_HOMEBANKING
				,Q.Work_Out_Sum_count_INSURANCE
				,Q.Work_Out_Sum_count_CHECKS
				,Q.Work_Out_Sum_count_PAYROLL
				,Q.Work_Out_Sum_count_KIOSK
				,Q.Work_Out_Sum_count_AUDIO_RESPONSE_TELEPHONE
				,Q.Work_Out_SUM_INTEREST_AMOUNT
				,Q.Work_Out_SUM_FEEAMOUNT
				,Q.Work_Out_Avg_Transaction_amount_Q1
				,Q.Work_Out_Avg_NEWBALANCE_Q1
				,Q.Work_Out_avg_Interest_amount_Q1
				,Q.Work_Out_avg_FEEAMOUNT_Q1
				,Q.Work_Out_sum_Transaction_amount_Q1
				,Q.Work_Out_Avg_Transaction_amount_Q2
				,Q.Work_Out_Avg_NEWBALANCE_Q2
				,Q.Work_Out_avg_Interest_amount_Q2
				,Q.Work_Out_avg_FEEAMOUNT_Q2
				,Q.Work_Out_sum_Transaction_amount_Q2
				,Q.Work_Out_Avg_Transaction_amount_Q3
				,Q.Work_Out_Avg_NEWBALANCE_Q3
				,Q.Work_Out_avg_Interest_amount_Q3
				,Q.Work_Out_avg_FEEAMOUNT_Q3
				,Q.Work_Out_sum_Transaction_amount_Q3
				,Q.Work_Out_Avg_Transaction_amount_Q4
				,Q.Work_Out_Avg_NEWBALANCE_Q4
				,Q.Work_Out_avg_Interest_amount_Q4
				,Q.Work_Out_avg_FEEAMOUNT_Q4
				,Q.Work_Out_sum_Transaction_amount_Q4
				
				--,P.Wealth_Management_Avg_count_loan_addon
				--,P.Wealth_Management_Avg_count_New_loan
				--,P.Wealth_Management_Avg_count_loan_payment
				--,P.Wealth_Management_Avg_count_CASH
				--,P.Wealth_Management_Avg_count_DRAFT
				--,P.Wealth_Management_Avg_count_ACH
				--,P.Wealth_Management_Avg_count_FEE
				--,P.Wealth_Management_Avg_count_HOMEBANKING
				--,P.Wealth_Management_Avg_count_INSURANCE
				--,P.Wealth_Management_Avg_count_CHECKS
				--,P.Wealth_Management_Avg_count_PAYROLL
				--,P.Wealth_Management_Avg_count_KIOSK
				--,P.Wealth_Management_Avg_count_AUDIO_RESPONSE_TELEPHONE
				--,P.Wealth_Management_Avg_INTEREST_AMOUNT
				--,P.Wealth_Management_Avg_FEEAMOUNT
				--,P.Wealth_Management_Sum_count_loan_addon
				--,P.Wealth_Management_Sum_count_New_loan
				--,P.Wealth_Management_Sum_count_loan_payment
				--,P.Wealth_Management_Sum_count_CASH
				--,P.Wealth_Management_Sum_count_DRAFT
				--,P.Wealth_Management_Sum_count_ACH
				--,P.Wealth_Management_Sum_count_FEE
				--,P.Wealth_Management_Sum_count_HOMEBANKING
				--,P.Wealth_Management_Sum_count_INSURANCE
				--,P.Wealth_Management_Sum_count_CHECKS
				--,P.Wealth_Management_Sum_count_PAYROLL
				--,P.Wealth_Management_Sum_count_KIOSK
				--,P.Wealth_Management_Sum_count_AUDIO_RESPONSE_TELEPHONE
				--,P.Wealth_Management_SUM_INTEREST_AMOUNT
				--,P.Wealth_Management_SUM_FEEAMOUNT
				--,P.Wealth_Management_Avg_Transaction_amount_Q1
				--,P.Wealth_Management_Avg_NEWBALANCE_Q1
				--,P.Wealth_Management_avg_Interest_amount_Q1
				--,P.Wealth_Management_avg_FEEAMOUNT_Q1
				--,P.Wealth_Management_sum_Transaction_amount_Q1
				--,P.Wealth_Management_Avg_Transaction_amount_Q2
				--,P.Wealth_Management_Avg_NEWBALANCE_Q2
				--,P.Wealth_Management_avg_Interest_amount_Q2
				--,P.Wealth_Management_avg_FEEAMOUNT_Q2
				--,P.Wealth_Management_sum_Transaction_amount_Q2
				--,P.Wealth_Management_Avg_Transaction_amount_Q3
				--,P.Wealth_Management_Avg_NEWBALANCE_Q3
				--,P.Wealth_Management_avg_Interest_amount_Q3
				--,P.Wealth_Management_avg_FEEAMOUNT_Q3
				--,P.Wealth_Management_sum_Transaction_amount_Q3
				--,P.Wealth_Management_Avg_Transaction_amount_Q4
				--,P.Wealth_Management_Avg_NEWBALANCE_Q4
				--,P.Wealth_Management_avg_Interest_amount_Q4
				--,P.Wealth_Management_avg_FEEAMOUNT_Q4
				--,P.Wealth_Management_sum_Transaction_amount_Q4
				,N.Vehicles_Avg_count_loan_addon
				,N.Vehicles_Avg_count_New_loan
				,N.Vehicles_Avg_count_loan_payment
				,N.Vehicles_Avg_count_CASH
				,N.Vehicles_Avg_count_DRAFT
				,N.Vehicles_Avg_count_ACH
				,N.Vehicles_Avg_count_FEE
				,N.Vehicles_Avg_count_HOMEBANKING
				,N.Vehicles_Avg_count_INSURANCE
				,N.Vehicles_Avg_count_CHECKS
				,N.Vehicles_Avg_count_PAYROLL
				,N.Vehicles_Avg_count_KIOSK
				,N.Vehicles_Avg_count_AUDIO_RESPONSE_TELEPHONE
				,N.Vehicles_Avg_INTEREST_AMOUNT
				,N.Vehicles_Avg_FEEAMOUNT
				,N.Vehicles_Sum_count_loan_addon
				,N.Vehicles_Sum_count_New_loan
				,N.Vehicles_Sum_count_loan_payment
				,N.Vehicles_Sum_count_CASH
				,N.Vehicles_Sum_count_DRAFT
				,N.Vehicles_Sum_count_ACH
				,N.Vehicles_Sum_count_FEE
				,N.Vehicles_Sum_count_HOMEBANKING
				,N.Vehicles_Sum_count_INSURANCE
				,N.Vehicles_Sum_count_CHECKS
				,N.Vehicles_Sum_count_PAYROLL
				,N.Vehicles_Sum_count_KIOSK
				,N.Vehicles_Sum_count_AUDIO_RESPONSE_TELEPHONE
				,N.Vehicles_SUM_INTEREST_AMOUNT
				,N.Vehicles_SUM_FEEAMOUNT
				,N.Vehicles_Avg_Transaction_amount_Q1
				,N.Vehicles_Avg_NEWBALANCE_Q1
				,N.Vehicles_avg_Interest_amount_Q1
				,N.Vehicles_avg_FEEAMOUNT_Q1
				,N.Vehicles_sum_Transaction_amount_Q1
				,N.Vehicles_Avg_Transaction_amount_Q2
				,N.Vehicles_Avg_NEWBALANCE_Q2
				,N.Vehicles_avg_Interest_amount_Q2
				,N.Vehicles_avg_FEEAMOUNT_Q2
				,N.Vehicles_sum_Transaction_amount_Q2
				,N.Vehicles_Avg_Transaction_amount_Q3
				,N.Vehicles_Avg_NEWBALANCE_Q3
				,N.Vehicles_avg_Interest_amount_Q3
				,N.Vehicles_avg_FEEAMOUNT_Q3
				,N.Vehicles_sum_Transaction_amount_Q3
				,N.Vehicles_Avg_Transaction_amount_Q4
				,N.Vehicles_Avg_NEWBALANCE_Q4
				,N.Vehicles_avg_Interest_amount_Q4
				,N.Vehicles_avg_FEEAMOUNT_Q4
				,N.Vehicles_sum_Transaction_amount_Q4
				,M.Unsecured_Avg_count_loan_addon
				,M.Unsecured_Avg_count_New_loan
				,M.Unsecured_Avg_count_loan_payment
				,M.Unsecured_Avg_count_CASH
				,M.Unsecured_Avg_count_DRAFT
				,M.Unsecured_Avg_count_ACH
				,M.Unsecured_Avg_count_FEE
				,M.Unsecured_Avg_count_HOMEBANKING
				,M.Unsecured_Avg_count_INSURANCE
				,M.Unsecured_Avg_count_CHECKS
				,M.Unsecured_Avg_count_PAYROLL
				,M.Unsecured_Avg_count_KIOSK
				,M.Unsecured_Avg_count_AUDIO_RESPONSE_TELEPHONE
				,M.Unsecured_Avg_INTEREST_AMOUNT
				,M.Unsecured_Avg_FEEAMOUNT
				,M.Unsecured_Sum_count_loan_addon
				,M.Unsecured_Sum_count_New_loan
				,M.Unsecured_Sum_count_loan_payment
				,M.Unsecured_Sum_count_CASH
				,M.Unsecured_Sum_count_DRAFT
				,M.Unsecured_Sum_count_ACH
				,M.Unsecured_Sum_count_FEE
				,M.Unsecured_Sum_count_HOMEBANKING
				,M.Unsecured_Sum_count_INSURANCE
				,M.Unsecured_Sum_count_CHECKS
				,M.Unsecured_Sum_count_PAYROLL
				,M.Unsecured_Sum_count_KIOSK
				,M.Unsecured_Sum_count_AUDIO_RESPONSE_TELEPHONE
				,M.Unsecured_SUM_INTEREST_AMOUNT
				,M.Unsecured_SUM_FEEAMOUNT
				,M.Unsecured_Avg_Transaction_amount_Q1
				,M.Unsecured_Avg_NEWBALANCE_Q1
				,M.Unsecured_avg_Interest_amount_Q1
				,M.Unsecured_avg_FEEAMOUNT_Q1
				,M.Unsecured_sum_Transaction_amount_Q1
				,M.Unsecured_Avg_Transaction_amount_Q2
				,M.Unsecured_Avg_NEWBALANCE_Q2
				,M.Unsecured_avg_Interest_amount_Q2
				,M.Unsecured_avg_FEEAMOUNT_Q2
				,M.Unsecured_sum_Transaction_amount_Q2
				,M.Unsecured_Avg_Transaction_amount_Q3
				,M.Unsecured_Avg_NEWBALANCE_Q3
				,M.Unsecured_avg_Interest_amount_Q3
				,M.Unsecured_avg_FEEAMOUNT_Q3
				,M.Unsecured_sum_Transaction_amount_Q3
				,M.Unsecured_Avg_Transaction_amount_Q4
				,M.Unsecured_Avg_NEWBALANCE_Q4
				,M.Unsecured_avg_Interest_amount_Q4
				,M.Unsecured_avg_FEEAMOUNT_Q4
				,M.Unsecured_sum_Transaction_amount_Q4
				,L.Secured_Avg_count_loan_addon
				,L.Secured_Avg_count_New_loan
				,L.Secured_Avg_count_loan_payment
				,L.Secured_Avg_count_CASH
				,L.Secured_Avg_count_DRAFT
				,L.Secured_Avg_count_ACH
				,L.Secured_Avg_count_FEE
				,L.Secured_Avg_count_HOMEBANKING
				,L.Secured_Avg_count_INSURANCE
				,L.Secured_Avg_count_CHECKS
				,L.Secured_Avg_count_PAYROLL
				,L.Secured_Avg_count_KIOSK
				,L.Secured_Avg_count_AUDIO_RESPONSE_TELEPHONE
				,L.Secured_Avg_INTEREST_AMOUNT
				,L.Secured_Avg_FEEAMOUNT
				,L.Secured_Sum_count_loan_addon
				,L.Secured_Sum_count_New_loan
				,L.Secured_Sum_count_loan_payment
				,L.Secured_Sum_count_CASH
				,L.Secured_Sum_count_DRAFT
				,L.Secured_Sum_count_ACH
				,L.Secured_Sum_count_FEE
				,L.Secured_Sum_count_HOMEBANKING
				,L.Secured_Sum_count_INSURANCE
				,L.Secured_Sum_count_CHECKS
				,L.Secured_Sum_count_PAYROLL
				,L.Secured_Sum_count_KIOSK
				,L.Secured_Sum_count_AUDIO_RESPONSE_TELEPHONE
				,L.Secured_SUM_INTEREST_AMOUNT
				,L.Secured_SUM_FEEAMOUNT
				,L.Secured_Avg_Transaction_amount_Q1
				,L.Secured_Avg_NEWBALANCE_Q1
				,L.Secured_avg_Interest_amount_Q1
				,L.Secured_avg_FEEAMOUNT_Q1
				,L.Secured_sum_Transaction_amount_Q1
				,L.Secured_Avg_Transaction_amount_Q2
				,L.Secured_Avg_NEWBALANCE_Q2
				,L.Secured_avg_Interest_amount_Q2
				,L.Secured_avg_FEEAMOUNT_Q2
				,L.Secured_sum_Transaction_amount_Q2
				,L.Secured_Avg_Transaction_amount_Q3
				,L.Secured_Avg_NEWBALANCE_Q3
				,L.Secured_avg_Interest_amount_Q3
				,L.Secured_avg_FEEAMOUNT_Q3
				,L.Secured_sum_Transaction_amount_Q3
				,L.Secured_Avg_Transaction_amount_Q4
				,L.Secured_Avg_NEWBALANCE_Q4
				,L.Secured_avg_Interest_amount_Q4
				,L.Secured_avg_FEEAMOUNT_Q4
				,L.Secured_sum_Transaction_amount_Q4

				,K.Real_Estate_Avg_count_loan_addon
				,K.Real_Estate_Avg_count_New_loan
				,K.Real_Estate_Avg_count_loan_payment
				,K.Real_Estate_Avg_count_CASH
				,K.Real_Estate_Avg_count_DRAFT
				,K.Real_Estate_Avg_count_ACH
				,K.Real_Estate_Avg_count_FEE
				,K.Real_Estate_Avg_count_HOMEBANKING
				,K.Real_Estate_Avg_count_INSURANCE
				,K.Real_Estate_Avg_count_CHECKS
				,K.Real_Estate_Avg_count_PAYROLL
				,K.Real_Estate_Avg_count_KIOSK
				,K.Real_Estate_Avg_count_AUDIO_RESPONSE_TELEPHONE
				,K.Real_Estate_Avg_INTEREST_AMOUNT
				,K.Real_Estate_Avg_FEEAMOUNT
				,K.Real_Estate_Sum_count_loan_addon
				,K.Real_Estate_Sum_count_New_loan
				,K.Real_Estate_Sum_count_loan_payment
				,K.Real_Estate_Sum_count_CASH
				,K.Real_Estate_Sum_count_DRAFT
				,K.Real_Estate_Sum_count_ACH
				,K.Real_Estate_Sum_count_FEE
				,K.Real_Estate_Sum_count_HOMEBANKING
				,K.Real_Estate_Sum_count_INSURANCE
				,K.Real_Estate_Sum_count_CHECKS
				,K.Real_Estate_Sum_count_PAYROLL
				,K.Real_Estate_Sum_count_KIOSK
				,K.Real_Estate_Sum_count_AUDIO_RESPONSE_TELEPHONE
				,K.Real_Estate_SUM_INTEREST_AMOUNT
				,K.Real_Estate_SUM_FEEAMOUNT
				,K.Real_Estate_Avg_Transaction_amount_Q1
				,K.Real_Estate_Avg_NEWBALANCE_Q1
				,K.Real_Estate_avg_Interest_amount_Q1
				,K.Real_Estate_avg_FEEAMOUNT_Q1
				,K.Real_Estate_sum_Transaction_amount_Q1
				,K.Real_Estate_Avg_Transaction_amount_Q2
				,K.Real_Estate_Avg_NEWBALANCE_Q2
				,K.Real_Estate_avg_Interest_amount_Q2
				,K.Real_Estate_avg_FEEAMOUNT_Q2
				,K.Real_Estate_sum_Transaction_amount_Q2
				,K.Real_Estate_Avg_Transaction_amount_Q3
				,K.Real_Estate_Avg_NEWBALANCE_Q3
				,K.Real_Estate_avg_Interest_amount_Q3
				,K.Real_Estate_avg_FEEAMOUNT_Q3
				,K.Real_Estate_sum_Transaction_amount_Q3
				,K.Real_Estate_Avg_Transaction_amount_Q4
				,K.Real_Estate_Avg_NEWBALANCE_Q4
				,K.Real_Estate_avg_Interest_amount_Q4
				,K.Real_Estate_avg_FEEAMOUNT_Q4
				,K.Real_Estate_sum_Transaction_amount_Q4

				,KA.Real_Estate2_Avg_count_loan_addon
				,KA.Real_Estate2_Avg_count_New_loan
				,KA.Real_Estate2_Avg_count_loan_payment
				,KA.Real_Estate2_Avg_count_CASH
				,KA.Real_Estate2_Avg_count_DRAFT
				,KA.Real_Estate2_Avg_count_ACH
				,KA.Real_Estate2_Avg_count_FEE
				,KA.Real_Estate2_Avg_count_HOMEBANKING
				,KA.Real_Estate2_Avg_count_INSURANCE
				,KA.Real_Estate2_Avg_count_CHECKS
				,KA.Real_Estate2_Avg_count_PAYROLL
				,KA.Real_Estate2_Avg_count_KIOSK
				,KA.Real_Estate2_Avg_count_AUDIO_RESPONSE_TELEPHONE
				,KA.Real_Estate2_Avg_INTEREST_AMOUNT
				,KA.Real_Estate2_Avg_FEEAMOUNT
				,KA.Real_Estate2_Sum_count_loan_addon
				,KA.Real_Estate2_Sum_count_New_loan
				,KA.Real_Estate2_Sum_count_loan_payment
				,KA.Real_Estate2_Sum_count_CASH
				,KA.Real_Estate2_Sum_count_DRAFT
				,KA.Real_Estate2_Sum_count_ACH
				,KA.Real_Estate2_Sum_count_FEE
				,KA.Real_Estate2_Sum_count_HOMEBANKING
				,KA.Real_Estate2_Sum_count_INSURANCE
				,KA.Real_Estate2_Sum_count_CHECKS
				,KA.Real_Estate2_Sum_count_PAYROLL
				,KA.Real_Estate2_Sum_count_KIOSK
				,KA.Real_Estate2_Sum_count_AUDIO_RESPONSE_TELEPHONE
				,KA.Real_Estate2_SUM_INTEREST_AMOUNT
				,KA.Real_Estate2_SUM_FEEAMOUNT
				,KA.Real_Estate2_Avg_Transaction_amount_Q1
				,KA.Real_Estate2_Avg_NEWBALANCE_Q1
				,KA.Real_Estate2_avg_Interest_amount_Q1
				,KA.Real_Estate2_avg_FEEAMOUNT_Q1
				,KA.Real_Estate2_sum_Transaction_amount_Q1
				,KA.Real_Estate2_Avg_Transaction_amount_Q2
				,KA.Real_Estate2_Avg_NEWBALANCE_Q2
				,KA.Real_Estate2_avg_Interest_amount_Q2
				,KA.Real_Estate2_avg_FEEAMOUNT_Q2
				,KA.Real_Estate2_sum_Transaction_amount_Q2
				,KA.Real_Estate2_Avg_Transaction_amount_Q3
				,KA.Real_Estate2_Avg_NEWBALANCE_Q3
				,KA.Real_Estate2_avg_Interest_amount_Q3
				,KA.Real_Estate2_avg_FEEAMOUNT_Q3
				,KA.Real_Estate2_sum_Transaction_amount_Q3
				,KA.Real_Estate2_Avg_Transaction_amount_Q4
				,KA.Real_Estate2_Avg_NEWBALANCE_Q4
				,KA.Real_Estate2_avg_Interest_amount_Q4
				,KA.Real_Estate2_avg_FEEAMOUNT_Q4
				,KA.Real_Estate2_sum_Transaction_amount_Q4

				--,J.Fresh_Start_Avg_count_loan_addon
				--,J.Fresh_Start_Avg_count_New_loan
				--,J.Fresh_Start_Avg_count_loan_payment
				--,J.Fresh_Start_Avg_count_CASH
				--,J.Fresh_Start_Avg_count_DRAFT
				--,J.Fresh_Start_Avg_count_ACH
				--,J.Fresh_Start_Avg_count_FEE
				--,J.Fresh_Start_Avg_count_HOMEBANKING
				--,J.Fresh_Start_Avg_count_INSURANCE
				--,J.Fresh_Start_Avg_count_CHECKS
				--,J.Fresh_Start_Avg_count_PAYROLL
				--,J.Fresh_Start_Avg_count_KIOSK
				--,J.Fresh_Start_Avg_count_AUDIO_RESPONSE_TELEPHONE
				--,J.Fresh_Start_Avg_INTEREST_AMOUNT
				--,J.Fresh_Start_Avg_FEEAMOUNT
				--,J.Fresh_Start_Sum_count_loan_addon
				--,J.Fresh_Start_Sum_count_New_loan
				--,J.Fresh_Start_Sum_count_loan_payment
				--,J.Fresh_Start_Sum_count_CASH
				--,J.Fresh_Start_Sum_count_DRAFT
				--,J.Fresh_Start_Sum_count_ACH
				--,J.Fresh_Start_Sum_count_FEE
				--,J.Fresh_Start_Sum_count_HOMEBANKING
				--,J.Fresh_Start_Sum_count_INSURANCE
				--,J.Fresh_Start_Sum_count_CHECKS
				--,J.Fresh_Start_Sum_count_PAYROLL
				--,J.Fresh_Start_Sum_count_KIOSK
				--,J.Fresh_Start_Sum_count_AUDIO_RESPONSE_TELEPHONE
				--,J.Fresh_Start_SUM_INTEREST_AMOUNT
				--,J.Fresh_Start_SUM_FEEAMOUNT
				--,J.Fresh_Start_Avg_Transaction_amount_Q1
				--,J.Fresh_Start_Avg_NEWBALANCE_Q1
				--,J.Fresh_Start_avg_Interest_amount_Q1
				--,J.Fresh_Start_avg_FEEAMOUNT_Q1
				--,J.Fresh_Start_sum_Transaction_amount_Q1
				--,J.Fresh_Start_Avg_Transaction_amount_Q2
				--,J.Fresh_Start_Avg_NEWBALANCE_Q2
				--,J.Fresh_Start_avg_Interest_amount_Q2
				--,J.Fresh_Start_avg_FEEAMOUNT_Q2
				--,J.Fresh_Start_sum_Transaction_amount_Q2
				--,J.Fresh_Start_Avg_Transaction_amount_Q3
				--,J.Fresh_Start_Avg_NEWBALANCE_Q3
				--,J.Fresh_Start_avg_Interest_amount_Q3
				--,J.Fresh_Start_avg_FEEAMOUNT_Q3
				--,J.Fresh_Start_sum_Transaction_amount_Q3
				--,J.Fresh_Start_Avg_Transaction_amount_Q4
				--,J.Fresh_Start_Avg_NEWBALANCE_Q4
				--,J.Fresh_Start_avg_Interest_amount_Q4
				--,J.Fresh_Start_avg_FEEAMOUNT_Q4
				--,J.Fresh_Start_sum_Transaction_amount_Q4

				,I.commercial_loan_Avg_count_loan_addon
				,I.commercial_loan_Avg_count_New_loan
				,I.commercial_loan_Avg_count_loan_payment
				,I.commercial_loan_Avg_count_CASH
				,I.commercial_loan_Avg_count_DRAFT
				,I.commercial_loan_Avg_count_ACH
				,I.commercial_loan_Avg_count_FEE
				,I.commercial_loan_Avg_count_HOMEBANKING
				,I.commercial_loan_Avg_count_INSURANCE
				,I.commercial_loan_Avg_count_CHECKS
				,I.commercial_loan_Avg_count_PAYROLL
				,I.commercial_loan_Avg_count_KIOSK
				,I.commercial_loan_Avg_count_AUDIO_RESPONSE_TELEPHONE
				,I.commercial_loan_Avg_INTEREST_AMOUNT
				,I.commercial_loan_Avg_FEEAMOUNT
				,I.commercial_loan_Sum_count_loan_addon
				,I.commercial_loan_Sum_count_New_loan
				,I.commercial_loan_Sum_count_loan_payment
				,I.commercial_loan_Sum_count_CASH
				,I.commercial_loan_Sum_count_DRAFT
				,I.commercial_loan_Sum_count_ACH
				,I.commercial_loan_Sum_count_FEE
				,I.commercial_loan_Sum_count_HOMEBANKING
				,I.commercial_loan_Sum_count_INSURANCE
				,I.commercial_loan_Sum_count_CHECKS
				,I.commercial_loan_Sum_count_PAYROLL
				,I.commercial_loan_Sum_count_KIOSK
				,I.commercial_loan_Sum_count_AUDIO_RESPONSE_TELEPHONE
				,I.commercial_loan_SUM_INTEREST_AMOUNT
				,I.commercial_loan_SUM_FEEAMOUNT
				,I.commercial_loan_Avg_Transaction_amount_Q1
				,I.commercial_loan_Avg_NEWBALANCE_Q1
				,I.commercial_loan_avg_Interest_amount_Q1
				,I.commercial_loan_avg_FEEAMOUNT_Q1
				,I.commercial_loan_sum_Transaction_amount_Q1
				,I.commercial_loan_Avg_Transaction_amount_Q2
				,I.commercial_loan_Avg_NEWBALANCE_Q2
				,I.commercial_loan_avg_Interest_amount_Q2
				,I.commercial_loan_avg_FEEAMOUNT_Q2
				,I.commercial_loan_sum_Transaction_amount_Q2
				,I.commercial_loan_Avg_Transaction_amount_Q3
				,I.commercial_loan_Avg_NEWBALANCE_Q3
				,I.commercial_loan_avg_Interest_amount_Q3
				,I.commercial_loan_avg_FEEAMOUNT_Q3
				,I.commercial_loan_sum_Transaction_amount_Q3
				,I.commercial_loan_Avg_Transaction_amount_Q4
				,I.commercial_loan_Avg_NEWBALANCE_Q4
				,I.commercial_loan_avg_Interest_amount_Q4
				,I.commercial_loan_avg_FEEAMOUNT_Q4
				,I.commercial_loan_sum_Transaction_amount_Q4
				
				,H.Count_of_product_Work_Out
				,H.count_of_type_Work_Out
				,H.min_OPENDATE_Work_Out
				,H.max_CLOSEDATE_Work_Out
				,H.Max_MOB_Work_Out
				,H.Month_to_Maturity_Work_Out
				,H.Max_paymentcount_Work_Out
				,H.max_Dueday1_Work_Out
				,H.max_interestrate_Work_Out
				,H.max_ORIGINALBALANCE_Work_Out
				,H.max_CREDITLIMIT_Work_Out
				,H.max_CREDITSCORE_Work_Out
				,H.CHARGEOFFAMOUNT_Work_Out
				,H.INTERESTRATE_Work_Out
				,H.Sum_PAYMENT_Work_Out
				,H.Sum_ORIGINALBALANCE_Work_Out
				,h.Staticpool_Work_Out_loan_flag
				,h.Max_delinquenty_Work_Out
				--,G.Count_of_product_Wealth_Management
				--,G.count_of_type_Wealth_Management
				--,G.min_OPENDATE_Wealth_Management
				--,G.max_CLOSEDATE_Wealth_Management
				--,G.Max_MOB_Wealth_Management
				--,G.Month_to_Maturity_Wealth_Management
				--,G.Max_paymentcount_Wealth_Management
				--,G.max_Dueday1_Wealth_Management
				--,G.max_interestrate_Wealth_Management
				--,G.max_ORIGINALBALANCE_Wealth_Management
				--,G.max_CREDITLIMIT_Wealth_Management
				--,G.max_CREDITSCORE_Wealth_Management
				--,G.CHARGEOFFAMOUNT_Wealth_Management
				--,G.INTERESTRATE_Wealth_Management
				--,G.Sum_PAYMENT_Wealth_Management
				--,G.Sum_ORIGINALBALANCE_Wealth_Management
				--,g.Staticpool_Wealth_Management_loan_flag
				,F.Count_of_product_Vehicles
				,F.count_of_type_Vehicles
				,F.min_OPENDATE_Vehicles
				,F.max_CLOSEDATE_Vehicles
				,F.Max_MOB_Vehicles
				,F.Month_to_Maturity_Vehicles
				,F.Max_paymentcount_Vehicles
				,F.max_Dueday1_Vehicles
				,F.max_interestrate_Vehicles
				,F.max_ORIGINALBALANCE_Vehicles
				,F.max_CREDITLIMIT_Vehicles
				,F.max_CREDITSCORE_Vehicles
				,F.CHARGEOFFAMOUNT_Vehicles
				,F.INTERESTRATE_Vehicles
				,F.Sum_PAYMENT_Vehicles
				,F.Sum_ORIGINALBALANCE_Vehicles
				,f.Staticpool_Vehicles_loan_flag
				,F.Max_delinquenty_Vehicles
				,E.Count_of_product_Unsecured
				,E.count_of_type_Unsecured
				,E.min_OPENDATE_Unsecured
				,E.max_CLOSEDATE_Unsecured
				,E.Max_MOB_Unsecured
				,E.Month_to_Maturity_Unsecured
				,E.Max_paymentcount_Unsecured
				,E.max_Dueday1_Unsecured
				,E.max_interestrate_Unsecured
				,E.max_ORIGINALBALANCE_Unsecured
				,E.max_CREDITLIMIT_Unsecured
				,E.max_CREDITSCORE_Unsecured
				,E.CHARGEOFFAMOUNT_Unsecured
				,E.INTERESTRATE_Unsecured
				,E.Sum_PAYMENT_Unsecured
				,E.Sum_ORIGINALBALANCE_Unsecured
				,e.Staticpool_Unsecured_loan_flag
				,e.Max_delinquenty_Unsecured

				,D.Count_of_product_Secured
				,D.count_of_type_Secured
				,D.min_OPENDATE_Secured
				,D.max_CLOSEDATE_Secured
				,D.Max_MOB_Secured
				,D.Month_to_Maturity_Secured
				,D.Max_paymentcount_Secured
				,D.max_Dueday1_Secured
				,D.max_interestrate_Secured
				,D.max_ORIGINALBALANCE_Secured
				,D.max_CREDITLIMIT_Secured
				,D.max_CREDITSCORE_Secured
				,D.CHARGEOFFAMOUNT_Secured
				,D.INTERESTRATE_Secured
				,D.Sum_PAYMENT_Secured
				,D.Sum_ORIGINALBALANCE_Secured
				,d.Staticpool_Secured_loan_flag
				,d.Max_delinquenty_Secured
				,C.Count_of_product_Real_Estate
				,C.count_of_type_Real_Estate
				,C.min_OPENDATE_Real_Estate
				,C.max_CLOSEDATE_Real_Estate
				,C.Max_MOB_Real_Estate
				,C.Month_to_Maturity_Real_Estate
				,C.Max_paymentcount_Real_Estate
				,C.max_Dueday1_Real_Estate
				,C.max_interestrate_Real_Estate
				,C.max_ORIGINALBALANCE_Real_Estate
				,C.max_CREDITLIMIT_Real_Estate
				,C.max_CREDITSCORE_Real_Estate
				,C.CHARGEOFFAMOUNT_Real_Estate
				,C.INTERESTRATE_Real_Estate
				,C.Sum_PAYMENT_Real_Estate
				,C.Sum_ORIGINALBALANCE_Real_Estate
				,c.Staticpool_Real_Estate_loan_flag

				,CCC.Count_of_product_real_estate2
				,CCC.count_of_type_real_estate2
				,CCC.min_OPENDATE_real_estate2
				,CCC.max_CLOSEDATE_real_estate2
				,CCC.Max_MOB_real_estate2
				,CCC.Month_to_Maturity_real_estate2
				,CCC.Max_paymentcount_real_estate2
				,CCC.max_Dueday1_real_estate2
				,CCC.max_interestrate_real_estate2
				,CCC.max_ORIGINALBALANCE_real_estate2
				,CCC.max_CREDITLIMIT_real_estate2
				,CCC.max_CREDITSCORE_real_estate2
				,CCC.CHARGEOFFAMOUNT_real_estate2
				,CCC.INTERESTRATE_real_estate2
				,CCC.Sum_PAYMENT_real_estate2
				,CCC.Sum_ORIGINALBALANCE_real_estate2
				,CCC.Staticpool_real_estate2_loan_flag
				,ccc.Max_delinquenty_Real_Estate2
				--,B.Count_of_product_Fresh_Start
				--,B.count_of_type_Fresh_Start
				--,b.Staticpool_Fresh_Start_loan_flag
				,A.Count_of_product_commercial_loan
				,A.count_of_type_commercial_loan
				,a.Staticpool_Commercial_loan_flag
				,a.Max_delinquenty_commercial_loan

				into
				 ##masterdata
				 --analytics.dbo.Master_table_data_V2
				from 
				(SELECT distinct ssn
				
				 FROM #Static_SSN_account_Final ) AA
				LEFT JOIN 
				(

			 select SSN SSN1
			,count(distinct UNID) Count_of_product_commercial_loan
			,count(distinct TYPE) count_of_type_commercial_loan
			,max(Staticpool_Commercial_loan_flag) Staticpool_Commercial_loan_flag
			,min(OPENDATE) min_OPENDATE_commercial_loan,max(CLOSEDATE) max_CLOSEDATE_commercial_loan
			,Max(MOB) Max_MOB_commercial_loan
			,max(Month_to_Maturity) Month_to_Maturity_commercial_loan
			,max(PAYMENTCOUNT) Max_paymentcount_commercial_loan
			,max(DUEDAY1) max_Dueday1_commercial_loan
			,max(ORIGINALBALANCE) max_ORIGINALBALANCE_commercial_loan
			,max(INTERESTRATE) INTERESTRATE_commercial_loan
			,max(CREDITLIMIT) max_CREDITLIMIT_commercial_loan
			,sum(PAYMENT) Sum_PAYMENT_commercial_loan
			,sum(ORIGINALBALANCE) Sum_ORIGINALBALANCE_commercial_loan
			,max(CRPMTCURRENT) Max_delinquenty_commercial_loan
			 from #commercial_loan
			group by SSN ) A
			ON A.SSN1=AA.SSN
			LEFT JOIN
			--(
			-- select SSN SSN2
			--,count(distinct UNID) Count_of_product_Fresh_Start
			--,count(distinct TYPE) count_of_type_Fresh_Start
			--,max(Staticpool_Fresh_Start_loan_flag) Staticpool_Fresh_Start_loan_flag
			--,min(OPENDATE) min_OPENDATE_Fresh_Start,max(CLOSEDATE) Max_CLOSEDATE_Fresh_Start,Max(MOB) Max_MOB_Fresh_Start
			--,max(Month_to_Maturity) Month_to_Maturity_Fresh_Start
			--,max(PAYMENTCOUNT) Max_paymentcount_Fresh_Start
			--,max(DUEDAY1) max_Dueday1_Fresh_Start
			--,max(ORIGINALBALANCE) max_ORIGINALBALANCE_Fresh_Start
			--,max(CHARGEOFFAMOUNT) CHARGEOFFAMOUNT_Fresh_Start
			--,max(INTERESTRATE) INTERESTRATE_Fresh_Start
			--,sum(PAYMENT) Sum_PAYMENT_Fresh_Start
			--,sum(ORIGINALBALANCE) Sum_ORIGINALBALANCE_Fresh_Start
			-- from #Fresh_Start
			-- group by SSN ) B
			--ON B.SSN2=AA.SSN
			--LEFT JOIN
			(
			 select SSN SSN3
			,count(distinct UNID) Count_of_product_Real_Estate
			,count(distinct TYPE) count_of_type_Real_Estate
			,max(Staticpool_Real_Estate_loan_flag) Staticpool_Real_Estate_loan_flag
			,min(OPENDATE) min_OPENDATE_Real_Estate,max(CLOSEDATE) max_CLOSEDATE_Real_Estate,Max(MOB) Max_MOB_Real_Estate
			,max(Month_to_Maturity) Month_to_Maturity_Real_Estate
			,max(PAYMENTCOUNT) Max_paymentcount_Real_Estate
			,max(DUEDAY1) max_Dueday1_Real_Estate
			,max([INTERESTRATE]) max_interestrate_Real_Estate
			,max(ORIGINALBALANCE) max_ORIGINALBALANCE_Real_Estate
			,max(CREDITLIMIT) max_CREDITLIMIT_Real_Estate
			,max(CREDITSCORE) max_CREDITSCORE_Real_Estate
			,max(CHARGEOFFAMOUNT) CHARGEOFFAMOUNT_Real_Estate
			,max(INTERESTRATE) INTERESTRATE_Real_Estate
			,sum(PAYMENT) Sum_PAYMENT_Real_Estate
			,sum(ORIGINALBALANCE) Sum_ORIGINALBALANCE_Real_Estate
			from #Real_Estate
			group by SSN
			 ) C
			ON C.SSN3=AA.SSN
			left join
			(
			 select SSN SSN33
			,count(distinct UNID) Count_of_product_Real_Estate2
			,count(distinct TYPE) count_of_type_Real_Estate2
			,max(Staticpool_Real_Estate2_loan_flag) Staticpool_Real_Estate2_loan_flag
			,min(OPENDATE) min_OPENDATE_Real_Estate2,max(CLOSEDATE) max_CLOSEDATE_Real_Estate2,Max(MOB) Max_MOB_Real_Estate2
			,max(Month_to_Maturity) Month_to_Maturity_Real_Estate2
			,max(PAYMENTCOUNT) Max_paymentcount_Real_Estate2
			,max(DUEDAY1) max_Dueday1_Real_Estate2
			,max([INTERESTRATE]) max_interestrate_Real_Estate2
			,max(ORIGINALBALANCE) max_ORIGINALBALANCE_Real_Estate2
			,max(CREDITLIMIT) max_CREDITLIMIT_Real_Estate2
			,max(CREDITSCORE) max_CREDITSCORE_Real_Estate2
			,max(CHARGEOFFAMOUNT) CHARGEOFFAMOUNT_Real_Estate2
			,max(INTERESTRATE) INTERESTRATE_Real_Estate2
			,sum(PAYMENT) Sum_PAYMENT_Real_Estate2
			,sum(ORIGINALBALANCE) Sum_ORIGINALBALANCE_Real_Estate2
			,max(CRPMTCURRENT) Max_delinquenty_Real_Estate2
			from #Real_Estate2
			group by SSN
			 ) CCC
			ON CCC.SSN33=AA.SSN

			LEFT JOIN
			(

			 select SSN SSN4
			,count(distinct UNID) Count_of_product_Secured
			,count(distinct TYPE) count_of_type_Secured
			,max(Staticpool_Secured_loan_flag) Staticpool_Secured_loan_flag
			,min(OPENDATE) min_OPENDATE_Secured,max(CLOSEDATE) Max_CLOSEDATE_Secured,Max(MOB) Max_MOB_Secured
			,max(Month_to_Maturity) Month_to_Maturity_Secured
			,max(PAYMENTCOUNT) Max_paymentcount_Secured
			,max(DUEDAY1) max_Dueday1_Secured
			,max([INTERESTRATE]) max_interestrate_Secured
			,max(ORIGINALBALANCE) max_ORIGINALBALANCE_Secured
			,max(CREDITLIMIT) max_CREDITLIMIT_Secured
			,max(CREDITSCORE) max_CREDITSCORE_Secured
			,max(CHARGEOFFAMOUNT) CHARGEOFFAMOUNT_Secured
			,max(INTERESTRATE) INTERESTRATE_Secured
			,sum(PAYMENT) Sum_PAYMENT_Secured
			,sum(ORIGINALBALANCE) Sum_ORIGINALBALANCE_Secured
			,max(CRPMTCURRENT) Max_delinquenty_Secured
			from #Secured
			group by SSN
			 ) D
			ON D.SSN4=AA.SSN
			LEFT JOIN
			(
			 select SSN SSN5
			,count(distinct UNID) Count_of_product_Unsecured
			,count(distinct TYPE) count_of_type_Unsecured
			,max(Staticpool_Unsecured_loan_flag) Staticpool_Unsecured_loan_flag
			,min(OPENDATE) Min_OPENDATE_Unsecured,max(CLOSEDATE) Max_CLOSEDATE_Unsecured,Max(MOB) Max_MOB_Unsecured
			,max(Month_to_Maturity) Month_to_Maturity_Unsecured
			,max(PAYMENTCOUNT) Max_paymentcount_Unsecured
			,max(DUEDAY1) max_Dueday1_Unsecured
			,max([INTERESTRATE]) max_interestrate_Unsecured
			,max(ORIGINALBALANCE) max_ORIGINALBALANCE_Unsecured
			,max(CREDITLIMIT) max_CREDITLIMIT_Unsecured
			,max(CREDITSCORE) max_CREDITSCORE_Unsecured
			,max(CHARGEOFFAMOUNT) CHARGEOFFAMOUNT_Unsecured
			,max(INTERESTRATE) INTERESTRATE_Unsecured
			,sum(PAYMENT) Sum_PAYMENT_Unsecured
			,sum(ORIGINALBALANCE) Sum_ORIGINALBALANCE_Unsecured
			,max(CRPMTCURRENT) Max_delinquenty_Unsecured
			from #Unsecured
			group by SSN
			 ) E
			ON E.SSN5=AA.SSN
			LEFT JOIN
			(
			 select SSN SSN6
			,count(distinct UNID) Count_of_product_Vehicles
			,count(distinct TYPE) count_of_type_Vehicles
			,max(Staticpool_Vehicles_loan_flag) Staticpool_Vehicles_loan_flag
			,min(OPENDATE) min_OPENDATE_Vehicles,max(CLOSEDATE) max_CLOSEDATE_Vehicles,Max(MOB) Max_MOB_Vehicles
			,max(Month_to_Maturity) Month_to_Maturity_Vehicles
			,max(PAYMENTCOUNT) Max_paymentcount_Vehicles
			,max(DUEDAY1) max_Dueday1_Vehicles
			,max([INTERESTRATE]) max_interestrate_Vehicles
			,max(ORIGINALBALANCE) max_ORIGINALBALANCE_Vehicles
			,max(CREDITLIMIT) max_CREDITLIMIT_Vehicles
			,max(CREDITSCORE) max_CREDITSCORE_Vehicles
			,max(CHARGEOFFAMOUNT) CHARGEOFFAMOUNT_Vehicles
			,max(INTERESTRATE) INTERESTRATE_Vehicles
			,sum(PAYMENT) Sum_PAYMENT_Vehicles
			,sum(ORIGINALBALANCE) Sum_ORIGINALBALANCE_Vehicles
			,max(CRPMTCURRENT) Max_delinquenty_Vehicles
			from #Vehicles
			group by SSN
			 ) F
			ON F.SSN6=AA.SSN
			LEFT JOIN
			--(
			-- select SSN SSN7
			--,count(distinct UNID) Count_of_product_Wealth_Management
			--,count(distinct TYPE) count_of_type_Wealth_Management
			--,max(Staticpool_Wealth_Management_loan_flag) Staticpool_Wealth_Management_loan_flag
			--,min(OPENDATE) min_OPENDATE_Wealth_Management,max(CLOSEDATE) max_CLOSEDATE_Wealth_Management,Max(MOB) Max_MOB_Wealth_Management
			--,max(Month_to_Maturity) Month_to_Maturity_Wealth_Management
			--,max(PAYMENTCOUNT) Max_paymentcount_Wealth_Management
			--,max(DUEDAY1) max_Dueday1_Wealth_Management
			--,max([INTERESTRATE]) max_interestrate_Wealth_Management
			--,max(ORIGINALBALANCE) max_ORIGINALBALANCE_Wealth_Management
			--,max(CREDITLIMIT) max_CREDITLIMIT_Wealth_Management
			--,max(CREDITSCORE) max_CREDITSCORE_Wealth_Management
			--,max(CHARGEOFFAMOUNT) CHARGEOFFAMOUNT_Wealth_Management
			--,max(INTERESTRATE) INTERESTRATE_Wealth_Management
			--,sum(PAYMENT) Sum_PAYMENT_Wealth_Management
			--,sum(ORIGINALBALANCE) Sum_ORIGINALBALANCE_Wealth_Management
			--from #Wealth_Management
			--group by SSN ) G
			--ON G.SSN7=AA.SSN
			--LEFT JOIN
			(	
			 select SSN SSN8
			,count(distinct UNID) Count_of_product_Work_Out
			,count(distinct TYPE) count_of_type_Work_Out
			,max(Staticpool_Work_Out_loan_flag) Staticpool_Work_Out_loan_flag
			,min(OPENDATE) min_OPENDATE_Work_Out,max(CLOSEDATE) max_CLOSEDATE_Work_Out,Max(MOB) Max_MOB_Work_Out
			,max(Month_to_Maturity) Month_to_Maturity_Work_Out
			,max(PAYMENTCOUNT) Max_paymentcount_Work_Out
			,max(DUEDAY1) max_Dueday1_Work_Out
			,max([INTERESTRATE]) max_interestrate_Work_Out
			,max(ORIGINALBALANCE) max_ORIGINALBALANCE_Work_Out
			,max(CREDITLIMIT) max_CREDITLIMIT_Work_Out
			,max(CREDITSCORE) max_CREDITSCORE_Work_Out
			,max(CHARGEOFFAMOUNT) CHARGEOFFAMOUNT_Work_Out
			,max(INTERESTRATE) INTERESTRATE_Work_Out
			,sum(PAYMENT) Sum_PAYMENT_Work_Out
			,sum(ORIGINALBALANCE) Sum_ORIGINALBALANCE_Work_Out
			,max(CRPMTCURRENT) Max_delinquenty_Work_Out
			from #Work_Out
			group by SSN 
			) H
			ON AA.SSN=H.SSN8
			

			--------//////////******* merging loan Transaction data**************\\\\\\\\\\\\\\\\\--------------------
			--Commercial
				--Fresh Start
				--Real Estate
				--Secured
				--Unsecured
				--Vehicles
				--Wealth Management
				--Work Out
						
						left join 
						(	select 
						SSN SSN9
						,Avg(Sum_count_loan_addon) commercial_loan_Avg_count_loan_addon
						,Avg(Sum_count_New_loan) commercial_loan_Avg_count_New_loan
						,Avg(Sum_count_loan_payment) commercial_loan_Avg_count_loan_payment
						,Avg(Sum_count_CASH) commercial_loan_Avg_count_CASH
						,Avg(Sum_count_DRAFT) commercial_loan_Avg_count_DRAFT
						,Avg(Sum_count_ACH) commercial_loan_Avg_count_ACH
						,Avg(Sum_count_FEE) commercial_loan_Avg_count_FEE
						,Avg(Sum_count_HOMEBANKING) commercial_loan_Avg_count_HOMEBANKING
						,Avg(Sum_count_INSURANCE) commercial_loan_Avg_count_INSURANCE
						,Avg(Sum_count_CHECKS) commercial_loan_Avg_count_CHECKS
						,Avg(Sum_count_PAYROLL) commercial_loan_Avg_count_PAYROLL
						,Avg(Sum_count_KIOSK) commercial_loan_Avg_count_KIOSK
						,Avg(Sum_count_AUDIO_RESPONSE_TELEPHONE) commercial_loan_Avg_count_AUDIO_RESPONSE_TELEPHONE
						,Avg(SUM_INTEREST_AMOUNT) commercial_loan_Avg_INTEREST_AMOUNT
						,Avg(SUM_FEEAMOUNT) commercial_loan_Avg_FEEAMOUNT

						,Sum(Sum_count_loan_addon) commercial_loan_Sum_count_loan_addon
						,Sum(Sum_count_New_loan) commercial_loan_Sum_count_New_loan
						,Sum(Sum_count_loan_payment) commercial_loan_Sum_count_loan_payment
						,Sum(Sum_count_CASH) commercial_loan_Sum_count_CASH
						,Sum(Sum_count_DRAFT) commercial_loan_Sum_count_DRAFT
						,Sum(Sum_count_ACH) commercial_loan_Sum_count_ACH
						,Sum(Sum_count_FEE) commercial_loan_Sum_count_FEE
						,Sum(Sum_count_HOMEBANKING) commercial_loan_Sum_count_HOMEBANKING
						,Sum(Sum_count_INSURANCE) commercial_loan_Sum_count_INSURANCE
						,Sum(Sum_count_CHECKS) commercial_loan_Sum_count_CHECKS
						,Sum(Sum_count_PAYROLL) commercial_loan_Sum_count_PAYROLL
						,Sum(Sum_count_KIOSK) commercial_loan_Sum_count_KIOSK
						,Sum(Sum_count_AUDIO_RESPONSE_TELEPHONE) commercial_loan_Sum_count_AUDIO_RESPONSE_TELEPHONE
						,Sum(SUM_INTEREST_AMOUNT) commercial_loan_SUM_INTEREST_AMOUNT
						,Sum(SUM_FEEAMOUNT) commercial_loan_SUM_FEEAMOUNT
						,Avg(Avg_Transaction_amount_Q1) commercial_loan_Avg_Transaction_amount_Q1
						,Avg(Avg_NEWBALANCE_Q1) commercial_loan_Avg_NEWBALANCE_Q1
						,Avg(avg_Interest_amount_Q1) commercial_loan_avg_Interest_amount_Q1
						,Avg(avg_FEEAMOUNT_Q1) commercial_loan_avg_FEEAMOUNT_Q1
						,Sum(sum_Transaction_amount_Q1) commercial_loan_sum_Transaction_amount_Q1
						,Avg(Avg_Transaction_amount_Q2) commercial_loan_Avg_Transaction_amount_Q2
						,Avg(Avg_NEWBALANCE_Q2) commercial_loan_Avg_NEWBALANCE_Q2
						,Avg(avg_Interest_amount_Q2) commercial_loan_avg_Interest_amount_Q2
						,Avg(avg_FEEAMOUNT_Q2) commercial_loan_avg_FEEAMOUNT_Q2
						,Sum(sum_Transaction_amount_Q2) commercial_loan_sum_Transaction_amount_Q2
						,Avg(Avg_Transaction_amount_Q3) commercial_loan_Avg_Transaction_amount_Q3
						,Avg(Avg_NEWBALANCE_Q3) commercial_loan_Avg_NEWBALANCE_Q3
						,Avg(avg_Interest_amount_Q3) commercial_loan_avg_Interest_amount_Q3
						,Avg(avg_FEEAMOUNT_Q3) commercial_loan_avg_FEEAMOUNT_Q3
						,Sum(sum_Transaction_amount_Q3) commercial_loan_sum_Transaction_amount_Q3
						,Avg(Avg_Transaction_amount_Q4) commercial_loan_Avg_Transaction_amount_Q4
						,Avg(Avg_NEWBALANCE_Q4) commercial_loan_Avg_NEWBALANCE_Q4
						,Avg(avg_Interest_amount_Q4) commercial_loan_avg_Interest_amount_Q4
						,Avg(avg_FEEAMOUNT_Q4) commercial_loan_avg_FEEAMOUNT_Q4
						,Sum(sum_Transaction_amount_Q4) commercial_loan_sum_Transaction_amount_Q4
					
					from #commercial_loan aaa
			
			inner join
			 (select	UNID
					,Sum_count_loan_addon
					,Sum_count_New_loan
					,Sum_count_loan_payment
					,Sum_count_CASH
					,Sum_count_DRAFT
					,Sum_count_ACH
					,Sum_count_FEE
					,Sum_count_HOMEBANKING
					,Sum_count_INSURANCE
					,Sum_count_CHECKS
					,Sum_count_PAYROLL
					,Sum_count_KIOSK
					,Sum_count_AUDIO_RESPONSE_TELEPHONE
					,SUM_INTEREST_AMOUNT
					,SUM_FEEAMOUNT
					,Avg_Transaction_amount_Q1
				,Avg_NEWBALANCE_Q1
				,avg_Interest_amount_Q1
				,avg_FEEAMOUNT_Q1
				,sum_Transaction_amount_Q1
				,Avg_Transaction_amount_Q2
				,Avg_NEWBALANCE_Q2
				,avg_Interest_amount_Q2
				,avg_FEEAMOUNT_Q2
				,sum_Transaction_amount_Q2
				,Avg_Transaction_amount_Q3
				,Avg_NEWBALANCE_Q3
				,avg_Interest_amount_Q3
				,avg_FEEAMOUNT_Q3
				,sum_Transaction_amount_Q3
				,Avg_Transaction_amount_Q4
				,Avg_NEWBALANCE_Q4
				,avg_Interest_amount_Q4
				,avg_FEEAMOUNT_Q4
				,sum_Transaction_amount_Q4
				from #loan_transaction_data_0
				
				  ) a
				 on aaa.UNID=a.UNID
				 Group by ssn ) I
				 ON AA.SSN=I.SSN9
				 left join 
				 --(
				 --select 
					--	SSN SSN10
					--	,Avg(Sum_count_loan_addon) Fresh_Start_Avg_count_loan_addon
					--	,Avg(Sum_count_New_loan) Fresh_Start_Avg_count_New_loan
					--	,Avg(Sum_count_loan_payment) Fresh_Start_Avg_count_loan_payment
					--	,Avg(Sum_count_CASH) Fresh_Start_Avg_count_CASH
					--	,Avg(Sum_count_DRAFT) Fresh_Start_Avg_count_DRAFT
					--	,Avg(Sum_count_ACH) Fresh_Start_Avg_count_ACH
					--	,Avg(Sum_count_FEE) Fresh_Start_Avg_count_FEE
					--	,Avg(Sum_count_HOMEBANKING) Fresh_Start_Avg_count_HOMEBANKING
					--	,Avg(Sum_count_INSURANCE) Fresh_Start_Avg_count_INSURANCE
					--	,Avg(Sum_count_CHECKS) Fresh_Start_Avg_count_CHECKS
					--	,Avg(Sum_count_PAYROLL) Fresh_Start_Avg_count_PAYROLL
					--	,Avg(Sum_count_KIOSK) Fresh_Start_Avg_count_KIOSK
					--	,Avg(Sum_count_AUDIO_RESPONSE_TELEPHONE) Fresh_Start_Avg_count_AUDIO_RESPONSE_TELEPHONE
					--	,Avg(SUM_INTEREST_AMOUNT) Fresh_Start_Avg_INTEREST_AMOUNT
					--	,Avg(SUM_FEEAMOUNT) Fresh_Start_Avg_FEEAMOUNT

					--	,Sum(Sum_count_loan_addon) Fresh_Start_Sum_count_loan_addon
					--	,Sum(Sum_count_New_loan) Fresh_Start_Sum_count_New_loan
					--	,Sum(Sum_count_loan_payment) Fresh_Start_Sum_count_loan_payment
					--	,Sum(Sum_count_CASH) Fresh_Start_Sum_count_CASH
					--	,Sum(Sum_count_DRAFT) Fresh_Start_Sum_count_DRAFT
					--	,Sum(Sum_count_ACH) Fresh_Start_Sum_count_ACH
					--	,Sum(Sum_count_FEE) Fresh_Start_Sum_count_FEE
					--	,Sum(Sum_count_HOMEBANKING) Fresh_Start_Sum_count_HOMEBANKING
					--	,Sum(Sum_count_INSURANCE) Fresh_Start_Sum_count_INSURANCE
					--	,Sum(Sum_count_CHECKS) Fresh_Start_Sum_count_CHECKS
					--	,Sum(Sum_count_PAYROLL) Fresh_Start_Sum_count_PAYROLL
					--	,Sum(Sum_count_KIOSK) Fresh_Start_Sum_count_KIOSK
					--	,Sum(Sum_count_AUDIO_RESPONSE_TELEPHONE) Fresh_Start_Sum_count_AUDIO_RESPONSE_TELEPHONE
					--	,Sum(SUM_INTEREST_AMOUNT) Fresh_Start_SUM_INTEREST_AMOUNT
					--	,Sum(SUM_FEEAMOUNT) Fresh_Start_SUM_FEEAMOUNT
					--	,Avg(Avg_Transaction_amount_Q1) Fresh_Start_Avg_Transaction_amount_Q1
					--	,Avg(Avg_NEWBALANCE_Q1) Fresh_Start_Avg_NEWBALANCE_Q1
					--	,Avg(avg_Interest_amount_Q1) Fresh_Start_avg_Interest_amount_Q1
					--	,Avg(avg_FEEAMOUNT_Q1) Fresh_Start_avg_FEEAMOUNT_Q1
					--	,Sum(sum_Transaction_amount_Q1) Fresh_Start_sum_Transaction_amount_Q1
					--	,Avg(Avg_Transaction_amount_Q2) Fresh_Start_Avg_Transaction_amount_Q2
					--	,Avg(Avg_NEWBALANCE_Q2) Fresh_Start_Avg_NEWBALANCE_Q2
					--	,Avg(avg_Interest_amount_Q2) Fresh_Start_avg_Interest_amount_Q2
					--	,Avg(avg_FEEAMOUNT_Q2) Fresh_Start_avg_FEEAMOUNT_Q2
					--	,Sum(sum_Transaction_amount_Q2) Fresh_Start_sum_Transaction_amount_Q2
					--	,Avg(Avg_Transaction_amount_Q3) Fresh_Start_Avg_Transaction_amount_Q3
					--	,Avg(Avg_NEWBALANCE_Q3) Fresh_Start_Avg_NEWBALANCE_Q3
					--	,Avg(avg_Interest_amount_Q3) Fresh_Start_avg_Interest_amount_Q3
					--	,Avg(avg_FEEAMOUNT_Q3) Fresh_Start_avg_FEEAMOUNT_Q3
					--	,Sum(sum_Transaction_amount_Q3) Fresh_Start_sum_Transaction_amount_Q3
					--	,Avg(Avg_Transaction_amount_Q4) Fresh_Start_Avg_Transaction_amount_Q4
					--	,Avg(Avg_NEWBALANCE_Q4) Fresh_Start_Avg_NEWBALANCE_Q4
					--	,Avg(avg_Interest_amount_Q4) Fresh_Start_avg_Interest_amount_Q4
					--	,Avg(avg_FEEAMOUNT_Q4) Fresh_Start_avg_FEEAMOUNT_Q4
					--	,Sum(sum_Transaction_amount_Q4) Fresh_Start_sum_Transaction_amount_Q4
					
					--from #Fresh_Start aaa
			
			--inner join
			-- (select	UNID
			--		,Sum_count_loan_addon
			--		,Sum_count_New_loan
			--		,Sum_count_loan_payment
			--		,Sum_count_CASH
			--		,Sum_count_DRAFT
			--		,Sum_count_ACH
			--		,Sum_count_FEE
			--		,Sum_count_HOMEBANKING
			--		,Sum_count_INSURANCE
			--		,Sum_count_CHECKS
			--		,Sum_count_PAYROLL
			--		,Sum_count_KIOSK
			--		,Sum_count_AUDIO_RESPONSE_TELEPHONE
			--		,SUM_INTEREST_AMOUNT
			--		,SUM_FEEAMOUNT
			--		,Avg_Transaction_amount_Q1
			--	,Avg_NEWBALANCE_Q1
			--	,avg_Interest_amount_Q1
			--	,avg_FEEAMOUNT_Q1
			--	,sum_Transaction_amount_Q1
			--	,Avg_Transaction_amount_Q2
			--	,Avg_NEWBALANCE_Q2
			--	,avg_Interest_amount_Q2
			--	,avg_FEEAMOUNT_Q2
			--	,sum_Transaction_amount_Q2
			--	,Avg_Transaction_amount_Q3
			--	,Avg_NEWBALANCE_Q3
			--	,avg_Interest_amount_Q3
			--	,avg_FEEAMOUNT_Q3
			--	,sum_Transaction_amount_Q3
			--	,Avg_Transaction_amount_Q4
			--	,Avg_NEWBALANCE_Q4
			--	,avg_Interest_amount_Q4
			--	,avg_FEEAMOUNT_Q4
			--	,sum_Transaction_amount_Q4
			--	from #loan_transaction_data_0
				
			--	  ) a
			--	 on aaa.UNID=a.UNID
			--	 Group by ssn ) J
			--	 ON AA.SSN=J.SSN10
				
			--	left join
				
				(
				select 
						SSN SSN11
						,Avg(Sum_count_loan_addon) Real_Estate_Avg_count_loan_addon
						,Avg(Sum_count_New_loan) Real_Estate_Avg_count_New_loan
						,Avg(Sum_count_loan_payment) Real_Estate_Avg_count_loan_payment
						,Avg(Sum_count_CASH) Real_Estate_Avg_count_CASH
						,Avg(Sum_count_DRAFT) Real_Estate_Avg_count_DRAFT
						,Avg(Sum_count_ACH) Real_Estate_Avg_count_ACH
						,Avg(Sum_count_FEE) Real_Estate_Avg_count_FEE
						,Avg(Sum_count_HOMEBANKING) Real_Estate_Avg_count_HOMEBANKING
						,Avg(Sum_count_INSURANCE) Real_Estate_Avg_count_INSURANCE
						,Avg(Sum_count_CHECKS) Real_Estate_Avg_count_CHECKS
						,Avg(Sum_count_PAYROLL) Real_Estate_Avg_count_PAYROLL
						,Avg(Sum_count_KIOSK) Real_Estate_Avg_count_KIOSK
						,Avg(Sum_count_AUDIO_RESPONSE_TELEPHONE) Real_Estate_Avg_count_AUDIO_RESPONSE_TELEPHONE
						,Avg(SUM_INTEREST_AMOUNT) Real_Estate_Avg_INTEREST_AMOUNT
						,Avg(SUM_FEEAMOUNT) Real_Estate_Avg_FEEAMOUNT

						,Sum(Sum_count_loan_addon) Real_Estate_Sum_count_loan_addon
						,Sum(Sum_count_New_loan) Real_Estate_Sum_count_New_loan
						,Sum(Sum_count_loan_payment) Real_Estate_Sum_count_loan_payment
						,Sum(Sum_count_CASH) Real_Estate_Sum_count_CASH
						,Sum(Sum_count_DRAFT) Real_Estate_Sum_count_DRAFT
						,Sum(Sum_count_ACH) Real_Estate_Sum_count_ACH
						,Sum(Sum_count_FEE) Real_Estate_Sum_count_FEE
						,Sum(Sum_count_HOMEBANKING) Real_Estate_Sum_count_HOMEBANKING
						,Sum(Sum_count_INSURANCE) Real_Estate_Sum_count_INSURANCE
						,Sum(Sum_count_CHECKS) Real_Estate_Sum_count_CHECKS
						,Sum(Sum_count_PAYROLL) Real_Estate_Sum_count_PAYROLL
						,Sum(Sum_count_KIOSK) Real_Estate_Sum_count_KIOSK
						,Sum(Sum_count_AUDIO_RESPONSE_TELEPHONE) Real_Estate_Sum_count_AUDIO_RESPONSE_TELEPHONE
						,Sum(SUM_INTEREST_AMOUNT) Real_Estate_SUM_INTEREST_AMOUNT
						,Sum(SUM_FEEAMOUNT) Real_Estate_SUM_FEEAMOUNT
						,Avg(Avg_Transaction_amount_Q1) Real_Estate_Avg_Transaction_amount_Q1
						,Avg(Avg_NEWBALANCE_Q1) Real_Estate_Avg_NEWBALANCE_Q1
						,Avg(avg_Interest_amount_Q1) Real_Estate_avg_Interest_amount_Q1
						,Avg(avg_FEEAMOUNT_Q1) Real_Estate_avg_FEEAMOUNT_Q1
						,Sum(sum_Transaction_amount_Q1) Real_Estate_sum_Transaction_amount_Q1
						,Avg(Avg_Transaction_amount_Q2) Real_Estate_Avg_Transaction_amount_Q2
						,Avg(Avg_NEWBALANCE_Q2) Real_Estate_Avg_NEWBALANCE_Q2
						,Avg(avg_Interest_amount_Q2) Real_Estate_avg_Interest_amount_Q2
						,Avg(avg_FEEAMOUNT_Q2) Real_Estate_avg_FEEAMOUNT_Q2
						,Sum(sum_Transaction_amount_Q2) Real_Estate_sum_Transaction_amount_Q2
						,Avg(Avg_Transaction_amount_Q3) Real_Estate_Avg_Transaction_amount_Q3
						,Avg(Avg_NEWBALANCE_Q3) Real_Estate_Avg_NEWBALANCE_Q3
						,Avg(avg_Interest_amount_Q3) Real_Estate_avg_Interest_amount_Q3
						,Avg(avg_FEEAMOUNT_Q3) Real_Estate_avg_FEEAMOUNT_Q3
						,Sum(sum_Transaction_amount_Q3) Real_Estate_sum_Transaction_amount_Q3
						,Avg(Avg_Transaction_amount_Q4) Real_Estate_Avg_Transaction_amount_Q4
						,Avg(Avg_NEWBALANCE_Q4) Real_Estate_Avg_NEWBALANCE_Q4
						,Avg(avg_Interest_amount_Q4) Real_Estate_avg_Interest_amount_Q4
						,Avg(avg_FEEAMOUNT_Q4) Real_Estate_avg_FEEAMOUNT_Q4
						,Sum(sum_Transaction_amount_Q4) Real_Estate_sum_Transaction_amount_Q4
					
					from #Real_Estate aaa
			
			inner join
			 (select	UNID
					,Sum_count_loan_addon
					,Sum_count_New_loan
					,Sum_count_loan_payment
					,Sum_count_CASH
					,Sum_count_DRAFT
					,Sum_count_ACH
					,Sum_count_FEE
					,Sum_count_HOMEBANKING
					,Sum_count_INSURANCE
					,Sum_count_CHECKS
					,Sum_count_PAYROLL
					,Sum_count_KIOSK
					,Sum_count_AUDIO_RESPONSE_TELEPHONE
					,SUM_INTEREST_AMOUNT
					,SUM_FEEAMOUNT
					,Avg_Transaction_amount_Q1
				,Avg_NEWBALANCE_Q1
				,avg_Interest_amount_Q1
				,avg_FEEAMOUNT_Q1
				,sum_Transaction_amount_Q1
				,Avg_Transaction_amount_Q2
				,Avg_NEWBALANCE_Q2
				,avg_Interest_amount_Q2
				,avg_FEEAMOUNT_Q2
				,sum_Transaction_amount_Q2
				,Avg_Transaction_amount_Q3
				,Avg_NEWBALANCE_Q3
				,avg_Interest_amount_Q3
				,avg_FEEAMOUNT_Q3
				,sum_Transaction_amount_Q3
				,Avg_Transaction_amount_Q4
				,Avg_NEWBALANCE_Q4
				,avg_Interest_amount_Q4
				,avg_FEEAMOUNT_Q4
				,sum_Transaction_amount_Q4
				from #loan_transaction_data_0
				
				  ) a
				 on aaa.UNID=a.UNID
				 Group by ssn ) K
				 ON AA.SSN=K.SSN11
				left join
				 (
				select 
						SSN SSN111
						,Avg(Sum_count_loan_addon) Real_Estate2_Avg_count_loan_addon
						,Avg(Sum_count_New_loan) Real_Estate2_Avg_count_New_loan
						,Avg(Sum_count_loan_payment) Real_Estate2_Avg_count_loan_payment
						,Avg(Sum_count_CASH) Real_Estate2_Avg_count_CASH
						,Avg(Sum_count_DRAFT) Real_Estate2_Avg_count_DRAFT
						,Avg(Sum_count_ACH) Real_Estate2_Avg_count_ACH
						,Avg(Sum_count_FEE) Real_Estate2_Avg_count_FEE
						,Avg(Sum_count_HOMEBANKING) Real_Estate2_Avg_count_HOMEBANKING
						,Avg(Sum_count_INSURANCE) Real_Estate2_Avg_count_INSURANCE
						,Avg(Sum_count_CHECKS) Real_Estate2_Avg_count_CHECKS
						,Avg(Sum_count_PAYROLL) Real_Estate2_Avg_count_PAYROLL
						,Avg(Sum_count_KIOSK) Real_Estate2_Avg_count_KIOSK
						,Avg(Sum_count_AUDIO_RESPONSE_TELEPHONE) Real_Estate2_Avg_count_AUDIO_RESPONSE_TELEPHONE
						,Avg(SUM_INTEREST_AMOUNT) Real_Estate2_Avg_INTEREST_AMOUNT
						,Avg(SUM_FEEAMOUNT) Real_Estate2_Avg_FEEAMOUNT

						,Sum(Sum_count_loan_addon) Real_Estate2_Sum_count_loan_addon
						,Sum(Sum_count_New_loan) Real_Estate2_Sum_count_New_loan
						,Sum(Sum_count_loan_payment) Real_Estate2_Sum_count_loan_payment
						,Sum(Sum_count_CASH) Real_Estate2_Sum_count_CASH
						,Sum(Sum_count_DRAFT) Real_Estate2_Sum_count_DRAFT
						,Sum(Sum_count_ACH) Real_Estate2_Sum_count_ACH
						,Sum(Sum_count_FEE) Real_Estate2_Sum_count_FEE
						,Sum(Sum_count_HOMEBANKING) Real_Estate2_Sum_count_HOMEBANKING
						,Sum(Sum_count_INSURANCE) Real_Estate2_Sum_count_INSURANCE
						,Sum(Sum_count_CHECKS) Real_Estate2_Sum_count_CHECKS
						,Sum(Sum_count_PAYROLL) Real_Estate2_Sum_count_PAYROLL
						,Sum(Sum_count_KIOSK) Real_Estate2_Sum_count_KIOSK
						,Sum(Sum_count_AUDIO_RESPONSE_TELEPHONE) Real_Estate2_Sum_count_AUDIO_RESPONSE_TELEPHONE
						,Sum(SUM_INTEREST_AMOUNT) Real_Estate2_SUM_INTEREST_AMOUNT
						,Sum(SUM_FEEAMOUNT) Real_Estate2_SUM_FEEAMOUNT
						,Avg(Avg_Transaction_amount_Q1) Real_Estate2_Avg_Transaction_amount_Q1
						,Avg(Avg_NEWBALANCE_Q1) Real_Estate2_Avg_NEWBALANCE_Q1
						,Avg(avg_Interest_amount_Q1) Real_Estate2_avg_Interest_amount_Q1
						,Avg(avg_FEEAMOUNT_Q1) Real_Estate2_avg_FEEAMOUNT_Q1
						,Sum(sum_Transaction_amount_Q1) Real_Estate2_sum_Transaction_amount_Q1
						,Avg(Avg_Transaction_amount_Q2) Real_Estate2_Avg_Transaction_amount_Q2
						,Avg(Avg_NEWBALANCE_Q2) Real_Estate2_Avg_NEWBALANCE_Q2
						,Avg(avg_Interest_amount_Q2) Real_Estate2_avg_Interest_amount_Q2
						,Avg(avg_FEEAMOUNT_Q2) Real_Estate2_avg_FEEAMOUNT_Q2
						,Sum(sum_Transaction_amount_Q2) Real_Estate2_sum_Transaction_amount_Q2
						,Avg(Avg_Transaction_amount_Q3) Real_Estate2_Avg_Transaction_amount_Q3
						,Avg(Avg_NEWBALANCE_Q3) Real_Estate2_Avg_NEWBALANCE_Q3
						,Avg(avg_Interest_amount_Q3) Real_Estate2_avg_Interest_amount_Q3
						,Avg(avg_FEEAMOUNT_Q3) Real_Estate2_avg_FEEAMOUNT_Q3
						,Sum(sum_Transaction_amount_Q3) Real_Estate2_sum_Transaction_amount_Q3
						,Avg(Avg_Transaction_amount_Q4) Real_Estate2_Avg_Transaction_amount_Q4
						,Avg(Avg_NEWBALANCE_Q4) Real_Estate2_Avg_NEWBALANCE_Q4
						,Avg(avg_Interest_amount_Q4) Real_Estate2_avg_Interest_amount_Q4
						,Avg(avg_FEEAMOUNT_Q4) Real_Estate2_avg_FEEAMOUNT_Q4
						,Sum(sum_Transaction_amount_Q4) Real_Estate2_sum_Transaction_amount_Q4
					
					from #Real_Estate2 aaa
			
			inner join
			 (select	UNID
					,Sum_count_loan_addon
					,Sum_count_New_loan
					,Sum_count_loan_payment
					,Sum_count_CASH
					,Sum_count_DRAFT
					,Sum_count_ACH
					,Sum_count_FEE
					,Sum_count_HOMEBANKING
					,Sum_count_INSURANCE
					,Sum_count_CHECKS
					,Sum_count_PAYROLL
					,Sum_count_KIOSK
					,Sum_count_AUDIO_RESPONSE_TELEPHONE
					,SUM_INTEREST_AMOUNT
					,SUM_FEEAMOUNT
					,Avg_Transaction_amount_Q1
				,Avg_NEWBALANCE_Q1
				,avg_Interest_amount_Q1
				,avg_FEEAMOUNT_Q1
				,sum_Transaction_amount_Q1
				,Avg_Transaction_amount_Q2
				,Avg_NEWBALANCE_Q2
				,avg_Interest_amount_Q2
				,avg_FEEAMOUNT_Q2
				,sum_Transaction_amount_Q2
				,Avg_Transaction_amount_Q3
				,Avg_NEWBALANCE_Q3
				,avg_Interest_amount_Q3
				,avg_FEEAMOUNT_Q3
				,sum_Transaction_amount_Q3
				,Avg_Transaction_amount_Q4
				,Avg_NEWBALANCE_Q4
				,avg_Interest_amount_Q4
				,avg_FEEAMOUNT_Q4
				,sum_Transaction_amount_Q4
				from #loan_transaction_data_0
				
				  ) a
				 on aaa.UNID=a.UNID
				 Group by ssn ) KA
				 ON AA.SSN=KA.SSN111
				left join
				(
				select 
						SSN SSN12
						,Avg(Sum_count_loan_addon) Secured_Avg_count_loan_addon
						,Avg(Sum_count_New_loan) Secured_Avg_count_New_loan
						,Avg(Sum_count_loan_payment) Secured_Avg_count_loan_payment
						,Avg(Sum_count_CASH) Secured_Avg_count_CASH
						,Avg(Sum_count_DRAFT) Secured_Avg_count_DRAFT
						,Avg(Sum_count_ACH) Secured_Avg_count_ACH
						,Avg(Sum_count_FEE) Secured_Avg_count_FEE
						,Avg(Sum_count_HOMEBANKING) Secured_Avg_count_HOMEBANKING
						,Avg(Sum_count_INSURANCE) Secured_Avg_count_INSURANCE
						,Avg(Sum_count_CHECKS) Secured_Avg_count_CHECKS
						,Avg(Sum_count_PAYROLL) Secured_Avg_count_PAYROLL
						,Avg(Sum_count_KIOSK) Secured_Avg_count_KIOSK
						,Avg(Sum_count_AUDIO_RESPONSE_TELEPHONE) Secured_Avg_count_AUDIO_RESPONSE_TELEPHONE
						,Avg(SUM_INTEREST_AMOUNT) Secured_Avg_INTEREST_AMOUNT
						,Avg(SUM_FEEAMOUNT) Secured_Avg_FEEAMOUNT

						,Sum(Sum_count_loan_addon) Secured_Sum_count_loan_addon
						,Sum(Sum_count_New_loan) Secured_Sum_count_New_loan
						,Sum(Sum_count_loan_payment) Secured_Sum_count_loan_payment
						,Sum(Sum_count_CASH) Secured_Sum_count_CASH
						,Sum(Sum_count_DRAFT) Secured_Sum_count_DRAFT
						,Sum(Sum_count_ACH) Secured_Sum_count_ACH
						,Sum(Sum_count_FEE) Secured_Sum_count_FEE
						,Sum(Sum_count_HOMEBANKING) Secured_Sum_count_HOMEBANKING
						,Sum(Sum_count_INSURANCE) Secured_Sum_count_INSURANCE
						,Sum(Sum_count_CHECKS) Secured_Sum_count_CHECKS
						,Sum(Sum_count_PAYROLL) Secured_Sum_count_PAYROLL
						,Sum(Sum_count_KIOSK) Secured_Sum_count_KIOSK
						,Sum(Sum_count_AUDIO_RESPONSE_TELEPHONE) Secured_Sum_count_AUDIO_RESPONSE_TELEPHONE
						,Sum(SUM_INTEREST_AMOUNT) Secured_SUM_INTEREST_AMOUNT
						,Sum(SUM_FEEAMOUNT) Secured_SUM_FEEAMOUNT
						,Avg(Avg_Transaction_amount_Q1) Secured_Avg_Transaction_amount_Q1
						,Avg(Avg_NEWBALANCE_Q1) Secured_Avg_NEWBALANCE_Q1
						,Avg(avg_Interest_amount_Q1) Secured_avg_Interest_amount_Q1
						,Avg(avg_FEEAMOUNT_Q1) Secured_avg_FEEAMOUNT_Q1
						,Sum(sum_Transaction_amount_Q1) Secured_sum_Transaction_amount_Q1
						,Avg(Avg_Transaction_amount_Q2) Secured_Avg_Transaction_amount_Q2
						,Avg(Avg_NEWBALANCE_Q2) Secured_Avg_NEWBALANCE_Q2
						,Avg(avg_Interest_amount_Q2) Secured_avg_Interest_amount_Q2
						,Avg(avg_FEEAMOUNT_Q2) Secured_avg_FEEAMOUNT_Q2
						,Sum(sum_Transaction_amount_Q2) Secured_sum_Transaction_amount_Q2
						,Avg(Avg_Transaction_amount_Q3) Secured_Avg_Transaction_amount_Q3
						,Avg(Avg_NEWBALANCE_Q3) Secured_Avg_NEWBALANCE_Q3
						,Avg(avg_Interest_amount_Q3) Secured_avg_Interest_amount_Q3
						,Avg(avg_FEEAMOUNT_Q3) Secured_avg_FEEAMOUNT_Q3
						,Sum(sum_Transaction_amount_Q3) Secured_sum_Transaction_amount_Q3
						,Avg(Avg_Transaction_amount_Q4) Secured_Avg_Transaction_amount_Q4
						,Avg(Avg_NEWBALANCE_Q4) Secured_Avg_NEWBALANCE_Q4
						,Avg(avg_Interest_amount_Q4) Secured_avg_Interest_amount_Q4
						,Avg(avg_FEEAMOUNT_Q4) Secured_avg_FEEAMOUNT_Q4
						,Sum(sum_Transaction_amount_Q4) Secured_sum_Transaction_amount_Q4
					
					from #Secured aaa
			
			inner join
			 (select	UNID
					,Sum_count_loan_addon
					,Sum_count_New_loan
					,Sum_count_loan_payment
					,Sum_count_CASH
					,Sum_count_DRAFT
					,Sum_count_ACH
					,Sum_count_FEE
					,Sum_count_HOMEBANKING
					,Sum_count_INSURANCE
					,Sum_count_CHECKS
					,Sum_count_PAYROLL
					,Sum_count_KIOSK
					,Sum_count_AUDIO_RESPONSE_TELEPHONE
					,SUM_INTEREST_AMOUNT
					,SUM_FEEAMOUNT
					,Avg_Transaction_amount_Q1
				,Avg_NEWBALANCE_Q1
				,avg_Interest_amount_Q1
				,avg_FEEAMOUNT_Q1
				,sum_Transaction_amount_Q1
				,Avg_Transaction_amount_Q2
				,Avg_NEWBALANCE_Q2
				,avg_Interest_amount_Q2
				,avg_FEEAMOUNT_Q2
				,sum_Transaction_amount_Q2
				,Avg_Transaction_amount_Q3
				,Avg_NEWBALANCE_Q3
				,avg_Interest_amount_Q3
				,avg_FEEAMOUNT_Q3
				,sum_Transaction_amount_Q3
				,Avg_Transaction_amount_Q4
				,Avg_NEWBALANCE_Q4
				,avg_Interest_amount_Q4
				,avg_FEEAMOUNT_Q4
				,sum_Transaction_amount_Q4
				from #loan_transaction_data_0
				
				  ) a
				 on aaa.UNID=a.UNID
				 Group by ssn ) L
				 ON AA.SSN=L.SSN12
				 left join
							(
							select 
						SSN SSN13
						,Avg(Sum_count_loan_addon) Unsecured_Avg_count_loan_addon
						,Avg(Sum_count_New_loan) Unsecured_Avg_count_New_loan
						,Avg(Sum_count_loan_payment) Unsecured_Avg_count_loan_payment
						,Avg(Sum_count_CASH) Unsecured_Avg_count_CASH
						,Avg(Sum_count_DRAFT) Unsecured_Avg_count_DRAFT
						,Avg(Sum_count_ACH) Unsecured_Avg_count_ACH
						,Avg(Sum_count_FEE) Unsecured_Avg_count_FEE
						,Avg(Sum_count_HOMEBANKING) Unsecured_Avg_count_HOMEBANKING
						,Avg(Sum_count_INSURANCE) Unsecured_Avg_count_INSURANCE
						,Avg(Sum_count_CHECKS) Unsecured_Avg_count_CHECKS
						,Avg(Sum_count_PAYROLL) Unsecured_Avg_count_PAYROLL
						,Avg(Sum_count_KIOSK) Unsecured_Avg_count_KIOSK
						,Avg(Sum_count_AUDIO_RESPONSE_TELEPHONE) Unsecured_Avg_count_AUDIO_RESPONSE_TELEPHONE
						,Avg(SUM_INTEREST_AMOUNT) Unsecured_Avg_INTEREST_AMOUNT
						,Avg(SUM_FEEAMOUNT) Unsecured_Avg_FEEAMOUNT

						,Sum(Sum_count_loan_addon) Unsecured_Sum_count_loan_addon
						,Sum(Sum_count_New_loan) Unsecured_Sum_count_New_loan
						,Sum(Sum_count_loan_payment) Unsecured_Sum_count_loan_payment
						,Sum(Sum_count_CASH) Unsecured_Sum_count_CASH
						,Sum(Sum_count_DRAFT) Unsecured_Sum_count_DRAFT
						,Sum(Sum_count_ACH) Unsecured_Sum_count_ACH
						,Sum(Sum_count_FEE) Unsecured_Sum_count_FEE
						,Sum(Sum_count_HOMEBANKING) Unsecured_Sum_count_HOMEBANKING
						,Sum(Sum_count_INSURANCE) Unsecured_Sum_count_INSURANCE
						,Sum(Sum_count_CHECKS) Unsecured_Sum_count_CHECKS
						,Sum(Sum_count_PAYROLL) Unsecured_Sum_count_PAYROLL
						,Sum(Sum_count_KIOSK) Unsecured_Sum_count_KIOSK
						,Sum(Sum_count_AUDIO_RESPONSE_TELEPHONE) Unsecured_Sum_count_AUDIO_RESPONSE_TELEPHONE
						,Sum(SUM_INTEREST_AMOUNT) Unsecured_SUM_INTEREST_AMOUNT
						,Sum(SUM_FEEAMOUNT) Unsecured_SUM_FEEAMOUNT
						,Avg(Avg_Transaction_amount_Q1) Unsecured_Avg_Transaction_amount_Q1
						,Avg(Avg_NEWBALANCE_Q1) Unsecured_Avg_NEWBALANCE_Q1
						,Avg(avg_Interest_amount_Q1) Unsecured_avg_Interest_amount_Q1
						,Avg(avg_FEEAMOUNT_Q1) Unsecured_avg_FEEAMOUNT_Q1
						,Sum(sum_Transaction_amount_Q1) Unsecured_sum_Transaction_amount_Q1
						,Avg(Avg_Transaction_amount_Q2) Unsecured_Avg_Transaction_amount_Q2
						,Avg(Avg_NEWBALANCE_Q2) Unsecured_Avg_NEWBALANCE_Q2
						,Avg(avg_Interest_amount_Q2) Unsecured_avg_Interest_amount_Q2
						,Avg(avg_FEEAMOUNT_Q2) Unsecured_avg_FEEAMOUNT_Q2
						,Sum(sum_Transaction_amount_Q2) Unsecured_sum_Transaction_amount_Q2
						,Avg(Avg_Transaction_amount_Q3) Unsecured_Avg_Transaction_amount_Q3
						,Avg(Avg_NEWBALANCE_Q3) Unsecured_Avg_NEWBALANCE_Q3
						,Avg(avg_Interest_amount_Q3) Unsecured_avg_Interest_amount_Q3
						,Avg(avg_FEEAMOUNT_Q3) Unsecured_avg_FEEAMOUNT_Q3
						,Sum(sum_Transaction_amount_Q3) Unsecured_sum_Transaction_amount_Q3
						,Avg(Avg_Transaction_amount_Q4) Unsecured_Avg_Transaction_amount_Q4
						,Avg(Avg_NEWBALANCE_Q4) Unsecured_Avg_NEWBALANCE_Q4
						,Avg(avg_Interest_amount_Q4) Unsecured_avg_Interest_amount_Q4
						,Avg(avg_FEEAMOUNT_Q4) Unsecured_avg_FEEAMOUNT_Q4
						,Sum(sum_Transaction_amount_Q4) Unsecured_sum_Transaction_amount_Q4
					
					from #Unsecured aaa
			
			inner join
			 (select	UNID
					,Sum_count_loan_addon
					,Sum_count_New_loan
					,Sum_count_loan_payment
					,Sum_count_CASH
					,Sum_count_DRAFT
					,Sum_count_ACH
					,Sum_count_FEE
					,Sum_count_HOMEBANKING
					,Sum_count_INSURANCE
					,Sum_count_CHECKS
					,Sum_count_PAYROLL
					,Sum_count_KIOSK
					,Sum_count_AUDIO_RESPONSE_TELEPHONE
					,SUM_INTEREST_AMOUNT
					,SUM_FEEAMOUNT
					,Avg_Transaction_amount_Q1
				,Avg_NEWBALANCE_Q1
				,avg_Interest_amount_Q1
				,avg_FEEAMOUNT_Q1
				,sum_Transaction_amount_Q1
				,Avg_Transaction_amount_Q2
				,Avg_NEWBALANCE_Q2
				,avg_Interest_amount_Q2
				,avg_FEEAMOUNT_Q2
				,sum_Transaction_amount_Q2
				,Avg_Transaction_amount_Q3
				,Avg_NEWBALANCE_Q3
				,avg_Interest_amount_Q3
				,avg_FEEAMOUNT_Q3
				,sum_Transaction_amount_Q3
				,Avg_Transaction_amount_Q4
				,Avg_NEWBALANCE_Q4
				,avg_Interest_amount_Q4
				,avg_FEEAMOUNT_Q4
				,sum_Transaction_amount_Q4
				from #loan_transaction_data_0
				
				  ) a
				 on aaa.UNID=a.UNID
				 Group by ssn ) M
					ON AA.SSN=M.SSN13

					left join 
				( select 
						SSN SSN14
						,Avg(Sum_count_loan_addon) Vehicles_Avg_count_loan_addon
						,Avg(Sum_count_New_loan) Vehicles_Avg_count_New_loan
						,Avg(Sum_count_loan_payment) Vehicles_Avg_count_loan_payment
						,Avg(Sum_count_CASH) Vehicles_Avg_count_CASH
						,Avg(Sum_count_DRAFT) Vehicles_Avg_count_DRAFT
						,Avg(Sum_count_ACH) Vehicles_Avg_count_ACH
						,Avg(Sum_count_FEE) Vehicles_Avg_count_FEE
						,Avg(Sum_count_HOMEBANKING) Vehicles_Avg_count_HOMEBANKING
						,Avg(Sum_count_INSURANCE) Vehicles_Avg_count_INSURANCE
						,Avg(Sum_count_CHECKS) Vehicles_Avg_count_CHECKS
						,Avg(Sum_count_PAYROLL) Vehicles_Avg_count_PAYROLL
						,Avg(Sum_count_KIOSK) Vehicles_Avg_count_KIOSK
						,Avg(Sum_count_AUDIO_RESPONSE_TELEPHONE) Vehicles_Avg_count_AUDIO_RESPONSE_TELEPHONE
						,Avg(SUM_INTEREST_AMOUNT) Vehicles_Avg_INTEREST_AMOUNT
						,Avg(SUM_FEEAMOUNT) Vehicles_Avg_FEEAMOUNT

						,Sum(Sum_count_loan_addon) Vehicles_Sum_count_loan_addon
						,Sum(Sum_count_New_loan) Vehicles_Sum_count_New_loan
						,Sum(Sum_count_loan_payment) Vehicles_Sum_count_loan_payment
						,Sum(Sum_count_CASH) Vehicles_Sum_count_CASH
						,Sum(Sum_count_DRAFT) Vehicles_Sum_count_DRAFT
						,Sum(Sum_count_ACH) Vehicles_Sum_count_ACH
						,Sum(Sum_count_FEE) Vehicles_Sum_count_FEE
						,Sum(Sum_count_HOMEBANKING) Vehicles_Sum_count_HOMEBANKING
						,Sum(Sum_count_INSURANCE) Vehicles_Sum_count_INSURANCE
						,Sum(Sum_count_CHECKS) Vehicles_Sum_count_CHECKS
						,Sum(Sum_count_PAYROLL) Vehicles_Sum_count_PAYROLL
						,Sum(Sum_count_KIOSK) Vehicles_Sum_count_KIOSK
						,Sum(Sum_count_AUDIO_RESPONSE_TELEPHONE) Vehicles_Sum_count_AUDIO_RESPONSE_TELEPHONE
						,Sum(SUM_INTEREST_AMOUNT) Vehicles_SUM_INTEREST_AMOUNT
						,Sum(SUM_FEEAMOUNT) Vehicles_SUM_FEEAMOUNT
						,Avg(Avg_Transaction_amount_Q1) Vehicles_Avg_Transaction_amount_Q1
						,Avg(Avg_NEWBALANCE_Q1) Vehicles_Avg_NEWBALANCE_Q1
						,Avg(avg_Interest_amount_Q1) Vehicles_avg_Interest_amount_Q1
						,Avg(avg_FEEAMOUNT_Q1) Vehicles_avg_FEEAMOUNT_Q1
						,Sum(sum_Transaction_amount_Q1) Vehicles_sum_Transaction_amount_Q1
						,Avg(Avg_Transaction_amount_Q2) Vehicles_Avg_Transaction_amount_Q2
						,Avg(Avg_NEWBALANCE_Q2) Vehicles_Avg_NEWBALANCE_Q2
						,Avg(avg_Interest_amount_Q2) Vehicles_avg_Interest_amount_Q2
						,Avg(avg_FEEAMOUNT_Q2) Vehicles_avg_FEEAMOUNT_Q2
						,Sum(sum_Transaction_amount_Q2) Vehicles_sum_Transaction_amount_Q2
						,Avg(Avg_Transaction_amount_Q3) Vehicles_Avg_Transaction_amount_Q3
						,Avg(Avg_NEWBALANCE_Q3) Vehicles_Avg_NEWBALANCE_Q3
						,Avg(avg_Interest_amount_Q3) Vehicles_avg_Interest_amount_Q3
						,Avg(avg_FEEAMOUNT_Q3) Vehicles_avg_FEEAMOUNT_Q3
						,Sum(sum_Transaction_amount_Q3) Vehicles_sum_Transaction_amount_Q3
						,Avg(Avg_Transaction_amount_Q4) Vehicles_Avg_Transaction_amount_Q4
						,Avg(Avg_NEWBALANCE_Q4) Vehicles_Avg_NEWBALANCE_Q4
						,Avg(avg_Interest_amount_Q4) Vehicles_avg_Interest_amount_Q4
						,Avg(avg_FEEAMOUNT_Q4) Vehicles_avg_FEEAMOUNT_Q4
						,Sum(sum_Transaction_amount_Q4) Vehicles_sum_Transaction_amount_Q4
					
					from #Vehicles aaa
			
			inner join
			 (select	UNID
					,Sum_count_loan_addon
					,Sum_count_New_loan
					,Sum_count_loan_payment
					,Sum_count_CASH
					,Sum_count_DRAFT
					,Sum_count_ACH
					,Sum_count_FEE
					,Sum_count_HOMEBANKING
					,Sum_count_INSURANCE
					,Sum_count_CHECKS
					,Sum_count_PAYROLL
					,Sum_count_KIOSK
					,Sum_count_AUDIO_RESPONSE_TELEPHONE
					,SUM_INTEREST_AMOUNT
					,SUM_FEEAMOUNT
					,Avg_Transaction_amount_Q1
				,Avg_NEWBALANCE_Q1
				,avg_Interest_amount_Q1
				,avg_FEEAMOUNT_Q1
				,sum_Transaction_amount_Q1
				,Avg_Transaction_amount_Q2
				,Avg_NEWBALANCE_Q2
				,avg_Interest_amount_Q2
				,avg_FEEAMOUNT_Q2
				,sum_Transaction_amount_Q2
				,Avg_Transaction_amount_Q3
				,Avg_NEWBALANCE_Q3
				,avg_Interest_amount_Q3
				,avg_FEEAMOUNT_Q3
				,sum_Transaction_amount_Q3
				,Avg_Transaction_amount_Q4
				,Avg_NEWBALANCE_Q4
				,avg_Interest_amount_Q4
				,avg_FEEAMOUNT_Q4
				,sum_Transaction_amount_Q4
				from #loan_transaction_data_0
				
				  ) a
				 on aaa.UNID=a.UNID
				 Group by ssn
				 ) N
				 ON AA.SSN=N.SSN14
				left join 

			--	(
			--	 select 
			--			SSN SSN15
			--			,Avg(Sum_count_loan_addon) Wealth_Management_Avg_count_loan_addon
			--			,Avg(Sum_count_New_loan) Wealth_Management_Avg_count_New_loan
			--			,Avg(Sum_count_loan_payment) Wealth_Management_Avg_count_loan_payment
			--			,Avg(Sum_count_CASH) Wealth_Management_Avg_count_CASH
			--			,Avg(Sum_count_DRAFT) Wealth_Management_Avg_count_DRAFT
			--			,Avg(Sum_count_ACH) Wealth_Management_Avg_count_ACH
			--			,Avg(Sum_count_FEE) Wealth_Management_Avg_count_FEE
			--			,Avg(Sum_count_HOMEBANKING) Wealth_Management_Avg_count_HOMEBANKING
			--			,Avg(Sum_count_INSURANCE) Wealth_Management_Avg_count_INSURANCE
			--			,Avg(Sum_count_CHECKS) Wealth_Management_Avg_count_CHECKS
			--			,Avg(Sum_count_PAYROLL) Wealth_Management_Avg_count_PAYROLL
			--			,Avg(Sum_count_KIOSK) Wealth_Management_Avg_count_KIOSK
			--			,Avg(Sum_count_AUDIO_RESPONSE_TELEPHONE) Wealth_Management_Avg_count_AUDIO_RESPONSE_TELEPHONE
			--			,Avg(SUM_INTEREST_AMOUNT) Wealth_Management_Avg_INTEREST_AMOUNT
			--			,Avg(SUM_FEEAMOUNT) Wealth_Management_Avg_FEEAMOUNT

			--			,Sum(Sum_count_loan_addon) Wealth_Management_Sum_count_loan_addon
			--			,Sum(Sum_count_New_loan) Wealth_Management_Sum_count_New_loan
			--			,Sum(Sum_count_loan_payment) Wealth_Management_Sum_count_loan_payment
			--			,Sum(Sum_count_CASH) Wealth_Management_Sum_count_CASH
			--			,Sum(Sum_count_DRAFT) Wealth_Management_Sum_count_DRAFT
			--			,Sum(Sum_count_ACH) Wealth_Management_Sum_count_ACH
			--			,Sum(Sum_count_FEE) Wealth_Management_Sum_count_FEE
			--			,Sum(Sum_count_HOMEBANKING) Wealth_Management_Sum_count_HOMEBANKING
			--			,Sum(Sum_count_INSURANCE) Wealth_Management_Sum_count_INSURANCE
			--			,Sum(Sum_count_CHECKS) Wealth_Management_Sum_count_CHECKS
			--			,Sum(Sum_count_PAYROLL) Wealth_Management_Sum_count_PAYROLL
			--			,Sum(Sum_count_KIOSK) Wealth_Management_Sum_count_KIOSK
			--			,Sum(Sum_count_AUDIO_RESPONSE_TELEPHONE) Wealth_Management_Sum_count_AUDIO_RESPONSE_TELEPHONE
			--			,Sum(SUM_INTEREST_AMOUNT) Wealth_Management_SUM_INTEREST_AMOUNT
			--			,Sum(SUM_FEEAMOUNT) Wealth_Management_SUM_FEEAMOUNT
			--			,Avg(Avg_Transaction_amount_Q1) Wealth_Management_Avg_Transaction_amount_Q1
			--			,Avg(Avg_NEWBALANCE_Q1) Wealth_Management_Avg_NEWBALANCE_Q1
			--			,Avg(avg_Interest_amount_Q1) Wealth_Management_avg_Interest_amount_Q1
			--			,Avg(avg_FEEAMOUNT_Q1) Wealth_Management_avg_FEEAMOUNT_Q1
			--			,Sum(sum_Transaction_amount_Q1) Wealth_Management_sum_Transaction_amount_Q1
			--			,Avg(Avg_Transaction_amount_Q2) Wealth_Management_Avg_Transaction_amount_Q2
			--			,Avg(Avg_NEWBALANCE_Q2) Wealth_Management_Avg_NEWBALANCE_Q2
			--			,Avg(avg_Interest_amount_Q2) Wealth_Management_avg_Interest_amount_Q2
			--			,Avg(avg_FEEAMOUNT_Q2) Wealth_Management_avg_FEEAMOUNT_Q2
			--			,Sum(sum_Transaction_amount_Q2) Wealth_Management_sum_Transaction_amount_Q2
			--			,Avg(Avg_Transaction_amount_Q3) Wealth_Management_Avg_Transaction_amount_Q3
			--			,Avg(Avg_NEWBALANCE_Q3) Wealth_Management_Avg_NEWBALANCE_Q3
			--			,Avg(avg_Interest_amount_Q3) Wealth_Management_avg_Interest_amount_Q3
			--			,Avg(avg_FEEAMOUNT_Q3) Wealth_Management_avg_FEEAMOUNT_Q3
			--			,Sum(sum_Transaction_amount_Q3) Wealth_Management_sum_Transaction_amount_Q3
			--			,Avg(Avg_Transaction_amount_Q4) Wealth_Management_Avg_Transaction_amount_Q4
			--			,Avg(Avg_NEWBALANCE_Q4) Wealth_Management_Avg_NEWBALANCE_Q4
			--			,Avg(avg_Interest_amount_Q4) Wealth_Management_avg_Interest_amount_Q4
			--			,Avg(avg_FEEAMOUNT_Q4) Wealth_Management_avg_FEEAMOUNT_Q4
			--			,Sum(sum_Transaction_amount_Q4) Wealth_Management_sum_Transaction_amount_Q4
					
			--		from #Wealth_Management aaa
			
			--inner join
			-- (select	UNID
			--		,Sum_count_loan_addon
			--		,Sum_count_New_loan
			--		,Sum_count_loan_payment
			--		,Sum_count_CASH
			--		,Sum_count_DRAFT
			--		,Sum_count_ACH
			--		,Sum_count_FEE
			--		,Sum_count_HOMEBANKING
			--		,Sum_count_INSURANCE
			--		,Sum_count_CHECKS
			--		,Sum_count_PAYROLL
			--		,Sum_count_KIOSK
			--		,Sum_count_AUDIO_RESPONSE_TELEPHONE
			--		,SUM_INTEREST_AMOUNT
			--		,SUM_FEEAMOUNT
			--		,Avg_Transaction_amount_Q1
			--	,Avg_NEWBALANCE_Q1
			--	,avg_Interest_amount_Q1
			--	,avg_FEEAMOUNT_Q1
			--	,sum_Transaction_amount_Q1
			--	,Avg_Transaction_amount_Q2
			--	,Avg_NEWBALANCE_Q2
			--	,avg_Interest_amount_Q2
			--	,avg_FEEAMOUNT_Q2
			--	,sum_Transaction_amount_Q2
			--	,Avg_Transaction_amount_Q3
			--	,Avg_NEWBALANCE_Q3
			--	,avg_Interest_amount_Q3
			--	,avg_FEEAMOUNT_Q3
			--	,sum_Transaction_amount_Q3
			--	,Avg_Transaction_amount_Q4
			--	,Avg_NEWBALANCE_Q4
			--	,avg_Interest_amount_Q4
			--	,avg_FEEAMOUNT_Q4
			--	,sum_Transaction_amount_Q4
			--	from #loan_transaction_data_0
				
			--	  ) a
			--	 on aaa.UNID=a.UNID
			--	 Group by ssn  ) P
			--	 ON AA.SSN=P.SSN15
			--	left join 

				(
				 
						select 
						SSN SSN16
						,Avg(Sum_count_loan_addon) Work_Out_Avg_count_loan_addon
						,Avg(Sum_count_New_loan) Work_Out_Avg_count_New_loan
						,Avg(Sum_count_loan_payment) Work_Out_Avg_count_loan_payment
						,Avg(Sum_count_CASH) Work_Out_Avg_count_CASH
						,Avg(Sum_count_DRAFT) Work_Out_Avg_count_DRAFT
						,Avg(Sum_count_ACH) Work_Out_Avg_count_ACH
						,Avg(Sum_count_FEE) Work_Out_Avg_count_FEE
						,Avg(Sum_count_HOMEBANKING) Work_Out_Avg_count_HOMEBANKING
						,Avg(Sum_count_INSURANCE) Work_Out_Avg_count_INSURANCE
						,Avg(Sum_count_CHECKS) Work_Out_Avg_count_CHECKS
						,Avg(Sum_count_PAYROLL) Work_Out_Avg_count_PAYROLL
						,Avg(Sum_count_KIOSK) Work_Out_Avg_count_KIOSK
						,Avg(Sum_count_AUDIO_RESPONSE_TELEPHONE) Work_Out_Avg_count_AUDIO_RESPONSE_TELEPHONE
						,Avg(SUM_INTEREST_AMOUNT) Work_Out_Avg_INTEREST_AMOUNT
						,Avg(SUM_FEEAMOUNT) Work_Out_Avg_FEEAMOUNT

						,Sum(Sum_count_loan_addon) Work_Out_Sum_count_loan_addon
						,Sum(Sum_count_New_loan) Work_Out_Sum_count_New_loan
						,Sum(Sum_count_loan_payment) Work_Out_Sum_count_loan_payment
						,Sum(Sum_count_CASH) Work_Out_Sum_count_CASH
						,Sum(Sum_count_DRAFT) Work_Out_Sum_count_DRAFT
						,Sum(Sum_count_ACH) Work_Out_Sum_count_ACH
						,Sum(Sum_count_FEE) Work_Out_Sum_count_FEE
						,Sum(Sum_count_HOMEBANKING) Work_Out_Sum_count_HOMEBANKING
						,Sum(Sum_count_INSURANCE) Work_Out_Sum_count_INSURANCE
						,Sum(Sum_count_CHECKS) Work_Out_Sum_count_CHECKS
						,Sum(Sum_count_PAYROLL) Work_Out_Sum_count_PAYROLL
						,Sum(Sum_count_KIOSK) Work_Out_Sum_count_KIOSK
						,Sum(Sum_count_AUDIO_RESPONSE_TELEPHONE) Work_Out_Sum_count_AUDIO_RESPONSE_TELEPHONE
						,Sum(SUM_INTEREST_AMOUNT) Work_Out_SUM_INTEREST_AMOUNT
						,Sum(SUM_FEEAMOUNT) Work_Out_SUM_FEEAMOUNT
						,Avg(Avg_Transaction_amount_Q1) Work_Out_Avg_Transaction_amount_Q1
						,Avg(Avg_NEWBALANCE_Q1) Work_Out_Avg_NEWBALANCE_Q1
						,Avg(avg_Interest_amount_Q1) Work_Out_avg_Interest_amount_Q1
						,Avg(avg_FEEAMOUNT_Q1) Work_Out_avg_FEEAMOUNT_Q1
						,Sum(sum_Transaction_amount_Q1) Work_Out_sum_Transaction_amount_Q1
						,Avg(Avg_Transaction_amount_Q2) Work_Out_Avg_Transaction_amount_Q2
						,Avg(Avg_NEWBALANCE_Q2) Work_Out_Avg_NEWBALANCE_Q2
						,Avg(avg_Interest_amount_Q2) Work_Out_avg_Interest_amount_Q2
						,Avg(avg_FEEAMOUNT_Q2) Work_Out_avg_FEEAMOUNT_Q2
						,Sum(sum_Transaction_amount_Q2) Work_Out_sum_Transaction_amount_Q2
						,Avg(Avg_Transaction_amount_Q3) Work_Out_Avg_Transaction_amount_Q3
						,Avg(Avg_NEWBALANCE_Q3) Work_Out_Avg_NEWBALANCE_Q3
						,Avg(avg_Interest_amount_Q3) Work_Out_avg_Interest_amount_Q3
						,Avg(avg_FEEAMOUNT_Q3) Work_Out_avg_FEEAMOUNT_Q3
						,Sum(sum_Transaction_amount_Q3) Work_Out_sum_Transaction_amount_Q3
						,Avg(Avg_Transaction_amount_Q4) Work_Out_Avg_Transaction_amount_Q4
						,Avg(Avg_NEWBALANCE_Q4) Work_Out_Avg_NEWBALANCE_Q4
						,Avg(avg_Interest_amount_Q4) Work_Out_avg_Interest_amount_Q4
						,Avg(avg_FEEAMOUNT_Q4) Work_Out_avg_FEEAMOUNT_Q4
						,Sum(sum_Transaction_amount_Q4) Work_Out_sum_Transaction_amount_Q4
					
					from #Work_Out aaa
			
			inner join
			 (select	UNID
					,Sum_count_loan_addon
					,Sum_count_New_loan
					,Sum_count_loan_payment
					,Sum_count_CASH
					,Sum_count_DRAFT
					,Sum_count_ACH
					,Sum_count_FEE
					,Sum_count_HOMEBANKING
					,Sum_count_INSURANCE
					,Sum_count_CHECKS
					,Sum_count_PAYROLL
					,Sum_count_KIOSK
					,Sum_count_AUDIO_RESPONSE_TELEPHONE
					,SUM_INTEREST_AMOUNT
					,SUM_FEEAMOUNT
					,Avg_Transaction_amount_Q1
				,Avg_NEWBALANCE_Q1
				,avg_Interest_amount_Q1
				,avg_FEEAMOUNT_Q1
				,sum_Transaction_amount_Q1
				,Avg_Transaction_amount_Q2
				,Avg_NEWBALANCE_Q2
				,avg_Interest_amount_Q2
				,avg_FEEAMOUNT_Q2
				,sum_Transaction_amount_Q2
				,Avg_Transaction_amount_Q3
				,Avg_NEWBALANCE_Q3
				,avg_Interest_amount_Q3
				,avg_FEEAMOUNT_Q3
				,sum_Transaction_amount_Q3
				,Avg_Transaction_amount_Q4
				,Avg_NEWBALANCE_Q4
				,avg_Interest_amount_Q4
				,avg_FEEAMOUNT_Q4
				,sum_Transaction_amount_Q4
				from #loan_transaction_data_0
				
				  ) a
				 on aaa.UNID=a.UNID
				 Group by ssn ) Q
				 ON AA.SSN=Q.SSN16
				 

		-- drop table if exists #Saving_accounts
		left join 
		
			( select aa.SSN SSN17,ab.Total_No_Account_Savings,Total_type_account_Savings
			,opendate_Savings,MOB_Savings,OPEN_DATE_Savings,Closed_date_Savings
			,CHARGEOFFDATE_Savings,CHARGEOFFAMOUNT_Savings,
			max(StaticPool_Saving_flag) StaticPool_Saving_flag
			,sum(case when Quarters='Q1' then sum_Month_end_balance_savings  END)-
			sum(case when Quarters='Q2' then sum_Month_end_balance_savings  END) Diff_Month_end_balance_savings_Q1_Q2
			,sum(case when Quarters='Q1' then sum_Month_end_balance_savings  END)-
			sum(case when Quarters='Q4' then sum_Month_end_balance_savings  END) Diff_Month_end_balance_savings_Q1_Q4
			,sum(case when Quarters='Q1' then Sum_LASTDIVAMOUNT_savings   END) Sum_LASTDIVAMOUNT_savings_Q1
			,sum(case when Quarters='Q1' then Avg_Month_end_balance_savings  END) Avg_Month_end_balance_savings_Q1
			,sum(case when Quarters='Q1' then sum_Month_end_balance_savings  END) sum_Month_end_balance_savings_Q1
			,sum(case when Quarters='Q1' then AVG_balancechange_savings  END) AVG_balancechange_savings_Q1
			,sum(case when Quarters='Q1' then avg_Deposited_amount_savings  END) avg_Deposited_amount_savings_Q1
			,sum(case when Quarters='Q1' then avg_Deposited_count_savings  END) avg_Deposited_count_savings_Q1
			,sum(case when Quarters='Q1' then avg_withdrawal_amount_savings  END) avg_withdrawal_amount_savings_Q1
			,sum(case when Quarters='Q1' then Avg_withdrawal_count_savings  END) Avg_withdrawal_count_savings_Q1
			,sum(case when Quarters='Q1' then Sum_transaction_count_savings  END) Sum_transaction_count_savings_Q1
			,sum(case when Quarters='Q1' then Sum_transaction_amount_savings  END) Sum_transaction_amount_savings_Q1
			,sum(case when Quarters='Q1' then Avg_transaction_amount_savings  END) Avg_transaction_amount_savings_Q1

			,sum(case when Quarters='Q2' then Sum_LASTDIVAMOUNT_savings   END) Sum_LASTDIVAMOUNT_savings_Q2
			,sum(case when Quarters='Q2' then Avg_Month_end_balance_savings  END) Avg_Month_end_balance_savings_Q2
			,sum(case when Quarters='Q2' then sum_Month_end_balance_savings  END) sum_Month_end_balance_savings_Q2
			,sum(case when Quarters='Q2' then AVG_balancechange_savings  END) AVG_balancechange_savings_Q2
			,sum(case when Quarters='Q2' then avg_Deposited_amount_savings  END) avg_Deposited_amount_savings_Q2
			,sum(case when Quarters='Q2' then avg_Deposited_count_savings  END) avg_Deposited_count_savings_Q2
			,sum(case when Quarters='Q2' then avg_withdrawal_amount_savings  END) avg_withdrawal_amount_savings_Q2
			,sum(case when Quarters='Q2' then Avg_withdrawal_count_savings  END) Avg_withdrawal_count_savings_Q2
			,sum(case when Quarters='Q2' then Sum_transaction_count_savings  END) Sum_transaction_count_savings_Q2
			,sum(case when Quarters='Q2' then Sum_transaction_amount_savings  END) Sum_transaction_amount_savings_Q2
			,sum(case when Quarters='Q2' then Avg_transaction_amount_savings  END) Avg_transaction_amount_savings_Q2

			,sum(case when Quarters='Q3' then Sum_LASTDIVAMOUNT_savings   END) Sum_LASTDIVAMOUNT_savings_Q3
			,sum(case when Quarters='Q3' then Avg_Month_end_balance_savings  END) Avg_Month_end_balance_savings_Q3
			,sum(case when Quarters='Q3' then sum_Month_end_balance_savings  END) sum_Month_end_balance_savings_Q3
			,sum(case when Quarters='Q3' then AVG_balancechange_savings  END) AVG_balancechange_savings_Q3
			,sum(case when Quarters='Q3' then avg_Deposited_amount_savings  END) avg_Deposited_amount_savings_Q3
			,sum(case when Quarters='Q3' then avg_Deposited_count_savings  END) avg_Deposited_count_savings_Q3
			,sum(case when Quarters='Q3' then avg_withdrawal_amount_savings  END) avg_withdrawal_amount_savings_Q3
			,sum(case when Quarters='Q3' then Avg_withdrawal_count_savings  END) Avg_withdrawal_count_savings_Q3
			,sum(case when Quarters='Q3' then Sum_transaction_count_savings  END) Sum_transaction_count_savings_Q3
			,sum(case when Quarters='Q3' then Sum_transaction_amount_savings  END) Sum_transaction_amount_savings_Q3
			,sum(case when Quarters='Q3' then Avg_transaction_amount_savings  END) Avg_transaction_amount_savings_Q3


			,sum(case when Quarters='Q4' then Sum_LASTDIVAMOUNT_savings   END) Sum_LASTDIVAMOUNT_savings_Q4
			,sum(case when Quarters='Q4' then Avg_Month_end_balance_savings  END) Avg_Month_end_balance_savings_Q4
			,sum(case when Quarters='Q4' then sum_Month_end_balance_savings  END) sum_Month_end_balance_savings_Q4
			,sum(case when Quarters='Q4' then AVG_balancechange_savings  END) AVG_balancechange_savings_Q4
			,sum(case when Quarters='Q4' then avg_Deposited_amount_savings  END) avg_Deposited_amount_savings_Q4
			,sum(case when Quarters='Q4' then avg_Deposited_count_savings  END) avg_Deposited_count_savings_Q4
			,sum(case when Quarters='Q4' then avg_withdrawal_amount_savings  END) avg_withdrawal_amount_savings_Q4
			,sum(case when Quarters='Q4' then Avg_withdrawal_count_savings  END) Avg_withdrawal_count_savings_Q4
			,sum(case when Quarters='Q4' then Sum_transaction_count_savings  END) Sum_transaction_count_savings_Q4
			,sum(case when Quarters='Q4' then Sum_transaction_amount_savings  END) Sum_transaction_amount_savings_Q4
			,sum(case when Quarters='Q4' then Avg_transaction_amount_savings  END) Avg_transaction_amount_savings_Q4


			,sum(case when Quarters='Staticpool' then Sum_LASTDIVAMOUNT_savings   END) Sum_LASTDIVAMOUNT_savings_Staticpool
			,sum(case when Quarters='Staticpool' then Avg_Month_end_balance_savings  END) Avg_Month_end_balance_savings_Staticpool
			,sum(case when Quarters='Staticpool' then sum_Month_end_balance_savings  END) sum_Month_end_balance_savings_Staticpool
			,sum(case when Quarters='Staticpool' then AVG_balancechange_savings  END) AVG_balancechange_savings_Staticpool
			,sum(case when Quarters='Staticpool' then avg_Deposited_amount_savings  END) avg_Deposited_amount_savings_Staticpool
			,sum(case when Quarters='Staticpool' then avg_Deposited_count_savings  END) avg_Deposited_count_savings_Staticpool
			,sum(case when Quarters='Staticpool' then avg_withdrawal_amount_savings  END) avg_withdrawal_amount_savings_Staticpool
			,sum(case when Quarters='Staticpool' then Avg_withdrawal_count_savings  END) Avg_withdrawal_count_savings_Staticpool
			,sum(case when Quarters='Staticpool' then Sum_transaction_count_savings  END) Sum_transaction_count_savings_Staticpool
			,sum(case when Quarters='Staticpool' then Sum_transaction_amount_savings  END) Sum_transaction_amount_savings_Staticpool
			,sum(case when Quarters='Staticpool' then Avg_transaction_amount_savings  END) avg_transaction_amount_savings_Staticpool
		 

		from
		(
		select 
		SSN,Quarters,sum(LASTDIVAMOUNT) Sum_LASTDIVAMOUNT_savings
		,avg(Month_end_balance) Avg_Month_end_balance_savings
		,sum(Month_end_balance) sum_Month_end_balance_savings
		,avg(AVG_BALANCECHANGE) AVG_balancechange_savings
		,sum(transaction_count) Sum_transaction_count_savings
		,sum(transaction_amount) Sum_transaction_amount_savings
		,avg(transaction_amount) Avg_transaction_amount_savings
		,avg(Deposited_amount) avg_Deposited_amount_savings
		,avg(Deposited_count) avg_Deposited_count_savings
		,avg(withdrawal_amount) avg_withdrawal_amount_savings
		,avg(withdrawal_count) Avg_withdrawal_count_savings
		,max(StaticPool_Saving_flag) StaticPool_Saving_flag
		from #Saving_account_data 
		group by ssn,Quarters ) AA
		left join 
		(		
		select SSN,count(distinct UNID) Total_No_Account_Savings,count(distinct type) Total_type_account_Savings
		,min(Open_date) opendate_Savings,max(CLOSE_DATE) CLOSEDATE_Savings
		,max(MOB) MOB_Savings,min(OPEN_DATE) OPEN_DATE_Savings,max(Close_date) Closed_date_Savings
		,max(CHARGEOFFDATE) CHARGEOFFDATE_Savings
		,max(CHARGEOFFAMOUNT) CHARGEOFFAMOUNT_Savings 
		 from
		#Saving_account_data
		group by SSN
		) AB
		on aa.SSN=ab.SSN
		group by aa.SSN,ab.Total_No_Account_Savings,Total_type_account_Savings
		,opendate_Savings,Closed_date_Savings,MOB_Savings,OPEN_DATE_Savings,Closed_date_Savings
		,CHARGEOFFDATE_Savings,CHARGEOFFAMOUNT_Savings)  R
		ON AA.SSN=R.SSN17

		-- drop table if exists Money Market
		Left join
		(
		select aa.SSN SSN18,ab.Total_No_Account_Money_Market,Total_type_account_Money_Market
		,opendate_Money_Market,MOB_Money_Market,OPEN_DATE_Money_Market,Closed_date_Money_Market
		,CHARGEOFFDATE_Money_Market,CHARGEOFFAMOUNT_Money_Market,max(StaticPool_Money_market_flag) StaticPool_Money_market_flag
		,Sum(case when Quarters='Q1' then sum_Month_end_balance_Money_Market End)-
		Sum(case when Quarters='Q2' then sum_Month_end_balance_Money_Market End) Diff_Month_end_balance_Money_Market_Q1_Q2
		,Sum(case when Quarters='Q1' then sum_Month_end_balance_Money_Market End)-
		Sum(case when Quarters='Q4' then sum_Month_end_balance_Money_Market End) Diff_Month_end_balance_Money_Market_Q1_Q4
		,Sum(case when Quarters='Q1' then Sum_LASTDIVAMOUNT_Money_Market End) Sum_LASTDIVAMOUNT_Money_Market_Q1
		,Sum(case when Quarters='Q1' then Avg_Month_end_balance_Money_Market End) Avg_Month_end_balance_Money_Market_Q1
		,Sum(case when Quarters='Q1' then sum_Month_end_balance_Money_Market End) sum_Month_end_balance_Money_Market_Q1
		,Sum(case when Quarters='Q1' then Sum_transaction_count_Money_Market End) Sum_transaction_count_Money_Market_Q1
		,Sum(case when Quarters='Q1' then Sum_transaction_amount_Money_Market End) Sum_transaction_amount_Money_Market_Q1
		,Sum(case when Quarters='Q1' then Avg_transaction_amount_Money_Market End) Avg_transaction_amount_Money_Market_Q1
		,Sum(case when Quarters='Q1' then AVG_balancechange_Money_Market End) AVG_balancechange_Money_Market_Q1
		,Sum(case when Quarters='Q1' then avg_Deposited_amount_Money_Market End) avg_Deposited_amount_Money_Market_Q1
		,Sum(case when Quarters='Q1' then avg_Deposited_count_Money_Market End) avg_Deposited_count_Money_Market_Q1
		,Sum(case when Quarters='Q1' then avg_withdrawal_amount_Money_Market End) avg_withdrawal_amount_Money_Market_Q1
		,Sum(case when Quarters='Q1' then Avg_withdrawal_count_Money_Market End) Avg_withdrawal_count_Money_Market_Q1


		,Sum(case when Quarters='Q2' then Sum_LASTDIVAMOUNT_Money_Market End) Sum_LASTDIVAMOUNT_Money_Market_Q2
			,Sum(case when Quarters='Q2' then Avg_Month_end_balance_Money_Market End) Avg_Month_end_balance_Money_Market_Q2
			,Sum(case when Quarters='Q2' then sum_Month_end_balance_Money_Market End) sum_Month_end_balance_Money_Market_Q2
			,Sum(case when Quarters='Q2' then Sum_transaction_count_Money_Market End) Sum_transaction_count_Money_Market_Q2
			,Sum(case when Quarters='Q2' then Sum_transaction_amount_Money_Market End) Sum_transaction_amount_Money_Market_Q2
			,Sum(case when Quarters='Q2' then Avg_transaction_amount_Money_Market End) Avg_transaction_amount_Money_Market_Q2
			,Sum(case when Quarters='Q2' then AVG_balancechange_Money_Market End) AVG_balancechange_Money_Market_Q2
			,Sum(case when Quarters='Q2' then avg_Deposited_amount_Money_Market End) avg_Deposited_amount_Money_Market_Q2
			,Sum(case when Quarters='Q2' then avg_Deposited_count_Money_Market End) avg_Deposited_count_Money_Market_Q2
			,Sum(case when Quarters='Q2' then avg_withdrawal_amount_Money_Market End) avg_withdrawal_amount_Money_Market_Q2
			,Sum(case when Quarters='Q2' then Avg_withdrawal_count_Money_Market End) Avg_withdrawal_count_Money_Market_Q2


			,Sum(case when Quarters='Q3' then Sum_LASTDIVAMOUNT_Money_Market End) Sum_LASTDIVAMOUNT_Money_Market_Q3
			,Sum(case when Quarters='Q3' then Avg_Month_end_balance_Money_Market End) Avg_Month_end_balance_Money_Market_Q3
			,Sum(case when Quarters='Q3' then sum_Month_end_balance_Money_Market End) sum_Month_end_balance_Money_Market_Q3
			,Sum(case when Quarters='Q3' then Sum_transaction_count_Money_Market End) Sum_transaction_count_Money_Market_Q3
			,Sum(case when Quarters='Q3' then Sum_transaction_amount_Money_Market End) Sum_transaction_amount_Money_Market_Q3
			,Sum(case when Quarters='Q3' then Avg_transaction_amount_Money_Market End) Avg_transaction_amount_Money_Market_Q3
			,Sum(case when Quarters='Q3' then AVG_balancechange_Money_Market End) AVG_balancechange_Money_Market_Q3
			,Sum(case when Quarters='Q3' then avg_Deposited_amount_Money_Market End) avg_Deposited_amount_Money_Market_Q3
			,Sum(case when Quarters='Q3' then avg_Deposited_count_Money_Market End) avg_Deposited_count_Money_Market_Q3
			,Sum(case when Quarters='Q3' then avg_withdrawal_amount_Money_Market End) avg_withdrawal_amount_Money_Market_Q3
			,Sum(case when Quarters='Q3' then Avg_withdrawal_count_Money_Market End) Avg_withdrawal_count_Money_Market_Q3


			,Sum(case when Quarters='Q4' then Sum_LASTDIVAMOUNT_Money_Market End) Sum_LASTDIVAMOUNT_Money_Market_Q4
			,Sum(case when Quarters='Q4' then Avg_Month_end_balance_Money_Market End) Avg_Month_end_balance_Money_Market_Q4
			,Sum(case when Quarters='Q4' then sum_Month_end_balance_Money_Market End) sum_Month_end_balance_Money_Market_Q4
			,Sum(case when Quarters='Q4' then Sum_transaction_count_Money_Market End) Sum_transaction_count_Money_Market_Q4
			,Sum(case when Quarters='Q4' then Sum_transaction_amount_Money_Market End) Sum_transaction_amount_Money_Market_Q4
			,Sum(case when Quarters='Q4' then Avg_transaction_amount_Money_Market End) Avg_transaction_amount_Money_Market_Q4
			,Sum(case when Quarters='Q4' then AVG_balancechange_Money_Market End) AVG_balancechange_Money_Market_Q4
			,Sum(case when Quarters='Q4' then avg_Deposited_amount_Money_Market End) avg_Deposited_amount_Money_Market_Q4
			,Sum(case when Quarters='Q4' then avg_Deposited_count_Money_Market End) avg_Deposited_count_Money_Market_Q4
			,Sum(case when Quarters='Q4' then avg_withdrawal_amount_Money_Market End) avg_withdrawal_amount_Money_Market_Q4
			,Sum(case when Quarters='Q4' then Avg_withdrawal_count_Money_Market End) Avg_withdrawal_count_Money_Market_Q4

			
			,Sum(case when Quarters='Staticpool' then Sum_LASTDIVAMOUNT_Money_Market End) Sum_LASTDIVAMOUNT_Money_Market_Staticpool
			,Sum(case when Quarters='Staticpool' then Avg_Month_end_balance_Money_Market End) Avg_Month_end_balance_Money_Market_Staticpool
			,Sum(case when Quarters='Staticpool' then sum_Month_end_balance_Money_Market End) sum_Month_end_balance_Money_Market_Staticpool
			,Sum(case when Quarters='Staticpool' then Sum_transaction_count_Money_Market End) Sum_transaction_count_Money_Market_Staticpool
			,Sum(case when Quarters='Staticpool' then Sum_transaction_amount_Money_Market End) Sum_transaction_amount_Money_Market_Staticpool
			,Sum(case when Quarters='Staticpool' then Avg_transaction_amount_Money_Market End) Avg_transaction_amount_Money_Market_Staticpool
			,Sum(case when Quarters='Staticpool' then AVG_balancechange_Money_Market End) AVG_balancechange_Money_Market_Staticpool
			,Sum(case when Quarters='Staticpool' then avg_Deposited_amount_Money_Market End) avg_Deposited_amount_Money_Market_Staticpool
			,Sum(case when Quarters='Staticpool' then avg_Deposited_count_Money_Market End) avg_Deposited_count_Money_Market_Staticpool
			,Sum(case when Quarters='Staticpool' then avg_withdrawal_amount_Money_Market End) avg_withdrawal_amount_Money_Market_Staticpool
			,Sum(case when Quarters='Staticpool' then Avg_withdrawal_count_Money_Market End) Avg_withdrawal_count_Money_Market_Staticpool

			
		from
		(
		select 
		SSN,Quarters,sum(LASTDIVAMOUNT) Sum_LASTDIVAMOUNT_Money_Market
		,avg(Month_end_balance) Avg_Month_end_balance_Money_Market
		,sum(Month_end_balance) sum_Month_end_balance_Money_Market
		,sum(transaction_count) Sum_transaction_count_Money_Market
		,sum(transaction_amount) Sum_transaction_amount_Money_Market
		,avg(transaction_amount) avg_transaction_amount_Money_Market
		,avg(AVG_BALANCECHANGE) AVG_balancechange_Money_Market
		,avg(Deposited_amount) avg_Deposited_amount_Money_Market
		,avg(Deposited_count) avg_Deposited_count_Money_Market
		,avg(withdrawal_amount) avg_withdrawal_amount_Money_Market
		,avg(withdrawal_count) Avg_withdrawal_count_Money_Market
		,max(StaticPool_Money_market_flag) StaticPool_Money_market_flag
		 from  #Money_Market_account_data 
		group by ssn,Quarters ) AA
		left join 
		(		
		select SSN,count(distinct UNID) Total_No_Account_Money_Market,count(distinct type) Total_type_account_Money_Market
		,min(OPEN_DATE) opendate_Money_Market,max(CLOSE_DATE) CLOSEDATE_Money_Market
		,max(MOB) MOB_Money_Market,min(OPEN_DATE) OPEN_DATE_Money_Market,max(Close_date) Closed_date_Money_Market
		,max(CHARGEOFFDATE) CHARGEOFFDATE_Money_Market
		,max(CHARGEOFFAMOUNT) CHARGEOFFAMOUNT_Money_Market 
		 from
		#Money_Market_account_data
		group by SSN
		) AB
		on aa.SSN=ab.SSN
		group by aa.SSN,ab.Total_No_Account_Money_Market,Total_type_account_Money_Market
		,opendate_Money_Market,Closed_date_Money_Market,MOB_Money_Market,OPEN_DATE_Money_Market,Closed_date_Money_Market
		,CHARGEOFFDATE_Money_Market,CHARGEOFFAMOUNT_Money_Market) S

		ON AA.SSN=S.SSN18

		-- drop table if exists #Certificates
		
		Left join (
		select aa.SSN SSN19,ab.Total_No_Account_Certificates,Total_type_account_Certificates
		,opendate_Certificates,MOB_Certificates,OPEN_DATE_Certificates,Closed_date_Certificates
		,CHARGEOFFDATE_Certificates,CHARGEOFFAMOUNT_Certificates,max(Staticpool_Certificates_flag) Staticpool_Certificates_flag
		,Sum(case when Quarters='Q1' then sum_Month_end_balance_Certificates End)-
		Sum(case when Quarters='Q2' then sum_Month_end_balance_Certificates End) Diff_Month_end_balance_Certificates_Q1_Q2
		,Sum(case when Quarters='Q1' then sum_Month_end_balance_Certificates End)-
		Sum(case when Quarters='Q4' then sum_Month_end_balance_Certificates End) Diff_Month_end_balance_Certificates_Q1_Q4
		,Sum(case when Quarters='Q1' then Sum_LASTDIVAMOUNT_Certificates End) Sum_LASTDIVAMOUNT_Certificates_Q1
		,Sum(case when Quarters='Q1' then Avg_Month_end_balance_Certificates End) Avg_Month_end_balance_Certificates_Q1
		,Sum(case when Quarters='Q1' then sum_Month_end_balance_Certificates End) sum_Month_end_balance_Certificates_Q1
		,Sum(case when Quarters='Q1' then sum_COURTESYPAYMONTHTODATE_Certificates End) sum_COURTESYPAYMONTHTODATE_Certificates_Q1
		,Sum(case when Quarters='Q1' then sum_NSFMONTHTODATE_Certificates End) sum_NSFMONTHTODATE_Certificates_Q1
		,Sum(case when Quarters='Q1' then sum_OVERDRAFTFEEYTD_Certificates End) sum_OVERDRAFTFEEYTD_Certificates_Q1
		,Sum(case when Quarters='Q1' then sum_FEECOUNT1_Certificates End) sum_FEECOUNT1_Certificates_Q1
		,Sum(case when Quarters='Q1' then sum_FEECOUNT2_Certificates End) sum_FEECOUNT2_Certificates_Q1
		,Sum(case when Quarters='Q1' then Sum_transaction_count_Certificates End) Sum_transaction_count_Certificates_Q1
		,Sum(case when Quarters='Q1' then Sum_transaction_amount_Certificates End) Sum_transaction_amount_Certificates_Q1
		,Sum(case when Quarters='Q1' then Avg_transaction_amount_Certificates End) Avg_transaction_amount_Certificates_Q1
		,Sum(case when Quarters='Q1' then AVG_balancechange_Certificates End) AVG_balancechange_Certificates_Q1
		,Sum(case when Quarters='Q1' then avg_Deposited_amount_Certificates End) avg_Deposited_amount_Certificates_Q1
		,Sum(case when Quarters='Q1' then avg_Deposited_count_Certificates End) avg_Deposited_count_Certificates_Q1
		,Sum(case when Quarters='Q1' then avg_withdrawal_amount_Certificates End) avg_withdrawal_amount_Certificates_Q1
		,Sum(case when Quarters='Q1' then Avg_withdrawal_count_Certificates End) Avg_withdrawal_count_Certificates_Q1


		,Sum(case when Quarters='Q2' then Sum_LASTDIVAMOUNT_Certificates End) Sum_LASTDIVAMOUNT_Certificates_Q2
			,Sum(case when Quarters='Q2' then Avg_Month_end_balance_Certificates End) Avg_Month_end_balance_Certificates_Q2
			,Sum(case when Quarters='Q2' then sum_Month_end_balance_Certificates End) sum_Month_end_balance_Certificates_Q2
			,Sum(case when Quarters='Q2' then sum_COURTESYPAYMONTHTODATE_Certificates End) sum_COURTESYPAYMONTHTODATE_Certificates_Q2
			,Sum(case when Quarters='Q2' then sum_NSFMONTHTODATE_Certificates End) sum_NSFMONTHTODATE_Certificates_Q2
			,Sum(case when Quarters='Q2' then sum_OVERDRAFTFEEYTD_Certificates End) sum_OVERDRAFTFEEYTD_Certificates_Q2
			,Sum(case when Quarters='Q2' then sum_FEECOUNT1_Certificates End) sum_FEECOUNT1_Certificates_Q2
			,Sum(case when Quarters='Q2' then sum_FEECOUNT2_Certificates End) sum_FEECOUNT2_Certificates_Q2
			,Sum(case when Quarters='Q2' then Sum_transaction_count_Certificates End) Sum_transaction_count_Certificates_Q2
			,Sum(case when Quarters='Q2' then Sum_transaction_amount_Certificates End) Sum_transaction_amount_Certificates_Q2
			,Sum(case when Quarters='Q2' then Avg_transaction_amount_Certificates End) Avg_transaction_amount_Certificates_Q2
			,Sum(case when Quarters='Q2' then AVG_balancechange_Certificates End) AVG_balancechange_Certificates_Q2
			,Sum(case when Quarters='Q2' then avg_Deposited_amount_Certificates End) avg_Deposited_amount_Certificates_Q2
			,Sum(case when Quarters='Q2' then avg_Deposited_count_Certificates End) avg_Deposited_count_Certificates_Q2
			,Sum(case when Quarters='Q2' then avg_withdrawal_amount_Certificates End) avg_withdrawal_amount_Certificates_Q2
			,Sum(case when Quarters='Q2' then Avg_withdrawal_count_Certificates End) Avg_withdrawal_count_Certificates_Q2


			,Sum(case when Quarters='Q3' then Sum_LASTDIVAMOUNT_Certificates End) Sum_LASTDIVAMOUNT_Certificates_Q3
			,Sum(case when Quarters='Q3' then Avg_Month_end_balance_Certificates End) Avg_Month_end_balance_Certificates_Q3
			,Sum(case when Quarters='Q3' then sum_Month_end_balance_Certificates End) sum_Month_end_balance_Certificates_Q3
			,Sum(case when Quarters='Q3' then sum_COURTESYPAYMONTHTODATE_Certificates End) sum_COURTESYPAYMONTHTODATE_Certificates_Q3
			,Sum(case when Quarters='Q3' then sum_NSFMONTHTODATE_Certificates End) sum_NSFMONTHTODATE_Certificates_Q3
			,Sum(case when Quarters='Q3' then sum_OVERDRAFTFEEYTD_Certificates End) sum_OVERDRAFTFEEYTD_Certificates_Q3
			,Sum(case when Quarters='Q3' then sum_FEECOUNT1_Certificates End) sum_FEECOUNT1_Certificates_Q3
			,Sum(case when Quarters='Q3' then sum_FEECOUNT2_Certificates End) sum_FEECOUNT2_Certificates_Q3
			,Sum(case when Quarters='Q3' then Sum_transaction_count_Certificates End) Sum_transaction_count_Certificates_Q3
			,Sum(case when Quarters='Q3' then Sum_transaction_amount_Certificates End) Sum_transaction_amount_Certificates_Q3
			,Sum(case when Quarters='Q3' then Avg_transaction_amount_Certificates End) Avg_transaction_amount_Certificates_Q3
			,Sum(case when Quarters='Q3' then AVG_balancechange_Certificates End) AVG_balancechange_Certificates_Q3
			,Sum(case when Quarters='Q3' then avg_Deposited_amount_Certificates End) avg_Deposited_amount_Certificates_Q3
			,Sum(case when Quarters='Q3' then avg_Deposited_count_Certificates End) avg_Deposited_count_Certificates_Q3
			,Sum(case when Quarters='Q3' then avg_withdrawal_amount_Certificates End) avg_withdrawal_amount_Certificates_Q3
			,Sum(case when Quarters='Q3' then Avg_withdrawal_count_Certificates End) Avg_withdrawal_count_Certificates_Q3


			,Sum(case when Quarters='Q4' then Sum_LASTDIVAMOUNT_Certificates End) Sum_LASTDIVAMOUNT_Certificates_Q4
			,Sum(case when Quarters='Q4' then Avg_Month_end_balance_Certificates End) Avg_Month_end_balance_Certificates_Q4
			,Sum(case when Quarters='Q4' then sum_Month_end_balance_Certificates End) sum_Month_end_balance_Certificates_Q4
			,Sum(case when Quarters='Q4' then sum_COURTESYPAYMONTHTODATE_Certificates End) sum_COURTESYPAYMONTHTODATE_Certificates_Q4
			,Sum(case when Quarters='Q4' then sum_NSFMONTHTODATE_Certificates End) sum_NSFMONTHTODATE_Certificates_Q4
			,Sum(case when Quarters='Q4' then sum_OVERDRAFTFEEYTD_Certificates End) sum_OVERDRAFTFEEYTD_Certificates_Q4
			,Sum(case when Quarters='Q4' then sum_FEECOUNT1_Certificates End) sum_FEECOUNT1_Certificates_Q4
			,Sum(case when Quarters='Q4' then sum_FEECOUNT2_Certificates End) sum_FEECOUNT2_Certificates_Q4
			,Sum(case when Quarters='Q4' then Sum_transaction_count_Certificates End) Sum_transaction_count_Certificates_Q4
			,Sum(case when Quarters='Q4' then Sum_transaction_amount_Certificates End) Sum_transaction_amount_Certificates_Q4
			,Sum(case when Quarters='Q4' then Avg_transaction_amount_Certificates End) Avg_transaction_amount_Certificates_Q4
			,Sum(case when Quarters='Q4' then AVG_balancechange_Certificates End) AVG_balancechange_Certificates_Q4
			,Sum(case when Quarters='Q4' then avg_Deposited_amount_Certificates End) avg_Deposited_amount_Certificates_Q4
			,Sum(case when Quarters='Q4' then avg_Deposited_count_Certificates End) avg_Deposited_count_Certificates_Q4
			,Sum(case when Quarters='Q4' then avg_withdrawal_amount_Certificates End) avg_withdrawal_amount_Certificates_Q4
			,Sum(case when Quarters='Q4' then Avg_withdrawal_count_Certificates End) Avg_withdrawal_count_Certificates_Q4

			
			,Sum(case when Quarters='Staticpool' then Sum_LASTDIVAMOUNT_Certificates End) Sum_LASTDIVAMOUNT_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then Avg_Month_end_balance_Certificates End) Avg_Month_end_balance_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then sum_Month_end_balance_Certificates End) sum_Month_end_balance_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then sum_COURTESYPAYMONTHTODATE_Certificates End) sum_COURTESYPAYMONTHTODATE_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then sum_NSFMONTHTODATE_Certificates End) sum_NSFMONTHTODATE_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then sum_OVERDRAFTFEEYTD_Certificates End) sum_OVERDRAFTFEEYTD_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then sum_FEECOUNT1_Certificates End) sum_FEECOUNT1_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then sum_FEECOUNT2_Certificates End) sum_FEECOUNT2_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then Sum_transaction_count_Certificates End) Sum_transaction_count_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then Sum_transaction_amount_Certificates End) Sum_transaction_amount_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then Avg_transaction_amount_Certificates End) Avg_transaction_amount_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then AVG_balancechange_Certificates End) AVG_balancechange_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then avg_Deposited_amount_Certificates End) avg_Deposited_amount_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then avg_Deposited_count_Certificates End) avg_Deposited_count_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then avg_withdrawal_amount_Certificates End) avg_withdrawal_amount_Certificates_Staticpool
			,Sum(case when Quarters='Staticpool' then Avg_withdrawal_count_Certificates End) Avg_withdrawal_count_Certificates_Staticpool

			
		from
		(
		select 
		SSN,Quarters,sum(LASTDIVAMOUNT) Sum_LASTDIVAMOUNT_Certificates
		,avg(Month_end_balance) Avg_Month_end_balance_Certificates
		,sum(Month_end_balance) sum_Month_end_balance_Certificates
		,sum(COURTESYPAYMONTHTODATE) sum_COURTESYPAYMONTHTODATE_Certificates
		,sum(NSFMONTHTODATE) sum_NSFMONTHTODATE_Certificates
		,sum(OVERDRAFTFEEYTD) sum_OVERDRAFTFEEYTD_Certificates
		,sum(FEECOUNT1) sum_FEECOUNT1_Certificates
		,sum(FEECOUNT2) sum_FEECOUNT2_Certificates
		,sum(transaction_count) Sum_transaction_count_Certificates
		,sum(transaction_amount) Sum_transaction_amount_Certificates
		,avg(transaction_amount) avg_transaction_amount_Certificates
		,avg(AVG_BALANCECHANGE) AVG_balancechange_Certificates
		,avg(Deposited_amount) avg_Deposited_amount_Certificates
		,avg(Deposited_count) avg_Deposited_count_Certificates
		,avg(withdrawal_amount) avg_withdrawal_amount_Certificates
		,avg(withdrawal_count) Avg_withdrawal_count_Certificates
		,max(Staticpool_Certificates_flag) Staticpool_Certificates_flag
		 from  #Certificates_account_data 
		group by ssn,Quarters ) AA
		left join 
		(		
		select SSN,count(distinct UNID) Total_No_Account_Certificates,count(distinct type) Total_type_account_Certificates
		,min(OPEN_DATE) opendate_Certificates,max(CLOSE_DATE) CLOSEDATE_Certificates
		,max(MOB) MOB_Certificates,min(OPEN_DATE) OPEN_DATE_Certificates,max(Close_date) Closed_date_Certificates
		,max(CHARGEOFFDATE) CHARGEOFFDATE_Certificates
		,max(CHARGEOFFAMOUNT) CHARGEOFFAMOUNT_Certificates 
		 from
		#Certificates_account_data
		group by SSN
		) AB
		on aa.SSN=ab.SSN
		group by aa.SSN,ab.Total_No_Account_Certificates,Total_type_account_Certificates
		,opendate_Certificates,Closed_date_Certificates,MOB_Certificates,OPEN_DATE_Certificates,Closed_date_Certificates
		,CHARGEOFFDATE_Certificates,CHARGEOFFAMOUNT_Certificates) T

		ON AA.SSN=T.SSN19

		-- drop table if exists #Checking
		Left join 
		(

		select aa.SSN SSN20,ab.Total_No_Account_Checkings,Total_type_account_Checkings
		,opendate_Checkings,MOB_Checkings,OPEN_DATE_Checkings,Closed_date_Checkings
		,CHARGEOFFDATE_Checkings,CHARGEOFFAMOUNT_Checkings
		,max(Staticpool_Checking_flag) Staticpool_Checking_flag
		,sum(case when Quarters='Q1' then sum_Month_end_balance_Checkings End)-
		sum(case when Quarters='Q2' then sum_Month_end_balance_Checkings End)  Diff_Month_end_balance_Checkings_Q1_Q2
		,sum(case when Quarters='Q1' then sum_Month_end_balance_Checkings End)-
		sum(case when Quarters='Q4' then sum_Month_end_balance_Checkings End)  Diff_Month_end_balance_Checkings_Q1_Q4
		,sum(case when Quarters='Q1' then Sum_LASTDIVAMOUNT_Checkings End) Sum_LASTDIVAMOUNT_Checkings_Q1
		,sum(case when Quarters='Q1' then Avg_Month_end_balance_Checkings End) Avg_Month_end_balance_Checkings_Q1
		,sum(case when Quarters='Q1' then sum_Month_end_balance_Checkings End) sum_Month_end_balance_Checkings_Q1
		,sum(case when Quarters='Q1' then sum_COURTESYPAYMONTHTODATE_checkings End) sum_COURTESYPAYMONTHTODATE_checkings_Q1
		,sum(case when Quarters='Q1' then sum_NSFMONTHTODATE_checkings End) sum_NSFMONTHTODATE_checkings_Q1
		,sum(case when Quarters='Q1' then sum_OVERDRAFTFEEYTD_checkings End) sum_OVERDRAFTFEEYTD_checkings_Q1
		,sum(case when Quarters='Q1' then sum_FEECOUNT1_checkings End) sum_FEECOUNT1_checkings_Q1
		,sum(case when Quarters='Q1' then sum_FEECOUNT2_checkings End) sum_FEECOUNT2_checkings_Q1
		,sum(case when Quarters='Q1' then Sum_transaction_count_checkings End) Sum_transaction_count_checkings_Q1
		,sum(case when Quarters='Q1' then Sum_transaction_amount_checkings End) Sum_transaction_amount_checkings_Q1
		,sum(case when Quarters='Q1' then Avg_transaction_amount_checkings End) Avg_transaction_amount_checkings_Q1
		,sum(case when Quarters='Q1' then AVG_balancechange_Checkings End) AVG_balancechange_Checkings_Q1
		,sum(case when Quarters='Q1' then avg_Deposited_amount_Checkings End) avg_Deposited_amount_Checkings_Q1
		,sum(case when Quarters='Q1' then avg_Deposited_count_Checkings End) avg_Deposited_count_Checkings_Q1
		,sum(case when Quarters='Q1' then avg_withdrawal_amount_Checkings End) avg_withdrawal_amount_Checkings_Q1
		,sum(case when Quarters='Q1' then Avg_withdrawal_count_Checkings End) Avg_withdrawal_count_Checkings_Q1


		,sum(case when Quarters='Q2' then Sum_LASTDIVAMOUNT_Checkings End) Sum_LASTDIVAMOUNT_Checkings_Q2
			,sum(case when Quarters='Q2' then Avg_Month_end_balance_Checkings End) Avg_Month_end_balance_Checkings_Q2
			,sum(case when Quarters='Q2' then sum_Month_end_balance_Checkings End) sum_Month_end_balance_Checkings_Q2
			,sum(case when Quarters='Q2' then sum_COURTESYPAYMONTHTODATE_checkings End) sum_COURTESYPAYMONTHTODATE_checkings_Q2
			,sum(case when Quarters='Q2' then sum_NSFMONTHTODATE_checkings End) sum_NSFMONTHTODATE_checkings_Q2
			,sum(case when Quarters='Q2' then sum_OVERDRAFTFEEYTD_checkings End) sum_OVERDRAFTFEEYTD_checkings_Q2
			,sum(case when Quarters='Q2' then sum_FEECOUNT1_checkings End) sum_FEECOUNT1_checkings_Q2
			,sum(case when Quarters='Q2' then sum_FEECOUNT2_checkings End) sum_FEECOUNT2_checkings_Q2
			,sum(case when Quarters='Q2' then Sum_transaction_count_checkings End) Sum_transaction_count_checkings_Q2
			,sum(case when Quarters='Q2' then Sum_transaction_amount_checkings End) Sum_transaction_amount_checkings_Q2
			,sum(case when Quarters='Q2' then Avg_transaction_amount_checkings End) Avg_transaction_amount_checkings_Q2
			,sum(case when Quarters='Q2' then AVG_balancechange_Checkings End) AVG_balancechange_Checkings_Q2
			,sum(case when Quarters='Q2' then avg_Deposited_amount_Checkings End) avg_Deposited_amount_Checkings_Q2
			,sum(case when Quarters='Q2' then avg_Deposited_count_Checkings End) avg_Deposited_count_Checkings_Q2
			,sum(case when Quarters='Q2' then avg_withdrawal_amount_Checkings End) avg_withdrawal_amount_Checkings_Q2
			,sum(case when Quarters='Q2' then Avg_withdrawal_count_Checkings End) Avg_withdrawal_count_Checkings_Q2


			,sum(case when Quarters='Q3' then Sum_LASTDIVAMOUNT_Checkings End) Sum_LASTDIVAMOUNT_Checkings_Q3
			,sum(case when Quarters='Q3' then Avg_Month_end_balance_Checkings End) Avg_Month_end_balance_Checkings_Q3
			,sum(case when Quarters='Q3' then sum_Month_end_balance_Checkings End) sum_Month_end_balance_Checkings_Q3
			,sum(case when Quarters='Q3' then sum_COURTESYPAYMONTHTODATE_checkings End) sum_COURTESYPAYMONTHTODATE_checkings_Q3
			,sum(case when Quarters='Q3' then sum_NSFMONTHTODATE_checkings End) sum_NSFMONTHTODATE_checkings_Q3
			,sum(case when Quarters='Q3' then sum_OVERDRAFTFEEYTD_checkings End) sum_OVERDRAFTFEEYTD_checkings_Q3
			,sum(case when Quarters='Q3' then sum_FEECOUNT1_checkings End) sum_FEECOUNT1_checkings_Q3
			,sum(case when Quarters='Q3' then sum_FEECOUNT2_checkings End) sum_FEECOUNT2_checkings_Q3
			,sum(case when Quarters='Q3' then Sum_transaction_count_checkings End) Sum_transaction_count_checkings_Q3
			,sum(case when Quarters='Q3' then Sum_transaction_amount_checkings End) Sum_transaction_amount_checkings_Q3
			,sum(case when Quarters='Q3' then Avg_transaction_amount_checkings End) Avg_transaction_amount_checkings_Q3
			,sum(case when Quarters='Q3' then AVG_balancechange_Checkings End) AVG_balancechange_Checkings_Q3
			,sum(case when Quarters='Q3' then avg_Deposited_amount_Checkings End) avg_Deposited_amount_Checkings_Q3
			,sum(case when Quarters='Q3' then avg_Deposited_count_Checkings End) avg_Deposited_count_Checkings_Q3
			,sum(case when Quarters='Q3' then avg_withdrawal_amount_Checkings End) avg_withdrawal_amount_Checkings_Q3
			,sum(case when Quarters='Q3' then Avg_withdrawal_count_Checkings End) Avg_withdrawal_count_Checkings_Q3


			,sum(case when Quarters='Q4' then Sum_LASTDIVAMOUNT_Checkings End) Sum_LASTDIVAMOUNT_Checkings_Q4
			,sum(case when Quarters='Q4' then Avg_Month_end_balance_Checkings End) Avg_Month_end_balance_Checkings_Q4
			,sum(case when Quarters='Q4' then sum_Month_end_balance_Checkings End) sum_Month_end_balance_Checkings_Q4
			,sum(case when Quarters='Q4' then sum_COURTESYPAYMONTHTODATE_checkings End) sum_COURTESYPAYMONTHTODATE_checkings_Q4
			,sum(case when Quarters='Q4' then sum_NSFMONTHTODATE_checkings End) sum_NSFMONTHTODATE_checkings_Q4
			,sum(case when Quarters='Q4' then sum_OVERDRAFTFEEYTD_checkings End) sum_OVERDRAFTFEEYTD_checkings_Q4
			,sum(case when Quarters='Q4' then sum_FEECOUNT1_checkings End) sum_FEECOUNT1_checkings_Q4
			,sum(case when Quarters='Q4' then sum_FEECOUNT2_checkings End) sum_FEECOUNT2_checkings_Q4
			,sum(case when Quarters='Q4' then Sum_transaction_count_checkings End) Sum_transaction_count_checkings_Q4
			,sum(case when Quarters='Q4' then Sum_transaction_amount_checkings End) Sum_transaction_amount_checkings_Q4
			,sum(case when Quarters='Q4' then Avg_transaction_amount_checkings End) Avg_transaction_amount_checkings_Q4
			,sum(case when Quarters='Q4' then AVG_balancechange_Checkings End) AVG_balancechange_Checkings_Q4
			,sum(case when Quarters='Q4' then avg_Deposited_amount_Checkings End) avg_Deposited_amount_Checkings_Q4
			,sum(case when Quarters='Q4' then avg_Deposited_count_Checkings End) avg_Deposited_count_Checkings_Q4
			,sum(case when Quarters='Q4' then avg_withdrawal_amount_Checkings End) avg_withdrawal_amount_Checkings_Q4
			,sum(case when Quarters='Q4' then Avg_withdrawal_count_Checkings End) Avg_withdrawal_count_Checkings_Q4

			
			,sum(case when Quarters='Staticpool' then Sum_LASTDIVAMOUNT_Checkings End) Sum_LASTDIVAMOUNT_Checkings_Staticpool
			,sum(case when Quarters='Staticpool' then Avg_Month_end_balance_Checkings End) Avg_Month_end_balance_Checkings_Staticpool
			,sum(case when Quarters='Staticpool' then sum_Month_end_balance_Checkings End) sum_Month_end_balance_Checkings_Staticpool
			,sum(case when Quarters='Staticpool' then sum_COURTESYPAYMONTHTODATE_checkings End) sum_COURTESYPAYMONTHTODATE_checkings_Staticpool
			,sum(case when Quarters='Staticpool' then sum_NSFMONTHTODATE_checkings End) sum_NSFMONTHTODATE_checkings_Staticpool
			,sum(case when Quarters='Staticpool' then sum_OVERDRAFTFEEYTD_checkings End) sum_OVERDRAFTFEEYTD_checkings_Staticpool
			,sum(case when Quarters='Staticpool' then sum_FEECOUNT1_checkings End) sum_FEECOUNT1_checkings_Staticpool
			,sum(case when Quarters='Staticpool' then sum_FEECOUNT2_checkings End) sum_FEECOUNT2_checkings_Staticpool
			,sum(case when Quarters='Staticpool' then Sum_transaction_count_checkings End) Sum_transaction_count_checkings_Staticpool
			,sum(case when Quarters='Staticpool' then Sum_transaction_amount_checkings End) Sum_transaction_amount_checkings_Staticpool
			,sum(case when Quarters='Staticpool' then Avg_transaction_amount_checkings End) Avg_transaction_amount_checkings_Staticpool
			,sum(case when Quarters='Staticpool' then AVG_balancechange_Checkings End) AVG_balancechange_Checkings_Staticpool
			,sum(case when Quarters='Staticpool' then avg_Deposited_amount_Checkings End) avg_Deposited_amount_Checkings_Staticpool
			,sum(case when Quarters='Staticpool' then avg_Deposited_count_Checkings End) avg_Deposited_count_Checkings_Staticpool
			,sum(case when Quarters='Staticpool' then avg_withdrawal_amount_Checkings End) avg_withdrawal_amount_Checkings_Staticpool
			,sum(case when Quarters='Staticpool' then Avg_withdrawal_count_Checkings End) Avg_withdrawal_count_Checkings_Staticpool

			
		from
		(
		select 
		SSN,Quarters,sum(LASTDIVAMOUNT) Sum_LASTDIVAMOUNT_Checkings
		,avg(Month_end_balance) Avg_Month_end_balance_Checkings
		,sum(Month_end_balance) sum_Month_end_balance_Checkings
		,sum(COURTESYPAYMONTHTODATE) sum_COURTESYPAYMONTHTODATE_checkings
		,sum(NSFMONTHTODATE) sum_NSFMONTHTODATE_checkings
		,sum(OVERDRAFTFEEYTD) sum_OVERDRAFTFEEYTD_checkings
		,sum(FEECOUNT1) sum_FEECOUNT1_checkings
		,sum(FEECOUNT2) sum_FEECOUNT2_checkings
		,sum(transaction_count) Sum_transaction_count_checkings
		,sum(transaction_amount) Sum_transaction_amount_checkings
		,avg(transaction_amount) avg_transaction_amount_checkings
		,avg(AVG_BALANCECHANGE) AVG_balancechange_Checkings
		,avg(Deposited_amount) avg_Deposited_amount_Checkings
		,avg(Deposited_count) avg_Deposited_count_Checkings
		,avg(withdrawal_amount) avg_withdrawal_amount_Checkings
		,avg(withdrawal_count) Avg_withdrawal_count_Checkings
		,max(Staticpool_Checking_flag) Staticpool_Checking_flag
		 from  #Checkings_account_data 
		group by ssn,Quarters ) AA
		left join 
		(		
		select SSN,count(distinct UNID) Total_No_Account_Checkings,count(distinct type) Total_type_account_Checkings
		,min(OPEN_DATE) opendate_Checkings,max(CLOSE_DATE) CLOSEDATE_Checkings
		,max(MOB) MOB_Checkings,min(OPEN_DATE) OPEN_DATE_Checkings,max(Close_date) Closed_date_Checkings
		,max(CHARGEOFFDATE) CHARGEOFFDATE_Checkings
		,max(CHARGEOFFAMOUNT) CHARGEOFFAMOUNT_Checkings 
		 from
		#Checkings_account_data
		group by SSN
		) AB
		on aa.SSN=ab.SSN
		group by aa.SSN,ab.Total_No_Account_Checkings,Total_type_account_Checkings
		,opendate_Checkings,Closed_date_Checkings,MOB_Checkings,OPEN_DATE_Checkings,Closed_date_Checkings
		,CHARGEOFFDATE_Checkings,CHARGEOFFAMOUNT_Checkings) U
		ON AA.SSN=U.SSN20
		left join #Loan_target_variable V
		ON AA.SSN=V.SSN21
		left join #desposit_Target_variable W
		on aa.SSN=W.ssn22
		left join #Credit_Card_data X
		on aa.ssn=x.SSN_CC
		
		left join #CC_Target_Flag Y
		on aa.ssn=y.cc_ssn
		left join #Loan_product_summary Z
		on aa.ssn=z.SSN000
		left join #Deposit_summary ZZ
		on aa.ssn=zz.ssn00
		order by aa.SSN

		end 

select * from  [AE_EDW].[tempods].[S_CRMApplicationType] a
select  * from  [AE_EDW].[tempods].[S_CRMProductType] where  ProductName like '%money%'  or ProductName like '% MM %'

		select *	from [AE_EDW].[tempods].[S_CRMProductType] a
		left join [AE_EDW].[tempods].[S_CRMApplicationType] b
				on a.ApplicationTypeID=b.ApplicationTypeID

select * from #groupproducttype_Deposits0


drop table if exists #groupproducttype_Deposits0
	select *
	,case when ProductName like '%money%'  or ProductName like '% MM %' then 'MoneyMarket'
	when ProductName='Youth Savings' and ApplicationDescription='Certificates' then 'Savings'
	when ProductCode=0 and ApplicationDescription='Certificates' then 'Savings'
	when ProductName='40 Month CD' and ApplicationDescription='Certificates' then 'Checking'
	when ProductName='Certificate' and ApplicationDescription='Certificates' then 'Checking' 
	when ProductName='Public Funds' and ApplicationDescription='Certificates' then 'Certificates'  
		else ApplicationDescription end Product_Group_wise
	into #groupproducttype_Deposits0
	from
		(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName,ApplicationDescription,ApplicationTableName
			from [AE_EDW].[tempods].[S_CRMProductType] a
		left join [AE_EDW].[tempods].[S_CRMApplicationType] b
		on a.ApplicationTypeID=b.ApplicationTypeID
		where ApplicationDescription is not null and ProductName!='IRA Savings'
		and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a order by ProductCode

select * from  #groupproducttype_Deposits0 where ProductName = '28'



select processdate,datefromparts(left(processdate,4),right(left(processdate,6),2),right(processdate,2)) [Process Date] from arcusym000..SAVINGS

select top 14 CHARGEOFFDATE,FORMAT(CHARGEOFFDATE,'yyyymm') ,* from arcusym000..SAVINGS where CHARGEOFFDATE is not null

(
select * ,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v,left(ProcessDate,6) Process_Date
,datefromparts(left(processdate,4),right(left(processdate,6),2),right(processdate,2)) [Process Date] from arcusym000..SAVINGS
)


select * from INFORMATION_SCHEMA.COLUMNS
where TABLE_NAME = 'SAVINGS' and COLUMN_NAME = 'CHARGEOFFDATE'

Drop table if exists #savings_1
					select Distinct aa.ProcessDate,aa.PARENTACCOUNT,aa.ID,concat(aa.PARENTACCOUNT,aa.ID) UNID,b.SharePrimeNameSSN,aa.TYPE
					,aa.opendate,case when Open_date=Process_Date then 1 else 0 end Open_Acct_flag
					,case when Close_date=Process_Date then 1 else 0 end Close_Acct_flag,CHARGEOFFDATE,CHARGEOFFDATE_v CHARGEOFF_DATE
					,aa.Close_date,aa.Open_date,aa.closedate,aa.BALANCE,e.ProductName
					,e.Product_Group_wise,case when Lag_opendate=Open_date and Lag_Type!= Type then 1 else 0 end Account_swtich_flag
					,Bal_Flag,LASTDIVAMOUNT,DIVTYPE,DIVRATE
					into #savings_1
					from 
									(	select *,case when [EOM_Process Date]=[Process Date] then 1 else 0 end EOM_flag
									,case when closedate is null and balance=0 then 0 else 1 end Bal_Flag 
										,case when (closedate is null and CHARGEOFFDATE is null) or Process_Date=close_date 
										or Process_Date=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
										,case when OPEN_DATE=CLOSE_DATE then 0 else 1 end Funded_loan_flag
										,lag(Open_date,1) over (partition by Concat(parentaccount,id) order by processdate) Lag_opendate
										,lag(type,1) over (partition by Concat(parentaccount,id) order by processdate) Lag_Type
										from
											(select a.*,EOMONTH([Process Date]) [EOM_Process Date]
											,case when Process_Date=CHARGEOFFDATE_v then CHARGEOFFAMOUNT else 0 end CHARGEOFFAMOUNT_v
											,left(Convert(varchar(20),Closedate,112),6)  Close_date
											,left(convert(varchar(20),opendate,112),6) Open_date
											 from 
												 ( select * ,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
												 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v,left(ProcessDate,6) Process_Date
												,datefromparts(left(processdate,4),right(left(processdate,6),2),right(processdate,2)) [Process Date] from arcusym000..SAVINGS
												--where (chargeoffdate is null or chargeoffdate>='2020-01-01')
												) a
												where  ProcessDate in (select ProcessDate from #processdate)
											) F
								 ) aa
						left join #groupproducttype_Deposits0 E
						on e.ProductCode=aa.TYPE
						left join (select AccountNumber,ShareID,ProcessDate,SharePrimeNameSSN from ARCUSYM000.arcu.ARCUSharePrimeNames 
									group by AccountNumber,ShareID,ProcessDate,SharePrimeNameSSN) B on aa.PARENTACCOUNT=b.AccountNumber 
						and aa.id=b.ShareID and aa.ProcessDate=b.ProcessDate
						where Funded_loan_flag=1 and Open_Flag=1 and ProductName!='IRA Savings' 
						and Bal_Flag=1
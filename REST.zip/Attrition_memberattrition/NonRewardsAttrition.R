
rm(list=ls())

getwd()

library(RODBC)
databaseConnection <- odbcDriverConnect("Driver={SQL Server};server=10.200.102.244;database=Analytics")
Checking_Data <- sqlQuery(databaseConnection, "select  *  from Analytics..NonRewardsAttrition")
str(Checking_Data)
Checking_dataframe <- data.frame(Checking_Data,stringsAsFactors=FALSE)

Column_type <- sapply(Checking_dataframe,class)
write.csv(Column_type,"Columnnames.csv")
index_number <- colnames(Checking_dataframe)
write.csv(index_number,"index_number.csv")
Checking_dataframe_colnames<- colnames(Checking_dataframe)
#write.csv(Checking_dataframe_colnames,"Checking_dataframe_colnames.csv")
Checking_dataframe_1<- Checking_dataframe[,c(1,	2,	3,	4,	5,	6,	7,	8,	9,	10,	11,	12,	13,	14,	15,	16,	17,	18,	19,	20,	21,	22,	23,	24,	25,	26,	27,	28,	29,	30,	31,	32,	33,	34,	35,	36,	37,	38,	39,	40,	41,	42,	43,	44,	45,	46,	47,	48,	49,	50,	51,	52,	53,	54,	55,	56,	57,	58,	59,	60,	61,	62,	63,	64,	65,	66,	67,	68,	69,	70,	71,	72,	73,	74,	75,	76,	77,	78,	79,	80,	81,	82,	83,	84,	85,	86,	87,	88,	89,	90,	91,	92,	93,	94,	95,	96,	97,	98,	99,	100,	101,	102,	103,	104,	105,	106,	107,	108,	109,	110,	111,	112,	113,	114,	115,	116,	117,	118,	119,	120,	121,	122,	123,	124,	125,	126,	127,	128,	129,	130,	131,	132,	133,	134,	135,	136,	137,	138,	139,	140,	141,	142,	143,	144,	145,	146,	147,	148,	149,	150,
                                             151,	152,	153,	154,	155,	156,	157,	158,	159,	160,	161,	162,	163,	164,	165,	166,	167,	168,	169,	170,	171,	172,	173,	174,	175,	176,	177,	178,	179,	180,	181,	182,	183,	184,	185,	186,	187,	188,	189,	190,	191,	192,	193,	194,	195,	196,	197,	198,	199,	200,	201,	202,	203,	204,	205,	206,	207,	208,	209,	210,	211,	212,	213,	214,	215,	216,	217,	218,	219,	220,	221,	222,	223,	224,	225,	226,	227,	228,	229,	230,	231,	232,	233,	234,	235,	236,	237,	238,	239,	240,	241,	242,	243,	244,	245,	246,	247,	248,	249,	250,	251,	252,	253,	254,	255,	256,	257,	258,	259,	260,	261,	262,	263,	264,	265,	266,	267,	268,	269,	270,	271,	272,	273,	274,	275,	276,	277,	278,	279,	280,	281,	282,	283,	284,	285,	286,	287,	288,	289,	290,	291,	292,	293,	294,	295,	296,	297,	298,	299,	300,	301,	302,	303,	304,	305,	306,	307,	308,	309,	310,	311,	312,	313,	314,	315,	316,	317,	318,	319,	320,	321,	322,	323,	324,	325,	326,	327,	328,	329,	330,	331,	332,	333,	334,	335,	336,	337,	338,	339,	340,	341,	342,	343,	344,	345,	346,	347,	348,	349,	350,	351,	352,	353,	354,	355,	356,	357,	358,	359,	360,	361,	362,	363,	364,	365,	366,	367,	368,	369,	370,	371,	372,	373,	374,	375,	376,	377,	378,	379,	380,	381,	382,	383,	384,	385,	386,	387,	388,	389,	390,	391,	392,	393,	394,	395,	396,	397,	398,	399,	400,	401,	402,	403,	404,	405,	406,	407,	408,	409,	410,	411,	412,	413,	414,	415,	416,	417,	418,	419,	420,	421,	422,	423,	424,	425,	426,	427,	428,	429,	430,	431,	432,	433,	434,	435,	436,	437,	438,	439,	440,	441,	442,	443,	444,	445,	446,	447,	448,	449,	450,	451,	452,	453,	454,	455,	456,	457,	458,	459,	460,	461,	462,	463,	464,	465,	466,	467,	468,	469,	470,	471,	472,	473,	474,	475,	476,	477,	478,	479,	480,	481,	482,	483,	484,	485,	486,	487,	488,	489,	490,	491,	492,	493,	494,	495,	496,	497,	498,	499,	500,	501,	502,	503,	504,	505,	506,	507,	508,	509,	510,	511,	512,	513,	514,	515,	516,	517,	518,	519,	520,	521,	522,	523,	524,	525,	526,	527,	528,	529,	530,	531,	532,	533,	534,	535,	536,	537,	538,	539,	540,	541,	542,	543,	544,	545,	546,	547,	548,	549,	550,	551,	552,	553,	554,	555,	556,	557,	558,	559,	560,	561,	562,	563,	564,	565,	566,	567,	568,	569,	570,	571,	572,	573,	574,	575,	576,	577,	578,	579,	580,	581,	582,	583,	584,	585,	586,	587,	588,	589,	590,	591,	592,	593,	594,	595,	596,	597,	598,	599,	600,	601,	602,	603,	604,	605,	606,	607,	608,	609,	610,	611,	612,	613,	614,	615,	616,	617,	618,	619,	620,	621,	622,	623,	624,	625,	626,	627,	628,	629,	630,	631,	632,	633,	634,	635,	636,	637,	638,	639,	640,	641,	642,	643,	644,	645,	646,	647,	648,	649,	650,	651,	652,	653,	654,	655,	656,	657,	658,	659,	660,	661,	662,	663,	664,	665,	666,	667,	668,	669,	670,	671,	672,	673,	674,	675,	676,	677,	678,	679,	680,	681,	682,	683,	684,	685,	686,	687,	688,	689,	690,	691,	692,	693,	694,	695,	696,	697,	698,	699,	700,	701,	702,	703,	704,	705,	706,	707,	708,	709,	710,	711,	712,	713,	714,	715,	716,	717,	718,	719,	720,	721,	722,	723,	724,	725,	726,	727,	728,	729,	730,	731,	732,	733,	734,	735,	736,	737,	738,	739,	740,	741,	742,	743,	744,	745,	746,	747,	748,	749,	750,	751,	752,	753,	754,	755,	756,	757,	758,	759,	760,	761,	762,	763,	764,	765,	766,	767,	768,	769,	770,	771,	772,	773,	774,	775,	776,	777,	778,	779,	780,	781,	782,	783,	784,	785,	786,	787,	788,	789,	790,	791,	792,	793,	794,	795,	796,	797,	798,	799,	800,	801,	802,	803,	804,	805,	806,	807,	808,	809,	810,	811,	812,	813,	814,	815,	816,	817,
                                             818,	819,	820,	821,	822,	823,	824,	825,	826,	827,	828,	829,	830,	831,	832,	833,	834,	835,	836,	837,	838,	839,	840,	841,	842,	843,	844,	845,	846,	847,	848,	849,	850,	851,	852,	853,	854,	855,	856,	857,	858,	859,	860,	861,	862,	863,	864,	865,	866,	867,	868,	869,	870,	871,	872,	873,	874,	875,	876,	877,	878,	879,	880,	881,	882,	883,	884,	885,	886,	887,	888,	889,	890,	891,	892,	893,	894,	895,	896,	897,	898,	899,	900,	901,	902,	903,	904,	905,	906,	907,	908,	909,	910,	911,	912,	913,	914,	915,	916,	917,	918,	919,	920,	921,	922,	923,	924,	925,	926,	927,	928,	929,	930,	931,	932,	933,	934,	935,	936,	937,	938,	939,	940,	941,	942,	943,	944,	945,	946,	947,	948,	949,	950,	951,	952,	953,	954,	955,	956,	957,	958,	959,	960,	961,	962,	963,	964,	965,	966,	967,	968,	969,	970,	971,	972,	973,	974,	975,	976,	977,	978,	979,	980,	981,	982,	983,	984,	985,	986,	987,	988,	989,	990,	991,	992,	993,	994,	995,	996,	997,	998,	999,	1000,1001,1002)]

# Index_Datafram1 <- colnames(Checking_dataframe_1)
# write.csv(Index_Datafram1,"Index_Datafram1.csv")

# Summary Function

Myfunction1 <- function(data)
{
  a <- data.frame()
  e <- data.frame()
  f <- data.frame()
  G <- data.frame()
  H <- data.frame()
  I <- data.frame()
  J <- data.frame()
  K <- data.frame()
  L <- data.frame()
  M <- data.frame()
  N <- data.frame()
  Col_bined <- data.frame()
  
  
  for (i in 1:ncol(data))
  {
    if(class(data[,c(i)])!="factor") {
      Total_count <- NROW(data)-(sum(is.na(data[,c(i)]))+sum(data[,c(i)]==0,na.rm = TRUE))
      Count_NA <- data.frame(sum(is.na(data[,c(i)])))
      Count_zero <- data.frame(sum(data[,c(i)]==0,na.rm = TRUE))
      Mean_1 <- data.frame(mean(data[,c(i)],na.rm = TRUE))
      Median_1 <- data.frame(median(data[,c(i)],na.rm = TRUE))
      std <- data.frame(sd(data[,c(i)],na.rm = TRUE))
      Max_1 <- data.frame(max(data[,c(i)],na.rm = TRUE))
      Min_1 <- data.frame(min(data[,c(i)],na.rm = TRUE))
      b <-data.frame(colnames(data)[i],quantile(data[,c(i)],.25,na.rm = TRUE))
      c <-data.frame(quantile(data[,c(i)],.75,na.rm = TRUE))
      d <-data.frame(quantile(data[,c(i)],.99,na.rm = TRUE))
      row.names(Count_NA) <- NULL
      row.names(Count_zero) <- NULL
      row.names(Mean_1) <- NULL
      row.names(Median_1) <- NULL
      row.names(std) <- NULL
      row.names(Max_1) <- NULL
      row.names(Min_1) <- NULL
      row.names(Total_count) <- NULL
      row.names(b) <- NULL
      row.names(c) <- NULL
      row.names(d) <- NULL
      
      a <- rbind(b,a)
      e <- rbind(c,e)
      f <- rbind(d,f)
      
      G <- rbind(Count_NA,G)
      H <- rbind(Count_zero,H)
      I <- rbind(Mean_1,I)
      J <- rbind(Median_1,J)
      K <- rbind(Max_1,K)
      L <- rbind(Min_1,L)
      M <- rbind(std,M)
      N <- rbind(Total_count,N)
      Col_bined <- data.frame(cbind(a,e,f,N,G,H,I,J,M,K,L))
      colnames(Col_bined) <- c("Variables","Percentile 25%","Percentile 75%","Percentile 99%"
                               ,"Total_No_obs","Count_NA","Count_zero","Mean","Median","Standard_Deviation","Max","Min")
      
    }
    
  }
  
  Col_bined1<- data.frame(apply(Col_bined,2,rev))
  
  write.csv(Col_bined1,"Summary_checking_attrition.csv")
}

Myfunction1(Checking_dataframe_1)

write.csv(colnames(Checking_dataframe_1),"Checking_dataframe_1.csv")

# selected variables from package
Checking_dataframe_2<-Checking_dataframe_1[,c(1,2,3,	5,	14,	15,	17,	18,	111,	112,	114,	115,	141,	235,	239,	240,	241,	252,	253,	254,	255,	256,	257,	258,	259,	260,	285,	286,	287,	288,	310,	311,	312,	334,	335,	336,	358,	359,	360,	381,	382,	383,	384,	405,	406,	407,	408,	453,	454,	455,	456,	477,	478,	479,	480,	501,	502,	503,	504,	525,	526,	527,	528,	549,	550,	551,	552,	573,	574,	575,	576,	694,	695,	696,	741,	746,	749,	750,	751,	758,	763,	764,	863,	865,	867,	869,	871,	873,	877,	879,	880,	881,	882,	883,	887,	888,	889,	890,	891,	892,	893,	894,	895,	896,	897,	898,	899,	900,	901,	902,	903,	904,	905,	906,	907,	908,	909,	910,	911,	912,	913,	914,	915,	916,	917,	918,	919,	920,	921,	922,	923,	924,	925,	926,	927,	928,	929,	930,	931,	932,	933,	934,	935,	936,	937,	938,	939,	940,	941,	942,	943,	944,	945,	946,	947,	948,	949,	950,	951,	952,	953,	954,	955,	956,	957,	958,	959,	960,	961,	962,	963,	964,	965,	966,	967,	968,	969,	970,	971,	972,	973,	974,	975,	976,	977,	978,	979,	980,	981,	982,	983,	984,	985,	986,	987,	988,	989,	990,	991,	992,	993,	994,	995,	996,	997,	998,	999,	1000,	1001,	1002)]


Index_dataframe2 <- colnames(Checking_dataframe_2)
write.csv(Index_dataframe2,"Datafram2.csv")

# replacing null values with -9999  
Checking_MOdel_dataframe_3 <- replace(Checking_dataframe_2,is.na(Checking_dataframe_2),-99999999)

#checkinf if it contains NA after replacement
sum(is.na(Checking_MOdel_dataframe_3))

#validating the unique vales of target variable
unique(Checking_MOdel_dataframe_3$Credit_Card_Closed)  

#Replacing the 99999 values with NA for target variable
Checking_MOdel_dataframe_3$Credit_Card_Closed[Checking_MOdel_dataframe_3$Credit_Card_Closed==-99999999]<-NA

#replacing NA with 0 for target variables 
Checking_MOdel_dataframe_3$Credit_Card_Closed[is.na(Checking_MOdel_dataframe_3$Credit_Card_Closed)]<-0

Index_dataframe3 <- colnames(Checking_MOdel_dataframe_3)
write.csv(Index_dataframe3,"Datafram3.csv")

# Extracting IV Values


# write.csv(Training_dataset_woe.sample,"Columns_IV_Value.csv")






#Checking_dataframe_1
############reorder variables and remove parent ccount and ssn#########################
#memory.limit(12000)

#data2<-Checking_dataframe[,c(904,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,523,524,525,526,527,528,529,530,531,532,533,534,535,536,537,538,539,540,541,542,543,544,545,546,547,548,549,550,551,552,553,554,555,556,557,558,559,560,561,562,563,564,565,566,567,568,569,570,571,572,573,574,575,576,577,578,579,580,581,582,583,584,585,586,587,588,589,590,591,592,593,594,595,596,597,598,599,600,601,602,603,604,605,606,607,608,609,610,611,612,613,614,615,616,617,618,619,620,621,622,623,624,625,626,627,628,629,630,631,632,633,634,635,636,637,638,639,640,641,642,643,644,645,646,647,648,649,650,651,652,653,654,655,656,657,658,659,660,661,662,663,664,665,666,667,668,669,670,671,672,673,674,675,676,677,678,679,680,681,682,683,684,685,686,687,688,689,690,691,692,693,694,695,696,697,698,699,700,701,702,703,704,705,706,707,708,709,710,711,712,713,714,715,716,717,718,719,720,721,722,723,724,725,726,727,728,729,730,731,732,733,734,735,736,737,738,739,740,741,742,743,744,745,746,747,748,749,750,751,752,753,754,755,756,757,758,759,760,761,762,763,764,765,766,767,768,769,770,771,772,773,774,775,776,777,778,779,780,781,782,783,784,785,786,787,788,789,790,791,792,793,794,795,796,797,798,799,800,801,802,803,804,805,806,807,808,809,810,811,812,813,814,815,816,817,818,819,820,821,822,823,824,825,826,827,828,829,830,831,832,833,834,835,836,837,838,839,840,841,842,843,844,845,846,847,848,849,850,851,852,853,854,855,856,857,858,859,860,861,862,863,864,865,866,867,868,869,870,871,872,873,874,875,876,877,878,879,880,881,884,885,886,887,888,889,890,891,892,893,894,895,896,897,898,899,902,903)]

# contains variables with IV>0.1
data2<-Checking_MOdel_dataframe_3[,c(1,	2,	3,	4,	5,	6,	7,	8,	9,	10,	11,	12,	13,	14,	15,	16,	17,	18,	19,	20,	21,	22,	23,	24,	25,	26,	27,	28,	29,	30,	31,	32,	33,	34,	35,	36,	37,	38,	39,	40,	41,	42,	43,	44,	45,	46,	47,	48,	49,	50,	51,	52,	53,	54,	55,	56,	57,	58,	59,	60,	61,	62,	63,	64,	65,	66,	67,	68,	69,	70,	71,	72,	73,	74,	75,	76,	77,	78,	79,	80,	81,	82,	83,	84,	85,	86,	87,	88,	89,	90,	91,	92,	93,	94,	95,	96,	97,	98,	99,	100,	101,	102,	103,	104,	105,	106,	107,	108,	109,	110,	111,	112,	113,	114,	115,	116,	117,	118,	119,	120,	121,	122,	123,	124,	125,	126,	127,	128,	129,	130,	131,	132,	133,	134,	135,	136,	137,	138,	139,	140,	141,	142,	143,	144,	145,	146,	147,	148,	149,	150,	151,	152,	153,	154,	155,	156,	157,	158,	159,	160,	161,	162,	163,	164,	165,	166,	167,	168,	169,	170,	171,	172,	173,	174,	175,	176,	177,	178,	179,	180,	181,	182,	183,	184,	185,	186,	187,	188,	189,	190,	191,	192,	193,	194,	195,	196,	197,	198,	199,	200,	201,	202,	203,	204,	205,	206,	207,208,209,210)]
write.csv(data2,"data2.csv")     

data2$credit_card_closed 




# Training and Testing dataset
require(caTools)
library(caTools)
set.seed(123)
sample=sample.split(data2,SplitRatio=0.70)
train1=subset(data2,sample==TRUE)
test1=subset(data2,sample==FALSE)

#write.csv(train1,"train1.csv")

write.csv(train1,"train1.csv")
#Step wise

library(My.stepwise)

my.variable.list<-c("FICO_Staticpool",
                    "ACHAutopay_Flag",
                    "X..Vehicle.loan",
                    "X..HELOC.loan",
                    "X..Personal_Unsecured.loan",
                    "Total_Loans",
                    "BALANCE_Vehicle_Staticpool",
                    "BALANCE_HELOC_Staticpool",
                    "BALANCE_Personal_Unsecured_Staticpool",
                    "X..Real_Estate.loan",
                    "BALANCE_Real_Estate_Staticpool",
                    "No_Mortgage_account_Staticpool",
                    "New_loans_Staticpool",
                    "New_bal_Staticpool",
                    "sum_Mortgage_balance_Staticpool",
                    "X..Savings",
                    "X..Checking",
                    "X..MoneyMarket",
                    "X..Certificates",
                    "TotalDepositAccounts",
                    "Total_Products",
                    "Total_Loan_Balance",
                    "Total_Deposit_Balance",
                    "Total_Fees",
                    "LASTDIVAMOUNT_Savings_Q1",
                    "LASTDIVAMOUNT_Checking_Q1",
                    "LASTDIVAMOUNT_MoneyMarket_Q1",
                    "LASTDIVAMOUNT_Certificates_Q1",
                    "COURTESYFEEMTD_Checking_Q1",
                    "COURTESYFEEMTD_MoneyMarket_Q1",
                    "COURTESYFEEMTD_Certificates_Q1",
                    "NSFFEEMTD_Checking_Q1",
                    "NSFFEEMTD_MoneyMarket_Q1",
                    "NSFFEEMTD_Certificates_Q1",
                    "Overdraftfee_Checking_Q1",
                    "Overdraftfee_MoneyMarket_Q1",
                    "Overdraftfee_Certificates_Q1",
                    "Transaction_COUNT_Savings_Q1",
                    "Transaction_COUNT_Checking_Q1",
                    "Transaction_COUNT_MoneyMarket_Q1",
                    "Transaction_COUNT_Certificates_Q1",
                    "Transaction_amount_Savings_Q1",
                    "Transaction_amount_Checking_Q1",
                    "Transaction_amount_MoneyMarket_Q1",
                    "Transaction_amount_Certificates_Q1",
                    "Deposited_amount_Savings_Q1",
                    "Deposited_amount_Checking_Q1",
                    "Deposited_amount_MoneyMarket_Q1",
                    "Deposited_amount_Certificates_Q1",
                    "Deposited_count_Savings_Q1",
                    "Deposited_count_Checking_Q1",
                    "Deposited_count_MoneyMarket_Q1",
                    "Deposited_count_Certificates_Q1",
                    "withdrawal_amount_Savings_Q1",
                    "withdrawal_amount_Checking_Q1",
                    "withdrawal_amount_MoneyMarket_Q1",
                    "withdrawal_amount_Certificates_Q1",
                    "withdrawal_count_Savings_Q1",
                    "withdrawal_count_Checking_Q1",
                    "withdrawal_count_MoneyMarket_Q1",
                    "withdrawal_count_Certificates_Q1",
                    "X..Deposit.ACH_Savings_Q1",
                    "X..Deposit.ACH_Checking_Q1",
                    "X..Deposit.ACH_MoneyMarket_Q1",
                    "X..Deposit.ACH_Certificates_Q1",
                    "X..Deposit.ACH_Savings_Q1.1",
                    "X..Deposit.ACH_Checking_Q1.1",
                    "X..Deposit.ACH_MoneyMarket_Q1.1",
                    "X..Deposit.ACH_Certificates_Q1.1",
                    "X..Deposit.Payroll_Checking_Q1",
                    "X..Deposit.Payroll_MoneyMarket_Q1",
                    "X..Deposit.Payroll_Certificates_Q1",
                    "Last.Statement.Payment.Count_CC_Q1",
                    "Last.Statment.Sale.Count_CC_Q1",
                    "Last.Statement.External.Fee.Amount_CC_Q1",
                    "Last.Statement.Credit.Life.Change.Amount_CC_Q1",
                    "Last.Statement.Charge.Late.Amount_CC_Q1",
                    "spend_CC_Q1",
                    "RevolvingBalance_CC_Q1",
                    "CreditLimit_CC_Q1",
                    "Avg_BALANCE_Savings_Diff_Q1_Q2",
                    "Avg_BALANCE_Checking_Diff_Q1_Q2",
                    "Avg_BALANCE_Certificates_Diff_Q1_Q2",
                    "Avg_BALANCE_MoneyMarket_Diff_Q1_Q2",
                    "Deposited_amount_Savings_Diff_Q1_Q2",
                    "Deposited_amount_Checking_Diff_Q1_Q2",
                    "Deposited_amount_MoneyMarket_Diff_Q1_Q2",
                    "Months_Inactive_3",
                    "Months_Inactive_6",
                    "Months_Inactive_9",
                    "Months_Inactive_12",
                    "Months_Inactive_18",
                    "Savings_balance_StaticPool",
                    "LASTDIVAMOUNT_Savings_StaticPool",
                    "COURTESYFEEMTD_Savings_StaticPool",
                    "NSFFEEMTD_Savings_StaticPool",
                    "Overdraftfee_Savings_StaticPool",
                    "Transaction_COUNT_Savings_StaticPool",
                    "Transaction_amount_Savings_StaticPool",
                    "AVG_BALANCECHANGE_Savings_StaticPool",
                    "Deposited_amount_Savings_StaticPool",
                    "Deposited_count_Savings_StaticPool",
                    "withdrawal_amount_Savings_StaticPool",
                    "withdrawal_count_Savings_StaticPool",
                    "X..Deposit.ACH_Savings_StaticPool",
                    "X..Deposit.ACH_Savings_StaticPool.1",
                    "X..Deposit.Home.Banking.Savings_StaticPool",
                    "X..Deposit.Home.Banking.Savings_StaticPool.1",
                    "X..Deposit.Check.Savings.StaticPool",
                    "X..Deposit.Check.Savings.StaticPool.1",
                    "X..Deposit.Payroll.Savings.StaticPool",
                    "X..Deposit.Payroll.Savings.StaticPool.1",
                    "Checking_balance_StaticPool",
                    "LASTDIVAMOUNT_Checking_StaticPool",
                    "COURTESYFEEMTD_Checking_StaticPool",
                    "NSFFEEMTD_Checking_StaticPool",
                    "Overdraftfee_Checking_StaticPool",
                    "Transaction_COUNT_Checking_StaticPool",
                    "Transaction_amount_Checking_StaticPool",
                    "AVG_BALANCECHANGE_Checking_StaticPool",
                    "Deposited_amount_Checking_StaticPool",
                    "Deposited_count_Checking_StaticPool",
                    "withdrawal_amount_Checking_StaticPool",
                    "withdrawal_count_Checking_StaticPool",
                    "X..Deposit.ACH_Checking_StaticPool",
                    "X..Deposit.ACH_Checking_StaticPool.1",
                    "X..Deposit.Home.Banking_Checking_StaticPool",
                    "X..Deposit.Home.Banking_Checking_StaticPool.1",
                    "X..Deposit.Check.Checking_StaticPool",
                    "X..Deposit.Check.Checking_StaticPool.1",
                    "X..Deposit.Payroll.Checking_StaticPool",
                    "X..Deposit.Payroll.Checking_StaticPool.1",
                    "BALANCE_Certificates_Staticpool",
                    "LASTDIVAMOUNT_Certificates_StaticPool",
                    "COURTESYFEEMTD_Certificates_StaticPool",
                    "NSFFEEMTD_Certificates_StaticPool",
                    "Overdraftfee_Certificates_StaticPool",
                    "Transaction_COUNT_Certificates_StaticPool",
                    "Transaction_amount_Certificates_StaticPool",
                    "AVG_BALANCECHANGE_Certificates_StaticPool",
                    "Deposited_amount_Certificates_StaticPool",
                    "Deposited_count_Certificates_StaticPool",
                    "withdrawal_amount_Certificates_StaticPool",
                    "withdrawal_count_Certificates_StaticPool",
                    "X..Deposit.ACH_Certificates_StaticPool",
                    "X..Deposit.ACH_Certificates_StaticPool.1",
                    "X..Deposit.Home.Banking_Certificates_StaticPool",
                    "X..Deposit.Home.Banking_Certificates_StaticPool.1",
                    "X..Deposit.Check_Certificates_Staticpool",
                    "X..Deposit.Check_Certificates_Staticpool.1",
                    "X..Deposit.Payroll_Certificates_Staticpool",
                    "X..Deposit.Payroll_Certificates_Staticpool.1",
                    "BALANCE_MoneyMarket_Staticpool",
                    "LASTDIVAMOUNT_MoneyMarket_StaticPool",
                    "COURTESYFEEMTD_MoneyMarket_StaticPool",
                    "NSFFEEMTD_MoneyMarket_StaticPool",
                    "Overdraftfee_MoneyMarket_StaticPool",
                    "Transaction_COUNT_MoneyMarket_StaticPool",
                    "Transaction_amount_MoneyMarket_StaticPool",
                    "AVG_BALANCECHANGE_MoneyMarket_StaticPool",
                    "Deposited_amount_MoneyMarket_StaticPool",
                    "Deposited_count_MoneyMarket_StaticPool",
                    "withdrawal_amount_MoneyMarket_StaticPool",
                    "withdrawal_count_MoneyMarket_StaticPool",
                    "X..Deposit.ACH_MoneyMarket_StaticPool",
                    "X..Deposit.ACH_MoneyMarket_StaticPool.1",
                    "X..Deposit.Home.Banking_MoneyMarket_StaticPool",
                    "X..Deposit.Home.Banking_MoneyMarket_StaticPool.1",
                    "X..Deposit.Check_MoneyMarket_Staticpool",
                    "X..Deposit.Check_MoneyMarket_Staticpool.1",
                    "X..Deposit.Payroll_MoneyMarket_Staticpool",
                    "X..Deposit.Payroll_MoneyMarket_Staticpool.1",
                    "Total_Deposit_Transactions_DepositProducts",
                    "Total_Withdrawal_Transactions_DepositProducts",
                    "CreditCards_fees",
                    "Diff_balance_Q1Q2",
                    "Diff_balance_Q1Q3",
                    "Diff_Payment_Count_Q1Q2",
                    "Diff_Payment_Count_Q1Q3",
                    "Diff_PaymentAmount_Q1Q2",
                    "Diff_PaymentAmount_Q1Q3",
                    "Diff_Promo_balance_Q1Q2",
                    "Diff_Promo_balance_Q1Q3",
                    "Diff_Protected_balance_Q1Q2",
                    "Diff_Protected_balance_Q1Q3",
                    "Diff_Revolving_Balance_Q1Q2",
                    "Diff_Revolving_Balance_Q1Q3",
                    "Diff_Spend_Q1Q2",
                    "Diff_Spend_Q1Q3",
                    "Diff_Spend_Q1Q4",
                    "Q1_PointsReddem",
                    "Q2_PointsReddem",
                    "Q3_PointsReddem",
                    "Q4_PointsReddem",
                    "Static_PointsRedeem",
                    "Q1_PointsEarned",
                    "Q2_PointsEarned",
                    "Q3_PointsEarned",
                    "Q4_PointsEarned",
                    "Static_PointsEarned",
                    "Static_TotalPtsRedeemed",
                    "Static_TotalPtsEarned",
                    "Static_Rewards_monthEndBalance",
                    "addresschange_flag",
                    "BT_Flag",
                    "ESTMTENABLE",
                    "JoinAccount_Loan_Flag"
                    #"Credit_Card_Closed"
                    
)

my.variable.list1<-c("Months_Inactive_18",
                      #  "Last.Statement.Charge.Late.Amount_CC_Q1",
                      #   "Last.Statment.Sale.Count_CC_Q1",
                      #   "RevolvingBalance_CC_Q1",
                      "Total_Deposit_Balance",
                      # "Last.Statement.External.Fee.Amount_CC_Q1",
                      "Total_Loan_Balance",
                      #  "Months_Inactive_9",
                      "Months_Inactive_3",
                      "Total_Fees",
                      # "Checking_balance_StaticPool",
                      "Savings_balance_StaticPool",
                      # "X..Deposit.Home.Banking.Savings_StaticPool",
                      "spend_CC_Q1",
                      "Overdraftfee_Checking_Q1",
                      #  "Last.Statment.Sale.Count_CC_Q1",
                      "CreditCards_fees",
                      # "Last.Statement.Charge.Late.Amount_CC_Q1",
                      "TotalDepositAccounts",
                      "Total_Products",
                      "Total_Loans",
                      "TotalDepositAccounts"
)
  
  #chi-square
  library(car)
  library(carData)
  Anova(my_glm_model, type="II", test="Wald")
  
  My.stepwise.glm.results <- My.stepwise.glm(Y = "Credit_Card_Closed", my.variable.list, data = train1, sle = 0.05,
                                             sls = 0.05, myfamily="binomial")
  
  
  
  
  #model 
  my_glm_model= glm(formula = Credit_Card_Closed ~ Months_Inactive_3 + Months_Inactive_18 + 
                      spend_CC_Q1 + Total_Deposit_Balance + Total_Loans + Total_Fees + 
                      Savings_balance_StaticPool, family = binomial(logit), data = train1)
  
  
  
  
  
  
  
  
  ###############
  
  
  
  #######################################
  
  
  
  
  #################################################  WOE #############################################
  
  library(woeBinning)
  
  Binning.train<-woe.binning(train1,'Credit_Card_Closed',train1)
  
  Binning.test<-woe.binning(test1,'Credit_Card_Closed',test1)
  
  Training_dataset_woe<-woe.binning.deploy(train1,Binning.train,add.woe.or.dum.var="woe")
  #colnames(Training_dataset_woe)
  
  Testing_dataset_woe<-woe.binning.deploy(test1,Binning.test,add.woe.or.dum.var="woe")
  
  write.csv(colnames(Training_dataset_woe),"Training_dataset_woe.csv")
  
  tabulate.binning.Train<-woe.binning.table(Binning.train)
  
  WOEsumm<-data.matrix(tabulate.binning.Train,rownames.force = NA)
  
  write.csv(WOEsumm,"WOEsumm.csv")
  #woe_var<-names(tabulate.binning.Train)
  
  #colnames(WOEsumm)
  
  #write.csv(woe_var,"woe_var.csv")
  
  my.variable.woe<-c("woe.Last.Statement.Payment.Count_CC_Q1.binned",
                     "woe.Months_Inactive_6.binned",
                     "woe.spend_CC_Q1.binned",
                     "woe.Months_Inactive_3.binned",
                     "woe.Last.Statment.Sale.Count_CC_Q1.binned",
                     "woe.Diff_Spend_Q1Q2.binned",
                     "woe.Months_Inactive_9.binned",
                     "woe.Months_Inactive_12.binned",
                     "woe.Diff_Spend_Q1Q3.binned",
                     "woe.Diff_Spend_Q1Q4.binned",
                     "woe.Months_Inactive_18.binned",
                     "woe.Diff_balance_Q1Q2.binned",
                     "woe.Diff_PaymentAmount_Q1Q2.binned",
                     "woe.Diff_balance_Q1Q3.binned",
                #     "woe.Static_Rewards_monthEndBalance.binned",
                   #  "woe.Q1_PointsEarned.binned",
                  #   "woe.Static_PointsEarned.binned",
                   #  "woe.Q2_PointsEarned.binned",
                   #  "woe.Q3_PointsEarned.binned",
                     "woe.Diff_PaymentAmount_Q1Q3.binned",
                    # "woe.Q4_PointsEarned.binned",
                     "woe.LASTDIVAMOUNT_Checking_StaticPool.binned",
                     "woe.Checking_balance_StaticPool.binned",
                     "woe.Total_Deposit_Balance.binned",
                     "woe.X..Deposit.ACH_Checking_StaticPool.1.binned",
                     "woe.X..Deposit.ACH_Checking_StaticPool.binned",
                 #    "woe.Static_TotalPtsEarned.binned",
                     "woe.LASTDIVAMOUNT_Checking_Q1.binned",
                     "woe.Deposited_count_Checking_StaticPool.binned",
                     "woe.X..Deposit.ACH_Checking_Q1.1.binned",
                     "woe.X..Deposit.ACH_Checking_Q1.binned",
                     "woe.Deposited_amount_Checking_StaticPool.binned",
                     "woe.Total_Withdrawal_Transactions_DepositProducts.binned",
                     "woe.Deposited_count_Checking_Q1.binned",
                     "woe.AVG_BALANCECHANGE_Checking_StaticPool.binned",
                     "woe.Transaction_COUNT_Checking_Q1.binned",
                     "woe.withdrawal_count_Checking_Q1.binned",
                     "woe.Total_Deposit_Transactions_DepositProducts.binned",
                     "woe.withdrawal_amount_Checking_StaticPool.binned",
                     "woe.Transaction_amount_Checking_StaticPool.binned",
                     "woe.Deposited_amount_Checking_Q1.binned",
                     "woe.Diff_Revolving_Balance_Q1Q2.binned",
                     "woe.withdrawal_amount_Checking_Q1.binned",
                     "woe.RevolvingBalance_CC_Q1.binned",
                     "woe.withdrawal_count_Checking_StaticPool.binned",
                     "woe.Transaction_amount_Checking_Q1.binned",
                   #  "woe.Q3_PointsReddem.binned",
                     "woe.Transaction_COUNT_Checking_StaticPool.binned",
                     "woe.Avg_BALANCE_Checking_Diff_Q1_Q2.binned",
                     "woe.Diff_Revolving_Balance_Q1Q3.binned",
                     "woe.Diff_Payment_Count_Q1Q3.binned",
                     "woe.Static_TotalPtsRedeemed.binned",
                     "woe.Diff_Payment_Count_Q1Q2.binned",
                     "woe.X..Deposit.Payroll.Checking_StaticPool.1.binned",
                     "woe.X..Deposit.Payroll.Checking_StaticPool.binned",
                     "woe.X..Deposit.Check.Checking_StaticPool.1.binned",
                     "woe.X..Deposit.Check.Checking_StaticPool.binned",
                     "woe.X..Deposit.Home.Banking_Checking_StaticPool.1.binned",
                     "woe.X..Deposit.Home.Banking_Checking_StaticPool.binned",
                     "woe.Overdraftfee_Checking_StaticPool.binned",
                     "woe.NSFFEEMTD_Checking_StaticPool.binned",
                     "woe.COURTESYFEEMTD_Checking_StaticPool.binned",
                     "woe.FICO_Staticpool.binned",
                     "woe.Deposited_amount_Checking_Diff_Q1_Q2.binned",
                     "woe.Diff_Protected_balance_Q1Q2.binned",
                     "woe.Last.Statement.Charge.Late.Amount_CC_Q1.binned",
                     "woe.Diff_Protected_balance_Q1Q3.binned",
                     "woe.TotalDepositAccounts.binned",
                     "woe.X..Deposit.Payroll_Checking_Q1.binned",
                     "woe.Overdraftfee_Checking_Q1.binned",
                     "woe.NSFFEEMTD_Checking_Q1.binned",
                     "woe.COURTESYFEEMTD_Checking_Q1.binned",
                     "woe.X..Checking.binned",
                     "woe.Total_Products.binned",
                   #  "woe.Static_PointsRedeem.binned",
                   #  "woe.Q1_PointsReddem.binned",
                    # "woe.Q2_PointsReddem.binned",
                     "woe.LASTDIVAMOUNT_Savings_Q1.binned",
                     "woe.CreditCards_fees.binned",
                    # "woe.Q4_PointsReddem.binned",
                     "woe.Savings_balance_StaticPool.binned",
                     "woe.Transaction_amount_Savings_Q1.binned",
                     "woe.ESTMTENABLE.binned",
                     "woe.LASTDIVAMOUNT_Savings_StaticPool.binned",
                     "woe.Transaction_COUNT_Savings_StaticPool.binned",
                     "woe.Deposited_count_Savings_Q1.binned",
                     "woe.CreditLimit_CC_Q1.binned",
                     "woe.Avg_BALANCE_Savings_Diff_Q1_Q2.binned",
                     "woe.X..Deposit.Payroll_Certificates_Staticpool.1.binned",
                     "woe.X..Deposit.Payroll_Certificates_Staticpool.binned",
                     "woe.X..Deposit.Check_Certificates_Staticpool.1.binned",
                     "woe.X..Deposit.Check_Certificates_Staticpool.binned",
                     "woe.X..Deposit.Home.Banking_Certificates_StaticPool.1.binned",
                     "woe.X..Deposit.Home.Banking_Certificates_StaticPool.binned",
                     "woe.X..Deposit.ACH_Certificates_StaticPool.1.binned",
                     "woe.X..Deposit.ACH_Certificates_StaticPool.binned",
                     "woe.withdrawal_count_Certificates_StaticPool.binned",
                     "woe.withdrawal_amount_Certificates_StaticPool.binned",
                     "woe.Deposited_count_Certificates_StaticPool.binned",
                     "woe.Deposited_amount_Certificates_StaticPool.binned",
                     "woe.AVG_BALANCECHANGE_Certificates_StaticPool.binned",
                     "woe.Transaction_amount_Certificates_StaticPool.binned",
                     "woe.Transaction_COUNT_Certificates_StaticPool.binned",
                     "woe.Overdraftfee_Certificates_StaticPool.binned",
                     "woe.NSFFEEMTD_Certificates_StaticPool.binned",
                     "woe.COURTESYFEEMTD_Certificates_StaticPool.binned",
                     "woe.LASTDIVAMOUNT_Certificates_StaticPool.binned",
                     "woe.BALANCE_Certificates_Staticpool.binned",
                     "woe.Avg_BALANCE_Certificates_Diff_Q1_Q2.binned",
                     "woe.X..Deposit.Payroll_Certificates_Q1.binned",
                     "woe.X..Deposit.ACH_Certificates_Q1.1.binned",
                     "woe.X..Deposit.ACH_Certificates_Q1.binned",
                     "woe.withdrawal_count_Certificates_Q1.binned",
                     "woe.withdrawal_amount_Certificates_Q1.binned",
                     "woe.Deposited_count_Certificates_Q1.binned",
                     "woe.Deposited_amount_Certificates_Q1.binned",
                     "woe.Transaction_amount_Certificates_Q1.binned",
                     "woe.Transaction_COUNT_Certificates_Q1.binned",
                     "woe.Overdraftfee_Certificates_Q1.binned",
                     "woe.NSFFEEMTD_Certificates_Q1.binned",
                     "woe.COURTESYFEEMTD_Certificates_Q1.binned",
                     "woe.LASTDIVAMOUNT_Certificates_Q1.binned",
                     "woe.X..Certificates.binned",
                     "woe.AVG_BALANCECHANGE_Savings_StaticPool.binned",
                     "woe.Deposited_count_Savings_StaticPool.binned",
                     "woe.Deposited_amount_Savings_StaticPool.binned",
                     "woe.Transaction_COUNT_Savings_Q1.binned",
                     "woe.Deposited_amount_Savings_Q1.binned",
                     "woe.Transaction_amount_Savings_StaticPool.binned",
                     "woe.Deposited_amount_Savings_Diff_Q1_Q2.binned",
                     "woe.X..Deposit.Payroll_MoneyMarket_Staticpool.1.binned",
                     "woe.X..Deposit.Payroll_MoneyMarket_Staticpool.binned",
                     "woe.X..Deposit.Check_MoneyMarket_Staticpool.1.binned",
                     "woe.X..Deposit.Check_MoneyMarket_Staticpool.binned",
                     "woe.X..Deposit.Home.Banking_MoneyMarket_StaticPool.1.binned",
                     "woe.X..Deposit.Home.Banking_MoneyMarket_StaticPool.binned",
                     "woe.X..Deposit.ACH_MoneyMarket_StaticPool.1.binned",
                     "woe.X..Deposit.ACH_MoneyMarket_StaticPool.binned",
                     "woe.withdrawal_count_MoneyMarket_StaticPool.binned",
                     "woe.withdrawal_amount_MoneyMarket_StaticPool.binned",
                     "woe.Deposited_count_MoneyMarket_StaticPool.binned",
                     "woe.Deposited_amount_MoneyMarket_StaticPool.binned",
                     "woe.AVG_BALANCECHANGE_MoneyMarket_StaticPool.binned",
                     "woe.Transaction_amount_MoneyMarket_StaticPool.binned",
                     "woe.Transaction_COUNT_MoneyMarket_StaticPool.binned",
                     "woe.Overdraftfee_MoneyMarket_StaticPool.binned",
                     "woe.NSFFEEMTD_MoneyMarket_StaticPool.binned",
                     "woe.COURTESYFEEMTD_MoneyMarket_StaticPool.binned",
                     "woe.LASTDIVAMOUNT_MoneyMarket_StaticPool.binned",
                     "woe.BALANCE_MoneyMarket_Staticpool.binned",
                     "woe.Deposited_amount_MoneyMarket_Diff_Q1_Q2.binned",
                     "woe.Avg_BALANCE_MoneyMarket_Diff_Q1_Q2.binned",
                     "woe.X..Deposit.Payroll_MoneyMarket_Q1.binned",
                     "woe.X..Deposit.ACH_MoneyMarket_Q1.1.binned",
                     "woe.X..Deposit.ACH_MoneyMarket_Q1.binned",
                     "woe.withdrawal_count_MoneyMarket_Q1.binned",
                     "woe.withdrawal_amount_MoneyMarket_Q1.binned",
                     "woe.Deposited_count_MoneyMarket_Q1.binned",
                     "woe.Deposited_amount_MoneyMarket_Q1.binned",
                     "woe.Transaction_amount_MoneyMarket_Q1.binned",
                     "woe.Transaction_COUNT_MoneyMarket_Q1.binned",
                     "woe.Overdraftfee_MoneyMarket_Q1.binned",
                     "woe.NSFFEEMTD_MoneyMarket_Q1.binned",
                     "woe.COURTESYFEEMTD_MoneyMarket_Q1.binned",
                     "woe.LASTDIVAMOUNT_MoneyMarket_Q1.binned",
                     "woe.X..MoneyMarket.binned",
                     "woe.BT_Flag.binned",
                     "woe.Last.Statement.Credit.Life.Change.Amount_CC_Q1.binned",
                     "woe.Last.Statement.External.Fee.Amount_CC_Q1.binned",
                     "woe.X..Deposit.Home.Banking.Savings_StaticPool.1.binned",
                     "woe.X..Deposit.Home.Banking.Savings_StaticPool.binned",
                     "woe.Diff_Promo_balance_Q1Q3.binned",
                     "woe.Diff_Promo_balance_Q1Q2.binned",
                     "woe.X..Vehicle.loan.binned",
                     "woe.addresschange_flag.binned",
                     "woe.Total_Loans.binned",
                     "woe.withdrawal_amount_Savings_Q1.binned",
                     "woe.withdrawal_count_Savings_StaticPool.binned",
                     "woe.BALANCE_Vehicle_Staticpool.binned",
                     "woe.withdrawal_count_Savings_Q1.binned",
                     "woe.X..Savings.binned",
                     "woe.withdrawal_amount_Savings_StaticPool.binned",
                     "woe.Total_Fees.binned",
                     "woe.Total_Loan_Balance.binned",
                     "woe.X..Deposit.ACH_Savings_Q1.1.binned",
                     "woe.X..Deposit.ACH_Savings_Q1.binned",
                     "woe.ACHAutopay_Flag.binned",
                     "woe.sum_Mortgage_balance_Staticpool.binned",
                     "woe.New_bal_Staticpool.binned",
                     "woe.New_loans_Staticpool.binned",
                     "woe.No_Mortgage_account_Staticpool.binned",
                     "woe.X..Deposit.ACH_Savings_StaticPool.1.binned",
                     "woe.X..Deposit.ACH_Savings_StaticPool.binned",
                     "woe.JoinAccount_Loan_Flag.binned",
                     "woe.BALANCE_Personal_Unsecured_Staticpool.binned",
                     "woe.X..Personal_Unsecured.loan.binned",
                     "woe.X..Deposit.Check.Savings.StaticPool.1.binned",
                     "woe.X..Deposit.Check.Savings.StaticPool.binned",
                     "woe.NSFFEEMTD_Savings_StaticPool.binned",
                     "woe.BALANCE_HELOC_Staticpool.binned",
                     "woe.X..HELOC.loan.binned",
                     "woe.BALANCE_Real_Estate_Staticpool.binned",
                     "woe.X..Real_Estate.loan.binned",
                     "woe.X..Deposit.Payroll.Savings.StaticPool.1.binned",
                     "woe.X..Deposit.Payroll.Savings.StaticPool.binned",
                     "woe.Overdraftfee_Savings_StaticPool.binned",
                     "woe.COURTESYFEEMTD_Savings_StaticPool.binned"
  )
  
  my.variable.woe1<-c("woe.Last.Statement.Payment.Count_CC_Q1.binned",
                      "woe.Static_Rewards_monthEndBalance.binned",
                      "woe.Last.Statement.Charge.Late.Amount_CC_Q1.binned",
                      #   "woe.X..Deposit.Payroll_Checking_Q1.binned",
                      "woe.Diff_balance_Q1Q2.binned",
                      "woe.Checking_balance_StaticPool.binned",
                      "woe.Months_Inactive_18.binned",
                      "woe.CreditCards_fees.binned",
                      "woe.Q2_PointsReddem.binned",
                      "woe.X..Deposit.ACH_Checking_StaticPool.1.binned",
                      "woe.X..Savings.binned",
                      "woe.Total_Fees.binned",
                      "woe.BALANCE_Vehicle_Staticpool.binned",
                      "woe.LASTDIVAMOUNT_Savings_Q1.binned",
                      "woe.Total_Loans.binned",
                      "woe.BT_Flag.binned",
                      "woe.addresschange_flag.binned",
                      #   "woe.Diff_Promo_balance_Q1Q3.binned",
                      "woe.RevolvingBalance_CC_Q1.binned",
                      "woe.spend_CC_Q1.binned",
                      "woe.Last.Statment.Sale.Count_CC_Q1.binned",
                      "woe.withdrawal_count_Checking_StaticPool.binned",
                      #  "woe.X..Deposit.ACH_Checking_Q1.1.binned",
                      "woe.Deposited_count_Savings_Q1.binned")
  
  
  
  
  
  
  ###################################################Final Model Trials
  
  
  my.variable.woe2<-c(
    "woe.Diff_balance_Q1Q2.binned",
   #"woe.Static_Rewards_monthEndBalance.binned",
    "woe.Last.Statement.Charge.Late.Amount_CC_Q1.binned",
    "woe.Checking_balance_StaticPool.binned",
    "woe.Months_Inactive_18.binned",
    "woe.CreditCards_fees.binned",
   #"woe.Q2_PointsReddem.binned",
    "woe.Total_Fees.binned",
    "woe.Total_Loans.binned",
    "woe.RevolvingBalance_CC_Q1.binned",
    "woe.spend_CC_Q1.binned",
    "woe.Last.Statment.Sale.Count_CC_Q1.binned"
   
  # "woe.Total_Deposit_Balance.binned",
  # "woe.Total_Products.binned"
   
  )
  
  
  My.stepwise.glm.results_woe2 <- My.stepwise.glm(Y = "Credit_Card_Closed", my.variable.woe2, data =Training_dataset_woe, sle = 0.05,
                                                  sls = 0.05, myfamily="binomial")
  
  
  # my.variable.list_after_woe<-c(woe.Diff_balance_Q1Q2.binned ,
  #                                  woe.Static_Rewards_monthEndBalance.binned , woe.Last.Statement.Charge.Late.Amount_CC_Q1.binned ,
  #                                  woe.Checking_balance_StaticPool.binned , woe.Months_Inactive_18.binned , 
  #                                  woe.spend_CC_Q1.binned, woe.RevolvingBalance_CC_Q1.binned ,
  #                                  woe.CreditCards_fees.binned , woe.Total_Fees.binned , woe.Q2_PointsReddem.binned ,
  #                                  woe.X..Savings.binned , woe.Total_Loans.binned
  #                               )
  # 
  # 
  # 
  # My.stepwise.glm.results_after_woe <- My.stepwise.glm(Y = "Credit_Card_Closed", my.variable.list_after_woe, data = Training_dataset_woe, sle = 0.05,
  #                                                      sls = 0.05, myfamily="binomial")
  
  
  My.stepwise.glm.results_woe2
  
  #model 
  
  
  
  my_glm_model=glm(formula = Credit_Card_Closed ~ woe.Diff_balance_Q1Q2.binned + 
                     woe.Months_Inactive_18.binned + woe.spend_CC_Q1.binned + 
                     woe.Last.Statement.Charge.Late.Amount_CC_Q1.binned + woe.RevolvingBalance_CC_Q1.binned + 
                     woe.Checking_balance_StaticPool.binned + woe.Total_Fees.binned + 
                     woe.CreditCards_fees.binned + woe.Total_Loans.binned, family = binomial(logit), 
                   data = Training_dataset_woe)
  
  
  
  #chi-square
  library(car)
  library(carData)
  Anova(my_glm_model, type="II", test="Wald")
  
  
  
  
  #prediction on training woe dataset
  pred1= predict(my_glm_model, newdata= Training_dataset_woe, type = "response")
  
  pred1
  
  df_results= data.frame(Training_dataset_woe$PARENTACCOUNT, pred1)
  
  
  write.csv(data.frame(Training_dataset_woe$PARENTACCOUNT, Training_dataset_woe$woe.Months_Inactive_18.binned, 
                       Training_dataset_woe$woe.RevolvingBalance_CC_Q1.binned, Training_dataset_woe$woe.RevolvingBalance_CC_Q1.binned, Training_dataset_woe$woe.Static_Rewards_monthEndBalance.binned,
                       Training_dataset_woe$woe.Checking_balance_StaticPool.binned,
                       
                       Training_dataset_woe$Credit_Card_Closed, pred1), "implementation4_train.csv")
  
  #coef(my_glm_model)
  
  #prediction on testing woe dataset
  pred1= predict(my_glm_model, newdata= Testing_dataset_woe, type = "response")
  
  pred1
  
  df_results= data.frame(Testing_dataset_woe$PARENTACCOUNT, pred1)
  
  
  write.csv(data.frame(Testing_dataset_woe$PARENTACCOUNT, Testing_dataset_woe$woe.Months_Inactive_18.binned, 
                       Testing_dataset_woe$woe.RevolvingBalance_CC_Q1.binned, Testing_dataset_woe$woe.RevolvingBalance_CC_Q1.binned, Testing_dataset_woe$woe.Static_Rewards_monthEndBalance.binned,
                       Testing_dataset_woe$woe.Checking_balance_StaticPool.binned,
                       
                       Testing_dataset_woe$Credit_Card_Closed, pred1), "implementation4_test.csv")
  
  
  
  
  
  

 
		Drop table if Exists #Qualified_account
		Drop table if Exists #R2_checking_accounts
		Drop table if Exists #Fee
		Drop table if Exists #Debit_card_Data
		Drop table if Exists #debitCards
		Drop table if Exists #ACH_table
		Drop table if Exists #SavingTransaction
		Drop table if Exists #Summary
		Drop table if Exists #Summary1
		Drop table if Exists #Name_table_R2
		Drop table if Exists #CC_data
		Drop table if Exists #CC_Summary
		Drop table if Exists #Summary2
		Drop table if Exists #Summary3
		Drop table if exists #processdate
		select Process_Date,max(ProcessDate) Max_Processdate
		into #processdate
		from (select ProcessDate,left(ProcessDate,6) Process_Date from ARCUSYM000..SAVINGS) A group by Process_Date order by Process_Date

		-- by changing the where condition , mentioning the rewards checking type , you can create the data summary for rewards checking also for free checking 

		-- Drop table if Exists #Qualified_account
		select processdate
		,left(ProcessDate,6) Process_Date
		,Process_date_v
		,BALANCE
		,PARENTACCOUNT,ID,CONCAT(PARENTACCOUNT,ID) UNID
		,CONCAT(PARENTACCOUNT,id,type) Account_number
		,type
		into #Qualified_account
		from
			(select *,EOMONTH(Process_date_v) Monthend from
				(select * 
				,DATEFROMPARTS(LEFT(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Process_date_v from ARCUSYM000..savings) a
				where ProcessDate in (select Max_Processdate from #processdate)
				) B																							
		  where
		  Monthend=Process_date_v 
		  and Process_date_v>='2017-08-31'
		  and  divtype in (48,4148,4048)
		  and closedate is null
		  and chargeoffdate is null

		  -- drop table if exists #R2_checking_accounts
		select PARENTACCOUNT,ID,TYPE,UNID
		,Process_date_v [Date]
		,OPENDATE,CLOSEDATE,Account_number
		,Checking_flag
		,case when opend_date=Process_Date then 1 else 0 end [New Account]
		,case when CLOSE_DATE=Process_Date then 1 else 0 end [Close Account]
		,case when OPENDATE>='2017-08-31' then 'New' else 'transfered' end R2_flag
		,BALANCE,LASTDIVAMOUNT [Dividend]
		,NSFFEELY,NSFFEEMTD,NSFFEEYTD
		,OVERDRAFTFEEYTD,COURTESYFEELY,COURTESYFEEMTD,COURTESYFEEYTD
		into #R2_checking_accounts
		from 
		(
		select ProcessDate
		,Process_date_v
		,left(ProcessDate,6) Process_Date 
		,PARENTACCOUNT,ID,CONCAT(PARENTACCOUNT,ID) UNID
		,CONCAT(PARENTACCOUNT,id,type) Account_number 
		,type,cast(OPENDATE as date) OPENDATE,cast(CLOSEDATE as date) CLOSEDATE
		,case when len(month(opendate))=1 then concat(year(OPENDATE),0,month(OPENDATE))
		else concat(year(OPENDATE),month(OPENDATE)) end  opend_date
		,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
		else concat(year(CLOSEDATE),month(CLOSEDATE)) end  CLOSE_DATE
		,BALANCE ,LASTDIVAMOUNT,NSFFEELY,NSFFEEMTD,NSFFEEYTD
		,OVERDRAFTFEEYTD,COURTESYFEELY,COURTESYFEEMTD,COURTESYFEEYTD,chargeoffdate
		,case when type in (48,4048,4148) then 'R2'
		when type in (40,47,4040,4140) then 'Rewards'
		else 'others' end Checking_flag
		from (select *,EOMONTH(Process_date_v) Monthend from
				(select * 
				,DATEFROMPARTS(LEFT(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Process_date_v
				 from ARCUSYM000..savings 
				 where ProcessDate in (select Max_Processdate from #processdate)
				 ) a ) B
		 where TYPE in (40,41,42,43,44,45,46,47,48,52,91,140,141,142,143,144,145,146,241,543,591,4040,4048,4140,4148)
		and Monthend=Process_date_v )A
		where   Checking_flag ='R2' and chargeoffdate is null 
		--and CLOSEDATE is null 
		

		-- Fee Calculation
		-- Drop table #Fee
			select [Date]
			,sum(COURTESYFEEMTD) [COURTESY FEE]
			,sum(NSFFEEMTD) [NSF FEE]
			,sum(Overdraftfee) [OVERDRAFT FEE]
			into #Fee
			from (	select date,Checking_flag,R2_flag,Account_number
			,BALANCE,Dividend,COURTESYFEEMTD,NSFFEEMTD,OVERDRAFTFEEYTD
			,case when (OVERDRAFTFEEYTD-(lag(OVERDRAFTFEEYTD,1,0) over (partition by account_number order by account_number,date)))<0 or
			date='2017-08-31' then 0 
			else (OVERDRAFTFEEYTD-(lag(OVERDRAFTFEEYTD,1,0) over (partition by account_number order by account_number,date))) end Overdraftfee
			from #R2_checking_accounts) a
			where date >= '2017-08-31'
				group by date
			order by date

		-- Qualified accounts Calculatin By UICCU

		--	select Process_date_v,R2_flag,Balance_20_flag,Checking_flag
		--	,count(distinct Account_number) No_count
		--	,sum(BALANCE) Qualifying_ACCT_balance
		--	,sum(LASTDIVAMOUNT) Sum_LASTDIVAMOUNT
		--	from
		--	(select a.*
		--	,case when balance>20000 then 1 else 0 end Balance_20_flag
		--	 from #R2_checking_accounts a
		--inner join #Qualified_account b
		--	on a.UNID=b.UNID
			
		--	and a.Process_date_v=b.Process_date_v ) AA
		--	group by Process_date_v,R2_flag,Balance_20_flag,Checking_flag
		--	order by Process_date_v,R2_flag,Balance_20_flag,Checking_flag



			-- calculate Debit card Transaction and amount from transaction table 
			 -- drop table if exists #Debit_card_Data
			 select 
			 UNID
			 ,EOMONTH(EFFECTIVEDATE) EFFECTIVEDATE
			 ,sum(BALANCECHANGE) [Debit Card Transaction Amount]
			 ,count(*) [Debit Card Transaction Count]
			 ,sum(BALANCECHANGE)*0.0130 [Debit Card Interchange Income] 
			 into #Debit_card_Data
			 from
					 (select PARENTACCOUNT,PARENTID
					 ,CONCAT(PARENTACCOUNT,PARENTID) UNID
					 ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(YEAR(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
					 else CONCAT(YEAR(EFFECTIVEDATE),month(EFFECTIVEDATE)) end  Effective_date
					 ,abs(BALANCECHANGE) BALANCECHANGE
					 ,cast(EFFECTIVEDATE as date) EFFECTIVEDATE
					  from ARCUSYM000..SAVINGSTRANSACTION
					where SOURCECODE='G' 
					) AF
			where UNID in (select UNID from #R2_checking_accounts where Checking_flag='R2')
			group by UNID,EOMONTH(EFFECTIVEDATE)
			order by UNID,EOMONTH(EFFECTIVEDATE)
			-- Doesnt match with saving transaction so only use it to calculate hte # debit cards
			drop table #debitCards
			select count(distinct NUMBER) [Debit Cards],count(Distinct Active_Cards) [Active Card],date 
			into #debitCards
			from 
				(select * 
				,case when STATUS=1 then NUMBER else null end Active_Cards
				,EOMONTH(DATEFROMPARTS(LEFT(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2))) date from ARCUSYM000..CARD
				where 
				CLOSEDATE is null 
				and BLOCKCODE is null
				 and RECLASSCODE is null 
				--and STATUS=1
				 and type!=99 and PARENTACCOUNT in (select PARENTACCOUNT from #R2_checking_accounts)
				 ) A
				 where date >='2017-08-31'
					group by date
					order by date

				 --- ACH calculation by savingstransaction
						-- drop table #ACH_table
							select unid,EOMONTH(EFFECTIVEDATE) EFFECTIVEDATE
					 ,sum(Balance_D) [Deposit Amount ACH], sum(abs(balance_w)) [Withdrawal Amount ACH]
					 ,count(*) [Transaction Count ACH]
					 ,Sum(Deposit_count) [Deposit Count ACH]
					 ,sum(Withdrawl_count) [Withdrawl Count ACH]
					  into #ACH_table
					  from 
					( select PARENTACCOUNT,PARENTID ID
					,CONCAT(PARENTACCOUNT,PARENTID) UNID
					,case when len(month(effectivedate))=1 then CONCAT(year(effectivedate),0,month(effectivedate))
					else CONCAT(year(effectivedate),month(effectivedate)) end Effective_date
					,cast(EFFECTIVEDATE as date) EFFECTIVEDATE
					,ACTIONCODE
					,case when ACTIONCODE ='D' then BALANCECHANGE else null end Balance_D
					,case when ACTIONCODE='W' then BALANCECHANGE else null end balance_w
					,case when ACTIONCODE ='D' then 1 else 0 end Deposit_count
					,case when ACTIONCODE='W' then 1 else 0 end Withdrawl_count
					 ,BALANCECHANGE

					  from ARCUSYM000..SAVINGSTRANSACTION
					  where SOURCECODE='E' and ACTIONCODE!='C') AA
					 -- left join #NAME BB
					 --on aa.PARENTACCOUNT=bb.PARENTACCOUNT
					   where UNID in (select UNID from #R2_checking_accounts)
					  group by aa.UNID,EOMONTH(EFFECTIVEDATE)
					   order by aa.UNID,EOMONTH(EFFECTIVEDATE)



					   ---  calculation by savingstransaction
						-- drop table #SavingTransaction
							select unid,EOMONTH(EFFECTIVEDATE) EFFECTIVEDATE
					 ,sum(Balance_D) [Deposit Amount], sum(abs(balance_w)) [Withdrawal Amount]
					 ,count(*) [Transaction Count]
					 ,Sum(Deposit_count) [Deposit Count]
					 ,sum(Withdrawl_count) [Withdrawl Count]
					  into #SavingTransaction
					  from 
					( select PARENTACCOUNT,PARENTID ID
					,CONCAT(PARENTACCOUNT,PARENTID) UNID
					,case when len(month(effectivedate))=1 then CONCAT(year(effectivedate),0,month(effectivedate))
					else CONCAT(year(effectivedate),month(effectivedate)) end Effective_date
					,cast(EFFECTIVEDATE as date) EFFECTIVEDATE
					,ACTIONCODE
					,case when ACTIONCODE ='D' then BALANCECHANGE else null end Balance_D
					,case when ACTIONCODE='W' then BALANCECHANGE else null end balance_w
					,case when ACTIONCODE ='D' then 1 else 0 end Deposit_count
					,case when ACTIONCODE='W' then 1 else 0 end Withdrawl_count
					 ,BALANCECHANGE

					  from ARCUSYM000..SAVINGSTRANSACTION
					  where  ACTIONCODE!='C') AA
					 -- left join #NAME BB
					 --on aa.PARENTACCOUNT=bb.PARENTACCOUNT
					   where UNID in (select UNID from #R2_checking_accounts)
					  group by aa.UNID,EOMONTH(EFFECTIVEDATE)
					   order by aa.UNID,EOMONTH(EFFECTIVEDATE)
			

			-- drop table if exists #Summary
			select a.*,case when b.UNID is null then 0 else 1 end Qualified
			,b.BALANCE [Qualified Balance]
			,c.[Debit Card Transaction Amount],c.[Debit Card Transaction Count],c.[Debit Card Interchange Income]
			,d.[Deposit Amount ACH],d.[Deposit Count ACH],d.[Withdrawal Amount ACH],d.[Withdrawl Count ACH],d.[Transaction Count ACH]
			,e.[Deposit Amount],e.[Deposit Count],e.[Withdrawal Amount],e.[Withdrawl Count],e.[Transaction Count]
			 into #Summary
			 from #R2_checking_accounts a
			left join #Qualified_account b
			on a.unid=b.UNID
			and a.Date=b.Process_date_v
			left join #Debit_card_Data c
			on a.UNID=c.UNID
			and a.Date=c.EFFECTIVEDATE
			left join #ACH_table D
			on a.UNID=d.UNID
			and a.Date=d.EFFECTIVEDATE
			left join #SavingTransaction E
			on a.UNID=e.UNID
			and a.Date=e.EFFECTIVEDATE
			
			
			-- drop table #Summary1
			select distinct  a.Date
			,count(distinct UNID) Total_account
			,sum([New Account]) [New Account]
			,sum([Close Account]) [Close Account]
			,sum(BALANCE) Balance
			,sum(Dividend) Dividend
			,sum(Qualified) [Qualified Account]
			,sum([Qualified Balance]) [Qualified Balance]
			,[Debit Cards]
			,[Active Card]
			,sum([debit card transaction count]) [debit card transaction count]
			,sum([debit card transaction amount]) [debit card transaction amount]
			,sum([Debit Card Interchange Income]) [Debit Card Interchange Income]
			,sum([deposit Amount ACH]) [deposit Amount ACH]
			,sum([deposit Count ACH]) [deposit Count ACH]
			,sum([Withdrawal Amount ACH]) [Withdrawal Amount ACH]
			,sum([Withdrawl Count ACH]) [Withdrawal Count ACH]
			,sum([Transaction Count ACH]) [Transaction Count ACH]

			,sum([deposit Amount]) [deposit Amount]
			,sum([deposit Count]) [deposit Count]
			,sum([Withdrawal Amount]) [Withdrawal Amount]
			,sum([Withdrawl Count]) [Withdrawal Count]
			,sum([Transaction Count]) [Transaction Count]
			,sum([Dividend])/sum(BALANCE) [Effective APY]
			 ,[COURTESY FEE]
			,[NSF FEE]
			,[OVERDRAFT FEE]
			into #Summary1
			 from #Summary a
			  left join #debitCards b
			  on a.Date=b.date
			  left join #Fee C
			  on a.date=C.date
			 where a.date>='2017-08-31'
			 group by a.date,[Debit Cards],[Active Card]
			 ,[COURTESY FEE]
			,[NSF FEE]
			,[OVERDRAFT FEE]
			 order by a.date
			
			
			-- drop table #Name_table_R2
			select a.*
			into #Name_table_R2
			from
				(select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date 
				from ARCUSYM000..NAME) a
		left join ARCUSYM000..SAVINGS b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		and a.ProcessDate=b.ProcessDate
		where a.TYPE=0
		and a.ProcessDate in (select max(Max_Processdate) from #processdate)
		--and a.Process_date=eomonth(dateadd(MONTH,-1,GETDATE()))
		--and b.SHARECODE=0 
		--and b.IRSCODE=0
		--and b.TYPE<9000
		--and b.type<>10 
		--and b.type<>11
		--and b.type<>12
		--and b.type<>14
		--and b.type<>113
		--and b.type<>510
		--and b.type<>512
		and b.ORIGINALDEPOSITDATE is not null
		and b.CLOSEDATE is null 
		and b.CHARGEOFFDATE is null
		and a.PARENTACCOUNT in (select PARENTACCOUNT from #Summary)

		--select max(Max_Processdate) from #processdate
		go
	drop table if exists #duplicate
	select SSN,count(PARENTACCOUNT) CNT 
	into #duplicate
	from #Name_table_R2
	group by SSN
	having count(PARENTACCOUNT)>1
	
	go
	
	drop table if exists #NAME
	select a.SSN,PARENTACCOUNT
	into #NAME
	from #Name_table_R2 A
	left join #duplicate b
	on a.SSN=b.SSN
	where b.SSN is null
	
	go
	
	
	drop table if exists #temp15
	select SSN,AccountNumber as parentaccount
	into #temp15
	from AE_EDW..D_Member
	where SSN in
	(select SSN from #duplicate)

	
	go

	drop table if exists #Name_final
	select *
	into #Name_final
	from #NAME
	union 
	select * from #temp15

			
			 -- drop table if exists #CC_data
			 -- Credit Card table 
			 select [Social Security Number] SSN,Durable_Key,[Account Number],[Master Account Key]
			 ,PARENTACCOUNT PARENTACCOUNT_CC
			 ,extract_datepart,eomonth(DATEFROMPARTS(left(extract_datepart,4),right(extract_datepart,2),1)) Extract_date
			 ,Extract_ACCOUNT_OPEN_DATE,Closed_account_flag,NewAccountFLag
			 ,case when Extract_ACCOUNT_OPEN_DATE >=201708 then 1 else 0 end Opendate_flag_201708
			 ,spend,([Last Statment Sale Count]-[Last Statement Return Count]) Total_CC_transaction
			 ,[Last Statement Balance Amount],RevolvingBalance,[Last Statement Cash Amount],[Last Statement Merchandise Average Daily Balance Amount]
			 ,Promo_Balance,Protected_Balance
			 ,[Calc Norm Cash Annual Rate],[Calc Norm Mrch Annual Rate]
			 ,[Last Statement Cash Interest Amount],[Accumulated Merchandise Interest Amount]
			 ,Promo_Current_Interest,Protected_Current_Interest
			 ,isnull([Last Statement Cash Interest Amount],0)+isnull([Accumulated Merchandise Interest Amount],0)
			 +isnull(Promo_Current_Interest,0)+isnull(Protected_Current_Interest,0) as interest_amount
			 ,[Credit Limit]
			 ,[Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]
			 +[Last Statement Charge Overlimit Amount]
			 +[Last Statement Charge Late Amount]+[Last Statement Charge Sale Amount]
			 +[Last Statement External Fee Amount]+ [Dynamic Fees Fee Charges Statement Year To Date]
			 +[Miscellaneous Fee Charges Since Last Statement]+ [Dynamic Interest Fees Charges Statement Year To Date] as fee
			 ,([Last Statement Sale Amount]-[Last Statement Return Amount]) *0.00324 as visa_expense
			 ,([Last Statement Sale Amount]-[Last Statement Return Amount]) *0.018 as Interchange_income
			 ,[Last Statement Balance Amount]*0.02/12 as COF
			 ,case when TRIPFLAG='I' then 0.9 else 2.75 end as processing_cost
			 ,ChargeoffAmount_final,TRIPFLAG,[Card Description]
			 ,case when [Card Description] in ('MasterCard Platinum Rewards','MasterCard World Credit','MasterCard Merchant Platinum')
			  then ([Last Statement Sale Amount]-[Last Statement Return Amount]) * 0.01  end as Reward_expense
				 into #CC_data
				 from TMGData..cardholder a 
				left join (select SSN,PARENTACCOUNT from #Name_final group by SSN,PARENTACCOUNT) b
				on a.[Social Security Number]=b.SSN
			  where Active_Flag=1 and [External Status Code] ='' and [Internal Status Code] in ('','N') 
			  and [Social Security Number] in (select SSN from #Name_final)
		go
		Drop table if Exists #Tran_R2_cards
				Select Transaction_date,RDT_CHD_ACCOUNT_NUMBER ACCOUNT_NUMBER,Sum(Amount) Amount,Sum(Cash_advance) [$ Cash Advance],Sum(Count_transaction) [# Tran],Sum(RDT_DETL_ICHG_FEE_AM) Interchange
				Into #Tran_R2_cards
				from
									(
									select [RDT_TRANSACTION_CODE],[RDT_MRCH_SIC_CODE],RDT_CHD_ACCOUNT_NUMBER,[RDT_TRANSACTION_DATE]
									,Transaction_date,[RDT_TRANSACTION_AMOUNT],APR_EAPR_CASH_INT,APR_EAPR_MRCH_INT,RDT_BKDT_ADDITIONAL_INT,Cast(RDT_DETL_ICHG_FEE_AM as money) RDT_DETL_ICHG_FEE_AM
									,case when [RDT_TRANSACTION_CODE]=255 then cast(RDT_TRANSACTION_AMOUNT as money)*-1 
									when [RDT_TRANSACTION_CODE]=253 then cast(RDT_TRANSACTION_AMOUNT as money) else 0 end Amount
									,case when [RDT_TRANSACTION_CODE]=254 then cast(RDT_TRANSACTION_AMOUNT as money) else 0 end Cash_advance
									,case when [RDT_TRANSACTION_CODE]=255 then -1 when [RDT_TRANSACTION_CODE]=253 then 1 else 0 end Count_transaction
									,case when [RDT_TRANSACTION_CODE]=254 then 1 else 0 end Count_transaction_cash_advance
									,case when [RDT_TRANSACTION_CODE]=271 then cast(RDT_TRANSACTION_AMOUNT as money) else 0 end [$ Payment]
									,case when [RDT_TRANSACTION_CODE]=271 then 1 else 0 end [# Payment]
									from (select *,cast(left(concat(20,[RDT_TRANSACTION_DATE]),6) as int) Transaction_date from TMGData.dbo.TMGCompleteCC) a
									left join #CC_data b
									on a.RDT_CHD_ACCOUNT_NUMBER=b.[Account Number]
									and a.Transaction_date=b.extract_datepart
									where [RDT_TRANSACTION_CODE] in (253,254,255,271) and RDT_MRCH_SIC_CODE not in (0,3,6) and Transaction_date >=201901 
									and b.[Account Number] in (select [Account Number] from #CC_data where [Card Description] in ('Mastercard Platinum','MasterCard Platinum Rewards','MasterCard World Credit'))
									) a  Group by Transaction_date,RDT_CHD_ACCOUNT_NUMBER


		go

					  drop table if exists #CC_data_All
			 -- Credit Card table 
			 select [Social Security Number] SSN,a.Durable_Key,[Account Number],[Master Account Key]
			 ,a.extract_datepart,eomonth(DATEFROMPARTS(left(a.extract_datepart,4),right(a.extract_datepart,2),1)) Extract_date
			 ,Extract_ACCOUNT_OPEN_DATE,Closed_account_flag,NewAccountFLag
			 ,case when Extract_ACCOUNT_OPEN_DATE >=201708 then 1 else 0 end Opendate_flag_201708
			 ,spend,([Last Statment Sale Count]-[Last Statement Return Count]) Total_CC_transaction
			 ,[Last Statement Balance Amount],RevolvingBalance,[Last Statement Cash Amount],[Last Statement Merchandise Average Daily Balance Amount]
			 ,Promo_Balance,Protected_Balance,[Calc Norm Cash Annual Rate],[Calc Norm Mrch Annual Rate]
			 ,[Last Statement Cash Interest Amount],[Accumulated Merchandise Interest Amount]
			 ,Promo_Current_Interest,Protected_Current_Interest
			 ,isnull([Last Statement Cash Interest Amount],0)+isnull([Accumulated Merchandise Interest Amount],0)
			 +isnull(Promo_Current_Interest,0)+isnull(Protected_Current_Interest,0) as interest_amount
			 ,[Credit Limit],[Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Overlimit Amount]
			 +[Last Statement Charge Late Amount]+[Last Statement Charge Sale Amount]
			 +[Last Statement External Fee Amount]+ [Dynamic Fees Fee Charges Statement Year To Date]
			 +[Miscellaneous Fee Charges Since Last Statement]+ [Dynamic Interest Fees Charges Statement Year To Date] as fee
			 ,([Last Statement Sale Amount]-[Last Statement Return Amount]) *0.00324 as visa_expense
			 ,([Last Statement Sale Amount]-[Last Statement Return Amount]) *0.018 as Interchange_income
			 ,[Last Statement Balance Amount]*0.02/12 as COF
			 ,case when TRIPFLAG='I' then 0.9 else 2.75 end as processing_cost
			 ,ChargeoffAmount_final,TRIPFLAG,[Card Description]
			 ,case when [Card Description] in ('MasterCard Platinum Rewards','MasterCard World Credit','MasterCard Merchant Platinum')
			  then ([Last Statement Sale Amount]-[Last Statement Return Amount]) * 0.01  end as Reward_expense
				 into #CC_data_All
				 from TMGData..cardholder a 
				left join (select Durable_Key,extract_datepart from #CC_data group by Durable_Key,extract_datepart) b
				on a.Durable_Key=b.Durable_Key and a.extract_datepart=b.extract_datepart
			  where Active_Flag=1 and [External Status Code] ='' and [Internal Status Code] in ('','N') 
			  and b.Durable_Key is null
		go
		Drop table if Exists #Tran_All_cards
				Select Transaction_date,RDT_CHD_ACCOUNT_NUMBER ACCOUNT_NUMBER,Sum(Amount) Amount,Sum(Cash_advance) [$ Cash Advance],Sum(Count_transaction) [# Tran],Sum(RDT_DETL_ICHG_FEE_AM) Interchange
				Into #Tran_All_cards
				from
									(
									select [RDT_TRANSACTION_CODE],[RDT_MRCH_SIC_CODE],RDT_CHD_ACCOUNT_NUMBER,[RDT_TRANSACTION_DATE]
									,Transaction_date,[RDT_TRANSACTION_AMOUNT],APR_EAPR_CASH_INT,APR_EAPR_MRCH_INT,RDT_BKDT_ADDITIONAL_INT,Cast(RDT_DETL_ICHG_FEE_AM as money) RDT_DETL_ICHG_FEE_AM
									,case when [RDT_TRANSACTION_CODE]=255 then cast(RDT_TRANSACTION_AMOUNT as money)*-1 
									when [RDT_TRANSACTION_CODE]=253 then cast(RDT_TRANSACTION_AMOUNT as money) else 0 end Amount
									,case when [RDT_TRANSACTION_CODE]=254 then cast(RDT_TRANSACTION_AMOUNT as money) else 0 end Cash_advance
									,case when [RDT_TRANSACTION_CODE]=255 then -1 when [RDT_TRANSACTION_CODE]=253 then 1 else 0 end Count_transaction
									,case when [RDT_TRANSACTION_CODE]=254 then 1 else 0 end Count_transaction_cash_advance
									,case when [RDT_TRANSACTION_CODE]=271 then cast(RDT_TRANSACTION_AMOUNT as money) else 0 end [$ Payment]
									,case when [RDT_TRANSACTION_CODE]=271 then 1 else 0 end [# Payment]
									from (select *,cast(left(concat(20,[RDT_TRANSACTION_DATE]),6) as int) Transaction_date from TMGData.dbo.TMGCompleteCC) a
									left join #CC_data_All b
									on a.RDT_CHD_ACCOUNT_NUMBER=b.[Account Number]
									and a.Transaction_date=b.extract_datepart
									where [RDT_TRANSACTION_CODE] in (253,254,255,271) and RDT_MRCH_SIC_CODE not in (0,3,6) and Transaction_date >=201901 
									and b.[Account Number] is not null
									) a  Group by Transaction_date,RDT_CHD_ACCOUNT_NUMBER
		select extract_datepart,count(distinct Durable_Key) [# Cards] from #CC_data where extract_datepart>=201901 Group by extract_datepart order by extract_datepart
		select extract_datepart,count(distinct Durable_Key) [# Cards] from #CC_data_All where extract_datepart>=201901 Group by extract_datepart order by extract_datepart
		Select Transaction_date,Count(ACCOUNT_NUMBER) [# R2 active cards],sum(Amount) Amount,sum(abs(Interchange)) Interchange,sum([# Tran]) [# Tran]
		from #Tran_R2_cards where Transaction_date>=201901 group by Transaction_date order by Transaction_date 
		Select Transaction_date,Count(ACCOUNT_NUMBER) [# Other active cards],sum(Amount) Amount,sum([# Tran]) [# Tran],sum(abs(Interchange)) Interchange
		from #Tran_All_cards where Transaction_date>=201901 group by Transaction_date order by Transaction_date 
		go
		select 
		Extract_reportdate,Count(distinct Durable_Key) [# Cards],sum(MthlyPtsEarned) MthlyPtsEarned,sum(MthlyPtsRedeemed) MthlyPtsRedeemed
		from
				(
				select 
				a.Durable_Key,Master_Account_Key,ReportDate,MthlyPtsEarned,MthlyPtsRedeemed ,Extract_reportdate
				from (select *,case when len(month(ReportDate))=1 then concat(year(ReportDate),0,month(ReportDate))
				else concat(year(ReportDate),month(ReportDate)) end Extract_reportdate from analytics..Rewards) a
				left join #CC_data b
				on a.Durable_Key=b.Durable_Key and a.Master_Account_Key=b.[Master Account Key] and b.extract_datepart=a.Extract_reportdate
				where ReportDate>='2019-01-01'-- and b.Durable_Key is not null
				and b.[Master Account Key] in (select [Master Account Key] from #CC_data where [Card Description] in ('MasterCard Platinum Rewards','MasterCard World Credit'))
				) S
		group by Extract_reportdate
		order by Extract_reportdate


		go

		drop table if exists #Transaction_rewards	
		select	
		Transaction_date
		,sum(Gas_Amount) Gas_Amount,sum(GROCERY_Amount) GROCERY_Amount,sum(Other_Amount) Other_Amount
		,sum(a.Amount) Amount
		,sum(a.Count_transaction) [# Transaction]
		,sum(Cash_advance) Cash_advance
		,sum(Count_transaction_cash_advance) Count_transaction_cash_advance
		,sum([# Payment]) [# Payment],sum([$ Payment]) [$ Payment]
		--into #Transaction_rewards
		from	
						(select a.*,case when b.[MCC Group (final)]='GAS AND FUEL SERVICES' then Amount else 0 end Gas_Amount
						,case when b.[MCC Group (final)]='GROCERY STORES' then Amount else 0 end GROCERY_Amount
						,case when b.[MCC Group (final)] not in ('GROCERY STORES','GAS AND FUEL SERVICES') then Amount else 0 end Other_Amount
						,b.[MCC Category],b.[MCC Description],b.[MCC Group (final)]
						from
									(
									select [RDT_TRANSACTION_CODE]
									,[RDT_MRCH_SIC_CODE]
									,RDT_CHD_ACCOUNT_NUMBER,[RDT_TRANSACTION_DATE]
									,Transaction_date
									,[RDT_TRANSACTION_AMOUNT]
									,case when [RDT_TRANSACTION_CODE]=255 then cast(RDT_TRANSACTION_AMOUNT as money)*-1 
									when [RDT_TRANSACTION_CODE]=253 then cast(RDT_TRANSACTION_AMOUNT as money) else 0 end Amount
									,case when [RDT_TRANSACTION_CODE]=254 then cast(RDT_TRANSACTION_AMOUNT as money) else 0 end Cash_advance
									,case when [RDT_TRANSACTION_CODE]=255 then -1 
									 when [RDT_TRANSACTION_CODE]=253 then 1 else 0 end Count_transaction
									,case when [RDT_TRANSACTION_CODE]=254 then 1 else 0 end Count_transaction_cash_advance
									,case when [RDT_TRANSACTION_CODE]=271 then cast(RDT_TRANSACTION_AMOUNT as money) else 0 end [$ Payment]
									,case when [RDT_TRANSACTION_CODE]=271 then 1 else 0 end [# Payment]
									from (select *,cast(left(concat(20,[RDT_TRANSACTION_DATE]),6) as int) Transaction_date from TMGData.dbo.TMGCompleteCC) a
									left join #CC_data b
									on a.RDT_CHD_ACCOUNT_NUMBER=b.[Account Number]
									and a.Transaction_date=b.extract_datepart
									--(select *,cast([RDT_TRANSACTION_DATE]as int) [TRANSACTION_DATE] from TMGData.dbo.TMGCompleteCC) bb
									where 
									[RDT_TRANSACTION_CODE] in (253,254,255,271) 
									and RDT_MRCH_SIC_CODE not in (0,3,6) and Transaction_date >=201901 
									and b.[Account Number] in (select [Account Number] from #CC_data where [Card Description] in ('MasterCard Platinum Rewards','MasterCard World Credit'))
									) a
						 left join Analytics.brijesh.MCC_Mapping b
						 on a.[RDT_MRCH_SIC_CODE] = b.[MCC Code]
						   
						 ) A
			group by Transaction_date
			order by Transaction_date
			 


			select 
			extract_datepart,count(distinct Durable_Key) [# Cards],sum([Last Statement Balance Amount]) [Last Statement Balance Amount]
			,sum(RevolvingBalance) RevolvingBalance
			, sum(interest_amount) interest_amount,sum(fee) fee
			,sum(Interchange_income) Interchange_income,sum(Reward_expense) Reward_expense,sum(COF) COF
			from #CC_data where extract_datepart>=201901
			group by extract_datepart
			order by extract_datepart

			select TRIPFLAG,count(distinct Durable_Key) [# Card]
			,sum([Last Statement Balance Amount]) [Balance CC]
		,sum(RevolvingBalance) [Revolving Balance CC] from #CC_data where extract_datepart=202005 
		group by TRIPFLAG
		order by TRIPFLAG

		drop table if exists #Inactive_paydown
		select *,case when [# Month]=[# Inactive] then 1 else 0 end Only_Inactive,case when ([# Inactive]+[# paydown])=[# Month] then 1 else 0 end Only_Inactive_paydown
		,case when [# Month]=[# Inactive] then 'Only Inactive'
		when [# Month]!=[# Inactive] and [inactive pre 24]>=12 then '12+ Inactive'
		when [# Month]!=[# Inactive] and [inactive pre 24]<12 then '> 12 Inactive'
		 end Flag,case when [inactive pre 12]=12 then 1 else 0 end Past12_inactive
		into #Inactive_paydown
		from
			(select 
			Durable_Key,PARENTACCOUNT_CC,SSN,max(case when Extract_ACCOUNT_OPEN_DATE<201708 then 1 else 0 end) Pre_card_R2_flag
			,count(distinct extract_datepart) [# Month],sum(inactive_flag) [# Inactive],sum(Paydown_flag) [# paydown]
			,sum(case when extract_datepart between 201907 and 202006 then inactive_flag else 0 End) [inactive pre 12]
			,sum(case when extract_datepart between 201907 and 202006 then Paydown_flag else 0 End) [Paydown pre 12]
			,sum(case when extract_datepart between 201807 and 201906 then inactive_flag else 0 End) [inactive pre pre 12]
			,sum(case when extract_datepart between 201807 and 201906 then Paydown_flag else 0 End) [Paydown pre pre 12]
			,sum(case when extract_datepart between 201807 and 202006 then inactive_flag else 0 End) [inactive pre 24]
			,sum(case when extract_datepart between 201807 and 202006 then Paydown_flag else 0 End) [Paydown pre 24]
			from
				(select extract_datepart,Extract_ACCOUNT_OPEN_DATE,SSN,Durable_Key,[Account Number],PARENTACCOUNT_CC,spend,Balance,RevolvingBalance 
				,case when spend=0 and Balance=0 then 1 else 0 end Inactive_flag
				,case when spend=0 and Balance>0 then 1 else 0 end Paydown_flag
				from
						(select extract_datepart,SSN,Extract_ACCOUNT_OPEN_DATE,Durable_Key,[Account Number],PARENTACCOUNT_CC,cast(spend as money) Spend,Cast([Last Statement Balance Amount] as Money) Balance,RevolvingBalance 
						from #CC_data) A 
				group by extract_datepart,Extract_ACCOUNT_OPEN_DATE,SSN,Durable_Key,[Account Number],PARENTACCOUNT_CC,spend,Balance,RevolvingBalance ) A
			group by Durable_Key,PARENTACCOUNT_CC,SSN) A
		
				
		drop table if exists #Inactive_202006
		select Durable_Key,Extract_date 
		into #Inactive_202006
		from #CC_data	where extract_datepart=202006
		
			drop table if exists #CC_Inactive_Summary
		select  Extract_date,
		count(distinct a.Durable_Key)--,a.SSN,a.PARENTACCOUNT_CC,b.Past12_inactive--,b.Flag,b.Pre_card_R2_flag
		,count(distinct Extract_date) [# Month]
		,sum(NewAccountFLag) [New Cards]
		,sum(case when Closed_account_flag='1' then 1 else 0 end ) [Close Cards]
		,sum([Credit Limit]) [Credit Limit]
		,sum(spend) [Spend CC]
		,sum([Last Statement Balance Amount]) [Balance CC]
		,sum(RevolvingBalance) [Revolving Balance CC]
		,sum([Last Statement Merchandise Average Daily Balance Amount]) [Merchant Balance CC]
		,sum([Last Statement Cash Amount]) [Cash Balance CC]
		,sum(Promo_Balance) [Promo Balance CC]
		,sum(Protected_Balance) [Protected Balance]
		,sum([Last Statement Cash Interest Amount]) [Cash Interest Amount CC]
		,sum([Accumulated Merchandise Interest Amount]) [Merchant Interest Amount CC]
		,sum(Promo_Current_Interest) [Promo Interest Amount CC]
		,sum(Protected_Current_Interest) [Protected Interest Amount CC]
		,sum(Total_CC_transaction) [# Transactions CC]
		,sum(interest_amount+Interchange_income+fee) [Income CC]
		,sum(COF+ChargeoffAmount_final+visa_expense+Reward_expense+processing_cost) [Expense CC]
		into #CC_Inactive_Summary
		 from #CC_data a left join #Inactive_paydown b on a.Durable_Key=b.Durable_Key
			where a.Durable_Key in (select Durable_Key from #Inactive_202006) and b.Past12_inactive=1
		group by Extract_date--a.Durable_Key,a.SSN,a.PARENTACCOUNT_CC,b.Past12_inactive--,b.Flag,b.Pre_card_R2_flag
		order by Extract_date--a.Durable_Key
		
		select Pre_card_R2_flag,flag,count(distinct Durable_Key) [# Cards],avg([# Month]) [# Month]
		,sum([New Cards]) [New Cards]
		,sum([Close Cards]) [Close Cards]
		,sum([Credit Limit]) [Credit Limit]
		,sum([Spend CC]) [Spend CC]
		,sum([Balance CC]) [Balance CC]
		,sum([Revolving Balance CC]) [Revolving Balance CC]
		,sum([Merchant Balance CC]) [Merchant Balance CC]
		,sum([Cash Balance CC]) [Cash Balance CC]
		,sum([Promo Balance CC]) [Promo Balance CC]
		,sum([Protected Balance]) [Protected Balance]
		,sum([Cash Interest Amount CC]) [Cash Interest Amount CC]
		,sum([Merchant Interest Amount CC]) [Merchant Interest Amount CC]
		,sum([Promo Interest Amount CC]) [Promo Interest Amount CC]
		,sum([Protected Interest Amount CC]) [Protected Interest Amount CC]
		,sum([# Transactions CC]) [# Transactions CC]
		,sum([Income CC]) [Income CC]
		,sum([Expense CC]) [Expense CC] 
		from #CC_Inactive_Summary
		group by Pre_card_R2_flag,flag	

		select Pre_card_R2_flag,Flag,count(Durable_Key) [# Cards],count(distinct [PARENTACCOUNT_CC]) [# Members],avg([deposit amount]) [deposit amount],avg([Withdrawal Amount]) [Withdrawal Amount]
				,avg([deposit count]) [deposit count],avg([Withdrawal count]) [Withdrawal Count] from 
				(select PARENTACCOUNT_CC,Durable_Key,Pre_card_R2_flag,Flag,[deposit amount],[Withdrawal Amount],[deposit count],[Withdrawal Count]
				from 
				#Inactive_paydown a left join 
				(select left(UNID,10) PARENTACCOUNT,avg([deposit amount]) [deposit amount],avg([Withdrawal Amount]) [Withdrawal Amount]
				,avg([deposit count]) [deposit count],avg([Withdrawl count]) [Withdrawal Count] from  #SavingTransaction where EFFECTIVEDATE between '2018-07-01' and '2020-06-01'
				group by left(UNID,10)) b
				on a.PARENTACCOUNT_CC=b.PARENTACCOUNT) A
		group by Pre_card_R2_flag,Flag
		

		drop table if exists #groupproducttype_Deposits0
		select * ,case when ProductName like '%money%'  or ProductName like '% MM %' then 'MoneyMarket'
		when ProductName='Youth Savings' and ApplicationDescription='Certificates' then 'Savings'
		when ProductCode=0 and ApplicationDescription='Certificates' then 'Savings'
		when ProductName='40 Month CD' and ApplicationDescription='Certificates' then 'Checking'
		when ProductName='Certificate' and ApplicationDescription='Certificates' then 'Checking' 
		when ProductName='Public Funds' and ApplicationDescription='Certificates' then 'Certificates'  
		 else ApplicationDescription end Product_Group_wise
		into #groupproducttype_Deposits0
		from
		(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName
		,ApplicationDescription,ApplicationTableName
		 from [AE_EDW].[tempods].[S_CRMProductType] a
		left join [AE_EDW].[tempods].[S_CRMApplicationType] b
		on a.ApplicationTypeID=b.ApplicationTypeID
		where ApplicationDescription is not null
		and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a
		order by ProductCode

				go
		go
		drop table if exists #processdate
		select Process_date,max(ProcessDate) Process_date_max
		into #processdate
		from
				(select ProcessDate,left(ProcessDate,6) Process_date from ARCUSYM000..SAVINGS
				where  ProcessDate>=20200131
				group by ProcessDate) A
		group by Process_date


		go
		 Drop table if exists #savings_account
		select Pre_card_R2_flag,Flag,count(distinct [PARENTACCOUNT]) [# Member],avg(BALANCE) avg_BALANCE,sum([# Deposit porducts]) [# Deposit porducts],sum([CHARGEOFFAMOUNT Deposit]) [CHARGEOFFAMOUNT Deposit],sum([# Chargeoff Deposit]) [# Chargeoff Deposit]
			,sum([# Savings]) [# Savings],sum([# Checking]) [# Checking],sum([# Certificates]) [# Certificates],sum([# MM]) [# MM]
			,avg([Savings Balance]) [avg Savings Balance],avg([Checking Balance]) [avg Checking Balance],avg([Certificates Balance]) [avg Certificates Balance]
			,sum([MM Balance]) [MM Balance],sum([Savings CHARGEOFFAMOUNT]) [Savings CHARGEOFFAMOUNT],sum([Checking CHARGEOFFAMOUNT]) [Checking CHARGEOFFAMOUNT],sum(Close_accounts) Close_accounts
			,sum([# close Savings]) [# close Savings],sum([# close Checking]) [# close Checking],sum([# close Certificates]) [# close Certificates],sum([# close MM]) [# close MM]
		from
			(select 
			[PARENTACCOUNT],unid,g.Pre_card_R2_flag,g.Flag,count(distinct ProcessDate_v) [# month],avg(BALANCE) BALANCE,max([# Deposit porducts]) [# Deposit porducts],sum(CHARGEOFFAMOUNT_v) [CHARGEOFFAMOUNT Deposit],max([# Chargeoff Deposit]) [# Chargeoff Deposit]
			,max([# Savings]) [# Savings],max([# Checking]) [# Checking],max([# Certificates]) [# Certificates],max([# MM]) [# MM]
			,avg([Savings Balance]) [Savings Balance],avg([Checking Balance]) [Checking Balance],avg([Certificates Balance]) [Certificates Balance]
			,sum([MM Balance]) [MM Balance],sum([Savings CHARGEOFFAMOUNT]) [Savings CHARGEOFFAMOUNT],sum([Checking CHARGEOFFAMOUNT]) [Checking CHARGEOFFAMOUNT],max(Close_flag) Close_accounts
			,max([# close Savings]) [# close Savings],max([# close Checking]) [# close Checking],max([# close Certificates]) [# close Certificates],max([# close MM]) [# close MM]
			from		
					(
					select *	
					,case when Product_Group_wise='Savings'	then BALANCE else 0 end [Savings Balance]
					,case when Product_Group_wise='Checking' then BALANCE else 0 end [Checking Balance]
					,case when Product_Group_wise='Certificates' then BALANCE else 0 end [Certificates Balance]
					,case when Product_Group_wise='Money Market'	then BALANCE else 0 end [MM Balance]
					,case when Product_Group_wise in ('Savings','Checking','Certificates','Money Market') and Close_flag=0 and Chargeoff_flag=0 then 1 else 0 end [# Deposit porducts]
					,case when Product_Group_wise='Savings' and Close_flag=0 and Chargeoff_flag=0	then 1 else 0 end [# Savings]
					,case when Product_Group_wise='Checking' and Close_flag=0 and Chargeoff_flag=0 then 1 else 0 end [# Checking]
					,case when Product_Group_wise='Certificates' and Close_flag=0 and Chargeoff_flag=0 then 1 else 0 end [# Certificates]
					,case when Product_Group_wise='Money Market' and Close_flag=0 and Chargeoff_flag=0	then 1 else 0 end [# MM]
					,case when Product_Group_wise='Savings' and Close_flag=1	then 1 else 0 end [# close Savings]
					,case when Product_Group_wise='Checking' and Close_flag=1 then 1 else 0 end [# close Checking]
					,case when Product_Group_wise='Certificates' and Close_flag=1 then 1 else 0 end [# close Certificates]
					,case when Product_Group_wise='Money Market' and Close_flag=1	then 1 else 0 end [# close MM]
					,case when Product_Group_wise='Savings'	then CHARGEOFFAMOUNT_v else 0 end [Savings CHARGEOFFAMOUNT]
					,case when Product_Group_wise='Checking' then CHARGEOFFAMOUNT_v else 0 end [Checking CHARGEOFFAMOUNT]
					from
							(
							select 
							ProcessDate,ProcessDate_v,UNID,[PARENTACCOUNT],id,type,opendate,MATURITYDATE,CLOSEDATE,Close_date,CHARGEOFFDATE_v,CHARGEOFFAMOUNT_v
							,case when closedate is null and chargeoffdate is null then BALANCE else 0 end BALANCE,e.Product_Group_wise
							,case when CHARGEOFFAMOUNT_v>0 then 1 else 0 end [# Chargeoff Deposit]
							,case when Close_date=ProcessDate_v then 1 else 0 end Close_flag
							,case when CHARGEOFFDATE_v=ProcessDate_v then 1 else 0 end Chargeoff_flag
							,case when Product_Group_wise='Certificates' and BALANCE=0 then 0 else 1 end carryforward_flag
							from 
										(select *,case when [EOM_Process Date]=[Process Date] then 1 else 0 end EOM_flag 
											,case when (closedate is null and CHARGEOFFDATE is null) or ProcessDate_v=close_date 
											or ProcessDate_v=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
											from
												(select a.*,EOMONTH([Process Date]) [EOM_Process Date]
												,case when OPENDATE=CLOSEDATE then 0 else 1 end Funded_loan_flag
												,case when ProcessDate_v=CHARGEOFFDATE_v then CHARGEOFFAMOUNT else 0 end CHARGEOFFAMOUNT_v
												,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
												else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
												 from 
													 ( select * ,concat(PARENTACCOUNT,id) UNID,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
													 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v,left(ProcessDate,6) ProcessDate_v
													,datefromparts(left(processdate,4),right(left(processdate,6),2),right(processdate,2)) [Process Date] from arcusym000..SAVINGS
													--where (chargeoffdate is null or chargeoffdate>='2020-01-01')
													) a
													where  ProcessDate in (select Process_date_max from #processdate)
													and ProcessDate_v between 201807 and 202006
											) F
									 ) aa
							left join #groupproducttype_Deposits0 E
							on e.ProductCode=aa.TYPE
							 where  PARENTACCOUNT in (select PARENTACCOUNT_CC from #CC_Inactive_Summary) --and EOM_flag=1 
							--and (CLOSEDATE is null) 
							and Funded_loan_flag=1 and Open_Flag=1
							group by ProcessDate,ProcessDate_v,[PARENTACCOUNT],unid,id,type,CLOSEDATE,CHARGEOFFDATE_v,CHARGEOFFAMOUNT_v,BALANCE,e.Product_Group_wise,opendate,MATURITYDATE,chargeoffdate,Close_date
							) A
					where carryforward_flag=1
					) AA  left join #CC_Inactive_Summary G
					on AA.PARENTACCOUNT=g.PARENTACCOUNT_CC
					group by [PARENTACCOUNT],unid,g.Pre_card_R2_flag,g.Flag) F 
					group by Pre_card_R2_flag,Flag
				
				go

				drop table if exists #loantable
				select Pre_card_R2_flag,Flag,count(Distinct PARENTACCOUNT) [# Members],count(distinct UNID) [# loan]
				,sum(CHARGEOFFAMOUNT) CHARGEOFFAMOUNT,max([# chargeoff]) [# chargeoff]
						,avg(balance) balance,count(Loan_category) Loan_category,avg(Vehicle_BALANCE) Vehicle_BALANCE,avg(Personal_BALANCE) Personal_BALANCE
						,avg(HELOC_BALANCE) HELOC_BALANCE,avg(Other_RealEstate_BALANCE) Other_RealEstate_BALANCE
						,Sum([# personal]) [# personal],Sum([# Vehicle]) [# Vehicle]
						,Sum([# HELOC]) [# HELOC] ,Sum([# other RealEstate]) [# other RealEstate] 
						,sum(Vehicle_CHARGEOFFAMOUNT) Vehicle_CHARGEOFFAMOUNT,sum(Personal_CHARGEOFFAMOUNT) Personal_CHARGEOFFAMOUNT,sum(Mortgage_CHARGEOFFAMOUNT) Mortgage_CHARGEOFFAMOUNT
						,sum(HELOC_CHARGEOFFAMOUNT) HELOC_CHARGEOFFAMOUNT,sum(Other_RealEstate_CHARGEOFFAMOUNT) Other_RealEstate_CHARGEOFFAMOUNT
						,sum([new HELOC]) [new HELOC]
						,Sum([# close HELOC]) [# close HELOC],Sum([# close other RealEstate]) [# close other RealEstate],Sum([# close personal]) [# close personal],Sum([# close Vehicle]) [# close Vehicle]
						,Sum([# close personal 0%]) [# close personal 0%],Sum([# close Mortgage Hardship]) [# close Mortgage Hardship],Sum([# personal 0%]) [# personal 0%],sum([new personal 0%]) [new personal 0%]

				from
						(select PARENTACCOUNT,UNID,g.Pre_card_R2_flag,g.Flag,count(Process_date) [# month],sum(CHARGEOFFAMOUNT) CHARGEOFFAMOUNT,max([# chargeoff]) [# chargeoff]
						,avg(balance) balance,count(Loan_category) Loan_category,avg(Vehicle_BALANCE) Vehicle_BALANCE,avg(Personal_BALANCE) Personal_BALANCE
						,avg(HELOC_BALANCE) HELOC_BALANCE,avg(Other_RealEstate_BALANCE) Other_RealEstate_BALANCE
						,max([# personal]) [# personal],max([# Vehicle]) [# Vehicle]
						,max([# HELOC]) [# HELOC] ,max([# other RealEstate]) [# other RealEstate] 
						,sum(Vehicle_CHARGEOFFAMOUNT) Vehicle_CHARGEOFFAMOUNT,sum(Personal_CHARGEOFFAMOUNT) Personal_CHARGEOFFAMOUNT,sum(Mortgage_CHARGEOFFAMOUNT) Mortgage_CHARGEOFFAMOUNT
						,sum(HELOC_CHARGEOFFAMOUNT) HELOC_CHARGEOFFAMOUNT,sum(Other_RealEstate_CHARGEOFFAMOUNT) Other_RealEstate_CHARGEOFFAMOUNT
						,sum([new HELOC]) [new HELOC]
						,max([# close HELOC]) [# close HELOC],max([# close other RealEstate]) [# close other RealEstate],max([# close personal]) [# close personal],max([# close Vehicle]) [# close Vehicle]
						,max([# close personal 0%]) [# close personal 0%],max([# close Mortgage Hardship]) [# close Mortgage Hardship],max([# personal 0%]) [# personal 0%],sum([new personal 0%]) [new personal 0%]
						from
								(select *
								,case when Loan_category='Vehicle' then BALANCE else 0 end Vehicle_BALANCE
								,case when Loan_category='Personal' then BALANCE else 0 end Personal_BALANCE
								,case when Loan_category='HELOC' then BALANCE else 0 end HELOC_BALANCE
								,case when Loan_category='Other RealEstate' then BALANCE else 0 end Other_RealEstate_BALANCE
								,case when Loan_category='Vehicle' then CHARGEOFFAMOUNT else 0 end Vehicle_CHARGEOFFAMOUNT
								,case when Loan_category='Personal' then CHARGEOFFAMOUNT else 0 end Personal_CHARGEOFFAMOUNT
								,case when Loan_category='Mortgage' then CHARGEOFFAMOUNT else 0 end Mortgage_CHARGEOFFAMOUNT
								,case when Loan_category='HELOC' then CHARGEOFFAMOUNT else 0 end HELOC_CHARGEOFFAMOUNT
								,case when Loan_category='Other RealEstate' then CHARGEOFFAMOUNT else 0 end Other_RealEstate_CHARGEOFFAMOUNT
								,case when Loan_category='Personal' and Close_flag=0 and Chargeoff_flag=0 then 1 else 0 end [# personal]
								,case when Loan_category='Personal 0%' and Close_flag=0 and Chargeoff_flag=0 then 1 else 0 end [# personal 0%]
								,case when Loan_category ='HELOC' and Close_flag=0 and Chargeoff_flag=0 then 1 else 0 end [# HELOC]
								,case when Loan_category = 'Other RealEstate' and Close_flag=0 and Chargeoff_flag=0 then 1 else 0 end [# other RealEstate]
								,case when Loan_category='Vehicle' and Close_flag=0 and Chargeoff_flag=0 then 1 else 0 end [# Vehicle]
								,case when Loan_category='Personal' then New_loan_flag else 0 end [new personal]
								,case when Loan_category='Personal 0%' then New_loan_flag else 0 end [new personal 0%]
								,case when Loan_category ='HELOC' then New_loan_flag else 0 end [new HELOC]
								,case when Loan_category = 'Other RealEstate' then New_loan_flag else 0 end [new other RealEstate]
								,case when Loan_category='Vehicle' then New_loan_flag else 0 end [new Vehicle]
								,case when Loan_category='Personal 0%' then New_loan_Balance else 0 end [new personal 0% Balance]
								,case when Loan_category='Mortgage Hardship'  then New_loan_Balance else 0 end [new Mortgage Hardship Balance]
								,case when Loan_category='Personal' then New_loan_Balance else 0 end [new personal Balance]
								,case when Loan_category ='HELOC' then New_loan_Balance else 0 end [new HELOC Balance]
								,case when Loan_category = 'Other RealEstate' then New_loan_Balance else 0 end [new other RealEstate Balance]
								,case when Loan_category='Vehicle' then New_loan_Balance else 0 end [new Vehicle Balance]
								,case when Loan_category='Mortgage Hardship' and Close_flag=1 then 1 else 0 end [# close Mortgage Hardship]
								,case when Loan_category='Personal 0%' and Close_flag=1 then 1 else 0 end [# close personal 0%]
								,case when Loan_category='Personal' and Close_flag=1 then 1 else 0 end [# close personal]
								,case when Loan_category ='HELOC' and Close_flag=1 then 1 else 0 end [# close HELOC]
								,case when Loan_category = 'Other RealEstate' and Close_flag=1 then 1 else 0 end [# close other RealEstate]
								,case when Loan_category='Vehicle' and Close_flag=1 then 1 else 0 end [# close Vehicle]
								from
										(
											 select
											a.PARENTACCOUNT,ID,ProcessDate,[Process date],[EOM process date],CONCAT(a.PARENTACCOUNT,id) UNID
											,case when closedate is null and chargeoffdate is null then BALANCE else 0 end BALANCE
											,case when Close_date=Process_date then 1 else 0 end Close_flag,case when Charge_off_date=Process_date then 1 else 0 end Chargeoff_flag
											,[LASTPAYMENTDATE],(Lastpayment_vdate),DUEDATE,case when PAYMENTHISTORY1!=0 and PAYMENTHISTORY1=lag_PAYMENT then 1 else 0 end Missed_paymnet,paymentskips,PAYMENTHISTORY1,lag_PAYMENT,lead_PAYMENT
											,datediff(day,[LASTPAYMENTDATE],DUEDATE) Days_due_payment
											,datediff(day,[LASTPAYMENTDATE],[Process date]) Delinquency_days
											,LoanCategory2,Process_date,case when Charge_off_date=Process_date then cast(CHARGEOFFAMOUNT as money) else 0 end CHARGEOFFAMOUNT
											,case when Open_date=Process_date then 1 else 0 end New_loan_flag
											,case when Open_date=Process_date then ORIGINALBALANCE else 0 end New_loan_Balance
											,case when Charge_off_date=Process_date then 1 else 0 end [# chargeoff]
											,case when [Personal 0%]=1 then 'Personal 0%' when LoanCategory2='Personal' then 'Personal'
											when PURPOSECODE=80 and TYPE=20 then 'Mortgage Hardship'
											when LoanCategory4 like '%1st %' then 'Mortgage'
											when LoanCategory4 like '%HEL%' then 'HELOC'
											when LoanCategory4 in ('Piggyback Balloon','Workout/TDR','Writeoff') then 'Other RealEstate'
											when LoanCategory4='Vehicle' then 'Vehicle' else LoanCategory2 end Loan_category,[Personal 0%]
											,case when [EOM process date]=[Process date] then 1 else 0 end EOM_flag
											from 
												( select *,lag(PAYMENTHISTORY1,1) over (partition by PARENTACCOUNT,ID order by PARENTACCOUNT,ID,processdate) lag_PAYMENT
													,lead(PAYMENTHISTORY1,1) over (partition by PARENTACCOUNT,ID order by PARENTACCOUNT,ID,processdate) lead_PAYMENT
													,case when opendate=closedate then 0 else 1 end Flag
													,EOMONTH([Process date]) [EOM process date],eomonth(DATEADD(month,1,lastpaymentdate)) Lastpayment_vdate
													,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date then 1 else 0 end Open_Flag
														from 
															(select *,case when REFERENCE ='UNSECURED - PANDEMIC' and TYPE=20 then 1 else 0 end [Personal 0%]
															,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
															else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
															,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
															else concat(year(opendate),month(opendate)) end Open_date
															,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
															else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
															,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
															,left(ProcessDate,6) Process_date
															 from ARCUSYM000..LOAN 
															) H
													 where  ORIGINALDATE is not null and OpenDate is not null 
													 and processdate in (select Process_date_max from #processdate)
													and PARENTACCOUNT in (select PARENTACCOUNT from #CC_Inactive_Summary) and Process_date between 201807 and 202006
												) A
													  left join ARCUSYM000.arcu.ARCULoanCategory b
													 on a.TYPE=b.LoanType
													 where Flag=1 and Open_Flag=1
										) AA
									) CC left join #CC_Inactive_Summary G on cc.PARENTACCOUNT=g.PARENTACCOUNT_CC
							group by PARENTACCOUNT,UNID,Pre_card_R2_flag,Flag) K where Pre_card_R2_flag is not null
					group by Pre_card_R2_flag,Flag
		go


			-- Credit Card Summary 
			-- drop table #CC_Summary
		select Extract_date [Extract date]
		,count(distinct Durable_Key) [# Card]
		,sum(NewAccountFLag) [New Cards]
		,sum(case when Closed_account_flag='1' then 1 else 0 end ) [Close Cards]
		,sum([Credit Limit]) [Credit Limit]
		,sum(spend) [Spend CC]
		,sum([Last Statement Balance Amount]) [Balance CC]
		,sum(RevolvingBalance) [Revolving Balance CC]
		,sum([Last Statement Merchandise Average Daily Balance Amount]) [Merchant Balance CC]
		,sum([Last Statement Cash Amount]) [Cash Balance CC]
		,sum(Promo_Balance) [Promo Balance CC]
		,sum(Protected_Balance) [Protected Balance]
		,sum([Last Statement Cash Interest Amount]) [Cash Interest Amount CC]
		,sum([Accumulated Merchandise Interest Amount]) [Merchant Interest Amount CC]
		,sum(Promo_Current_Interest) [Promo Interest Amount CC]
		,sum(Protected_Current_Interest) [Protected Interest Amount CC]
		,sum(Total_CC_transaction) [# Transactions CC]
		,sum(interest_amount+Interchange_income+fee) [Income CC]
		,sum(COF+ChargeoffAmount_final+visa_expense+Reward_expense+processing_cost) [Expense CC]
		 --into #CC_Summary
		 from #CC_data a
			where extract_datepart>201707 and Durable_Key in (select Durable_Key from #CC_Inactive_Summary where  Pre_card_R2_flag=0 and flag='12+ Inactive'-- > 12 Inactive
			)
		group by Extract_date
		order by Extract_date
	-- drop table #Summary2
			 select * 
			 into #Summary2
			 from #Summary1 a
			 left join #CC_Summary b
			 on a.Date=b.[Extract date]
			
			--   drop table #Summary3
			select 
			*,([Lending Income]+[Overall Fee]-[Processing Cost]-Dividend) [Revenue R2]
			into #Summary3
			from
			(select *,(Total_account*((36+0)/12)) [Processing Cost]
			,(Balance*0.9)*0.0020833 [Lending Income]
			,([COURTESY FEE]+[NSF FEE]+[OVERDRAFT FEE]) [Overall Fee] 
			from #Summary2) a
			order by date

				--truncate table monthly_tran_cc
			
			 select * from #Summary3 order by Date



			 select Date
			  ,CITY,STATE
			 ,count(Account_number) Total_accounts
			 ,sum([Close Account]) [Close Account]
			 ,sum(BALANCE) Balance
			 ,sum(Dividend) Dividend 
			
			 from
						 (
						 select a.*
						 ,case when b.CITY= 'W DES MOINES' then 'WEST DES MOINES' else b.city end CITY
						 ,b.STATE
						 from #R2_checking_accounts a
						 left join #Name_table_R2 b
						 on a.PARENTACCOUNT=b.PARENTACCOUNT
						 --where b.CITY like '%moines%'
						 ) a
				group by Date,CITY,STATE
				order by Date,CITY,STATE

			
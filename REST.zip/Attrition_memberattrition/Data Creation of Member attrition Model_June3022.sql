	
	/* creating Processdate Columns with latets dates */
		
	drop table if exists #processdate 
	select max(ProcessDate) ProcessDate,Process_Date
	into #processdate
	from (select ProcessDate,left(ProcessDate,6) Process_Date from ARCUSYM000..ACCOUNT group by ProcessDate) A
	where Process_Date>=202003
	group by Process_Date
	go	

/* Fetching Latest #processdate data for SSN , ParentA/c and Closeaccount details from NAME & ACCOUNT Table */

	Drop table if exists #name
	select a.processdate,a.parentaccount,a.SSN,case when b.CLOSEDATE is not null then 1 else 0 end Account_close  
	into #name
	from ARCUSYM000..name a left join (select * from ARCUSYM000..ACCOUNT) b on a.parentaccount=b.ACCOUNTNUMBER
	and a.processdate=b.ProcessDate where a.type=0 and A.EXPIRATIONDATE is null 
	and a.processdate in (select  ProcessDate from #processdate)

	select * from #processdate
	select * from #name

	go		
	
	/* Bifurcating Deposite type  with multiple condition*/
			
		drop table if exists #groupproducttype_Deposits0
		select *
		,case when ProductName like '%money%'  or ProductName like '% MM %' then 'MoneyMarket'
		when ProductName='Youth Savings' and ApplicationDescription='Certificates' then 'Savings'
		when ProductCode=0 and ApplicationDescription='Certificates' then 'Savings'
		when ProductName='40 Month CD' and ApplicationDescription='Certificates' then 'Checking'
		when ProductName='Certificate' and ApplicationDescription='Certificates' then 'Checking' 
		when ProductName='Public Funds' and ApplicationDescription='Certificates' then 'Certificates'  
		 else ApplicationDescription end Product_Group_wise
		into #groupproducttype_Deposits0
		from
			(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName,ApplicationDescription,ApplicationTableName
			 from [AE_EDW].[tempods].[S_CRMProductType] a
			left join [AE_EDW].[tempods].[S_CRMApplicationType] b
			on a.ApplicationTypeID=b.ApplicationTypeID
			where ApplicationDescription is not null and ProductName!='IRA Savings'
			and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a order by ProductCode
	
	select * from #groupproducttype_Deposits0

		go

	/* Yet to review*/
			
					Drop table if exists #savings_1
					select Distinct aa.ProcessDate,aa.PARENTACCOUNT,aa.ID,concat(aa.PARENTACCOUNT,aa.ID) UNID,b.SharePrimeNameSSN,aa.TYPE
					,aa.opendate,
					 case when Open_date=Process_Date then 1 else 0 end Open_Acct_flag
					,case when Close_date=Process_Date then 1 else 0 end Close_Acct_flag,CHARGEOFFDATE,CHARGEOFFDATE_v CHARGEOFF_DATE
					,aa.Close_date,aa.Open_date,aa.closedate,aa.BALANCE,e.ProductName
					,e.Product_Group_wise,
					case when Lag_opendate=Open_date and Lag_Type!= Type then 1 else 0 end Account_swtich_flag
					,Bal_Flag,LASTDIVAMOUNT,DIVTYPE,DIVRATE
					into #savings_1
					from 
						(	select *,case when [EOM_Process Date]=[Process Date] then 1 else 0 end EOM_flag
						,case when closedate is null and balance=0 then 0 else 1 end Bal_Flag 
							,case when (closedate is null and CHARGEOFFDATE is null) or Process_Date=close_date 
							or Process_Date=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
							,case when OPEN_DATE=CLOSE_DATE then 0 else 1 end Funded_loan_flag
							,lag(Open_date,1) over (partition by Concat(parentaccount,id) order by processdate) Lag_opendate
							,lag(type,1) over (partition by Concat(parentaccount,id) order by processdate) Lag_Type
							from
								(select a.*,EOMONTH([Process Date]) [EOM_Process Date]
								,case when Process_Date=CHARGEOFFDATE_v then CHARGEOFFAMOUNT else 0 end CHARGEOFFAMOUNT_v
								,left(Convert(varchar(20),Closedate,112),6)  Close_date
								,left(convert(varchar(20),opendate,112),6) Open_date
									from 
										( select * ,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
										else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v,left(ProcessDate,6) Process_Date
									,datefromparts(left(processdate,4),right(left(processdate,6),2),right(processdate,2)) [Process Date] from arcusym000..SAVINGS
									--where (chargeoffdate is null or chargeoffdate>='2020-01-01')
									) a
									where  ProcessDate in (select ProcessDate from #processdate)
								) F
						) aa
						left join #groupproducttype_Deposits0 E
						on e.ProductCode=aa.TYPE
						left join (select AccountNumber,ShareID,ProcessDate,SharePrimeNameSSN from ARCUSYM000.arcu.ARCUSharePrimeNames 
									group by AccountNumber,ShareID,ProcessDate,SharePrimeNameSSN) B on aa.PARENTACCOUNT=b.AccountNumber 
						and aa.id=b.ShareID and aa.ProcessDate=b.ProcessDate
						where Funded_loan_flag=1 and Open_Flag=1 and ProductName!='IRA Savings' 
						and Bal_Flag=1

						go

								drop table if exists #LoanStatic_01
								select a.[ProcessDate],[Process date],[Process_date],[PARENTACCOUNT],c.LoanPrimeNameSSN SSN,concat(PARENTACCOUNT,ID) UNID
								  ,[ID],TYPE,OPENdate,Open_date,closedate,Close_date,Charge_off_date,CHARGEOFFDATE,Loan_Term
								  ,[PARTIALPAYMENT],[PAYMENT],[LASTPAYMENTDATE],DUEDATE,[PAYMENTCOUNT],[INTERESTRATE]
								  ,[LATECHARGELASTYEAR],[BALANCE],[DESCRIPTION],[BRANCH]
								  ,b.LoanCategory2,b.LoanCategory3,b.LoanCategory4
								  ,case when LoanCategory2='Vehicle' then 'Vehicle'
								   when LoanCategory2='Personal' and LoanCategory3='Secured' then 'Personal_Secured'
								   when LoanCategory2='Personal' and LoanCategory3='Unsecured' then 'Personal_Unsecured'
								   when LoanCategory2='Real Estate' and LoanCategory4 like 'HEL%' then 'HELOC' 
								   when LoanCategory2='Real Estate' then 'Real Estate'
								   when LoanCategory2='Commercial Loans' then 'Commercial Loans'
								   when LoanCategory2='Construction And Development' then 'Construction And Development'
								   when LoanTypeDescription like '%AUTO (OL)' then 'Vehicle' else LoanTypeDescription end Loan_Categories
								   	,case when Open_date=Process_date then 1 else 0 end Open_acct_flag
								   ,case when Close_date=Process_date then 1 else 0 end Close_acct_flag
								  into #LoanStatic_01
								from
											(
											select *
											,case when closedate is null and balance=0 then 0 else 1 end Bal_zero_flag
											,CONCAT(PARENTACCOUNT,ID) UNID,case when opendate=closedate then 0 else 1 end Flag
											,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date then 1 else 0 end Open_Flag
												-- add the @Staticpooldate
											,DATEDIFF(month,OPENDATE,MATURITYDATE) Loan_Term
												from 
													(select *
													,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
													else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
													,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
													else concat(year(opendate),month(opendate)) end Open_date
													,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
													else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
													,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
													,left(ProcessDate,6) Process_date
													from ARCUSYM000..LOAN
													--where (CHARGEOFFDATE>='2020-10-31' or CHARGEOFFDATE is null ) 
													) H
											 where  ORIGINALDATE is not null and OpenDate is not null 
											 --and CLOSEDATE is null and CHARGEOFFDATE is null
											 and   ProcessDate in (select ProcessDate from #processdate)
											  	-- Later give the @staticpooldate date here 
											 --and MATURITYDATE>@staticpooldate	-- add 3 month in currrent date
											) A
									left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
									on b.loantype=a.TYPE
									left join ARCUSYM000.arcu.ARCULoanPrimeNames c on a.PARENTACCOUNT=c.AccountNumber 
									and a.id=c.LoanID and a.ProcessDate=c.ProcessDate
									where Flag=1 and Open_Flag=1  and Bal_zero_flag=1
									order by PARENTACCOUNT,a.ProcessDate
		go 
		
		--####VALIDATION-041422###########################################################################################################################################################
		DROP TABLE IF EXISTS #Loan_Validate_041522
		 SELECT DISTINCT SSN SSN1 into #Loan_Validate_041522
		  FROM #LoanStatic_01 where SSN in (SELECT SSN FROM Analytics..Member_attrition_data_040822 where Count_Total_Deposit_ACCT>1)--47821 
		 
		--#########################################################################################################################################################################

		-- Harland loans 
		drop table if exists #Extractdate_mortgage
		select  Extractdate,max(AsOfDate) AsOfDate
		into #Extractdate_mortgage
		from (select case when len(month(AsOfDate))=1 then concat(year(AsOfDate),0,month(AsOfDate)) else concat(year(AsOfDate),month(AsOfDate)) end Extractdate,* 
		from AE_EDW..F_Mortgage_Daily) A
		where CoreMortgageStatus='Active' and Extractdate in  (select Process_Date from #processdate)
		group by Extractdate
		order by Extractdate
		go
		drop table if exists #Tracking
		select parentaccount,ID,(USERCHAR1) USERCHAR1,EXPIREDATE,ProcessDate,left(ProcessDate,6) Process_Date 
		into #Tracking
		from ARCUSYM000..TRACKING where ProcessDate in (select ProcessDate from #processdate)
		group by parentaccount,ID,USERCHAR1,EXPIREDATE,ProcessDate
		go
		drop table if exists #Mortgage1
		select a.*	
		into #Mortgage1
				from (
				select b.parentaccount,a.*,case when Extractdate=Opendate then 1 else 0 end New_flag
				from	(select case when len(month(AsOfDate))=1 then concat(year(AsOfDate),0,month(AsOfDate)) else concat(year(AsOfDate),month(AsOfDate)) end Extractdate
						,case when len(month(MortgageOpenDate))=1 then concat(year(MortgageOpenDate),0,month(MortgageOpenDate)) else concat(year(MortgageOpenDate),month(MortgageOpenDate)) end Opendate
						,* from AE_EDW..F_Mortgage_Daily 
						) A
				left join (Select * from #Tracking) b
				on a.mortgageid=b.USERCHAR1 and a.Extractdate=b.Process_Date	
				where CoreMortgageStatus='Active' --and AsOfDate='2020-01-31' 
				and AsOfDate in (select AsOfDate from #Extractdate_mortgage) and b.EXPIREDATE is null --and MortgageDueDate>'2020-01-31' 
				and CurrentBalance>0 and b.USERCHAR1 is not null
				) A

		go

			--####VALIDATION-041422################################################################################################################
			DROP TABLE IF EXISTS #Mort_Validate_041522
		 SELECT DISTINCT B.SSN SSN1 INTO #Mort_Validate_041522 FROM #Mortgage1 y left join ARCUSYM000..NAME b on y.PARENTACCOUNT=b.PARENTACCOUNT
		  where SSN in (SELECT SSN FROM Analytics..Member_attrition_data_040822 where Count_Total_Deposit_ACCT>1)--10756

      --###################################################################################################################################

		Drop table if exists #Credit_card
		select *,format(cast([Social Security Number] as int) ,'000000000') SSN 
		into #Credit_card
		from TMGData..cardholder where extract_datepart in (select Process_Date from #processdate) and Active_Flag=1
		Drop table if exists  #CC_tracking
		select * ,SSN_USERCHAR3 SSN,LEFT(PROCESSDATE,6) EXTRACT_DATEPART 
		into #CC_tracking
		FROM ARCUSYM000.TRACKING.TVWARCUTRACKINGCREDITCARD C
		WHERE C.EXTERNALSTATUS_USERCHAR8 IS NULL AND C.EXPIREDATE IS NULL
		AND (C.EXPIRATIONDATE_USERDATE3 IS NULL OR C.EXPIRATIONDATE_USERDATE3 > GETDATE()) 
		AND PROCESSDATE IN (SELECT PROCESSDATE FROM #PROCESSDATE)
		
		go

		--####VALIDATION-041422################################################################################################################
		--DROP TABLE IF EXISTS #Credit_Validate_041522
		-- SELECT DISTINCT SSN SSN1 into #Credit_Validate_041522 FROM  #Credit_card 
		-- where SSN in (SELECT SSN FROM Analytics..Member_attrition_data_040822 where Count_Total_Deposit_ACCT>1)--48431
		-- SELECT DISTINCT SSN1 from
		--    (SELECT * FROM #Credit_Validate_041522
		--	  UNION ALL
		--	  SELECT * FROM #Credit_Validate_041522
		--	  Union all
		--	  SELECT * FROM #Loan_Validate_041522 ) R --64693
      --###################################################################################################################################


		-- Static Pool 
		select PARENTACCOUNT,SharePrimeNameSSN from #savings_1 where ProcessDate=20210531
		group by PARENTACCOUNT,SharePrimeNameSSN
		go
		select extract_datepart,count(distinct Durable_Key),sum(case when Closed_account_flag='1' then 1 else 0 end) from #Credit_card
		group by extract_datepart order by extract_datepart

		select ProcessDate,Product_Group_wise,count(UNID) [# Accounts],sum(Close_Acct_flag) from #savings_1
		group by ProcessDate,Product_Group_wise order by Product_Group_wise,ProcessDate

		select ProcessDate,Loan_Categories,count(UNID) [# Accounts],sum(Close_Acct_flag) [# Close] from #LoanStatic_01
		group by ProcessDate,Loan_Categories
		
		go

		select Extractdate,count(distinct MortgageID)
		,sum(case when Extractdate= left(convert(varchar(20),MortgageFullPayDate,112),6) then 1 else 0 end ) [# Close] 
		from #Mortgage1 
		group by Extractdate order by Extractdate
		select MortgageID,count(*) from #Mortgage1 where left(convert(varchar(20),Opendate,112),6)=202001
		group by MortgageID having count(*)<20
		
		go

		select ProcessDate,count(distinct UNID),sum(Close_acct_flag)  from  #savings_1
		where ProcessDate in (20210228,20210331) and Product_Group_wise='Checking'
		and Close_Acct_flag=1 --order by UNID,ProcessDate
		group by ProcessDate

		go

		select Process_date,count(distinct UNID),sum(Close_acct_flag) from #LoanStatic_01
		where ProcessDate in (20210228,20210331) and Loan_Categories='vehicle'
		--and Close_Acct_flag=1 --order by UNID,ProcessDate
		group by Process_date

		go


		--[TMGData].[dbo].[TMGCompleteCC]

		select Loan_Categories ,count(*),count(distinct Process_date),Count(distinct SSN),count(distinct UNID)
		from #LoanStatic_01
		group by Loan_Categories 
		order by Loan_Categories
		
		go
		Drop table if exists #Saving_static1
		select SSN into #Saving_static1 From
		(select SharePrimeNameSSN SSN,min(Close_Acct_flag) Close_Min_flag from #savings_1 where ProcessDate=20210331
		group by SharePrimeNameSSN) A where Close_Min_Flag=0
		Drop table if exists #Loan_static1
		Select SSN into #Loan_static1 From
		(Select SSN,min(Close_acct_flag) Close_Min_flag from #LoanStatic_01 where ProcessDate=20210331 group by SSN) B where Close_Min_Flag=0
		--################################################################################################################################
		--FOR OUR ANALYSIS
		Drop table if exists #Loan_static1_040822
		Select SSN,LoanCategory2,LoanCategory3 into #Loan_static1_040822 From
		(Select SSN
		       ,min(Close_acct_flag) Close_Min_flag
			   ,LoanCategory2
			   ,LoanCategory3 from #LoanStatic_01 where ProcessDate=20210331 group by SSN,LoanCategory2,LoanCategory3) B where Close_Min_Flag=0

		--#################################################################################################################################
		Drop table if exists #Credit_Static
		select SSN into #Credit_Static from #Credit_card where extract_datepart=202103 and Closed_account_flag='0'
		
		go
		Drop table if exists #Mortgage_static
		Select PARENTACCOUNT into #Mortgage_static from 
		(Select *   from #Mortgage1 
		 where Extractdate=202103) A group by PARENTACCOUNT
		go
		Drop table if exists #mort_dup
		select SSN,count(*) dup into #mort_dup from
		(select  * ,left(ProcessDate,6) Process_date from #name where PARENTACCOUNT in (select PARENTACCOUNT from #Mortgage_static) ) A 
		where Process_Date=202103 group by SSN having count(*)>1
		go
		Drop table if exists #dup
		select PARENTACCOUNT,max(SSN) SSN
		into #dup 
		from #name where ProcessDate=20210331 and SSN in (select SSN from #mort_dup)
		group by PARENTACCOUNT
		
		go
		Drop table if exists #mortgage_SSN
		Select * into #mortgage_SSN 
		from 
		(select a.PARENTACCOUNT,b.SSN  from #Mortgage_static A 
		left join #name b on a.PARENTACCOUNT=b.PARENTACCOUNT
		left join #dup c on a.PARENTACCOUNT=c.PARENTACCOUNT
		where c.PARENTACCOUNT is null
		group by a.PARENTACCOUNT,b.SSN) A
		union
		select PARENTACCOUNT,SSN from #dup
		go
		Drop table if exists #mort_static
		select b.SSN into #mort_static from #Mortgage_static a left join #mortgage_SSN b on a.PARENTACCOUNT=b.PARENTACCOUNT
		group by b.SSN

		go
		Drop table if exists #Final_static
		select * into #Final_static from #Saving_static1
		union
		select * from #Loan_static1
		union
		select * from #Credit_Static
		union
		select * from #mort_static
		go
		Drop table if exists #Attrition_flag
		select a.*,1 Attrition_flag  
		into #Attrition_flag
		from #Final_static A left join 
		
		(select SharePrimeNameSSN SSN,Close_Acct_flag 
		,case when Product_Group_wise='Certificates' then Close_Acct_flag else null end Certificates_Close_Acct_flag
		,case when Product_Group_wise='Checking' then Close_Acct_flag else null end Checking_Close_Acct_flag
		,case when Product_Group_wise='MoneyMarket' then Close_Acct_flag else null end MoneyMarket_Close_Acct_flag
		,case when Product_Group_wise='Savings' then Close_Acct_flag else null end Savings_Close_Acct_flag
		from #savings_1 where ProcessDate between 20210731 and 20211231
		) b on a.SSN=b.SSN
		where Certificates_Close_Acct_flag is null and Checking_Close_Acct_flag is null and MoneyMarket_Close_Acct_flag is null
		and Savings_Close_Acct_flag is null

		--exec [dbo].[Dynamic_Master_data MEMBER_ATTRITION_040822] '2020-05-31'
		Drop table if exists analytics..Member_attrition_data_040822
		select b.*,isnull(c.Attrition_flag,0) Attrition_flag
		into analytics..Member_attrition_data_040822
		from #Final_static A left join #Attrition_flag C on a.SSN=c.SSN
			left join (select  * from Analytics.dbo.masterdata_for_member_attrition_041222) B  on a.SSN=b.SSN
			where b.SSN is not null
			order by b.SSN
			go
			select sum (Attrition_flag) from analytics..Member_attrition_data_040822 

		
		
		
		
		--COUNT OF FINAL TABLES
		
		--SELECT COUNT(DISTINCT  SSN) FROM #Saving_static1 --272101

		--SELECT COUNT(DISTINCT  SSN) FROM #Loan_static1   --107600

		--SELECT COUNT(DISTINCT  SSN) FROM #Credit_Static  --60491

		--SELECT COUNT(DISTINCT  SSN) FROM #mort_static   --11609

		--SELECT COUNT(*) from #Attrition_flag --9393







		--SELECT COUNT(DISTINCT SSN) from #Credit_Static --50971 changed to 60491

		
		--SELECT COUNT(DISTINCT SSN) from #mort_static --11958 changed to 11609

		
		--SELECT COUNT(DISTINCT SSN) from #Saving_static1 --225791 changed to 272101


		--########################################################################################################################
		--FOR our Analysis ( Finding SSN for Indirect ) : 06092022
		DROP TABLE IF Exists #in_loan_ssn_040822
		SELECT Distinct SSN into  #in_loan_ssn_040822 FROM #Loan_static1_040822 where LoanCategory3='Indirect' and LoanCategory2='Vehicle' --72217
--#################### Indirect Attrition data Formation ####################################################################################
		DROP table if exists #indirect_attrition_060922
		SELECT *
		into #indirect_attrition_060922
		 FROM analytics..Member_attrition_data_040822 
		where SSN in (SELECT * FROM #in_loan_ssn_040822) --66934

		SELECT * FROM #indirect_attrition_060922 where Attrition_flag = 1 --501
--###########################################################################################################################################	
		
		--select ssn,Attrition_flag from  [UICCU\sadamhuseni].Member_attrition_data_202112
		--where ssn in (select distinct ssn from #Subham_temp_in_loan_ssn)

		DROP TABLE IF EXISTS #indirect_SSN_040822
		SELECT Distinct SSN into #indirect_SSN_040822 FROM analytics..Member_attrition_data_040822
		where Total_No_Account_Certificates = 0
              or
              Total_No_Account_Checkings = 0
              or
              Total_No_Account_Money_Market = 0
              or
              Total_No_Account_Savings = 1
		      and SSN in (SELECT * FROM  #in_loan_ssn_040822) --44497 changed to 63059


         --ONLY DEPOSITS

	   DROP TABLE IF EXISTS #ONLY_DEPOSIT_040822
	   SELECT distinct SSN
	   INTO #ONLY_DEPOSIT_040822
	   FROM analytics..Member_attrition_data_040822
	   where SSN not IN (SELECT Distinct SSN from #Loan_static1 ) 
	   AND  SSN not IN (SELECT Distinct SSN from #Credit_Static ) 
	   AND  SSN not IN (SELECT Distinct SSN from #mort_static )  --104867 changed to 135652

 --SELECT distinct SSN  
	--   FROM analytics..Member_attrition_data_040822--272356

	   --SELECT COUNT(DISTINCT SSN) from #Credit_Static  --50971 changed to 60491

		--SELECT COUNT(DISTINCT SSN) from #Loan_static1 --107600
		--SELECT COUNT(DISTINCT SSN) from #mort_static --11958 changed to 11609

		SELECT COUNT(Distinct CONCAT(PARENTACCOUNT,id) ) from #savings_1 where ProcessDate = 20210331 --461918
		--SELECT COUNT(DISTINCT SSN) from #Saving_static1 --225791 changed to 272101

	   Select Distinct SSN 
	   from 
	   (
		   Select *
		   from
		(
			   Select *
			   from analytics..Member_attrition_data_040822
				where SSN not IN (SELECT Distinct SSN from #Loan_static1 ) 
			)a
			where  SSN not IN (SELECT Distinct SSN from #Credit_Static ) 
		)a
		where  SSN not IN (SELECT Distinct SSN from #mort_static )

	      DROP TABLE IF EXISTS #DATA_wo_L
		  SELECT distinct SSN
	   INTO #DATA_wo_L
	   FROM analytics..Member_attrition_data_040822  
	   where SSN not IN (SELECT Distinct SSN from #Loan_static1 ) --170513
	     DROP TABLE IF EXISTS #DATA_wo_Lc
		 SELECT distinct SSN
	   INTO #DATA_wo_Lc
	   FROM #DATA_wo_L
	   where SSN not IN (SELECT Distinct SSN from #Credit_Static ) --137561
	   DROP TABLE IF EXISTS #DATA_wo_Lcm
		 SELECT distinct SSN
	   INTO #DATA_wo_Lcm
	   FROM #DATA_wo_Lc
	   where SSN not IN (SELECT Distinct SSN from #mort_static) --135652

	   --###########    VALIDATION     ##############

	   SELECT Count(*) FROM analytics..Member_attrition_data_040822 
	   where Count_Account_Total_loan_ACCT is NULL 
	   and Count_Total_Deposit_ACCT >= 1 --187334

	   SELECT Count_Account_Total_loan_ACCT , Count(*)  FROM Analytics..Member_attrition_data_040822
	   group by Count_Account_Total_loan_ACCT

	   --################################################################################################################
	   --OTHERS

	   DROP TABLE IF EXISTS #OTHERS_040822
	   SELECT * 
	   INTO #OTHERS_040822
	   FROM analytics..Member_attrition_data_040822
	   WHERE SSN NOT IN 
	   (SELECT * FROM #indirect_SSN_040822
	   UNION ALL
	   SELECT * FROM #ONLY_DEPOSIT_040822)  --64981 changed to 73645

	   SELECT * FROM #OTHERS_040822 WHERE Attrition_flag = 1 --514
			
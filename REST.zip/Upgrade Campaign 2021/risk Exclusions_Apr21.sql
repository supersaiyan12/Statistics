--------------------------------------------------Univariate Analysis Code-----------------------------------------------------
	drop table if exists #NAME1
	--select max(processdate) from ARCUSYM000..SAVINGS
	select distinct a.PARENTACCOUNT,SSN,BIRTHDATE,a.USERCHAR3 FICO_Latest
		into #NAME1
		from 
		(
		select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date 
		from ARCUSYM000..NAME
		) a
		left join ARCUSYM000..SAVINGS b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		and a.ProcessDate=b.ProcessDate
		where a.TYPE=0
		and a.ProcessDate=20210512
		and b.SHARECODE=0 
		and b.IRSCODE=0
		and b.TYPE<9000
		and b.type<>10 
		and b.type<>11
		and b.type<>12
		and b.type<>14
		and b.type<>113
		and b.type<>510
		and b.type<>512
		and b.ORIGINALDEPOSITDATE is not null
		and b.CLOSEDATE is null 
		and b.CHARGEOFFDATE is null
		order by PARENTACCOUNT
	
	go
				
	drop table if exists #Unemployment
	select 
	a.PARENTACCOUNT,1 Unemployment,sum(BALANCECHANGE) Amount
	into #Unemployment
	from 
	(
	select PARENTACCOUNT,PARENTID,EFFECTIVEDATE,SEQUENCENUMBER-1 as SEQUENCENUMBER,COMMENT
	, case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE)) 
	else  CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVE_DATE from ARCUSYM000..SAVINGSTRANSACTION
	where COMMENT like '%Unemplo%' and EFFECTIVEDATE >='2020-10-01 00:00:00' 
	) A 
	left join 
	(
	select PARENTACCOUNT,PARENTID,EFFECTIVEDATE,SEQUENCENUMBER,COMMENT,BALANCECHANGE
	, case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE)) 
	else  CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVE_DATE from ARCUSYM000..SAVINGSTRANSACTION
	where EFFECTIVEDATE >='2020-10-01 00:00:00'
	) b
	on a.PARENTACCOUNT=b.PARENTACCOUNT and a.PARENTID=b.PARENTID
	and a.EFFECTIVEDATE=b.EFFECTIVEDATE and a.SEQUENCENUMBER=b.SEQUENCENUMBER
	group by a.PARENTACCOUNT


	go

drop table if exists #Overdraft
select 
PARENTACCOUNT,sum(case when ProcessDate in (20200229,20200331,20200430) then [# Overdraft] else 0 end) [# Overdraft_2020]
	,sum(case when ProcessDate in (20210228,20210331,20210430) then [# Overdraft] else 0 end) [# Overdraft_2021]
into #Overdraft
from
	(select 
	ProcessDate,PARENTACCOUNT,sum(Overdraft_fee) Overdraft_fee,sum(Overdraft_count) [# Overdraft]
				
	from
			(
			select 
			*,case when Overdraft_fee>0 then 1 else 0 end Overdraft_count
			from
					(
					select 
					*,isnull(case when OVERDRAFTFEEYTD>0 then lead_overdraft-OVERDRAFTFEEYTD else 0 end,0) Overdraft_fee
					from 
							( select ProcessDate,PARENTACCOUNT,ID,TYPE
							,BALANCE
							,case when OPENDATE=CLOSEDATE then 0 else 1 end FLag ,OVERDRAFTFEELASTYR,OVERDRAFTTOLERANCE
							,overdraftfeeytd,LEAD(overdraftfeeytd,1) 
							over(partition by PARENTACCOUNT,ID,TYPE,year_ order by PARENTACCOUNT,ID,ProcessDate) lead_overdraft
							,CHARGEOFFDATE,OPENDATE,closedate
							from 
									(select * ,left(ProcessDate,4) year_ from ARCUSYM000..SAVINGS 
									where ProcessDate in (20200229,20200331,20200430,20210228,20210331,20210430)) A
							) B
					where  CHARGEOFFDATE is null and OpenDate is not null and CLOSEDATE is null and flag=1
					) A
			) D
			group by ProcessDate,PARENTACCOUNT
	) F
	where [# Overdraft] >0
	group by PARENTACCOUNT
				

	go

Drop table if exists #HELOC
	--select distinct chargeoffdate from ARCUSYM000..LOAN order by chargeoffdate
select PARENTACCOUNT,sum(Flag_HELOC) Flag_HELOC
	--,sum(HELOC_Jan) HELOC_Jan
	,sum(HELOC_Feb) HELOC_Feb
	,sum(HELOC_Mar) HELOC_Mar
	,sum(HELOC_April) HELOC_April
into #HELOC
from
	(
	select ProcessDate,PARENTACCOUNT,case when Extract_date=Extract_open then 1 else 0 end Flag_HELOC
	-- ,when Extract_date=Extract_open and ProcessDate=20210430 then 1 else 0 end HELOC_Jan
	,case when Extract_date=Extract_open and ProcessDate=20210228 then 1 else 0 end HELOC_Feb
	,case when Extract_date=Extract_open and ProcessDate=20210331 then 1 else 0 end HELOC_Mar
	,case when Extract_date=Extract_open and ProcessDate=20200428 then 1 else 0 end HELOC_April
	from
	( select *,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate)) 
	else concat(year(opendate),month(opendate)) end Extract_open
	,CONCAT((PARENTACCOUNT),(id))UNID,dateadd(month,-1,DUEDATE) [Duedatenew]
	,left(ProcessDate,6) Extract_date,
	case when len(month(CHARGEOFFDATE))=1then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
	else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end extract_chargeoff
	,case when opendate=closedate then 0 else 1 end Flag
	,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
		from ARCUSYM000..LOAN where  ORIGINALDATE is not null 
		and OpenDate is not null and CLOSEDATE is null 
		and (chargeoffdate>='2020-01-01' or chargeoffdate is null)
		and processdate in (20200229,20200331,2020430)
		) A
		left join  ARCUSYM000.arcu.ARCULoanCategory B
		on a.TYPE=b.LoanType
		where DESCRIPTION like '%line of%' or DESCRIPTION like '%HELOC%'--LoanCategory2 like 'HEl%' 
		) B
		where Flag_HELOC>0
		group by PARENTACCOUNT


		go
		
		drop table if exists ##RiskTrigger
		select 
		a.SSN,a.FICO_Latest
		,sum(isnull(b.[# Overdraft_2020],0)) [# Overdraft_2020]
		,sum(isnull(b.[# Overdraft_2021],0)) [# Overdraft_2021]
		,sum(isnull(c.Amount,0)) [$ Unemployment],sum(isnull(c.Unemployment,0)) Unemployment
		,sum(isnull(d.Flag_HELOC,0)) Flag_HELOC--,sum(isnull(d.HELOC_Jan,0)) HELOC_Jan
		,sum(isnull(d.HELOC_Feb,0)) HELOC_Feb,sum(isnull(d.HELOC_Mar,0)) HELOC_Mar
		,sum(isnull(d.HELOC_April,0)) HELOC_April
		into ##RiskTrigger
		from #NAME1 A
		left join #Overdraft b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		left join #Unemployment c
		on a.PARENTACCOUNT=c.PARENTACCOUNT
		left join #HELOC d
		on a.PARENTACCOUNT=d.PARENTACCOUNT
		Group by A.SSn,a.FICO_Latest

		go
		drop table if exists #doublefico
		select SSN,count(distinct FICO_Latest) counts
		into #doublefico
		from #NAME1
		group by SSN having count(distinct FICO_Latest)>1

		go
		drop table if exists ##FICO
		select SSN,max(FICO_Latest) FICO
		into ##FICO
		from #NAME1
		group by SSN

		go

				
--Date: 6th Apr 2021
--Change the static pool month from entire code....
	--drop table #temp1
	--drop table #temp_pre_12mo_2
	--drop table #temp_pre_12mo_3
	--drop table #temp_pre_12mo_3a
	--drop table #temp_pre_12mo_4

	--drop table #temp_pre_6mo_2
	--drop table #temp_pre_6mo_3
	--drop table #temp_pre_6mo_3a
	--drop table #temp_pre_6mo_4

	--drop table #temp_post_12mo_2
	--drop table #temp_post_12mo_3
	--drop table #temp_post_12mo_3a
	--drop table #temp_post_12mo_4

	--drop table #temp2
	--drop table #temp3
	--drop table #temp4
	--drop table #temp5
	--drop table #temp6
	--drop table #temp7
	--drop table #temp8
	--drop table #temp9
	--drop table #temp10

	--select distinct [Card Description] FROM [TMGData].[dbo].[cardholder] where  Extract_DatePart = 201812
	--select max(Extract_DatePart) FROM [TMGData].[dbo].[cardholder] where  Extract_DatePart = 201812
	--static pool data
	select Durable_Key,[Master Account Key],[Credit Limit],mob,[Card Description],
	[External Status Code],[Internal Status Code] ,
	[Last Statement Balance Amount],RevolvingBalance,age,
	([Last Statement Sale Amount]-[Last Statement Return Amount]) as spend,
	TRIPFLAG,[Last Statement Payment Amount], Extract_DatePart as sp_month
    into #temp1
	FROM [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and [External Status Code] in ('') and [Internal Status Code] in ('','N')
	and Extract_DatePart = 202104 and mob > 11 --and [Social Security Number] <> '0'
	--select * from #temp1
	
	go
	--Step 1: Pre 12 month numbers
	select Durable_Key as d_pre_12mo,
	sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_12mo,
	sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_12mo,
	sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_12mo,
	sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_12mo,
	sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_12mo,
	sum([Last Statement Balance Amount]) as sum_bal_pre_12mo,
	sum(RevolvingBalance) as sum_revbal_pre_12mo,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_12mo,
	avg([Last Statement Balance Amount]) as avg_bal_pre_12mo,
	avg(RevolvingBalance) as avg_revbal_pre_12mo,
	avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_12mo
	into #temp_pre_12mo_2
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 --and [Card Description] not in ('Mastercard Business')
	and Extract_DatePart between 202104 - 99 and 202104
	and Durable_Key in 
	(select Durable_Key from #temp1)
	group by Durable_Key

	go

	--Pre 12 month Profit numbers
	select Durable_Key,Extract_DatePart,
	case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization,
	case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate,
	case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate,

	([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income,
	([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees,
	([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income,    
	([Last Statement Balance Amount]*0.02/12) as COF,
	(ChargeoffAmount_final) as chgoff_amt,
	--0 as rewards_expense, --since at that time there was only one card and it was non-reward
	--case when [Card Description] not in ('','') then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end as rewards_expense,
	([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense,
	case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost
	into #temp_pre_12mo_3
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 --and [Card Description] not in ('Mastercard Business')
	and Extract_DatePart between 202104 - 99 and 202104
	and Durable_Key in 
	(select Durable_Key from #temp1)
	
	go

	--Pre 12 month Profit numbers_summary
	select Durable_Key,count(*) as N_months,
	sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit,
	avg(Utilization) as avg_Utilization,avg(revolve_rate) as avg_revolve_rate,avg(payment_rate) as avg_payment_rate
	into #temp_pre_12mo_3a
	from #temp_pre_12mo_3
	group by Durable_Key
		
	go
	
	select a.*,
	b.profit as sum_profit_pre_12mo,b.profit/b.N_months as avg_profit_pre_12mo, 
	b.avg_Utilization as avg_Utilization_pre_12mo,
	b.avg_revolve_rate as avg_revolve_rate_pre_12mo,
	b.avg_payment_rate as avg_payment_rate_pre_12mo
	into #temp_pre_12mo_4
	from #temp_pre_12mo_2 a
	left join #temp_pre_12mo_3a b
	on a.d_pre_12mo = b.Durable_Key

	go

	--select top 1000 * from #temp_pre_12mo_4

	go

	
			
	go
	--Step 2: Pre 6 month numbers
	
	--drop table #temp_pre_to_pre_6mo_2
	--drop table #temp_pre_to_pre_6mo_3
	--drop table #temp_pre_to_pre_6mo_3a
	--drop table #temp_pre_to_pre_6mo_4


	go

	--Pre 6 month Profit numbers
	select Durable_Key,Extract_DatePart,
	case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization
	into #temp_pre_to_pre_6mo_2
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and Extract_DatePart between 202005 and 202010
	
	go

	--Pre 6 month Profit numbers_summary
	select Durable_Key,avg(Utilization) as avg_Utilization_pre_to_pre_6mo
	into #temp_pre_to_pre_6mo_3
	from #temp_pre_to_pre_6mo_2
	group by Durable_Key
	


	
	go
	--Step 2: Pre 6 month numbers
	
	--drop table #temp_pre_6mo_2
	--drop table #temp_pre_6mo_3
	--drop table #temp_pre_6mo_3a
	--drop table #temp_pre_6mo_4
	
	select Durable_Key  as d_pre_6mo,
	sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_6mo,
	sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_6mo,
	sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_6mo,
	sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_6mo,
	sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_6mo,
	sum([Last Statement Balance Amount]) as sum_bal_pre_6mo,
	sum(RevolvingBalance) as sum_revbal_pre_6mo,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_6mo,
	avg([Last Statement Balance Amount]) as avg_bal_pre_6mo,
	avg(RevolvingBalance) as avg_revbal_pre_6mo,
	avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_6mo
	into #temp_pre_6mo_2
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and Extract_DatePart between 202011 and 202104
	and Durable_Key in 
	(select Durable_Key from #temp1)
	group by Durable_Key

	go

	--Pre 6 month Profit numbers
	select Durable_Key,Extract_DatePart,
	case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization,
	case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate,
	case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate,

	([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income,
	([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees,
	([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income,    
	([Last Statement Balance Amount]*0.02/12) as COF,
	(ChargeoffAmount_final) as chgoff_amt,
	--0 as rewards_expense, --since at that time there was only one card and it was non-reward
	--case when [Card Description] not in ('','') then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end as rewards_expense,
	([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense,
	case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost
	into #temp_pre_6mo_3
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and Extract_DatePart between 202011 and 202104
	and Durable_Key in 
	(select Durable_Key from #temp1)
	
	go

	--Pre 6 month Profit numbers_summary
	select Durable_Key,count(*) as N_months,
	sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit,
	avg(Utilization) as avg_Utilization,avg(revolve_rate) as avg_revolve_rate,avg(payment_rate) as avg_payment_rate
	into #temp_pre_6mo_3a
	from #temp_pre_6mo_3
	group by Durable_Key
		
	go
	
	select a.*,
	b.profit as sum_profit_pre_6mo,b.profit/b.N_months as avg_profit_pre_6mo,
	b.avg_Utilization as avg_Utilization_pre_6mo,
	b.avg_revolve_rate as avg_revolve_rate_pre_6mo,
	b.avg_payment_rate as avg_payment_rate_pre_6mo,
	c.avg_Utilization_pre_to_pre_6mo as avg_Utilization_pre_to_pre_6mo,
	b.avg_Utilization - c.avg_Utilization_pre_to_pre_6mo as Utilization_drift
	into #temp_pre_6mo_3b
	from #temp_pre_6mo_2 a
	left join #temp_pre_6mo_3a b
	on a.d_pre_6mo = b.Durable_Key
	left join #temp_pre_to_pre_6mo_3 c
	on a.d_pre_6mo = c.Durable_Key
		
	go
	
	select *,
	case 
	when Utilization_drift <= -1.00 then '<=-100%'
	when Utilization_drift <= -0.75 then '<=-75%'
	when Utilization_drift <= -0.50 then '<=-50%'
	when Utilization_drift <= -0.25 then '<=-25%'
	when Utilization_drift <= 0.00  then '<=0%'
	when Utilization_drift <= 0.25  then '<=25%'
	when Utilization_drift <= 0.50  then '<=50%'
	when Utilization_drift <= 0.75  then '<=75%'
	when Utilization_drift <= 1.00  then '<=100%'
	else '100%+' end as Utilization_drift_Band
	into #temp_pre_6mo_4
	from #temp_pre_6mo_3b

	go




	go
	--drop table #temp2
	select a.*,b.*,c.*
	into #temp3
	from #temp1 a
	left join #temp_pre_12mo_4 b
	on a.Durable_Key = b.d_pre_12mo
	left join #temp_pre_6mo_4 c
	on a.Durable_Key = c.d_pre_6mo


	go

	--select * from #temp3
	--select * from #temp7
	go

	--select top 10 * from [TMGData].[dbo].[TransUnion_CreditBureau_data_Jun20]
	drop table if exists #temp4
	select distinct 
	SSN,
	Score_1*1 as FICO_score,
	left(INCOME,3)*1000 as Annual_Income,
	left(INCOME,3)*1000/12 as Monthly_Income,
	[BC07_Number of bankcard trades opened in past 12 months]*1 as N_bankcard_Trades_in_past_12months,
	[BC33_Total current balance of all open bankcard trades reported ]*1 as Bureau_Balance,
	convert(float,[RE34_Ratio of total current balance to high credit / credit limi]) as Debt_Burden,
	[AT36_Months since most recent delinquency on any trade captures ]*1 as Months_since_most_recent_delq,
	[BC28_Sum of high credit or credit limit for all open bankcard ac]*1 as Bureau_CL,
	[COLL_Number of collections in 12 months ]*1 as N_collections_in_past_12months,
	[G068_Total number of accounts 90 or more days past due in the la]*1 as N_accts_90plus_days_past_due_in_past_6months,
	[G094_Number of public record bankruptcies]*1 as N_accts_bankruptcies,
	[G098_Number of Inquiries in the past 6 months]*1 as N_Inquiries_in_past_6months
	,[AT34_Ratio of total current balance to high credit / credit limi] [Avg_Bureau Balance]
	,[BC31_Percentage of all open bankcard trades with > 75% of the li] [Utilization >75%]
	into #temp4
	from [TMGData].[dbo].[TransUnion_CreditBureau_data_Jun20]
	--select distinct N_Inquiries_in_past_6months from #temp4 order by 1
	--select * from #temp4
	
	go
	
	drop table if exists #temp5
	Select Durable_Key,[Social Security Number]
	into #temp5
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and [External Status Code] in ('') and [Internal Status Code] in ('','N')
	and Extract_DatePart = 202104 and mob > 11

	go
	
	--select count(*) from #temp6
	drop table if exists #temp6
	select a.*,b.[Social Security Number]
	into #temp6
	from #temp3 a
	left join #temp5 b
	on a.Durable_Key = b.Durable_Key
	
	go
	
	drop table if exists #temp7
	select a.*,b.*
	into #temp7
	from #temp6 a
	left join #temp4 b
	on a.[Social Security Number] = b.SSN

	go
	drop table if exists #temp8
	select [Social Security Number],count(*) as cnt
	into #temp8
	from #temp7 
	group by [Social Security Number]
	having count(*) >= 2

	go
	drop table if exists #temp9
	select *
	into #temp9
	from #temp4
	where SSN not in 
	(select [Social Security Number] from #temp8)

	go
	drop table if exists #temp10
	select a.*,b.*
	into #temp10
	from #temp6 a
	left join #temp9 b
	on a.[Social Security Number] = b.SSN
	
	go

	--select * from #temp10

	go

	--select top 10 * from [TMGData].[dbo].[TransUnion_CreditBureau_data_May19]
	--drop table #temp10a
	--drop table #temp10b
	--drop table #temp10c
	--drop table #temp10d
	--drop table #temp10e
	drop table if exists #temp10a
	select distinct 
	SSN,
	Score_1*1 as FICO_score
	into #temp10a
	from [TMGData].[dbo].[TransUnion_CreditBureau_data_May19]
	--select distinct N_Inquiries_in_past_6months from #temp4 order by 1
	--select * from #temp10a
	
	go
	
	drop table if exists #temp10b
	Select Durable_Key,[Social Security Number]
	into #temp10b
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and [External Status Code] in ('') and [Internal Status Code] in ('','N')
	and Extract_DatePart = 202104 and mob > 11
	--select * from #temp10b
	
	go
	drop table if exists #temp10c
	select a.*,b.*
	into #temp10c
	from #temp10a a
	left join #temp10b b
	on a.[SSN] = b.[Social Security Number]
	--select * from #temp10c
	
	go
	drop table if exists #temp10d
	--drop table #temp10d
	select [SSN],count(*) as cnt
	into #temp10d
	from #temp10c
	group by [SSN]
	having count(*) >= 2

	go
	drop table if exists #temp10e
	select *
	into #temp10e
	from #temp10c
	where [SSN] not in 
	(select [SSN] from #temp10d)
	--select * from #temp10e

	go
	--drop table #temp11
	drop table if exists #temp11
	select a.*,b.FICO_score as FICO_May19,(a.FICO_score - b.FICO_score) as FICO_drift
	into #temp11
	from #temp10 a
	left join #temp10e b
	on a.Durable_Key = b.Durable_Key
	
	go
	
	select * from #temp11
	--select * from #temp11 where FICO_drift is null
	
	go

		--select [Social Security Number] from #temp11
	 drop table if exists #Risktriger_data
	select a.[Social Security Number],a.Durable_Key,a.[Master Account Key]
	,b.[# Overdraft_2020],b.[# Overdraft_2021],b.[$ Unemployment],b.Unemployment,b.Flag_HELOC,b.HELOC_Feb,b.HELOC_Mar,b.HELOC_April
	into #Risktriger_data
	from (select distinct [Social Security Number],Durable_Key,[Master Account Key]
	from #temp11) a
	left join (select SSN
				,sum([# Overdraft_2020]) [# Overdraft_2020],sum([# Overdraft_2021]) [# Overdraft_2021]
				,sum([$ Unemployment]) [$ Unemployment],sum(Unemployment) Unemployment
				,sum(Flag_HELOC) Flag_HELOC--,sum(HELOC_Jan) HELOC_Jan
				,sum(HELOC_Feb) HELOC_Feb,sum(HELOC_Mar) HELOC_Mar,sum(HELOC_April) HELOC_April
				from ##RiskTrigger 
				group by SSN
				) b
	on a.[Social Security Number]=b.ssn
	where a.Durable_Key in (select Durable_Key from #temp11) 
	and a.[Master Account Key] in (select [Master Account Key] from #temp11)
	
	go

	drop table if exists #Overdraft
	select *,case when [# Overdraft_2021]>0 and [# Overdraft_2020]>0 
	then [# Overdraft_2021]/[# Overdraft_2020] else 0 end Overdraft_rate
	 into #Overdraft
	 from #Risktriger_data
	 where [# Overdraft_2021]>0
	
	go

	 drop table if exists #Unemployment
	 select *,
	 case when [# Overdraft_2021]>0 and [# Overdraft_2020]>0 
	 then [# Overdraft_2021]/[# Overdraft_2020] else 0 end Overdraft_rate
	 into #Unemployment
	 from #Risktriger_data
	 where [$ Unemployment]>0
	
	go

	 drop table if exists #Heloc
	  select *,case when [# Overdraft_2021]>0 and [# Overdraft_2020]>0 
	  then [# Overdraft_2021]/[# Overdraft_2020] else 0 end Overdraft_rate
	 into #Heloc
	 from #Risktriger_data
	 where Flag_HELOC>0

	 go

	 drop table if exists #RiskExclude
	  select *,case when [# Overdraft_2021]>0 and [# Overdraft_2020]>0 
	  then [# Overdraft_2021]/[# Overdraft_2020] else 0 end Overdraft_rate
	 into #RiskExclude
	 from #Risktriger_data
	 where Flag_HELOC>0 or  [# Overdraft_2021]>0 or [$ Unemployment]>0

	 go

	 
	drop table if exists #risk_model_Exclusion
	select Durable_Key
	into #risk_model_Exclusion
	from ##Final_Riskmodel_list 
	where Deciling=1 

	go
	
	--select top 10 * from #temp4
	select count(*)
	from [TMGData].[dbo].[cardholder]
	where extract_datepart = 202104 and Active_Flag = 1
	and [External Status Code] in ('') and [Internal Status Code] in ('','N')
	and [Card Description] not in
	('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and mob >= 12
	and Durable_Key not in
	(select Durable_Key from #temp11
	where N_accts_bankruptcies >= 1)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where Times_1_cycle_delq_pre_6mo >= 1)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where Times_2_cycle_delq_pre_6mo >= 1)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where Times_overlimit_pre_6mo >= 2)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where Times_cash_Advances_pre_6mo >= 1)
	and Durable_Key not in
	((select Durable_Key from #temp11
	where avg_Utilization_pre_6mo > 0.75) 
	union all (select Durable_Key from #temp11
	where avg_Utilization_pre_6mo between 0.50 and 0.75 and Utilization_drift > 0.25))
	and Durable_Key not in
	(select Durable_Key from #temp11
	where FICO_score < 660 or FICO_score is null)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where FICO_drift <= -50 or 
	(FICO_score between 660 and 689 and FICO_drift <= -25))
	and Durable_Key not in
	(select Durable_Key from #temp11
	where Bureau_Balance > 30000 or Bureau_Balance is null)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where Debt_Burden > 100 or Debt_Burden is null)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where Months_since_most_recent_delq <= 3)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where N_collections_in_past_12months >= 1 or N_collections_in_past_12months is null)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where N_accts_90plus_days_past_due_in_past_6months >= 1 or N_accts_90plus_days_past_due_in_past_6months is null)
	and AGE > 21
	and Durable_Key not in (select Durable_Key from #risk_model_Exclusion)
	and Durable_Key not in (select Durable_Key from #RiskExclude)
	
	go
	--select Durable_Key,Bureau_balance from #temp11
	--where Durable_Key in 
	--(
	go
	
	drop table if exists #temp12
	--select top 10 * from #temp4
	select  Durable_Key,[Master Account Key]--count(*)  
	into #temp12
	from [TMGData].[dbo].[cardholder]
	where extract_datepart = 202104 and Active_Flag = 1
	and [External Status Code] in ('') and [Internal Status Code] in ('','N')
	and [Credit Limit] <= 10000
	and [Card Description] not in
	('Mastercard Business','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and mob >= 12
	and Durable_Key not in
	(select Durable_Key from #temp11
	where N_accts_bankruptcies >= 1)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where Times_1_cycle_delq_pre_6mo >= 1)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where Times_2_cycle_delq_pre_6mo >= 1)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where Times_overlimit_pre_6mo >= 2)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where Times_cash_Advances_pre_6mo >= 1)
	and Durable_Key not in
	((select Durable_Key from #temp11
	where avg_Utilization_pre_6mo > 0.75) 
	union all (select Durable_Key from #temp11
	where avg_Utilization_pre_6mo between 0.50 and 0.75 and Utilization_drift > 0.25))
	and Durable_Key not in
	(select Durable_Key from #temp11
	where avg_payment_rate_pre_12mo = 0 and TRIPFLAG in ('R','P'))
	and Durable_Key not in
	(select Durable_Key from #temp11
	where FICO_score < 660 or FICO_score is null)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where FICO_drift <= -50 or 
	(FICO_score between 660 and 689 and FICO_drift <= -25))
	and Durable_Key not in
	(select Durable_Key from #temp11
	where Bureau_Balance > 30000 or Bureau_Balance is null)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where Debt_Burden > 100 or Debt_Burden is null)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where Months_since_most_recent_delq <= 3)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where N_collections_in_past_12months >= 1 or N_collections_in_past_12months is null)
	and Durable_Key not in
	(select Durable_Key from #temp11
	where N_accts_90plus_days_past_due_in_past_6months >= 1 or N_accts_90plus_days_past_due_in_past_6months is null)
	and AGE > 21
	and Durable_Key not in (select Durable_Key from #RiskExclude)
	and Durable_Key not in (select Durable_Key from #risk_model_Exclusion)

	--select * from #Final_Exclusion
	
	go

---------------data for clustering/segmentation analysis---------------------------------------
	drop table if exists #temp13
	select 
		[Durable_Key],
		[Master Account Key],
		[Credit Limit],
		[mob],
		[Card Description],
		[Last Statement Balance Amount],
		[RevolvingBalance],
		[avg_Utilization_pre_6mo],
		[age],
		[spend],
		[TRIPFLAG],
		[Last Statement Payment Amount],
		[avg_bal_pre_6mo],
		[avg_spend_pre_6mo],
		[sum_profit_pre_6mo],
		[avg_profit_pre_6mo],
		[FICO_score],
		[Annual_Income],
		[Monthly_Income],
		[Bureau_Balance],
		[Debt_Burden],
		[Bureau_CL],
		[Avg_Bureau Balance],
		case 
		when [avg_bal_pre_6mo] <= 900 and [avg_spend_pre_6mo] <= 900 then 'Less Active'
		when [avg_bal_pre_6mo] > 900 and [Last Statement Balance Amount] > 2000 then 'Highly Active'
		when (([avg_bal_pre_6mo] <= 900 and [avg_spend_pre_6mo] > 900) or
		([avg_bal_pre_6mo] > 900 and [Last Statement Balance Amount] <= 2000)) then 'Moderately Active'
		else 'Others' end as cluster
		into #temp13
	from #temp11            
	where [Durable_Key] in (select [Durable_Key] from #temp12)

	go

	select cluster,count(*) as N_Cards,
	avg([Credit Limit]) as Avg_CL,
	avg([avg_spend_pre_6mo]) as Avg_Spend,
	avg([Last Statement Balance Amount]) as Avg_Balance,
	avg(RevolvingBalance) as Avg_Rev_Balance,
	avg(avg_profit_pre_6mo) as Avg_Profit,
	avg([avg_Utilization_pre_6mo]) as Avg_Utilization,
	avg(FICO_score) as Avg_FICO,
	avg(Annual_Income) as Avg_Annual_Income,
	avg(Bureau_Balance) as Avg_Bureau_Balance,
	avg(Bureau_CL) as Avg_Bureau_CL,
	avg(Debt_Burden) as Avg_Debt_Burden,
	sum(case when TRIPFLAG = 'I' then 1 else 0 end) as N_Inactives,
	sum(case when TRIPFLAG = 'P' then 1 else 0 end) as N_Paydown,
	sum(case when TRIPFLAG = 'R' then 1 else 0 end) as N_Revolvers,
	sum(case when TRIPFLAG = 'T' then 1 else 0 end) as N_Transators
	from #temp13
	group by cluster
	with rollup

	
	---------------data for clustering/segmentation analysis---------------------------------------




	go

	drop table if exists #temp14
	select *,
	case 
	when [Credit Limit] <= $3900 then '<=$3.9K'
	when [Credit Limit] <= $7400 then '$3.9K-$7.4K'
	else '$7.4K-$10K' end as CL_Band_DT,
	case 
	when FICO_score <= 711 then '660-711'
	when FICO_score <= 783 then '712-783'
	when FICO_score > 783 and FICO_score <1000 then '784+'
	else 'NA' end as FICO_Band_DT

	into #temp14
	from #temp13
	--select * from #temp14
	go
	
	drop table if exists #temp15
		select *,
	case 
	-- Cluseter1
		when cluster = 'Less Active' and FICO_Band_DT = '660-711' and [Credit Limit] <= 3900 then [Credit Limit] + 1000
		
		when cluster = 'Less Active' and FICO_Band_DT = '712-783' and [Credit Limit] <= 3900 then [Credit Limit] + 2000
		when cluster = 'Less Active' and FICO_Band_DT = '712-783' and [Credit Limit] <= 7400 then [Credit Limit] + 1000
		
		
		when cluster = 'Less Active' and FICO_Band_DT = '784+' and [Credit Limit] <= 3900 then 5000
		when cluster = 'Less Active' and FICO_Band_DT = '784+' and [Credit Limit] <= 7400 then [Credit Limit] + 2000
		when cluster = 'Less Active' and FICO_Band_DT = '784+' and [Credit Limit] > 7400 then [Credit Limit] + 3000
		-- Cluseter2

		when cluster = 'Moderately Active' and FICO_Band_DT = '660-711' and [Credit Limit] <= 3900 then [Credit Limit] + 1000
		
		when cluster = 'Moderately Active' and FICO_Band_DT = '712-783' and [Credit Limit] <= 3900 then [Credit Limit] + 2000
		when cluster = 'Moderately Active' and FICO_Band_DT = '712-783' and [Credit Limit] <= 7400 then [Credit Limit] + 1000
		
		when cluster = 'Moderately Active' and FICO_Band_DT = '784+' and [Credit Limit] <= 3900 then 5000
		when cluster = 'Moderately Active' and FICO_Band_DT = '784+' and [Credit Limit] <= 7400 then [Credit Limit] + 1000
		when cluster = 'Moderately Active' and FICO_Band_DT = '784+' and [Credit Limit] > 7400 then [Credit Limit] + 2000
		
		-- Cluseter3
		when cluster = 'Highly Active' and FICO_Band_DT = '660-711' and [Credit Limit] <= 4000 then [Credit Limit] + 2000
		when cluster = 'Highly Active' and FICO_Band_DT = '712-783' and [Credit Limit] <= 7400 then [Credit Limit] + 3000
		when cluster = 'Highly Active' and FICO_Band_DT = '784+' and [Credit Limit] <= 7400 then [Credit Limit] + 3000
		when cluster = 'Highly Active' and FICO_Band_DT = '784+' and [Credit Limit] > 7400 then [Credit Limit] + 5000
		
		else null end as [Proposed CL],
		Monthly_Income - (0.8*Monthly_Income)- (0.03*Bureau_balance) as Monthly_Diposable_Income 
	into #temp15
	from #temp14

	go

	select * from #temp15
	


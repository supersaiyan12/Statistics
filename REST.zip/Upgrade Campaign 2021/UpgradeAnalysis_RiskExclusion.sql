--==================================================== 2022 BALANCE TRANSFER - LIST GENERATION ====================================================
--=====================================================================================================================================================

--**********************
--|| STATIC POOL DATA ||
--**********************
Drop table if exists #CLIEligible
Select 
*
into #CLIEligible
from Analytics.dbo.JK_CLI2022_FinalCards


---------------------------------------
DROP TABLE IF EXISTS #temp1
SELECT 
	A.Durable_Key
	,A.[Master Account Key]
	,A.[Social Security Number]
	,CASE WHEN B.DURABLE_KEY IS NOT NULL THEN B.[Proposed CL] ELSE A.[Credit Limit] END AS [Credit Limit]
	,A.mob
	,A.[Card Description]
	,A.[External Status Code]
	,A.[Internal Status Code]
	,A.[Last Statement Balance Amount]
	,A.RevolvingBalance
	,A.age
	,(A.[Last Statement Sale Amount]-A.[Last Statement Return Amount]) as spend
	,A.TRIPFLAG
	,A.[Last Statement Payment Amount]
	,A.Extract_DatePart as sp_month
	,A.[Account System Entry Date]
	,A.[Account Number]
	, CASE WHEN B.DURABLE_KEY IS NOT NULL THEN B.[Proposed CL] ELSE A.[Credit Limit] END - A.[Last Statement Balance Amount] as OpenToBuy


INTO #temp1
FROM [TMGData].[dbo].[cardholder] a
left join #CLIEligible b on a.Durable_Key = b.Durable_key
where 1=1
and a.[Active_flag] = 1 
and a.Extract_DatePart = 202204
and a.[External Status Code] in ('') and a.[Internal Status Code] in ('','N')
and a.[Card Description] not in ('Mastercard Business','MasterCard Black & Gold','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
--and CASE WHEN B.DURABLE_KEY IS NOT NULL THEN B.[Proposed CL] ELSE A.[Credit Limit] END > 1000
--and  (CASE WHEN B.DURABLE_KEY IS NOT NULL THEN B.[Proposed CL] ELSE A.[Credit Limit] END - a.[Last Statement Balance Amount]) > 500
and A.mob > 11


go


--***********************************
-- || STEP 1: PRE 12 MONTH NUMBERS ||
--***********************************

Drop table if exists #temp_pre_12mo_2
select 
	Durable_Key as d_pre_12mo
	,sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_12mo
	,sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_12mo
	,sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_12mo
	,sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_12mo
	,sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_12mo
	,sum([Last Statement Balance Amount]) as sum_bal_pre_12mo
	,sum(RevolvingBalance) as sum_revbal_pre_12mo
	,sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_12mo
	,avg([Last Statement Balance Amount]) as avg_bal_pre_12mo
	,avg(RevolvingBalance) as avg_revbal_pre_12mo
	,avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_12mo

into #temp_pre_12mo_2
from [TMGData].[dbo].[cardholder]

	where [Active_flag] = 1 
	and Extract_DatePart between 202204 - 99 and 202204
	and Durable_Key in (select Durable_Key from #temp1)
	group by Durable_Key

go

--******************************************
-- ||  TIMES TRANSACTORS IN LAST 24 MONTHS ||
--******************************************
--drop table if exists #Times_Transactors
--Select 
--Durable_Key as DurableKey_TimesTransactors
--,sum(case when TRIPFLAG = 'T' then 1 else 0 end) as Times_Transactors

--into #Times_Transactors
--from [TMGData].[dbo].[cardholder]

--where [Active_flag] = 1 
--and Extract_DatePart between 202202 - 99 and 202204
--and Durable_Key in (select Durable_Key from #temp1)
--group by Durable_Key



--******************************************
-- || STEP 2: PRE 12 MONTH PROFIT NUMBERS ||
--******************************************
Drop table if exists #temp_pre_12mo_3
select 
	Durable_Key
	,Extract_DatePart
	,case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization
	,case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate
	,case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate

	,([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income
	,([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees
	,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income    
	,([Last Statement Balance Amount]*0.02/12) as COF
	,(ChargeoffAmount_final) as chgoff_amt
	,case when [Card Description] in ('Mastercard Platinum Rewards','Mastercard World Credit') then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end as rewards_expense -- verify it with internal team
	,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense
	,case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost
	into #temp_pre_12mo_3
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and Extract_DatePart between 202204 - 99 and 202204
	and Durable_Key in 
	(select Durable_Key from #temp1)

--**************************************************
-- || STEP 3: PRE 12 MONTH PROFIT NUMBERS SUMMARY ||
--**************************************************
Drop table if exists #temp_pre_12mo_3a
select 
	Durable_Key
	,count(*) as N_months
	,sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit
	,avg(Utilization) as avg_Utilization
	,avg(revolve_rate) as avg_revolve_rate
	,avg(payment_rate) as avg_payment_rate

into #temp_pre_12mo_3a
from #temp_pre_12mo_3
group by Durable_Key
	
go

Drop table if exists #temp_pre_12mo_4
select 
	a.*
	,b.profit as sum_profit_pre_12mo,b.profit/b.N_months as avg_profit_pre_12mo
	,b.avg_Utilization as avg_Utilization_pre_12mo
	,b.avg_revolve_rate as avg_revolve_rate_pre_12mo
	,b.avg_payment_rate as avg_payment_rate_pre_12mo

into #temp_pre_12mo_4
from #temp_pre_12mo_2 a
left join #temp_pre_12mo_3a b
on a.d_pre_12mo = b.Durable_Key



--*********************************
-- || STEP 4: PRE 6 MONTH NUMBERS||
--*********************************
Drop table if exists #temp_pre_6mo_2
select Durable_Key  as d_pre_6mo,
	sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_6mo,
	sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_6mo,
	sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_6mo,
	sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_6mo,
	sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_6mo,
	sum([Last Statement Balance Amount]) as sum_bal_pre_6mo,
	sum(RevolvingBalance) as sum_revbal_pre_6mo,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_6mo,
	avg([Last Statement Balance Amount]) as avg_bal_pre_6mo,
	avg(RevolvingBalance) as avg_revbal_pre_6mo,
	avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_6mo
	
	into #temp_pre_6mo_2
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and [Card Description] not in ('Mastercard Business','MasterCard Black & Gold','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
	and Extract_DatePart between  202111 and 202204
	and Durable_Key in 
	(select Durable_Key from #temp1)
	group by Durable_Key


--******************************************
-- || STEP 5: PRE 6 MONTH PROFIT NUMBERS ||
--******************************************
Drop table if exists  #temp_pre_6mo_3
select 
	Durable_Key
	,Extract_DatePart
	,case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization
	,case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate
	,case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate

	,([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income
	,([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees
	,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income   
	,([Last Statement Balance Amount]*0.02/12) as COF
	,(ChargeoffAmount_final) as chgoff_amt
	,case when [Card Description] in ('Mastercard Platinum Rewards','Mastercard World Credit') then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end as rewards_expense -- verify
	,([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense
	,case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost

into #temp_pre_6mo_3
from [TMGData].[dbo].[cardholder]
where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business','MasterCard Black & Gold','MasterCard Classic','MasterCard Gold','MasterCard Merchant Platinum')
and Extract_DatePart between 202111 and 202204
and Durable_Key in 
(select Durable_Key from #temp1)


--*************************************************
-- || STEP 6: PRE 6 MONTH PROFIT NUMBERS SUMMARY ||
--*************************************************
Drop table if exists #temp_pre_6mo_3a
select 
	Durable_Key
	,count(*) as N_months
	,sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit
	,avg(Utilization) as avg_Utilization,avg(revolve_rate) as avg_revolve_rate,avg(payment_rate) as avg_payment_rate

into #temp_pre_6mo_3a
from #temp_pre_6mo_3
group by Durable_Key


--***************************************************
-- || STEP 7: DATA GETHERING OF DATA BUILDED ABOVE ||
--***************************************************
Drop table if exists #temp_pre_6mo_3b
select a.*,
	b.profit as sum_profit_pre_6mo,b.profit/b.N_months as avg_profit_pre_6mo
	,b.avg_Utilization as avg_Utilization_pre_6mo
	,b.avg_revolve_rate as avg_revolve_rate_pre_6mo
	,b.avg_payment_rate as avg_payment_rate_pre_6mo

into #temp_pre_6mo_3b
from #temp_pre_6mo_2 a
left join #temp_pre_6mo_3a b
on a.d_pre_6mo = b.Durable_Key

go

--********************************
-- || STEP 13: BUREAU DATA PULL ||
--********************************
Drop table if exists #temp4	
select distinct 
	customerInput_socSecurityNum0007,
	cemp09_bFinscr*1 as FICO_score,
	eads04_bcTrd*1 as N_bankcard_Trades,
	eads142_at33a*1 as Bureau_Balance,
	cast(eads142_bc33s as int)/case when cast(eads142_bc28s as int)=0 then 1 else cast(eads142_bc28s as int) end as Debt_Burden,
	eads142_g094s*1 as N_accts_bankruptcies,
	eads142_g237s*1 as N_Inquiries_in_past_6months
	,eads142_g300s as Worst_Rating_on_CC_Trades_in_Past_12_Months

into #temp4
from uiccu.dbo.TransUnionAttribute_20220430
where customerInput_socSecurityNum0007 in (select  distinct [Social Security Number] from #temp1)

--**********************************
-- || STEP 11: COMBINING ALL DATA ||
--**********************************
Drop table if exists #temp2
select a.*,b.*,c.*,d.*--,e.*
	,(avg_Utilization_pre_6mo-avg_Utilization_pre_12mo) / case when avg_Utilization_pre_12mo =0 then 1 else avg_Utilization_pre_12mo end as Util_Drift
	,case when(avg_Utilization_pre_12mo > 0.75) then 1 else 0 end as Exclu_AvgUtilPre12Months
	,case when((avg_Utilization_pre_12mo between 0.50 and 0.75)  and (avg_Utilization_pre_6mo-avg_Utilization_pre_12mo) / 
		case when avg_Utilization_pre_12mo =0 then 1 else avg_Utilization_pre_12mo end > 0.25) then 1 else 0 end as Exclu_Utili2

	, case when (case when(avg_Utilization_pre_12mo >0.75) then 1 else 0 end =1 OR 
		case when((avg_Utilization_pre_6mo between 0.50 and 0.75)  and (avg_Utilization_pre_6mo-avg_Utilization_pre_12mo) / 
		case when avg_Utilization_pre_12mo =0 then 1 else avg_Utilization_pre_12mo end > 0.25) then 1 else 0 end =1) then 1 else 0 end as Exclu_FinalUtil
	
	,case when(d.FICO_score-f.Score_1 > 50) then 1 else 0 end as Exc_FicoDropped50Pts
	,case when((d.FICO_score between  680 and 709) and (d.FICO_score-f.Score_1) > 25) then 1 else 0 end as Exc_Fico2

	,case when(case when(d.FICO_score-f.Score_1 > 50) then 1 else 0 end =1 OR	
		case when((d.FICO_score between  680 and 709) and (d.FICO_score-f.Score_1) > 25) then 1 else 0 end =1) then 1 else 0 end as Exclu_FicoDrop

	into #temp2
	from #temp1 a
	left join #temp_pre_12mo_4 b
	on a.Durable_Key = b.d_pre_12mo
	left join #temp_pre_6mo_3b c
	on a.Durable_Key = c.d_pre_6mo
	left join #temp4 d
	on a.[Social Security Number] = d.customerInput_socSecurityNum0007
	--left join #Times_Transactors e
	--on a.Durable_Key = e.DurableKey_TimesTransactors 
	left join analytics.dbo.TransUnion_CreditBureau_data_May21  f
	on a.[Social Security Number] = f.SSN

go



--***********************************
-- || STEP 14: RISK TRIGGERS DATA ||
--***********************************
drop table if exists #NAME1
	--select max(processdate) from ARCUSYM000..SAVINGS
	select distinct a.PARENTACCOUNT,SSN,BIRTHDATE,a.USERCHAR3 FICO_Latest
		into #NAME1
		from 
		(
		select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date 
		from ARCUSYM000..NAME
		) a
		left join ARCUSYM000..SAVINGS b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		and a.ProcessDate=b.ProcessDate
		where a.TYPE=0
		and a.ProcessDate=20220430
		and b.SHARECODE=0 
		and b.IRSCODE=0
		and b.TYPE<9000
		and b.type<>10 
		and b.type<>11
		and b.type<>12
		and b.type<>14
		and b.type<>113
		and b.type<>510
		and b.type<>512
		and b.ORIGINALDEPOSITDATE is not null
		and b.CLOSEDATE is null 
		and b.CHARGEOFFDATE is null
		order by PARENTACCOUNT
	
	go
		

drop table if exists #Unemployment
select 
a.PARENTACCOUNT,1 Unemployment,sum(BALANCECHANGE) Amount
into #Unemployment
from 
(
select PARENTACCOUNT,PARENTID,EFFECTIVEDATE,SEQUENCENUMBER-1 as SEQUENCENUMBER,COMMENT
, case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE)) 
else  CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVE_DATE from ARCUSYM000..SAVINGSTRANSACTION
where COMMENT like '%Unemplo%' and EFFECTIVEDATE >='2021-11-01 00:00:00' 
) A 
left join 
(
select PARENTACCOUNT,PARENTID,EFFECTIVEDATE,SEQUENCENUMBER,COMMENT,BALANCECHANGE
, case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE)) 
else  CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVE_DATE from ARCUSYM000..SAVINGSTRANSACTION
where EFFECTIVEDATE >='2021-11-01 00:00:00'
) b
on a.PARENTACCOUNT=b.PARENTACCOUNT and a.PARENTID=b.PARENTID
and a.EFFECTIVEDATE=b.EFFECTIVEDATE and a.SEQUENCENUMBER=b.SEQUENCENUMBER
group by a.PARENTACCOUNT


	go

drop table if exists #Overdraft
select 
PARENTACCOUNT,sum(case when ProcessDate in (20220228,20220431,20220430) then [# Overdraft] else 0 end) [# Overdraft_2022]
	,sum(case when ProcessDate in (20210228,20210331,20210430) then [# Overdraft] else 0 end) [# Overdraft_2021]
into #Overdraft
from
	(select 
	ProcessDate,PARENTACCOUNT,sum(Overdraft_fee) Overdraft_fee,sum(Overdraft_count) [# Overdraft]
				
	from
			(
			select 
			*,case when Overdraft_fee>0 then 1 else 0 end Overdraft_count
			from
					(
					select 
					*,isnull(case when OVERDRAFTFEEYTD>0 then lead_overdraft-OVERDRAFTFEEYTD else 0 end,0) Overdraft_fee
					from 
							( select ProcessDate,PARENTACCOUNT,ID,TYPE
							,BALANCE
							,case when OPENDATE=CLOSEDATE then 0 else 1 end FLag ,OVERDRAFTFEELASTYR,OVERDRAFTTOLERANCE
							,overdraftfeeytd,LEAD(overdraftfeeytd,1) 
							over(partition by PARENTACCOUNT,ID,TYPE,year_ order by PARENTACCOUNT,ID,ProcessDate) lead_overdraft
							,CHARGEOFFDATE,OPENDATE,closedate
							from 
									(select * ,left(ProcessDate,4) year_ from ARCUSYM000..SAVINGS 
									where ProcessDate in (20210228,20210331,20210430,20220228,20220431,20220430)) A
							) B
					where  CHARGEOFFDATE is null and OpenDate is not null and CLOSEDATE is null and flag=1
					) A
			) D
			group by ProcessDate,PARENTACCOUNT
	) F
	where [# Overdraft] >0
	group by PARENTACCOUNT
				

	go

Drop table if exists #HELOC
	--select distinct chargeoffdate from ARCUSYM000..LOAN order by chargeoffdate
select PARENTACCOUNT,sum(Flag_HELOC) Flag_HELOC,sum(HELOC_Jan) HELOC_Jan,sum(HELOC_Feb) HELOC_Feb,
sum(HELOC_Mar) HELOC_Mar--,sum(HELOC_April) HELOC_April
into #HELOC
from
	(
	select ProcessDate,PARENTACCOUNT,case when Extract_date=Extract_open then 1 else 0 end Flag_HELOC
	,case when Extract_date=Extract_open and ProcessDate=20210430 then 1 else 0 end HELOC_Jan
	,case when Extract_date=Extract_open and ProcessDate=20210228 then 1 else 0 end HELOC_Feb
	,case when Extract_date=Extract_open and ProcessDate=20210331 then 1 else 0 end HELOC_Mar
	--,case when Extract_date=Extract_open and ProcessDate=20200428 then 1 else 0 end HELOC_April
	from
	( select *,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate)) 
	else concat(year(opendate),month(opendate)) end Extract_open
	,CONCAT((PARENTACCOUNT),(id))UNID,dateadd(month,-1,DUEDATE) [Duedatenew]
	,left(ProcessDate,6) Extract_date,
	case when len(month(CHARGEOFFDATE))=1then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
	else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end extract_chargeoff
	,case when opendate=closedate then 0 else 1 end Flag
	,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
		from ARCUSYM000..LOAN where  ORIGINALDATE is not null 
		and OpenDate is not null and CLOSEDATE is null 
		and (chargeoffdate>='2021-02-01' or chargeoffdate is null)
		and processdate in (20210228,20210331,20210430)
		) A
		left join  ARCUSYM000.arcu.ARCULoanCategory B
		on a.TYPE=b.LoanType
		where DESCRIPTION like '%line of%' or DESCRIPTION like '%HELOC%'--LoanCategory2 like 'HEl%' 
		) B
		where Flag_HELOC>0
		group by PARENTACCOUNT


		go
		
drop table if exists ##RiskTrigger
select 
a.SSN,a.FICO_Latest
,sum(isnull(b.[# Overdraft_2021],0)) [# Overdraft_2021]
,sum(isnull(b.[# Overdraft_2022],0)) [# Overdraft_2022]
,sum(isnull(c.Amount,0)) [$ Unemployment],sum(isnull(c.Unemployment,0)) Unemployment
,sum(isnull(d.Flag_HELOC,0)) Flag_HELOC,sum(isnull(d.HELOC_Jan,0)) HELOC_Jan
,sum(isnull(d.HELOC_Feb,0)) HELOC_Feb,sum(isnull(d.HELOC_Mar,0)) HELOC_Mar
--,sum(isnull(d.HELOC_April,0)) HELOC_April
into ##RiskTrigger
from #NAME1 A
left join #Overdraft b
on a.PARENTACCOUNT=b.PARENTACCOUNT
left join #Unemployment c
on a.PARENTACCOUNT=c.PARENTACCOUNT
left join #HELOC d
on a.PARENTACCOUNT=d.PARENTACCOUNT
Group by A.SSn,a.FICO_Latest

GO

drop table if exists #Risktriger_data
	select a.[Social Security Number],a.Durable_Key,a.[Master Account Key]
	,b.[# Overdraft_2021],b.[# Overdraft_2022],b.[$ Unemployment],b.Unemployment,b.Flag_HELOC,b.HELOC_Jan,b.HELOC_Feb,b.HELOC_Mar--,b.HELOC_April
	into #Risktriger_data
	from (select distinct [Social Security Number],Durable_Key,[Master Account Key]
	from #temp1) a
	left join (select SSN
				,sum([# Overdraft_2021]) [# Overdraft_2021],sum([# Overdraft_2022]) [# Overdraft_2022]
				,sum([$ Unemployment]) [$ Unemployment],sum(Unemployment) Unemployment
				,sum(Flag_HELOC) Flag_HELOC,sum(HELOC_Jan) HELOC_Jan
				,sum(HELOC_Feb) HELOC_Feb,sum(HELOC_Mar) HELOC_Mar--,sum(HELOC_April) HELOC_April
				from ##RiskTrigger 
				group by SSN
				) b
	on a.[Social Security Number]=b.ssn
	where a.Durable_Key in (select Durable_Key from #temp1) 
	and a.[Master Account Key] in (select [Master Account Key] from #temp1	)
	
	go

	drop table if exists #Overdraft
	select *,case when [# Overdraft_2022]>0 and [# Overdraft_2021]>0 
	then [# Overdraft_2022]/[# Overdraft_2021] else 0 end Overdraft_rate
	 into #Overdraft
	 from #Risktriger_data
	 where [# Overdraft_2021]>0
	
	go

	 drop table if exists #Unemployment
	 select *,
	 case when [# Overdraft_2022]>0 and [# Overdraft_2021]>0 
	 then [# Overdraft_2022]/[# Overdraft_2021] else 0 end Overdraft_rate
	 into #Unemployment
	 from #Risktriger_data
	 where [$ Unemployment]>0
	
	go

	 drop table if exists #Heloc
	  select *,case when [# Overdraft_2022]>0 and [# Overdraft_2021]>0 
	  then [# Overdraft_2022]/[# Overdraft_2021] else 0 end Overdraft_rate
	 into #Heloc
	 from #Risktriger_data
	 where Flag_HELOC>0

	 go

	 drop table if exists #RiskExclude
	  select *,case when [# Overdraft_2022]>0 and [# Overdraft_2021]>0 
	  then [# Overdraft_2022]/[# Overdraft_2021] else 0 end Overdraft_rate
	 into #RiskExclude
	 from #Risktriger_data
	 where Flag_HELOC>0 or  [# Overdraft_2021]>0 or [$ Unemployment]>0

drop table if exists #risk_model_Exclusion
select Durable_Key
into #risk_model_Exclusion
from ##Final_Riskmodel_list 
where Deciling=1 

--*******************************g
-- || STEP 15: RISK EXCLUSIONS ||
--*******************************
Drop table if exists #risk
SELECT 
*
into #risk
FROM #temp2
where 1=1
and N_accts_bankruptcies <= 0  
--AND Times_Transactors < 13
and Times_1_cycle_delq_pre_6mo <1
and Times_2_cycle_delq_pre_12mo <1
and Times_overlimit_pre_6mo <1
and Times_cash_Advances_pre_6mo <1
and avg_Utilization_pre_12mo <= 0.75
and Exclu_Utili2 =0
and FICO_score>=680
and Exc_FicoDropped50Pts=0
and Exc_Fico2 = 0
AND DEBT_BURDEN<1
and N_Inquiries_in_past_6months < 2
AND Worst_Rating_on_CC_Trades_in_Past_12_Months < 3
and AGE >21
and Durable_Key not in (select distinct Durable_Key from #risk_model_Exclusion)
and Durable_Key not in (select Durable_Key from #RiskExclude)



--select * into Analytics.dbo.JK_2022_BTList from #risk




----------------------------------------------------- WILL APPLY AT LAST --------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------

--**********************
--|| MEMBER DATA PULL ||
--**********************
--Drop table if exists #Member
--select
--distinct
--SSN
--,first
--,LAST
--,CITY
--,STATE
--,ZIPCODE
--INTO #Member
--from ARCUSYM000.dbo.NAME
--where ProcessDate = '20220431'
--and SSN in (select distinct [Social Security Number] from #temp1)
--and FIRST is not null
--and LAST is not null
--and city is not null
--and STATE is not null
--and ZIPCODE is not null



--*******************
--|| DATA MATCHING ||
--*******************
--Drop table if exists #SemiFinal
--Select 
--distinct
--b.FIRST
--,b.LAST
--, a.Durable_Key as [Reference Number]
--,a.[Social Security Number]
---- Address Number
---- Pre Directinal Number
----[7] Street Name or Full Street Address (Required)
----[8] Post-Directional
----[9] Street Type
--,b.CITY as [City (Required)]
--,b.STATE as [State (Required)]
--,b.ZIPCODE as [Zip Code (Required)]
----[13] Maternal Name (recommended for Puerto Rico)
--,a.[Master Account Key] as [Master Account Key]
--,a.[Account Number] as [Account Number]
--,a.[External Status Code]
--,a.[Internal Status Code]
--,a.[Card Description]
--,a.[Account System Entry Date]
--,a.[Credit Limit]
--,202204 as extract_datepart
--,a.AGE
--,rank() Over(Partition by a.[Social Security Number] order by [Master Account Key]) as rank

--into #SemiFinal
--from #temp1 a left join 
--	(select * from #Member where SSN not in (select distinct ssn from #Member group by ssn  having count(*) >1)) b
--on a.[Social Security Number] = b.SSN
--where first is not null


--------------



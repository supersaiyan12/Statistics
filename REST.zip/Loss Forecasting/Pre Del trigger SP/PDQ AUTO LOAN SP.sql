
		alter procedure [dbo].[PDQ Autoloan Trigger] 
		as
			begin
		declare @staticpooldate date
		set  @staticpooldate= (select datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Processdate from
		(select max(ProcessDate) processdate from ARCUSYM000..LOAN) A)
		
		drop table if exists #groupproducttype_Deposits0
		select * ,case when ProductName like '%money%'  or ProductName like '% MM %' then 'MoneyMarket'
		when ProductName='Youth Savings' and ApplicationDescription='Certificates' then 'Savings'
		when ProductCode=0 and ApplicationDescription='Certificates' then 'Savings'
		when ProductName='40 Month CD' and ApplicationDescription='Certificates' then 'Checking'
		when ProductName='Certificate' and ApplicationDescription='Certificates' then 'Checking' 
		when ProductName='Public Funds' and ApplicationDescription='Certificates' then 'Certificates'  
		 else ApplicationDescription end Product_Group_wise
		into #groupproducttype_Deposits0
		from
				(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName
				,ApplicationDescription,ApplicationTableName
				 from [AE_EDW].[tempods].[S_CRMProductType] a
				left join [AE_EDW].[tempods].[S_CRMApplicationType] b
				on a.ApplicationTypeID=b.ApplicationTypeID
				where ApplicationDescription is not null
				and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a order by ProductCode

	drop table if exists #LoanStatic
	select * 
	into #LoanStatic
	from
	(
	select 
		[ProcessDate],[Process date],[Process_date],[PARENTACCOUNT],concat(PARENTACCOUNT,ID) UNID
		,case when LoanCategory2='Vehicle' then 'Vehicle'
		when LoanCategory2='Personal' and LoanCategory3='Secured' then 'Personal_Secured'
		when LoanCategory2='Personal' and LoanCategory3='Unsecured' then 'Personal_Unsecured'
		when LoanCategory2='Real Estate' and LoanCategory4 like 'HEL%' then 'HELOC' 
		when LoanCategory2='Real Estate' then 'Real Estate'
		when LoanCategory2='Commercial Loans' then 'Commercial Loans'
		when LoanCategory2='Construction And Development' then 'Construction And Development'
		when LoanTypeDescription like '%AUTO (OL)' then 'Vehicle' else LoanTypeDescription end Loan_Categories
		,case when LoanCategory3='Indirect' then 'Indirect' else 'Direct' END Direct_indirect
		from
			(
			select *,CONCAT(PARENTACCOUNT,ID) UNID
			,case when opendate=closedate then 0 else 1 end Flag
			,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date 
			then 1 else 0 end Open_Flag
			,DATEDIFF(month,OPENDATE,@staticpooldate) MOB	-- add the @Staticpooldate
			,DATEDIFF(month,OPENDATE,MATURITYDATE) Loan_Term
			,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
				from 
					(select *
					,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
					else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
					,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
					else concat(year(opendate),month(opendate)) end Open_date
					,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
					else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
					,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
					,left(ProcessDate,6) Process_date
					from ARCUSYM000..LOAN
					--where (CHARGEOFFDATE>=@staticpooldate or CHARGEOFFDATE is null ) 
					) H
				where  ORIGINALDATE is not null and OpenDate is not null 
				and CLOSEDATE is null and CHARGEOFFDATE is null
				and [Process date]=@staticpooldate		-- Later give the @staticpooldate date here 
				and MATURITYDATE>@staticpooldate	-- add 3 month in currrent date
			) A
				left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
				on b.loantype=a.TYPE
				where Flag=1 and Open_Flag=1 
				) D
				where Loan_Categories='Vehicle'
				order by PARENTACCOUNT,ProcessDate
									
		Drop table if exists #Processdate
		select 
		Process_date,max(ProcessDate) MAX_ProcessDate 
		into #Processdate
		from
			(
			select ProcessDate,left(ProcessDate,6) Process_date
			,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
			from ARCUSYM000..NAME group by ProcessDate
			) A 
			where [Process date] between dateadd(month,-12,@staticpooldate) and @staticpooldate
			group by Process_Date
			order by Process_Date
		
		  ---- *******************////////  mapping using tracking
	 

	DROP TABLE IF EXISTS #TMPName
	SELECT N.PARENTACCOUNT,N.SSN,N.FIRST, N.LAST, N.BIRTHDATE,STREET,CITY,STATE,ZIPCODE,USERCHAR3 FICO_Staticpool
	 INTO #TMPName
	FROM
	(
	SELECT SSN,PARENTACCOUNT,FIRST,LAST,BIRTHDATE,STREET,CITY,STATE,ZIPCODE,case when isnumeric(N.USERCHAR3)=0 then null when  N.USERCHAR3>1000 then null else N.USERCHAR3 end USERCHAR3
	from
		(select *,datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) [Process Date]
		FROM ARCUSYM000.dbo.NAME) N
	LEFT JOIN ARCUSYM000.dbo.ACCOUNT A
		ON N.PARENTACCOUNT = A.ACCOUNTNUMBER
		AND N.ProcessDate = A.ProcessDate
	WHERE N.TYPE = 0
		AND N.[Process Date] =(@staticpooldate) --(SELECT MAX(ProcessDate) FROM ARCUSYM000.dbo.IRS)
		AND N.LAST <> 'NEW MEMBER'
		--AND N.BIRTHDATE is not null
		AND N.SSNTYPE in (0,9)
		AND N.NAMEFORMAT = 0
		AND A.CLOSEDATE is null
		--AND A.type in (0,70)
	--UNION ALL

	--SELECT distinct SSN,N.PARENTACCOUNT, FIRST, LAST, BIRTHDATE,STREET,CITY,STATE,N.USERCHAR3
	--from
	--(select *,datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) [Process Date]
	--FROM ARCUSYM000.dbo.LOANNAME) N
	--LEFT JOIN ARCUSYM000.dbo.LOAN L
	--	ON L.ProcessDate = N.ProcessDate
	--	AND L.PARENTACCOUNT = N.PARENTACCOUNT
	--	AND L.ID = N.PARENTID
	--WHERE N.TYPE = 1
	--	AND N.[Process Date] = (@staticpooldate)
	--	AND N.EXPIRATIONDATE is null
	--	AND L.CLOSEDATE is null
	--	AND L.CHARGEOFFDATE is null
	--	AND N.BIRTHDATE is not null
	--	AND N.SSNTYPE in (0,9)
	--UNION ALL

	--SELECT distinct SSN,N.PARENTACCOUNT, FIRST, LAST, BIRTHDATE,STREET,CITY,STATE,N.USERCHAR3
	--from
	--(select * ,datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) [Process Date] FROM ARCUSYM000.dbo.SAVINGSNAME) N
	--LEFT JOIN ARCUSYM000.dbo.Savings S
	--	ON S.ProcessDate = N.ProcessDate
	--	AND S.PARENTACCOUNT = N.PARENTACCOUNT
	--	AND S.ID = N.PARENTID
	--WHERE N.[Process Date] =(@staticpooldate)-- (SELECT MAX(ProcessDate) FROM ARCUSYM000.dbo.IRS)
	--	AND N.EXPIRATIONDATE is null AND S.CLOSEDATE is null AND S.CHARGEOFFDATE is null
	--	AND N.SSNTYPE in (0,9) AND N.NAMEFORMAT = 0	AND N.BIRTHDATE is not null
	) N
	where PARENTACCOUNT in (select PARENTACCOUNT from #LoanStatic group by PARENTACCOUNT)
	group by N.PARENTACCOUNT,N.SSN,N.FIRST, N.LAST, N.BIRTHDATE,STREET,CITY,STATE,ZIPCODE,USERCHAR3
	
	Drop table if exists #doubl
	select SSN,count(*) cnt into #doubl from #TMPName group by SSN having count(*)>1
	Drop table if exists #D_Member
	select AccountNumber PARENTACCOUNT 
	into #D_Member
	from AE_EDW..D_Member where SSN in (select SSN from #doubl) group by AccountNumber order by AccountNumber 
	Drop table if exists #No_Duplicate
	select * 
	into #No_Duplicate
	from #TMPName
	where PARENTACCOUNT in (select PARENTACCOUNT from #D_Member)
	
	Drop table if exists #FinalName
	select PARENTACCOUNT,SSN,FIRST,LAST,BIRTHDATE,STREET,CITY,State,ZIPCODE
	,case when isnumeric(FICO_Staticpool)=0 then null when FICO_Staticpool>1000 then null  else FICO_Staticpool end FICO_Staticpool
	into #FinalName
	from		(Select a.* from #TMPName a left join #doubl b on a.SSN=b.SSN where b.SSN is null
			union 
			select * from #No_Duplicate) A
	

		Drop table if exists #QFICO
		
				select [Process date],case when [Process date] between EOMONTH(dateadd(month,-3,@staticpooldate)) and EOMONTH(dateadd(month,-1,@staticpooldate)) then 'Q1'
											when [Process date] between EOMONTH(dateadd(month,-6,@staticpooldate)) and EOMONTH(dateadd(month,-4,@staticpooldate)) then 'Q2'
											when [Process date] between EOMONTH(dateadd(month,-9,@staticpooldate)) and EOMONTH(dateadd(month,-7,@staticpooldate)) then 'Q3'
											when [Process date] between EOMONTH(dateadd(month,-12,@staticpooldate)) and EOMONTH(dateadd(month,-10,@staticpooldate)) then 'Q4'
				end Quarterly,a.PARENTACCOUNT,SSN,case when a.USERCHAR3_ is null or a.USERCHAR3_>1000 then 0 else USERCHAR3_ end FICO
				into #QFICO
				from 
						(select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date],try_parse(USERCHAR3 as int) USERCHAR3_
						from ARCUSYM000..NAME
						where PARENTACCOUNT in (select PARENTACCOUNT from #FinalName) 
						) A
				left join ARCUSYM000..ACCOUNT B
						on a.PARENTACCOUNT=b.ACCOUNTNUMBER
						and a.ProcessDate=b.ProcessDate
						where a.TYPE=0
						and a.ProcessDate in (select MAX_ProcessDate from #Processdate where right(left(MAX_ProcessDate,6),2) in (3,6,9,12) )
						--and a.Process_date=dateadd(year,-1,@staticpooldate)
						AND A.LAST <> 'NEW MEMBER'
						AND A.BIRTHDATE is not null
						AND A.SSNTYPE in (0,9)
						AND A.NAMEFORMAT = 0
						AND B.CLOSEDATE is null
						
						group by [Process date],a.PARENTACCOUNT,SSN,A.USERCHAR3_
						order by  a.PARENTACCOUNT
						
		Drop table if exists #QuarterlyFICO				
		select 
		PARENTACCOUNT,max([Q1])[Q1],max([Q2])[Q2] ,max([Q3])[Q3] ,max([Q4])[Q4] 
		Into #QuarterlyFICO
		from	(
			select * from #QFICO
			) S
		Pivot
		(
		max(FICO) 
		for Quarterly in ([Q1],[Q2],[Q3],[Q4])
		
		) as PIVOT_table
		group by PARENTACCOUNt
		order by PARENTACCOUNT
		
			
			
		drop table if exists #Delinquency
		select processdate,Process_date,AccountNumber,LoanID,Cycle1,Cycle2,Cycle3
		into #Delinquency
		from
		 (
				 select 
				Convert(date, cast(l.Processdate as nvarchar)) as Date, l.ProcessDate,left(l.ProcessDate,6) Process_date,
				AccountNumber, 
				LoanID, 
				l.LoanOpenDate, 
				LoanDelqDays,
				case when LoanDelqDays between 1 and 29 then 1 else 0 end Cycle1 
				,case when LoanDelqDays between 30 and 59 then 1 else 0 end Cycle2 
				,case when LoanDelqDays between 60 and 89 then 1 else 0 end Cycle3 
				,LoanPastDueAmount, 
				LoanBalance, 
				l.LoanChargeoffDate, 
				l.LoanType, 
				alc.LoanTypeDescription, 
				Count(t.locator) as BankruptcyCount 
				from arcusym000.arcu.ARCULoanDetailed  as l
						left join arcusym000.arcu.ARCULoanCategory as alc on alc.LoanType = l.LoanType
						left join ARCUSYM000.dbo.tracking as t on t.processdate = l.ProcessDate and t.PARENTACCOUNT = l.AccountNumber 
						and t.TYPE = 36 and (t.EXPIREDATE is null or t.EXPIREDATE < Convert(date, cast(t.processdate as varchar)))
				where LoanDelqDays > 0 
				and l.processdate in (select MAX_ProcessDate from #processdate)
				and l.AccountNumber in (select PARENTACCOUNT from #LoanStatic group by PARENTACCOUNT)
				group by l.ProcessDate,l.AccountNumber,l.LoanID,l.LoanOpenDate,l.LoanPastDueAmount,l.LoanChargeoffDate
				,l.LoanType,alc.LoanTypeDescription, l.LoanDelqDays, LoanBalance
		) A
		order by AccountNumber,LoanID,ProcessDate
		
		
								Drop table if exists #LoanAccount
								select 
								   [ProcessDate],[Process date],[Process_date],Quarters,MonthBack_seg,[PARENTACCOUNT],UNID
								  ,[ID],TYPE,OPENdate,Open_date,closedate,Close_date,Charge_off_date,CHARGEOFFDATE,Loan_MOB,Loan_Term,Month_to_Maturity
								  ,[PARTIALPAYMENT],[PAYMENT],[LASTPAYMENTDATE],DUEDATE,[PAYMENTCOUNT],[INTERESTRATE],day(LASTPAYMENTDATE) Payment_day,abs(day(DUEDATE)-day(LASTPAYMENTDATE)) Diff_Due_Payment
								  ,[DQNOTICENUMBER],[DQNOTICEDATE],[DQCARDDATE],[LATECHARGETYPE],[LATECHARGEACCRUED],[LATECHARGEUNPAID],[LATECHARGEYTD]
								  ,case when (latechargeYTD-(lag(latechargeYTD,1,0) over (partition by UNID order by UNID,[Process date])))<0 or
									[Process date]='2017-08-31' then 0 
									else (latechargeYTD-(lag(latechargeYTD,1,0) over (partition by UNID order by UNID,[Process date]))) end Latechargefee
								  ,[LATECHARGELASTYEAR]
								  ,[BALANCE],[ORIGINALBALANCE],[CREDITLIMIT],[PRINCIPALYTD],[PRINCIPALLASTYEAR],[STATEMENTDATE],[DESCRIPTION],[NSFMONTHTODATE],FEEBILLINGDATE
								  ,FEEBILLINGAMOUNT,[FEEOLDBALANCE]
								  ,[FEENEWBALANCE],[FEECOUNT1],[FEECOUNT2],[FEECOUNT3],[FEECOUNT4],[MATURITYDATE],[LATECHARGEDATE],[BRANCH],[RISKRATE],[CREDITSCORE]
								  ,b.LoanCategory2,b.LoanCategory3,b.LoanCategory4
								  ,case when LoanCategory2='Vehicle' then 'Vehicle'
								   when LoanCategory2='Personal' and LoanCategory3='Secured' then 'Personal_Secured'
								   when LoanCategory2='Personal' and LoanCategory3='Unsecured' then 'Personal_Unsecured'
								   when LoanCategory2='Real Estate' and LoanCategory4 like 'HEL%' then 'HELOC' 
								   when LoanCategory2='Real Estate' then 'Real_Estate'
								   when LoanCategory2='Commercial Loans' then 'Commercial Loans'
								   when LoanCategory2='Construction And Development' then 'Construction And Development'
								   when LoanTypeDescription like '%AUTO (OL)' then 'Vehicle' else LoanTypeDescription end Loan_Categories
								  
								into #LoanAccount
								from
											(
											select *,CONCAT(PARENTACCOUNT,ID) UNID
											,case when [Process date] between EOMONTH(dateadd(month,-3,@staticpooldate)) and EOMONTH(dateadd(month,-1,@staticpooldate)) then 'Q1'
											when [Process date] between EOMONTH(dateadd(month,-6,@staticpooldate)) and EOMONTH(dateadd(month,-4,@staticpooldate)) then 'Q2'
											when [Process date] between EOMONTH(dateadd(month,-9,@staticpooldate)) and EOMONTH(dateadd(month,-7,@staticpooldate)) then 'Q3'
											when [Process date] between EOMONTH(dateadd(month,-12,@staticpooldate)) and EOMONTH(dateadd(month,-10,@staticpooldate)) then 'Q4'
											 when [Process date]=@staticpooldate then 'Staticpool' end Quarters 
											  ,case when Process_Date in (201909) then 'M4'
												 when Process_Date in (201910) then 'M3'
												 when Process_Date in (201911) then 'M2'
												 when Process_Date in (201912) then 'M1'
												 end MonthBack_seg 
											,case when opendate=closedate then 0 else 1 end Flag
											,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date 
											then 1 else 0 end Open_Flag
											,DATEDIFF(month,OPENDATE,@staticpooldate) Loan_MOB	-- add the @Staticpooldate
											,DATEDIFF(month,OPENDATE,MATURITYDATE) Loan_Term
											,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
												from 
													(
													select *
													,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
													else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
													,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
													else concat(year(opendate),month(opendate)) end Open_date
													,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
													else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
													,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
													,left(ProcessDate,6) Process_date
													from ARCUSYM000..LOAN
													) H
											 where  ORIGINALDATE is not null and OpenDate is not null 
											 --and [Process date]=@staticpooldate		-- Later add -12 month the @staticpooldate date here 
											 and MATURITYDATE>@staticpooldate	-- add 3 month in currrent date
											 and ProcessDate in (select MAX_ProcessDate from #Processdate)
											) A
									left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
									on b.loantype=a.TYPE
									where Flag=1 and Open_Flag=1
									and parentaccount in (select PARENTACCOUNT from #LoanStatic group by PARENTACCOUNT)
									order by PARENTACCOUNT,ProcessDate
								
		
		
		 drop table if exists #LoanAccountMerg
		 select a.PARENTACCOUNT
		,d.Cycle1,d.Cycle2
		into #LoanAccountMerg
		from #LoanAccount A
		left join #Delinquency D
		on a.UNID=CONCAT(d.AccountNumber,d.loanid) and a.Process_date=d.Process_date
		
		drop table if exists #Max_loan
		select a.PARENTACCOUNT,isnull(max(Cycle1),0) Cycle1,isnull(max(Cycle2),0) Cycle2,[Current Balance],[Orignal Balance]
		into #Max_loan
		from #LoanAccountMerg A
		left join (select PARENTACCOUNT,sum(case when Quarters='staticpool' then balance else 0 end) [Current Balance]
		,sum(case when Quarters='staticpool' then ORIGINALBALANCE else 0 end) [Orignal Balance]
		from #LoanAccount group by Parentaccount) B on a.PARENTACCOUNT=b.PARENTACCOUNT
		group by a.PARENTACCOUNT,[Current Balance],[Orignal Balance]
		order by a.PARENTACCOUNT
		
		
		-- Summarizing Loan Talbes 
		drop table if exists #LoanInfoSummary
		select distinct a.PARENTACCOUNT,cast(h.FICO_Staticpool as int) FICO_Staticpool,a.Direct_indirect
		,g.Cycle1,g.Cycle2,i.Q1 [FICO Q1] ,i.Q2 [FICO Q2],i.Q3 [FICO Q3],i.Q4[FICO Q4]
		,g.[Current Balance],g.[Orignal Balance]
		into #LoanInfoSummary
		from #LoanStatic a
		left join #Max_loan g on a.PARENTACCOUNT=g.PARENTACCOUNT
		left join #FinalName h on a.PARENTACCOUNT=h.PARENTACCOUNT
		left join #QuarterlyFICO I on a.PARENTACCOUNT=i.PARENTACCOUNT
		
			Drop table if exists #FICODRIFT
			select PARENTACCOUNT,case when (FICO_Staticpool is null or [FICO Q4] is null) then null else  FICO_Staticpool-[FICO Q4] end as Static_FICO_Q4
			,case when (FICO_Staticpool is null or [FICO Q3] is null) then null else FICO_Staticpool-[FICO Q3] end as Static_FICO_Q3
			,case when (FICO_Staticpool is null or [FICO Q3] is null) then null else FICO_Staticpool-[FICO Q2] end as Static_FICO_Q2
			,case when (FICO_Staticpool is null or [FICO Q3] is null) then null else FICO_Staticpool-[FICO Q1] end as Static_FICO_Q1
			,case when ([FICO Q4] is null or [FICO Q3] is null) then null else [FICO Q4]-[FICO Q3] end as Q1_FICO_Q3
			,case when ([FICO Q4] is null or [FICO Q2] is null) then null else [FICO Q4]-[FICO Q2] end as Q1_FICO_Q2 
			into #FICODRIFT
			from 
				(select PARENTACCOUNT,cast([FICO Q1] as int) [FICO Q1],cast([FICO Q2] as INT) [FICO Q2],cast([FICO Q3] as int) [FICO Q3]
				,cast([FICO Q4] as int) [FICO Q4],cast(FICO_Staticpool as INT) FICO_Staticpool
				from #LoanInfoSummary) a
				
				
		drop table if exists #FICODRIFTbackup
		select PARENTACCOUNT
		,[Static_FICO_Q1],[Static_FICO_Q2],[Static_FICO_Q3],[Static_FICO_Q4],[Q1_FICO_Q2],[Q1_FICO_Q3]
		into #FICODRIFTbackup
		 from #FICODRIFT group by PARENTACCOUNT,[Static_FICO_Q1],[Static_FICO_Q2],[Static_FICO_Q3],[Static_FICO_Q4],[Q1_FICO_Q2],[Q1_FICO_Q3]

		 drop table if exists #tempauto 
			  --create table 
			  select @staticpooldate [Extractdate],a.[PARENTACCOUNT],a.[FICO_Staticpool],Static_FICO_Q1,[Cycle1],[Cycle2],[Static_FICO_Q2]
			  ,[Current Balance],[Orignal Balance]
			  ,case when [Cycle2]>0 and [Static_FICO_Q2]<=0 then '1. Severe'
			  when [Cycle2]>0 and [Static_FICO_Q2] is null then '1. Severe'
			  when [Cycle2]>0 and [Static_FICO_Q2]>0 and a.[FICO_Staticpool]<=561 then '2. High'
			  when [Cycle2]>0 and [Static_FICO_Q2]>0 and a.[FICO_Staticpool]>561 then '3. Moderate'
			   when [Cycle2]<=0 and a.[FICO_Staticpool] is null then '4. Low'
			  when [Cycle2]<=0 and a.[FICO_Staticpool]<=561 and [Cycle1]<=0 then '4. Low'
			  when [Cycle2]<=0 and a.[FICO_Staticpool]<=561 and [Cycle1]>0 then '3. Moderate'
			  when [Cycle2]<=0 and a.[FICO_Staticpool] between 562 and 628 and [Cycle1]<=0 then '4. Low'
			  when [Cycle2]<=0 and a.[FICO_Staticpool] between 562 and 628  and [Cycle1]>0 then '3. Moderate'
			  when [Cycle2]<=0 and a.[FICO_Staticpool] >= 629  then '4. Low' end Segment
			  ,E.FIRST,E.LAST,E.SSN,E.BIRTHDATE,e.CITY,e.STREET,e.STATE,e.ZIPCODE,datediff(year,e.birthdate,getdate()) AGE,Direct_indirect
			  into #tempauto
			 from #LoanInfoSummary a 
			 left join #FICODRIFTbackup d on a.parentaccount=d.parentaccount
			 left join #FinalName E on a.PARENTACCOUNT=E.PARENTACCOUNT
			 where e.PARENTACCOUNT is not null
			 
			 
drop table if exists #temp
Select COUNT(*) as cnt into #temp   from #tempauto

 drop table if exists #temp2
 Select row_number() over (order by [Current Balance]) as srno,[Current Balance] into #temp2 from #tempauto order by 1 
 


  Declare @f as int

Set @f = (Select [Current Balance] from #temp2 where srno in ( select round((cnt+1)*0.99,0)  from #temp))
 
drop table if exists #tempauto2 
Select *,case when [Current Balance] > @f then @f else [Current Balance] end as newcurrentbalance into #tempauto2  from #tempauto


declare @z as float
Set @z = (select MAX(newcurrentbalance) from #tempauto2 )

declare @y as float
Set @y = (select Min(newcurrentbalance) from #tempauto2 )

Drop table if exists #tempauto3

Select * ,
((newCurrentBalance - @y)/(@z-@y))*40 as Scaler
,(1-((@z-newCurrentBalance)/@z))*40 as Scaler2
into #tempauto3
from #tempauto2


 drop table if exists analytics..PDQAutoloantriggerdata
Select * ,
Case when Segment = '1. Severe' then Round(60 + Scaler,2)
  when Segment = '2. High' then Round(50 + Scaler,2)
  when Segment = '3. Moderate' then Round(25 + Scaler,2)
  when Segment = '4. Low' then Round(10 +Scaler,2)
   end as final_score
 into analytics..PDQAutoloantriggerdata
from #tempauto3
order by final_score Desc,[Current Balance] DESC

end


			 
		
	Alter procedure dbo.PDQTriggerPersonalLoanTargetlist
	as 
	begin
	declare @staticpooldate as date 
	 set @staticpooldate = (Select MAX(convert(date,convert(varchar(50),processdate))) from ARCUSYM000..LOAN) 
	 
	 Select @staticpooldate
	 --Case when EOMONTH(Getdate()) = GETDATE() then GETDATE() else EOMonth(DATEADD(mm,-1,getdate())) end 
	  
	  --Select @staticpooldate
	-- Select EOMONTH(getdate()-1)

	 

		 drop table if exists #groupproducttype_Deposits0
		 		drop table if exists #LoanStatic
		 Drop table if exists #Processdate
		Drop table if exists #QFICO
		drop table if exists #QuarterlyFICO
		Drop table if exists #NAME
		drop table if exists #duplicate
		drop table if exists #NAME1
		drop table if exists #temp15
		drop table if exists #FinalName
		Drop table if exists #LoanAccount
		drop table if exists #LOAN_TRANSACITON_DATA
		drop table if exists #LoanAccountMerg
		drop table if exists ##Max_loan
		Drop table if exists #Vehicle
		Drop table if exists #HELOC
		Drop table if exists #Personal_Secured
		Drop table if exists #Personal_Unsecured
		Drop table if exists #Real_Estate
		drop table if exists #loandata
		drop table if exists #SavingsAccount
		Drop table if exists #Saving_transaction
		drop table if exists #SavingAccountMerg
		drop table if exists #Savings
		drop table if exists #Checking
		drop table if exists #Certificates
		drop table if exists #MoneyMarket
		drop table if exists #savingmerg
		drop table if exists #MergSaving
		drop table if exists #FICDRIFT
		Drop table if exists #FICodrift		
		drop table if exists #j

		select *
		,case when ProductName like '%money%'  or ProductName like '% MM %' then 'MoneyMarket'
		when ProductName='Youth Savings' and ApplicationDescription='Certificates' then 'Savings'
		when ProductCode=0 and ApplicationDescription='Certificates' then 'Savings'
		when ProductName='40 Month CD' and ApplicationDescription='Certificates' then 'Checking'
		when ProductName='Certificate' and ApplicationDescription='Certificates' then 'Checking' 
		when ProductName='Public Funds' and ApplicationDescription='Certificates' then 'Certificates'  
		 else ApplicationDescription end Product_Group_wise
		into #groupproducttype_Deposits0
		from
		(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName
		,ApplicationDescription,ApplicationTableName
		 from [AE_EDW].[tempods].[S_CRMProductType] a
		left join [AE_EDW].[tempods].[S_CRMApplicationType] b
		on a.ApplicationTypeID=b.ApplicationTypeID
		where ApplicationDescription is not null
		and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a
		order by ProductCode

	select 
	[ProcessDate],[Process date],[Process_date],[PARENTACCOUNT],concat(PARENTACCOUNT,ID) UNID,[ID]
	,TYPE,OPENdate,Open_date,closedate,Close_date,Charge_off_date,CHARGEOFFDATE,MOB,Loan_Term,Month_to_Maturity
	,[PARTIALPAYMENT],[PAYMENT],[LASTPAYMENTDATE],DUEDATE,[PAYMENTCOUNT],[INTERESTRATE]
	,[DQNOTICENUMBER],[DQNOTICEDATE],[DQCARDDATE],[LATECHARGETYPE],[LATECHARGEACCRUED],[LATECHARGEUNPAID],[LATECHARGEYTD],[LATECHARGELASTYEAR]
	,[BALANCE],[ORIGINALBALANCE],[CREDITLIMIT],[PRINCIPALYTD],[PRINCIPALLASTYEAR],[STATEMENTDATE],[DESCRIPTION],[NSFMONTHTODATE],FEEBILLINGDATE
	,FEEBILLINGAMOUNT,[FEEOLDBALANCE],[FEENEWBALANCE],[FEECOUNT1],[FEECOUNT2],[FEECOUNT3],[FEECOUNT4],[MATURITYDATE],[LATECHARGEDATE],[BRANCH],[RISKRATE],[CREDITSCORE]
	,b.LoanCategory2,b.LoanCategory3,b.LoanCategory4
	,case when LoanCategory2='Vehicle' then 'Vehicle'
	when LoanCategory2='Personal' and LoanCategory3='Secured' then 'Personal_Secured'
	when LoanCategory2='Personal' and LoanCategory3='Unsecured' then 'Personal_Unsecured'
	when LoanCategory2='Real Estate' and LoanCategory4 like 'HEL%' then 'HELOC' 
	when LoanCategory2='Real Estate' then 'Real Estate'
	when LoanCategory2='Commercial Loans' then 'Commercial Loans'
	when LoanCategory2='Construction And Development' then 'Construction And Development'
	when LoanTypeDescription like '%AUTO (OL)' then 'Vehicle' else LoanTypeDescription end Loan_Categories
	into #LoanStatic
								from
											(
											select *
											,CONCAT(PARENTACCOUNT,ID) UNID
											,case when opendate=closedate then 0 else 1 end Flag
											,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date 
											then 1 else 0 end Open_Flag
											,DATEDIFF(month,OPENDATE,@staticpooldate) MOB	-- add the @Staticpooldate
											,DATEDIFF(month,OPENDATE,MATURITYDATE) Loan_Term
											,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
												from 
													(select *
													,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
													else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
													,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
													else concat(year(opendate),month(opendate)) end Open_date
													,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
													else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
													,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
													,left(ProcessDate,6) Process_date
													from ARCUSYM000..LOAN 
													--where (CHARGEOFFDATE>='2020-01-31' or CHARGEOFFDATE is null ) 
													) H
											 where  ORIGINALDATE is not null and OpenDate is not null 
											 and CLOSEDATE is null and CHARGEOFFDATE is null
											 and [Process date]= @staticpooldate		-- Later give the @staticpooldate date here 
											 and MATURITYDATE> @staticpooldate	-- add 3 month in currrent date
											) A
									left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
									on b.loantype=a.TYPE
									where Flag=1 and Open_Flag=1 and LoanCategory2='Personal'
									order by PARENTACCOUNT,ProcessDate

					
	
		select 
		Process_date,max(ProcessDate) MAX_ProcessDate 
		into #Processdate
		from
			(
			select ProcessDate,left(ProcessDate,6) Process_date
			,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
			from ARCUSYM000..NAME group by ProcessDate
			) A 
			where [Process date] between dateadd(month,-12,@staticpooldate) and @staticpooldate
			group by Process_Date
			order by Process_Date
		
		DROP TABLE IF EXISTS #TMPName
		
SELECT distinct N.PARENTACCOUNT,N.SSN,N.FIRST, N.LAST, N.BIRTHDATE, n.userchar3 FICO_Staticpool,STREET,CITY,STATE,ZIPCODE INTO #TMPName
FROM
	(
	SELECT SSN,PARENTACCOUNT, FIRST, LAST, BIRTHDATE,n.USERCHAR3,STREET,CITY,STATE,ZIPCODE
	FROM ARCUSYM000.dbo.NAME N
	LEFT JOIN ARCUSYM000.dbo.ACCOUNT A
		ON N.PARENTACCOUNT = A.ACCOUNTNUMBER
		AND N.ProcessDate = A.ProcessDate
	WHERE N.TYPE = 0
		AND N.ProcessDate =concat(left(@staticpooldate ,4),right(left(@staticpooldate ,7),2),right(@staticpooldate ,2))--(SELECT MAX(ProcessDate) FROM ARCUSYM000.dbo.IRS)
		AND N.LAST <> 'NEW MEMBER'
		AND N.BIRTHDATE is not null
		AND N.SSNTYPE in (0,9)
		AND N.NAMEFORMAT = 0
		AND A.CLOSEDATE is null
		--AND A.type in (0,70)
	) N where PARENTACCOUNT in ( Select distinct PARENTACCOUNT from #LoanStatic)

	

	select SSN,count(PARENTACCOUNT) CNT 
		into #duplicate
		from #TMPName
		group by SSN
		having count(PARENTACCOUNT)>1
		
		
		select a.SSN,PARENTACCOUNT
		into #NAME1
		from #TMPName A
		left join #duplicate b
		on a.SSN=b.SSN
		where b.SSN is null
		
		select SSN,AccountNumber as parentaccount
		into #temp15
		from AE_EDW..D_Member
		where SSN in
		(select SSN from #duplicate)

		select a.*,case when  b.FICO_Staticpool >1000 then Null else b.FICO_Staticpool end FICO_Staticpool,FIRST,LAST,STREET,CITY,STATE,ZIPCODE,BIRTHDATE 
		into #FinalName from
				(select *
				from #NAME1
				union 
				select * from #temp15) a
				left join #TMPName b
				on a.PARENTACCOUNT=b.PARENTACCOUNT

	
		select [Process date],case when [Process date] between dateadd(month,-3,@staticpooldate) and Eomonth(DATEADD(month,-1,@staticpooldate)) then 'Q1'
				when [Process date] between Eomonth(dateadd(month,-6,@staticpooldate))and   EOmonth(DATEADD(month,-4,@staticpooldate)) then 'Q2'
				when [Process date] between Eomonth(dateadd(month,-9,@staticpooldate))and   EOmonth(DATEADD(month,-7,@staticpooldate)) then 'Q3'
				when [Process date] between Eomonth(dateadd(month,-12,@staticpooldate)) and EOmonth(DATEADD(month,-10,@staticpooldate)) then 'Q4'
				end as Quarterly,a.PARENTACCOUNT,SSN,case when  a.USERCHAR3 >1000 then Null else a.USERCHAR3 end FICO
				into #QFICO
				from 
						(select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date] 
						from ARCUSYM000..NAME) a
				left join ARCUSYM000..SAVINGS b
						on a.PARENTACCOUNT=b.PARENTACCOUNT
						and a.ProcessDate=b.ProcessDate
						where a.TYPE=0
						and a.ProcessDate in (select MAX_ProcessDate from #Processdate where right(left(MAX_ProcessDate,6),2) in (3,6,9,12) )
						--and a.Process_date=dateadd(year,-1,@staticpooldate)
						and b.SHARECODE=0 and b.ORIGINALDEPOSITDATE is not null
						and b.CLOSEDATE is null 
						and b.CHARGEOFFDATE is null
						and a.PARENTACCOUNT in (select PARENTACCOUNT from #FinalName)
						group by [Process date],a.PARENTACCOUNT,SSN,a.USERCHAR3
						order by  a.PARENTACCOUNT
						
		
		select 
		PARENTACCOUNT,max([Q1])[Q1],max([Q2])[Q2] ,max([Q3])[Q3] ,max([Q4])[Q4] --,max([2020Q-1]) [2020Q-1],Max([2020Q-2]) [2020Q-2]
		Into #QuarterlyFICO
		from	(
			select * from #QFICO
			) S
		Pivot
		(
		max(FICO) 
		for Quarterly in ([Q1],[Q2],[Q3],[Q4])
		--(select Quarterly from #QFICO group by Quarterly)
		) as PIVOT_table
		group by PARENTACCOUNt
		order by PARENTACCOUNT
		
																		
							select 
								   [ProcessDate],[Process date],[Process_date],Quarters,MonthBack_seg
								  ,[PARENTACCOUNT],UNID
								  ,[ID],TYPE,OPENdate,Open_date,closedate,Close_date,Charge_off_date,CHARGEOFFDATE,Loan_MOB,Loan_Term,Month_to_Maturity
								  ,[PARTIALPAYMENT],[PAYMENT],[LASTPAYMENTDATE],DUEDATE,[PAYMENTCOUNT],[INTERESTRATE],day(LASTPAYMENTDATE) Payment_day,abs(day(DUEDATE)-day(LASTPAYMENTDATE)) Diff_Due_Payment
								  ,[DQNOTICENUMBER],[DQNOTICEDATE],[DQCARDDATE],[LATECHARGETYPE],[LATECHARGEACCRUED],[LATECHARGEUNPAID],[LATECHARGEYTD]
								  ,case when (latechargeYTD-(lag(latechargeYTD,1,0) over (partition by UNID order by UNID,[Process date])))<0 or
									[Process date]='2017-08-31' then 0  -- jay
									else (latechargeYTD-(lag(latechargeYTD,1,0) over (partition by UNID order by UNID,[Process date]))) end Latechargefee
								  ,[LATECHARGELASTYEAR]
								  ,[BALANCE],[ORIGINALBALANCE],[CREDITLIMIT],[PRINCIPALYTD],[PRINCIPALLASTYEAR],[STATEMENTDATE],[DESCRIPTION],[NSFMONTHTODATE],FEEBILLINGDATE
								  ,FEEBILLINGAMOUNT,[FEEOLDBALANCE]
								  ,[FEENEWBALANCE],[FEECOUNT1],[FEECOUNT2],[FEECOUNT3],[FEECOUNT4],[MATURITYDATE],[LATECHARGEDATE],[BRANCH],[RISKRATE],[CREDITSCORE]
								  ,b.LoanCategory2,b.LoanCategory3,b.LoanCategory4
								  ,case when LoanCategory2='Vehicle' then 'Vehicle'
								   when LoanCategory2='Personal' and LoanCategory3='Secured' then 'Personal_Secured'
								   when LoanCategory2='Personal' and LoanCategory3='Unsecured' then 'Personal_Unsecured'
								   when LoanCategory2='Real Estate' and LoanCategory4 like 'HEL%' then 'HELOC' 
								   when LoanCategory2='Real Estate' then 'Real_Estate'
								   when LoanCategory2='Commercial Loans' then 'Commercial Loans'
								   when LoanCategory2='Construction And Development' then 'Construction And Development'
								   when LoanTypeDescription like '%AUTO (OL)' then 'Vehicle' else LoanTypeDescription end Loan_Categories
								  --,case when (OVERDRAFTFEEYTD-(lag(OVERDRAFTFEEYTD,1,0) over (partition by UNID order by UNID,date)))<0 or
								  --date<='2017-01-31' then 0 
								  --else (OVERDRAFTFEEYTD-(lag(OVERDRAFTFEEYTD,1,0) over (partition by UNID order by UNID,date))) end Overdraftfee
								into #LoanAccount
								from
											(
											select *,CONCAT(PARENTACCOUNT,ID) UNID
											,case when[Process date] between dateadd(month,-3,@staticpooldate) and DATEADD(month,-1,@staticpooldate) then 'Q1'
													when [Process date] between dateadd(month,-6,@staticpooldate) and DATEADD(month,-4,@staticpooldate) then 'Q2'
													when [Process date] between dateadd(month,-9,@staticpooldate) and DATEADD(month,-7,@staticpooldate) then 'Q3'
													when [Process date] between dateadd(month,-12,@staticpooldate) and DATEADD(month,-10,@staticpooldate) then 'Q4'
													when month([Process date] ) in (MONTH(@staticpooldate)) then 'Staticpool'
											  end Quarters 
											  ,case when month([Process date]) in (month((dateadd(month,-4,@staticpooldate)))) then 'M4'
												 when month([Process date] ) in (month((dateadd(month,-3,@staticpooldate)))) then 'M3'
												 when month([Process date] ) in (month((dateadd(month,-2,@staticpooldate)))) then 'M2'
												 when month([Process date] ) in (month((dateadd(month,-1,@staticpooldate)))) then 'M1'
												 end MonthBack_seg 
											,case when opendate=closedate then 0 else 1 end Flag
											,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date 
											then 1 else 0 end Open_Flag
											,DATEDIFF(month,OPENDATE,@staticpooldate) Loan_MOB	-- add the @Staticpooldate
											,DATEDIFF(month,OPENDATE,MATURITYDATE) Loan_Term
											,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
												from 
													(
													select *
													,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
													else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
													,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
													else concat(year(opendate),month(opendate)) end Open_date
													,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
													else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
													,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
													,left(ProcessDate,6) Process_date
													from ARCUSYM000..LOAN
													--where (CHARGEOFFDATE>='2020-01-31' or CHARGEOFFDATE is null ) 
													) H
											 where  ORIGINALDATE is not null and OpenDate is not null 
											 --and [Process date]='2020-01-31'		-- Later add -12 month the @staticpooldate date here 
											 and MATURITYDATE>@staticpooldate	-- add 3 month in currrent date
											 and ProcessDate in (select MAX_ProcessDate from #Processdate)
											) A
									left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
									on b.loantype=a.TYPE
									where Flag=1 and Open_Flag=1
									and UNID in (select UNID from #LoanStatic group by UNID)
									order by PARENTACCOUNT,ProcessDate
	 


		select b.SSN,a.PARENTACCOUNT, case when isnumeric(b.FICO_Staticpool) = 0 then NUll
		when b.FICO_Staticpool > 1000 then NULL
		else b.FICO_Staticpool
		end FICO_Staticpool
		into ##Max_loan 
		from #LoanAccount a left join #FinalName b on a.PARENTACCOUNT=b.PARENTACCOUNT where SSN is not null
		group by a.PARENTACCOUNT,b.SSN,b.FICO_Staticpool order by b.FICO_Staticpool
		
		
		select parentaccount,count(distinct UNID) [# Personal_Unsecured loan]
		,SUM(ISNULL(Case when Quarters='Q1' then PARTIALPAYMENT else 0 end,0))  PARTIALPAYMENT_Personal_Unsecured_Q1	,SUM(ISNULL(Case when Quarters='Q2' then PARTIALPAYMENT else 0 end,0))  PARTIALPAYMENT_Personal_Unsecured_Q2	,SUM(ISNULL(Case when Quarters='Q3' then PARTIALPAYMENT else 0 end,0))  PARTIALPAYMENT_Personal_Unsecured_Q3	,SUM(ISNULL(Case when Quarters='Q4' then PARTIALPAYMENT else 0 end,0))  PARTIALPAYMENT_Personal_Unsecured_Q4
		,SUM(ISNULL(Case when Quarters='Q1' then PAYMENT else 0 end,0))  PAYMENT_Personal_Unsecured_Q1	,SUM(ISNULL(Case when Quarters='Q2' then PAYMENT else 0 end,0))  PAYMENT_Personal_Unsecured_Q2	,SUM(ISNULL(Case when Quarters='Q3' then PAYMENT else 0 end,0))  PAYMENT_Personal_Unsecured_Q3	,SUM(ISNULL(Case when Quarters='Q4' then PAYMENT else 0 end,0))  PAYMENT_Personal_Unsecured_Q4
		,SUM(ISNULL(Case when Quarters='Q1' then Latechargefee else 0 end,0))  Latechargefee_Personal_Unsecured_Q1	,SUM(ISNULL(Case when Quarters='Q2' then Latechargefee else 0 end,0))  Latechargefee_Personal_Unsecured_Q2	,SUM(ISNULL(Case when Quarters='Q3' then Latechargefee else 0 end,0))  Latechargefee_Personal_Unsecured_Q3	,SUM(ISNULL(Case when Quarters='Q4' then Latechargefee else 0 end,0))  Latechargefee_Personal_Unsecured_Q4
		,AVG(ISNULL(Case when Quarters='Q1' then BALANCE else 0 end,0))  AVG_BALANCE_Personal_Unsecured_Q1	,AVG(ISNULL(Case when Quarters='Q2' then BALANCE else 0 end,0))  AVG_BALANCE_Personal_Unsecured_Q2	,AVG(ISNULL(Case when Quarters='Q3' then BALANCE else 0 end,0))  AVG_BALANCE_Personal_Unsecured_Q3	,AVG(ISNULL(Case when Quarters='Q4' then BALANCE else 0 end,0))  AVG_BALANCE_Personal_Unsecured_Q4
		into #Personal_Unsecured
		from #LoanAccount 
		where Loan_Categories='Personal_Unsecured' 
		group by parentaccount
		
		select PARENTACCOUNT 
		into #loanstatic2 
		from #LoanStatic group by PARENTACCOUNT

		-- Summarizing Loan Talbes 
		select a.PARENTACCOUNT,case when isnumeric(h.FICO_Staticpool) = 0 then NUll
		when h.FICO_Staticpool > 1000 then NUll
		else h.FICO_Staticpool
		end FICO_Staticpool
		,i.[Q1],I.[Q2],i.[Q3],i.[Q4]	
		,e.[# Personal_Unsecured loan]
		,e.[AVG_BALANCE_Personal_Unsecured_Q1]	
		,h.SSN,FIRST,LAST,STREET,CITY,STATE,ZIPCODE,BIRTHDATE
		into #loandata
		from #loanstatic2 a
		left join #Personal_Unsecured e on a.PARENTACCOUNT=e.PARENTACCOUNT
		left join ##Max_loan g on a.PARENTACCOUNT=g.PARENTACCOUNT   
		left join #FinalName h on a.PARENTACCOUNT=h.PARENTACCOUNT
		left join #QuarterlyFICO I on a.PARENTACCOUNT=i.PARENTACCOUNT
		
	
		select 
		ProcessDate,Process_Date,[PARENTACCOUNT],id,UNID,type,opendate,MATURITYDATE,CLOSEDATE,Close_date,CHARGEOFFDATE_v,CHARGEOFFAMOUNT_v
		,BALANCE,Product_Group_wise,LASTDIVAMOUNT,[# Chargeoff Deposit],Close_flag,Chargeoff_flag,Quarters,MonthBack_seg,COURTESYFEEMTD,NSFFEEMTD
		,case when (Overdraftfeeytd-(lag(Overdraftfeeytd,1,0) over (partition by UNID order by UNID,[Process date])))<0 or
									[Process date]='2017-08-31' then 0 -- Jay
									else (Overdraftfeeytd-(lag(Overdraftfeeytd,1,0) over (partition by UNID order by UNID,[Process date]))) end Overdraftfee
		into #SavingsAccount
		from
				(
						select 
						ProcessDate,Process_Date,[Process Date],[PARENTACCOUNT],id,CONCAT(PARENTACCOUNT,ID) UNID,type,opendate,MATURITYDATE,CLOSEDATE,Close_date,CHARGEOFFDATE_v,CHARGEOFFAMOUNT_v
						,case when closedate is null and chargeoffdate is null then BALANCE else 0 end BALANCE,e.Product_Group_wise
						,LASTDIVAMOUNT,Overdraftfeeytd,COURTESYFEEMTD,NSFFEEMTD
						,case when CHARGEOFFAMOUNT_v>0 then 1 else 0 end [# Chargeoff Deposit]
						,case when Close_date=Process_Date then 1 else 0 end Close_flag
						,case when CHARGEOFFDATE_v=Process_Date then 1 else 0 end Chargeoff_flag
						,case when Product_Group_wise='Certificates' and BALANCE=0 then 0 else 1 end carryforward_flag
						,case when[Process date] between dateadd(month,-3,@staticpooldate) and DATEADD(month,-1,@staticpooldate) then 'Q1'
													when [Process date] between dateadd(month,-6,@staticpooldate) and DATEADD(month,-4,@staticpooldate) then 'Q2'
													when [Process date] between dateadd(month,-9,@staticpooldate) and DATEADD(month,-7,@staticpooldate) then 'Q3'
													when [Process date] between dateadd(month,-12,@staticpooldate) and DATEADD(month,-10,@staticpooldate) then 'Q4'
													when month([Process date] ) in (MONTH(@staticpooldate)) then 'Staticpool'
											  end Quarters 
											  ,case when month([Process date]) in (month((dateadd(month,-4,@staticpooldate)))) then 'M4'
												 when month([Process date] ) in (month((dateadd(month,-3,@staticpooldate)))) then 'M3'
												 when month([Process date] ) in (month((dateadd(month,-2,@staticpooldate)))) then 'M2'
												 when month([Process date] ) in (month((dateadd(month,-1,@staticpooldate)))) then 'M1'
												 end MonthBack_seg 
						
						from 
								(
										select *,case when [EOM_Process Date]=[Process Date] then 1 else 0 end EOM_flag 
										,case when (closedate is null and CHARGEOFFDATE is null) or Process_Date=close_date 
										or Process_Date=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
										from
											(select a.*,EOMONTH([Process Date]) [EOM_Process Date]
											,case when OPENDATE=CLOSEDATE then 0 else 1 end Funded_loan_flag
											,case when Process_Date=CHARGEOFFDATE_v then CHARGEOFFAMOUNT else 0 end CHARGEOFFAMOUNT_v
											,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
											else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
											 from 
												 ( select * ,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
												 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v,left(ProcessDate,6) Process_Date
												,datefromparts(left(processdate,4),right(left(processdate,6),2),right(processdate,2)) [Process Date] from arcusym000..SAVINGS
												--where (chargeoffdate is null or chargeoffdate>='2020-01-01')
												) a
												where  ProcessDate in (select MAX_ProcessDate from #processdate)
												and PARENTACCOUNT in (select PARENTACCOUNT from #LoanStatic)
											) F
								 ) aa
						left join #groupproducttype_Deposits0 E
						on e.ProductCode=aa.TYPE
						 where Funded_loan_flag=1 and Open_Flag=1
						group by ProcessDate,[Process Date],Process_Date,[PARENTACCOUNT],id,type,CLOSEDATE,CHARGEOFFDATE_v,CHARGEOFFAMOUNT_v,LASTDIVAMOUNT
						,BALANCE,e.Product_Group_wise,opendate,MATURITYDATE,chargeoffdate,Close_date,Overdraftfeeytd,COURTESYFEEMTD,NSFFEEMTD
				) A
				order by PARENTACCOUNT,id,ProcessDate
					
			select PARENTACCOUNT,PARENTID,UNID
			,count(*) Transaction_COUNT
			,sum(BALANCECHANGE) Transaction_amount
			,AVG(BALANCECHANGE) AVG_BALANCECHANGE
			,sum(Deposited_amount) Deposited_amount
			--,sum(Deposited_count) Deposited_count
			--,sum(withdrawl_amount) withdrawal_amount
			--,sum(withdrawl_count) withdrawal_count
			,sum([$ Deposit ACH]) [$ Deposit ACH]--,sum([# Deposit ACH]) [# Deposit ACH]
			--,sum([$ Deposit Home Banking]) [$ Deposit Home Banking],sum([# Deposit Home Banking]) [# Deposit Home Banking]
			--,sum([$ Deposit Check]) [$ Deposit Check],sum([# Deposit Check]) [# Deposit Check],sum([$ Deposit Payroll]) [$ Deposit Payroll],sum([# Deposit Payroll]) [# Deposit Payroll]
			,EFFECTIVEDATE_v1
		    into #Saving_transaction
			from 
					(
					SELECT  [PARENTACCOUNT]
					  ,[PARENTID]
					  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
					  ,[SUBACTIONCODE]
					  ,[SEQUENCENUMBER]
					  ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
					  ,[DESCRIPTION]
					  ,[ACTIONCODE]
					  ,[SOURCECODE]
					  ,[BALANCECHANGE]
					  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
					  ,case when SOURCECODE='E' and ACTIONCODE='D' then BALANCECHANGE else 0 end [$ Deposit ACH]
					  ,[INTEREST]
					  ,[NEWBALANCE]
					  ,[FEEAMOUNT]
					  ,[ESCROWAMOUNT]
					  ,[LASTTRANDATE]
					 ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
					  else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
					  FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
					  WHERE PARENTACCOUNT IN (SELECT PARENTACCOUNT FROM #LoanStatic)
					  AND ACTIONCODE!='C'
					) A
			where EFFECTIVEDATE_v1 in (select Process_date from #Processdate)
			--between left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6) and left(convert(varchar,@staticpooldate,112),6)
			and PARENTACCOUNT in (select PARENTACCOUNT from #LoanStatic)
			group by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1
			order by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1

			

			
			select 
			a.*
			,isnull(b.Transaction_COUNT,0) Transaction_COUNT,isnull(b.Transaction_amount,0) Transaction_amount
			,isnull(b.AVG_BALANCECHANGE,0) AVG_BALANCECHANGE
			,isnull(b.Deposited_amount,0) Deposited_amount
			,isnull(b.[$ Deposit ACH],0) [$ Deposit ACH]--,isnull(b.[# Deposit ACH],0) [# Deposit ACH]
			into #SavingAccountMerg
			from #SavingsAccount A
			left join #Saving_transaction B
			on a.UNID=b.UNID
			and a.Process_date=b.EFFECTIVEDATE_v1

			
			
			select
			parentaccount,count(distinct UNID) [# Savings]
			,sum(case when Quarters='Q1' then Deposited_amount else 0 end)  Deposited_amount_Savings_Q1	
			,sum(case when Quarters='Q2' then Deposited_amount else 0 end)  Deposited_amount_Savings_Q2	
			,sum(case when Quarters='Q3' then Deposited_amount else 0 end)  Deposited_amount_Savings_Q3	
			,sum(case when Quarters='Q4' then Deposited_amount else 0 end)  Deposited_amount_Savings_Q4	
			into #Savings
			from #SavingAccountMerg 
			where Product_Group_wise='Savings'
			group by parentaccount
			order by parentaccount

			

			
			select
			parentaccount,count(distinct UNID) [# Checking]
			,sum(case when Quarters='Q1' then LASTDIVAMOUNT else 0 end)  LASTDIVAMOUNT_Checking_Q1	
			,sum(case when Quarters='Q1' then [$ Deposit ACH] else 0 end)  [$ Deposit ACH_Checking_Q1]	
			into #Checking
			from #SavingAccountMerg 
			where Product_Group_wise='Checking'
			group by parentaccount
			order by parentaccount

			
			

			
			select a.parentaccount
			,b.[# Savings]	,c.[# Checking]	
					,c.[LASTDIVAMOUNT_Checking_Q1]	
				,b.[Deposited_amount_Savings_Q1]	
				,b.[Deposited_amount_Savings_Q3]	
				,c.[$ Deposit ACH_Checking_Q1]	
				into #SavingMerg
			from #loanstatic2 a
			left join #Savings b on a.parentaccount=b.parentaccount
			left join #Checking c on a.parentaccount=c.parentaccount
			
		
			
			select parentaccount
			,Deposited_amount_Savings_Q1-Deposited_amount_Savings_Q3 Deposited_amount_Savings_Diff_Q1_Q3
			into #MergSaving
			from #SavingMerg
			
			
			-- Jay--
			
			select PARENTACCOUNT,case when (FICO_Staticpool is null or Q1 is null) then 0 else  FICO_Staticpool-[Q1] end as Static_FICO_Q1
			,case when (FICO_Staticpool is null or [Q2] is null) then 0 else FICO_Staticpool-[Q2] end as Static_FICO_Q2
			,case when (FICO_Staticpool is null or [Q3] is null) then 0 else FICO_Staticpool-[Q3] end as Static_FICO_Q3
			,case when (FICO_Staticpool is null or [Q4] is null) then 0 else FICO_Staticpool-[Q4] end as Static_FICO_Q4
			,case when ([Q1] is null or [Q2] is null) then 0 else [Q1]-[Q2] end as Q1_FICO_Q2
			,case when ([Q1] is null or [Q3] is null) then 0 else [Q1]-[Q3] end as Q1_FICO_Q3 
			into #FICDRIFT
			from 
				(select PARENTACCOUNT,cast([Q1] as int) [Q1],cast([Q2] as INT) [Q2],cast([Q3] as int) [Q3]
				,cast([Q4] as int) [Q4],cast(FICO_Staticpool as INT) FICO_Staticpool
				from #loandata) a  
			

		
	

		select PARENTACCOUNT
,[Static_FICO_Q1]
,[Static_FICO_Q2]
,[Static_FICO_Q3]
,[Static_FICO_Q4]
,[Q1_FICO_Q2]
,[Q1_FICO_Q3]
into #Ficodrift
 from 
#FICDRIFT group by 
PARENTACCOUNT
,[Static_FICO_Q1]
,[Static_FICO_Q2]
,[Static_FICO_Q3]
,[Static_FICO_Q4]
,[Q1_FICO_Q2]
,[Q1_FICO_Q3]



Select PARENTACCOUNt,BALANCE as balance 
,CREDITSCORE creditscore,creditlimit creditlimit,[ORIGINALBALANCE] OriginalBalance
,LoanCategory2,LoanCategory3,LoanCategory4,DESCRIPTION
into #j
from #LoanStatic



drop table if exists Analytics..PDQtriggersPersonalloan
Drop table if exists #temppersonal
Select a.PARENTACCOUNT,cast (FICO_Staticpool as int) FICO_Staticpool,Q1_FICO_Q2,Deposited_amount_Savings_Diff_Q1_Q3,[$ Deposit ACH_checking_Q1],AVG_BALANCE_Personal_Unsecured_Q1,a.SSN,FICO_Staticpool fico2
,[Static_FICO_Q1],[Static_FICO_Q2]
,case when isnull(FICO_Staticpool,0) <= 592 and isnull([Q1_fico_q2],0) <= -8 then '1. Severe'
when isnull(FICO_Staticpool,0) <= 592 and isnull([Q1_fico_q2],0) > -8 and isnull(Deposited_amount_Savings_Diff_Q1_Q3,0)<=0 then '2. High'
when isnull(FICO_Staticpool,0) <= 592 and isnull([Q1_fico_q2],0) > -8 and isnull(Deposited_amount_Savings_Diff_Q1_Q3,0)>0 then '3. Moderate'
when isnull(FICO_Staticpool,0) between 592 and 638 then '3. Moderate'
when isnull(FICO_Staticpool,0) between 638 and 733 and isnull([$ Deposit ACH_checking_Q1],0) > 3909.85 then '5. Lowest'
when isnull(FICO_Staticpool,0) between 638 and 733 and isnull([$ Deposit ACH_checking_Q1],0) <= 3909.85 and isnull(AVG_BALANCE_Personal_Unsecured_Q1,0) >335.168 then '4. Low'
when isnull(FICO_Staticpool,0) between 638 and 733 and isnull([$ Deposit ACH_Checking_Q1],0) <= 3909.85 and isnull(AVG_BALANCE_Personal_Unsecured_Q1,0) <=335.168 then '5. Lowest'
when isnull(FICO_Staticpool,0) >=733 then '5. Lowest'
end as Segments
,balance,creditscore,creditlimit,OriginalBalance,LoanCategory2,LoanCategory3,LoanCategory4,DESCRIPTION
,FIRST,LAST,STREET,CITY,STATE,ZIPCODE,BIRTHDATE,
datediff(year,BIRTHDATE,getdate()) as age
,@staticpooldate asofdate
into #temppersonal
--into Analytics..PDQtriggersPersonalloan
from #loandata A
left join 
#SavingMerg d
on a.PARENTACCOUNT = d.PARENTACCOUNT
LEFT join 
#MergSaving B
ON A.PARENTACCOUNT = B.PARENTACCOUNT
left join
#ficodrift c
on a.PARENTACCOUNT = c.PARENTACCOUNT
left join #j z
on a.PARENTACCOUNT = z.parentaccount
Where a.PARENTACCOUNT is not null and SSN is not null

drop table if exists #temp
Select COUNT(*) as cnt into #temp   from #temppersonal

 drop table if exists #temp2
 Select rank() over (order by balance) as srno,Balance into #temp2 from #temppersonal  order by 1 

 
 Declare @f as int

 Set @f = (Select Balance from #temp2 where srno in( select round((cnt+1)*0.99,0)  from #temp))
 


drop table if exists #temppersonal2
Select *,case when Balance > @f then @f else Balance end as newcurrentbalance into #temppersonal2  from #temppersonal


declare @z as float
Set @z = (select MAX(newcurrentbalance) from #temppersonal2)

declare @y as float
Set @y = (select Min(newcurrentbalance) from #temppersonal2)

Drop table if exists #temppersonal3

Select * ,
((newCurrentBalance - @y)/(@z-@y))*40 as Scaler
,(1-((@z-newCurrentBalance)/@z))*40 as Scaler2
into #temppersonal3
from #temppersonal2

 Drop table if exists Analytics..PDQtriggersPersonalloan

Select * ,
Case when Segments = '1. Severe' then Round(60 + Scaler,2)
  when Segments = '2. High' then Round(40 + Scaler,2)
  when Segments = '3. Moderate' then Round(25 + Scaler,2)
  when Segments = '4. Low' then Round(15 +Scaler,2)
  when Segments = '5. Lowest' then Round(10 +Scaler,2)
   end as final_score
 into Analytics..PDQtriggersPersonalloan
from #temppersonal3
order by final_score Desc,balance DESC



end


Exec dbo.PDQTriggerPersonalLoanTargetlist





select PARENTACCOUNT,COUNT(*) from Analytics..PDQtriggersPersonalloan group by PARENTACCOUNT having COUNT(*) > 1


Select * from Analytics..PDQtriggersPersonalloan order by final_score desc



Select * from Analytics..PDQtriggersPersonalloan where FICO_Staticpool <= 592 


Select distinct Q1_FICO_Q2 
from Analytics..PDQtriggersPersonalloan

order by final_score Desc
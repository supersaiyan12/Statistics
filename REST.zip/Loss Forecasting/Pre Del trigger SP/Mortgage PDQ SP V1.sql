

	Alter procedure dbo.PDQTriggerMortgagTargetlist
	as 
	begin
	declare @staticpooldate as date 
	 set @staticpooldate = (Select MAX(convert(date,convert(varchar(50),processdate))) from ARCUSYM000..LOAN)

	 -- Case when EOMONTH(Getdate()) = GETDATE() 
	 --then GETDATE() else EOMonth(DATEADD(mm,-1,getdate())) end 
	  --convert(date,getdate()-1)
	 --select mortgageID,count(*) from 
	 -- (select mortgageid,MortgageOriginalBalance from ae_edw..d_mortgage group by mortgageid,MortgageOriginalBalance) A
	 -- group by mortgageID having count(*)>1

		drop table if exists #groupproducttype_Deposits0
		select *
		,case when ProductName like '%money%'  or ProductName like '% MM %' then 'MoneyMarket'
		when ProductName='Youth Savings' and ApplicationDescription='Certificates' then 'Savings'
		when ProductCode=0 and ApplicationDescription='Certificates' then 'Savings'
		when ProductName='40 Month CD' and ApplicationDescription='Certificates' then 'Checking'
		when ProductName='Certificate' and ApplicationDescription='Certificates' then 'Checking' 
		when ProductName='Public Funds' and ApplicationDescription='Certificates' then 'Certificates'  
		 else ApplicationDescription end Product_Group_wise
		into #groupproducttype_Deposits0
		from
		(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName
		,ApplicationDescription,ApplicationTableName
		 from [AE_EDW].[tempods].[S_CRMProductType] a
		left join [AE_EDW].[tempods].[S_CRMApplicationType] b
		on a.ApplicationTypeID=b.ApplicationTypeID
		where ApplicationDescription is not null
		and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a
		order by ProductCode



		drop table if exists #Extractdate_mortgage
		select  Extractdate,max(AsOfDate) AsOfDate
		into #Extractdate_mortgage
		from (select case when len(month(AsOfDate))=1 then concat(year(AsOfDate),0,month(AsOfDate)) 
		else concat(year(AsOfDate),month(AsOfDate)) end Extractdate,* from AE_EDW..F_Mortgage_Daily) A
		where CoreMortgageStatus='Active' 
		group by Extractdate
		order by Extractdate

		
		drop table if exists #Max_processdate_Mortgage
		select Process_Date,max(ProcessDate) ProcessDate
		into #Max_processdate_Mortgage from
		(select parentaccount,(USERCHAR1) USERCHAR1,EXPIREDATE,ProcessDate,left(ProcessDate,6) Process_Date 
					from ARCUSYM000..TRACKING 
					group by parentaccount,USERCHAR1,EXPIREDATE,ProcessDate) A
		group by Process_Date

		drop table if exists #Tracking
		select parentaccount,ID,(USERCHAR1) USERCHAR1,EXPIREDATE,ProcessDate,left(ProcessDate,6) Process_Date 
		into #Tracking
		from ARCUSYM000..TRACKING where ProcessDate in (select ProcessDate from #Max_processdate_Mortgage)
		group by parentaccount,ID,USERCHAR1,EXPIREDATE,ProcessDate

		drop table if exists #Mortgage
		select  b.parentaccount,d.MortgageOriginalBalance,
		a.*,case when Extractdate=Opendate then 1 else 0 end New_flag
		into #Mortgage
		from (select case when len(month(AsOfDate))=1 then concat(year(AsOfDate),0,month(AsOfDate)) else concat(year(AsOfDate),month(AsOfDate)) end Extractdate
				,case when len(month(MortgageOpenDate))=1 then concat(year(MortgageOpenDate),0,month(MortgageOpenDate)) else concat(year(MortgageOpenDate),month(MortgageOpenDate)) end Opendate
				,* from AE_EDW..F_Mortgage_Daily) A
		left join #Tracking b
		on a.mortgageid=b.USERCHAR1 and a.Extractdate=b.Process_Date
		left join AE_EDW..D_Mortgage d on a.mortgageid=d.MortgageID
		where CoreMortgageStatus='Active' and AsOfDate=@staticpooldate  and
		 b.EXPIREDATE is null
		 --select * from #Mortgage
		Drop table if exists #Processdate
		select 
		Process_date,max(ProcessDate) MAX_ProcessDate 
		into #Processdate
		from
			(
			select ProcessDate,left(ProcessDate,6) Process_date
			,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
			from ARCUSYM000..NAME group by ProcessDate
			) A 
			where [Process date] between dateadd(month,-12,@staticpooldate) and @staticpooldate
			group by Process_Date
			order by Process_Date
		
		Drop table if exists #NAME
		SELECT distinct N.PARENTACCOUNT,N.SSN,N.FIRST, N.LAST, N.BIRTHDATE, n.userchar3 FICO_Staticpool,STREET,CITY,STATE,ZIPCODE INTO #Name
		FROM
			(
			SELECT SSN,PARENTACCOUNT, FIRST, LAST, BIRTHDATE,n.USERCHAR3,STREET,CITY,STATE,ZIPCODE
			FROM ARCUSYM000.dbo.NAME N
			LEFT JOIN ARCUSYM000.dbo.ACCOUNT A
				ON N.PARENTACCOUNT = A.ACCOUNTNUMBER
				AND N.ProcessDate = A.ProcessDate
			WHERE N.TYPE = 0
				AND N.ProcessDate =concat(left(@staticpooldate ,4),right(left(@staticpooldate ,7),2),right(@staticpooldate ,2))--(SELECT MAX(ProcessDate) FROM ARCUSYM000.dbo.IRS)
				AND N.LAST <> 'NEW MEMBER' AND N.BIRTHDATE is not null AND N.SSNTYPE in (0,9) AND N.NAMEFORMAT = 0 AND A.CLOSEDATE is null
			) N 
			where PARENTACCOUNT in (Select distinct PARENTACCOUNT from #Mortgage group by PARENTACCOUNT)
		

		drop table if exists #duplicate
		select SSN,count(PARENTACCOUNT) CNT 
		into #duplicate
		from #NAME
		group by SSN
		having count(PARENTACCOUNT)>1

		drop table if exists #NAME1
		select a.SSN,PARENTACCOUNT
		into #NAME1
		from #NAME A
		left join #duplicate b
		on a.SSN=b.SSN
		where b.SSN is null
	
		drop table if exists #temp15
		select SSN,AccountNumber as parentaccount
		into #temp15
		from AE_EDW..D_Member
		where SSN in
		(select SSN from #duplicate)

	drop table if exists #FinalName
		select a.*,case when b.FICO_Staticpool is null or b.FICO_Staticpool>1000 then 0 else b.FICO_Staticpool end FICO_Staticpool,FIRST,LAST,STREET,CITY,STATE,ZIPCODE,BIRTHDATE into #FinalName from
				(select *
				from #NAME1
				union 
				select * from #temp15) a
				left join #NAME b
				on a.PARENTACCOUNT=b.PARENTACCOUNT		   


 Drop table if exists #LoanAccount
								select 
								   [ProcessDate],[Process date],[Process_date],Quarters,MonthBack_seg
								  ,[PARENTACCOUNT]
								  ,[ID],TYPE,OPENdate,Open_date,closedate,Close_date,Charge_off_date,CHARGEOFFDATE,Loan_MOB,Loan_Term,Month_to_Maturity
								  ,[PARTIALPAYMENT],[PAYMENT],[LASTPAYMENTDATE],DUEDATE,[PAYMENTCOUNT],[INTERESTRATE],day(LASTPAYMENTDATE) Payment_day,abs(day(DUEDATE)-day(LASTPAYMENTDATE)) Diff_Due_Payment
								  ,[DQNOTICENUMBER],[DQNOTICEDATE],[DQCARDDATE],[LATECHARGETYPE],[LATECHARGEACCRUED],[LATECHARGEUNPAID],[LATECHARGEYTD]
								  ,case when (latechargeYTD-(lag(latechargeYTD,1,0) over (partition by Parentaccount order by Parentaccount,[Process date])))<0 or  --change Parentaccount to Parentaccount
									[Process date]='2017-08-31' then 0  -- jay
									else (latechargeYTD-(lag(latechargeYTD,1,0) over (partition by Parentaccount order by Parentaccount,[Process date]))) end Latechargefee
								  ,[LATECHARGELASTYEAR]
								  ,[BALANCE],[ORIGINALBALANCE],[CREDITLIMIT],[PRINCIPALYTD],[PRINCIPALLASTYEAR],[STATEMENTDATE],[DESCRIPTION],[NSFMONTHTODATE],FEEBILLINGDATE
								  ,FEEBILLINGAMOUNT,[FEEOLDBALANCE]
								  ,[FEENEWBALANCE],[FEECOUNT1],[FEECOUNT2],[FEECOUNT3],[FEECOUNT4],[MATURITYDATE],[LATECHARGEDATE],[BRANCH],[RISKRATE],[CREDITSCORE]
								  ,b.LoanCategory2,b.LoanCategory3,b.LoanCategory4
								  ,case when LoanCategory2='Vehicle' then 'Vehicle'
								   when LoanCategory2='Personal' and LoanCategory3='Secured' then 'Personal_Secured'
								   when LoanCategory2='Personal' and LoanCategory3='Unsecured' then 'Personal_Unsecured'
								   when LoanCategory2='Real Estate' and LoanCategory4 like 'HEL%' then 'HELOC' 
								   when LoanCategory2='Real Estate' then 'Real_Estate'
								   when LoanCategory2='Commercial Loans' then 'Commercial Loans'
								   when LoanCategory2='Construction And Development' then 'Construction And Development'
								   when LoanTypeDescription like '%AUTO (OL)' then 'Vehicle' else LoanTypeDescription end Loan_Categories
								into #LoanAccount
								from
											(
											select *
											,case when[Process date] between dateadd(month,-3,@staticpooldate) and DATEADD(month,-1,@staticpooldate) then 'Q1'
													when [Process date] between dateadd(month,-6,@staticpooldate) and DATEADD(month,-4,@staticpooldate) then 'Q2'
													when [Process date] between dateadd(month,-9,@staticpooldate) and DATEADD(month,-7,@staticpooldate) then 'Q3'
													when [Process date] between dateadd(month,-12,@staticpooldate) and DATEADD(month,-10,@staticpooldate) then 'Q4'
													when month([Process date] ) in (MONTH(@staticpooldate)) then 'Staticpool'
											  end Quarters 
											  ,case when month([Process date]) in (month((dateadd(month,-4,@staticpooldate)))) then 'M4'
												 when month([Process date] ) in (month((dateadd(month,-3,@staticpooldate)))) then 'M3'
												 when month([Process date] ) in (month((dateadd(month,-2,@staticpooldate)))) then 'M2'
												 when month([Process date] ) in (month((dateadd(month,-1,@staticpooldate)))) then 'M1'
												 end MonthBack_seg 	 
												 
												  
											,case when opendate=closedate then 0 else 1 end Flag
											,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date 
											then 1 else 0 end Open_Flag
											,DATEDIFF(month,OPENDATE,@staticpooldate) Loan_MOB	-- add the @Staticpooldate
											,DATEDIFF(month,OPENDATE,MATURITYDATE) Loan_Term
											,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
												from 
													(
													select *
													,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
													else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
													,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
													else concat(year(opendate),month(opendate)) end Open_date
													,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
													else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
													,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
													,left(ProcessDate,6) Process_date
													from ARCUSYM000..LOAN
													--where (CHARGEOFFDATE>=@staticpooldate or CHARGEOFFDATE is null ) 
													) H
											 where  ORIGINALDATE is not null and OpenDate is not null 
											 --and [Process date]=@staticpooldate		-- Later add -12 month the @staticpooldate date here 
											 and MATURITYDATE>@staticpooldate	-- add 3 month in currrent date
											 and ProcessDate in (select MAX_ProcessDate from #Processdate)
											) A
									left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
									on b.loantype=a.TYPE
									where Flag=1 and Open_Flag=1
									and PARENTACCOUNT in (select PARENTACCOUNT from #mortgage group by PARENTACCOUNT)
									order by PARENTACCOUNT,ProcessDate


drop table if exists #LOAN_TRANSACITON_DATA
		select 
			PARENTACCOUNT
			,EFFECTIVEDATE_v1
			,sum(Interest_amount) sum_Interest_amount
			,sum(FEEAMOUNT) Sum_FEEAMOUNT
			INTO #LOAN_TRANSACITON_DATA
			from   
				( select PARENTACCOUNT,EFFECTIVEDATE_v1,ACTIONCODE,SOURCECODE,Transaction_amount Transaction_amount,NEWBALANCE,Interest_amount, FEEAMOUNT
				from
					(
								select PARENTACCOUNT,case when len(month(effectivedate))=1 then CONCAT(year(effectivedate),0,month(effectivedate))
												else CONCAT(year(effectivedate),month(effectivedate)) end EFFECTIVEDATE_v1
												,cast(EFFECTIVEDATE as date) EFFECTIVEDATE
								,ACTIONCODE,SOURCECODE,BALANCECHANGE Transaction_amount,NEWBALANCE,INTEREST Interest_amount, FEEAMOUNT			
								from [ARCUSYM000]..LOANTRANSACTION
												where
												ACTIONCODE in ('A','N','P') AND SOURCECODE in ('C','D','E','F','H','I','K','P','S','T')
												 and ACTIONCODE !='C' 	
					 ) AA
				) bb
			 where  EFFECTIVEDATE_v1 In (select Process_date from #Processdate)
			 --between (Cast((left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6)) as int)) 
			 --and cast((left(convert(varchar,@staticpooldate,112),6)) as int)
			 and PARENTACCOUNT in (select PARENTACCOUNT from #Mortgage group by PARENTACCOUNT)
			 group by EFFECTIVEDATE_v1,PARENTACCOUNT
			 

		 drop table if exists #LoanAccountMerg
		 select a.*,b.Sum_FEEAMOUNT,b.sum_Interest_amount
		--,d.Cycle1,d.Cycle2,d.Cycle3,e.ACHAutopay_Flag,f.OffCycle_flag--,g.vehicle_Flag
		into #LoanAccountMerg
		from #LoanAccount A
		left join #LOAN_TRANSACITON_DATA B
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		and a.Process_date=b.EFFECTIVEDATE_v1
		order by a.PARENTACCOUNT,a.Process_date	 
			
		drop table if exists ##Max_loan
		select b.SSN,a.PARENTACCOUNT,case when b.FICO_Staticpool>1000 then 0  else b.FICO_Staticpool end FICO_Staticpool
		into ##Max_loan 
		from #LoanAccountMerg a left join #finalname b on a.PARENTACCOUNT=b.PARENTACCOUNT where SSN is not null
		group by a.PARENTACCOUNT,b.SSN,b.FICO_Staticpool order by b.FICO_Staticpool

			Drop table if exists #savingsaccount
		select 
		ProcessDate,Process_Date,[PARENTACCOUNT],id,UNID,type,opendate,MATURITYDATE,CLOSEDATE,Close_date,CHARGEOFFDATE_v,CHARGEOFFAMOUNT_v
		,BALANCE,Product_Group_wise,LASTDIVAMOUNT,[# Chargeoff Deposit],Close_flag,Chargeoff_flag,Quarters,MonthBack_seg,COURTESYFEEMTD,NSFFEEMTD
		,case when (Overdraftfeeytd-(lag(Overdraftfeeytd,1,0) over (partition by UNID order by UNID,[Process date])))<0 or
									[Process date]='2017-08-31' then 0 -- Jay
									else (Overdraftfeeytd-(lag(Overdraftfeeytd,1,0) over (partition by UNID order by UNID,[Process date]))) end Overdraftfee
		into #SavingsAccount
		from
				(
						select 
						ProcessDate,Process_Date,[Process Date],[PARENTACCOUNT],id,CONCAT(PARENTACCOUNT,ID) UNID,type,opendate,MATURITYDATE,CLOSEDATE,Close_date,CHARGEOFFDATE_v,CHARGEOFFAMOUNT_v
						,case when closedate is null and chargeoffdate is null then BALANCE else 0 end BALANCE,e.Product_Group_wise
						,LASTDIVAMOUNT,Overdraftfeeytd,COURTESYFEEMTD,NSFFEEMTD
						,case when CHARGEOFFAMOUNT_v>0 then 1 else 0 end [# Chargeoff Deposit]
						,case when Close_date=Process_Date then 1 else 0 end Close_flag
						,case when CHARGEOFFDATE_v=Process_Date then 1 else 0 end Chargeoff_flag
						,case when Product_Group_wise='Certificates' and BALANCE=0 then 0 else 1 end carryforward_flag
					,case when[Process date] between dateadd(month,-3,@staticpooldate) and DATEADD(month,-1,@staticpooldate) then 'Q1'
													when [Process date] between dateadd(month,-6,@staticpooldate) and DATEADD(month,-4,@staticpooldate) then 'Q2'
													when [Process date] between dateadd(month,-9,@staticpooldate) and DATEADD(month,-7,@staticpooldate) then 'Q3'
													when [Process date] between dateadd(month,-12,@staticpooldate) and DATEADD(month,-10,@staticpooldate) then 'Q4'
													when month([Process date] ) in (MONTH(@staticpooldate)) then 'Staticpool'
											  end Quarters 
											  ,case when month([Process date]) in (month((dateadd(month,-4,@staticpooldate)))) then 'M4'
												 when month([Process date] ) in (month((dateadd(month,-3,@staticpooldate)))) then 'M3'
												 when month([Process date] ) in (month((dateadd(month,-2,@staticpooldate)))) then 'M2'
												 when month([Process date] ) in (month((dateadd(month,-1,@staticpooldate)))) then 'M1'
												 end MonthBack_seg 
						--,case when [Process Date] in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
						-- when [Process Date] in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
						-- when [Process Date] in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
						-- when [Process Date] in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
						-- when [Process Date] in (@staticpooldate) then 'Staticpool'
						--  end Quarters
						from 
								(
										select *,case when [EOM_Process Date]=[Process Date] then 1 else 0 end EOM_flag 
										,case when (closedate is null and CHARGEOFFDATE is null) or Process_Date=close_date 
										or Process_Date=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
										from
											(select a.*,EOMONTH([Process Date]) [EOM_Process Date]
											,case when OPENDATE=CLOSEDATE then 0 else 1 end Funded_loan_flag
											,case when Process_Date=CHARGEOFFDATE_v then CHARGEOFFAMOUNT else 0 end CHARGEOFFAMOUNT_v
											,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
											else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
											 from 
												 ( select * ,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
												 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v,left(ProcessDate,6) Process_Date
												,datefromparts(left(processdate,4),right(left(processdate,6),2),right(processdate,2)) [Process Date] from arcusym000..SAVINGS
												--where (chargeoffdate is null or chargeoffdate>='2020-01-01')
												) a
												where  ProcessDate in (select MAX_ProcessDate from #processdate)
												and PARENTACCOUNT in (select PARENTACCOUNT from #Mortgage)
											) F
								 ) aa
						left join #groupproducttype_Deposits0 E
						on e.ProductCode=aa.TYPE
						 where Funded_loan_flag=1 and Open_Flag=1
						group by ProcessDate,[Process Date],Process_Date,[PARENTACCOUNT],id,type,CLOSEDATE,CHARGEOFFDATE_v,CHARGEOFFAMOUNT_v,LASTDIVAMOUNT
						,BALANCE,e.Product_Group_wise,opendate,MATURITYDATE,chargeoffdate,Close_date,Overdraftfeeytd,COURTESYFEEMTD,NSFFEEMTD
				) A
				order by PARENTACCOUNT,id,ProcessDate


	Drop table if exists #Saving_transaction	
			select PARENTACCOUNT,PARENTID,UNID
			,sum([$ Deposit ACH]) [$ Deposit ACH]
			,EFFECTIVEDATE_v1
		    into #Saving_transaction
			from 
					(
					SELECT  [PARENTACCOUNT]
					  ,[PARENTID]
					  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
					  
					  ,case when SOURCECODE='E' and ACTIONCODE='D' then BALANCECHANGE else 0 end [$ Deposit ACH]
					 ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
					  else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
					  FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
					  WHERE PARENTACCOUNT IN (SELECT PARENTACCOUNT FROM #Mortgage)
					  AND ACTIONCODE!='C'
					) A
			where EFFECTIVEDATE_v1 in (select Process_date from #Processdate)
			--between left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6) and left(convert(varchar,@staticpooldate,112),6)
			and PARENTACCOUNT in (select PARENTACCOUNT from #Mortgage)
			group by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1
			order by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1

			drop table if exists #SavingAccountMerg
			select 
			a.*
			,isnull(b.[$ Deposit ACH],0) [$ Deposit ACH]	
			into #SavingAccountMerg
			from #SavingsAccount A
			left join #Saving_transaction B
			on a.UNID=b.UNID
			and a.Process_date=b.EFFECTIVEDATE_v1

			drop table if exists #Checking
			select
			parentaccount,count(distinct UNID) [# Checking]
			,sum(case when Quarters='Q1' then [$ Deposit ACH] else 0 end)  [$ Deposit ACH_Checking_Q1]	
			into #Checking
			from #SavingAccountMerg 
			where Product_Group_wise='Checking'
			group by parentaccount
			order by parentaccount

		drop table if exists #Mortgage2
		Select PARENTACCOUNT into #mortgage2 from #Mortgage group by PARENTACCOUNT

		Drop table if exists #loandata
		select a.PARENTACCOUNT,g.FICO_Staticpool,g.SSN,g.FIRST,g.LAST,g.STREET,g.CITY,g.STATE,g.ZIPCODE,g.BIRTHDATE
		into #loandata
		from #mortgage2 a
		left join #FinalName g on a.PARENTACCOUNT=g.PARENTACCOUNT   
		
		drop table if exists #j
		Select PARENTACCOUNT,SUM(MortgageCount) MortgageCount,max(MortgageOriginalBalance) [Original Balance]
		,SUM(CurrentBalance) CurrentBalance,SUM(EscrowBalance) EscrowBalance
		,max(InterestRate) InterestRate,SUM(PaymentDue) PaymentDue
		into #j
		from #Mortgage group by PARENTACCOUNT

		drop table if exists #tempb
		Select * into #tempb from  ARCUSYM000.arcu.ARCUMemberAccountDetailed where ProcessDate = concat(left(@staticpooldate ,4),right(left(@staticpooldate ,7),2),right(@staticpooldate ,2))

		drop table if exists #negativedays
			  Select parentaccount,SUM(FLAG) NEGATIVEDAYS3MONTHS INTO #negativedays FROM(
		Select parentaccount,EFFECTIVEDATE,max(flag) AS FLAG from (
		  Select  PARENTACCOUNT,EFFECTIVEDATE,LASTTRANDATE,BALANCECHANGE,PREVAVAILBALANCE,NEWBALANCE,case when NEWBALANCE < 0 then 1 else 0 end as flag
		  from ARCUSYM000..SAVINGSTRANSACTION where EFFECTIVEDATE between DATEADD(MM,-3,@staticpooldate) and @staticpooldate 
		   )t group by parentAccount,effectivedate )T GROUP BY pARENTACCOUNT

	 Drop table if exists #QFICO
	  select [Process date],case when [Process date]=@staticpooldate then 'Static'
				when [Process date] between dateadd(month,-3,@staticpooldate) and DATEADD(month,-1,@staticpooldate) then 'Q1'
				when [Process date] between dateadd(month,-6,@staticpooldate) and DATEADD(month,-4,@staticpooldate) then 'Q2'
				when [Process date] between dateadd(month,-9,@staticpooldate) and DATEADD(month,-7,@staticpooldate) then 'Q3'
				when [Process date] between dateadd(month,-12,@staticpooldate) and DATEADD(month,-10,@staticpooldate) then 'Q4'
				end as Quarterly,a.PARENTACCOUNT,SSN,a.USERCHAR3 FICO
				into #QFICO
				from 
						(select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date] 
						from ARCUSYM000..NAME) a
				left join ARCUSYM000..SAVINGS b
						on a.PARENTACCOUNT=b.PARENTACCOUNT
						and a.ProcessDate=b.ProcessDate
						where a.TYPE=0
						and a.ProcessDate in (select MAX_ProcessDate from #Processdate where right(left(MAX_ProcessDate,6),2) in (3,6,9,12) )
						--and a.Process_date=dateadd(year,-1,@staticpooldate)
						and b.SHARECODE=0 
						and b.ORIGINALDEPOSITDATE is not null
						and b.CLOSEDATE is null 
						and b.CHARGEOFFDATE is null
						and a.PARENTACCOUNT in (select PARENTACCOUNT from #loandata)
						group by [Process date],a.PARENTACCOUNT,SSN,a.USERCHAR3
						order by  a.PARENTACCOUNT
	
		Drop table if exists #QuarterlyFICO				
		select 
		PARENTACCOUNT,max([Q1])[Q1],max([Q2])[Q2] ,max([Q3])[Q3] ,max([Q4])[Q4] --,max([2020Q-1]) [2020Q-1],Max([2020Q-2]) [2020Q-2]
		Into #QuarterlyFICO
		from	(
			select * from #QFICO
			) S
		Pivot
		(
		max(FICO) 
		for Quarterly in ([Q1],[Q2],[Q3],[Q4])
		--(select Quarterly from #QFICO group by Quarterly)
		) as PIVOT_table
		group by PARENTACCOUNt
		order by PARENTACCOUNT

		drop table if exists #FICDRIFT
		select PARENTACCOUNT,case when (FICO_Staticpool is null or Q1 is null) then 0 else  FICO_Staticpool-[Q1] end as Static_FICO_Q1
		,case when (FICO_Staticpool is null or [Q2] is null) then 0 else FICO_Staticpool-[Q2] end as Static_FICO_Q2
		,case when (FICO_Staticpool is null or [Q3] is null) then 0 else FICO_Staticpool-[Q3] end as Static_FICO_Q3
		,case when (FICO_Staticpool is null or [Q4] is null) then 0 else FICO_Staticpool-[Q4] end as Static_FICO_Q4
		,case when ([Q1] is null or [Q2] is null) then 0 else [Q1]-[Q2] end as Q1_FICO_Q2
		,case when ([Q1] is null or [Q3] is null) then 0 else [Q1]-[Q3] end as Q1_FICO_Q3 
			into #FICDRIFT
			from 
				(select a.PARENTACCOUNT,cast([Q1] as int) [Q1],cast([Q2] as INT) [Q2],cast([Q3] as int) [Q3]
				,cast([Q4] as int) [Q4],cast(FICO_Staticpool as INT) FICO_Staticpool
				from #QuarterlyFICO a left join (select parentaccount,FICO_Staticpool from #FinalName) b on a.PARENTACCOUNT=b.PARENTACCOUNT
				) a  

					

Drop table if exists Analytics..mortgagetargetlist
Select A.*,b.ShareAvgBalanceLast90Days,c.NEGATIVEDAYS3MONTHS,z.EscrowBalance,d.[$ Deposit ACH_Checking_Q1],z.CurrentBalance,z.[Original Balance],FICO_Staticpool fico
,e.Static_FICO_Q1,e.Static_FICO_Q2
into Analytics..mortgagetargetlist
from #loandata A
left join #j z
on a.PARENTACCOUNT = z.parentaccount
left join #tempb b
on a.PARENTACCOUNT = b.AccountNumber
left join #negativedays c
on a.parentaccount = c.parentaccount
left join #Checking d
on A.PARENTACCOUNT = d.PARENTACCOUNT 
left join #FICDRIFT e on a.PARENTACCOUNT=e.PARENTACCOUNT

Drop table if exists Analytics..MortgageloansTargetlist
Select *,datediff(year,BIRTHDATE,getdate()) as age,
Case when isnull(FICO_Staticpool,0) <= 622 and escrowband2 = 0 then '1. Severe'
when isnull(FICO_Staticpool,0) <= 622 and isnull(Escrowband2,0) = 1 and isnull(EscrowBalance,0)<=1101.020  then '2. High'
when isnull(FICO_Staticpool,0) <= 622 and isnull(Escrowband2,0) = 1 and isnull(EscrowBalance,0)>1101.020  then '3. Moderate'
when isnull(FICO_Staticpool,0) <= 622 and isnull(Escrowband2,0) = 2 and isnull([$ Deposit ACH_Checking_Q1],0) <= 0 then '3. Moderate'
when isnull(FICO_Staticpool,0) <= 622 and isnull(escrowband2,0) = 2 and isnull([$ Deposit ACH_Checking_Q1],0) > 0 then '4. Low'
when isnull(FICO_Staticpool,0) between 622 and 673 and isnull(NEGATIVEDAYS3MONTHS,0) <=0 then '4. Low'
when isnull(FICO_Staticpool,0) between 622 and 673 and isnull(NEGATIVEDAYS3MONTHs,0) > 0 then '3. Moderate'
when isnull(FICO_Staticpool,0) > 673   then '4. Low' end as Segments
,@staticpooldate as asofdate
into Analytics..MortgageloansTargetlist
from (
Select *, case when escrowbalance <0 then 0
when Escrowbalance <= 1790 then 1
when Escrowbalance >1790 then 2 end as escrowband2
 from Analytics..mortgagetargetlist
 )T 

 Delete from Analytics..MortgageloansTargetlist where PARENTACCOUNT is null
 Delete from Analytics..MortgageloansTargetlist where SSN is null


end





--------------------------------------------------Univariate Analysis Code-----------------------------------------------------
--Date: 28th Mar '18
--Change the static pool month from entire code....

	alter procedure [dbo].[PDQTriggerCreditCardTargetList] 
	as 
	begin
	declare @staticpooldate date, @newdate date
	set @staticpooldate=(select max(fullExtractdate) from TMGData..cardholder)
	set @newdate=(select eomonth(max(fullExtractdate)) from TMGData..cardholder)
	Drop table if exists ##masterdata
	exec dbo.Dynamic_Master_data @newdate
	-- date is 1st only
	--Truncate [PDQTriggerCreditCardTargetList]
	
	drop table If Exists #temp1
	drop table If Exists #temp_pre_12mo_2
	drop table If Exists #temp_pre_12mo_3
	drop table If Exists #temp_pre_12mo_3a
	drop table If Exists #temp_pre_12mo_4
	drop table If Exists #temp_pre_6mo_2
	drop table If Exists #temp_pre_6mo_3
	drop table If Exists #temp_pre_6mo_3a
	drop table If Exists #temp_pre_6mo_4
	drop table If Exists #temp2
	drop table If Exists #temp3
	drop table If Exists #temp4
	drop table If Exists #temp5
	drop table If Exists #temp6
	drop table If Exists #temp7
	drop table If Exists #temp8
	drop table If Exists #temp9
	drop table If Exists #temp10
	drop table If Exists #temp10a
	drop table If Exists #temp10b
	drop table If Exists #temp10c
	drop table If Exists #temp10d
	drop table If Exists #temp10e
	drop table If Exists #temp11
	drop table if exists analytics..[PDQTriggerCreditCardTargetListTable]

	--select distinct [Card Description] FROM TMGdata.[dbo].[cardholder] where  Extract_DatePart = 201812
	--static pool data
	select Durable_Key,[Credit Limit],mob,[Card Description],format(cast([Social Security Number] as int),'000000000') [Social Security Number],
	[Last Statement Balance Amount],RevolvingBalance,[Credit Limit] [CL Static]
	,([Last Statement Sale Amount]-[Last Statement Return Amount]) as spend,
	TRIPFLAG,[Last Statement Payment Amount], fullExtractdate as sp_month
	,case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization_Static
    into #temp1
	FROM TMGdata.[dbo].[cardholder]
	where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business')
	and [External Status Code] in ('') and [Internal Status Code] in ('','N')
	and fullExtractdate = @staticpooldate 
	and mob > 11 and [card account delinquent day account]<60
	
	--Step 1: Pre 12 month numbers
	select Durable_Key as d_pre_12mo,
	sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_12mo,
	sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_12mo,
	sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_12mo,
	sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_12mo,
	sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_12mo,
	sum([Last Statement Balance Amount]) as sum_bal_pre_12mo,
	sum(RevolvingBalance) as sum_revbal_pre_12mo,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_12mo,
	avg([Last Statement Balance Amount]) as avg_bal_pre_12mo,
	avg(RevolvingBalance) as avg_revbal_pre_12mo,
	avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_12mo
	,sum(case when TRIPFLAG='T' then 1 else 0 end) Transactor_Pre_12mo
	into #temp_pre_12mo_2
	from TMGdata.[dbo].[cardholder]
	where [Active_flag] = 1 --and [Card Description] not in ('Mastercard Business')
	and fullExtractdate between ((dateadd(month,-11,@staticpooldate))) and @staticpooldate
	and Durable_Key in 
	(select Durable_Key from #temp1)
	group by Durable_Key

	--Pre 12 month Profit numbers
	select Durable_Key,Extract_DatePart,
	case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization,
	case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate,
	case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate,
	([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income,
	([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees,
	([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income,    
	([Last Statement Balance Amount]*0.02/12) as COF,
	(ChargeoffAmount_final) as chgoff_amt,
	--0 as rewards_expense, --since at that time there was only one card and it was non-reward
	--case when [Card Description] not in ('','') then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end as rewards_expense,
	([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense,
	case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost
	into #temp_pre_12mo_3
	from TMGdata.[dbo].[cardholder]
	where [Active_flag] = 1 --and [Card Description] not in ('Mastercard Business')
	and fullExtractdate between (dateadd(month,-11,@staticpooldate)) and @staticpooldate
	and Durable_Key in 
	(select Durable_Key from #temp1)
	
	--Pre 12 month Profit numbers_summary
	select Durable_Key,count(*) as N_months,
	sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit,
	avg(Utilization) as avg_Utilization,avg(revolve_rate) as avg_revolve_rate,avg(payment_rate) as avg_payment_rate
	into #temp_pre_12mo_3a
	from #temp_pre_12mo_3
	group by Durable_Key
	
	select a.*,
	b.profit as sum_profit_pre_12mo,b.profit/b.N_months as avg_profit_pre_12mo, 
	b.avg_Utilization as avg_Utilization_pre_12mo,
	b.avg_revolve_rate as avg_revolve_rate_pre_12mo,
	b.avg_payment_rate as avg_payment_rate_pre_12mo
	into #temp_pre_12mo_4
	from #temp_pre_12mo_2 a
	left join #temp_pre_12mo_3a b
	on a.d_pre_12mo = b.Durable_Key

	select Durable_Key  as d_pre_6mo,
	sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_6mo,
	sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_6mo,
	sum(case when [Last Statement Balance Amount] > [Credit Limit] then 1 else 0 end) as Times_overlimit_pre_6mo,
	sum(case when [Last Statement Balance Amount] > 1.05*[Credit Limit] then 1 else 0 end) as Times_5pc_overlimit_pre_6mo,
	sum(case when [Last Statement Cash Advance Count] > 0 then 1 else 0 end) as Times_cash_Advances_pre_6mo,
	sum([Last Statement Balance Amount]) as sum_bal_pre_6mo,
	sum(RevolvingBalance) as sum_revbal_pre_6mo,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as sum_spend_pre_6mo,
	avg([Last Statement Balance Amount]) as avg_bal_pre_6mo,
	avg(RevolvingBalance) as avg_revbal_pre_6mo,
	avg([Last Statement Sale Amount]-[Last Statement Return Amount]) as avg_spend_pre_6mo
	into #temp_pre_6mo_2
	from TMGdata.[dbo].[cardholder]
	where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business')
	and fullExtractdate between (dateadd(month,-5,@staticpooldate)) and @staticpooldate
	and Durable_Key in 
	(select Durable_Key from #temp1)
	group by Durable_Key

	--Pre 6 month Profit numbers
	select Durable_Key,Extract_DatePart,
	case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end as Utilization,
	case when [Last Statement Balance Amount] = 0 then 0 else RevolvingBalance/[Last Statement Balance Amount] end as revolve_rate,
	case when [Last Statement Balance Amount] = 0 then 0 else [Last Statement Payment Amount]/[Last Statement Balance Amount] end as payment_rate,
	([Protected_Current_Interest]+[Promo_Current_Interest]+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income,
	([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] +[Dynamic Interest Fees Charges Statement Year To Date]) as fees,
	([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income,    
	([Last Statement Balance Amount]*0.02/12) as COF,
	(ChargeoffAmount_final) as chgoff_amt,
	--0 as rewards_expense, --since at that time there was only one card and it was non-reward
	--case when [Card Description] not in ('','') then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end as rewards_expense,
	([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense,
	case when TRIPFLAG = 'I' then 0.9 else 2.75 end as processing_cost
	into #temp_pre_6mo_3
	from TMGdata.[dbo].[cardholder]
	where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business')
	and fullExtractdate between (dateadd(month,-5,@staticpooldate)) and @staticpooldate
	and Durable_Key in (select Durable_Key from #temp1)
	
	--Pre 6 month Profit numbers_summary
	select Durable_Key,count(*) as N_months,
	sum(Interest_Income+fees+interchange_income- COF-chgoff_amt-visa_expense-processing_cost) as profit,
	avg(Utilization) as avg_Utilization,avg(revolve_rate) as avg_revolve_rate,avg(payment_rate) as avg_payment_rate
	into #temp_pre_6mo_3a
	from #temp_pre_6mo_3
	group by Durable_Key
		
	select a.*,
	b.profit as sum_profit_pre_6mo,b.profit/b.N_months as avg_profit_pre_6mo,
	b.avg_Utilization as avg_Utilization_pre_6mo,
	b.avg_revolve_rate as avg_revolve_rate_pre_6mo,
	b.avg_payment_rate as avg_payment_rate_pre_6mo
	into #temp_pre_6mo_4
	from #temp_pre_6mo_2 a
	left join #temp_pre_6mo_3a b
	on a.d_pre_6mo = b.Durable_Key

	
	---Step 3: post 12 month variables
	
	--drop table #temp2
	select a.*,b.*,c.*
	into #temp2
	from #temp1 a
	left join #temp_pre_12mo_4 b
	on a.Durable_Key = b.d_pre_12mo
	left join #temp_pre_6mo_4 c
	on a.Durable_Key = c.d_pre_6mo
	
	--Creating tranformed variables/bands
	select *
	into #temp3
	from #temp2
		
	select a.*
	into #temp6
	from #temp3 a	-- 42243
	
	
	select a.*
	into #temp7
	from #temp6 a
	
	select [Social Security Number],count(*) as cnt
	into #temp8
	from #temp7 
	group by [Social Security Number]
	having count(*) >= 2
	
	select a.*
	into #temp10
	from #temp6 a
	
	select a.*
	into #temp10c
	from #temp1 a
	
	
	select [Social Security Number] [SSN],count(*) as cnt
	into #temp10d
	from #temp10c
	group by [Social Security Number]
	having count(*) >= 2

	select *
	into #temp10e
	from #temp10c
	where [Social Security Number] not in 
	(select [SSN] from #temp10d)
	
	select a.*
	into #temp11
	from #temp10 a
	
	
	drop table if exists #Final_data_an
	select a.Durable_Key,[Last Statement Balance Amount] [Current Balance],Utilization_Static
	,isnull(Times_overlimit_pre_6mo,0) Times_overlimit_pre_6mo,isnull(Times_1_cycle_delq_pre_6mo,0) Times_1_cycle_delq_pre_6mo
	,isnull(avg_spend_pre_6mo,0) avg_spend_pre_6mo,isnull(avg_Utilization_pre_6mo,0) avg_Utilization_pre_6mo
	,avg_bal_pre_12mo,avg_Utilization_pre_12mo,[CL Static]
	--,isnull(Annual_Income,0) Annual_Income,isnull(Debt_Burden,0) Debt_Burden,isnull(FICO_score,0) FICO_score
	into #Final_data_an
	from #temp11 a 
		
		Drop table if exists #temp17
		select a.ACCOUNTNUMBER,b.PARENTACCOUNT,b.USERCHAR1,b.USERCHAR13
		into #temp17
		from (select *,DATEFROMPARTS(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) [Process Date] from ARCUSYM000..ACCOUNT) A
		left join ARCUSYM000..TRACKING b
		on a.ACCOUNTNUMBER = b.PARENTACCOUNT
		and a.ProcessDate = b.ProcessDate
		where a.[Process Date] =EOMONTH(@staticpooldate)
		and b.TYPE = 30
		and b.EXPIREDATE is null
		
		Drop table if exists #temp18
		select Durable_Key,a.[Master Account Key],a.[Account Number],format(cast(a.[Social Security Number] as int),'000000000') [Social Security Number]
		,a.[External Status Code],a.[Internal Status Code],a.[Card Description],a.[Account System Entry Date],
		a.[Credit Limit],a.extract_datepart,a.[Last Statement Balance Amount] [Balance as of Static]
		,b.PARENTACCOUNT,b.USERCHAR13
	   into #temp18
	   FROM TMGdata.[dbo].[cardholder] a
	   left join #temp17 b
	   on a.[Account Number] = b.USERCHAR1
	   where Active_Flag = 1 and [Card Description] not in ('Mastercard Business')
	   and [External Status Code] not in ('c','z') 
	   and fullExtractdate = @staticpooldate --'2020-08-01'--
	   and Durable_Key in (select Durable_Key from #Final_data_an group by Durable_Key)
	  -- select * from #temp18 where durable_key in(4274088, 6797646)
 
	-- Mapping Credit card 
	-- need to change the parentaccount info which should come from the previous temp 19 table not from name table
	DROP TABLE IF EXISTS #TMPName
	SELECT distinct N.SSN,N.FIRST,N.PARENTACCOUNT,N.LAST,N.FICO_score,N.BIRTHDATE,STREET,CITY,STATE,ZIPCODE
	INTO #TMPName
	FROM
	(
		SELECT PARENTACCOUNT,FIRST,LAST,BIRTHDATE,STREET,CITY,STATE,ZIPCODE
		,format(cast(N.SSN1 as int),'000000000') SSN,case when N.USERCHAR3_1 is null or N.USERCHAR3_1>1000 then 0 else N.USERCHAR3 end FICO_score
		 from
				(select *,datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) [Process Date]
				,TRY_PARSE(USERCHAR3 as int) USERCHAR3_1, TRY_PARSE(SSN as int)SSN1
				FROM ARCUSYM000.dbo.NAME) N
		LEFT JOIN ARCUSYM000.dbo.ACCOUNT A
			ON N.PARENTACCOUNT = A.ACCOUNTNUMBER AND N.ProcessDate = A.ProcessDate
		WHERE N.TYPE = 0 AND N.[Process Date] =EOmonth(@staticpooldate) 
		AND N.LAST <> 'NEW MEMBER' AND N.BIRTHDATE is not null AND N.SSNTYPE in (0,9) AND N.NAMEFORMAT = 0 AND A.CLOSEDATE is null
	) N where N.SSN in (select [Social Security Number] from #temp18)
	--    select * from #TMPName where SSN in (483068392,482082767)
	--select * from #TMPName where SSN =404414481
	--select * FROM ARCUSYM000.dbo.NAME where SSN= 404414481 and ProcessDate=20201031
	--select top 10  * from ARCUSYM000..TRACKING where UserChar3='404414481' and ProcessDate=20201031
	--select * FROM ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard where SSN_UserChar3='404414481' and ProcessDate=20201031
	--AND ExpireDate is null and ExternalStatus_UserChar8  in ('CLOSED','CHARGEOFF')
	  
	  Drop table if exists #ClosedChargeoff
	  SELECT C.PARENTACCOUNT,C.SSN_UserChar3 SSN_ARCU,TMGDurableKey_UserChar10 Durablekey
	 into #ClosedChargeoff
	 from (select *,datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) [Process Date]
	 FROM ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard) C
	 WHERE C.[Process Date] = EOmonth(@staticpooldate) AND C.ExpireDate is null and c.ExternalStatus_UserChar8  in ('CLOSED','CHARGEOFF') 
	
	Drop table if exists  #temp19
	SELECT distinct  C.[Social Security Number],Durable_Key,[Card Description], T.PARENTACCOUNT, N.BIRTHDATE,N.CITY,N.STATE,c.[Balance as of Static]
	,[Master Account Key],[Account Number],[External Status Code],[Internal Status Code],[Account System Entry Date]
	,N.ZIPCODE,upper(left(N.FIRST,1))+lower(substring(N.FIRST,2,len(N.FIRST)-1)) FIRST
	,upper(left(N.last,1))+lower(substring(N.LAST,2,len(N.LAST)-1)) LAST,datediff(year,N.BIRTHDATE,getdate()) AGE,case when isnumeric(N.FICO_score)=1 then N.FICO_score else 0 end FICO_score
	 ,N.ssn,Lower(N.STREET) STREET,upper(left(N.[City],1))+lower(substring(N.[City],2,len(N.[City])-1)) as City_2,N.STATE as STATE_2,N.ZIPCODE as ZIPCODE_2
	into #temp19
	FROM #temp18 C
	LEFT JOIN (select * from(select *,datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) [Process Date] from ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard) JJ
	where [Process Date]=eomonth(@staticpooldate)) T
		ON (T.TMGDurableKey_UserChar10 = C.Durable_Key OR (TMGDurableKey_UserChar10 is null and T.SSN_UserChar3 = C.[Social Security Number]))
		AND T.[Process Date] = EOmonth(@staticpooldate)
	left join #ClosedChargeoff F on c.[Social Security Number]=F.SSN_ARCU
	LEFT JOIN #TMPName N
	ON N.SSN = T.SSN_UserChar3 and n.PARENTACCOUNT=t.PARENTACCOUNT
	where  T.ExpireDate is null	AND (T.ExternalStatus_UserChar8 is null) and F.SSN_ARCU is null
	--select * from #temp19 where  [Social Security Number]=404414481
	--select Durable_Key,count(*) from #temp19 group by Durable_Key having count(*)>1
	--select distinct  * from #temp19 where PARENTACCOUNT= 0051030100 0014140343   
	--select * from ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard where PARENTACCOUNT= 0051030100 and ProcessDate=20201031
	-- select * from #tmpname where PARENTACCOUNT= 0051030100 
	--  select * from #ClosedChargeoff where PARENTACCOUNT= 0051030100 
	--  select * from  #temp1 where durable_key=6797646
--4274088

			
	 
	 Drop table if exists #Processdate
	 select Process_date,max(ProcessDate) MAX_ProcessDate 
		into #Processdate
		from
			(
			select ProcessDate,left(ProcessDate,6) Process_date
			,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
			from ARCUSYM000..NAME group by ProcessDate
			) A 
			where [Process date] between dateadd(month,-12,@staticpooldate) and @staticpooldate
			group by Process_Date
			order by Process_Date
	
	 Drop table if exists #QFICO
	  select [Process date],case when [Process date]=@newdate then 'Static'
				when [Process date] between dateadd(month,-3,@newdate) and DATEADD(month,-1,@newdate) then 'Q1'
				when [Process date] between dateadd(month,-6,@newdate) and DATEADD(month,-4,@newdate) then 'Q2'
				when [Process date] between dateadd(month,-9,@newdate) and DATEADD(month,-7,@newdate) then 'Q3'
				when [Process date] between dateadd(month,-12,@newdate) and DATEADD(month,-10,@newdate) then 'Q4'
				end as Quarterly,a.PARENTACCOUNT,SSN
				,FICO_score FICO
				into #QFICO
				from 
					(
					SELECT PARENTACCOUNT,FIRST,LAST,BIRTHDATE,STREET,CITY,STATE,ZIPCODE,[Process Date]
					,format(cast(N.SSN1 as int),'000000000') SSN,case when N.USERCHAR3_1 is null or N.USERCHAR3_1>1000 then 0 else N.USERCHAR3 end FICO_score
					 from
							(select *,datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) [Process Date]
							,TRY_PARSE(USERCHAR3 as int) USERCHAR3_1, TRY_PARSE(SSN as int)SSN1
							FROM ARCUSYM000.dbo.NAME) N
					LEFT JOIN ARCUSYM000.dbo.ACCOUNT A
						ON N.PARENTACCOUNT = A.ACCOUNTNUMBER AND N.ProcessDate = A.ProcessDate
					WHERE N.TYPE = 0 AND N.ProcessDate in (select MAX_ProcessDate from #Processdate where right(left(MAX_ProcessDate,6),2) in (3,6,9,12) )
					AND N.LAST <> 'NEW MEMBER' AND N.BIRTHDATE is not null AND N.SSNTYPE in (0,9) AND N.NAMEFORMAT = 0 AND A.CLOSEDATE is null
					and parentaccount in (select PARENTACCOUNT from #temp19)
					) A
						
						
		--select * from #QFICO where SSN=482082767
		Drop table if exists #QuarterlyFICO				
		select 
		PARENTACCOUNT,max([Static]) [Static],max([Q1])[Q1],max([Q2])[Q2] ,max([Q3])[Q3] ,max([Q4])[Q4] --,max([2020Q-1]) [2020Q-1],Max([2020Q-2]) [2020Q-2]
		Into #QuarterlyFICO
		from	(
			select * from #QFICO
			) S
		Pivot
		(
		max(FICO) 
		for Quarterly in ([Static],[Q1],[Q2],[Q3],[Q4])
		--(select Quarterly from #QFICO group by Quarterly)
		) as PIVOT_table
		group by PARENTACCOUNt
		order by PARENTACCOUNT
		--select * from #QFICO where SSN=482082767
		--select * from #QuarterlyFICO where parentaccount=0014140343	 
		drop table if exists #FICDRIFT
		select PARENTACCOUNT,case when (FICO_Staticpool is null or Q1 is null) then 0 else  FICO_Staticpool-[Q1] end as Static_FICO_Q1
		,case when (FICO_Staticpool is null or [Q2] is null) then 0 else FICO_Staticpool-[Q2] end as Static_FICO_Q2
		,case when (FICO_Staticpool is null or [Q3] is null) then 0 else FICO_Staticpool-[Q3] end as Static_FICO_Q3
		,case when (FICO_Staticpool is null or [Q4] is null) then 0 else FICO_Staticpool-[Q4] end as Static_FICO_Q4
		,case when ([Q1] is null or [Q2] is null) then 0 else [Q1]-[Q2] end as Q1_FICO_Q2
		,case when ([Q1] is null or [Q3] is null) then 0 else [Q1]-[Q3] end as Q1_FICO_Q3 
			into #FICDRIFT
			from 
				(select a.PARENTACCOUNT,cast([Q1] as int) [Q1],cast([Q2] as INT) [Q2],cast([Q3] as int) [Q3]
				,cast([Q4] as int) [Q4],cast(b.FICO_score as INT) FICO_Staticpool
				From #QuarterlyFICO a left join (select parentaccount,FICO_score from #temp19) b on a.PARENTACCOUNT=b.PARENTACCOUNT
				) a  
		-- select * from #FICDRIFT where parentaccount=0051030100
		--  select * from #temp19 where parentaccount=0051030100
		--  select * from #tmpname where parentaccount=0051030100
	  --flag HELOC 2019 Vs 2020 Pendemic time till now
	  drop table if exists #LOC
	  select PARENTACCOUNT,Sum(BALANCE) LOC_BALANCE,b.LOC
	  into #LOC
	  from		  
				  (select * ,case when opendate=closedate then 0 else 1 end Flag
				  ,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date then 1 else 0 end Open_Flag
				  from								
													(
													select * ,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
													else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
													,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
													else concat(year(opendate),month(opendate)) end Open_date
													,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
													else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
													,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
													,left(ProcessDate,6) Process_date
													from ARCUSYM000..loan where PARENTACCOUNT in (select PARENTACCOUNT from #temp19) and BALANCE>0
													) AA
				  where  ORIGINALDATE is not null and OpenDate is not null and aa.[Process Date] between dateadd(month,-6,@staticpooldate) and @staticpooldate
				  ) A 
		  left join					(select *,case when (LoanCategory4='LOC' or LoanCategory4 like '%HEL%') then 1 else 0 end LOC
									,case when LoanCategory2='Personal' and LoanCategory3='Unsecured' then 'Personal_Unsecured'
									when LoanCategory2='Personal' and LoanCategory3='Secured' then 'Personal_Secured'
									when LoanCategory4 like '%1st %' then 'Mortgage'
									when LoanCategory4 like '%HEL%' then 'HELOC'
									when LoanCategory4 in ('Piggyback Balloon','Workout/TDR','Writeoff') then 'Other RealEstate'
									when LoanCategory4='Vehicle' then 'Vehicle' else LoanCategory2 end Loan_category from ARCUSYM000.arcu.ARCULoanCategory) b
		  on a.TYPE=b.LoanType
		  where  Flag=1 and Open_Flag=1 and b.loc=1
		  group by PARENTACCOUNT,b.LOC
	  
	  
		drop table if exists #Overdraft
		select 
		PARENTACCOUNT,sum([# Overdraft]) [# Overdraft]
		,sum(Overdraft_fee) [Overdraft fee]
		into #Overdraft
		from
				(select 
				ProcessDate,PARENTACCOUNT,sum(Overdraft_fee) Overdraft_fee,sum(Overdraft_count) [# Overdraft]
				from
						(
						select 
						*,case when Overdraft_fee>0 then 1 else 0 end Overdraft_count
						from
								(
								select 
								*,isnull(case when OVERDRAFTFEEYTD>0 then lead_overdraft-OVERDRAFTFEEYTD else 0 end,0) Overdraft_fee
								from 
										( select ProcessDate,PARENTACCOUNT,ID,TYPE
										,BALANCE
										,case when OPENDATE=CLOSEDATE then 0 else 1 end FLag ,OVERDRAFTFEELASTYR,OVERDRAFTTOLERANCE
										,overdraftfeeytd,LEAD(overdraftfeeytd,1) over(partition by PARENTACCOUNT,ID,TYPE,year_ order by PARENTACCOUNT,ID,ProcessDate) lead_overdraft
										,CHARGEOFFDATE,OPENDATE,closedate
										,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
										from 
												(select * ,left(ProcessDate,4) year_ from ARCUSYM000..SAVINGS  
												) A
										) B
								where  CHARGEOFFDATE is null and OpenDate is not null and CLOSEDATE is null and flag=1
								and [Process date] between dateadd(month,-6,@staticpooldate) and @staticpooldate
								and PARENTACCOUNT in (select PARENTACCOUNT from #temp19)
								) A
						) D
						group by ProcessDate,PARENTACCOUNT
				) F
				where [# Overdraft] >0
				group by PARENTACCOUNT
		
				Drop table if exists #Unemployment
				select 
				a.PARENTACCOUNT,1 Unemployment,sum(BALANCECHANGE) Amount
				into #Unemployment
				from 
				(
				select PARENTACCOUNT,PARENTID,EFFECTIVEDATE,SEQUENCENUMBER-1 as SEQUENCENUMBER,COMMENT
				, case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE)) 
				else  CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVE_DATE from ARCUSYM000..SAVINGSTRANSACTION
				where COMMENT like '%TYPE: UNEMPLOYME  CO: ST OF IA-UI PAY%' and EFFECTIVEDATE between dateadd(month,-6,@staticpooldate) and @staticpooldate
				) A 
				left join 
				(
				select PARENTACCOUNT,PARENTID,EFFECTIVEDATE,SEQUENCENUMBER,COMMENT,BALANCECHANGE
				, case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE)) 
				else  CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVE_DATE from ARCUSYM000..SAVINGSTRANSACTION
				where EFFECTIVEDATE between dateadd(month,-6,@staticpooldate) and @staticpooldate
				) b
				on a.PARENTACCOUNT=b.PARENTACCOUNT and a.PARENTID=b.PARENTID
				and a.EFFECTIVEDATE=b.EFFECTIVEDATE and a.SEQUENCENUMBER=b.SEQUENCENUMBER
				where a.PARENTACCOUNT in (select PARENTACCOUNT from #temp19)
				group by a.PARENTACCOUNT
				-- flag 
				drop table if exists #temp20
				select a.PARENTACCOUNT,isnull(D.Unemployment,0) Unemployment
				,C.LOC_BALANCE,C.LOC,B.[# Overdraft] 
				into #temp20 
				from #temp19 a
				left join #Overdraft B on a.PARENTACCOUNT=b.PARENTACCOUNT
				left join #LOC C on a.PARENTACCOUNT=C.PARENTACCOUNT
				left join #Unemployment D on a.PARENTACCOUNT=D.PARENTACCOUNT
				group by a.PARENTACCOUNT,D.Unemployment,C.LOC_BALANCE,C.LOC,B.[# Overdraft]
				
	
	
	Drop table if exists #ALL_master
	select SSN,AVG_Month_end_balance_Total_Deposit_ACCT
	 into #ALL_master from ##masterdata

	 drop table if exists #tempcreditcard

	select distinct 
	@staticpooldate Extractdate,
	a.PARENTACCOUNT, a.Durable_Key,a.[Current Balance],a.Times_overlimit_pre_6mo,a.Times_1_cycle_delq_pre_6mo,a.avg_spend_pre_6mo,a.avg_Utilization_pre_6mo,a.avg_Utilization_pre_12mo
	,isnull(Unemployment,0) Unemployment,LOC_BALANCE,isnull(LOC,0) [Line Of Credit],isnull([# Overdraft],0) [# Overdraft],AVG_Month_end_balance_Total_Deposit_ACCT,b.Static_FICO_Q1
	,FICO_score, b.Static_FICO_Q2,avg_bal_pre_12mo,Utilization_Static,[CL Static]
	,case when Times_1_cycle_delq_pre_6mo>0 then '1. Severe'
	when Times_1_cycle_delq_pre_6mo<=0 and Times_overlimit_pre_6mo>0 then '2. High'
	when Times_1_cycle_delq_pre_6mo<=0 and Times_overlimit_pre_6mo<=0 and avg_Utilization_pre_6mo<=0.827 then '4. Low'
	when Times_1_cycle_delq_pre_6mo<=0 and Times_overlimit_pre_6mo<=0 and avg_Utilization_pre_6mo>0.827 and AVG_Month_end_balance_Total_Deposit_ACCT<=204 then '3. Moderate'
	when Times_1_cycle_delq_pre_6mo<=0 and Times_overlimit_pre_6mo<=0 and avg_Utilization_pre_6mo>0.827 and AVG_Month_end_balance_Total_Deposit_ACCT>204 then '4. Low'
	end Segments
	,[Social security number],[Master Account Key] [Card number],[card description],Age,City_2 City,STATE_2 State,ZIPCODE_2 Zipcode,First [First Name],Last [Last Name]
	into #tempcreditcard

	from
		( select c.PARENTACCOUNT,a.*,b.[Social security number],b.[Master Account Key],b.[card description],b.Age,b.City_2,b.STATE_2,b.ZIPCODE_2,b.FIRST,b.LAST
		,isnull(AVG_Month_end_balance_Total_Deposit_ACCT,0) AVG_Month_end_balance_Total_Deposit_ACCT,c.[# Overdraft],c.LOC,c.LOC_BALANCE,c.Unemployment,FICO_score 
		 from #Final_data_an A
			left join (select k.*,l.AVG_Month_end_balance_Total_Deposit_ACCT from #Temp19 k left join #ALL_master l on k.[Social security number]=l.SSN) B
			on a.durable_key=b.durable_key
			left join #temp20 C on b.PARENTACCOUNT=c.PARENTACCOUNT
			) A
		left join #FICDRIFT b on a.PARENTACCOUNT=b.PARENTACCOUNT

		delete from #tempcreditcard
	where PARENTACCOUNT is null
	

				 
drop table if exists #temp
Select COUNT(*) as cnt into #temp   from #tempcreditcard

 drop table if exists #temp22
 Select row_number() over (order by [Current Balance]) as srno,[Current Balance] into #temp22 from #tempcreditcard order by 1 
 

 Declare @f as int
 
Set @f = (Select [Current Balance] from #temp22 where srno in ( select round((cnt+1)*0.99,0)  from #temp))



drop table if exists #tempcreditcard2 
Select *,case when [Current Balance] > @f then @f else [Current Balance] end as newcurrentbalance into #tempcreditcard2  from #tempcreditcard


declare @z as float
Set @z = (select MAX(newcurrentbalance) from #tempcreditcard2 )

declare @y as float
Set @y = (select Min(newcurrentbalance) from #tempcreditcard2 )

Drop table if exists #tempcreditcard3

Select * ,
((newCurrentBalance - @y)/(@z-@y))*40 as Scaler
,(1-((@z-newCurrentBalance)/@z))*40 as Scaler2
into #tempcreditcard3
from #tempcreditcard2

Drop table if exists analytics.dbo.[PDQTriggerCreditCardTargetListTable] 

Select * ,
Case when Segments = '1. Severe' then Round(60 + Scaler,2)
  when SegmentS = '2. High' then Round(50 + Scaler,2)
  when SegmentS = '3. Moderate' then Round(25 + Scaler,2)
  when Segments = '4. Low' then Round(10 +Scaler,2)
   end as final_score
 into analytics.dbo.[PDQTriggerCreditCardTargetListTable] 
from #tempcreditcard3
order by final_score Desc,[Current Balance] DESC

end

exec [dbo].[PDQTriggerCreditCardTargetList] 

select * from analytics.dbo.[PDQTriggerCreditCardTargetListTable] order by final_score Desc





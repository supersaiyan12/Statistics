-- Static pool date ---
--select * from arcusym000.arcu.arculoancategory
--where loancategory4='Writeoff'
-- order by loantype
  --rewrite logic for chargeoff



declare @staticpooldate date
		declare @staticpooldate2 date
		declare @staticpooldate3 date
		set  @staticpooldate= (select datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Processdate from
	(select max(ProcessDate) processdate from ARCUSYM000.dbo.LOAN) A)
set  @staticpooldate2 = (Select case when @staticpooldate = EOMONTH(@staticpooldate) then @staticpooldate else EOmonth(DATEADD(Month,-1,@staticpooldate)) end)
set  @staticpooldate3 = (select dateadd(month,-35,@staticpooldate2))

declare @creditcarddate date
set @creditcarddate =  (Select max(fullExtractdate) from TMGData.dbo.cardholder) 

--select distinct extract_datepart, fullExtractdate from tmgdata.dbo.cardholder order by extract_datepart
drop table if exists #processdate
select process_date,max(ProcessDate) max_ProcessDate,max([process date]) [process date]
into #processdate
		from (select ProcessDate,left(ProcessDate,6) process_date ,datefromparts(left(processdate,4),right(left(processdate,6),2),RIGHT(processdate,2)) [process date]
				from ARCUSYM000.dbo.loan) A
where [process date]>=@staticpooldate3 and [process date]<=@staticpooldate2
group by process_date

--select * from #processdate order by max_ProcessDate
--select distinct [Process date] from Rollratetracker_13Month_compare order by [process date]

--select distinct loancategory1,loancategory2,loancategory3 from #LoanStatic order by loancategory3
--Loan Static of one month back -- 
	
	drop table if exists #LoanStatic
	select *
	into #LoanStatic
	from
	(
	select 
		[ProcessDate],[Process date],[Process_date],[PARENTACCOUNT],concat(PARENTACCOUNT,ID) UNID,ID
		,LoanCategory4 Loan_Categories
		,case when LoanCategory3='Indirect' then 'Indirect' else 'Direct' END Direct_indirect
		,LoanCategory2 LoanCategory1,LoanCategory3 LoanCategory2,
		case when loantypedescription like '%otb%' then Concat(loancategory4,' - OTB')  --OTB
		when loantypedescription like '%gll%' then Concat(loancategory4,' - GLL- (GreenLight)')   --GreenLight
		 else LoanCategory4 end  LoanCategory3,LoanTypeDescription, BALANCE
		from
			(
			select *,CONCAT(PARENTACCOUNT,ID) UNID
			,case when opendate=closedate then 0 else 1 end Flag
			,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date 
			then 1 else 0 end Open_Flag
			,DATEDIFF(month,OPENDATE,@staticpooldate2) MOB	-- add the @Staticpooldate
			,DATEDIFF(month,OPENDATE,MATURITYDATE) Loan_Term
			,DATEDIFF(month,@staticpooldate2,MATURITYDATE) Month_to_Maturity
				from 
					(select *
					,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
					else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
					,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
					else concat(year(opendate),month(opendate)) end Open_date
					,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
					else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
					,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
					,left(ProcessDate,6) Process_date
					from ARCUSYM000.dbo.LOAN
					where ProcessDate in (select max_ProcessDate from #processdate)
					) H
				where  ORIGINALDATE is not null and OpenDate is not null 
				and CLOSEDATE is null
				-- and CHARGEOFFDATE is null
				and [Process date] between @staticpooldate3 and @staticpooldate2    -- DATEADD(month,-1,@staticpooldate2)		-- Later give the @staticpooldate date here 
				and MATURITYDATE> @staticpooldate2      -- DATEADD(month,-1,@staticpooldate2)	-- add 3 month in currrent date
			) A
				left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
				on b.loantype=a.TYPE
				where Flag=1 and Open_Flag=1 
							         --AND b.loancategory4 not in ('writeoff','Workout/TDR') 
									  and b.LoanCategory1 in ('Consumer')

				) D
				order by PARENTACCOUNT,ProcessDate
				--select distinct [process date] from #LoanStatic
				--select top 10 PAYMENTSKIPS  from 		 ARCUSYM000.dbo.LOAN where PAYMENTSKIPS>1
				--select distinct PARENTACCOUNT,id ORIGINALBALANCE  from 		 ARCUSYM000.dbo.LOAN
				--select distinct loancategory2,loancategory3,loancategory4, LoanTypeDescription from  [ARCUSYM000].[arcu].[ARCULoanCategory] order by loancategory2
			
			
				----------Bankrupcy Data add
				--select top 1 * from loan
drop table if exists #tempBankrupcy
select  
        L.PARENTACCOUNT+'-'+L.ID "LoanID" ,L.PARENTACCOUNT,
		L.ID
       ,L.OPENDATE 
       ,L.CHARGEOFFDATE 
       ,FM.POSTDATE "BK Note Date" 
       ,B.BankruptcyCaseNumber_UserChar1 
       ,B.FilingDate_UserDate1 
       ,B.DischargeDate_UserDate2 
       ,B.DismissDate_UserDate5 
       ,B.ReaffirmationDate_UserDate3 
       ,B.DateConverted_UserDate6 
       ,coalesce(B.FilingDate_UserDate1,FM.postdate) "BK Start" -- *** If 2 t 
,coalesce(L.CHARGEOFFDATE,dischargedate_userdate2,B.dismissdate_UserDate5,B.reaffirmationdate_UserDate3,l.closedate) "BK End" ---Order is important 
---select top 10 * from #tempBankrupcy
into #tempBankrupcy
from ARCUSYM000.dbo.loan L 
left join ARCUSYM000.dbo.FMHISTORY FM 
       on FM.PARENTACCOUNT = L.PARENTACCOUNT 
	          AND FM.ID = L.ID 
	          AND FM.NEWNUMBER = 4.99 
	          AND FM.FMTYPE = 1 
	          AND FM.FIELDNUMBER = 17 
	   join ARCUSYM000.arcu.arculoancategory C 
	          on C.loantype = L.type 
			         AND C.loancategory4 not in ('writeoff','Workout/TDR') and c.LoanCategory1 in ('Consumer')
					 left join ARCUSYM000.tracking.tvwARCUTRACKINGBankruptcy B 
					        on B.PARENTACCOUNT = L.PARENTACCOUNT 
							       AND B.ProcessDate = L.ProcessDate 
								          AND B.CreationDate > L.OPENDATE 
										  where l.ProcessDate in (select max_ProcessDate from #processdate)
										         AND L.APPROVALCODE = 499 
--select * from #tempBankrupcy
			drop table if exists #tempBKFinal
			select Distinct [BK Note Date], [BK Start],
			loanid,PARENTACCOUNT,ID,left(cast(convert(varchar(20),[BK Start],112) as int),6) BK_Start ,
			 left(cast(convert(varchar(20),[BK End],112) as int),6) BK_End 
			 , case when [BK Start]='1900-01-01 00:00:00' then [BK Note Date] else [BK Start] END BK_Start_Final
			 into #tempBKFinal
			 from #tempBankrupcy order by [BK Start]
			 
			drop table if exists #test
			 select [BK Note Date], [BK Start],BK_Start,
			LoanID,ID,PARENTACCOUNT, left(cast(convert(varchar(20),[BK_Start_Final],112) as int),6) BK_Start_Final1, BK_End
			into #Test
			  from #tempBKFinal 
			  --select *  from #tempBKFinal where parentaccount=0013500716
			 -- select *  from #test where BK_End is null
			  
			  
			  drop table if exists #test1
			  select [BK Note Date], [BK Start],BK_Start,
			LoanID,ID,PARENTACCOUNT,BK_Start_Final1
			,case when BK_End is null then  left(cast(convert(varchar(20),GETDATE(),112) as int),6)  else BK_End end BK_End1
			into #Test1
			  from #test
			  --select * from #test1 where BK_end1=202104
			drop table if exists #test2
			select PARENTACCOUNT, LoanID , ID,min(eomonth(concat(left(BK_Start_Final1 ,4),'-',right(BK_Start_Final1,2),'-01'))) as BK_Start_Final1_EOM
			,max(eomonth(concat(left(BK_End1 ,4),'-',right(BK_End1,2),'-01'))) as BK_End_EOM 
			into #test2
			from #Test1
			where 1=1
			-- BK_Start_Final1 between '201901' and '202012' 
			and BK_Start_Final1 < BK_End1
			group by PARENTACCOUNT, LoanID , ID
			--select * from #test2
			--isnull( BK_End , '299912') 
			--or BK_End='190001'
		--	 select * from #tempBKFinal order by PARENTACCOUNT,LoanID
			 
			 --select * from #loanDelinquency1 where BankruptcyCount >1
			
	-- Deliquency in last month (Previous Month Del calculation) ---


--	declare @staticpooldate date
--		declare @staticpooldate2 date
--	declare @staticpooldate3 date
--		set  @staticpooldate= (select datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Processdate from
--	(select max(ProcessDate) processdate from ARCUSYM000.dbo.LOAN) A)
--set  @staticpooldate2 = (Select case when @staticpooldate = EOMONTH(@staticpooldate) then @staticpooldate else EOmonth(DATEADD(Month,-1,@staticpooldate)) end)
--set  @staticpooldate3 = (select dateadd(month,-24,@staticpooldate2))

		drop table if exists #loanDelinquency1
		select processdate,Process_date,[Process Date],AccountNumber,LoanID,Cycle1,Cycle2,Cycle3,Cycle4,cycle5,Cycle6,cycle7,cycle8
		,loanchargeoff,LoanType,loancategory2,
		LoanTypeDescription,
		BankruptcyCount
		into #loanDelinquency1
		from
		 (
				 select 
				Convert(date, cast(l.Processdate as nvarchar)) as Date, l.ProcessDate,left(l.ProcessDate,6) Process_date,
				AccountNumber,l.LoanID,l.LoanOpenDate,LoanDelqDays,datefromparts(left(l.ProcessDate,4),left(right(l.ProcessDate,4),2),right(l.ProcessDate,2)) [Process Date]
				,case when LoanDelqDays between 1 and    29  and l.loanchargeoffdate is null then 1 else 0  end Cycle1 
				,case when LoanDelqDays between 30 and  59  and l.loanchargeoffdate is null then 1 else 0 end  Cycle2 
				,case when LoanDelqDays between 60 and  89  and l.loanchargeoffdate is null then 1 else 0 end  Cycle3 
				,case when LoanDelqDays between 90 and  119 and l.loanchargeoffdate is null then 1 else 0 end   Cycle4 
				,case when LoanDelqDays between 120 and 149 and l.loanchargeoffdate is null then 1 else 0 end   Cycle5 
				,case when LoanDelqDays between 150 and 179 and l.loanchargeoffdate is null then 1 else 0 end   Cycle6 
				,case when LoanDelqDays between 180 and 359 and l.loanchargeoffdate is null then 1 else 0 end   Cycle7 
				,case when LoanDelqDays >= 360 and l.loanchargeoffdate is null then 1 else 0 end Cycle8 
				,case when l.LoanChargeoffDate is not null then 1 else 0 end loanchargeoff
				,loancategory2,LoanPastDueAmount,LoanBalance,l.LoanChargeoffDate,l.LoanType, 
				alc.LoanTypeDescription, 
				--Count(t.locator) as BankruptcyCount 
				max(case when datefromparts(left(l.ProcessDate,4),left(right(l.ProcessDate,4),2),right(l.ProcessDate,2)) 
				between AA.BK_Start_Final1_EOM and AA.BK_End_EOM then 1 else 0 end) BankruptcyCount
								from arcusym000.arcu.ARCULoanDetailed  as l
						left join arcusym000.arcu.ARCULoanCategory as alc on alc.LoanType = l.LoanType
						left join ARCUSYM000.dbo.tracking as t on t.processdate = l.ProcessDate and t.PARENTACCOUNT = l.AccountNumber 
						and t.TYPE = 36 and (t.EXPIREDATE is null or t.EXPIREDATE < Convert(date, cast(t.processdate as varchar)))
						left join #test2 AA on l.AccountNumber = AA.PARENTACCOUNT and 
						--left(l.ProcessDate,6)= AA.BK_Start_Final1 and 
						l.LoanID=AA.ID
				where LoanDelqDays > 0 
				and datefromparts(left(l.ProcessDate,4),left(right(l.ProcessDate,4),2),right(l.ProcessDate,2)) between @staticpooldate3 and @staticpooldate2
				and l.ProcessDate in (select max_ProcessDate from #processdate)
				and l.AccountNumber in (select PARENTACCOUNT from #LoanStatic group by PARENTACCOUNT)
				group by l.ProcessDate,l.AccountNumber,l.LoanID,l.LoanOpenDate,l.LoanPastDueAmount,l.LoanChargeoffDate
				,l.LoanType,
				alc.LoanTypeDescription,
				 l.LoanDelqDays, LoanBalance, loancategory2
		) A
		order by AccountNumber,LoanID,ProcessDate
		
	
		/*
		select * from #loanDelinquency1
		left join
				
		select  parentaccount, id , postdate,olddate,newdate
		from arcusym000.dbo.fmhistory
		where recordtype=10 and fieldnumber=37 and parentaccount=0014873069
		and newdate<olddate 
		order by postdate
		*/

		--select  * from arcusym000.dbo.fmhistory where parentaccount='0014873069'
			--	select * from arcusym000.arcu.ARCULoanDetailed where AccountNumber=0014873069 and loanid=0001
		

	--	select * from  #loanDelinquency1 where loanchargeoff=1
		---Validation for Bankrupcy 
	
	/*	select  distinct AccountNumber 
		from
		#loanDelinquency1
		where AccountNumber not in( select distinct AccountNumber from #loanDelinquency1 where BankruptcyCount=1) */
		-- where AccountNumber='0014174318' order by 3
	--	select * from #test1 where PARENTACCOUNT='0014177528'
		--select * from #test1 where PARENTACCOUNT='0013632056'
		--		select processdate,count(*) from #loanDelinquency1 group by processdate

---- Deliquency in this month (Current month Del calculation) ---
--		drop table if exists #loanDelinquency2
--		select processdate,Process_date,AccountNumber,LoanID,Cycle1,Cycle2,Cycle3,Cycle4,cycle5,Cycle6,cycle7,Cycle8,loanchargeoff,LoanType,loancategory2,LoanTypeDescription
--		into #loanDelinquency2
--		from
--		 (
--				 select 
--				Convert(date, cast(l.Processdate as nvarchar)) as Date, l.ProcessDate,left(l.ProcessDate,6) Process_date,
--				AccountNumber, 
--				LoanID, 
--				l.LoanOpenDate, 
--				LoanDelqDays,
--				case when LoanDelqDays between 1 and    29  and l.loanchargeoffdate is null then 1 else 0  end Cycle1 
--				,case when LoanDelqDays between 30 and  59  and l.loanchargeoffdate is null then 1 else 0 end  Cycle2 
--				,case when LoanDelqDays between 60 and  89  and l.loanchargeoffdate is null then 1 else 0 end  Cycle3 
--				,case when LoanDelqDays between 90 and  119 and l.loanchargeoffdate is null then 1 else 0 end   Cycle4 
--				,case when LoanDelqDays between 120 and 149 and l.loanchargeoffdate is null then 1 else 0 end   Cycle5 
--				,case when LoanDelqDays between 150 and 179 and l.loanchargeoffdate is null then 1 else 0 end   Cycle6 
--				,case when LoanDelqDays between 180 and 359 and l.loanchargeoffdate is null then 1 else 0 end   Cycle7 
--				,case when LoanDelqDays >= 360 and l.loanchargeoffdate is null then 1 else 0 end Cycle8 
--				,case when l.LoanChargeoffDate is not null then 1 else 0 end loanchargeoff
--				,loancategory2
--				,LoanPastDueAmount, 
--				LoanBalance, 
--				l.LoanChargeoffDate, 
--				l.LoanType, 
--				alc.LoanTypeDescription, 
--				Count(t.locator) as BankruptcyCount 
--				from arcusym000.arcu.ARCULoanDetailed  as l
--						left join arcusym000.arcu.ARCULoanCategory as alc on alc.LoanType = l.LoanType
--						left join ARCUSYM000.dbo.tracking as t on t.processdate = l.ProcessDate and t.PARENTACCOUNT = l.AccountNumber 
--						and t.TYPE = 36 and (t.EXPIREDATE is null or t.EXPIREDATE < Convert(date, cast(t.processdate as varchar)))
--				where LoanDelqDays > 0 
--				and datefromparts(left(l.ProcessDate,4),left(right(l.ProcessDate,4),2),right(l.ProcessDate,2)) = @staticpooldate2
--				and l.AccountNumber in (select PARENTACCOUNT from #LoanStatic group by PARENTACCOUNT)
--				group by l.ProcessDate,l.AccountNumber,l.LoanID,l.LoanOpenDate,l.LoanPastDueAmount,l.LoanChargeoffDate
--				,l.LoanType,alc.LoanTypeDescription, l.LoanDelqDays, LoanBalance,alc.loancategory2
--		) A
--		order by AccountNumber,LoanID,ProcessDate,LoanTypeDescription

--select * from #tracking where loanchargeoff=1
		
-- Mortgage Data --
 drop table if exists #Tracking
		select parentaccount,ID,(USERCHAR1) USERCHAR1,EXPIREDATE,ProcessDate,left(ProcessDate,6) Process_Date 
		into #Tracking
		from (select * from
					(select *,case when isnumeric(USERCHAR1)=1 then USERCHAR1 else null end Mortgage_id ,len(USERCHAR1) Mortgage_id_len
					from ARCUSYM000.dbo.TRACKING where ProcessDate in (select max_ProcessDate from #processdate) and TYPE='35'
					) AA
		where Mortgage_id is not null and Mortgage_id_len=10 and Mortgage_id in (select Mortgageid from AE_EDW.dbo.F_Mortgage_Daily where AsOfDate in (select [process date] from #processdate))
		--where Mortgage_id is not null and Mortgage_id_len=10 and Mortgage_id in (select * from openquery([GSDWSQL01],'SELECT * FROM 

		) A
		where datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2))
		between @staticpooldate3 and @staticpooldate2
		-- dateadd(month,-1,CONCAT(left(@staticpooldate2,4),left(right(@staticpooldate2,5),2),right(@staticpooldate2,2))) 
		group by parentaccount,ID,USERCHAR1,EXPIREDATE,ProcessDate

		--Add Mortgage description and clear out the error of loantypedescription
		drop table if exists #Mortgage
		select  b.parentaccount,
		a.*,case when Extractdate=Opendate then 1 else 0 end New_flag,d.MortgageOriginalBalance orignalbalance
		into #Mortgage
		from (select case when len(month(AsOfDate))=1 then concat(year(AsOfDate),0,month(AsOfDate)) else concat(year(AsOfDate),month(AsOfDate)) end Extractdate
				,case when len(month(MortgageOpenDate))=1 then concat(year(MortgageOpenDate),0,month(MortgageOpenDate)) else concat(year(MortgageOpenDate),month(MortgageOpenDate)) end Opendate
				,* from AE_EDW.dbo.F_Mortgage_Daily where AsOfDate in (select [process date] from #processdate)
				) A 
		left join #Tracking b
		on a.mortgageid=b.USERCHAR1 and a.Extractdate=b.Process_Date
		left join AE_EDW.dbo.D_Mortgage d on a.mortgageid=d.MortgageID
		where CoreMortgageStatus='Active' and AsOfDate between @staticpooldate3 and @staticpooldate2 and
		 b.EXPIREDATE is null  
--		 select * from #tracking
--		 select * from #Mortgage
		-- select AsOfDate,count(*),count(distinct MortgageID) from #Mortgage group by AsOfDate order by AsOfDate
--Mortgage Deliquency ---
		Drop table if exists #mortgagedelinquency1
		Select *
		into #mortgagedelinquency1
		from 
		(
		SELECT 
        case when datediff(d, h.duedate, DateAdd(month, -1, eomonth(cutoffdate)))  < 30 then 'New' end New30Flag
		,case when datediff(d, h.duedate, DateAdd(month, -1, eomonth(cutoffdate)))  between 30 and 60 then 'New' end New61Flag
                ,h.loanid,InvestorID MortgageDescription
	,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and datediff(d, h.duedate, eomonth(cutoffdate)) < 30 then 1 else 0  end [DQ 1+ Days Flag]
    ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 30 and datediff(d, h.duedate, eomonth(cutoffdate)) < 60 then 1 else 0  end [DQ 30+ Days Flag]
    ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 60 and datediff(d, h.duedate, eomonth(cutoffdate)) < 90 then 1 else 0  end [DQ 60+ Days Flag]
	,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 90 and datediff(d, h.duedate, eomonth(cutoffdate)) < 120 then 1 else 0  end [DQ 90+ Days Flag]
	,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 120 and datediff(d, h.duedate, eomonth(cutoffdate)) < 150 then 1 else 0  end [DQ 120+ Days Flag]
    ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 150 and datediff(d, h.duedate, eomonth(cutoffdate)) < 179 then 1 else 0  end [DQ 150+ Days Flag]
	,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 180 and datediff(d, h.duedate, eomonth(cutoffdate)) < 359 then 1 else 0  end [DQ 180+ Days Flag]
	,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 360 then 1 else 0  end [DQ 360+ Days Flag]
    ,h.duedate NextDueDate,lastpmtrecd,cast(CutoffDate as date) CutoffDate,MortgageOpenDate,InvestorPrinBal,CurrentBalance Balance
    ,datediff(d, h.duedate, eomonth(cutoffdate)) DQDays
	,Case when len(MONTH(CutoffDate)) = 1 then CONCAT(YEAR(cutoffdate),0,month(cutoffdate))
	else CONCAT(YEAR(cutoffdate),month(cutoffdate)) end as extract_date 
	FROM [UICCU].[dbo].[HarlandLoanCutoff] h
    left join ae_edw.dbo.f_mortgage f on f.mortgageid = h.loanid and month(reportmonth) = month(cutoffdate)
                                    and year(reportmonth) = year(cutoffdate)
	WHERE CutoffDate in (select [process date] from #processdate) and
	loanprincipalbal > 0 AND RegPrincipalColl != investorprinbal AND (investorid LIKE '%bal' or investorid LIKE '%fix%' or investorid LIKE '%arm' or
								investorid LIKE 'E-10YR' or investorid LIKE 'E-WORK' or InvestorID like '%Equity%' or InvestorID like '%TDR%' or
								InvestorID = 'F-ARM' or InvestorID = 'FAB-HH' )
               and investorprinbal is not null
               and datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and RecordType <> 2
		)T 
			   where CutoffDate between @staticpooldate3 and @staticpooldate2
			   --T.extract_date =  concat(left(DATEADD(month,-1,@staticpooldate2),4),left(RIGHT(DATEADD(month,-1,@staticpooldate2),5),2))
		--    select * from #mortgagedelinquency1
--- Next Deliquency -- 
	--Drop table if exists #mortgagedelinquency2
	--Select *
	--into #mortgagedelinquency2
	--	from (

	--	SELECT 
 --       case when datediff(d, h.duedate, DateAdd(month, -1, eomonth(cutoffdate)))  < 30 then 'New' end New30Flag
	--	,case when datediff(d, h.duedate, DateAdd(month, -1, eomonth(cutoffdate)))  between 30 and 60 then 'New' end New61Flag
 --               ,h.loanid,InvestorID MortgageDescription
	--,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and datediff(d, h.duedate, eomonth(cutoffdate)) < 30 then 1 else 0  end [DQ 1+ Days Flag]
 --   ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 30 and datediff(d, h.duedate, eomonth(cutoffdate)) < 60 then 1 else 0  end [DQ 30+ Days Flag]
 --   ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 60 and datediff(d, h.duedate, eomonth(cutoffdate)) < 90 then 1 else 0  end [DQ 60+ Days Flag]
	--,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 90 and datediff(d, h.duedate, eomonth(cutoffdate)) < 120 then 1 else 0  end [DQ 90+ Days Flag]
	--,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 120 and datediff(d, h.duedate, eomonth(cutoffdate)) < 150 then 1 else 0  end [DQ 120+ Days Flag]
 --   ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 150 and datediff(d, h.duedate, eomonth(cutoffdate)) < 179 then 1 else 0  end [DQ 150+ Days Flag]
	--,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 180 and datediff(d, h.duedate, eomonth(cutoffdate)) < 359 then 1 else 0  end [DQ 180+ Days Flag]
	--,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 360 then 1 else 0  end [DQ 360+ Days Flag]
 --   ,h.duedate NextDueDate,lastpmtrecd,CutoffDate,MortgageOpenDate,InvestorPrinBal
 --   ,datediff(d, h.duedate, eomonth(cutoffdate)) DQDays
	--,Case when len(MONTH(CutoffDate)) = 1 then CONCAT(YEAR(cutoffdate),0,month(cutoffdate))
	--else CONCAT(YEAR(cutoffdate),month(cutoffdate)) end as extract_date 

	--FROM [UICCU].[dbo].[HarlandLoanCutoff] h
 --   left join ae_edw.dbo.f_mortgage f on f.mortgageid = h.loanid and month(reportmonth) = month(cutoffdate)
 --                                   and year(reportmonth) = year(cutoffdate)
	--WHERE loanprincipalbal > 0 AND RegPrincipalColl != investorprinbal AND (investorid LIKE '%bal' or investorid LIKE '%fix%' or investorid LIKE '%arm' or
	--							investorid LIKE 'E-10YR' or investorid LIKE 'E-WORK' or InvestorID like '%Equity%' or InvestorID like '%TDR%' or
	--							InvestorID = 'F-ARM' or InvestorID = 'FAB-HH' )
 --              and investorprinbal is not null
 --              and datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and RecordType <> 2)T 
	--		   where T.extract_date = concat(left(@staticpooldate2,4),left(RIGHT(@staticpooldate2,5),2)) 


			 --  Select * from #mortgagedelinquency3

			 --Duplicate Check
		drop table if exists #mortgagedelinquency3
		Select cast(a.AsOfDate as date) date,a.PARENTACCOUNT,a.MortgageID
		,isnull(b.[DQ 1+ Days Flag],0) [DQ 1+ Days Flag],isnull(b.[DQ 30+ Days Flag],0) [DQ 30+ Days Flag],isnull(b.[DQ 60+ Days Flag],0) [DQ 60+ Days Flag],isnull(b.[DQ 90+ Days Flag],0) [DQ 90+ Days Flag]
		,isnull(b.[DQ 120+ Days Flag],0) [DQ 120+ Days Flag],isnull(b.[DQ 150+ Days Flag],0) [DQ 150+ Days Flag],isnull(b.[DQ 180+ Days Flag],0) [DQ 180+ Days Flag],isnull(b.[DQ 360+ Days Flag],0) [DQ 360+ Days Flag]
		,0 chargeoff,c.InvestorID,CurrentBalance Balance,LOANTYPE_UserChar3
		into #mortgagedelinquency3
		from
		(Select * from #mortgage) a 
		left join #mortgagedelinquency1 b 
		on a.MortgageID = b.loanid and a.AsOfDate=b.CutoffDate
		left join
			(select T.PARENTACCOUNT, T.PROCESSORACCOUNTNUMBER_USERCHAR1 "LoanID", M.InvestorID
			,cast(convert(varchar(20),t.ProcessDate) as Date) Processdate,T.LOANTYPE_UserChar3
				from ARCUSYM000.tracking.tvwARCUTRACKINGMortgage T
				join [AE_EDW].dbo.[D_MortgageParticipation] M
				on M.mortgageid= T.PROCESSORACCOUNTNUMBER_UserChar1
				where t.ProcessDate in (select max_ProcessDate from #processdate)
				and T.ExpireDate is null
				) C
				on a.MortgageID=c.LoanID and a.AsOfDate=c.Processdate 
				--select * from #mortgagedelinquency3
					--(select parentaccount from #loanDelinquency1 where loancategory2='real estate' and loanchargeoff=1 and loantypedescription='1ST MTG WRITEOFF (2019+)')
				--	select * from #LoanStatic where PARENTACCOUNT=0014092367
						--select * from ARCUSYM000.tracking.tvwARCUTRACKINGMortgage where PARENTACCOUNT=0013891526  order by ProcessDate 
				--	select * from ARCUSYM000.dbo.loan where PARENTACCOUNT=0013891526 and id in (0001,0002)   order by ProcessDate 
					--select * from #LoanStatic
				--	where PARENTACCOUNT in (select accountnumber parentaccount from #loanDelinquency1 where loancategory2='real estate' and loanchargeoff=1 and loantypedescription='1ST MTG WRITEOFF (2019+)') 
				--	and loancategory1='real estate'
			--0014092367,0013891526
			--select  * from [UICCU].[dbo].[HarlandLoanCutoff]  where loanid='0013891526' order by cutoffdate
		--	select  * from [UICCU].[dbo].[HarlandLoanCutoff] where CutoffDate='2019-09-30 00:00:00.000'
				--check
		--	Select   * from #mortgagedelinquency3 where parentaccount in (select parentaccount from ##tempmortg) order by PARENTACCOUNT, date
		
		--	select date,count(*) from #mortgagedelinquency3 where parentaccount=0013947245 group by date

			--select * from #mortgagedelinquency1 order by parentaccount

			--drop table if exists #mortgagedelinquency4
		 --  Select a.PARENTACCOUNT,a.MortgageID,b.[DQ 1+ Days Flag],b.[DQ 30+ Days Flag]
		 --  ,b.[DQ 60+ Days Flag],b.[DQ 90+ Days Flag],b.[DQ 120+ Days Flag],b.[DQ 150+ Days Flag],b.[DQ 180+ Days Flag],b.[DQ 360+ Days Flag],0 chargeoff,a.MortgageDescription
		 --  into #mortgagedelinquency4
		 --   from #mortgage a  left join #mortgagedelinquency2 b on a.MortgageID = b.loanid
			
			--Select * from #mortgagedelinquency4

			--Select '#LoanStatic' , COUNT(1) from #LoanStatic
			--Select '#loanDelinquency1' , COUNT(1) from #loanDelinquency1
			--Select '#Tracking' , COUNT(1) from #Tracking
			--Select '#Mortgage' , COUNT(1) from #Mortgage
			--Select '#mortgagedelinquency1' , COUNT(1) from #mortgagedelinquency1
			--Select '#mortgagedelinquency3' , COUNT(1) from #mortgagedelinquency3
			---select '#finalloandeliquency1' , count(1) from #finalloandeliquency1
			--select '#creditcard' , count(1) from #creditcard


			
			
			
			
			-- Adding the previous month Del colums
			drop table if exists #finalloandeliquency1
			Select a.[Process date],a.PARENTACCOUNT,a.ID LoanID,Loan_Categories,a.LoanCategory1,a.LoanCategory2,a.LoanCategory3,a.LoanTypeDescription
			,isnull(Cycle1,0) Cycle1,isnull(Cycle2,0) Cycle2,isnull(Cycle3,0) Cycle3,isnull(Cycle4,0) Cycle4,isnull(Cycle5,0) Cycle5
			,isnull(Cycle6,0) Cycle6,isnull(Cycle7,0) Cycle7,isnull(Cycle8,0) Cycle8,isnull(loanchargeoff,0) loanchargeoff,isnull(BankruptcyCount,0) BankruptcyCount,Balance
			 into #finalloandeliquency1 from  #LoanStatic a  
			 left join  #loanDelinquency1 b on a.PARENTACCOUNT = b.AccountNumber and a.ID = b.LoanID
			 and a.ProcessDate=b.ProcessDate
			 --select * from #finalloandeliquency1 where BankruptcyCount=1
			 -- where loanchargeoff=1
			 --select * from #loanDelinquency1 where BankruptcyCount=1
			 
			 -- Adding the Current month Del columns
			-- drop table if exists #finalloandeliquency2
			--Select a.PARENTACCOUNT,a.ID LoanID,Loan_Categories,a.LoanCategory2,LoanCategory3,LoanCategory4
			--,Cycle1,Cycle2,Cycle3,Cycle4,Cycle5,Cycle6,Cycle7,Cycle8,loanchargeoff,LoanTypeDescription
			-- into #finalloandeliquency2 from #LoanStatic a  left join #loanDelinquency2 b on a.PARENTACCOUNT = b.AccountNumber and a.ID = b.LoanID
--------------------


-- Credit card Staticpool -- 




		drop table if exists #creditcard
  select distinct [Social Security Number],Durable_Key
  into #creditcard
	  from Tmgdata.dbo.cardholder a
	  where Active_Flag=1 and [External Status Code] not in ('C')
	  and  fullExtractdate between dateadd(month,-35,@creditcarddate) and @creditcarddate
	    AND [Card Description]  not IN ('Mastercard Business')

				
 ---Delinquency2 ----
 Drop table if exists #creditcarddelinquency2
Select  eomonth(cast(fullExtractdate as date)) Date,durable_key,[Social Security Number],
 case when [Card Account Delinquent Day Account new] between 1 and 29     and CHARGEOFF_FLAG<>1  then 1 else 0  end  cycle1 
 ,case when [Card Account Delinquent Day Account new] between 30 and 59   and chargeoff_flag<>1  then 1 else 0  end  cycle2
 ,case when [Card Account Delinquent Day Account new] between 60 and 89   and chargeoff_flag<>1  then 1 else 0  end  cycle3
 ,case when [Card Account Delinquent Day Account new] between 90 and 119  and chargeoff_flag<>1  then 1 else 0  end  cycle4
 ,case when [Card Account Delinquent Day Account new] between 120 and 149 and chargeoff_flag<>1  then 1 else 0 end  cycle5
 ,case when [Card Account Delinquent Day Account new] between 150 and 179 and chargeoff_flag<>1  then 1 else 0 end  cycle6
 ,case when [Card Account Delinquent Day Account new] between 180 and 359 and chargeoff_flag<>1  then 1 else 0 end  cycle7
 ,case when [Card Account Delinquent Day Account new] >359 and chargeoff_flag<>1   then 1 else 0 end  cycle8
 ,case when chargeoff_flag = 1   then 1 else 0 end chargeoff,[Card Description], case when chargeoff_flag=1 then [Charge-off Amount] else [Last Statement Balance Amount] end Balance
 into #creditcarddelinquency2
  from
		  (select * 
		,case when pre_del>0 then pre_del-lead(date,1) over(partition by Durable_Key order by extract_datepart) else [Card Account Delinquent Day Account] end [Card Account Delinquent Day Account new]
		,lead(date,1) over(partition by Durable_Key order by extract_datepart) pre_days
		from 
		(select *,day(eomonth(cast(fullExtractdate as date))) date
		,lead([Card Account Delinquent Day Account],1) over(partition by Durable_Key order by extract_datepart) pre_del
		from TMGData.dbo.cardholder where Active_Flag=1 and [External Status Code] not in ('C')
		) AB  ) A
where fullExtractdate between dateadd(month,-35,@creditcarddate) and @creditcarddate
--extract_datepart between case when len(month(@creditcarddate))=1 then concat(year(@creditcarddate),0,month(@creditcarddate))  
--else concat(year(@creditcarddate),0,month(@creditcarddate))  end 
and active_flag = 1
 AND [Card Description] not IN ('Mastercard Business')
 
 
 ---------------------select * from #creditcarddelinquency2
-- Drop table if exists #finalcreditcarddelinquency1
-- Select a.[Social Security Number],a.Durable_Key,Cycle1,Cycle2,Cycle3,Cycle4,Cycle5,Cycle6,Cycle7,Cycle8,chargeoff,[Card Description]
-- into #finalcreditcarddelinquency1
-- from #creditcard a  left join #creditcarddelinquency1 b on a.Durable_Key = b.Durable_Key and a.[Social Security Number] = b.[Social Security Number]
------------------

 Drop table if exists #finalcreditcarddelinquency2
 Select date,a.[Social Security Number],a.Durable_Key,Cycle1,Cycle2,Cycle3,Cycle4,Cycle5,Cycle6,Cycle7,Cycle8,chargeoff,[Card Description],Balance
 into #finalcreditcarddelinquency2
 from #creditcard a  left join #creditcarddelinquency2 b on a.Durable_Key = b.Durable_Key and a.[Social Security Number] = b.[Social Security Number]

 --select * from #finalcreditcarddelinquency2 where  durable_key=1438324 order by [Social Security Number],date 
		
-------select top 1 * from tmgdata.dbo.cardholder
			--  merging mortgage and credit card info in the overall data for previous moth cal

			Drop table if exists  #finaldelinquency1
		   Select [Process date],PARENTACCOUNT ,LoanID,Cycle1,Cycle2,Cycle3,Cycle4,Cycle5,Cycle6,Cycle7,Cycle8,loanchargeoff,
		   LoanTypeDescription,Balance,LoanCategory1,LoanCategory2,LoanCategory3,Loan_Categories LoanCategories, BankruptcyCount
		   into #finaldelinquency1
		   from #finalloandeliquency1 
		   union all 
		   Select  date,PARENTACCOUNT,MortgageID, [DQ 1+ Days Flag],[DQ 30+ Days Flag],[DQ 60+ Days Flag], [DQ 90+ Days Flag]
		, [DQ 120+ Days Flag], [DQ 150+ Days Flag],[DQ 180+ Days Flag], [DQ 360+ Days Flag], chargeoff,InvestorID,Balance,
		'Real Estate' loancategory1,case when LOANTYPE_UserChar3='Manufactured Home' then 'Manufactured Home' else '1st Mortgage H' end loancategory2,
		case when LOANTYPE_UserChar3='Manufactured Home' then 'Manufactured Home' else '1st Mortgage H' end loancategory3,case when LOANTYPE_UserChar3='Manufactured Home' then 'Manufactured Home' else '1st Mortgage H' end Loan_Categories ,
		 0 BankruptcyCount
		   from #mortgagedelinquency3
		   union all
		   Select date,rtrim([Social Security Number]),rtrim(Durable_Key),Cycle1,Cycle2,Cycle3,Cycle4,Cycle5,Cycle6,Cycle7,Cycle8,chargeoff,[Card Description],Balance
		   ,'Personal' loancategory1,'Unsecured' loancategory2,'CreditCard' loancategory3,'CreditCard' Loan_Categories, 0 BankruptcyCount
		    from #finalcreditcarddelinquency2
		--select  loancategory1,[Process date],loanchargeoff  from #finaldelinquency1 where [Process date]='2021-05-31' and loanchargeoff=1 and loancategory1='Personal' 
		--select loancategory1,[Process date] from analytics.dbo.#finaldelinquency1 where loanchargeoff=1 and loancategory1='Personal' and [Process date]='2021-07-31'
		--select distinct LoanCategory1,LoanCategory2,LoanCategory3, LoanCategories from #finaldelinquency1 where LoanCategory1='real estate'

--select distinct loancategory1, loancategory2,loancategory3 from #finaldelinquency1 
		--data validation
		
		--	select PARENTACCOUNT* from #finaldelinquency1 where LoanCategory1='vehicle' and LoanCategory3='used auto' and cycle4=1 and loantypedescription='used indirect auto loan' and [process date]='2021-04-30' order by PARENTACCOUNT
		/*
			select top 1 * from #finaldelinquency1 where LoanCategory1='vehicle' and LoanCategory3='used auto' and cycle1=1 and loantypedescription='used indirect auto loan' 
			and [process date]='2021-03-31' 
			and PARENTACCOUNT in (select PARENTACCOUNT from #finaldelinquency1 where LoanCategory1='vehicle' and LoanCategory3='used auto'
			 and cycle4=1 and loantypedescription='used indirect auto loan' and [process date]='2021-04-30' )
			
			select * from #finaldelinquency1 where LoanCategory1='vehicle' and LoanCategory3='used auto' and cycle1=1 and loantypedescription='used indirect auto loan' 
			and [process date]='2020-09-30' 
			and PARENTACCOUNT in (select PARENTACCOUNT from #finaldelinquency1 where LoanCategory1='vehicle' and LoanCategory3='used auto'
			 and cycle3=1 and loantypedescription='used indirect auto loan' and [process date]='2020-10-31' )

			 drop table if exists #sample3
select LoanDelqDays, ProcessDate into #sample3 from arcusym000.arcu.ARCULoanDetailed  where AccountNumber=0014056286 and loanid=0001 order by processdate
select * from #sample3 order by processdate

select ProcessDate,BALANCE,PAYMENT,PARTIALPAYMENT,LASTPAYMENTDAloanTE,DUEDATE,INTERESTUNPAID,DQNOTICENUMBER,DQNOTICEDATE,PRINCIPALYTD,PRINCIPALLASTYEAR,ADVANCEAMOUNT
 from ARCUSYM000.dbo.LOAN where PARENTACCOUNT=0014638127 and id=0001 order by processdate
*/

			 	/*
			select * from #finaldelinquency1 where LoanCategory1='personal' and LoanCategory3='other secured' and (cycle1=0 and cycle2=0 and cycle3=0 and cycle4=0 and cycle5=0
			 and cycle6=0 and cycle7=0 and cycle8=0) and loantypedescription='secured loan' 
			and [process date]='2020-01-31' 
			and PARENTACCOUNT in (select PARENTACCOUNT from #finaldelinquency1 where LoanCategory1='personal' and LoanCategory3='other secured'
			 and cycle7=1 and loantypedescription='secured loan' and [process date]='2020-02-29' )
			 */			
			--select * from  #finaldelinquency1  where PARENTACCOUNt=14623310
			--			where BankruptcyCount=1 and loanchargeoff=1
			

			--select * from [ARCUSYM000].[arcu].[ARCULoanCategory]
			----  Credit card and mortgage loan may have duplications
			--select loancategory4,count(distinct CONCAT(parentaccount,loanid)) 
			--from #finaldelinquency1 
			--group by loancategory4 
			--order by loancategory4

			
			--select [process date],count(distinct CONCAT(parentaccount,loanid)),count( CONCAT(parentaccount,loanid)) 
			--from #finaldelinquency1 where loancategory4='1st Mortgage'
			--group by [process date] 
			--order by [process date]
   
   
		     --10182


--Drop table if exists #deliquency_previousmonth
--		Select *,
--		case when Cycle1=1 then '1.Cycle1'
--		 when Cycle2=1 then '2.Cycle2'
--		 when Cycle3=1 then '3.Cycle3'
--		 when Cycle4=1 then '4.Cycle4'
--		 when Cycle5=1 then '5.Cycle5'
--		 when Cycle6=1 then '6.Cycle6'
--		 when Cycle7=1 then '7.Cycle7'
--		 when Cycle8=1 then '8.Cycle8'
--		 when loanchargeoff=1 then '9.chargeoff'
--		 else '0.Not Deliquent'
--		 end as 'j' ,eomonth(dateadd(month,-1,[Process date])) pre_month
--		 into #deliquency_previousmonth
--		from #finaldelinquency1
--		order by [Process date]

	
	--Select a.[Process date],concat(a.PARENTACCOUNT,a.loanid) UNID,a.Loan_Categories,a.LoanTypeDescription
	--,a.LoanCategory2,a.LoanCategory3,a.LoanCategory4,a.j Cur_month ,b.J as Next_month,b.pre_month pre_monthdate
	--from #deliquency_previousmonth a  
 --   left join (select * from #deliquency_previousmonth) b on a.PARENTACCOUNT = b.PARENTACCOUNT 
	--and a.LoanID = b.LoanID and a.[Process date]=b.pre_month
	--order by a.[Process date]
	
	--- ## savan

	
	drop table if exists Analytics.dbo.rollratetracker_pre12

	create table Analytics.dbo.rollratetracker_pre12
	(month1 nvarchar(4000),Month2 nvarchar(4000),LoanCategories varchar(50) ,LoanTypeDescription nvarchar(100),
	LoanCategory1 varchar(50),LoanCategory2 varchar(50),LoanCategory3 varchar(50),BankruptcyCount int,Cur_month varchar(15),
	[1.Cycle1] int,[2.Cycle2] int,[3.cycle3] int,[4.cycle4] int,[5.cycle5] int,[6.cycle6] int,[7.cycle7] int,[8.cycle8] int
	,[9.chargeoff] int ,[0.Not Deliquent] int ,Date1 date,Date2 date)

	Truncate table Analytics.dbo.rollratetracker_pre12

	Drop table if exists #deliquency_Cursor
		Select *,
		case when Cycle1=1 then '1.Cycle1'
		 when Cycle2=1 then '2.Cycle2'
		 when Cycle3=1 then '3.Cycle3'
		 when Cycle4=1 then '4.Cycle4'
		 when Cycle5=1 then '5.Cycle5'
		 when Cycle6=1 then '6.Cycle6'
		 when Cycle7=1 then '7.Cycle7'
		 when Cycle8=1 then '8.Cycle8'
		 when loanchargeoff=1 then '9.chargeoff'
	-- when BankruptcyCount=1 then '10.Bankruptcy'
		 else '0.Not Deliquent'
		 end as 'j' 
		 into #deliquency_Cursor
		from #finaldelinquency1
		order by [Process date]
		--select distinct Date2 from  Analytics.dbo.rollratetracker_pre12 where BankruptcyCount=1
	--	select *,cast(BankruptcyCount as int) from #deliquency_Cursor where BankruptcyCount=1
		--where PARENTACCOUNT='0014231057'
			
		/*	drop table if exists #testn
			select * 
			into #testn
			from  #deliquency_Cursor where [Process date]='2021-04-30' and [Cycle7]=1
			select * from #testn

			select * from  #deliquency_Cursor where [Process date]='2021-05-31'
			 and PARENTACCOUNT  in (select PARENTACCOUNT from  #testn) 
			and LoanId  in (select LoanId from  #testn)

			*/
	--		select * from #finaldelinquency1  where PARENTACCOUNT=0014197010 and loanid=0005 order by [Process date]
	--select distinct [Process date] from #finaldelinquency1

	---select distinct month1, month2 from rollratetracker_pre12 order by month2
	----**********/////-Cursor
	declare @extrac_date date
	declare @extrac_date1 date

	declare curp cursor  for

	select distinct [Process date] from #deliquency_Cursor order by [Process date]
		open curp
	fetch next from curp into @extrac_date

	While @@FETCH_STATUS = 0
		begin 
			
			declare curp1 cursor  for

			select distinct [Process date] from #deliquency_Cursor where  [Process date] >@extrac_date order by 1

			open curp1

			fetch next from curp1 into @extrac_date1

			While @@FETCH_STATUS = 0

			begin 
			print (@extrac_date1)

			print (@extrac_date)

			Insert Into Analytics.dbo.rollratetracker_pre12
			select 
			month1,Month2,LoanCategories,LoanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,BankruptcyCount,Cur_month,[1.cycle1],[2.cycle2]
			,[3.cycle3],[4.cycle4],[5.cycle5],[6.cycle6],[7.cycle7],[8.cycle8],[9.chargeoff],[0.Not Deliquent],Date1,Date2
 			
			from
					(
				Select format(a.[Process date] , 'MMM-yy') as month1,format(b.[Process date], 'MMM-yy') as Month2
				,concat(a.PARENTACCOUNT,a.loanid) UNID
				,a.LoanCategories,a.LoanTypeDescription,a.BankruptcyCount
				,a.LoanCategory1,a.LoanCategory2,a.LoanCategory3,a.j Cur_month ,b.J as Next_month, a.[Process date] Date1,b.[Process date] Date2
				from (Select * from #deliquency_Cursor where [Process date] = @extrac_date) a  
				left join (select * from #deliquency_Cursor where [Process date] = @extrac_date1) b on a.PARENTACCOUNT = b.PARENTACCOUNT 
				and a.LoanID = b.LoanID --and a.[Process date]=@extrac_date1
						) A
			PIVOT (
			count(UNID)
			for
			Next_month		
			in 
			([1.cycle1],[2.cycle2],[3.cycle3],[4.cycle4],[5.cycle5],[6.cycle6],[7.cycle7],[8.cycle8],[9.chargeoff],[0.Not Deliquent]) 
			) as PVT
			order by Cur_month

			fetch next from curp1 into @extrac_date1

			end
			close curp1
			deallocate curp1

		fetch next from curp into @extrac_date

	end
	close curp
	deallocate curp
	--select * from  Analytics.dbo.rollratetracker_pre12 where BankruptcyCount=1 and month2='Apr-21' and cur_month='2.cycle2' and date

	--select * from #deliquency_Cursor where BankruptcyCount=1 and PARENTACCOUNT=0014498837 and loancategory1='personal' and LoanTypeDescription='secured loan' order by [Process date]
	--select * from  Analytics.dbo.rollratetracker_pre12 where BankruptcyCount=1  and cur_month='2.cycle2'  and loancategory1='personal' and LoanTypeDescription='secured loan'

----amount

	drop table if exists Analytics.dbo.rollratetracker_pre12amount

	create table Analytics.dbo.rollratetracker_pre12amount
	(month1 nvarchar(4000),Month2 nvarchar(4000),LoanCategories varchar(50) ,LoanTypeDescription nvarchar(100),
	LoanCategory1 varchar(50),LoanCategory2 varchar(50),LoanCategory3 varchar(50),BankruptcyCount int,Cur_month varchar(15),
	[1.Cycle1] money,[2.Cycle2] money,[3.cycle3] money,[4.cycle4] money,[5.cycle5] money,[6.cycle6] money,[7.cycle7] money,[8.cycle8] money
	,[9.chargeoff] money ,[0.Not Deliquent] money ,Date1 date,Date2 date)

	Truncate table Analytics.dbo.rollratetracker_pre12amount

		declare @extrac_date2 date
	declare @extrac_date3 date

	declare curp2 cursor  for

	select distinct [Process date] from #deliquency_Cursor order by [Process date]
		open curp2
	fetch next from curp2 into @extrac_date2

	While @@FETCH_STATUS = 0
		begin 
			
			declare curp3 cursor  for

			select distinct [Process date] from #deliquency_Cursor where  [Process date] >@extrac_date2 order by 1

			open curp3

			fetch next from curp3 into @extrac_date3

			While @@FETCH_STATUS = 0

			begin 
			print (@extrac_date3)

			print (@extrac_date2)

			Insert Into Analytics.dbo.rollratetracker_pre12amount
			select 
			month1,Month2,LoanCategories,LoanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,BankruptcyCount,Cur_month,[1.cycle1],[2.cycle2]
			,[3.cycle3],[4.cycle4],[5.cycle5],[6.cycle6],[7.cycle7],[8.cycle8],[9.chargeoff],[0.Not Deliquent],Date1,Date2
 			
			from
					(
				Select format(a.[Process date] , 'MMM-yy') as month1,format(b.[Process date], 'MMM-yy') as Month2
				,b.balance
				,a.LoanCategories,a.LoanTypeDescription,a.BankruptcyCount
				,a.LoanCategory1,a.LoanCategory2,a.LoanCategory3,a.j Cur_month ,b.J as Next_month, a.[Process date] Date1,b.[Process date] Date2
				from (Select * from #deliquency_Cursor where [Process date] = @extrac_date2) a  
				left join (select * from #deliquency_Cursor where [Process date] = @extrac_date3) b on a.PARENTACCOUNT = b.PARENTACCOUNT 
				and a.LoanID = b.LoanID --and a.[Process date]=@extrac_date3
						) A
			PIVOT (
			sum(balance)
			for
			Next_month		
			in 
			([1.cycle1],[2.cycle2],[3.cycle3],[4.cycle4],[5.cycle5],[6.cycle6],[7.cycle7],[8.cycle8],[9.chargeoff],[0.Not Deliquent]) 
			) as PVT
			order by Cur_month

			fetch next from curp3 into @extrac_date3

			end
			close curp3
			deallocate curp3

		fetch next from curp2 into @extrac_date2

	end
	close curp2
	deallocate curp2


	--check end

	--	select * from #deliquency_Cursor where BankruptcyCount=1 and j='2.cycle2' and loancategory1='real estate' order by [Process date]
--	select * from  Analytics.dbo.rollratetracker_pre12amount where BankruptcyCount=1  and cur_month='2.cycle2'  and loancategory1='real estate'



			---- adding non deliquent in separate column to use in rollratetracker_13 month comparison
		drop table if exists #nondel
			select [Process date], ParentAccount, LoanId,
			Cycle1,
			Cycle2,
			Cycle3,Cycle4,Cycle5,Cycle6,Cycle7,Cycle8,loanchargeoff,BankruptcyCount,
		loanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,LoanCategories,Balance,
			 case when j='0.Not Deliquent' then 1 else 0 END [0.Not Deliquent],
			 case when BankruptcyCount=1 and loanchargeoff=1 then 1 else 0 end [Bankruptcy Flag-Chargeoff],
			 case when BankruptcyCount=1 and loanchargeoff<>1 then 1 else 0 end [Active Bankruptcy Flag Account],
			 --case when BankruptcyCount<>1 and loanchargeoff=1 then 1 else 0 end [Charge-off]
			 case when loanchargeoff=1 then 1 else 0 end [Charge-off] --new edit 07/19
			 into #nondel
			 from #deliquency_Cursor order by [Process date]
			
			
			---- removing BK cycle from original table 
			 drop table  if exists  #cycleswithoutBKcount
			 select [Process date], ParentAccount, LoanId,
				loanchargeoff,		BankruptcyCount,
		loanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,LoanCategories,Balance,
			  [0.Not Deliquent],
			  [Bankruptcy Flag-Chargeoff],
			  [Active Bankruptcy Flag Account],
			  [Charge-off],
			 case when Cycle1=1 and BankruptcyCount<>1 then 1 else 0 end Cycle1, 
			 case when Cycle2=1 and BankruptcyCount<>1 then 1 else 0 end Cycle2, 
			 case when Cycle3=1 and BankruptcyCount<>1 then 1 else 0 end Cycle3, 
			 case when Cycle4=1 and BankruptcyCount<>1 then 1 else 0 end Cycle4, 
			 case when Cycle5=1 and BankruptcyCount<>1 then 1 else 0 end Cycle5, 
			 case when Cycle6=1 and BankruptcyCount<>1 then 1 else 0 end Cycle6, 
			 case when Cycle7=1 and BankruptcyCount<>1 then 1 else 0 end Cycle7, 
			 case when Cycle8=1 and BankruptcyCount<>1 then 1 else 0 end Cycle8 
			  into #cycleswithoutBKcount
			  from #nondel 

		--	  select * from #cycleswithoutBKcount where  BankruptcyCount=1 and loanchargeoff=1
					 
			 
			 --- creating cycle 1 to 8 for Bankruptcy Accounts 
			 
			 drop table if exists #bankruptcyflagaccounts 
			 select [Process date], ParentAccount, LoanId,
				--- removed these fields as calculated both breakdown  --loanchargeoff,		BankruptcyCount,  [0.Not Deliquent],  [Charge-off],
		loanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,LoanCategories,Balance,
			 			  [Bankruptcy Flag-Chargeoff],
			  [Active Bankruptcy Flag Account],
		case when Cycle1=1 and BankruptcyCount=1 and loanchargeoff<>1 then 1 else 0 end Cycle1,
		case when Cycle2=1 and BankruptcyCount=1 and loanchargeoff<>1 then 1 else 0 end Cycle2,
		case when Cycle3=1 and BankruptcyCount=1 and loanchargeoff<>1 then 1 else 0 end Cycle3,
		case when Cycle4=1 and BankruptcyCount=1 and loanchargeoff<>1 then 1 else 0 end Cycle4,
		case when Cycle5=1 and BankruptcyCount=1 and loanchargeoff<>1 then 1 else 0 end Cycle5,
		case when Cycle6=1 and BankruptcyCount=1 and loanchargeoff<>1 then 1 else 0 end Cycle6,
		case when Cycle7=1 and BankruptcyCount=1 and loanchargeoff<>1 then 1 else 0 end Cycle7,
		case when Cycle8=1 and BankruptcyCount=1 and loanchargeoff<>1 then 1 else 0 end Cycle8
						 into #bankruptcyflagaccounts
			 from #nondel 
						
			drop table if exists  analytics.dbo.finalBankruptcyTable
			 select *
			 into analytics.dbo.finalBankruptcyTable
			  from #bankruptcyflagaccounts 
			   where cycle1<>0 or cycle2<>0 or cycle3<>0 or  cycle4<>0  or  cycle5<>0  or  cycle6<>0
			  or  cycle7<>0  or  cycle8<>0  or  [Bankruptcy Flag-Chargeoff]<>0  or  [Active Bankruptcy Flag Account]<>0
			  

			 
			---update the query here for amount- remove aggregation and load direct table for amounts

		--UniversalTable--Used for adjustments 4 year data---
	
			drop table if exists analytics.dbo.Rollratetracker_13Month_compare
		select [Process date],format([Process date] , 'MMM-yy') ShortDate
		,CONCAT(parentaccount,loanid,loanTypeDescription) [# Loans]
		, Cycle1, Cycle2, Cycle3
		, Cycle4, Cycle5
		, Cycle6, Cycle7,
		 Cycle8,
		--removed these two fields as calculated both breakdown --sum(loanchargeoff) loanchargeoff,sum(BankruptcyCount) BankruptcyCount,
		 [0.Not Deliquent],
		[Bankruptcy Flag-Chargeoff] [BKFlagClosed-LoanChargeoff], [Active Bankruptcy Flag Account] [Active BK Status],[Charge-off] loanchargeoff,
				--count(CONCAT(parentaccount,loanid)) [0.Not Deliquent]
		loanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,LoanCategories ,Balance
		into analytics.dbo.Rollratetracker_13Month_compare
		from #cycleswithoutBKcount
			--group by  [Process date],loanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,LoanCategories ,Balance,CONCAT(parentaccount,loanid,loanTypeDescription)
		 order by [Process date]

		-- select count(*), [Process date] from  analytics.dbo.Rollratetracker_13Month_compare group by [Process date] order by [Process date]
		--DATA ROWS COUNT
				--select distinct [Process date] from  analytics.dbo.Rollratetracker_13Month_compare order by [Process date]
				--select distinct month1 from analytics.dbo.rollratetracker_pre12 order by month1
				--select distinct month2 from analytics.dbo.rollratetracker_pre12 order by month2
				--select distinct month1 from analytics.dbo.rollratetracker_CallReportView order by month1
				--select distinct [Process date] from analytics.dbo.finalBankruptcyTable order by [Process date]


				--select count(*) from analytics.dbo.finalBankruptcyTable
				--select count(*) from  analytics.dbo.rollratetracker_pre12
				--select count(*) from  analytics.dbo.Rollratetracker_13Month_compare
				--select count(*) from analytics.dbo.rollratetracker_CallReportView

				--select count(*) from analytics.dbo.finalBankruptcyTable

				--select count(*) from analytics.dbo.POWERBIFORECASTING

				--select  count(*)  from analytics.dbo.POWERBIFORECASTING2
				--select  count(*)  from analytics.dbo.POWERBIFORECASTINGRecovery
				----select * from Rollratetracker_ParentLevelInfo_bal


		---3 years of data--
		
		 
--declare @staticpoolmonth date
--		declare @staticpooldatemonth2 date
--		declare @staticpooldatemonth3 date
--		set  @staticpoolmonth= (select datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Processdate from
--	(select max(ProcessDate) processdate from ARCUSYM000.dbo.LOAN) A)
--set  @staticpooldatemonth2 = (Select case when @staticpoolmonth = EOMONTH(@staticpoolmonth) then @staticpoolmonth else EOmonth(DATEADD(Month,-1,@staticpoolmonth)) end)
--set  @staticpooldatemonth3 = (select dateadd(month,-23,@staticpooldatemonth2))

--		drop table if exists analytics.dbo.Rollratetracker_13Month_compare
--		select [Process date],format([Process date] , 'MMM-yy') ShortDate
--		,CONCAT(parentaccount,loanid,loanTypeDescription) [# Loans]
--		, Cycle1, Cycle2, Cycle3
--		, Cycle4, Cycle5
--		, Cycle6, Cycle7,
--		 Cycle8,
--		--removed these two fields as calculated both breakdown --sum(loanchargeoff) loanchargeoff,sum(BankruptcyCount) BankruptcyCount,
--		 [0.Not Deliquent],
--		[Bankruptcy Flag-Chargeoff] [BKFlagClosed-LoanChargeoff], [Active Bankruptcy Flag Account] [Active BK Status],[Charge-off] loanchargeoff,
--				--count(CONCAT(parentaccount,loanid)) [0.Not Deliquent]
--		loanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,LoanCategories ,Balance
--		into analytics.dbo.Rollratetracker_13Month_compare
--		from #cycleswithoutBKcount
--		where [process date]>=@staticpooldatemonth3 and [process date]<=@staticpooldatemonth2
--		--group by  [Process date],loanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,LoanCategories ,Balance,CONCAT(parentaccount,loanid,loanTypeDescription)
--		 order by [Process date]

		-- select distinct [Process date], count(*) from analytics.dbo.Rollratetracker_13Month_compare group by [Process date] order by [Process date]

		--replace table name in forecasting R for the charge off rates

					--original

					/*
		drop table if exists analytics.dbo.Rollratetracker_13Month_compare
		select [Process date],format([Process date] , 'MMM-yy') ShortDate
		,CONCAT(parentaccount,loanid,loanTypeDescription) [# Loans]
		,sum(Cycle1) Cycle1,sum(Cycle2) Cycle2,sum(Cycle3) Cycle3
		,sum(Cycle4) Cycle4,sum(Cycle5) Cycle5
		,sum(Cycle6) Cycle6,sum(Cycle7) Cycle7,
		sum(Cycle8) Cycle8,
		--removed these two fields as calculated both breakdown --sum(loanchargeoff) loanchargeoff,sum(BankruptcyCount) BankruptcyCount,
		sum([0.Not Deliquent]) [0.Not Deliquent],
		sum([Bankruptcy Flag-Chargeoff]) [BKFlagClosed-LoanChargeoff], sum([Active Bankruptcy Flag Account]) [Active BK Status],sum([Charge-off]) loanchargeoff,
				--count(CONCAT(parentaccount,loanid)) [0.Not Deliquent]
		loanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,LoanCategories ,Balance
		into analytics.dbo.Rollratetracker_13Month_compare
		from #cycleswithoutBKcount
		group by  [Process date],loanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,LoanCategories ,Balance,CONCAT(parentaccount,loanid,loanTypeDescription)
		 order by [Process date]
		*/
		--select cycle1+cycle2+cycle3+cycle4+cycle6+cycle7+cycle8+loanchargeoff+[0.Not Deliquent], * from Rollratetracker_13Month_compare where cycle1+cycle2+cycle3+cycle4+cycle6+cycle7+cycle8+loanchargeoff+[0.Not Deliquent]>1
--select  * from Rollratetracker_13Month_compare where loanchargeoff=1
	--select  top 100 * from analytics.dbo.Rollratetracker_13Month_compare

	--	select * from analytics.dbo.Rollratetracker_13Month_compare where [Active BK Status]=1 LoanCategory1='Writeoff'
		---incomplete for logic of bk resolved
		--select * from analytics.dbo.Rollratetracker_13Month_compare where loanchargeoff balance is zero and loanchargeoff=1 and [BKFlagClosed-LoanChargeoff]=1
	
	---FINAL FORECASTING BASETABLE

	--drop table if exists forecastingdata
	--select * into forecastingdata from #nondel

--	select distinct [process date] from forecastingdata

				---validation
			 --select  * from analytics.dbo.Rollratetracker_13Month_compare where LoanTypeDescription='PIGGYBACK - BALLOON' and PARENTACCOUNT='0014296862'
		-- select * from analytics.dbo.Rollratetracker_13Month_compare where [0.Not Deliquent]=0 and Cycle1=0 and  Cycle2=0 and  Cycle3=0 and  Cycle4=0
		 --	and  Cycle5=0 and  Cycle6=0 and  Cycle7=0 and  Cycle8=0 and  loanchargeoff=0 and  BankruptcyCount=1 and [# Loans]=1

		--select [Process date],ShortDate,LoanCategory1,LoanCategory2,LoanCategory3,loanTypeDescription, sum(balance) from analytics.dbo.Rollratetracker_13Month_compare 
		--where loanTypeDescription='CONSTRUCTION LOAN - INT ONLY'
		---group by  [Process date],ShortDate,LoanCategory1,LoanCategory2,LoanCategory3,loanTypeDescription
	

		--select * from analytics.dbo.Rollratetracker_13Month_compare where [0.Not Deliquent]=1 and Cycle1<>0 or Cycle2<>0 or Cycle3<>0 or Cycle4<>0
		-- 	or Cycle5<>0 or Cycle6<>0 or Cycle7<>0 or Cycle8<>0 or loanchargeoff<>0 or BankruptcyCount<>0
					
		--	select 	* from analytics.dbo.Rollratetracker_13Month_compare  where [0.Not Deliquent]=0 and LoanCategory1='Personal' order by PARENTACCOUNT,LoanID,[Process date],Cycle1,Cycle2,Cycle3
		---,Cycle4,Cycle5
		--,Cycle6,Cycle7,
		--Cycle8,loanchargeoff,BankruptcyCount
			
			--select 	* from analytics.dbo.Rollratetracker_13Month_compare  where  cycle7=1 order by PARENTACCOUNT,LoanID,[Process date]
			--where PARENTACCOUNT=478968429 order by [Process date]
			--cycle1=1 or 
	---loanchargeoff=1 
--			order by PARENTACCOUNT,LoanID, [Process date]
		
		----refresh this table before working on forecasting query


	-- member level information - Amount 6 months 
	--- Static pool date for member level information---

declare @staticpooldatez date
		declare @staticpooldatex date
		declare @staticpooldatexx date
		set  @staticpooldatez= (select datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Processdate from
	(select max(ProcessDate) processdate from ARCUSYM000.dbo.LOAN) A)
set  @staticpooldatex = (Select case when @staticpooldatez = EOMONTH(@staticpooldatez) then @staticpooldatez else EOmonth(DATEADD(Month,-1,@staticpooldatez)) end)
		
		drop table if exists analytics.dbo.Rollratetracker_ParentLevelInfo_bal
		select 
		case when cycle1=1 then balance else 0 END [B.Cycle1(1-29)] ,
	case when cycle2=1 then balance else 0 END [C.Cycle2(30-59)],
	case when cycle3=1 then balance else 0 END [D.Cycle3(60-89)],
	case when cycle4=1 then balance else 0 END [E.Cycle4(90-119)],
	case when cycle5=1 then balance else 0 END [F.Cycle5(120-149)],
	case when cycle6=1 then balance else 0 END [G.Cycle6(150-179)],
	case when cycle7=1 then balance else 0 END [H.Cycle7(180-359)],
	case when cycle8=1 then balance else 0 END [I.Cycle8(360+)],
	case when [0.Not Deliquent]=1 then balance else 0 END [A.Not Delinquent] ,
	case when [Charge-off]=1 then balance else 0 END [L.Charge-off],
	case when [Active Bankruptcy Flag Account]=1 then balance else 0 END [J.Bankruptcy],
	case when [Bankruptcy Flag-Chargeoff]=1 then balance else 0 END [K.Bankruptcy Flag Charged-off] ,
	 [Process date],format([Process date] , 'MMM-yy') ShortDate,
	 loanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,LoanCategories , PARENTACCOUNT, LoanID
		into analytics.dbo.Rollratetracker_ParentLevelInfo_bal
		from #nondel where [Process date] between dateadd(month,-5,@staticpooldatex) and @staticpooldatex
	--select * from analytics.dbo.Rollratetracker_ParentLevelInfo_bal where loanchargeoff>0  and [L.Charge-off]=0
	--select distinct [Process date] from Rollratetracker_ParentLevelInfo_bal
	--select count(*) from analytics.dbo.Rollratetracker_ParentLevelInfo_bal where loanchargeoff>0  

	--trial load[UICCU\Nikitalalan].[trial]
	drop table if exists TRIAL
	select top 10 [Process date] into trial  from analytics.dbo.Rollratetracker_ParentLevelInfo_bal

	--select * from analytics.[UICCU\Nikitalalan].trial
	--sp_spaceused TRIAL
	

	--sp_spaceused  Rollratetracker_ParentLevelInfo_bal
	
			--Forecasting for excel
	-- here charge off constitute of all type of charge off --- ignore this

	--	  drop table if exists #delinquency_forecasting
	--	select 
	--case when cycle1=1 then balance else 0 END cycle1_bal ,
	--case when cycle2=1 then balance else 0 END cycle2_bal,
	--case when cycle3=1 then balance else 0 END cycle3_bal,
	--case when cycle4=1 then balance else 0 END cycle4_bal,
	--case when cycle5=1 then balance else 0 END cycle5_bal,
	--case when cycle6=1 then balance else 0 END cycle6_bal,
	--case when cycle7=1 then balance else 0 END cycle7_bal,
	--case when cycle8=1 then balance else 0 END cycle8_bal,
	--case when loanchargeoff=1 then balance else 0 END loanchargeoff_bal,
	--case when [0.Not Deliquent]=1 then balance else 0 END [0.Not Deliquent_bal] ,
	
	--*
	--	into #delinquency_forecasting
	--	from analytics.dbo.Rollratetracker_13Month_compare
	--	--select * from #delinquency_forecasting

		
	--	drop table if exists Analytics.dbo.delinquency_forecastingsummary
	--	select 
	--	loanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,[Process date],ShortDate
	--		,sum(cycle1_bal) cycle1_bal,	sum(cycle2_bal)cycle2_bal,	sum(cycle3_bal)cycle3_bal,	sum(cycle4_bal)cycle4_bal,
	--	sum(cycle5_bal) cycle5_bal,	sum(cycle6_bal) cycle6_bal,	sum(cycle7_bal) cycle7_bal,	sum(cycle8_bal) cycle8_bal,
	--	sum(loanchargeoff_bal) loanchargeoff_bal,	sum([0.Not Deliquent_bal]) [0.Not Deliquent_bal] ,
	--	sum([# loans]) [# Loans]
	--	--,count(CONCAT(parentaccount,loanid)) [# Loans]
	--	,sum(Cycle1) Cycle1,sum(Cycle2) Cycle2,sum(Cycle3) Cycle3
	--	,sum(Cycle4) Cycle4,sum(Cycle5) Cycle5
	--	,sum(Cycle6) Cycle6,sum(Cycle7) Cycle7,
	--	sum(Cycle8) Cycle8,sum(loanchargeoff) loanchargeoff,sum([0.Not Deliquent]) [0.Not Deliquent]
	--	into Analytics.dbo.delinquency_forecastingsummary

	--	from  #delinquency_forecasting
	--	group by  [Process date],ShortDate,LoanCategory1,LoanCategory2,LoanCategory3,loanTypeDescription
	
	--select * from Analytics.dbo.delinquency_forecastingsummary where loanchargeoff_bal=0

	
	--Main Tables
--	select top 1 * from arcusym000.arcu.ARCULoanDetailed where LoanChargeOffLoanBalance>0 loanchargeoffloanbalance
---where LoanDelqDays=0

--select  * from [UICCU].[dbo].[HarlandLoanCutoff]  where loanid=8880127130 order by cutoffdate

--select top 100 * from arcusym000.dbo.Loan

--select top 1 * from  TMGData.dbo.cardholder where [Charge-Off Amount]
 --where [Card Account Delinquent Day Account]=0
	
	
	
		--Balance amount cursor

	/*

	drop table if exists Analytics.dbo.rollratetracker_RollRateMainAmount

	create table Analytics.dbo.rollratetracker_RollRateMainAmount
	(month1 nvarchar(4000),Month2 nvarchar(4000),LoanCategories varchar(50) ,LoanTypeDescription nvarchar(100),
	LoanCategory1 varchar(50),LoanCategory2 varchar(50),LoanCategory3 varchar(50),Balance money,Cur_month varchar(15),
	[1.Cycle1] int,[2.Cycle2] int,[3.cycle3] int,[4.cycle4] int,[5.cycle5] int,[6.cycle6] int,[7.cycle7] int,[8.cycle8] int,[0.Not Deliquent] int ,[9.chargeoff] int ,Date1 date,Date2 date)

select * from  #finaldelinquency1
--	select * from Analytics.dbo.rollratetracker_RollRateMainAmount
	Truncate table Analytics.dbo.rollratetracker_RollRateMainAmount
	
	Drop table if exists #deliquency_Cursor
		Select *,
		case when Cycle1=1 then '1.Cycle1'
		 when Cycle2=1 then '2.Cycle2'
		 when Cycle3=1 then '3.Cycle3'
		 when Cycle4=1 then '4.Cycle4'
		 when Cycle5=1 then '5.Cycle5'
		 when Cycle6=1 then '6.Cycle6'
		 when Cycle7=1 then '7.Cycle7'
		 when Cycle8=1 then '8.Cycle8'
		 when loanchargeoff=1 then '9.chargeoff'
		 else '0.Not Deliquent'
		 end as 'j' 
		 into #deliquency_Cursor
		from #finaldelinquency1
		order by [Process date]


		--select * from #LoanStatic
	
	
	
		--cursor for balance


declare @extrac_date date
	declare @extrac_date1 date

	declare curp cursor  for

	select distinct [Process date] from #deliquency_Cursor order by [Process date]

	open curp
	fetch next from curp into @extrac_date

	While @@FETCH_STATUS = 0

	begin 
			
			declare curp1 cursor  for

			select distinct [Process date] from #deliquency_Cursor where  [Process date] >@extrac_date order by 1

			open curp1

			fetch next from curp1 into @extrac_date1

			While @@FETCH_STATUS = 0

			begin 
			print (@extrac_date1)

			print (@extrac_date)

			Insert Into Analytics.dbo.rollratetracker_RollRateMainAmount
			select 
			month1,Month2,LoanCategories,LoanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,Balance,Cur_month,[1.cycle1],[2.cycle2]
			,[3.cycle3],[4.cycle4],[5.cycle5],[6.cycle6],[7.cycle7],[8.cycle8],[0.Not Deliquent],[9.chargeoff],Date1,Date2
 
			
			from
			(
			Select format(a.[Process date] , 'MMM-yy') as month1,format(b.[Process date], 'MMM-yy') as Month2
			,a.Balance
			,a.LoanCategories,a.LoanTypeDescription
			,a.LoanCategory1,a.LoanCategory2,a.LoanCategory3,a.j Cur_month ,b.J as Next_month, a.[Process date] Date1,b.[Process date] Date2
			from (Select * from #deliquency_Cursor where [Process date] = @extrac_date) a  
			left join (select * from #deliquency_Cursor where [Process date] = @extrac_date1) b on a.PARENTACCOUNT = b.PARENTACCOUNT 
			and a.LoanID = b.LoanID --and a.[Process date]=@extrac_date1
					) A
			PIVOT (
			sum(Balance)
			for
			Next_month		
			in 
			([1.cycle1],[2.cycle2],[3.cycle3],[4.cycle4],[5.cycle5],[6.cycle6],[7.cycle7],[8.cycle8],[0.Not Deliquent],[9.chargeoff]) 
			) as PVT
			order by Cur_month

			fetch next from curp1 into @extrac_date1

			end
			close curp1
			deallocate curp1

		fetch next from curp into @extrac_date

	end
	close curp
	deallocate curp

	*/
	


	



	------ 13 month difference ---- hault-- not required

	--drop table if exists #13MonthDiff
	--select * 
	--into #13MonthDiff
	--from analytics.dbo.Rollratetracker_13Month_compare
	


	--drop table if exists #temp_13
	--select [Process date],Cycle1,Null as Cycle1_Cur  
	--into #temp_13
	--  from #13MonthDiff where 1=0


	-----cursor for 13 month diff --not required

	--declare @extrac_date date
	
	--declare curp cursor  for

	--select distinct [Process date]  from #13MonthDiff order by [Process date]

	--open curp
	--fetch next from curp into @extrac_date

	--While @@FETCH_STATUS = 0

	--begin 
	--select * 
	--case when @extrac_date 
	--from #13MonthDiff 

	--where [Process date] in ( @extrac_date, EOMONTH(Dateadd(MM,-1,@extrac_date)))

			




























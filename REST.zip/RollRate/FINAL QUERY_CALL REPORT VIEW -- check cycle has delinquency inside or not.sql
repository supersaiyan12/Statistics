-- Static pool date ---

declare @staticpooldate date
		declare @staticpooldate2 date
		declare @staticpooldate3 date
		set  @staticpooldate= (select datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Processdate from
	(select max(ProcessDate) processdate from ARCUSYM000..LOAN) A)
set  @staticpooldate2 = (Select case when @staticpooldate = EOMONTH(@staticpooldate) then @staticpooldate else EOmonth(DATEADD(Month,-1,@staticpooldate)) end)
set  @staticpooldate3 = (select dateadd(month,-35,@staticpooldate2))

declare @creditcarddate date
set @creditcarddate =  (Select max(fullExtractdate) from TMGData..cardholder) 


drop table if exists #processdate
select process_date,max(ProcessDate) max_ProcessDate,max([process date]) [process date]
into #processdate
		from (select ProcessDate,left(ProcessDate,6) process_date ,datefromparts(left(processdate,4),right(left(processdate,6),2),RIGHT(processdate,2)) [process date]
				from ARCUSYM000..loan) A
where [process date]>=@staticpooldate3 and [process date]<=@staticpooldate2
group by process_date
--select * from #processdate
--select top 1 * from ARCUSYM000..loan where ProcessDate>20210831
--Loan Static of one month back -- 
	
	drop table if exists #LoanStatic
	select *
	into #LoanStatic
	from
	(
	select 
		[ProcessDate],[Process date],[Process_date],[PARENTACCOUNT],concat(PARENTACCOUNT,ID) UNID,ID
		,LoanCategory4 Loan_Categories
		,case when LoanCategory3='Indirect' then 'Indirect' else 'Direct' END Direct_indirect
		,LoanCategory2 LoanCategory1,LoanCategory3 LoanCategory2,LoanCategory4 LoanCategory3,LoanTypeDescription,BALANCE
		from
			(
			select *,CONCAT(PARENTACCOUNT,ID) UNID
			,case when opendate=closedate then 0 else 1 end Flag
			,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date 
			then 1 else 0 end Open_Flag
			,DATEDIFF(month,OPENDATE,@staticpooldate2) MOB	-- add the @Staticpooldate
			,DATEDIFF(month,OPENDATE,MATURITYDATE) Loan_Term
			,DATEDIFF(month,@staticpooldate2,MATURITYDATE) Month_to_Maturity
				from 
					(select *
					,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
					else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
					,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
					else concat(year(opendate),month(opendate)) end Open_date
					,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
					else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
					,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
					,left(ProcessDate,6) Process_date
					from ARCUSYM000..LOAN
					where ProcessDate in (select max_ProcessDate from #processdate)
					) H
				where  ORIGINALDATE is not null and OpenDate is not null 
				and CLOSEDATE is null 
				--and CHARGEOFFDATE is null
				and [Process date] between @staticpooldate3 and @staticpooldate2    -- DATEADD(month,-1,@staticpooldate2)		-- Later give the @staticpooldate date here 
				and MATURITYDATE> @staticpooldate2      -- DATEADD(month,-1,@staticpooldate2)	-- add 3 month in currrent date
			) A
				left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
				on b.loantype=a.TYPE
				where Flag=1 and Open_Flag=1 
				) D
				order by PARENTACCOUNT,ProcessDate


				---select distinct loancategory1,loancategory2,loancategory3 from #loanstatic where [Processdate]>20210831
				----------Bankrupcy Data add
				
drop table if exists #tempBankrupcy
select  
        L.PARENTACCOUNT+'-'+L.ID "LoanID" ,L.PARENTACCOUNT,
		L.ID
       ,L.OPENDATE 
       ,L.CHARGEOFFDATE 
       ,FM.POSTDATE "BK Note Date" 
       ,B.BankruptcyCaseNumber_UserChar1 
       ,B.FilingDate_UserDate1 
       ,B.DischargeDate_UserDate2 
       ,B.DismissDate_UserDate5 
       ,B.ReaffirmationDate_UserDate3 
       ,B.DateConverted_UserDate6 
       ,coalesce(B.FilingDate_UserDate1,FM.postdate) "BK Start" -- *** If 2 t 
,coalesce(L.CHARGEOFFDATE,dischargedate_userdate2,B.dismissdate_UserDate5,B.reaffirmationdate_UserDate3) "BK End" ---Order is important 
---select top 10 * from #tempBankrupcy
into #tempBankrupcy
from ARCUSYM000.dbo.loan L 
left join ARCUSYM000.dbo.FMHISTORY FM 
       on FM.PARENTACCOUNT = L.PARENTACCOUNT 
	          AND FM.ID = L.ID 
	          AND FM.NEWNUMBER = 4.99 
	          AND FM.FMTYPE = 1 
	          AND FM.FIELDNUMBER = 17 
	   join ARCUSYM000.arcu.arculoancategory C 
	          on C.loantype = L.type 
			         AND C.loancategory4 not in ('writeoff','Workout/TDR') 
					 left join ARCUSYM000.tracking.tvwARCUTRACKINGBankruptcy B 
					        on B.PARENTACCOUNT = L.PARENTACCOUNT 
							       AND B.ProcessDate = L.ProcessDate 
								          AND B.CreationDate > L.OPENDATE 
										  where l.ProcessDate in (select max_ProcessDate from #processdate)
										         AND L.APPROVALCODE = 499 
--select * from #tempBankrupcy
			drop table if exists #tempBKFinal
			select Distinct [BK Note Date], [BK Start],
			loanid,PARENTACCOUNT,ID,left(cast(convert(varchar(20),[BK Start],112) as int),6) BK_Start ,
			 left(cast(convert(varchar(20),[BK End],112) as int),6) BK_End 
			 , case when [BK Start]='1900-01-01 00:00:00' then [BK Note Date] else [BK Start] END BK_Start_Final
			 into #tempBKFinal
			 from #tempBankrupcy order by [BK Start]
			 
			drop table if exists #test
			 select [BK Note Date], [BK Start],BK_Start,
			LoanID,ID,PARENTACCOUNT, left(cast(convert(varchar(20),[BK_Start_Final],112) as int),6) BK_Start_Final1, BK_End
			into #Test
			  from #tempBKFinal 
			  
			drop table if exists #test1
			select PARENTACCOUNT, LoanID , ID,min(eomonth(concat(left(BK_Start_Final1 ,4),'-',right(BK_Start_Final1,2),'-01'))) as BK_Start_Final1_EOM
			,max(eomonth(concat(left(BK_End ,4),'-',right(BK_End,2),'-01'))) as BK_End_EOM
			into #test1
			from #Test
			where 1=1
			-- BK_Start_Final1 between '201901' and '202012' 
			and BK_Start_Final1 < BK_End
			group by PARENTACCOUNT, LoanID , ID
			--isnull( BK_End , '299912') 
			--or BK_End='190001'
			 --select * from #test1
		--	 select * from #loanDelinquency1 where BankruptcyCount >1
			 --decstaticpool
	-- Deliquency in last month (Previous Month Del calculation) ---

		drop table if exists #loanDelinquency1
		select processdate,Process_date,[Process Date],AccountNumber,LoanID,[Code 0],[Code 1],[Code 2],[Code 3]
		,loanchargeoff,LoanType,loancategory2,LoanTypeDescription,BankruptcyCount
		into #loanDelinquency1
		from
		 (
				 select 
				Convert(date, cast(l.Processdate as nvarchar)) as Date, l.ProcessDate,left(l.ProcessDate,6) Process_date,
				AccountNumber,l.LoanID,l.LoanOpenDate,LoanDelqDays,datefromparts(left(l.ProcessDate,4),left(right(l.ProcessDate,4),2),right(l.ProcessDate,2)) [Process Date]
				
						,case when LoanDelqDays between 30 and  60    and l.loanchargeoffdate is null then 1 else 0  end [Code 0]
						,case when LoanDelqDays between 61 and  181  and l.loanchargeoffdate is null then 1 else 0 end  [Code 1] 
						,case when LoanDelqDays between 182 and  364  and l.loanchargeoffdate is null then 1 else 0 end  [Code 2]  
						,case when  LoanDelqDays >= 365 and l.loanchargeoffdate is null then 1 else 0 end [Code 3] 
						,case when l.LoanChargeoffDate is not null then 1 else 0 end loanchargeoff
				
								,loancategory2,LoanPastDueAmount,LoanBalance,l.LoanChargeoffDate,l.LoanType, 
				alc.LoanTypeDescription, 
				--Count(t.locator) as BankruptcyCount 
				max(case when datefromparts(left(l.ProcessDate,4),left(right(l.ProcessDate,4),2),right(l.ProcessDate,2)) between AA.BK_Start_Final1_EOM and AA.BK_End_EOM then 1 else 0 end) BankruptcyCount
				from arcusym000.arcu.ARCULoanDetailed  as l
						left join arcusym000.arcu.ARCULoanCategory as alc on alc.LoanType = l.LoanType
						left join ARCUSYM000.dbo.tracking as t on t.processdate = l.ProcessDate and t.PARENTACCOUNT = l.AccountNumber 
						and t.TYPE = 36 and (t.EXPIREDATE is null or t.EXPIREDATE < Convert(date, cast(t.processdate as varchar)))
						left join #test1 AA on l.AccountNumber = AA.PARENTACCOUNT and 
						--left(l.ProcessDate,6)= AA.BK_Start_Final1 and 
						l.LoanID=AA.ID
				where LoanDelqDays > 0 
				and datefromparts(left(l.ProcessDate,4),left(right(l.ProcessDate,4),2),right(l.ProcessDate,2)) between @staticpooldate3 and @staticpooldate2
				and l.ProcessDate in (select max_ProcessDate from #processdate)
				and l.AccountNumber in (select PARENTACCOUNT from #LoanStatic group by PARENTACCOUNT)
				group by l.ProcessDate,l.AccountNumber,l.LoanID,l.LoanOpenDate,l.LoanPastDueAmount,l.LoanChargeoffDate
				,l.LoanType,alc.LoanTypeDescription, l.LoanDelqDays, LoanBalance, loancategory2
		) A
		order by AccountNumber,LoanID,ProcessDate
		--select * from #loanDelinquency1 where AccountNumber='0014195687' order by 3
		--select * from #test1 where PARENTACCOUNT='0014195687'
		--select * from #test1 where PARENTACCOUNT='0013632056'
		--		select processdate,count(*) from #loanDelinquency1 group by processdate

---- Deliquency in this month (Current month Del calculation) ---
--		drop table if exists #loanDelinquency2
--		select processdate,Process_date,AccountNumber,LoanID,Cycle1,Cycle2,Cycle3,Cycle4,cycle5,Cycle6,cycle7,Cycle8,loanchargeoff,LoanType,loancategory2,LoanTypeDescription
--		into #loanDelinquency2
--		from
--		 (
--				 select 
--				Convert(date, cast(l.Processdate as nvarchar)) as Date, l.ProcessDate,left(l.ProcessDate,6) Process_date,
--				AccountNumber, 
--				LoanID, 
--				l.LoanOpenDate, 
--				LoanDelqDays,
--				case when LoanDelqDays between 1 and    29  and l.loanchargeoffdate is null then 1 else 0  end Cycle1 
--				,case when LoanDelqDays between 30 and  59  and l.loanchargeoffdate is null then 1 else 0 end  Cycle2 
--				,case when LoanDelqDays between 60 and  89  and l.loanchargeoffdate is null then 1 else 0 end  Cycle3 
--				,case when LoanDelqDays between 90 and  119 and l.loanchargeoffdate is null then 1 else 0 end   Cycle4 
--				,case when LoanDelqDays between 120 and 149 and l.loanchargeoffdate is null then 1 else 0 end   Cycle5 
--				,case when LoanDelqDays between 150 and 179 and l.loanchargeoffdate is null then 1 else 0 end   Cycle6 
--				,case when LoanDelqDays between 180 and 359 and l.loanchargeoffdate is null then 1 else 0 end   Cycle7 
--				,case when LoanDelqDays >= 360 and l.loanchargeoffdate is null then 1 else 0 end Cycle8 
--				,case when l.LoanChargeoffDate is not null then 1 else 0 end loanchargeoff
--				,loancategory2
--				,LoanPastDueAmount, 
--				LoanBalance, 
--				l.LoanChargeoffDate, 
--				l.LoanType, 
--				alc.LoanTypeDescription, 
--				Count(t.locator) as BankruptcyCount 
--				from arcusym000.arcu.ARCULoanDetailed  as l
--						left join arcusym000.arcu.ARCULoanCategory as alc on alc.LoanType = l.LoanType
--						left join ARCUSYM000.dbo.tracking as t on t.processdate = l.ProcessDate and t.PARENTACCOUNT = l.AccountNumber 
--						and t.TYPE = 36 and (t.EXPIREDATE is null or t.EXPIREDATE < Convert(date, cast(t.processdate as varchar)))
--				where LoanDelqDays > 0 
--				and datefromparts(left(l.ProcessDate,4),left(right(l.ProcessDate,4),2),right(l.ProcessDate,2)) = @staticpooldate2
--				and l.AccountNumber in (select PARENTACCOUNT from #LoanStatic group by PARENTACCOUNT)
--				group by l.ProcessDate,l.AccountNumber,l.LoanID,l.LoanOpenDate,l.LoanPastDueAmount,l.LoanChargeoffDate
--				,l.LoanType,alc.LoanTypeDescription, l.LoanDelqDays, LoanBalance,alc.loancategory2
--		) A
--		order by AccountNumber,LoanID,ProcessDate,LoanTypeDescription


		
-- Mortgage Data --
 drop table if exists #Tracking
		select parentaccount,ID,(USERCHAR1) USERCHAR1,EXPIREDATE,ProcessDate,left(ProcessDate,6) Process_Date 
		into #Tracking
		from (select * from
					(select *,case when isnumeric(USERCHAR1)=1 then USERCHAR1 else null end Mortgage_id ,len(USERCHAR1) Mortgage_id_len
					from ARCUSYM000..TRACKING where ProcessDate in (select max_ProcessDate from #processdate) and TYPE='35'
					) AA
		where Mortgage_id is not null and Mortgage_id_len=10 and Mortgage_id in (select Mortgageid from AE_EDW..F_Mortgage_Daily where AsOfDate in (select [process date] from #processdate))
		) A
		where datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2))
		between @staticpooldate3 and @staticpooldate2
		-- dateadd(month,-1,CONCAT(left(@staticpooldate2,4),left(right(@staticpooldate2,5),2),right(@staticpooldate2,2))) 
		group by parentaccount,ID,USERCHAR1,EXPIREDATE,ProcessDate

		--Add Mortgage description and clear out the error of loantypedescription
		drop table if exists #Mortgage
		select  b.parentaccount,
		a.*,case when Extractdate=Opendate then 1 else 0 end New_flag,d.MortgageOriginalBalance orignalbalance
		into #Mortgage
		from (select case when len(month(AsOfDate))=1 then concat(year(AsOfDate),0,month(AsOfDate)) else concat(year(AsOfDate),month(AsOfDate)) end Extractdate
				,case when len(month(MortgageOpenDate))=1 then concat(year(MortgageOpenDate),0,month(MortgageOpenDate)) else concat(year(MortgageOpenDate),month(MortgageOpenDate)) end Opendate
				,* from AE_EDW..F_Mortgage_Daily where AsOfDate in (select [process date] from #processdate)
				) A 
		left join #Tracking b
		on a.mortgageid=b.USERCHAR1 and a.Extractdate=b.Process_Date
		left join AE_EDW..D_Mortgage d on a.mortgageid=d.MortgageID
		where CoreMortgageStatus='Active' and AsOfDate between @staticpooldate3 and @staticpooldate2 and
		 b.EXPIREDATE is null  

		-- select AsOfDate,count(*),count(distinct MortgageID) from #Mortgage group by AsOfDate order by AsOfDate
--Mortgage Deliquency ---
		Drop table if exists #mortgagedelinquency1
		Select *
		into #mortgagedelinquency1
		from 
		(
		SELECT 
        case when datediff(d, h.duedate, DateAdd(month, -1, eomonth(cutoffdate)))  < 30 then 'New' end New30Flag
		,case when datediff(d, h.duedate, DateAdd(month, -1, eomonth(cutoffdate)))  between 30 and 60 then 'New' end New61Flag
                ,h.loanid,InvestorID MortgageDescription
	
    ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 30 and datediff(d, h.duedate, eomonth(cutoffdate)) < 60 then 1 else 0  end [Code 0]
    ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 60 and datediff(d, h.duedate, eomonth(cutoffdate)) < 180 then 1 else 0  end [Code 1]
	,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 180 and datediff(d, h.duedate, eomonth(cutoffdate)) < 359 then 1 else 0  end [Code 2]
	,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 360 then 1 else 0  end [Code 3]
    ,h.duedate NextDueDate,lastpmtrecd,cast(CutoffDate as date) CutoffDate,MortgageOpenDate,InvestorPrinBal,CurrentBalance Balance
    ,datediff(d, h.duedate, eomonth(cutoffdate)) DQDays
	,Case when len(MONTH(CutoffDate)) = 1 then CONCAT(YEAR(cutoffdate),0,month(cutoffdate))
	else CONCAT(YEAR(cutoffdate),month(cutoffdate)) end as extract_date 
	FROM [UICCU].[dbo].[HarlandLoanCutoff] h
    left join ae_edw.dbo.f_mortgage f on f.mortgageid = h.loanid and month(reportmonth) = month(cutoffdate)
                                    and year(reportmonth) = year(cutoffdate)
	WHERE CutoffDate in (select [process date] from #processdate) and
	loanprincipalbal > 0 AND RegPrincipalColl != investorprinbal AND (investorid LIKE '%bal' or investorid LIKE '%fix%' or investorid LIKE '%arm' or
								investorid LIKE 'E-10YR' or investorid LIKE 'E-WORK' or InvestorID like '%Equity%' or InvestorID like '%TDR%' or
								InvestorID = 'F-ARM' or InvestorID = 'FAB-HH' )
               and investorprinbal is not null
               and datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and RecordType <> 2
		)T 
			   where CutoffDate between @staticpooldate3 and @staticpooldate2
			   --T.extract_date =  concat(left(DATEADD(month,-1,@staticpooldate2),4),left(RIGHT(DATEADD(month,-1,@staticpooldate2),5),2))
		--    select * #mortgagedelinquency1
--- Next Deliquency -- 
	--Drop table if exists #mortgagedelinquency2
	--Select *
	--into #mortgagedelinquency2
	--	from (

	--	SELECT 
 --       case when datediff(d, h.duedate, DateAdd(month, -1, eomonth(cutoffdate)))  < 30 then 'New' end New30Flag
	--	,case when datediff(d, h.duedate, DateAdd(month, -1, eomonth(cutoffdate)))  between 30 and 60 then 'New' end New61Flag
 --               ,h.loanid,InvestorID MortgageDescription
	--,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and datediff(d, h.duedate, eomonth(cutoffdate)) < 30 then 1 else 0  end [DQ 1+ Days Flag]
 --   ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 30 and datediff(d, h.duedate, eomonth(cutoffdate)) < 60 then 1 else 0  end [DQ 30+ Days Flag]
 --   ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 60 and datediff(d, h.duedate, eomonth(cutoffdate)) < 90 then 1 else 0  end [DQ 60+ Days Flag]
	--,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 90 and datediff(d, h.duedate, eomonth(cutoffdate)) < 120 then 1 else 0  end [DQ 90+ Days Flag]
	--,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 120 and datediff(d, h.duedate, eomonth(cutoffdate)) < 150 then 1 else 0  end [DQ 120+ Days Flag]
 --   ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 150 and datediff(d, h.duedate, eomonth(cutoffdate)) < 179 then 1 else 0  end [DQ 150+ Days Flag]
	--,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 180 and datediff(d, h.duedate, eomonth(cutoffdate)) < 359 then 1 else 0  end [DQ 180+ Days Flag]
	--,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 360 then 1 else 0  end [DQ 360+ Days Flag]
 --   ,h.duedate NextDueDate,lastpmtrecd,CutoffDate,MortgageOpenDate,InvestorPrinBal
 --   ,datediff(d, h.duedate, eomonth(cutoffdate)) DQDays
	--,Case when len(MONTH(CutoffDate)) = 1 then CONCAT(YEAR(cutoffdate),0,month(cutoffdate))
	--else CONCAT(YEAR(cutoffdate),month(cutoffdate)) end as extract_date 

	--FROM [UICCU].[dbo].[HarlandLoanCutoff] h
 --   left join ae_edw.dbo.f_mortgage f on f.mortgageid = h.loanid and month(reportmonth) = month(cutoffdate)
 --                                   and year(reportmonth) = year(cutoffdate)
	--WHERE loanprincipalbal > 0 AND RegPrincipalColl != investorprinbal AND (investorid LIKE '%bal' or investorid LIKE '%fix%' or investorid LIKE '%arm' or
	--							investorid LIKE 'E-10YR' or investorid LIKE 'E-WORK' or InvestorID like '%Equity%' or InvestorID like '%TDR%' or
	--							InvestorID = 'F-ARM' or InvestorID = 'FAB-HH' )
 --              and investorprinbal is not null
 --              and datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and RecordType <> 2)T 
	--		   where T.extract_date = concat(left(@staticpooldate2,4),left(RIGHT(@staticpooldate2,5),2)) 


			 --  Select * from #mortgagedelinquency3

			 --Duplicate Check
		drop table if exists #mortgagedelinquency3
		Select cast(a.AsOfDate as date) date,a.PARENTACCOUNT,a.MortgageID
		,isnull(b.[Code 0],0) [Code 0],isnull(b.[Code 1],0) [Code 1],
		isnull(b.[Code 2],0) [Code 2],isnull(b.[Code 3],0) [Code 3]
		,0 chargeoff,c.InvestorID,CurrentBalance Balance
		into #mortgagedelinquency3
		from
		(Select * from #mortgage) a 
		left join #mortgagedelinquency1 b 
		on a.MortgageID = b.loanid and a.AsOfDate=b.CutoffDate
		left join
			(select T.PARENTACCOUNT, T.PROCESSORACCOUNTNUMBER_USERCHAR1 "LoanID", M.InvestorID
			,cast(convert(varchar(20),t.ProcessDate) as Date) Processdate
				from ARCUSYM000.tracking.tvwARCUTRACKINGMortgage T
				join [AE_EDW].dbo.[D_MortgageParticipation] M
				on M.mortgageid= T.PROCESSORACCOUNTNUMBER_UserChar1
				where t.ProcessDate in (select max_ProcessDate from #processdate)
				and T.ExpireDate is null
				) C
				on a.MortgageID=c.LoanID and a.AsOfDate=c.Processdate 

			--Select   * from #mortgagedelinquency3 order by PARENTACCOUNT, date
		--	select date,count(*) from #mortgagedelinquency3 where parentaccount=0013947245 group by date

			--select * from #mortgagedelinquency1 order by parentaccount

			--drop table if exists #mortgagedelinquency4
		 --  Select a.PARENTACCOUNT,a.MortgageID,b.[DQ 1+ Days Flag],b.[DQ 30+ Days Flag]
		 --  ,b.[DQ 60+ Days Flag],b.[DQ 90+ Days Flag],b.[DQ 120+ Days Flag],b.[DQ 150+ Days Flag],b.[DQ 180+ Days Flag],b.[DQ 360+ Days Flag],0 chargeoff,a.MortgageDescription
		 --  into #mortgagedelinquency4
		 --   from #mortgage a  left join #mortgagedelinquency2 b on a.MortgageID = b.loanid
			
			--Select * from #mortgagedelinquency4

			--Select '#LoanStatic' , COUNT(1) from #LoanStatic
			--Select '#loanDelinquency1' , COUNT(1) from #loanDelinquency1
			--Select '#Tracking' , COUNT(1) from #Tracking
			--Select '#Mortgage' , COUNT(1) from #Mortgage
			--Select '#mortgagedelinquency1' , COUNT(1) from #mortgagedelinquency1
			--Select '#mortgagedelinquency3' , COUNT(1) from #mortgagedelinquency3
			---select '#finalloandeliquency1' , count(1) from #finalloandeliquency1
			--select '#creditcard' , count(1) from #creditcard


			
			
			
			
			-- Adding the previous month Del colums
			drop table if exists #finalloandeliquency1
			Select a.[Process date],a.PARENTACCOUNT,a.ID LoanID,Loan_Categories,a.LoanCategory1,a.LoanCategory2,a.LoanCategory3,a.LoanTypeDescription
			,isnull([Code 0],0) [Code 0],isnull([Code 1],0) [Code 1],isnull([Code 2],0) [Code 2],isnull([Code 3],0) [Code 3],
			isnull(loanchargeoff,0) loanchargeoff, Balance
			 into #finalloandeliquency1 from #LoanStatic a  
			 left join #loanDelinquency1 b on a.PARENTACCOUNT = b.AccountNumber and a.ID = b.LoanID
			 and a.ProcessDate=b.ProcessDate

			 
			 -- Adding the Current month Del columns
			-- drop table if exists #finalloandeliquency2
			--Select a.PARENTACCOUNT,a.ID LoanID,Loan_Categories,a.LoanCategory2,LoanCategory3,LoanCategory4
			--,Cycle1,Cycle2,Cycle3,Cycle4,Cycle5,Cycle6,Cycle7,Cycle8,loanchargeoff,LoanTypeDescription
			-- into #finalloandeliquency2 from #LoanStatic a  left join #loanDelinquency2 b on a.PARENTACCOUNT = b.AccountNumber and a.ID = b.LoanID
--------------------
-- Credit card Staticpool -- 

		drop table if exists #creditcard
  select distinct [Social Security Number],Durable_Key
  into #creditcard
	  from Tmgdata..cardholder a
	  where Active_Flag=1 
	  and  fullExtractdate between dateadd(month,-35,@creditcarddate) and @creditcarddate
	    AND [Card Description]  not IN ('Mastercard Business')
	
 ---Delinquency2 ----
 Drop table if exists #creditcarddelinquency2
Select  eomonth(cast(fullExtractdate as date)) Date,durable_key,[Social Security Number],
 case when [Card Account Delinquent Day Account new] between 30 and 59   and chargeoff_flag<>1  then 1 else 0  end  [Code 0]
 ,case when [Card Account Delinquent Day Account new] between 60 and 179   and chargeoff_flag<>1  then 1 else 0  end  [Code 1]
 ,case when [Card Account Delinquent Day Account new] between 180 and 359  and chargeoff_flag<>1  then 1 else 0  end  [Code 2]
 ,case when [Card Account Delinquent Day Account new] >360 and chargeoff_flag<>1   then 1 else 0 end  [Code 3]
 ,case when chargeoff_flag = 1   then 1 else 0 end chargeoff,[Card Description],[Last Statement Balance Amount] Balance
 into #creditcarddelinquency2
  from
		  (select * 
		,case when pre_del>0 then pre_del-lead(date,1) over(partition by Durable_Key order by extract_datepart) else [Card Account Delinquent Day Account] end [Card Account Delinquent Day Account new]
		,lead(date,1) over(partition by Durable_Key order by extract_datepart) pre_days
		from 
		(select *,day(eomonth(cast(fullExtractdate as date))) date
		,lead([Card Account Delinquent Day Account],1) over(partition by Durable_Key order by extract_datepart) pre_del
		from TMGData..cardholder where Active_Flag=1 
		) AB  ) A
where fullExtractdate between dateadd(month,-35,@creditcarddate) and @creditcarddate
--extract_datepart between case when len(month(@creditcarddate))=1 then concat(year(@creditcarddate),0,month(@creditcarddate))  
--else concat(year(@creditcarddate),0,month(@creditcarddate))  end 
and active_flag = 1
 AND [Card Description] not IN ('Mastercard Business')
 ---------------------
-- Drop table if exists #finalcreditcarddelinquency1
-- Select a.[Social Security Number],a.Durable_Key,Cycle1,Cycle2,Cycle3,Cycle4,Cycle5,Cycle6,Cycle7,Cycle8,chargeoff,[Card Description]
-- into #finalcreditcarddelinquency1
-- from #creditcard a  left join #creditcarddelinquency1 b on a.Durable_Key = b.Durable_Key and a.[Social Security Number] = b.[Social Security Number]
------------------

 Drop table if exists #finalcreditcarddelinquency2
 Select date,a.[Social Security Number],a.Durable_Key,[Code 0],[Code 1],[Code 2],[Code 3],chargeoff,[Card Description],Balance
 into #finalcreditcarddelinquency2
 from #creditcard a  left join #creditcarddelinquency2 b on a.Durable_Key = b.Durable_Key and a.[Social Security Number] = b.[Social Security Number]

 
	--	select * from #finalcreditcarddelinquency2
-------
			--  merging mortgage and credit card info in the overall data for previous moth cal

			Drop table if exists  #finaldelinquency1
		   Select [Process date],PARENTACCOUNT ,LoanID,[Code 0],[Code 1],[Code 2],[Code 3],loanchargeoff,
		   LoanTypeDescription,Balance,LoanCategory1,LoanCategory2,LoanCategory3,Loan_Categories LoanCategories
		   into #finaldelinquency1
		   from #finalloandeliquency1 
		   union all 
		   Select *,'Real Estate' loancategory1,'1st Mortgage H' loancategory2,'1st Mortgage H' loancategory3,'1st Mortgage' loancategory5 
		   from #mortgagedelinquency3
		   union all
		   Select date,rtrim([Social Security Number]),rtrim(Durable_Key),[Code 0],[Code 1],[Code 2],[Code 3],chargeoff,[Card Description],Balance
		   ,'Personal' loancategory1,'Unsecured' loancategory2,'CreditCard' loancategory3,'CreditCard' loancategory5
		    from #finalcreditcarddelinquency2
			
			--select * from [ARCUSYM000].[arcu].[ARCULoanCategory]
			----  Credit card and mortgage loan may have duplications
			--select loancategory4,count(distinct CONCAT(parentaccount,loanid)) 
			--from #finaldelinquency1 
			--group by loancategory4 
			--order by loancategory4

			go
			--select [process date],count(distinct CONCAT(parentaccount,loanid)),count( CONCAT(parentaccount,loanid)) 
			--from #finaldelinquency1 where loancategory4='1st Mortgage'
			--group by [process date] 
			--order by [process date]
   
   
		     --10182


--Drop table if exists #deliquency_previousmonth
--		Select *,
--		case when Cycle1=1 then '1.Cycle1'
--		 when Cycle2=1 then '2.Cycle2'
--		 when Cycle3=1 then '3.Cycle3'
--		 when Cycle4=1 then '4.Cycle4'
--		 when Cycle5=1 then '5.Cycle5'
--		 when Cycle6=1 then '6.Cycle6'
--		 when Cycle7=1 then '7.Cycle7'
--		 when Cycle8=1 then '8.Cycle8'
--		 when loanchargeoff=1 then '9.chargeoff'
--		 else '0.Not Deliquent'
--		 end as 'j' ,eomonth(dateadd(month,-1,[Process date])) pre_month
--		 into #deliquency_previousmonth
--		from #finaldelinquency1
--		order by [Process date]

	
	--Select a.[Process date],concat(a.PARENTACCOUNT,a.loanid) UNID,a.Loan_Categories,a.LoanTypeDescription
	--,a.LoanCategory2,a.LoanCategory3,a.LoanCategory4,a.j Cur_month ,b.J as Next_month,b.pre_month pre_monthdate
	--from #deliquency_previousmonth a  
 --   left join (select * from #deliquency_previousmonth) b on a.PARENTACCOUNT = b.PARENTACCOUNT 
	--and a.LoanID = b.LoanID and a.[Process date]=b.pre_month
	--order by a.[Process date]
	
	--- ## savan
	--select distinct month1  from Analytics.dbo.rollratetracker_CallReportView order by month1
	drop table if exists Analytics.dbo.rollratetracker_CallReportView

	create table Analytics.dbo.rollratetracker_CallReportView 
	(month1 nvarchar(4000),Month2 nvarchar(4000),LoanCategories varchar(50) ,LoanTypeDescription nvarchar(100),
	LoanCategory1 varchar(50),LoanCategory2 varchar(50),LoanCategory3 varchar(50),Cur_month varchar(15),
	[1.Cycle1] int,[2.Cycle2] int,[3.cycle3] int,[4.cycle4] int,[0.Not Deliquent] int ,[9.chargeoff] int ,Date1 date,Date2 date)

	Truncate table Analytics.dbo.rollratetracker_CallReportView
		
	
	
	Drop table if exists #deliquency_Cursor
		Select *,
		case when [Code 0]=1 then '1.Cycle1'
		 when [Code 1]=1 then '2.Cycle2'
		 when [Code 2]=1 then '3.Cycle3'
		 when [Code 3]=1 then '4.Cycle4'
		 
		 when loanchargeoff=1 then '9.chargeoff'
		 else '0.Not Deliquent'
		 end as 'j' 
		 into #deliquency_Cursor
		from #finaldelinquency1
		order by [Process date]
		
	--	select * from Analytics..rollratetracker_CallReportView
		 		
		
		--------13 month 
	----**********/////-Cursor
	declare @extrac_date date
	declare @extrac_date1 date

	declare curp cursor  for

	select distinct [Process date] from #deliquency_Cursor order by [Process date]

	open curp
	fetch next from curp into @extrac_date

	While @@FETCH_STATUS = 0

	begin 
			
			declare curp1 cursor  for

			select distinct [Process date] from #deliquency_Cursor where  [Process date] >@extrac_date order by 1

			open curp1

			fetch next from curp1 into @extrac_date1

			While @@FETCH_STATUS = 0

			begin 
			print (@extrac_date1)

			print (@extrac_date)
			
			Insert Into Analytics.dbo.rollratetracker_CallReportView
			select 
			month1,Month2,LoanCategories,LoanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,Cur_month,[1.Cycle1],[2.Cycle2]
			,[3.cycle3],[4.cycle4],[0.Not Deliquent],[9.chargeoff],Date1,Date2
 			
			from
			(
			Select format(a.[Process date] , 'MMM-yy') as month1,format(b.[Process date], 'MMM-yy') as Month2
			,concat(a.PARENTACCOUNT,a.loanid) UNID
			,a.LoanCategories,a.LoanTypeDescription
			,a.LoanCategory1,a.LoanCategory2,a.LoanCategory3,a.j Cur_month ,b.J as Next_month, a.[Process date] Date1,b.[Process date] Date2
			from (Select * from #deliquency_Cursor where [Process date] = @extrac_date) a  
			left join (select * from #deliquency_Cursor where [Process date] = @extrac_date1) b on a.PARENTACCOUNT = b.PARENTACCOUNT 
			and a.LoanID = b.LoanID --and a.[Process date]=@extrac_date1
					) A
			PIVOT (
			count(UNID)
			for
			Next_month		
			in 
			([1.cycle1],[2.cycle2],[3.cycle3],[4.cycle4],[0.Not Deliquent],[9.chargeoff]) 
			) as PVT
			order by Cur_month

			fetch next from curp1 into @extrac_date1

			end
			close curp1
			deallocate curp1

		fetch next from curp into @extrac_date

	end
	close curp
	deallocate curp

	
	
	-----13 month comparisonn table
	
	
	
	--select top 10 * from analytics..Rollratetracker_13Month_compare
		
		drop table if exists analytics..Rollratetracker_13Month_compare_CALLReport
		select [Process date],format([Process date] , 'MMM-yy') ShortDate
		,count(CONCAT(parentaccount,loanid)) [# Loans],sum([Code 0]) [Code 0],sum([Code 1]) [Code 1],sum([Code 2]) [Code 2]
		,sum([Code 3]) [Code 3],sum(loanchargeoff) loanchargeoff,count(CONCAT(parentaccount,loanid)) [0.Not Deliquent]
		,loanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,LoanCategories ,Balance
		into analytics..Rollratetracker_13Month_compare_CallReport
		from #deliquency_Cursor
		group by  [Process date],loanTypeDescription,LoanCategory1,LoanCategory2,LoanCategory3,LoanCategories ,Balance
		 order by [Process date]

		-- select * from analytics..Rollratetracker_13Month_compare_CallReport




   --Change the static pool month from entire code....
		drop table if exists #temp1
		drop table if exists #temp_pre_12mo

		drop table if exists #temp_post_6mo_2
		drop table if exists #temp_post_6mo_2a

		drop table if exists #temp2
		drop table if exists #temp3
		drop table if exists #temp4
		drop table if exists #temp5
		drop table if exists #temp6
		drop table if exists #temp7
		drop table if exists #temp8
		drop table if exists #temp9
		drop table if exists #temp10
		drop table if exists #temp11
		drop table if exists #temp12
		drop table if exists #temp13
		drop table if exists #temp14
		drop table if exists #temp15
		drop table if exists #transaction
		drop table if exists #transaction_band
		drop table if exists #transaction_MCC_Flag
		drop table if exists #risk_model_final	

	
	
	--static pool data
	drop table if exists #temp1
	select Durable_Key,[Credit Limit],[Card Account Delinquent Day Account],
	[Last Statement Balance Amount]
    into #temp1
	FROM [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold')
	and [Internal Status Code] in ('','N') and [External Status Code] in ('')
	and Extract_DatePart = 202304 and mob > 11 and [Social Security Number] <> '0'


	go
	--Step 1: Pre 12 month numbers
	select Durable_Key as d_pre_12mo,
	sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Times_1_cycle_delq_pre_12mo,
	sum(case when [Card Account Delinquent Day Account] >= 60 and [Card Account Delinquent Day Account] < 90 then 1 else 0 end) as Times_2_cycle_delq_pre_12mo,
    avg(case when [Credit Limit] = 0 then 0 else [Last Statement Balance Amount]/[Credit Limit] end) as avg_Utilization_pre_12mo
	into #temp_pre_12mo
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and Extract_DatePart between 202304 - 99 and 202304
	and Durable_Key in 
	(select Durable_Key from #temp1)
	group by Durable_Key
	

	go

	--Post 6 month Profit numbers

	select Durable_Key,
	sum(case when ChargeoffAmount_final > 0 then 1 else 0 end) as chgoff_flag_1to12_months,
	sum(case when ChargeoffAmount_final > 0 and (Extract_DatePart between 202304 + 1 and 202310) then 1 else 0 end) as chgoff_flag_1to6_months,
	sum(case when ChargeoffAmount_final > 0 and (Extract_DatePart between 202304 + 1 and 202401) then 1 else 0 end) as chgoff_flag_1to9_months,
	sum(case when ChargeoffAmount_final > 0 and (Extract_DatePart between 202304 + 4 and 202401) then 1 else 0 end) as chgoff_flag_4to9_months,
	
	sum(case when [Card Account Delinquent Day Account] > 90 then 1 else 0 end) as Cycle_3plus_delq_flag_1to12_months,
	sum(case when [Card Account Delinquent Day Account] > 90 and (Extract_DatePart between 202304 + 1 and 202310) then 1 else 0 end) as Cycle_3plus_delq_flag_1to6_months,
	sum(case when [Card Account Delinquent Day Account] > 90 and (Extract_DatePart between 202304 + 1 and 202401) then 1 else 0 end) as Cycle_3plus_delq_flag_1to9_months,
	sum(case when [Card Account Delinquent Day Account] > 90 and (Extract_DatePart between 202304 + 4 and 202401) then 1 else 0 end) as Cycle_3plus_delq_flag_4to9_months
	
	into #temp_post_6mo_2
	from [TMGData].[dbo].[cardholder]
	where [Active_flag] = 1 
	and Extract_DatePart between 202304 + 1 and 202404
	and Durable_Key in 
	(select Durable_Key from #temp1)
	group by Durable_Key
		
	go
	
	select
	Durable_Key as d_post_6mo,
	case when (Cycle_3plus_delq_flag_1to12_months >= 1 or chgoff_flag_1to12_months >= 1) then 1 else 0 end as Cycle_3plus_delq_flag_1to12_months,
	case when (Cycle_3plus_delq_flag_1to6_months >= 1 or chgoff_flag_1to6_months >= 1) then 1 else 0 end as Cycle_3plus_delq_flag_1to6_months,
	case when (Cycle_3plus_delq_flag_4to9_months >= 1 or chgoff_flag_4to9_months >= 1) then 1 else 0 end as Cycle_3plus_delq_flag_4to9_months,
	case when (Cycle_3plus_delq_flag_1to9_months >= 1 or chgoff_flag_1to9_months >= 1) then 1 else 0 end as Cycle_3plus_delq_flag_1to9_months

	into #temp_post_6mo_2a
	from  #temp_post_6mo_2 b


	go
	--drop table if exists #temp2
	select a.*,b.*,d.*
	into #temp2
	from #temp1 a
	left join #temp_pre_12mo b
	on a.Durable_Key = b.d_pre_12mo
	left join #temp_post_6mo_2a d
	on a.Durable_Key = d.d_post_6mo

	go
	
	--drop table #temp3
	select 
	a.SSN as SSN_CC,
	a.FICO as FICO_score,
	case when b.AT36 is not null then b.AT36 else c.[AT36]*1 end as Months_since_most_recent_delq
	into #temp3
	from [BureauData].[dbo].[TransUnionAttributeHistory] a
	left join [Analytics].[dbo].[Transunion_CreditBureau_data_Apr22] b
	on a.SSN = b.SSN
	left join [Analytics].[dbo].[TransUnion_CreditBureau_data_May21] c
	on a.SSN = c.SSN
	
	--select * from #temp3
	--where SSN_CC in (select [Social Security Number] from #temp4)
	
	go

	Select Durable_Key,[Social Security Number]
	into #temp4
	from [TMGData].[dbo].[cardholder]
    where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business','MasterCard Classic','MasterCard Gold')
	and [Internal Status Code] in ('','N') and [External Status Code] in ('')
	and Extract_DatePart = 202304 and mob > 11 and [Social Security Number] <> '0'
	
	go


	select a.*,b.[Social Security Number]
	into #temp5
	from #temp2 a
	left join #temp4 b
	on a.Durable_Key = b.Durable_Key
	
	go

	select a.*,b.*
	into #temp6
	from #temp5 a
	left join #temp3 b
	on a.[Social Security Number] = b.SSN_CC

	go

	select [Social Security Number],count(*) as cnt
	into #temp7
	from #temp6 
	group by [Social Security Number]
	having count(*) >= 2

	go

	select *
	into #temp8
	from #temp3
	where SSN_CC not in 
	(select [Social Security Number] from #temp7)

	go
	--drop table if exists #temp10
	select a.*,b.*,
	case 
	when b.FICO_score is null or b.FICO_score >= 9000 then 'NA'
	when b.FICO_score < 600 then '<600'
	when b.FICO_score < 629 then '600-629'
	when b.FICO_score < 659 then '630-659'
	when b.FICO_score < 689 then '660-689'
	when b.FICO_score < 719 then '690-719'
	when b.FICO_score < 759 then '720-759'
	when b.FICO_score < 799 then '760-799'
	else '800+' end as FICO_Band,
	case 
	when b.Months_since_most_recent_delq is null then 'NA'
	when b.Months_since_most_recent_delq = 0 then '1.0'
	when b.Months_since_most_recent_delq <= 3 then '2.1-3'
	when b.Months_since_most_recent_delq <= 6 then '3.4-6'
	when b.Months_since_most_recent_delq <= 12 then '4.7-12'
	else '5.13+' end as Months_since_most_recent_delq_Band
	into #temp9
	from #temp5 a
	left join #temp8 b
	on a.[Social Security Number] = b.SSN_CC
	
	go

	
	select [Durable_Key],
	[Credit Limit],
	[Times_1_cycle_delq_pre_12mo],
	[Times_2_cycle_delq_pre_12mo],
	[avg_Utilization_pre_12mo],
	Cycle_3plus_delq_flag_1to6_months,
	Cycle_3plus_delq_flag_1to12_months,
	Cycle_3plus_delq_flag_1to9_months,
	Cycle_3plus_delq_flag_4to9_months,
	[SSN_CC],
	[FICO_score],
	[Months_since_most_recent_delq]
	into #risk_model_final
	from #temp9
	

	go


	drop table if exists #temp10
	select 
	 Durable_Key
	,[Times_2_cycle_delq_pre_12mo]
	,[Months_since_most_recent_delq]
	,[Times_1_cycle_delq_pre_12mo]
	,[avg_Utilization_pre_12mo]
	,[FICO_score]
	,Cycle_3plus_delq_flag_1to6_months
	into #temp10
	from #risk_model_final


	go


	drop table if exists  #temp11
	select 
	Durable_Key
	,case when Times_2_cycle_delq_pre_12mo <= 0 then -19.4
	when Times_2_cycle_delq_pre_12mo > 0 then 317.7
	else Times_2_cycle_delq_pre_12mo end Times_2_cycle_delq_pre_12mo
	,case when Months_since_most_recent_delq <= 1 then 207.2
	when Months_since_most_recent_delq > 1 then -83.7
	when Months_since_most_recent_delq is null then 2.5
	else Months_since_most_recent_delq end Months_since_most_recent_delq
	,case when Times_1_cycle_delq_pre_12mo <= 0 then -64.2
	when Times_1_cycle_delq_pre_12mo > 0 then 186.2
	else Times_1_cycle_delq_pre_12mo end Times_1_cycle_delq_pre_12mo
	,case when avg_Utilization_pre_12mo <= 0.1174 then -212.9
	when  avg_Utilization_pre_12mo <= 0.32066 then -84.6
	when avg_Utilization_pre_12mo < 0.87533 then 25.6
	when avg_Utilization_pre_12mo > 0.87533 then 132.8
	else avg_Utilization_pre_12mo end avg_Utilization_pre_12mo
	,case when FICO_score <= 800 then -83.5
	when FICO_score > 800 then -742.4
	when FICO_score is null then 180.2
	else FICO_score end FICO_score
	, Cycle_3plus_delq_flag_1to6_months
	into #temp11
	from #temp10


	   
	   go

	   
	   drop table if exists  #temp12
	   select 
	   Durable_Key

	   ,(EXP (-5.5063496
        + 0.0034792 * Times_2_cycle_delq_pre_12mo
		+ 0.0096444 * Months_since_most_recent_delq
		+ 0.0040912 * Times_1_cycle_delq_pre_12mo
		+ 0.0077612 * avg_Utilization_pre_12mo
		+ 0.0099412 * FICO_score
		)
		/
		(1 +
		EXP (-5.5063496
        + 0.0034792 * Times_2_cycle_delq_pre_12mo
		+ 0.0096444 * Months_since_most_recent_delq
		+ 0.0040912 * Times_1_cycle_delq_pre_12mo
		+ 0.0077612 * avg_Utilization_pre_12mo
		+ 0.0099412 * FICO_score
		)
		)
		) as [Probability Value]
       ,Cycle_3plus_delq_flag_1to6_months
	   into #temp12
	   from #temp11


	   go


	   drop table if exists #temp13
	   select Durable_Key,[Probability Value]
	   ,NTILE(10) over (order by [Probability Value] desc) as Deciling
	   ,Cycle_3plus_delq_flag_1to6_months
	   into #temp13
	   from #temp12


	   go


	     drop table if exists  #temp14
        select Durable_Key,TranAmount,MCCCode,TranCode
		,case when TranCode=255 then TranAmount*-1 else TranAmount end [Amount]
		,case when extract_datepart between 202105 and 202204 then 1 else 2 end Year_flag 
		into #temp14
		from [TMGData].[dbo].[Transactions]
		where extract_datepart between 202105 and 202304
		and TranCode in (253,255) and MCCcode not in (0,3,6)
		and Durable_Key in (select Durable_Key from #risk_model_final)


		go
		
		
		drop table if exists  #temp15				
        select 
		a.Durable_Key,b.[MCC Code]
		,sum(case when a.Year_flag=1 then a.Amount else 0 end ) Last_to_last_year_spend
		,sum(case when a.Year_flag=2 then a.Amount else 0 end ) Last_year_spend
		,b.[MCC Description],b.[MCC Group (final)]
		into #temp15
		from #temp14 a
		left join Analytics.brijesh.MCC_Mapping b
		on a.MCCCode=b.[MCC Code]
		group by a.Durable_Key,b.[MCC Description],b.[MCC Group (final)],b.[MCC Code]

		
		
		go
		
		
		drop table if exists  #transaction
		select
		Durable_Key,Cycle_3plus_delq_flag_1to6_months
		,SUM(ISNULL([Book Stores_Last_to_last_year_spend(202105-202204)],0)) AS [Book Stores_Last_to_last_year_spend]
		,SUM(ISNULL([Book Stores_Last_year_spend(202205-202304)],0)) AS [Book Stores_Last_year_spend]
		,SUM(ISNULL([Clothing Stores_Last_to_last_year_spend(202105-202204)],0)) AS [Clothing Stores_Last_to_last_year_spend]
		,SUM(ISNULL([Clothing Stores_Last_year_spend(202205-202304)],0)) AS [Clothing Stores_Last_year_spend]
		,SUM(ISNULL([GAS AND FUEL SERVICES_Last_to_last_year_spend(202105-202204)],0)) AS [GAS AND FUEL SERVICES_Last_to_last_year_spend]
		,SUM(ISNULL([GAS AND FUEL SERVICES_Last_year_spend(202205-202304)],0)) AS [GAS AND FUEL SERVICES_Last_year_spend]
		,SUM(ISNULL([GROCERY STORES_Last_to_last_year_spend(202105-202204)],0)) AS [GROCERY STORES_Last_to_last_year_spend]
		,SUM(ISNULL([GROCERY STORES_Last_year_spend(202205-202304)],0)) AS [GROCERY STORES_Last_year_spend]
		,SUM(ISNULL([HEALTHCARE_Last_to_last_year_spend(202105-202204)],0)) AS [HEALTHCARE_Last_to_last_year_spend]
		,SUM(ISNULL([HEALTHCARE_Last_year_spend(202205-202304)],0)) AS [HEALTHCARE_Last_year_spend]
		,SUM(ISNULL([ASSOCIATIONS/ORGANIZATIONS_Last_to_last_year_spend(202105-202204)],0)) AS [ASSOCIATIONS/ORGANIZATIONS_Last_to_last_year_spend]
		,SUM(ISNULL([ASSOCIATIONS/ORGANIZATIONS_Last_year_spend(202205-202304)],0)) AS [ASSOCIATIONS/ORGANIZATIONS_Last_year_spend]
		,SUM(ISNULL([Travel & Entertainment_Last_to_last_year_spend(202105-202204)],0)) AS [Travel & Entertainment_Last_to_last_year_spend]
		,SUM(ISNULL([Travel & Entertainment_Last_year_spend(202205-202304)],0)) AS [Travel & Entertainment_Last_year_spend]
		,SUM(ISNULL([Education_Last_to_last_year_spend(202105-202204)],0)) AS [Education_Last_to_last_year_spend]
		,SUM(ISNULL([Education_Last_year_spend(202205-202304)],0)) AS [Education_Last_year_spend]
		,SUM(ISNULL([Business Services_Last_to_last_year_spend(202105-202204)],0)) AS [Business Services_Last_to_last_year_spend]
		,SUM(ISNULL([Business Services_Last_year_spend(202205-202304)],0)) AS [Business Services_Last_year_spend]
		,SUM(ISNULL([Airlines_Last_to_last_year_spend(202105-202204)],0)) AS [Airlines_Last_to_last_year_spend]
		,SUM(ISNULL([Airlines_Last_year_spend(202205-202304)],0)) AS [Airlines_Last_year_spend]
		,SUM(ISNULL([Hotels_Last_to_last_year_spend(202105-202204)],0)) AS [Hotels_Last_to_last_year_spend]
		,SUM(ISNULL([Hotels_Last_year_spend(202205-202304)],0)) AS [Hotels_Last_year_spend]
		,SUM(ISNULL([ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_to_last_year_spend(202105-202204)],0)) AS [ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_to_last_year_spend]
		,SUM(ISNULL([ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_year_spend(202205-202304)],0)) AS [ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_year_spend]
		,SUM(ISNULL([FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_to_last_year_spend(202105-202204)],0)) AS [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_to_last_year_spend]
		,SUM(ISNULL([FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_year_spend(202205-202304)],0)) AS [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_year_spend]
		into #transaction
		from (

					select Durable_Key 
					,[MCC Group (final)] +'_'+col col       
					,Cycle_3plus_delq_flag_1to6_months
					,value
					from
								(select 
								 b.Durable_Key
								,b.[MCC Group (final)]
								,a.Cycle_3plus_delq_flag_1to6_months
								,cast(sum(b.Last_to_last_year_spend) as numeric(10,2)) [Last_to_last_year_spend(202105-202204)]
								,cast(sum(b.Last_year_spend) as numeric(10,2)) [Last_year_spend(202205-202304)]
								from #temp15 b
								left join #risk_model_final a
								on b.Durable_Key=a.Durable_Key
								where b.[MCC Code] not in ('0','3','6') and b.[MCC Group (final)] in ('Book Stores','Clothing Stores','GROCERY STORES','HEALTHCARE'
								,'Travel & Entertainment','Education','ENTERTAINMENT/THEATER/DANCE STUDIOS','FURNISHINGS/APPLIANCES/MAINTENANCE/HOME'
								,'ASSOCIATIONS/ORGANIZATIONS','Business Services','Airlines','Hotels','GAS AND FUEL SERVICES')
								group by b.Durable_Key,b.[MCC Group (final)],a.Cycle_3plus_delq_flag_1to6_months) a
						  UNPIVOT (
							value 
							for col in ([Last_to_last_year_spend(202105-202204)],[Last_year_spend(202205-202304)])
							) as [Unpivot table]
							) t
							PIVOT (
							sum(value)
							FOR col in 
							([Book Stores_Last_to_last_year_spend(202105-202204)]
							,[Clothing Stores_Last_to_last_year_spend(202105-202204)],[GAS AND FUEL SERVICES_Last_to_last_year_spend(202105-202204)]
       ,[GROCERY STORES_Last_to_last_year_spend(202105-202204)],[HEALTHCARE_Last_to_last_year_spend(202105-202204)],[FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_to_last_year_spend(202105-202204)]
       ,[Travel & Entertainment_Last_to_last_year_spend(202105-202204)],[Education_Last_to_last_year_spend(202105-202204)],[ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_to_last_year_spend(202105-202204)],[ASSOCIATIONS/ORGANIZATIONS_Last_to_last_year_spend(202105-202204)]
	   ,[Book Stores_Last_year_spend(202205-202304)],[Clothing Stores_Last_year_spend(202205-202304)],[GAS AND FUEL SERVICES_Last_year_spend(202205-202304)]
       ,[GROCERY STORES_Last_year_spend(202205-202304)],[HEALTHCARE_Last_year_spend(202205-202304)],[FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_year_spend(202205-202304)]
       ,[Travel & Entertainment_Last_year_spend(202205-202304)],[Education_Last_year_spend(202205-202304)],[ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_year_spend(202205-202304)],[ASSOCIATIONS/ORGANIZATIONS_Last_year_spend(202205-202304)]
	   ,[Business Services_Last_year_spend(202205-202304)],[Airlines_Last_year_spend(202205-202304)],[Hotels_Last_year_spend(202205-202304)]
	   ,[Business Services_Last_to_last_year_spend(202105-202204)],[Airlines_Last_to_last_year_spend(202105-202204)],[Hotels_Last_to_last_year_spend(202105-202204)]
	       )
		   ) AS Pivot_table
		   group by Pivot_table.Durable_Key,Pivot_table.Cycle_3plus_delq_flag_1to6_months



	go
	
	
	
	drop table if exists #transaction_band
	select 	
	Durable_Key
	,Cycle_3plus_delq_flag_1to6_months				  
	,[Book Stores_Last_to_last_year_spend]
	,[Book Stores_Last_year_spend]
	,[Book Stores % diff]
	,case when [Book Stores % diff] < -100 then '< -100%' when [Book Stores % diff] <= -90 then '-100% to -90%'
	when [Book Stores % diff] <=-75 then '-90% to -75%' when [Book Stores % diff] <= -50 then '-75% to -50%'
	when [Book Stores % diff] <= -25 then '-50% to -25%' when [Book Stores % diff] <= -10 then '-25% to -10%'
	when [Book Stores % diff] <= 10 then '-10% to 10%' when [Book Stores % diff] <= 25 then '10% to 25%'
	when [Book Stores % diff] <= 50 then '25% to 50%' when [Book Stores % diff] <= 75 then '50% to 75%'
	when [Book Stores % diff] <= 90 then '75% to 90%' when [Book Stores % diff] <= 100 then '90% to 100%'
	when [Book Stores % diff] > 100 then '100%+' end [Book Stores % diff band]
	,[Clothing Stores_Last_to_last_year_spend]
	,[Clothing Stores_Last_year_spend]
	,[Clothing Stores % diff]
	,case when [Clothing Stores % diff] < -100 then '< -100%'
	when [Clothing Stores % diff] <= -90 then '-100% to -90%' when [Clothing Stores % diff] <=-75 then '-90% to -75%'
	when [Clothing Stores % diff] <= -50 then '-75% to -50%' when [Clothing Stores % diff] <= -25 then '-50% to -25%'
	when [Clothing Stores % diff] <= -10 then '-25% to -10%' when [Clothing Stores % diff] <= 10 then '-10% to 10%'
	when [Clothing Stores % diff] <= 25 then '10% to 25%'  when [Clothing Stores % diff] <= 50 then '25% to 50%'
	when [Clothing Stores % diff] <= 75 then '50% to 75%'  when [Clothing Stores % diff] <= 90 then '75% to 90%'
	when [Clothing Stores % diff] <= 100 then '90% to 100%' when [Clothing Stores % diff] > 100 then '100%+' end [Clothing Stores % diff band]
	,[GAS AND FUEL SERVICES_Last_to_last_year_spend]
	,[GAS AND FUEL SERVICES_Last_year_spend]
	,[GAS AND FUEL SERVICES % diff]
	,case when [GAS AND FUEL SERVICES % diff] < -100 then '< -100%' when [GAS AND FUEL SERVICES % diff] <= -90 then '-100% to -90%'
	when [GAS AND FUEL SERVICES % diff] <=-75 then '-90% to -75%' when [GAS AND FUEL SERVICES % diff] <= -50 then '-75% to -50%'
	when [GAS AND FUEL SERVICES % diff] <= -25 then '-50% to -25%' when [GAS AND FUEL SERVICES % diff] <= -10 then '-25% to -10%'
	when [GAS AND FUEL SERVICES % diff] <= 10 then '-10% to 10%' when [GAS AND FUEL SERVICES % diff] <= 25 then '10% to 25%'
	when [GAS AND FUEL SERVICES % diff] <= 50 then '25% to 50%' when [GAS AND FUEL SERVICES % diff] <= 75 then '50% to 75%'
	when [GAS AND FUEL SERVICES % diff] <= 90 then '75% to 90%' when [GAS AND FUEL SERVICES % diff] <= 100 then '90% to 100%'
	when [GAS AND FUEL SERVICES % diff] > 100 then '100%+' end [GAS AND FUEL SERVICES % diff band]
	,[GROCERY STORES_Last_to_last_year_spend]
	,[GROCERY STORES_Last_year_spend]
	,[GROCERY STORES % diff]
	,case when [GROCERY STORES % diff] < -100 then '< -100%' when [GROCERY STORES % diff] <= -90 then '-100% to -90%'
	when [GROCERY STORES % diff] <=-75 then '-90% to -75%' when [GROCERY STORES % diff] <= -50 then '-75% to -50%'
	when [GROCERY STORES % diff] <= -25 then '-50% to -25%' when [GROCERY STORES % diff] <= -10 then '-25% to -10%'
	when [GROCERY STORES % diff] <= 10 then '-10% to 10%' when [GROCERY STORES % diff] <= 25 then '10% to 25%'
	when [GROCERY STORES % diff] <= 50 then '25% to 50%' when [GROCERY STORES % diff] <= 75 then '50% to 75%'
	when [GROCERY STORES % diff] <= 90 then '75% to 90%' when [GROCERY STORES % diff] <= 100 then '90% to 100%'
	when [GROCERY STORES % diff] > 100 then '100%+' end [GROCERY STORES % diff band]
	,[HEALTHCARE_Last_to_last_year_spend]
	,[HEALTHCARE_Last_year_spend]
	,[HEALTHCARE % diff]
	,case when [HEALTHCARE % diff] < -100 then '< -100%' when [HEALTHCARE % diff] <= -90 then '-100% to -90%'
	when [HEALTHCARE % diff] <=-75 then '-90% to -75%' when [HEALTHCARE % diff] <= -50 then '-75% to -50%'
	when [HEALTHCARE % diff] <= -25 then '-50% to -25%' when [HEALTHCARE % diff] <= -10 then '-25% to -10%'
	when [HEALTHCARE % diff] <= 10 then '-10% to 10%' when [HEALTHCARE % diff] <= 25 then '10% to 25%'
	when [HEALTHCARE % diff] <= 50 then '25% to 50%' when [HEALTHCARE % diff] <= 75 then '50% to 75%'
	when [HEALTHCARE % diff] <= 90 then '75% to 90%' when [HEALTHCARE % diff] <= 100 then '90% to 100%'
	when [HEALTHCARE % diff] > 100 then '100%+' end [HEALTHCARE % diff band]
	,[ASSOCIATIONS/ORGANIZATIONS_Last_to_last_year_spend]
	,[ASSOCIATIONS/ORGANIZATIONS_Last_year_spend]
	,[ASSOCIATIONS/ORGANIZATIONS % diff]
	,case when [ASSOCIATIONS/ORGANIZATIONS % diff] < -100 then '< -100%' when [ASSOCIATIONS/ORGANIZATIONS % diff] <= -90 then '-100% to -90%'
	when [ASSOCIATIONS/ORGANIZATIONS % diff] <=-75 then '-90% to -75%' when [ASSOCIATIONS/ORGANIZATIONS % diff] <= -50 then '-75% to -50%'
	when [ASSOCIATIONS/ORGANIZATIONS % diff] <= -25 then '-50% to -25%' when [ASSOCIATIONS/ORGANIZATIONS % diff] <= -10 then '-25% to -10%'
	when [ASSOCIATIONS/ORGANIZATIONS % diff] <= 10 then '-10% to 10%' when [ASSOCIATIONS/ORGANIZATIONS % diff] <= 25 then '10% to 25%'
	when [ASSOCIATIONS/ORGANIZATIONS % diff] <= 50 then '25% to 50%' when [ASSOCIATIONS/ORGANIZATIONS % diff] <= 75 then '50% to 75%'
	when [ASSOCIATIONS/ORGANIZATIONS % diff] <= 90 then '75% to 90%' when [ASSOCIATIONS/ORGANIZATIONS % diff] <= 100 then '90% to 100%'
	when [ASSOCIATIONS/ORGANIZATIONS % diff] > 100 then '100%+' end [ASSOCIATIONS/ORGANIZATIONS % diff band]
	,[Travel & Entertainment_Last_to_last_year_spend]
	,[Travel & Entertainment_Last_year_spend]
	,[Travel & Entertainment % diff]
	,case when [Travel & Entertainment % diff] < -100 then '< -100%' when [Travel & Entertainment % diff] <= -90 then '-100% to -90%'
	when [Travel & Entertainment % diff] <=-75 then '-90% to -75%' when [Travel & Entertainment % diff] <= -50 then '-75% to -50%'
	when [Travel & Entertainment % diff] <= -25 then '-50% to -25%' when [Travel & Entertainment % diff] <= -10 then '-25% to -10%'
	when [Travel & Entertainment % diff] <= 10 then '-10% to 10%' when [Travel & Entertainment % diff] <= 25 then '10% to 25%'
	when [Travel & Entertainment % diff] <= 50 then '25% to 50%' when [Travel & Entertainment % diff] <= 75 then '50% to 75%'
	when [Travel & Entertainment % diff] <= 90 then '75% to 90%' when [Travel & Entertainment % diff] <= 100 then '90% to 100%'
	when [Travel & Entertainment % diff] > 100 then '100%+' end [Travel & Entertainment % diff band]
	,[Education_Last_to_last_year_spend]
	,[Education_Last_year_spend]
	,[Education % diff]
	,case when [Education % diff] < -100 then '< -100%' when [Education % diff] <= -90 then '-100% to -90%'
	when [Education % diff] <=-75 then '-90% to -75%' when [Education % diff] <= -50 then '-75% to -50%'
	when [Education % diff] <= -25 then '-50% to -25%' when [Education % diff] <= -10 then '-25% to -10%'
	when [Education % diff] <= 10 then '-10% to 10%' when [Education % diff] <= 25 then '10% to 25%'
	when [Education % diff] <= 50 then '25% to 50%' when [Education % diff] <= 75 then '50% to 75%'
	when [Education % diff] <= 90 then '75% to 90%' when [Education % diff] <= 100 then '90% to 100%'
	when [Education % diff] > 100 then '100%+' end [Education % diff band]
	,[Business Services_Last_to_last_year_spend]
	,[Business Services_Last_year_spend]
	,[Business Services % diff]
	,case when [Business Services % diff] < -100 then '< -100%' when [Business Services % diff] <= -90 then '-100% to -90%'
	when [Business Services % diff] <=-75 then '-90% to -75%' when [Business Services % diff] <= -50 then '-75% to -50%'
	when [Business Services % diff] <= -25 then '-50% to -25%' when [Business Services % diff] <= -10 then '-25% to -10%'
	when [Business Services % diff] <= 10 then '-10% to 10%' when [Business Services % diff] <= 25 then '10% to 25%'
	when [Business Services % diff] <= 50 then '25% to 50%' when [Business Services % diff] <= 75 then '50% to 75%'
	when [Business Services % diff] <= 90 then '75% to 90%' when [Business Services % diff] <= 100 then '90% to 100%'
	when [Business Services % diff] > 100 then '100%+' end [Business Services % diff band]
	,[Airlines_Last_to_last_year_spend]
	,[Airlines_Last_year_spend]
	,[Airlines % diff]
	,case when [Airlines % diff] < -100 then '< -100%' when [Airlines % diff] <= -90 then '-100% to -90%'
	when [Airlines % diff] <=-75 then '-90% to -75%' when [Airlines % diff] <= -50 then '-75% to -50%'
	when [Airlines % diff] <= -25 then '-50% to -25%' when [Airlines % diff] <= -10 then '-25% to -10%'
	when [Airlines % diff] <= 10 then '-10% to 10%' when [Airlines % diff] <= 25 then '10% to 25%'
	when [Airlines % diff] <= 50 then '25% to 50%' when [Airlines % diff] <= 75 then '50% to 75%'
	when [Airlines % diff] <= 90 then '75% to 90%' when [Airlines % diff] <= 100 then '90% to 100%'
	when [Airlines % diff] > 100 then '100%+' end [Airlines % diff band]
	,[Hotels_Last_to_last_year_spend]
	,[Hotels_Last_year_spend]
	,[Hotels % diff]
	,case when [Hotels % diff] < -100 then '< -100%' when [Hotels % diff] <= -90 then '-100% to -90%'
	when [Hotels % diff] <=-75 then '-90% to -75%' when [Hotels % diff] <= -50 then '-75% to -50%'
	when [Hotels % diff] <= -25 then '-50% to -25%' when [Hotels % diff] <= -10 then '-25% to -10%'
	when [Hotels % diff] <= 10 then '-10% to 10%' when [Hotels % diff] <= 25 then '10% to 25%'
	when [Hotels % diff] <= 50 then '25% to 50%' when [Hotels % diff] <= 75 then '50% to 75%'
	when [Hotels % diff] <= 90 then '75% to 90%' when [Hotels % diff] <= 100 then '90% to 100%'
	when [Hotels % diff] > 100 then '100%+' end [Hotels % diff band]
	,[ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_to_last_year_spend]
	,[ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_year_spend]
	,[ENTERTAINMENT/THEATER/DANCE STUDIOS % diff]
	,case when [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff] < -100 then '< -100%' when [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff] <= -90 then '-100% to -90%'
	when [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff] <=-75 then '-90% to -75%' when [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff] <= -50 then '-75% to -50%'
	when [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff] <= -25 then '-50% to -25%' when [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff] <= -10 then '-25% to -10%'
	when [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff] <= 10 then '-10% to 10%' when [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff] <= 25 then '10% to 25%'
	when [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff] <= 50 then '25% to 50%' when [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff] <= 75 then '50% to 75%'
	when [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff] <= 90 then '75% to 90%' when [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff] <= 100 then '90% to 100%'
	when [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff] > 100 then '100%+' end [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff band]
    ,[FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_to_last_year_spend]
	,[FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_year_spend]
	,[FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff]
	,case when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff] < -100 then '< -100%' when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff] <= -90 then '-100% to -90%'
	when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff] <=-75 then '-90% to -75%' when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff] <= -50 then '-75% to -50%'
	when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff] <= -25 then '-50% to -25%' when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff] <= -10 then '-25% to -10%'
	when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff] <= 10 then '-10% to 10%' when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff] <= 25 then '10% to 25%'
	when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff] <= 50 then '25% to 50%' when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff] <= 75 then '50% to 75%'
	when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff] <= 90 then '75% to 90%' when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff] <= 100 then '90% to 100%'
	when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff] > 100 then '100%+' end [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff band]

	into #transaction_band
	from 
		(select * 
		,cast(case when [Book Stores_Last_to_last_year_spend] = 0 and [Book Stores_Last_year_spend] != 0 then 5
		when [Book Stores_Last_to_last_year_spend] = 0 and [Book Stores_Last_year_spend] = 0 then NULL
		when [Book Stores_Last_to_last_year_spend] != 0 and [Book Stores_Last_year_spend] = 0 then -5
		else ([Book Stores_Last_year_spend]-[Book Stores_Last_to_last_year_spend])/[Book Stores_Last_to_last_year_spend] end as decimal(18,2))*100 [Book Stores % diff]
		,cast(case when [Clothing Stores_Last_to_last_year_spend] = 0 and [Clothing Stores_Last_year_spend] != 0 then 5
		when [Clothing Stores_Last_to_last_year_spend] = 0 and [Clothing Stores_Last_year_spend] = 0 then NULL
		when [Clothing Stores_Last_to_last_year_spend] != 0 and [Clothing Stores_Last_year_spend] = 0 then -5
		else ([Clothing Stores_Last_year_spend]-[Clothing Stores_Last_to_last_year_spend])/[Clothing Stores_Last_to_last_year_spend] end as decimal(18,2))*100 [Clothing Stores % diff]
		,cast(case when [GAS AND FUEL SERVICES_Last_to_last_year_spend] = 0 and [GAS AND FUEL SERVICES_Last_year_spend] != 0 then 5 
		when  [GAS AND FUEL SERVICES_Last_to_last_year_spend] = 0 and [GAS AND FUEL SERVICES_Last_year_spend] = 0 then NULL
		when [GAS AND FUEL SERVICES_Last_to_last_year_spend] != 0 and [GAS AND FUEL SERVICES_Last_year_spend] = 0 then -5 
		else ([GAS AND FUEL SERVICES_Last_year_spend]-[GAS AND FUEL SERVICES_Last_to_last_year_spend])/[GAS AND FUEL SERVICES_Last_to_last_year_spend] end as decimal(18,2))*100 [GAS AND FUEL SERVICES % diff]
		,cast(case when [GROCERY STORES_Last_to_last_year_spend] = 0 and [GROCERY STORES_Last_year_spend] != 0 then 5
		when  [GROCERY STORES_Last_to_last_year_spend] = 0 and [GROCERY STORES_Last_year_spend] = 0 then NULL
		when [GROCERY STORES_Last_to_last_year_spend] != 0 and [GROCERY STORES_Last_year_spend] = 0 then -5
		else ([GROCERY STORES_Last_year_spend]-[GROCERY STORES_Last_to_last_year_spend])/[GROCERY STORES_Last_to_last_year_spend] end as decimal(18,2))*100 [GROCERY STORES % diff]
		,cast(case when [HEALTHCARE_Last_to_last_year_spend] = 0 and [HEALTHCARE_Last_year_spend] != 0 then 5
		when  [HEALTHCARE_Last_to_last_year_spend] = 0 and [HEALTHCARE_Last_year_spend] = 0 then NULL
		when [HEALTHCARE_Last_to_last_year_spend] != 0 and [HEALTHCARE_Last_year_spend] = 0 then -5 
		else ([HEALTHCARE_Last_year_spend]-[HEALTHCARE_Last_to_last_year_spend])/[HEALTHCARE_Last_to_last_year_spend] end as decimal(18,2))*100 [HEALTHCARE % diff]
		,cast(case when [ASSOCIATIONS/ORGANIZATIONS_Last_to_last_year_spend] = 0 and [ASSOCIATIONS/ORGANIZATIONS_Last_year_spend] != 0 then 5 
		when  [ASSOCIATIONS/ORGANIZATIONS_Last_to_last_year_spend] = 0 and [ASSOCIATIONS/ORGANIZATIONS_Last_year_spend] = 0 then NULL
		when [ASSOCIATIONS/ORGANIZATIONS_Last_to_last_year_spend] != 0 and [ASSOCIATIONS/ORGANIZATIONS_Last_year_spend] = 0 then -5
		else ([ASSOCIATIONS/ORGANIZATIONS_Last_year_spend]-[ASSOCIATIONS/ORGANIZATIONS_Last_to_last_year_spend])/[ASSOCIATIONS/ORGANIZATIONS_Last_to_last_year_spend] end as decimal(18,2))*100 [ASSOCIATIONS/ORGANIZATIONS % diff]
		,cast(case when [Travel & Entertainment_Last_to_last_year_spend] = 0 and [Travel & Entertainment_Last_year_spend] != 0 then 5 
		when  [Travel & Entertainment_Last_to_last_year_spend] = 0 and [Travel & Entertainment_Last_year_spend] = 0 then NULL
		when [Travel & Entertainment_Last_to_last_year_spend] != 0 and [Travel & Entertainment_Last_year_spend] = 0 then -5 
		else ([Travel & Entertainment_Last_year_spend]-[Travel & Entertainment_Last_to_last_year_spend])/[Travel & Entertainment_Last_to_last_year_spend] end as decimal(18,2))*100 [Travel & Entertainment % diff]
		,cast(case when [Education_Last_to_last_year_spend] = 0 and [Education_Last_year_spend] != 0 then 5 
		when  [Education_Last_to_last_year_spend] = 0 and [Education_Last_year_spend] = 0 then NULL
		when [Education_Last_to_last_year_spend] != 0 and [Education_Last_year_spend] = 0 then -5 
		else ([Education_Last_year_spend]-[Education_Last_to_last_year_spend])/[Education_Last_to_last_year_spend] end as decimal(18,2))*100 [Education % diff]
		,cast(case when [Business Services_Last_to_last_year_spend] = 0 and [Business Services_Last_year_spend] != 0 then 5
		when  [Business Services_Last_to_last_year_spend] = 0 and [Business Services_Last_year_spend] = 0 then NULL
		when [Business Services_Last_to_last_year_spend] != 0 and [Business Services_Last_year_spend] = 0 then -5
		else ([Business Services_Last_year_spend]-[Business Services_Last_to_last_year_spend])/[Business Services_Last_to_last_year_spend] end as decimal(18,2))*100 [Business Services % diff]
		,cast(case when [Airlines_Last_to_last_year_spend] = 0 and [Airlines_Last_year_spend] != 0 then 5
		when  [Airlines_Last_to_last_year_spend] = 0 and [Airlines_Last_year_spend] = 0 then NULL
		when [Airlines_Last_to_last_year_spend] != 0 and [Airlines_Last_year_spend] = 0 then -5
		else ([Airlines_Last_year_spend]-[Airlines_Last_to_last_year_spend])/[Airlines_Last_to_last_year_spend] end as decimal(18,2))*100 [Airlines % diff]
		,cast(case when [Hotels_Last_to_last_year_spend] = 0 and [Hotels_Last_year_spend] != 0 then 5
		when  [Hotels_Last_to_last_year_spend] = 0 and [Hotels_Last_year_spend] = 0 then NULL
		when [Hotels_Last_to_last_year_spend] != 0 and [Hotels_Last_year_spend] = 0 then -5
		else ([Hotels_Last_year_spend]-[Hotels_Last_to_last_year_spend])/[Hotels_Last_to_last_year_spend] end as decimal(18,2))*100 [Hotels % diff]
		,cast(case when [ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_to_last_year_spend] = 0 and [ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_year_spend] != 0 then 5 
		when  [ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_to_last_year_spend] = 0 and [ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_year_spend] = 0 then NULL
		when [ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_to_last_year_spend] != 0 and [ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_year_spend] = 0 then -5
		else ([ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_year_spend]-[ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_to_last_year_spend])/[ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_to_last_year_spend] end as decimal(18,2))*100 [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff]
		,cast(case when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_to_last_year_spend] = 0 and [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_year_spend] != 0 then 5 
		when  [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_to_last_year_spend] = 0 and [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_year_spend] = 0 then NULL
		when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_to_last_year_spend] != 0 and [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_year_spend] = 0 then -5
		else ([FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_year_spend]-[FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_to_last_year_spend])/[FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_to_last_year_spend] end as decimal(18,2))*100 [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff]
		from #transaction
		) aa
		
		go
		
		drop table if exists  #transaction_MCC_Flag
	
	
		select *
			,case when ([Book Stores Flag]+[Clothing Stores Flag]+[Education Flag]+[HEALTHCARE Flag]+
			[ENTERTAINMENT/THEATER/DANCE STUDIOS Flag]+[Travel & Entertainment Flag]+[ASSOCIATIONS/ORGANIZATIONS Flag]
			+[GROCERY STORES Flag]+[Business Service Flag]+[Hotels Flag]+[Airlines Flag]+[GAS AND FUEL SERVICES Flag]
			+[FURNISHINGS/APPLIANCES/MAINTENANCE/HOME Flag]) > 6 then 1 else 0 end Flag_final
			into #transaction_MCC_Flag
			from
					(select *
					,case when [Book Stores % diff band] = '< -100%' or [Book Stores % diff band] is null then 1 else 0 end [Book Stores Flag]
					,case when [Clothing Stores % diff band] = '< -100%' or [Clothing Stores % diff band] is null then 1 else 0 end [Clothing Stores Flag]
					,case when [Business Services % diff band] = '< -100%' or [Business Services % diff band] is null then 1 else 0 end [Business Service Flag]
					,case when [Education % diff band] = '< -100%' then 1 else 0 end [Education Flag]
					,case when [HEALTHCARE % diff band] = '< -100%' then 1 else 0 end [HEALTHCARE Flag]
					,case when [Hotels % diff band] is null then 1 else 0 end [Hotels Flag]
					,case when [ENTERTAINMENT/THEATER/DANCE STUDIOS % diff band] = '< -100%' then 1 else 0 end [ENTERTAINMENT/THEATER/DANCE STUDIOS Flag]
					,case when [Travel & Entertainment % diff band] is null then 1 else 0 end [Travel & Entertainment Flag]
					,case when [ASSOCIATIONS/ORGANIZATIONS % diff band] = '< -100%' or [ASSOCIATIONS/ORGANIZATIONS % diff band] is null then 1 else 0 end [ASSOCIATIONS/ORGANIZATIONS Flag]
					,case when [Airlines % diff band] is null then 1 else 0 end [Airlines Flag]
					,case when [GAS AND FUEL SERVICES % diff band] is null then 0 else 1 end [GAS AND FUEL SERVICES Flag]
					,case when [GROCERY STORES % diff band] = '100%+' then 1 else 0 end [GROCERY STORES Flag]
					,case when [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff band] is null then 1 else 0 end [FURNISHINGS/APPLIANCES/MAINTENANCE/HOME Flag]
					from #transaction_band 
					) bb

		
		go

		drop table if  exists ##Final_Riskmodel_list
		select 
		 a.Durable_Key
		,a.[Times_2_cycle_delq_pre_12mo]
		,a.[Months_since_most_recent_delq]
		,a.[Times_1_cycle_delq_pre_12mo]
		,a.[avg_Utilization_pre_12mo]
		,a.[FICO_score]
		,a.Cycle_3plus_delq_flag_1to6_months
		,c.[Probability Value]
		,c.Deciling
		,b.[Book Stores_Last_to_last_year_spend]
		,b.[Book Stores_Last_year_spend]
		,b.[Book Stores % diff]
		,b.[Book Stores % diff band]
		,b.[Book Stores Flag]
		,b.[Clothing Stores_Last_to_last_year_spend]
		,b.[Clothing Stores_Last_year_spend]
		,b.[Clothing Stores % diff]
		,b.[Clothing Stores % diff band]
		,b.[Clothing Stores Flag]
		,b.[GAS AND FUEL SERVICES_Last_to_last_year_spend]
		,b.[GAS AND FUEL SERVICES_Last_year_spend]
		,b.[GAS AND FUEL SERVICES % diff]
		,b.[GAS AND FUEL SERVICES % diff band]
		,b.[GAS AND FUEL SERVICES Flag]
		,b.[GROCERY STORES_Last_to_last_year_spend]
		,b.[GROCERY STORES_Last_year_spend]
		,b.[GROCERY STORES % diff]
		,b.[GROCERY STORES % diff band]
		,b.[GROCERY STORES Flag]
		,b.[HEALTHCARE_Last_to_last_year_spend]
		,b.[HEALTHCARE_Last_year_spend]
		,b.[HEALTHCARE % diff]
		,b.[HEALTHCARE % diff band]
		,b.[HEALTHCARE Flag]
		,b.[ASSOCIATIONS/ORGANIZATIONS_Last_to_last_year_spend]
		,b.[ASSOCIATIONS/ORGANIZATIONS_Last_year_spend]
		,b.[ASSOCIATIONS/ORGANIZATIONS % diff]
		,b.[ASSOCIATIONS/ORGANIZATIONS % diff band]
		,b.[ASSOCIATIONS/ORGANIZATIONS Flag]
		,b.[Travel & Entertainment_Last_to_last_year_spend]
		,b.[Travel & Entertainment_Last_year_spend]
		,b.[Travel & Entertainment % diff]
		,b.[Travel & Entertainment % diff band]
		,b.[Travel & Entertainment Flag]
		,b.[Education_Last_to_last_year_spend]
		,b.[Education_Last_year_spend]
		,b.[Education % diff]
		,b.[Education % diff band]
		,b.[Education Flag]
		,b.[FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_to_last_year_spend]
		,b.[FURNISHINGS/APPLIANCES/MAINTENANCE/HOME_Last_year_spend]
		,b.[FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff]
		,b.[FURNISHINGS/APPLIANCES/MAINTENANCE/HOME % diff band]
		,b.[FURNISHINGS/APPLIANCES/MAINTENANCE/HOME Flag]
		,b.[Business Services_Last_to_last_year_spend]
		,b.[Business Services_Last_year_spend]
		,b.[Business Services % diff]
		,b.[Business Services % diff band]
		,b.[Business Service Flag]
		,b.[Airlines_Last_to_last_year_spend]
		,b.[Airlines_Last_year_spend]
		,b.[Airlines % diff]
		,b.[Airlines % diff band]
		,b.[Airlines Flag]
		,b.[Hotels_Last_to_last_year_spend]
		,b.[Hotels_Last_year_spend]
		,b.[Hotels % diff]
		,b.[Hotels % diff band]
		,b.[Hotels Flag]
		,b.[ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_to_last_year_spend]
		,b.[ENTERTAINMENT/THEATER/DANCE STUDIOS_Last_year_spend]
		,b.[ENTERTAINMENT/THEATER/DANCE STUDIOS % diff]
		,b.[ENTERTAINMENT/THEATER/DANCE STUDIOS % diff band]
		,b.[ENTERTAINMENT/THEATER/DANCE STUDIOS Flag]
		,b.Flag_final
		into ##Final_Riskmodel_list
		from #risk_model_final a
		left join #transaction_MCC_Flag b
		ON a.Durable_Key = b.Durable_Key
		left join #temp13 c
		ON a.Durable_Key = c.Durable_Key
		order by c.Deciling


		go

		select 
		Durable_Key,Deciling,[Probability Value]
		from ##Final_Riskmodel_list
		
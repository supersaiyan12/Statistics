		 -- drop table if exists #1
		select distinct  SSN,AccountNumber PARENTACCOUNT  
		into #1 
		from AE_EDW..D_Member
		where SSN is not null	
	
	go
	--	drop table if exists #2
		select distinct  SSN,PARENTACCOUNT
		 into #2
		 from ARCUSYM000..NAME
		 where PARENTACCOUNT not in (select PARENTACCOUNT from #1)
		 and SSN is not null

		
		 	go
			-- drop table if exists #NAME
			select * 
			into #NAME
			from
			(select * from #1
			union
			select * from #2 ) A


			go
-- drop table if exists #Unsecured_loan
		select * 
		into #Unsecured_loan
		from 
		(select distinct  a.PARENTACCOUNT,id,a.type,OPEN_DATE,CLOSE_DATE,b.loancategory1,SSN
		,case when OPEN_DATE <='2018-01-31'  then 1 else 0 end Flag
		
		from (select PARENTACCOUNT,id
		,TYPE
		,cast (OPENDATE as date) Open_date
		,cast (CLOSEDATE as date) Close_date from [ARCUSYM000]..loan) as a
		left join  [ARCUSYM000].[arcu].[ARCULoanCategory] b
		on b.loantype=a.TYPE
		left join #NAME C
		on a.PARENTACCOUNT=c.PARENTACCOUNT
		) AA
		where Flag=1 and LoanCategory1='unsecured'

		go

		-- drop table if exists Analytics..Unsecured_loan_model_data
		select a.*,case when Unsecured_ACCT_Flag is null then 0 else Unsecured_ACCT_Flag end Final_Unsecured_flag
		into Analytics..Unsecured_loan_model_data
		from Analytics..Master_table_data_V1 a
		left join #Unsecured_loan b
		on a.SSN=b.SSN
		where b.SSN is null and MOB_Savings is not null
		

		go


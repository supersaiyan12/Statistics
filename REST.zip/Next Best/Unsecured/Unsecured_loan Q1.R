rm(list=ls())
library(RODBC)
databaseConnection <- odbcDriverConnect("Driver={SQL Server};server=ACARCU01;database=Analytics;trusted_connection=TRUE")
Unsecured_Data <- sqlQuery(databaseConnection, "select  *  from Analytics..Unsecured_loan_model_data")
UnsecuredLoan_dataframe <- data.frame(Unsecured_Data,stringsAsFactors=FALSE)


#library(pastecs)
#stats <- stat.desc(CREDITCARDdataframe)
#write.csv(stats, "Creditcard_STATS1.csv")
#colnames.listofallvar <-colnames(UnsecuredLoan_dataframe)
#write.csv(colnames.listofallvar,"listofvairable.csv")



UnsecuredLoan_dataframe1 <- (UnsecuredLoan_dataframe[,c(1,893,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,139,140,141,143,144,145,146,147,149,150,153,154,155,156,157,159,160,161,163,164,165,166,167,169,170,173,174,175,176,177,178,179,180,181,182,183,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,212,213,214,215,216,217,218,219,221,222,223,224,225,226,227,228,229,230,231,232,234,239,240,241,242,243,244,245,246,247,249,251,252,253,254,255,256,257,258,259,260,261,262,263,266,267,268,269,270,271,272,273,274,275,276,277,278,279,282,283,284,285,286,287,288,289,290,291,293,297,298,299,301,302,303,304,305,306,307,308,309,310,311,312,313,314,316,317,318,319,320,321,322,323,324,325,326,328,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,349,350,351,352,353,354,355,356,357,358,359,360,361,362,364,365,366,367,368,369,370,371,372,373,374,376,380,381,382,383,384,385,386,387,388,390,391,392,393,394,395,396,397,398,399,400,401,402,403,405,406,407,408,409,410,411,412,413,414,415,417,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,442,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,487,491,492,493,494,495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,523,524,525,526,527,528,529,530,531,532,533,534,535,536,537,538,539,540,541,542,543,544,545,546,547,548,549,550,551,552,553,554,555,556,557,558,559,560,561,562,563,564,565,566,567,568,569,570,571,572,573,574,575,576,577,578,579,580,581,582,583,584,585,586,587,588,589,590,591,592,593,594,595,596,597,598,599,600,601,602,603,604,605,606,607,608,609,610,611,612,613,614,615,616,617,618,619,620,621,622,623,624,625,626,627,628,629,630,631,632,633,634,635,636,637,638,639,640,641,642,643,644,645,646,647,648,649,650,651,652,653,654,655,656,657,658,659,660,661,662,663,664,665,666,667,668,669,670,671,672,673,674,675,676,677,678,679,680,681,682,683,684,685,686,687,688,689,690,691,692,693,694,695,696,697,698,699,700,701,702,703,704,705,706,707,708,709,710,711,712,713,714,715,716,717,718,719,720,721,722,723,724,725,726,727,728,729,730,731,732,733,734,735,736,737,738,739,740,741,742,743,744,745,746,747,748,749,750,751,752,753,754,755,756,757,758,759,760,761,762,763,764,765,766,767,768,769,770,771,772,773,774,775,776,777,778,779,780,781,782,783,784,785,786,787,788,789,790,791,792,793,794,795,796,797,798,799,800,801,802,803,804,805,806,809,810,811,812,813,814,815,816,817,818,819,820,821,822,823,826,827,828,829,830,831,832,833,834,835,836,837,838,839,840,843,844,845,846,847,848,849,850,851,852,853,854,855,856,857,862,863,864,865,866,867,868,869,870,871,872,873,874,877,878,881,882,883,884,885,886,887,888,889,890,891,892)])

#Colnames.UnsecuredLoan_dataframe1 <- colnames(UnsecuredLoan_dataframe1)
#write.csv(Colnames.UnsecuredLoan_dataframe1,"colnames.UnsecuredLoan_dataframe1.csv")

UnsecuredLoan_dataframe1 <- replace(UnsecuredLoan_dataframe1,is.na(UnsecuredLoan_dataframe1),-99999999)

UnsecuredLoan_dataframe1[,c(356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412)][UnsecuredLoan_dataframe1[,c(356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412)]==-99999999] <- 0
UnsecuredLoan_dataframe1[,c(141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160)][UnsecuredLoan_dataframe1[,c(141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160)]==-99999999] <- 0


UnsecuredLoan_dataframe1$Final_Unsecured_flag <- as.factor(UnsecuredLoan_dataframe1$Final_Unsecured_flag)


library(woeBinning)
binning <- woe.binning(UnsecuredLoan_dataframe1,'Final_Unsecured_flag',UnsecuredLoan_dataframe)
tabulate.binning <- woe.binning.table(binning)

#WOEsumm <-data.matrix(tabulate.binning, rownames.force = NA)
#write.csv(WOEsumm,"Summary_bining_allvariable_Unsecured.csv") 

UnsecuredLoan_dataframe_V1 <- (UnsecuredLoan_dataframe1[,c(1,2,144,203,146,179,145,276,275,274,273,272,271,732,743,742,741,740,739,738,737,736,735,734,733,731,730,729,191,284,283,282,281,280,279,278,277,234,299,232,231,230,229,493,492,491,490,489,488,487,486,485,484,483,482,481,480,479,478,477,476,475,474,473,472,471,470,469,468,467,466,465,464,262,261,260,233,270,269,268,267,266,265,264,263,252,251,250,249,248,259,258,257,256,255,254,253,239,238,237,236,235,290,289,288,287,286,285,247,246,245,244,243,242,241,240,170,160,156,152,498,497,496,495,494,129,183,503,502,501,500,499,118,227,225,140,139,138,137,136,135,134,133,132,131,130,128,127,126,125,124,123,122,121,120,119,117,116,115,158,178,176,166,159,155,151,105,188,186,111,216,508,507,506,505,504,96,102,193,223,217,167,210,94,150,157,171,358,390,3,180,201,199,9,513,512,511,510,509,187,153,214,212,181)]) 
summary(UnsecuredLoan_dataframe_V1)
#Colname.UnsecuredLoan_dataframe_V1 <- colnames(UnsecuredLoan_dataframe_V1)
#write.csv(Colname.UnsecuredLoan_dataframe_V1,"Colname.UnsecuredLoan_dataframe_V1.csv")

library(randomForest)
set.seed(2017)
RF <- randomForest(Final_Unsecured_flag ~.,data = UnsecuredLoan_dataframe_V1,ntree=100)

#RF1 <- randomForest(Final_Unsecured_flag ~.,data = UnsecuredLoan_dataframe_V1,ntree=500,localImp=TRUE)
print(RF)
Important_vr <- importance(RF)
write.csv(Important_vr,"Imp_VR100_all_Unsecured_V.csv")
library(randomForestExplainer)
min_depth_frame <- min_depth_distribution(RF)
plot_min_depth_distribution(min_depth_frame)

importance_frame <- measure_importance(RF)
save(importance_frame, file = "importance_frame_Unsecured.rda")
load("importance_frame_Unsecured.rda")
importance_frame
write.csv(importance_frame,"Importance_frame_all_unsecured.csv")


UnsecuredLoan_dataframe_V2<- (UnsecuredLoan_dataframe_V1[,c(1,2,5,7,188,185,201,186,160,3,183,4,204,163,171,191,29,181,180,182,189,187,164,165,200,166,169,119,120,162,118,203,161,202,168,193,192,134,135,6,177,178,190,184,194,117,23,133,167,138,170,179,127)])
UnsecuredLoan_dataframe_V2$Final_Unsecured_flag <- as.numeric(as.character(UnsecuredLoan_dataframe_V2$Final_Unsecured_flag))

require(caTools)
library(caTools)
set.seed(123)   #  set seed to ensure you always have same random numbers generated
sample = sample.split(UnsecuredLoan_dataframe_V2,SplitRatio = 0.60) # splits the data in the ratio mentioned in SplitRatio. After splitting marks these rows as logical TRUE and the the remaining are marked as logical FALSE
train1 =subset(UnsecuredLoan_dataframe_V2,sample ==TRUE) # creates a training dataset named train1 with rows which are marked as TRUE
test1=subset(UnsecuredLoan_dataframe_V2, sample==FALSE)


library(woeBinning)

Binning.train <- woe.binning(train1,'Final_Unsecured_flag',train1)
Training_dataset_woe <- woe.binning.deploy(train1, Binning.train, add.woe.or.dum.var = "woe")


library(My.stepwise)

#my.variable.list <- c("AVG_Month_end_balance_Total_Deposit_ACCT","SUM_Month_end_balance_Total_Deposit_ACCT","MOB_Savings","MAX_MOB_Total_Deposit_ACCT","SUM_Deposited_amount_Total_Deposit_ACCT","SUM_withdrawal_amount_Total_Deposit_ACCT","AVG_withdrawal_amount_Total_Deposit_ACCT","Avg_LASTDIVAMOUNT_Total_Deposit_ACCT","AVG_balancechange_Checkings_Q4","Avg_Month_end_balance_Checkings_Q4","sum_Month_end_balance_Checkings_Q2","Avg_Month_end_balance_Checkings_Q1","Avg_Month_end_balance_Checkings_Staticpool","Avg_Month_end_balance_Checkings_Q2","sum_Month_end_balance_Checkings_Q3","sum_Month_end_balance_Checkings_Staticpool","AVG_balancechange_Checkings_Staticpool","sum_Month_end_balance_Checkings_Q1","avg_withdrawal_amount_savings_Q3","Sum_transaction_count_checkings_Q1","SUM_withdrawal_count_Total_Deposit_ACCT","SUM_Deposited_count_Total_Deposit_ACCT","avg_withdrawal_amount_Checkings_Q2","SUM_Transaction_COUNT_Total_Deposit_ACCT","avg_Deposited_count_Checkings_Q2","AVG_Deposited_count_Total_Deposit_ACCT","AVG_Transaction_COUNT_Total_Deposit_ACCT","avg_Deposited_count_Checkings_Q1","AVG_withdrawal_count_Total_Deposit_ACCT","avg_Deposited_count_Checkings_Q4","Avg_withdrawal_count_Checkings_Q1","Avg_withdrawal_count_Checkings_Q4","Avg_withdrawal_count_Checkings_Q2","avg_Deposited_count_Checkings_Q3","Avg_withdrawal_count_Checkings_Q3","Avg_withdrawal_count_Checkings_Staticpool","avg_Deposited_count_Checkings_Staticpool","Sum_LASTDIVAMOUNT_Checkings_Q2","Last.Statement.Average.Daily.Balance.Amount_CC_Staticpool","RevolvingBalance_CC_Staticpool","Last.Statement.Average.Daily.Balance.Amount_CC_Q1","Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Staticpool","RevolvingBalance_CC_Q1","sum_OVERDRAFTFEEYTD_checkings_Q1","max_interestrate_Vehicles","Max_Month_to_Maturity_Total_loan_ACCT","max_credit_Limit","sum_Transaction_amount_Total_loan_ACCT","CL_CC_StaticPool","sum_OVERDRAFTFEEYTD_checkings_Q3","sum_OVERDRAFTFEEYTD_checkings_Q2")
#my.variable.list <- c("woe.INTERESTRATE_Vehicles.binned","woe.MOB_Savings.binned","woe.Last.Statement.Average.Daily.Balance.Amount_CC_Staticpool.binned","woe.AVG_Transaction_COUNT_Total_Deposit_ACCT.binned","woe.Avg_Month_end_balance_Checkings_Q4.binned","woe.sum_OVERDRAFTFEEYTD_checkings_Q1.binned","woe.avg_withdrawal_amount_savings_Q3.binned","woe.sum_Transaction_amount_Total_loan_ACCT.binned")

my.variable.list <- c("woe.max_interestrate_Vehicles.binned"
#,"woe.Sum_LASTDIVAMOUNT_Checkings_Q2.binned"
,"woe.MOB_Savings.binned"
,"woe.Last.Statement.Average.Daily.Balance.Amount_CC_Staticpool.binned"
#,"woe.AVG_Transaction_COUNT_Total_Deposit_ACCT.binned"
#,"woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned"
#,"woe.Avg_Month_end_balance_Checkings_Q4.binned"
,"woe.sum_OVERDRAFTFEEYTD_checkings_Q1.binned"
#,"woe.max_credit_Limit.binned"
,"woe.avg_withdrawal_amount_savings_Q3.binned"
#,"woe.SUM_Month_end_balance_Total_Deposit_ACCT.binned"
#,"woe.Sum_transaction_count_checkings_Q1.binned"
,"woe.sum_Transaction_amount_Total_loan_ACCT.binned"
,"woe.SUM_withdrawal_amount_Total_Deposit_ACCT.binned"
#,"woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned"
#,"woe.AVG_withdrawal_amount_Total_Deposit_ACCT.binned"
,"woe.CL_CC_StaticPool.binned"
#,"Max_Month_to_Maturity_Total_loan_ACCT"
#,"AVG_withdrawal_count_Total_Deposit_ACCT"
)

My.stepwise.glm.results <- My.stepwise.glm(Y = "Final_Unsecured_flag", my.variable.list, data = Training_dataset_woe, sle = 0.10,
                                           sls = 0.10, myfamily="binomial")
print(Mystepwiseglm_6)
#GLM_Model <- glm(Final_Unsecured_flag~  woe.INTERESTRATE_Vehicles.binned + woe.MOB_Savings.binned + woe.Last.Statement.Average.Daily.Balance.Amount_CC_Staticpool.binned + woe.AVG_Transaction_COUNT_Total_Deposit_ACCT.binned + woe.Avg_Month_end_balance_Checkings_Q4.binned + woe.sum_OVERDRAFTFEEYTD_checkings_Q1.binned + woe.avg_withdrawal_amount_savings_Q3.binned + woe.sum_Transaction_amount_Total_loan_ACCT.binned  ,data = Training_dataset_woe)

GLM_Model <- glm(Final_Unsecured_flag~ woe.max_interestrate_Vehicles.binned 
                 + woe.MOB_Savings.binned + woe.SUM_withdrawal_amount_Total_Deposit_ACCT.binned 
                 + woe.Last.Statement.Average.Daily.Balance.Amount_CC_Staticpool.binned 
                 + woe.sum_Transaction_amount_Total_loan_ACCT.binned + woe.sum_OVERDRAFTFEEYTD_checkings_Q1.binned 
                 + woe.avg_withdrawal_amount_savings_Q3.binned + CL_CC_StaticPool ,data = Training_dataset_woe)
#GLM_Model <- glm(Final_Creditcard_Flag~ woe.avg_withdrawal_amount_Certificates_Q1.binned + woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned + woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned + woe.Diff_Month_end_balance_Certificates_Q1_Q2.binned ,data = Training_dataset_woe)

summary(GLM_Model)

library(car)
library(carData)
Anova(GLM_Model, type="II", test="Wald")
vif(GLM_Model)
alias.result <- alias(GLM_Model)

colnames(Training_dataset_woe)

#write.csv(Training_dataset_woe,"Training_dataset_woe.csv")
fitted.results <- predict(GLM_Model,Training_dataset_woe,type='response')
score_train <- data.frame(Training_dataset_woe,fitted.results)
write.csv(score_train,"score_train_Unsecured_F.csv")

library(gplots)
library(ROCR)
library(pROC)
pdata3 <- as.numeric(format(round(predict(GLM_Model,data = Training_dataset_woe,type='response',na.action = na.pass))))

fitpreds = predict(GLM_Model,Training_dataset_woe,type="response")
fitpred = prediction(fitpreds,Training_dataset_woe$Final_Unsecured_flag)
fitperf = performance(fitpred,"tpr","fpr")
plot(fitperf,col="green",lwd=2,main="ROC Curve for Logistic:  Adult")
abline(a=0,b=1,lwd=2,lty=2,col="gray")
library(AUC)
auc(fitpreds,(Training_dataset_woe$Final_Unsecured_flag))

predictions <- as.numeric(predict(GLM_Model, Training_dataset_woe, type = 'response'))
multiclass.roc(Training_dataset_woe$Final_Unsecured_flag, predictions)


# ******* Test ***********
library(woeBinning)
Binning.test <- woe.binning(test1,'Final_Unsecured_flag',test1)
Test_dataset_woe <- woe.binning.deploy(test1, Binning.test, add.woe.or.dum.var = "woe")

fitted.test.results <- predict(GLM_Model,Test_dataset_woe,type='response')
score_test <- data.frame(Test_dataset_woe$Final_Unsecured_flag,fitted.test.results)
write.csv(score_test,"score_test_CC_4.csv")

library(gplots)
library(ROCR)
library(pROC)
pdata3 <- as.numeric(format(round(predict(GLM_Model,data = Test_dataset_woe,type='response',na.action = na.pass))))

fitpreds = predict(GLM_Model,Test_dataset_woe,type="response")
fitpred = prediction(fitpreds,Test_dataset_woe$Final_Unsecured_flag)
fitperf = performance(fitpred,"tpr","fpr")
plot(fitperf,col="green",lwd=2,main="ROC Curve for Logistic:  Adult")
abline(a=0,b=1,lwd=2,lty=2,col="gray")
library(AUC)
auc(fitpreds,(Test_dataset_woe$Final_Unsecured_flag))

predictions <- as.numeric(predict(GLM_Model, Test_dataset_woe, type = 'response'))
multiclass.roc(Test_dataset_woe$Final_Unsecured_flag, predictions)





train2 <- train1[,c("Final_Unsecured_flag","MOB_Savings"
                    ,"avg_withdrawal_amount_savings_Q3"
                    ,"max_interestrate_Vehicles"
                    ,"Last.Statement.Average.Daily.Balance.Amount_CC_Staticpool"
                    ,"sum_OVERDRAFTFEEYTD_checkings_Q1"
                    ,"sum_Transaction_amount_Total_loan_ACCT"
                    ,"SUM_withdrawal_amount_Total_Deposit_ACCT"
                    ,"CL_CC_StaticPool"
)]

cc<- data.frame()
library(woe)

for( i in 2:9)
{
  
  
  aa <- data.frame(colnames(train2)[i],woe(Data = train2,colnames(train2)[i],TRUE,"Final_Unsecured_flag",10,Bad = 0,Good = 1))
  cc <- rbind(cc,aa)
}
write.csv(cc,file = "WOESummary_10_binned_Unsecured_loan.csv") 

b <- woe(Data = train2,"sum_FEECOUNT1_Certificates_Q4",TRUE,"Final_Creditcard_Flag",10,Bad = 0,Good = 1)

colnames(train1)

# Decision Tree
colnames(Training_dataset_woe)
train3 <- (Training_dataset_woe[,c(2,102,104,106,108,110,112,114,116,118,120,122,124,126,128,130,132,134,136,138,140,142,144,146,148,150,152,154,156,158,160,162,164,166,168,170,172,174,176,178,180,182,184,186,188,190,192,194,196,198,200,202,204,206,208,210,212,214,216,218,220,222,224,226,228,230,232,234,236,238,240,242,244,246,248,250,252,254,256,258,260,262,264,266,268,270,272,274,276,278,280,282,284,286,288,290,292,294,296)])
train3 <- (train1[,c(2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53)])

library(rpart)
train3$Final_Unsecured_flag <- as.factor(train3$Final_Unsecured_flag)

# grow tree 
fit <- rpart(Final_Unsecured_flag ~ .,
             method="class",control =rpart.control(minsplit =1,minbucket=1
                                                   , cp=0 ,maxdepth = 5), data=train3)

score <- predict(fit,train3)
Decision_tree_score <- data.frame(train3,score)
write.csv(Decision_tree_score,"Decision_tree_score_cp0_0011.csv")

#rpart.control(minsplit = 20, minbucket = round(minsplit/3), cp = 0.01, 
# maxcompete = 4, maxsurrogate = 5, usesurrogate = 2, xval = 10,
# surrogatestyle = 0, maxdepth = 30, ...)

printcp(fit) # display the results 
plotcp(fit) # visualize cross-validation results 
summary(fit) # detailed summary of splits

# plot tree 
plot(fit, uniform=TRUE, 
     main="Classification Tree for Kyphosis")
text(fit, use.n=TRUE, all=TRUE, cex=.8,xpd=TRUE)

# create attractive postscript plot of tree 
post(fit, file = "c:/tree.ps", 
     title = "Classification Tree for Kyphosis")



#************* WOE binning For Visulisation ************

train3 <- train1[,c("Direct_vehicle_loan_Flag","AVG_Month_end_balance_Total_Deposit_ACCT")]
cc <- data.frame()
library(woe)

for( i in 2)
{
  
  
  aa <- data.frame(colnames(train3)[i],woe(Data = train3,colnames(train3)[i],TRUE,"Direct_vehicle_loan_Flag",10,Bad = 0,Good = 1))
  cc <- rbind(cc,aa)
}

write.csv(cc,file = "WOESummary_DV_model.csv")



















































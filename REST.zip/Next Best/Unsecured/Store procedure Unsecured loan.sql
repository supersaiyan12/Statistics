


				
	alter procedure dbo.UnsecuredLoanModel @staticpooldate as date
as 
	begin
--	declare @staticpooldate as date
	--set @staticpooldate='2019-04-30'
		
		drop table if exists #Static_SSN_account_final
		drop table if exists ##Static_SSN_account
		drop table if exists #Account_SSN_Name
		drop table if exists #groupproducttype_Deposits
		drop table if exists ##Saving_transaction
		drop table if exists #saving_account_data
		drop table if exists #Deposit_Product_all_data
		drop table if exists ##Checkings_transaction
		drop table if exists #Checkings_account_data
		drop table if exists #masterdata
		drop table if exists ##1
		drop table if exists ##targetList_UnsecuredLoan
		drop table if exists #Saving_account_Summary
		drop table if exists #LOAN_TRANSACITON_DATA
		drop table if exists #Vehicle
		drop table if exists #savings_table1 
		drop table if exists ##Deposit_transaction
		drop table if exists #Unsecured_loan_data
		drop table if exists #CC_SSN_Staticpool
		drop table if exists #Deposit_account_data
		drop table if exists #Deposit_summary
		drop table if exists #savings_account
		drop table if exists #Checkings_account
		drop table if exists #CC_Members_Static
		drop table if exists #CC_data
		drop table if exists #Credit_Card_data
		drop table if exists #Unsecured_loan
		drop table if exists #name
		drop table if exists #1
		drop table if exists #2
		

		select distinct a.PARENTACCOUNT,SSN 
		into #NAME
		from 
		(select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date from ARCUSYM000..NAME) a
		left join ARCUSYM000..SAVINGS b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		and a.ProcessDate=b.ProcessDate
		where a.TYPE=0
		and a.Process_date=@staticpooldate
		and b.SHARECODE=0 
		and b.IRSCODE=0
		and b.TYPE<9000
		and b.type<>10 
		and b.type<>11
		and b.type<>12
		and b.type<>14
		and b.type<>113
		and b.type<>510
		and b.type<>512
		and b.ORIGINALDEPOSITDATE is not null
		and b.CLOSEDATE is null 
		and b.CHARGEOFFDATE is null


		-- Drop table if exists #Static_SSN_account_final
		select distinct  SSN 
		into #Static_SSN_account_final
		 from
			(select b.SSN,a.PARENTACCOUNT,id
			,cast(OPENDATE as date) OPEN_DATE
			,cast(CLOSEDATE as date) CLOSE_DATE
			,cast(CHARGEOFFDATE as date) CHARGEOFFDATE
			,datefromparts(left(a.ProcessDate ,4),right(left(a.ProcessDate,6),2),right(a.ProcessDate,2)) Process_date
			,case when len(month(closedate))=1 then CONCAT(year(closedate),0,month(closedate)) 
			else CONCAT(year(closedate),month(closedate)) end Close_date_Savings 
			,case when len(month(OpenDate))=1 then CONCAT(year(OpenDate),0,month(OpenDate)) 
			else CONCAT(year(OpenDate),month(OpenDate))end  OPEN_date_INT_Savings
			,case when len(month(CHARGEOFFDATE))=1 then CONCAT(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE)) 
			else CONCAT(year(CHARGEOFFDATE),month(CHARGEOFFDATE))end  Chargeoff_date_Savings
		
			from ARCUSYM000..SAVINGS a
			left join #NAME b
			on a.PARENTACCOUNT=b.PARENTACCOUNT
			) aa
			left join 
			(select ssn SSN1,DATEDIFF(month,min_opendate,@staticpooldate) Savings_ACCT_MOB from
				(select ssn,min(Min_Opendate) Min_Opendate from
					(select PARENTACCOUNT,id,MIn(cast(OPENDATE as date)) Min_Opendate
					from ARCUSYM000..SAVINGS
					group by PARENTACCOUNT,ID ) F
			left join ARCUSYM000..NAME G
			on f.PARENTACCOUNT=g.PARENTACCOUNT 
			group by ssn ) A ) AB
		on aa.SSN=ab.SSN1
		where ssn is not null and Savings_ACCT_MOB>=12 and 
		 OPEN_DATE<@staticpooldate  
		 and (CLOSE_DATE is null or CLOSE_DATE>@staticpooldate)
		and (CHARGEOFFDATE is null or CHARGEOFFDATE>@staticpooldate)  
		and Process_date=@staticpooldate 
		

		

		
		
	
	
	select distinct 
	PARENTACCOUNT AccountNumber,SSN
	into ##Static_SSN_account
	from ARCUSYM000..name
		where SSN!=000000000





	-----------------------------------------------------------------------------------------
	-- 
			select distinct  PARENTACCOUNT,ssn 
			Into #Account_SSN_Name
			from #NAME
			where PARENTACCOUNT not in (select PARENTACCOUNT from
		(select PARENTACCOUNT,count(distinct ssn) Count_ssn
		from ARCUSYM000..NAME
		group by PARENTACCOUNT
		having count(distinct ssn)>1) a )
		
		
		
		

		--  Group by product type

		-- 
		
		select *
		,case when ProductName like '%money%'  or ProductName like '% MM %' then 'Money Market'
		when ProductName='Youth Savings' and ApplicationDescription='Certificates' then 'Savings'
		when ProductName='40 Month CD' and ApplicationDescription='Certificates' then 'Checking'
		when ProductName='Certificate' and ApplicationDescription='Certificates' then 'Checking' 
		when ProductName='Public Funds' and ApplicationDescription='Certificates' then 'Savings' 
		 else ApplicationDescription end Product_Group_wise
		into #groupproducttype_Deposits
		from
		(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName
		,ApplicationDescription,ApplicationTableName
		 from [AE_EDW].[tempods].[S_CRMProductType] a
		left join [AE_EDW].[tempods].[S_CRMApplicationType] b
		on a.ApplicationTypeID=b.ApplicationTypeID
		where ApplicationDescription is not null
		and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a
		
		
		
		--  drop table if exists #savings_account

		
				-- closed_flag will remove the account closed account in any time 
		
		select ssn,UNID,Process_Date,PARENTACCOUNT,id,TYPE,LASTDIVAMOUNT,BALANCE Month_end_balance
		--,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE
		,Closed_flag,Close_date,OPEN_DATE 
		,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    
			when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    
			when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
		   ,DATEDIFF(MONTH,OPEN_DATE,@staticpooldate) MOB
		 into #savings_account 
		from 
		(
		select  
		d.SSN
		,aa.*,c.Closed_flag
		
		,case when aa.OPEN_DATE=aa.CLOSE_DATE then 0 else 1 end Funded_loan_flag
		,E.ProductName,E.Product_Group_wise	
		from 
		(select 
		CONCAT(PARENTACCOUNT,id) UNID
		,Process_Date,PARENTACCOUNT,ID,TYPE
		,cast(OPENDATE as date) OPEN_DATE,cast(CLOSEDATE as date)  CLOSE_DATE,LASTDIVDATE
		,LASTDIVAMOUNT
		--,DIVTYPE,DIVRATE
		--,PENALTYTYPE,PENALTYYTD
		,BALANCE
		--,ORIGINALBALANCE,MINIMUMBALANCE,YEARENDBALANCE,WITHDRAWNFROMOPEN,WITHDRAWALFEETYPE,WITHDRAWALFEECOUNT
		,DESCRIPTION
		--,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE
		--,COURTESYFEELY,COURTESYFEEMTD,ACTIVITYDATE,NSFMONTHTODATE,nsffeemtd,FEECOUNT1,FEECOUNT2,FEECOUNT3,FEECOUNT4
		 from (select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
		 from ARCUSYM000..savings) a 
		 where PARENTACCOUNT in (select AccountNumber from ##Static_SSN_account ) ) aa
		left join 
		(select UNID,max(closed_flag) Closed_flag
		from
		(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when CLOSEDATE is null then 0 else 1 end closed_flag
		
		from 
		(select distinct PARENTACCOUNT,ID,CLOSEDATE 
		from ARCUSYM000..SAVINGS
		 where PARENTACCOUNT in (select AccountNumber from ##Static_SSN_account ) 
		 ) a )b
		group by UNID
		) c
		on aa.UNID=c.UNID
		left join ##Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join #groupproducttype_Deposits E
		on e.ProductCode=aa.TYPE
		where Process_Date between DATEADD(month,-12,@staticpooldate) and @staticpooldate
		and PARENTACCOUNT in (select AccountNumber from ##Static_SSN_account ) ) ZZ
		where Product_Group_wise='Savings'  and OPEN_DATE<(DATEADD(month,-1,@staticpooldate))
		 and Close_date is null
		 -- removed as in staticpool there wont be closed after staticpool
		 -- or Close_date>@staticpooldate)
		and Funded_loan_flag=1 
		order by UNID,Process_Date,TYPE
		


		

		------------------
		------------------   Transaciton data 

			
			-- 
		

		select PARENTACCOUNT,PARENTID,UNID
			,count(*) Transaction_COUNT
			
			,sum(Deposited_amount) Deposited_amount
			,count(Deposited_amount) Deposited_count
			,sum(withdrawl_amount) withdrawal_amount
			,count(withdrawl_amount) withdrawal_count
			,EFFECTIVEDATE
		into ##Saving_transaction
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      ,[POSTDATE]
      ,[POSTTIME]
     
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	 
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
  
  FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
  WHERE PARENTACCOUNT IN (SELECT PARENTACCOUNT FROM #savings_account)
  and PARENTID in (select ID from #savings_account) 
   AND ACTIONCODE!='C') A
	where [EFFECTIVEDATE] between DATEADD(month,-12,@staticpooldate) and @staticpooldate
      group by PARENTACCOUNT,PARENTID,UNID,[EFFECTIVEDATE]
			order by PARENTACCOUNT,PARENTID,UNID,[EFFECTIVEDATE]
	 
	 
			
		
		
		
		

		

	----******///// merging the saving and transaciton table 

		-- drop table if exists #saving_account_data
		
		select a.*
		
		,b.Transaction_COUNT
		,b.Deposited_amount
		,Deposited_count
		,withdrawal_amount
		,withdrawal_count
		into #Saving_account_data
		 from #savings_account a
		left join ##Saving_transaction b
		on a.UNID=b.UNID
		and Process_Date=b.EFFECTIVEDATE

		

		-- Drop talbe if exists #Saving_account_Summary
		
		select SSN00,
		sum(case when Quarters='Q1' then AVG_Deposited_count_Savings end) AVG_Deposited_count_Savings_Q1
		,sum(case when Quarters='Q3' then AVG_withdrawal_amount_Savings end) AVG_withdrawal_amount_Savings_Q3
		INTO #Saving_account_Summary
		from
				(
				select ssn as ssn00,Quarters
				,avg(Deposited_count) AVG_Deposited_count_Savings
				,avg(withdrawal_amount) AVG_withdrawal_amount_Savings
				
				from #Saving_account_data
				where Process_Date=@staticpooldate and SSN is not null
				and OPEN_DATE<@staticpooldate and (Close_date>@staticpooldate or Close_date is null)
				group by ssn,Quarters ) A
		group by ssn00
		order by SSN00

		-- #savings_table1 	
		select SSN,count(distinct UNID) Total_No_Account_Savings,count(distinct type) Total_type_account_Savings
		,max(MOB) MOB_Savings,min(OPEN_DATE) OPEN_DATE_Savings
		 into #savings_table1
		 from
		#Saving_account_data
		group by SSN
		order by SSN
		

		
		
		-------------------------------------------------------------------------------------------------------------------
		------------------------------------------------------------------------------------------------------------------

		-------------------------------*************Checking Account ***************-----------------------------------
		              
		
		--  drop table if exists #Checkings_account

				-- closed_flag will remove the account closed account in any time 
		
		select ssn,UNID,Process_Date,PARENTACCOUNT,id,TYPE,LASTDIVAMOUNT,BALANCE Month_end_balance
		,Closed_flag,Close_date,OPEN_DATE,OVERDRAFTFEEYTD
		
		,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    
			when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    
			when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
		   ,DATEDIFF(MONTH,OPEN_DATE,@staticpooldate) MOB
		 into #Checkings_account 
		from 
		(
		select  
		d.SSN
		,aa.*,c.Closed_flag
		,case when aa.OPEN_DATE=aa.CLOSE_DATE then 0 else 1 end Funded_loan_flag
		,E.ProductName,E.Product_Group_wise		
		from 
		(select 
		CONCAT(PARENTACCOUNT,id) UNID
		,PARENTACCOUNT,ID,TYPE
		,Process_Date,Open_date,Close_date
		,LASTDIVDATE
		,LASTDIVAMOUNT,DIVTYPE,DIVRATE
		,PENALTYTYPE,PENALTYYTD
		,BALANCE,ORIGINALBALANCE,MINIMUMBALANCE,YEARENDBALANCE
		,OVERDRAFTFEEYTD
		,DESCRIPTION
		 from (select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
		 ,cast(OPENDATE as date) Open_date ,cast(CLOSEDATE as date) Close_date
		 from ARCUSYM000..savings) a 
		  where PARENTACCOUNT in (select AccountNumber from ##Static_SSN_account ) ) aa
		left join 
		(select UNID,max(closed_flag) Closed_flag
		from
		(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when closedate is null then 0 else 1 end closed_flag
		
		from 
		(select distinct PARENTACCOUNT,ID,CLOSEDATE 
		from ARCUSYM000..SAVINGS
		 where PARENTACCOUNT in (select AccountNumber from ##Static_SSN_account ) 
		 ) a )b
		group by UNID
		) c
		on aa.UNID=c.UNID
		left join ##Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join  #groupproducttype_Deposits E
		on e.ProductCode=aa.TYPE
		where Process_Date between DATEADD(month,-12,@staticpooldate) and @staticpooldate
		
		and PARENTACCOUNT in (select AccountNumber from ##Static_SSN_account ) ) ZZ
		where Product_Group_wise='checking'  and OPEN_DATE<@staticpooldate and (Close_date>@staticpooldate or Close_date is null)
		and Funded_loan_flag=1 
		order by UNID,Process_Date,TYPE

		

		------------------
		------------------   Transaciton data 

			
			-- drop table if exists ##Checkings_transaction
		

		select PARENTACCOUNT,PARENTID,UNID
			,count(*) Transaction_COUNT
			,sum(BALANCECHANGE) Transaction_amount
			,AVG(BALANCECHANGE) AVG_BALANCECHANGE
			,sum(Deposited_amount) Deposited_amount
			,count(Deposited_amount) Deposited_count
			,sum(withdrawl_amount) withdrawal_amount
			,count(withdrawl_amount) withdrawal_count
			,sum(INTEREST) Sum_INTEREST
			,[EFFECTIVEDATE]
		into ##Checkings_transaction
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      
      ,[DESCRIPTION]
      ,[ACTIONCODE]
      ,[SOURCECODE]
      ,[BALANCECHANGE]
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	  
      ,[INTEREST]
      
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
  
  FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
  WHERE PARENTACCOUNT IN (SELECT PARENTACCOUNT FROM #Checkings_account)
  and PARENTID in (select ID from #Checkings_account) 
   AND ACTIONCODE!='C') A
	where EFFECTIVEDATE in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate)
			,DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate)
      group by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE
			order by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE
	 
	
		

		----
		----******///// merging the saving and transaciton table 

		-- drop table if exists #Checkings_account_data
		
		select a.*
		,b.Transaction_COUNT
		,b.Transaction_amount
		,AVG_BALANCECHANGE
		,b.Deposited_amount
		,Deposited_count
		,withdrawal_amount
		,withdrawal_count
		,sum_interest
		into #Checkings_account_data
		from #Checkings_account a
		left join ##Checkings_transaction b
		on a.UNID=b.UNID
		and a.Process_Date=b.EFFECTIVEDATE

		

		-------- data Vehicle Loan 

		---- drop table if exists #vehicle

			select 
			*
			into #Vehicle
			from
			(
			select [ProcessDate],left(ProcessDate,6) ProcessDate_V
			,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
			,case when Process_Date =@staticpooldate then 1 else 0 end Staticpool_Vehicles_loan_flag
			,d.SSN
			,[PARENTACCOUNT]
			,[ID]
			,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
			,a.Close_date,a.Open_date
			,DATEDIFF(month,a.Open_date,@staticpooldate) MOB
			,DATEDIFF(month,@staticpooldate,[MATURITYDATE]) Month_to_Maturity
			,[TYPE]
			,[ORIGINALDATE]
			,a.[OPENDATE]
			,[CHARGEOFFDATE]
			,a.[CLOSEDATE]
			,[INTERESTRATE]
			,[BALANCE]
			,b.LoanCategory1
			,b.LoanTypeDescription
			from
			(select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
			,cast(OPENDATE as date) Open_date ,cast(CLOSEDATE as date) Close_date from [ARCUSYM000]..LOAN) a
			left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
			on b.loantype=a.TYPE
			left join  ##Static_SSN_account d
			on a.PARENTACCOUNT=d.AccountNumber
			where  ORIGINALDATE is not null and a.Open_Date is not null and a.Open_date <@staticpooldate and
			(a.CLOSE_DATE is null or a.CLOSE_DATE>@staticpooldate)   
			and  Process_Date between DATEADD(month,-12,@staticpooldate) and @staticpooldate
			and  PARENTACCOUNT in (select AccountNumber from ##Static_SSN_account )
			) AA
			where  LoanCategory1='Vehicles'  
			and OPEN_DATE<@staticpooldate and (Close_date is null or Close_date>@staticpooldate) and ORIGINALDATE>= OPEN_DATE

		
				
		
		
		------/////*** Loan Transaction data

		

		--	-- DROP TABLE IF EXISTS #LOAN_TRANSACITON_DATA

			select 
			UNID
			,PARENTACCOUNT
			,Quarters
			,action_source_code
			,Sum(Transaction_amount) SUM_Transaction_amount
			 INTO #LOAN_TRANSACITON_DATA
			from 
			(
			select unid,PARENTACCOUNT
			,case when EFFECTIVEDATE in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    
			when EFFECTIVEDATE in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    
			when EFFECTIVEDATE in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when EFFECTIVEDATE in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when EFFECTIVEDATE in (@staticpooldate) then 'Staticpool'
		    end Quarters
			,effectivedate_v
			,ACTIONCODE,SOURCECODE
			,case when ACTIONCODE='A' then 1 else 0 end Loan_addon
			,case when ACTIONCODE='N' then 1 else 0 end New_loan
			,case when ACTIONCODE='N' then 1 else 0 end loan_payment
			,case when SOURCECODE='C' then 1 else 0 end CASH
			,case when SOURCECODE='D' then 1 else 0 end DRAFT
			,case when SOURCECODE='E' then 1 else 0 end ACH
			,case when SOURCECODE='F' then 1 else 0 end FEE
			,case when SOURCECODE='H' then 1 else 0 end HOMEBANKING
			,case when SOURCECODE='I' then 1 else 0 end INSURANCE
			,case when SOURCECODE='K' then 1 else 0 end CHECKS
			,case when SOURCECODE='P' then 1 else 0 end PAYROLL
			,case when SOURCECODE='S' then 1 else 0 end KIOSK
			,case when SOURCECODE='T' then 1 else 0 end  AUDIO_RESPONSE_TELEPHONE
			,CASE WHEN ACTIONCODE='A' AND SOURCECODE='C' THEN 'LOANADDON_CASH'
			WHEN ACTIONCODE='A' AND SOURCECODE='F' THEN 'LOANADDON_FEE'
			WHEN ACTIONCODE='A' AND SOURCECODE='H' THEN 'LOANADDON_HOMEBANKING'
			WHEN ACTIONCODE='A' AND SOURCECODE='I' THEN 'LOANADDON_INSURANCE'
			WHEN ACTIONCODE='A' AND SOURCECODE='K' THEN 'LOANADDON_CHECK'
			WHEN ACTIONCODE='A' AND SOURCECODE='T' THEN 'LOANADDON_RESPONSE_TELEPHONE'
			WHEN ACTIONCODE='A' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'LOANADDON'
			WHEN ACTIONCODE='N' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'NEWLOAN'
			WHEN ACTIONCODE='N' AND SOURCECODE='K' THEN 'NEWLOAN_CHECKS'
			WHEN ACTIONCODE='N' AND SOURCECODE='S' THEN 'NEWLOAN_KIOSK'
			WHEN ACTIONCODE='P' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'LOANPAYMENT'
			
			WHEN ACTIONCODE='P' AND SOURCECODE='C' THEN 'LOANPAYMENT_CASH'
			WHEN ACTIONCODE='P' AND SOURCECODE='D' THEN 'LOANPAYMENT_DRAFT'
			WHEN ACTIONCODE='P' AND SOURCECODE='E' THEN 'LOANPAYMENT_ACH'
			WHEN ACTIONCODE='P' AND SOURCECODE='H' THEN 'LOANPAYMENT_HOMEBANKING'
			WHEN ACTIONCODE='P' AND SOURCECODE='K' THEN 'LOANPAYMENT_CHECKS'
			WHEN ACTIONCODE='P' AND SOURCECODE='P' THEN 'LOANPAYMENT_PAYROLL'
			WHEN ACTIONCODE='P' AND SOURCECODE='S' THEN 'LOANPAYMENT_KIOSK'
			WHEN ACTIONCODE='P' AND SOURCECODE='T' THEN  'LOANPAYMENT_RESPONSE_TELEPHONE' end action_source_code
			,INTEREST Interest_amount
			,BALANCECHANGE Transaction_amount
			from(

			select CONCAT(PARENTACCOUNT,PARENTID) UNID
			,PARENTACCOUNT,PARENTID
			,TRANSFERCODE
			
			,case when len(month(effectivedate))=1 then CONCAT(year(effectivedate),0,month(effectivedate))
			else CONCAT(year(effectivedate),month(effectivedate)) end effectivedate_v
			,cast(EFFECTIVEDATE as date) EFFECTIVEDATE,POSTDATE
			,ACTIONCODE,SOURCECODE,BALANCECHANGE,NEWBALANCE,INTEREST,FEEAMOUNT
			from ARCUSYM000..LOANTRANSACTION
			where
			ACTIONCODE in ('A','N','P') AND SOURCECODE in ('C','D','E','F','H','I','K','P','S','T')
			 and ACTIONCODE !='C' ) AA
			WHERE EFFECTIVEDATE between DATEADD(month,-12,@staticpooldate) and @staticpooldate
			 )bb
			group by UNID,Quarters,action_source_code,PARENTACCOUNT


				---------------------------------------credit cards data 


		
  -- drop table if exists #CC_Members_Static
	  select distinct [Social Security Number] 
	  into #CC_Members_Static
	  from
	  (select Durable_Key,[Social Security Number],Active_Flag,[External Status Code],[Internal Status Code]
	  ,EOMONTH(datefromparts(left(extract_datepart ,4),right(extract_datepart,2),1)) extract_datepart
	  from analytics..cardholder ) AA 
	  where Active_Flag=1 and [External Status Code]='' and [Internal Status Code] in ('N','')
	  and extract_datepart=@staticpooldate
			

			-- drop table if exists #CC_data	
		
		
		select * 
		into #CC_data
		from 
		(
		SELECT  [Durable_Key]
		,case when extract_datepart=@staticpooldate then 1 else 0 end Staticpool_CreditCard_Flag
		,case when extract_datepart in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    
			when extract_datepart in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    
			when extract_datepart in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when extract_datepart in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when extract_datepart in (@staticpooldate) then 'Staticpool'
		    end Quarters
       ,[Social Security Number]
      ,[Credit Limit]
     ,extract_datepart
      ,[mob]
      ,[Last Statement Average Daily Balance Amount]
  from
  (	select Durable_Key,[Social Security Number]
  ,[Last Statement Average Daily Balance Amount]
      ,[Credit Limit]
       ,[mob]
     ,Active_Flag
  ,EOMONTH(datefromparts(left(extract_datepart ,4),right(extract_datepart,2),1)) extract_datepart
  FROM [Analytics].[dbo].[cardholder] ) AA
  where [Social Security Number] in (select [Social Security Number] from #CC_Members_Static)
  and Active_Flag=1 ) a where  quarters is not null and mob>=12


  select 
		*
		into #Credit_Card_data
		from 
		(
				select  [Social Security Number] SSN_CC
				,SUM(case when Quarters='Staticpool' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Staticpool]
					--into #CC_data_summary		
			 from #CC_data
			  group by [Social Security Number] ) a
			  left join 			
			 (
			 select [Social Security Number] SSN_00
			 ,max([Credit Limit]) CL_CC_StaticPool
			 ,max(mob) MOB_CC_staticPool
			 
			 from #cc_data
			 where Quarters='staticpool'
			 group by [Social Security Number]) w
			 on a.ssn_CC=w.SSN_00


			 ----------------------------------------------------------------------------------------------------------
		------------------------//////********** Deposit table summary************\\\\\\\\---------------------
		-- drop table if exists #Deposit_account_data

		select ssn,UNID,Process_Date,PARENTACCOUNT,id,TYPE,LASTDIVAMOUNT,BALANCE Month_end_balance
		--,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE
		,Closed_flag,Close_date,OPEN_DATE 
		,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    
			when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    
			when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
		   ,DATEDIFF(MONTH,OPEN_DATE,@staticpooldate) MOB
		 into #Deposit_account_data
		from 
		(
		select  
		d.SSN
		,aa.*,c.Closed_flag
		
		,case when aa.OPEN_DATE=aa.CLOSE_DATE then 0 else 1 end Funded_loan_flag
		,E.ProductName,E.Product_Group_wise	
		from 
		(select 
		CONCAT(PARENTACCOUNT,id) UNID
		,Process_Date,PARENTACCOUNT,ID,TYPE
		,cast(OPENDATE as date) OPEN_DATE,cast(CLOSEDATE as date)  CLOSE_DATE,LASTDIVDATE
		,LASTDIVAMOUNT
		,BALANCE
		,DESCRIPTION
		 from (select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
		 from ARCUSYM000..savings) a 
		 where PARENTACCOUNT in (select AccountNumber from ##Static_SSN_account ) ) aa
		left join 
		(select UNID,max(closed_flag) Closed_flag
		from
		(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when CLOSEDATE is null then 0 else 1 end closed_flag
		
		from 
		(select distinct PARENTACCOUNT,ID,CLOSEDATE 
		from ARCUSYM000..SAVINGS
		 where PARENTACCOUNT in (select AccountNumber from ##Static_SSN_account ) 
		 ) a )b
		group by UNID
		) c
		on aa.UNID=c.UNID
		left join ##Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join #groupproducttype_Deposits E
		on e.ProductCode=aa.TYPE
		where Process_Date between DATEADD(month,-12,@staticpooldate) and @staticpooldate
		and PARENTACCOUNT in (select AccountNumber from ##Static_SSN_account ) ) ZZ
		where OPEN_DATE<(DATEADD(month,-1,@staticpooldate))
		 and Close_date is null
		 -- removed as in staticpool there wont be closed after staticpool
		 -- or Close_date>@staticpooldate)
		and Funded_loan_flag=1 
		order by UNID,Process_Date,TYPE
		
		------------------
		------------------   Transaciton data 


		select PARENTACCOUNT,PARENTID,UNID
			,count(*) Transaction_COUNT
			
			,sum(Deposited_amount) Deposited_amount
			,count(Deposited_amount) Deposited_count
			,sum(withdrawl_amount) withdrawal_amount
			,count(withdrawl_amount) withdrawal_count
			,EFFECTIVEDATE
		into ##Deposit_transaction
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      ,[POSTDATE]
      ,[POSTTIME]
     
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	 
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
  
  FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
  WHERE PARENTACCOUNT IN (SELECT PARENTACCOUNT FROM #savings_account)
  and PARENTID in (select ID from #savings_account) 
   AND ACTIONCODE!='C') A
	where [EFFECTIVEDATE] between DATEADD(month,-12,@staticpooldate) and @staticpooldate
      group by PARENTACCOUNT,PARENTID,UNID,[EFFECTIVEDATE]
			order by PARENTACCOUNT,PARENTID,UNID,[EFFECTIVEDATE]
	 
	 
		
	----******///// merging the saving and transaciton table 

		-- drop table if exists #Deposit_Product_all_data
		
		select a.*
		
		,b.Transaction_COUNT
		,b.Deposited_amount
		,Deposited_count
		,withdrawal_amount
		,withdrawal_count
		into #Deposit_Product_all_data
		 from #Deposit_account_data a
		left join ##Deposit_transaction b
		on a.UNID=b.UNID
		and Process_Date=b.EFFECTIVEDATE

		
		

			 -- Drop talbe if exists #Deposit_summary
		select ssn ssn00,count(distinct UNID) Count_Total_Deposit_ACCT, count(distinct type) Count_product_Total_Deposit_ACCT 
		,sum(withdrawal_amount) SUM_withdrawal_amount_Total_Deposit_ACCT 
		INTO #Deposit_summary
		from #Deposit_Product_all_data
				where Process_Date=@staticpooldate and SSN is not null
				and OPEN_DATE<@staticpooldate and (Close_date>@staticpooldate or Close_date is null)
				and Quarters='staticpool'
				group by ssn 
			 
			 
		--------------------------------------------------------------------------------------------------------------------------------------------
										--  Merging the data
		--------------------------------------------------------------------------------------------------------------------------------------------

		
			---------------------------------------------------------------------------------------------------------------------------
				-------------------MERGING ALL LOAN TALBE---------------------------------------------------------------------------

				-- drop table if exists analytics.dbo.Master_table_April2019
				-- drop table #masterdata
				select AA.SSN
				,MOB_Savings
				,avg_withdrawal_amount_savings_Q3
				,max_interestrate_Vehicles
				,[Last Statement Average Daily Balance Amount_CC_Staticpool]
				,sum_OVERDRAFTFEEYTD_checkings_Q1
				,sum_Transaction_amount_Total_loan_ACCT
				,SUM_withdrawal_amount_Total_Deposit_ACCT
				,CL_CC_StaticPool
				into
				 #masterdata
				
				from 
				(SELECT distinct ssn
				
				 FROM #Static_SSN_account_Final ) AA

				 left join #Credit_Card_data mn
				 on aa.ssn=mn.[Last Statement Average Daily Balance Amount_CC_Staticpool]
				 left join #Deposit_summary l
				 on aa.SSN=l.ssn00
			

		-- drop table if exists #Checking
		Left join 
		(

		select aa.SSN SSN20
		,sum(case when Quarters='Q1' then sum_OVERDRAFTFEEYTD_checkings End) sum_OVERDRAFTFEEYTD_checkings_Q1
		,MOB_Checkings
		from
		(
		select 
		SSN,Quarters
		,sum(OVERDRAFTFEEYTD) sum_OVERDRAFTFEEYTD_checkings
		 from  #Checkings_account_data 
		group by ssn,Quarters ) AA
		left join 
		(		
		select SSN,count(distinct UNID) Total_No_Account_Checkings,count(distinct type) Total_type_account_Checkings
		,min(Open_date) opendate_Checkings,max(CLOSE_DATE) CLOSEDATE_Checkings
		,max(MOB) MOB_Checkings,min(OPEN_DATE) OPEN_DATE_Checkings,max(Close_date) Close_date_Checkings
		 from
		#Checkings_account_data
		group by SSN
		) AB
		on aa.SSN=ab.SSN
		group by aa.SSN,ab.Total_No_Account_Checkings,Total_type_account_Checkings
		,opendate_Checkings,Close_date_Checkings,MOB_Checkings,OPEN_DATE_Checkings,Close_date_Checkings
		 ) U
		ON AA.SSN=U.SSN20
		left join #Saving_account_Summary ZZ
		on aa.ssn=zz.ssn00
		left join #savings_table1 k
		on aa.SSN=k.SSN
		left join 
			(
			 select SSN SSN6
			,max([INTERESTRATE]) Max_interestrate_Vehicles
			from #Vehicle
			group by SSN
			 ) F
			 ON F.SSN6=AA.SSN
			 left join
			 (select SSN000
		,sum(SUM_Transaction_amount) SUM_Transaction_amount_Total_loan_ACCT
		from
		(select a.*,b.SSN SSN000 from #LOAN_TRANSACITON_DATA a left join ##Static_SSN_account b
		on a.PARENTACCOUNT=b.AccountNumber
		where Quarters='staticpool' ) FF
		group by SSN000 ) BB
		on aa.ssn=bb.ssn000
		
		







		----------------------
		---------------------
		----------------------
			
	--			 -- drop table if exists #1
	--	select distinct  SSN,AccountNumber PARENTACCOUNT  
	--	into #1 
	--	from AE_EDW..D_Member
	--	where SSN is not null	
	
	
	----	drop table if exists #2
	--	select distinct  SSN,PARENTACCOUNT
	--	 into #2
	--	 from ARCUSYM000..NAME
	--	 where PARENTACCOUNT not in (select PARENTACCOUNT from #1)
	--	 and SSN is not null

		
		 	
	--		-- drop table if exists #NAME
	--		select * 
	--		into #NAME
	--		from
	--		(select * from #1
	--		union
	--		select * from #2 ) A


			
-- drop table if exists #Unsecured_loan
		select * 
		into #Unsecured_loan
		from 
		(select distinct  a.PARENTACCOUNT,id,a.type,OPEN_DATE,CLOSE_DATE,b.loancategory1,SSN
		,case when OPEN_DATE <=@staticpooldate  then 1 else 0 end Flag
		
		from (select PARENTACCOUNT,id
		,TYPE
		,cast (OPENDATE as date) Open_date
		,cast (CLOSEDATE as date) Close_date from [ARCUSYM000]..loan) as a
		left join  [ARCUSYM000].[arcu].[ARCULoanCategory] b
		on b.loantype=a.TYPE
		left join #NAME C
		on a.PARENTACCOUNT=c.PARENTACCOUNT
		) AA
		where Flag=1 and LoanCategory1='unsecured'


		

				-- drop table if exists ##1
			
			
			select distinct a.SSN 
			into ##1 from #masterdata a
			left join  #Unsecured_loan b
			 on a.SSN=b.SSN
			 where b.SSN is null

		

		
		-- drop table if exists #Unsecured_loan_data
		

				select	 SSN		
				,case when MOB_Savings <=52 or mob_savings is null then 30.9
				when MOB_Savings <=83  then -14.4
				else -50.2 end mob_savings
				,case when avg_withdrawal_amount_savings_Q3 <= -33.33 or avg_withdrawal_amount_savings_Q3 is null then 57.3
				else -21.3 end avg_withdrawal_amount_savings_Q3
				,case when max_interestrate_Vehicles is null then -22.1 else 97.2 end max_interestrate_Vehicles
				,case when [Last Statement Average Daily Balance Amount_CC_Staticpool]  <=0 
				or [Last Statement Average Daily Balance Amount_CC_Staticpool] is null then -14.5
				when [Last Statement Average Daily Balance Amount_CC_Staticpool]>0 then 89.8 end [Last Statement Average Daily Balance Amount_CC_Staticpool]
				,case when sum_OVERDRAFTFEEYTD_checkings_Q1 <=0 or sum_OVERDRAFTFEEYTD_checkings_Q1 is null then -14.9
				when sum_OVERDRAFTFEEYTD_checkings_Q1 >0 then 96.1 end sum_OVERDRAFTFEEYTD_checkings_Q1
				,case when sum_Transaction_amount_Total_loan_ACCT  is null then -18.5  
				when sum_Transaction_amount_Total_loan_ACCT <= -162.342 then 48.7
				when sum_Transaction_amount_Total_loan_ACCT > -162.342 then 115.9
				 end sum_Transaction_amount_Total_loan_ACCT

				,case when SUM_withdrawal_amount_Total_Deposit_ACCT <=-7367.12 or SUM_withdrawal_amount_Total_Deposit_ACCT is null then 15.1
				when SUM_withdrawal_amount_Total_Deposit_ACCT<= -952.138 then 50.3
				when SUM_withdrawal_amount_Total_Deposit_ACCT <= -10 then 4.5 
				when SUM_withdrawal_amount_Total_Deposit_ACCT > -10 then -34
				end SUM_withdrawal_amount_Total_Deposit_ACCT
				--,case when CL_CC_StaticPool is null then -99999999 else CL_CC_StaticPool end CL_CC_StaticPool
				,case when CL_CC_StaticPool is null then -11 
				when CL_CC_StaticPool<=9000 then 85
				when CL_CC_StaticPool>=9000 then -8.2 else CL_CC_StaticPool end CL_CC_StaticPool
		into #Unsecured_loan_data
		from 
		#masterdata
		where SSN in (select SSN from ##1)


			--select * 
			--,NTILE (10) OVER ( order by Ranks) Decile
			--into ##targetList_UnsecuredLoan
			--from
			--(select *
		
			--,Row_number() over(order by score desc)  Ranks
			--from
			--(
			--	select * 
		
			--	,EXP(0.0142+(0.0001365*mob_savings)+(0.0001236*avg_withdrawal_amount_savings_Q3)
			--	+(0.0001084*max_interestrate_Vehicles)
			--	+(0.0001609*[Last Statement Average Daily Balance Amount_CC_Staticpool])
			--	+(0.00009164*sum_OVERDRAFTFEEYTD_checkings_Q1)+(0.00008105*sum_Transaction_amount_Total_loan_ACCT)
			--	+(0.00006404*SUM_withdrawal_amount_Total_Deposit_ACCT)+(-0.00000000004323*CL_CC_StaticPool))
			--	/(1+EXP(0.0142+(0.0001365*mob_savings)+(0.0001236*avg_withdrawal_amount_savings_Q3)
			--	+(0.0001084*max_interestrate_Vehicles)
			--	+(0.0001609*[Last Statement Average Daily Balance Amount_CC_Staticpool])
			--	+(0.00009164*sum_OVERDRAFTFEEYTD_checkings_Q1)+(0.00008105*sum_Transaction_amount_Total_loan_ACCT)
			--	+(0.00006404*SUM_withdrawal_amount_Total_Deposit_ACCT)+(-0.00000000004323*CL_CC_StaticPool)))   as score
			--	from #Unsecured_loan_data ) a ) B
			--	order by score desc

			select * 
			,NTILE (10) OVER ( order by Ranks) Decile
			into ##targetList_UnsecuredLoan
			from
			(select *
		
			,Row_number() over(order by score desc)  Ranks
			from
			(
				select * 
		
				,EXP(-4.3327687+(0.0114806*mob_savings)
				+(0.0052731*avg_withdrawal_amount_savings_Q3)
				+(0.0049218*max_interestrate_Vehicles)
				+(0.0045947*[Last Statement Average Daily Balance Amount_CC_Staticpool])
				+(0.0052787*sum_OVERDRAFTFEEYTD_checkings_Q1)
				+(0.0042066*sum_Transaction_amount_Total_loan_ACCT)
				+(0.0049571*SUM_withdrawal_amount_Total_Deposit_ACCT)
				+(0.0029084*CL_CC_StaticPool))
				/(1+EXP(-4.3327687+(0.0114806*mob_savings)
				+(0.0052731*avg_withdrawal_amount_savings_Q3)
				+(0.0049218*max_interestrate_Vehicles)
				+(0.0045947*[Last Statement Average Daily Balance Amount_CC_Staticpool])
				+(0.0052787*sum_OVERDRAFTFEEYTD_checkings_Q1)
				+(0.0042066*sum_Transaction_amount_Total_loan_ACCT)
				+(0.0049571*SUM_withdrawal_amount_Total_Deposit_ACCT)
				+(0.0029084*CL_CC_StaticPool)))   as score
				from #Unsecured_loan_data ) a ) B
				where SSN>000000000
				order by score desc
			end	
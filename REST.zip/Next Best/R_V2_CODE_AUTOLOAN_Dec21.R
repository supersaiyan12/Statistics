###################################### Next Best Product Auto Loan Model (12/28/2022) ###############################
## STATIC POOL : 12/31/2021


#setting working directory
setwd("//acdfs01/Departmental/Trellance/cu rise/CU Rise Workspace/Jitesh/Next Best/New folder_Dec_21/CSV")

# Loading the Train Data :

rm(list=ls())
getwd()
# install.packages('RODBC')
databaseConnection <- odbcDriverConnect("Driver={SQL Server};server=ACARCU01;trusted_connection=true")
AL_train <- sqlQuery(databaseConnection, "select * from Analytics.dbo.NBP_AutoLoan_train_202212")
AL_train <- data.frame(AL_train,stringsAsFactors=FALSE)
dim(AL_train) # 975 vars 188638 rows


# Loading the Test data

AL_test <- sqlQuery(databaseConnection, "select * from Analytics.dbo.NBP_AutoLoan_test_202212")
                                                       Analytics.dbo.REVISED_MASTER_DATA_Dec_2022
AL_test <- data.frame(AL_test,stringsAsFactors=FALSE)
dim(AL_test) # 976 vars 80844 rows

##1. Extracting out the date and char variable.

type = sapply(AL_train,class)
write.csv(type,"CLASS OF Autoloan.csv")

df1 = AL_train[,!sapply(AL_train,is.character)]   ## Excluding character variable
dim(df1) # 974 vars

# install.packages("lubridate")
library(lubridate)
df2 =  df1[,!sapply(df1,is.POSIXct)]   ## Excluding date variable
dim(df2) # 960 vars

df3 =  df2[,!sapply(df2,is.factor)]   ## Here factor variables also contains the date variables. So removing it
dim(df3) # 960 vars

df4 =  df3[,!sapply(df3,is.logical)]   ## Here logical variables also contains NULL variables. So removing it
dim(df4) # 908 vars

### 2. Removing the i.i.d. variables (Uniqueidentifier variables)

df5 = subset(df4,select = - c(SSN_CC,SSN001,SSN002,SSN003,SSN004))
dim(df5) # 870 vars

### 3. Creating the summary function

Summary_Function <- function(data)
{
  a <- data.frame()
  e <- data.frame()
  f <- data.frame()
  G <- data.frame()
  H <- data.frame()
  I <- data.frame()
  J <- data.frame()
  K <- data.frame()
  L <- data.frame()
  M <- data.frame()
  N <- data.frame()
  Col_bined <- data.frame()
  
  for (i in 1:ncol(data))
  {
    if(class(data[,c(i)])!="factor") {
      Total_count <- NROW(data)-(sum(is.na(data[,c(i)]))+sum(data[,c(i)]==0,na.rm = TRUE))
      Count_NA <- data.frame(sum(is.na(data[,c(i)])))
      Count_zero <- data.frame(sum(data[,c(i)]==0,na.rm = TRUE))
      Mean_1 <- data.frame(mean(data[,c(i)],na.rm = TRUE))
      Median_1 <- data.frame(median(data[,c(i)],na.rm = TRUE))
      std <- data.frame(sd(data[,c(i)],na.rm = TRUE))
      Max_1 <- data.frame(max(data[,c(i)],na.rm = TRUE))
      Min_1 <- data.frame(min(data[,c(i)],na.rm = TRUE))
      b <-data.frame(colnames(data)[i],quantile(data[,c(i)],.25,na.rm = TRUE))
      c <-data.frame(quantile(data[,c(i)],.75,na.rm = TRUE))
      d <-data.frame(quantile(data[,c(i)],.99,na.rm = TRUE))
      row.names(Count_NA) <- NULL
      row.names(Count_zero) <- NULL
      row.names(Mean_1) <- NULL
      row.names(Median_1) <- NULL
      row.names(std) <- NULL
      row.names(Max_1) <- NULL
      row.names(Min_1) <- NULL
      row.names(Total_count) <- NULL
      row.names(b) <- NULL
      row.names(c) <- NULL
      row.names(d) <- NULL
      
      a <- rbind(b,a)
      e <- rbind(c,e)
      f <- rbind(d,f)
      
      G <- rbind(Count_NA,G)
      H <- rbind(Count_zero,H)
      I <- rbind(Mean_1,I)
      J <- rbind(Median_1,J)
      K <- rbind(Max_1,K)
      L <- rbind(Min_1,L)
      M <- rbind(std,M)
      N <- rbind(Total_count,N)
      Col_bined <- data.frame(cbind(a,e,f,N,G,H,I,J,M,K,L))
      colnames(Col_bined) <- c("Variables","Percentile 25%","Percentile 75%","Percentile 99%"
                               ,"Total_No_obs","Count_NA","Count_zero","Mean","Median","Standard_Deviation","Max","Min")
      
    }
    
  }
  
  Col_bined1<- data.frame(apply(Col_bined,2,rev))
  
  write.csv(Col_bined1,"Summary of Auto Loan Propensity Model.csv")
}


Summary_Function(df5)


# Selecting variables after summary statistics exclusion 

df6 = subset(df5,select = - c(
  Max_chargoff_date_CC,
  Max_Extract_ACCOUNT_OPEN_DATE_CC,
  TYPE_RealEstate_Q1,
  DFT_TYPE_RealEstate_Q1_Q2,
  DFT_TYPE_RealEstate_Q1_Q3,
  TYPE_SecuredLoan_Q1,
  DFT_TYPE_SecuredLoan_Q1_Q2,
  DFT_TYPE_SecuredLoan_Q1_Q3,
  TYPE_UnsecuredLoan_Q1,
  DFT_TYPE_UnsecuredLoan_Q1_Q2,
  DFT_TYPE_UnsecuredLoan_Q1_Q3,
  TYPE_Loan_Q1,
  DFT_TYPE_Loan_Q1_Q2,
  DFT_TYPE_Loan_Q1_Q3,
  TYPE_SAVINGS_SP,
  TYPE_SAVINGS_Q1,
  DFT_TYPE_SAVINGS_Q1_Q2,
  DFT_TYPE_SAVINGS_Q1_Q3,
  TYPE_CHECKING_SP,
  TYPE_CHECKING_Q1,
  DFT_TYPE_CHECKING_Q1_Q2,
  DFT_TYPE_CHECKING_Q1_Q3,
  TYPE_CERTIFICATES_SP,
  TYPE_CERTIFICATES_Q1,
  DFT_TYPE_CERTIFICATES_Q1_Q2,
  DFT_TYPE_CERTIFICATES_Q1_Q3,
  TYPE_MONEYMARKET_SP,
  TYPE_MONEYMARKET_Q1,
  DFT_TYPE_MONEYMARKET_Q1_Q2,
  DFT_TYPE_MONEYMARKET_Q1_Q3,
  TYPE_IRA_SP,
  TYPE_IRA_Q1,
  DFT_TYPE_IRA_Q1_Q2,
  DFT_TYPE_IRA_Q1_Q3,
  TYPE_DEPOSITS_Q1,
  DFT_TYPE_DEPOSITS_Q1_Q2,
  DFT_TYPE_DEPOSITS_Q1_Q3,
  LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,
  AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,
  DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2,
  DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2,
  DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q3,
  DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q3,
  TRANSACTION_AMOUNT_IRA_Q1,
  DFT_TRANSACTION_AMOUNT_IRA_Q1_Q2,
  DFT_TRANSACTION_AMOUNT_IRA_Q1_Q3,
  TRANSACTION_AMOUNT_MONEYMARKET_Q1,
  DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q2,
  DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q3,
  LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,
  AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,
  LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,
  AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,
  DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2,
  DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2,
  DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2,
  DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2,
  DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q3,
  DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q3,
  DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q3,
  DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q3,
  TRANSACTION_AMOUNT_CERTIFICATES_Q1,
  DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q2,
  DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q3,
  TRANSACTION_AMOUNT_SAVINGS_Q1,
  TRANSACTION_AMOUNT_CHECKING_Q1,
  DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2,
  DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3,
  DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2,
  DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3,
  TRANSACTION_AMOUNT_DEPOSITS_Q1,
  DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2,
  DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3,
  ForeclosureCountP12Months,
  SUM_INTEREST_IRA_Q1,
  DFT_SUM_INTEREST_IRA_Q1_Q2,
  DFT_SUM_INTEREST_IRA_Q1_Q3,
  Max_Closed_account_flag_CC,
  ForeclosureTotalBalance,
  COUNT_PAYROLL_SecuredLoan_Q1,
  COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1,
  DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q2,
  DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q2,
  DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q3,
  DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q3,
  MAX_CREDITLIMIT_SecuredLoan_Q1,
  DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q2,
  DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q3,
  SUM_INTEREST_MONEYMARKET_Q1,
  DFT_SUM_INTEREST_MONEYMARKET_Q1_Q2,
  DFT_SUM_INTEREST_MONEYMARKET_Q1_Q3,
  COUNT_PAYROLL_RealEstate_Q1,
  COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1,
  COUNT_PAYROLL_UnsecuredLoan_Q1,
  COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1,
  DFT_COUNT_PAYROLL_RealEstate_Q1_Q2,
  DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q2,
  DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q2,
  DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q2,
  DFT_COUNT_PAYROLL_RealEstate_Q1_Q3,
  DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q3,
  DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q3,
  DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q3,
  MAX_CREDITLIMIT_RealEstate_Q1,
  DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q2,
  MAX_CREDITLIMIT_UnsecuredLoan_Q1,
  DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q3,
  DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q2,
  DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q3,
  Last.Statement.External.Fee.Amount_CC_Q1,
  Last.Statement.Credit.Life.Change.Amount_CC_Q1,
  Last.Statement.Charge.Overlimit.Amount_CC_Q1,
  DFT_Last.Statement.External.Fee.Amount_CC_Q1_Q2,
  DFT_Last.Statement.Credit.Life.Change.Amount_CC_Q1_Q2,
  DFT_Last.Statement.Charge.Overlimit.Amount_CC_Q1_Q2,
  DFT_Last.Statement.External.Fee.Amount_CC_Q1_Q3,
  DFT_Last.Statement.Credit.Life.Change.Amount_CC_Q1_Q3,
  DFT_Last.Statement.Charge.Overlimit.Amount_CC_Q1_Q3,
  COUNT_PAYROLL_STATICPOOL,
  COUNT_AUDIO_RESPONSE_TELEPHONE_STATICPOOL,
  COUNT_PAYROLL_Q1,
  COUNT_AUDIO_RESPONSE_TELEPHONE_Q1,
  DFT_COUNT_PAYROLL_Q1_Q2,
  DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q2,
  DFT_COUNT_PAYROLL_Q1_Q3,
  DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q3,
  SUM_INTEREST_SAVINGS_Q1,
  MAX_CREDITLIMIT_Loan_Q1,
  SUM_INTEREST_CHECKING_Q1,
  DFT_MAX_CREDITLIMIT_Loan_Q1_Q2,
  DFT_SUM_INTEREST_CHECKING_Q1_Q2,
  DFT_SUM_INTEREST_CHECKING_Q1_Q3,
  DFT_MAX_CREDITLIMIT_Loan_Q1_Q3,
  PRODUCT_CommercialLoan_Q1,
  DFT_PRODUCT_CommercialLoan_Q1_Q2,
  DFT_PRODUCT_CommercialLoan_Q1_Q3,
  PRODUCT_Others_Q1,
  DFT_PRODUCT_Others_Q1_Q2,
  DFT_PRODUCT_Others_Q1_Q3,
  TYPE_CommercialLoan_Q1,
  DFT_TYPE_CommercialLoan_Q1_Q2,
  DFT_TYPE_CommercialLoan_Q1_Q3,
  TYPE_Others_Q1,
  DFT_TYPE_Others_Q1_Q2,
  DFT_TYPE_Others_Q1_Q3,
  CommercialLoan_StaticPoolFlag,
  CommercialLoan_Q1Flag,
  DFT_SUM_INTEREST_SAVINGS_Q1_Q2,
  DFT_SUM_INTEREST_SAVINGS_Q1_Q3,
  WITHDRAWAL_COUNT_HSA_Q1,
  DFT_WITHDRAWAL_COUNT_HSA_Q1_Q2,
  DFT_WITHDRAWAL_COUNT_HSA_Q1_Q3,
  PRODUCT_HSA_SP,
  PRODUCT_HSA_Q1,
  DFT_PRODUCT_HSA_Q1_Q2,
  DFT_PRODUCT_HSA_Q1_Q3,
  TYPE_HSA_SP,
  TYPE_HSA_Q1,
  DFT_TYPE_HSA_Q1_Q2,
  DFT_TYPE_HSA_Q1_Q3,
  HSA_StaticpoolFlag,
  HSA_Q1Flag,
  TRANSACTION_COUNT_HSA_Q1,
  DFT_TRANSACTION_COUNT_HSA_Q1_Q2,
  DFT_TRANSACTION_COUNT_HSA_Q1_Q3,
  DEPOSITED_COUNT_HSA_Q1,
  DFT_DEPOSITED_COUNT_HSA_Q1_Q2,
  DFT_DEPOSITED_COUNT_HSA_Q1_Q3,
  CommercialLoan_MOB,
  PAYMENTCOUNT_CommercialLoan_Q1,
  DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q2,
  DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q3,
  MAX_INTERESTRATE_CommercialLoan_Q1,
  DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q2,
  DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q3,
  CommercialLoan_Month_to_Maturity,
  COUNT_LOAN_ADDON_CommercialLoan_Q1,
  DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q2,
  DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q3,
  COUNT_NEW_LOAN_CommercialLoan_Q1,
  COUNT_NEW_LOAN_CommercialLoan_Q1_Q2,
  COUNT_NEW_LOAN_CommercialLoan_Q1_Q3,
  COUNT_LOAN_PAYMENT_CommercialLoan_Q1,
  DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q2,
  DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q3,
  COUNT_CASH_CommercialLoan_Q1,
  DFT_COUNT_CASH_CommercialLoan_Q1_Q2,
  DFT_COUNT_CASH_CommercialLoan_Q1_Q3,
  COUNT_DRAFT_CommercialLoan_Q1,
  DFT_COUNT_DRAFT_CommercialLoan_Q1_Q2,
  DFT_COUNT_DRAFT_CommercialLoan_Q1_Q3,
  COUNT_ACH_CommercialLoan_Q1,
  DFT_COUNT_ACH_CommercialLoan_Q1_Q2,
  DFT_COUNT_ACH_CommercialLoan_Q1_Q3,
  COUNT_FEE_CommercialLoan_Q1,
  DFT_COUNT_FEE_CommercialLoan_Q1_Q2,
  DFT_COUNT_FEE_CommercialLoan_Q1_Q3,
  COUNT_HOMEBANKING_CommercialLoan_Q1,
  DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q2,
  DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q3,
  COUNT_INSURANCE_CommercialLoan_Q1,
  DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q2,
  DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q3,
  COUNT_CHECKS_CommercialLoan_Q1,
  DFT_COUNT_CHECKS_CommercialLoan_Q1_Q2,
  DFT_COUNT_CHECKS_CommercialLoan_Q1_Q3,
  COUNT_PAYROLL_CommercialLoan_Q1,
  DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q2,
  DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q3,
  COUNT_KIOSK_CommercialLoan_Q1,
  DFT_COUNT_KIOSK_CommercialLoan_Q1_Q2,
  DFT_COUNT_KIOSK_CommercialLoan_Q1_Q3,
  COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1,
  DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q2,
  DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q3,
  MOB_HSA,
  COUNT_LOAN_ADDON_Others_Q1,
  DFT_COUNT_LOAN_ADDON_Others_Q1_Q2,
  DFT_COUNT_LOAN_ADDON_Others_Q1_Q3,
  COUNT_NEW_LOAN_Others_Q1,
  COUNT_NEW_LOAN_Others_Q1_Q2,
  COUNT_NEW_LOAN_Others_Q1_Q3,
  COUNT_LOAN_PAYMENT_Others_Q1,
  DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q2,
  DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q3,
  COUNT_CASH_Others_Q1,
  DFT_COUNT_CASH_Others_Q1_Q2,
  DFT_COUNT_CASH_Others_Q1_Q3,
  COUNT_DRAFT_Others_Q1,
  DFT_COUNT_DRAFT_Others_Q1_Q2,
  DFT_COUNT_DRAFT_Others_Q1_Q3,
  COUNT_ACH_Others_Q1,
  DFT_COUNT_ACH_Others_Q1_Q2,
  DFT_COUNT_ACH_Others_Q1_Q3,
  COUNT_FEE_Others_Q1,
  DFT_COUNT_FEE_Others_Q1_Q2,
  DFT_COUNT_FEE_Others_Q1_Q3,
  COUNT_HOMEBANKING_Others_Q1,
  DFT_COUNT_HOMEBANKING_Others_Q1_Q2,
  DFT_COUNT_HOMEBANKING_Others_Q1_Q3,
  COUNT_INSURANCE_Others_Q1,
  DFT_COUNT_INSURANCE_Others_Q1_Q2,
  DFT_COUNT_INSURANCE_Others_Q1_Q3,
  COUNT_CHECKS_Others_Q1,
  DFT_COUNT_CHECKS_Others_Q1_Q2,
  DFT_COUNT_CHECKS_Others_Q1_Q3,
  COUNT_PAYROLL_Others_Q1,
  DFT_COUNT_PAYROLL_Others_Q1_Q2,
  DFT_COUNT_PAYROLL_Others_Q1_Q3,
  COUNT_KIOSK_Others_Q1,
  DFT_COUNT_KIOSK_Others_Q1_Q2,
  DFT_COUNT_KIOSK_Others_Q1_Q3,
  COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1,
  DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q2,
  DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q3,
  LOAN_TRANSACTION_AMOUNT_Others_Q1,
  DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q2,
  DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q3,
  INTEREST_AMOUNT_Others_Q1,
  DFT_INTEREST_AMOUNT_Others_Q1_Q2,
  DFT_INTEREST_AMOUNT_Others_Q1_Q3,
  FEEAMOUNT_Others_Q1,
  DFT_FEEAMOUNT_Others_Q1_Q2,
  DFT_FEEAMOUNT_Others_Q1_Q3,
  AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1,
  DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q2,
  DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q3,
  AVG_NEWBALANCE_Others_Q1,
  DFT_AVG_NEWBALANCE_Others_Q1_Q2,
  DFT_AVG_NEWBALANCE_Others_Q1_Q3,
  AVG_FEEAMOUNT_Others_Q1,
  DFT_AVG_FEEAMOUNT_Others_Q1_Q2,
  DFT_AVG_FEEAMOUNT_Others_Q1_Q3,
  PAYMENTCOUNT_Others_Q1,
  DFT_PAYMENTCOUNT_Others_Q1_Q2,
  DFT_PAYMENTCOUNT_Others_Q1_Q3,
  SUM_OriginalBalance_Others_Q1,
  DFT_SUM_OriginalBalance_Others_Q1_Q2,
  DFT_SUM_OriginalBalance_Others_Q1_Q3,
  SUM_PAYMENT_Others_Q1,
  DFT_SUM_PAYMENT_Others_Q1_Q2,
  DFT_SUM_PAYMENT_Others_Q1_Q3,
  MAX_INTERESTRATE_Others_Q1,
  DFT_MAX_INTERESTRATE_Others_Q1_Q2,
  DFT_MAX_INTERESTRATE_Others_Q1_Q3,
  MAX_CREDITLIMIT_Others_Q1,
  DFT_MAX_CREDITLIMIT_Others_Q1_Q2,
  DFT_MAX_CREDITLIMIT_Others_Q1_Q3,
  Others_MOB,
  Others_Month_to_Maturity,
  AVG_CHARGEOFFAMOUNT_IRA_Q1,
  DFT_AVG_CHARGEOFFAMOUNT_IRA_Q1_Q2,
  AVG_CHARGEOFFAMOUNT_MONEYMARKET_SP,
  AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1,
  DFT_AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1_Q2,
  DFT_AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1_Q3,
  AVG_CHARGEOFFAMOUNT_CERTIFICATES_SP,
  AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1,
  DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q2,
  DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q3,
  AVG_CHARGEOFFAMOUNT_CHECKING_SP,
  AVG_CHARGEOFFAMOUNT_CHECKING_Q1,
  DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q2,
  DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q3,
  FICO,
  AVG_CHARGEOFFAMOUNT_SAVINGS_SP,
  AVG_CHARGEOFFAMOUNT_DEPOSITS_SP,
  AVG_CHARGEOFFAMOUNT_SAVINGS_Q1,
  AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1,
  DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q2,
  DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q2,
  DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q3,
  DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q3
))

dim(df6) # 557 vars

# a. REPLACE NA WITH 0 BEFORE WOE BINNINGS

df6$CreditCard_StaticpoolFlag = replace(df6$CreditCard_StaticpoolFlag,is.na(df6$CreditCard_StaticpoolFlag),0)
df6$CreditCard_Q1Flag = replace(df6$CreditCard_Q1Flag,is.na(df6$CreditCard_Q1Flag),0)

df6$RealEstate_StaticPoolFlag = replace(df6$RealEstate_StaticPoolFlag,is.na(df6$RealEstate_StaticPoolFlag),0)
df6$RealEstate_Q1Flag = replace(df6$RealEstate_Q1Flag,is.na(df6$RealEstate_Q1Flag),0)

df6$SecuredLoan_StaticPoolFlag = replace(df6$SecuredLoan_StaticPoolFlag,is.na(df6$SecuredLoan_StaticPoolFlag),0)
df6$SecuredLoan_Q1Flag = replace(df6$SecuredLoan_Q1Flag,is.na(df6$SecuredLoan_Q1Flag),0)

df6$UnsecuredLoan_StaticPoolFlag = replace(df6$UnsecuredLoan_StaticPoolFlag,is.na(df6$UnsecuredLoan_StaticPoolFlag),0)
df6$UnsecuredLoan_Q1Flag = replace(df6$UnsecuredLoan_Q1Flag,is.na(df6$UnsecuredLoan_Q1Flag),0)

df6$MONEYMARKET_StaticpoolFlag = replace(df6$MONEYMARKET_StaticpoolFlag,is.na(df6$MONEYMARKET_StaticpoolFlag),0)
df6$MONEYMARKET_Q1Flag = replace(df6$MONEYMARKET_Q1Flag,is.na(df6$MONEYMARKET_Q1Flag),0)

df6$CERTIFICATES_StaticpoolFlag = replace(df6$CERTIFICATES_StaticpoolFlag,is.na(df6$CERTIFICATES_StaticpoolFlag),0)
df6$CERTIFICATES_Q1Flag = replace(df6$CERTIFICATES_Q1Flag,is.na(df6$CERTIFICATES_Q1Flag),0)

df6$CHECKING_StaticpoolFlag = replace(df6$CHECKING_StaticpoolFlag,is.na(df6$CHECKING_StaticpoolFlag),0)
df6$CHECKING_Q1Flag = replace(df6$CHECKING_Q1Flag,is.na(df6$CHECKING_Q1Flag),0)

df6$SAVINGS_StaticpoolFlag = replace(df6$SAVINGS_StaticpoolFlag,is.na(df6$SAVINGS_StaticpoolFlag),0)
df6$SAVINGS_Q1Flag = replace(df6$SAVINGS_Q1Flag,is.na(df6$SAVINGS_Q1Flag),0)

df6$IRA_StaticpoolFlag = replace(df6$IRA_StaticpoolFlag,is.na(df6$IRA_StaticpoolFlag),0)
df6$IRA_Q1Flag = replace(df6$IRA_Q1Flag,is.na(df6$IRA_Q1Flag),0)


NAReplace_train <- replace(df6,is.na(df6),-9999999)
sum(is.na(NAReplace_train)) 

##5.WOE binning (WOE Binning on train data)
# install.packages("woeBinning")
library(woeBinning)


AL_binning_model <- woe.binning(NAReplace_train,'AL_TargetFlag',NAReplace_train)
AL_train_woe <- woe.binning.deploy(NAReplace_train,AL_binning_model,add.woe.or.dum.var = "woe")
index_number4 <- colnames(AL_train_woe)
write.csv(index_number4,"Combined Auto Loan WOE variables.csv") 

# Sub-setting WOE variable input to train model
df_train_woe = subset(AL_train_woe,select = c(
  woe.NumberInquiriesP6Months.binned,
  woe.AutoWorstRatingP12Months.binned,
  woe.AutoLoanOrgBalanceP12Months.binned,
  woe.AutoOpenTradeBalance.binned,
  woe.AutoOpenTradeCount.binned,
  woe.OpenTradeBalance.binned,
  woe.RevolvingAccountCount.binned,
  woe.CCCount.binned,
  woe.OpenTradeCount.binned,
  woe.Days.Since.Last.Login.binned,
  woe.CCOpenCount.binned,
  woe.CCRevolvingBalance.binned,
  woe.CCWorstRatingP12Months.binned,
  woe.CCTotalAvailableLOC.binned,
  woe.CCOpenBalance.binned,
  woe.AggregatedSpendPast3Months.binned,
  woe.TopOfWalletCCAnnualSpend.binned,
  woe.TopOfWalletCCCurrentBalance.binned,
  woe.PRODUCT_Loan_Q1.binned,
  woe.MAX_Loan_MOB.binned,
  woe.DFT_PRODUCT_Loan_Q1_Q3.binned,
  woe.DFT_PRODUCT_Loan_Q1_Q2.binned,
  woe.DFT_PRODUCT_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_PRODUCT_UnsecuredLoan_Q1_Q2.binned,
  woe.PRODUCT_UnsecuredLoan_Q1.binned,
  woe.DFT_PRODUCT_SecuredLoan_Q1_Q3.binned,
  woe.DFT_PRODUCT_SecuredLoan_Q1_Q2.binned,
  woe.PRODUCT_SecuredLoan_Q1.binned,
  woe.DFT_PRODUCT_RealEstate_Q1_Q3.binned,
  woe.DFT_PRODUCT_RealEstate_Q1_Q2.binned,
  woe.PRODUCT_RealEstate_Q1.binned,
  woe.Max_Loan_Month_to_Maturity.binned,
  woe.TRIP_FLAG_staticpool.binned,
  woe.MOB_CC_staticPool.binned,
  woe.CL_CC_StaticPool.binned,
  woe.ChargeoffAmount_final_CC.binned,
  woe.Max_MOB_CC.binned,
  woe.max_age_member_CC.binned,
  woe.max_credit_Limit.binned,
  woe.Count_Durable_CC.binned,
  woe.Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Staticpool.binned,
  woe.DFT_PRODUCT_CC_Q1_Q3.binned,
  woe.DFT_PRODUCT_CC_Q1_Q2.binned,
  woe.PRODUCT_CC_Q1.binned,
  woe.CreditCard_StaticpoolFlag.binned,
  woe.WITHDRAWAL_COUNT_CHECKING_Q1.binned,
  woe.TRANSACTION_COUNT_CHECKING_Q1.binned,
  woe.MortgageOpenCount.binned,
  woe.DFT_MAX_INTERESTRATE_Loan_Q1_Q3.binned,
  woe.DFT_SUM_PAYMENT_Loan_Q1_Q3.binned,
  woe.DFT_SUM_OriginalBalance_Loan_Q1_Q3.binned,
  woe.DFT_PAYMENTCOUNT_Loan_Q1_Q3.binned,
  woe.CL_DIFF_past_oneyear.binned,
  woe.AVG_UTILIZATION_RATE_CC_Q1.binned,
  woe.RevolvingBalance_CC_Q1.binned,
  woe.Promo_Current_Interest_CC_Q1.binned,
  woe.Protected_Current_Interest_CC_Q1.binned,
  woe.Promo_Balance_CC_Q1.binned,
  woe.Protected_Balance_CC_Q1.binned,
  woe.spend_CC_Q1.binned,
  woe.Last.Statement.Average.Daily.Balance.Amount_CC_Q1.binned,
  woe.Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1.binned,
  woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned,
  woe.Last.Statement.Charge.Sale.Amount_CC_Q1.binned,
  woe.Last.Statement.Charge.Cash.Amount_CC_Q1.binned,
  woe.Last.Statement.Charge.Late.Amount_CC_Q1.binned,
  woe.Last.Statement.Return.Count_CC_Q1.binned,
  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned,
  woe.Last.Statement.Sale.Count_CC_Q1.binned,
  woe.Last.Statement.Return.Amount_CC_Q1.binned,
  woe.Last.Statement.Cash.Amount_CC_Q1.binned,
  woe.Last.Statement.Sale.Amount_CC_Q1.binned,
  woe.Last.Statement.Payment.Amount_CC_Q1.binned,
  woe.Last.Statement.Payment.Count_CC_Q1.binned,
  woe.CreditCard_Q1Flag.binned,
  woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned,
  woe.DFT_RevolvingBalance_CC_Q1_Q2.binned,
  woe.DFT_Promo_Current_Interest_CC_Q1_Q2.binned,
  woe.DFT_Protected_Current_Interest_CC_Q1_Q2.binned,
  woe.DFT_Promo_Balance_CC_Q1_Q2.binned,
  woe.DFT_Protected_Balance_CC_Q1_Q2.binned,
  woe.DFT_spend_CC_Q1_Q2.binned,
  woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
  woe.DFT_Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
  woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
  woe.DFT_Last.Statement.Charge.Sale.Amount_CC_Q1_Q2.binned,
  woe.DFT_Last.Statement.Charge.Cash.Amount_CC_Q1_Q2.binned,
  woe.DFT_Last.Statement.Charge.Late.Amount_CC_Q1_Q2.binned,
  woe.DFT_Last.Statement.Return.Count_CC_Q1_Q2.binned,
  woe.DFT_Last.Statement.Cash.Advance.Count_CC_Q1_Q2.binned,
  woe.DFT_Last.Statement.Sale.Count_CC_Q1_Q2.binned,
  woe.DFT_Last.Statement.Return.Amount_CC_Q1_Q2.binned,
  woe.DFT_Last.Statement.Cash.Amount_CC_Q1_Q2.binned,
  woe.DFT_Last.Statement.Sale.Amount_CC_Q1_Q2.binned,
  woe.DFT_Last.Statement.Payment.Amount_CC_Q1_Q2.binned,
  woe.DFT_Last.Statement.Payment.Count_CC_Q1_Q2.binned,
  woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q3.binned,
  woe.DFT_RevolvingBalance_CC_Q1_Q3.binned,
  woe.DFT_Promo_Current_Interest_CC_Q1_Q3.binned,
  woe.DFT_Protected_Current_Interest_CC_Q1_Q3.binned,
  woe.DFT_Promo_Balance_CC_Q1_Q3.binned,
  woe.DFT_Protected_Balance_CC_Q1_Q3.binned,
  woe.DFT_spend_CC_Q1_Q3.binned,
  woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_Q1_Q3.binned,
  woe.DFT_Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1_Q3.binned,
  woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1_Q3.binned,
  woe.DFT_Last.Statement.Charge.Sale.Amount_CC_Q1_Q3.binned,
  woe.DFT_Last.Statement.Charge.Cash.Amount_CC_Q1_Q3.binned,
  woe.DFT_Last.Statement.Charge.Late.Amount_CC_Q1_Q3.binned,
  woe.DFT_Last.Statement.Return.Count_CC_Q1_Q3.binned,
  woe.DFT_Last.Statement.Cash.Advance.Count_CC_Q1_Q3.binned,
  woe.DFT_Last.Statement.Sale.Count_CC_Q1_Q3.binned,
  woe.DFT_Last.Statement.Return.Amount_CC_Q1_Q3.binned,
  woe.DFT_Last.Statement.Cash.Amount_CC_Q1_Q3.binned,
  woe.DFT_Last.Statement.Sale.Amount_CC_Q1_Q3.binned,
  woe.DFT_Last.Statement.Payment.Amount_CC_Q1_Q3.binned,
  woe.DFT_Last.Statement.Payment.Count_CC_Q1_Q3.binned,
  woe.WITHDRAWAL_COUNT_DEPOSITS_Q1.binned,
  woe.TRANSACTION_COUNT_DEPOSITS_Q1.binned,
  woe.DFT_MAX_INTERESTRATE_Loan_Q1_Q2.binned,
  woe.DFT_SUM_PAYMENT_Loan_Q1_Q2.binned,
  woe.DFT_SUM_OriginalBalance_Loan_Q1_Q2.binned,
  woe.DFT_PAYMENTCOUNT_Loan_Q1_Q2.binned,
  woe.MortgageWorstRatingP12Months.binned,
  woe.DFT_COUNT_KIOSK_Q1_Q2.binned,
  woe.DFT_COUNT_CHECKS_Q1_Q2.binned,
  woe.DFT_COUNT_INSURANCE_Q1_Q2.binned,
  woe.DFT_COUNT_HOMEBANKING_Q1_Q2.binned,
  woe.DFT_COUNT_FEE_Q1_Q2.binned,
  woe.DFT_COUNT_ACH_Q1_Q2.binned,
  woe.DFT_COUNT_DRAFT_Q1_Q2.binned,
  woe.DFT_COUNT_CASH_Q1_Q2.binned,
  woe.DFT_COUNT_LOAN_PAYMENT_Q1_Q2.binned,
  woe.DFT_COUNT_NEW_LOAN_Q1_Q2.binned,
  woe.DFT_COUNT_LOAN_ADDON_Q1_Q2.binned,
  woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned,
  woe.DFT_COUNT_KIOSK_Q1_Q3.binned,
  woe.DFT_COUNT_CHECKS_Q1_Q3.binned,
  woe.DFT_COUNT_INSURANCE_Q1_Q3.binned,
  woe.DFT_COUNT_HOMEBANKING_Q1_Q3.binned,
  woe.DFT_COUNT_FEE_Q1_Q3.binned,
  woe.DFT_COUNT_ACH_Q1_Q3.binned,
  woe.DFT_COUNT_DRAFT_Q1_Q3.binned,
  woe.DFT_COUNT_CASH_Q1_Q3.binned,
  woe.DFT_COUNT_LOAN_PAYMENT_Q1_Q3.binned,
  woe.DFT_COUNT_NEW_LOAN_Q1_Q3.binned,
  woe.DFT_COUNT_LOAN_ADDON_Q1_Q3.binned,
  woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned,
  woe.CHECKING_StaticpoolFlag.binned,
  woe.PRODUCT_CHECKING_SP.binned,
  woe.DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3.binned,
  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned,
  woe.CCAPREstimate.binned,
  woe.DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q2.binned,
  woe.MAX_INTERESTRATE_Loan_Q1.binned,
  woe.SUM_PAYMENT_Loan_Q1.binned,
  woe.SUM_OriginalBalance_Loan_Q1.binned,
  woe.PAYMENTCOUNT_Loan_Q1.binned,
  woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned,
  woe.DEPOSITED_COUNT_CHECKING_Q1.binned,
  woe.DEPOSITED_AMOUNT_CHECKING_Q1.binned,
  woe.AVG_TRANSACTION_CHECKING_Q1.binned,
  woe.CHECKING_Q1Flag.binned,
  woe.SUM_LASTDIVAMOUNT_CHECKING_Q1.binned,
  woe.PRODUCT_CHECKING_Q1.binned,
  woe.DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2.binned,
  woe.DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2.binned,
  woe.DFT_AVG_TRANSACTION_CHECKING_Q1_Q2.binned,
  woe.DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2.binned,
  woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2.binned,
  woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2.binned,
  woe.COUNT_KIOSK_Q1.binned,
  woe.COUNT_CHECKS_Q1.binned,
  woe.COUNT_INSURANCE_Q1.binned,
  woe.COUNT_HOMEBANKING_Q1.binned,
  woe.COUNT_FEE_Q1.binned,
  woe.COUNT_ACH_Q1.binned,
  woe.COUNT_DRAFT_Q1.binned,
  woe.COUNT_CASH_Q1.binned,
  woe.COUNT_LOAN_PAYMENT_Q1.binned,
  woe.COUNT_NEW_LOAN_Q1.binned,
  woe.COUNT_LOAN_ADDON_Q1.binned,
  woe.MortgageOpenBalance.binned,
  woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned,
  woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned,
  woe.DEPOSITED_COUNT_DEPOSITS_Q1.binned,
  woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned,
  woe.MOB_CHECKING.binned,
  woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3.binned,
  woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3.binned,
  woe.DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q3.binned,
  woe.DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q3.binned,
  woe.DFT_AVG_TRANSACTION_CHECKING_Q1_Q3.binned,
  woe.DFT_TRANSACTION_COUNT_CHECKING_Q1_Q3.binned,
  woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q3.binned,
  woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned,
  woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3.binned,
  woe.PRODUCT_DEPOSITS_SP.binned,
  woe.COUNT_KIOSK_STATICPOOL.binned,
  woe.COUNT_CHECKS_STATICPOOL.binned,
  woe.COUNT_INSURANCE_STATICPOOL.binned,
  woe.COUNT_HOMEBANKING_STATICPOOL.binned,
  woe.COUNT_FEE_STATICPOOL.binned,
  woe.COUNT_ACH_STATICPOOL.binned,
  woe.COUNT_DRAFT_STATICPOOL.binned,
  woe.COUNT_CASH_STATICPOOL.binned,
  woe.COUNT_LOAN_PAYMENT_STATICPOOL.binned,
  woe.COUNT_NEW_LOAN_STATICPOOL.binned,
  woe.COUNT_LOAN_ADDON_STATICPOOL.binned,
  woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2.binned,
  woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2.binned,
  woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2.binned,
  woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q3.binned,
  woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned,
  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned,
  woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q3.binned,
  woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned,
  woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3.binned,
  woe.AVG_TRANSACTION_DEPOSITS_Q1.binned,
  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q3.binned,
  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned,
  woe.SUM_INTEREST_DEPOSITS_Q1.binned,
  woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned,
  woe.DEPOSITED_AMOUNT_SAVINGS_Q1.binned,
  woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2.binned,
  woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2.binned,
  woe.WITHDRAWAL_AMOUNT_SAVINGS_Q1.binned,
  woe.PRODUCT_DEPOSITS_Q1.binned,
  woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2.binned,
  woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned,
  woe.HEOpenCount.binned,
  woe.WITHDRAWAL_COUNT_SAVINGS_Q1.binned,
  woe.DEPOSITED_COUNT_SAVINGS_Q1.binned,
  woe.TRANSACTION_COUNT_SAVINGS_Q1.binned,
  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned,
  woe.UnsecuredLoan_MOB.binned,
  woe.UnsecuredLoan_Month_to_Maturity.binned,
  woe.DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_FEE_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_ACH_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_CASH_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q3.binned,
  woe.COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_FEE_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_ACH_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_CASH_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q2.binned,
  woe.COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_AVG_TRANSACTION_SAVINGS_Q1_Q2.binned,
  woe.DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q3.binned,
  woe.DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q3.binned,
  woe.AVG_FEEAMOUNT_UnsecuredLoan_Q1.binned,
  woe.AVG_NEWBALANCE_UnsecuredLoan_Q1.binned,
  woe.FEEAMOUNT_UnsecuredLoan_Q1.binned,
  woe.INTEREST_AMOUNT_UnsecuredLoan_Q1.binned,
  woe.COUNT_KIOSK_UnsecuredLoan_Q1.binned,
  woe.COUNT_CHECKS_UnsecuredLoan_Q1.binned,
  woe.COUNT_INSURANCE_UnsecuredLoan_Q1.binned,
  woe.COUNT_HOMEBANKING_UnsecuredLoan_Q1.binned,
  woe.COUNT_FEE_UnsecuredLoan_Q1.binned,
  woe.COUNT_ACH_UnsecuredLoan_Q1.binned,
  woe.COUNT_DRAFT_UnsecuredLoan_Q1.binned,
  woe.COUNT_CASH_UnsecuredLoan_Q1.binned,
  woe.COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1.binned,
  woe.COUNT_NEW_LOAN_UnsecuredLoan_Q1.binned,
  woe.COUNT_LOAN_ADDON_UnsecuredLoan_Q1.binned,
  woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned,
  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned,
  woe.DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q2.binned,
  woe.DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q2.binned,
  woe.PRODUCT_SAVINGS_SP.binned,
  woe.HEWorstRatingP12Months.binned,
  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned,
  woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned,
  woe.AVG_TRANSACTION_SAVINGS_Q1.binned,
  woe.StudentLoanOpenCount.binned,
  woe.UnsecuredLoan_Q1Flag.binned,
  woe.MAX_INTERESTRATE_UnsecuredLoan_Q1.binned,
  woe.SUM_PAYMENT_UnsecuredLoan_Q1.binned,
  woe.SUM_OriginalBalance_UnsecuredLoan_Q1.binned,
  woe.PAYMENTCOUNT_UnsecuredLoan_Q1.binned,
  woe.UnsecuredLoan_StaticPoolFlag.binned,
  woe.RealEstate_Month_to_Maturity.binned,
  woe.RealEstate_MOB.binned,
  woe.SUM_LASTDIVAMOUNT_SAVINGS_Q1.binned,
  woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned,
  woe.DFT_SUM_INTEREST_DEPOSITS_Q1_Q2.binned,
  woe.DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q2.binned,
  woe.HETotalAvailableLOC.binned,
  woe.HEOpenBalance.binned,
  woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned,
  woe.DFT_SUM_PAYMENT_RealEstate_Q1_Q3.binned,
  woe.DFT_SUM_OriginalBalance_RealEstate_Q1_Q3.binned,
  woe.DFT_PAYMENTCOUNT_RealEstate_Q1_Q3.binned,
  woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q2.binned,
  woe.DFT_SUM_PAYMENT_RealEstate_Q1_Q2.binned,
  woe.DFT_SUM_OriginalBalance_RealEstate_Q1_Q2.binned,
  woe.DFT_PAYMENTCOUNT_RealEstate_Q1_Q2.binned,
  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned,
  woe.RealEstate_Q1Flag.binned,
  woe.MAX_INTERESTRATE_RealEstate_Q1.binned,
  woe.SUM_PAYMENT_RealEstate_Q1.binned,
  woe.SUM_OriginalBalance_RealEstate_Q1.binned,
  woe.PAYMENTCOUNT_RealEstate_Q1.binned,
  woe.RealEstate_StaticPoolFlag.binned,
  woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned,
  woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3.binned,
  woe.DFT_AVG_TRANSACTION_SAVINGS_Q1_Q3.binned,
  woe.DFT_SUM_INTEREST_DEPOSITS_Q1_Q3.binned,
  woe.SAVINGS_StaticpoolFlag.binned,
  woe.HELOCOpenCount.binned,
  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3.binned,
  woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2.binned,
  woe.DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q3.binned,
  woe.DFT_AVG_NEWBALANCE_RealEstate_Q1_Q3.binned,
  woe.DFT_FEEAMOUNT_RealEstate_Q1_Q3.binned,
  woe.DFT_INTEREST_AMOUNT_RealEstate_Q1_Q3.binned,
  woe.DFT_COUNT_KIOSK_RealEstate_Q1_Q3.binned,
  woe.DFT_COUNT_CHECKS_RealEstate_Q1_Q3.binned,
  woe.DFT_COUNT_INSURANCE_RealEstate_Q1_Q3.binned,
  woe.DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q3.binned,
  woe.DFT_COUNT_FEE_RealEstate_Q1_Q3.binned,
  woe.DFT_COUNT_ACH_RealEstate_Q1_Q3.binned,
  woe.DFT_COUNT_DRAFT_RealEstate_Q1_Q3.binned,
  woe.DFT_COUNT_CASH_RealEstate_Q1_Q3.binned,
  woe.DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q3.binned,
  woe.COUNT_NEW_LOAN_RealEstate_Q1_Q3.binned,
  woe.DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q3.binned,
  woe.DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q3.binned,
  woe.DFT_SUM_INTEREST_CERTIFICATES_Q1_Q3.binned,
  woe.DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q3.binned,
  woe.DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q3.binned,
  woe.DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q3.binned,
  woe.DFT_AVG_TRANSACTION_CERTIFICATES_Q1_Q3.binned,
  woe.DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q3.binned,
  woe.MOB_CERTIFICATES.binned,
  woe.DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q2.binned,
  woe.DFT_AVG_NEWBALANCE_RealEstate_Q1_Q2.binned,
  woe.DFT_FEEAMOUNT_RealEstate_Q1_Q2.binned,
  woe.DFT_INTEREST_AMOUNT_RealEstate_Q1_Q2.binned,
  woe.DFT_COUNT_KIOSK_RealEstate_Q1_Q2.binned,
  woe.DFT_COUNT_CHECKS_RealEstate_Q1_Q2.binned,
  woe.DFT_COUNT_INSURANCE_RealEstate_Q1_Q2.binned,
  woe.DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q2.binned,
  woe.DFT_COUNT_FEE_RealEstate_Q1_Q2.binned,
  woe.DFT_COUNT_ACH_RealEstate_Q1_Q2.binned,
  woe.DFT_COUNT_DRAFT_RealEstate_Q1_Q2.binned,
  woe.DFT_COUNT_CASH_RealEstate_Q1_Q2.binned,
  woe.DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q2.binned,
  woe.COUNT_NEW_LOAN_RealEstate_Q1_Q2.binned,
  woe.DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q2.binned,
  woe.DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q3.binned,
  woe.DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q3.binned,
  woe.StudentLoanOpenBalance.binned,
  woe.DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q2.binned,
  woe.AVG_FEEAMOUNT_RealEstate_Q1.binned,
  woe.AVG_NEWBALANCE_RealEstate_Q1.binned,
  woe.FEEAMOUNT_RealEstate_Q1.binned,
  woe.INTEREST_AMOUNT_RealEstate_Q1.binned,
  woe.COUNT_KIOSK_RealEstate_Q1.binned,
  woe.COUNT_CHECKS_RealEstate_Q1.binned,
  woe.COUNT_INSURANCE_RealEstate_Q1.binned,
  woe.COUNT_HOMEBANKING_RealEstate_Q1.binned,
  woe.COUNT_FEE_RealEstate_Q1.binned,
  woe.COUNT_ACH_RealEstate_Q1.binned,
  woe.COUNT_DRAFT_RealEstate_Q1.binned,
  woe.COUNT_CASH_RealEstate_Q1.binned,
  woe.COUNT_LOAN_PAYMENT_RealEstate_Q1.binned,
  woe.COUNT_NEW_LOAN_RealEstate_Q1.binned,
  woe.COUNT_LOAN_ADDON_RealEstate_Q1.binned,
  woe.DFT_SUM_INTEREST_CERTIFICATES_Q1_Q2.binned,
  woe.DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q2.binned,
  woe.DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q2.binned,
  woe.DFT_AVG_TRANSACTION_CERTIFICATES_Q1_Q2.binned,
  woe.DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q2.binned,
  woe.DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q2.binned,
  woe.DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q2.binned,
  woe.DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2.binned,
  woe.WITHDRAWAL_AMOUNT_CERTIFICATES_Q1.binned,
  woe.CERTIFICATES_Q1Flag.binned,
  woe.SUM_LASTDIVAMOUNT_CERTIFICATES_Q1.binned,
  woe.AVG_MONTH_END_BALANCE_CERTIFICATES_Q1.binned,
  woe.PRODUCT_CERTIFICATES_Q1.binned,
  woe.SUM_INTEREST_CERTIFICATES_Q1.binned,
  woe.WITHDRAWAL_COUNT_CERTIFICATES_Q1.binned,
  woe.DEPOSITED_COUNT_CERTIFICATES_Q1.binned,
  woe.DEPOSITED_AMOUNT_CERTIFICATES_Q1.binned,
  woe.AVG_TRANSACTION_CERTIFICATES_Q1.binned,
  woe.TRANSACTION_COUNT_CERTIFICATES_Q1.binned,
  woe.CERTIFICATES_StaticpoolFlag.binned,
  woe.PRODUCT_CERTIFICATES_SP.binned,
  woe.MOB_SAVINGS.binned,
  woe.MOB_DEPOSITS.binned,
  woe.PRODUCT_SAVINGS_Q1.binned,
  woe.HELOCWorstRatingP12Months.binned,
  woe.SecuredLoan_Month_to_Maturity.binned,
  woe.SecuredLoan_MOB.binned,
  woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned,
  woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned,
  woe.DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q3.binned,
  woe.DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q3.binned,
  woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q2.binned,
  woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q2.binned,
  woe.DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q2.binned,
  woe.DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q2.binned,
  woe.DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q3.binned,
  woe.DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q3.binned,
  woe.DFT_FEEAMOUNT_SecuredLoan_Q1_Q3.binned,
  woe.DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_KIOSK_SecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_CHECKS_SecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_FEE_SecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_ACH_SecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_DRAFT_SecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_CASH_SecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q3.binned,
  woe.COUNT_NEW_LOAN_SecuredLoan_Q1_Q3.binned,
  woe.DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q3.binned,
  woe.DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q2.binned,
  woe.DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q2.binned,
  woe.DFT_FEEAMOUNT_SecuredLoan_Q1_Q2.binned,
  woe.DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_KIOSK_SecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_CHECKS_SecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_FEE_SecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_ACH_SecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_DRAFT_SecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_CASH_SecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q2.binned,
  woe.COUNT_NEW_LOAN_SecuredLoan_Q1_Q2.binned,
  woe.DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q2.binned,
  woe.SecuredLoan_StaticPoolFlag.binned,
  woe.SecuredLoan_Q1Flag.binned,
  woe.MAX_INTERESTRATE_SecuredLoan_Q1.binned,
  woe.SUM_PAYMENT_SecuredLoan_Q1.binned,
  woe.SUM_OriginalBalance_SecuredLoan_Q1.binned,
  woe.PAYMENTCOUNT_SecuredLoan_Q1.binned,
  woe.HELOCOpenBalance.binned,
  woe.HELOCTotalAvailableLOC.binned,
  woe.AVG_FEEAMOUNT_SecuredLoan_Q1.binned,
  woe.AVG_NEWBALANCE_SecuredLoan_Q1.binned,
  woe.FEEAMOUNT_SecuredLoan_Q1.binned,
  woe.INTEREST_AMOUNT_SecuredLoan_Q1.binned,
  woe.COUNT_KIOSK_SecuredLoan_Q1.binned,
  woe.COUNT_CHECKS_SecuredLoan_Q1.binned,
  woe.COUNT_INSURANCE_SecuredLoan_Q1.binned,
  woe.COUNT_HOMEBANKING_SecuredLoan_Q1.binned,
  woe.COUNT_FEE_SecuredLoan_Q1.binned,
  woe.COUNT_ACH_SecuredLoan_Q1.binned,
  woe.COUNT_DRAFT_SecuredLoan_Q1.binned,
  woe.COUNT_CASH_SecuredLoan_Q1.binned,
  woe.COUNT_LOAN_PAYMENT_SecuredLoan_Q1.binned,
  woe.COUNT_NEW_LOAN_SecuredLoan_Q1.binned,
  woe.COUNT_LOAN_ADDON_SecuredLoan_Q1.binned,
  woe.DFT_PRODUCT_CHECKING_Q1_Q3.binned,
  woe.ChargeOffTradeCountP12Months.binned,
  woe.ChargeOffTotalBalance.binned,
  woe.WITHDRAWAL_COUNT_IRA_Q1.binned,
  woe.DEPOSITED_COUNT_IRA_Q1.binned,
  woe.DEPOSITED_AMOUNT_IRA_Q1.binned,
  woe.AVG_TRANSACTION_IRA_Q1.binned,
  woe.TRANSACTION_COUNT_IRA_Q1.binned,
  woe.WITHDRAWAL_AMOUNT_IRA_Q1.binned,
  woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned,
  woe.DFT_WITHDRAWAL_COUNT_IRA_Q1_Q3.binned,
  woe.DFT_DEPOSITED_COUNT_IRA_Q1_Q3.binned,
  woe.DFT_DEPOSITED_AMOUNT_IRA_Q1_Q3.binned,
  woe.DFT_AVG_TRANSACTION_IRA_Q1_Q3.binned,
  woe.DFT_TRANSACTION_COUNT_IRA_Q1_Q3.binned,
  woe.DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q3.binned,
  woe.DFT_PRODUCT_CHECKING_Q1_Q2.binned,
  woe.IRA_StaticpoolFlag.binned,
  woe.PRODUCT_IRA_SP.binned,
  woe.DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q3.binned,
  woe.DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q3.binned,
  woe.DFT_PRODUCT_CERTIFICATES_Q1_Q3.binned,
  woe.IRA_Q1Flag.binned,
  woe.SUM_LASTDIVAMOUNT_IRA_Q1.binned,
  woe.AVG_MONTH_END_BALANCE_IRA_Q1.binned,
  woe.PRODUCT_IRA_Q1.binned,
  woe.DFT_WITHDRAWAL_COUNT_IRA_Q1_Q2.binned,
  woe.DFT_DEPOSITED_COUNT_IRA_Q1_Q2.binned,
  woe.DFT_DEPOSITED_AMOUNT_IRA_Q1_Q2.binned,
  woe.DFT_AVG_TRANSACTION_IRA_Q1_Q2.binned,
  woe.DFT_TRANSACTION_COUNT_IRA_Q1_Q2.binned,
  woe.DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q2.binned,
  woe.DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q2.binned,
  woe.DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q2.binned,
  woe.MOB_IRA.binned,
  woe.DFT_PRODUCT_CERTIFICATES_Q1_Q2.binned,
  woe.MOB_MONEYMARKET.binned,
  woe.MONEYMARKET_Q1Flag.binned,
  woe.SUM_LASTDIVAMOUNT_MONEYMARKET_Q1.binned,
  woe.AVG_MONTH_END_BALANCE_MONEYMARKET_Q1.binned,
  woe.PRODUCT_MONEYMARKET_Q1.binned,
  woe.DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q3.binned,
  woe.DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q3.binned,
  woe.MONEYMARKET_StaticpoolFlag.binned,
  woe.PRODUCT_MONEYMARKET_SP.binned,
  woe.DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2.binned,
  woe.DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2.binned,
  woe.BankruptcyCount.binned,
  woe.DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q3.binned,
  woe.DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q3.binned,
  woe.DFT_AVG_TRANSACTION_MONEYMARKET_Q1_Q3.binned,
  woe.DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q3.binned,
  woe.DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q3.binned,
  woe.DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q3.binned,
  woe.WITHDRAWAL_COUNT_MONEYMARKET_Q1.binned,
  woe.DEPOSITED_COUNT_MONEYMARKET_Q1.binned,
  woe.DEPOSITED_AMOUNT_MONEYMARKET_Q1.binned,
  woe.AVG_TRANSACTION_MONEYMARKET_Q1.binned,
  woe.TRANSACTION_COUNT_MONEYMARKET_Q1.binned,
  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned,
  woe.DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q2.binned,
  woe.DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q2.binned,
  woe.DFT_AVG_TRANSACTION_MONEYMARKET_Q1_Q2.binned,
  woe.DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q2.binned,
  woe.DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q2.binned,
  woe.DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q2.binned,
  woe.DFT_PRODUCT_SAVINGS_Q1_Q2.binned,
  woe.DFT_PRODUCT_IRA_Q1_Q2.binned,
  woe.DFT_PRODUCT_IRA_Q1_Q3.binned,
  woe.DFT_PRODUCT_DEPOSITS_Q1_Q2.binned,
  woe.DFT_PRODUCT_SAVINGS_Q1_Q3.binned,
  woe.DFT_PRODUCT_MONEYMARKET_Q1_Q2.binned,
  woe.DFT_PRODUCT_MONEYMARKET_Q1_Q3.binned,
  woe.SAVINGS_Q1Flag.binned,
  AL_TargetFlag))

df_train_woe$AL_TargetFlag = as.factor(df_train_woe$AL_TargetFlag)
dim(df_train_woe) #557 vars


# 6. Random Forest Feature Selection
# 
# install.packages("randomForest")
# install.packages('e1071')
# install.packages('caret')
# install.packages('ROCR')

# RandomForest
set.seed(2022)
RF_AL <- randomForest(AL_TargetFlag ~.,data = df_train_woe,ntree=50)
Important_vr <- importance(RF_AL)
write.csv(Important_vr,"Important Variables for AutoLoan.csv")


# Selecting variables with Mean_Gini_Index more than 10:
df7 = subset(df_train_woe,select =c(woe.NumberInquiriesP6Months.binned,
                                    woe.DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q3.binned,
                                    woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned,
                                    woe.DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3.binned,
                                    woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned,
                                    woe.DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q2.binned,
                                    woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3.binned,
                                    woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                    woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned,
                                    woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned,
                                    woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                    woe.StudentLoanOpenCount.binned,
                                    woe.DFT_AVG_TRANSACTION_SAVINGS_Q1_Q2.binned,
                                    woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                    woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2.binned,
                                    woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q3.binned,
                                    woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2.binned,
                                    woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned,
                                    woe.MOB_SAVINGS.binned,
                                    woe.Days.Since.Last.Login.binned,
                                    woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned,
                                    woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                    woe.CCAPREstimate.binned,
                                    woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned,
                                    woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2.binned,
                                    woe.DFT_AVG_TRANSACTION_SAVINGS_Q1_Q3.binned,
                                    woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned,
                                    woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned,
                                    woe.StudentLoanOpenBalance.binned,
                                    woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q3.binned,
                                    woe.MOB_DEPOSITS.binned,
                                    woe.MortgageOpenBalance.binned,
                                    woe.MortgageWorstRatingP12Months.binned,
                                    woe.DEPOSITED_AMOUNT_SAVINGS_Q1.binned,
                                    woe.MortgageOpenCount.binned,
                                    woe.HEOpenCount.binned,
                                    woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned,
                                    woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned,
                                    woe.HELOCOpenCount.binned,
                                    woe.TRANSACTION_COUNT_DEPOSITS_Q1.binned,
                                    woe.PRODUCT_SAVINGS_SP.binned,
                                    woe.WITHDRAWAL_COUNT_DEPOSITS_Q1.binned,
                                    woe.WITHDRAWAL_AMOUNT_SAVINGS_Q1.binned,
                                    woe.DEPOSITED_COUNT_SAVINGS_Q1.binned,
                                    woe.PRODUCT_SAVINGS_Q1.binned,
                                    woe.DEPOSITED_COUNT_DEPOSITS_Q1.binned,
                                    woe.AutoOpenTradeCount.binned,
                                    woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned,
                                    woe.WITHDRAWAL_COUNT_SAVINGS_Q1.binned,
                                    woe.AutoOpenTradeBalance.binned,
                                    woe.AutoLoanOrgBalanceP12Months.binned,
                                    woe.ChargeOffTradeCountP12Months.binned,
                                    woe.WITHDRAWAL_COUNT_CHECKING_Q1.binned,
                                    woe.PRODUCT_Loan_Q1.binned,
                                    woe.ChargeOffTotalBalance.binned,
                                    woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned,
                                    woe.HETotalAvailableLOC.binned,
                                    woe.HEOpenBalance.binned,
                                    woe.HEWorstRatingP12Months.binned,
                                    woe.HELOCWorstRatingP12Months.binned,
                                    woe.AutoWorstRatingP12Months.binned,
                                    woe.AVG_TRANSACTION_DEPOSITS_Q1.binned,
                                    woe.HELOCTotalAvailableLOC.binned,
                                    woe.HELOCOpenBalance.binned,
                                    woe.BankruptcyCount.binned,
                                    woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned,
                                    woe.UnsecuredLoan_Month_to_Maturity.binned,
                                    woe.UnsecuredLoan_StaticPoolFlag.binned,
                                    woe.RealEstate_Month_to_Maturity.binned,
                                    woe.RealEstate_StaticPoolFlag.binned,
                                    woe.CHECKING_StaticpoolFlag.binned,
                                    woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned,
                                    woe.DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q3.binned,
                                    woe.DFT_SUM_PAYMENT_RealEstate_Q1_Q3.binned,
                                    woe.SUM_PAYMENT_UnsecuredLoan_Q1.binned,
                                    woe.DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2.binned,
                                    woe.Max_MOB_CC.binned,
                                    woe.CreditCard_StaticpoolFlag.binned,
                                    woe.MAX_INTERESTRATE_SecuredLoan_Q1.binned,
                                    woe.DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q2.binned,
                                    woe.WITHDRAWAL_COUNT_MONEYMARKET_Q1.binned,
                                    woe.MONEYMARKET_StaticpoolFlag.binned,
                                    woe.DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q3.binned,
                                    woe.SecuredLoan_StaticPoolFlag.binned,
                                    woe.DFT_Last.Statement.Sale.Amount_CC_Q1_Q3.binned,
                                    woe.Last.Statement.Payment.Amount_CC_Q1.binned,
                                    woe.Last.Statement.Charge.Cash.Amount_CC_Q1.binned,
                                    woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned,
                                    woe.DFT_COUNT_CASH_SecuredLoan_Q1_Q3.binned,
                                    woe.IRA_StaticpoolFlag.binned,
                                    AL_TargetFlag))
dim(df7) # 91 vars

df7$AL_TargetFlag = as.factor(df7$AL_TargetFlag)


# Iteration 1 :
sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list1 = colnames(subset(df7,select = - AL_TargetFlag))
stepwise_1 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list1, data = df7,
                              sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

logreg1 <- glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AutoLoanOrgBalanceP12Months.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
                 woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.StudentLoanOpenCount.binned + 
                 woe.PRODUCT_Loan_Q1.binned + woe.ChargeOffTotalBalance.binned + 
                 woe.CCAPREstimate.binned + woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.AutoWorstRatingP12Months.binned + 
                 woe.HETotalAvailableLOC.binned + woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.TRANSACTION_COUNT_DEPOSITS_Q1.binned + 
                 woe.StudentLoanOpenBalance.binned + woe.HEOpenCount.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.PRODUCT_SAVINGS_Q1.binned, 
                family = binomial(logit),data = df7)

a1 <- Anova(logreg1,type = "II",test = "Wald" )

v1 <- vif(logreg1)

write.csv(a1,"ANOVA.csv")

write.csv(v1,"VIF.csv")

summary(logreg1)

df8 = subset(df7,select = -woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q3.binned)
dim(df8) # 90 vars


# Iteration 2 :
sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list2 = colnames(subset(df8,select = - AL_TargetFlag))
stepwise_2 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list2, data = df8, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)


logreg2 <- glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AutoLoanOrgBalanceP12Months.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
                 woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.StudentLoanOpenCount.binned + 
                 woe.PRODUCT_Loan_Q1.binned + woe.ChargeOffTotalBalance.binned + 
                 woe.CCAPREstimate.binned + woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.AutoWorstRatingP12Months.binned + 
                 woe.HETotalAvailableLOC.binned + woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.TRANSACTION_COUNT_DEPOSITS_Q1.binned + 
                 woe.StudentLoanOpenBalance.binned + woe.HEOpenCount.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.PRODUCT_SAVINGS_Q1.binned, family = binomial(logit), 
               data = df8)


a2 <- Anova(logreg2,type = "II",test = "Wald" )

v2 <- vif(logreg2)

write.csv(a2,"ANOVA2.csv")

write.csv(v2,"VIF2.csv")

summary(logreg2)

df9 = subset(df8,select = -woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned)
dim(df9) # 89 vars


# Iteration 3 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list3 = colnames(subset(df9,select = - AL_TargetFlag))
stepwise_3 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list3, data = df9, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

logreg3 <-glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
                woe.Days.Since.Last.Login.binned + woe.AutoLoanOrgBalanceP12Months.binned + 
                woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
                woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.StudentLoanOpenCount.binned + 
                woe.PRODUCT_Loan_Q1.binned + woe.ChargeOffTotalBalance.binned + 
                woe.CCAPREstimate.binned + woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3.binned + 
                woe.MortgageOpenCount.binned + woe.AutoWorstRatingP12Months.binned + 
                woe.HETotalAvailableLOC.binned + woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
                woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.TRANSACTION_COUNT_DEPOSITS_Q1.binned + 
                woe.StudentLoanOpenBalance.binned + woe.HEOpenCount.binned + 
                woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + woe.PRODUCT_SAVINGS_Q1.binned + 
                woe.WITHDRAWAL_AMOUNT_SAVINGS_Q1.binned + woe.DEPOSITED_AMOUNT_SAVINGS_Q1.binned, 
              family = binomial(logit), data = df9)


a3 <- Anova(logreg3,type = "II",test = "Wald" )

v3 <- vif(logreg3)

write.csv(a3,"ANOVA3.csv")

write.csv(v3,"VIF3.csv")

summary(logreg3)

df10 = subset(df9,select = -woe.HEOpenCount.binned)
dim(df10) # 88 vars

# Iteration 4 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list4 = colnames(subset(df10,select = - AL_TargetFlag))
stepwise_4 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list4, data = df10, sle = 0.05,sls = 0.05, myfamily="binomial")


sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

logreg4 <- glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AutoLoanOrgBalanceP12Months.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
                 woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.StudentLoanOpenCount.binned + 
                 woe.PRODUCT_Loan_Q1.binned + woe.ChargeOffTotalBalance.binned + 
                 woe.CCAPREstimate.binned + woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.AutoWorstRatingP12Months.binned + 
                 woe.HETotalAvailableLOC.binned + woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.TRANSACTION_COUNT_DEPOSITS_Q1.binned + 
                 woe.StudentLoanOpenBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned, 
               family = binomial(logit), data = df10)

a4 <- Anova(logreg4,type = "II",test = "Wald" )

v4 <- vif(logreg4)

write.csv(a4,"ANOVA4.csv")

write.csv(v4,"VIF4.csv")

summary(logreg4)

df11 = subset(df10,select = -woe.StudentLoanOpenBalance.binned)
dim(df11) # 87 vars


# Iteration 5 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list5 = colnames(subset(df11,select = - AL_TargetFlag))
stepwise_5 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list5, data = df11, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

logreg5 <- glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
      woe.Days.Since.Last.Login.binned + woe.AutoLoanOrgBalanceP12Months.binned + 
      woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
      woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.StudentLoanOpenCount.binned + 
      woe.PRODUCT_Loan_Q1.binned + woe.ChargeOffTotalBalance.binned + 
      woe.CCAPREstimate.binned + woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3.binned + 
      woe.MortgageOpenCount.binned + woe.AutoWorstRatingP12Months.binned + 
      woe.HETotalAvailableLOC.binned + woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
      woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.TRANSACTION_COUNT_DEPOSITS_Q1.binned + 
      woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned, family = binomial(logit), data = df11)

a5 <- Anova(logreg5,type = "II",test = "Wald" )

v5 <- vif(logreg5)

write.csv(a5,"ANOVA5.csv")

write.csv(v5,"VIF5.csv")

summary(logreg5)

df12 = subset(df11,select = -woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned)
dim(df12) # 86 vars



# Iteration 6 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list6 = colnames(subset(df12,select = - AL_TargetFlag))
stepwise_6 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list6, data = df12, sle = 0.05,sls = 0.05, myfamily="binomial")


sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

logreg6 <- glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AutoLoanOrgBalanceP12Months.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
                 woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.StudentLoanOpenCount.binned + 
                 woe.PRODUCT_Loan_Q1.binned + woe.CCAPREstimate.binned + woe.MortgageOpenCount.binned + 
                 woe.HETotalAvailableLOC.binned + woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
                 woe.PRODUCT_SAVINGS_Q1.binned, family = binomial(logit), data = df12)


a6 <- Anova(logreg6,type = "II",test = "Wald" )

v6 <- vif(logreg6)

write.csv(a6,"ANOVA6.csv")

write.csv(v6,"VIF6.csv")

summary(logreg6)

df13 = subset(df12,select = -woe.CCAPREstimate.binned)
dim(df13) # 85 vars  

# Iteration 7 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list7 = colnames(subset(df13,select = - AL_TargetFlag))
stepwise_7 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list7, data = df13, sle = 0.05,sls = 0.05, myfamily="binomial")


sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

logreg7 <-  glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
      woe.Days.Since.Last.Login.binned + woe.AutoLoanOrgBalanceP12Months.binned + 
      woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
      woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.StudentLoanOpenCount.binned + 
      woe.UnsecuredLoan_Month_to_Maturity.binned + woe.ChargeOffTotalBalance.binned + 
      woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned + woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned + 
      woe.MortgageOpenCount.binned + woe.RealEstate_Month_to_Maturity.binned + 
      woe.AutoWorstRatingP12Months.binned + woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
      woe.IRA_StaticpoolFlag.binned + woe.PRODUCT_SAVINGS_Q1.binned + 
      woe.HETotalAvailableLOC.binned, family = binomial(logit), 
    data = df13)

a7 <- Anova(logreg7,type = "II",test = "Wald" )

v7 <- vif(logreg7)

write.csv(a7,"ANOVA7.csv")

write.csv(v7,"VIF7.csv")

summary(logreg7)

df14 = subset(df13,select = -woe.MortgageOpenCount.binned)
dim(df14) # 84 vars
  

# Iteration 8 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list8 = colnames(subset(df14,select = - AL_TargetFlag))
stepwise_8 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list8, data = df14, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

logreg8 <- glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AutoLoanOrgBalanceP12Months.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
                 woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.StudentLoanOpenCount.binned + 
                 woe.UnsecuredLoan_Month_to_Maturity.binned + woe.ChargeOffTotalBalance.binned + 
                 woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned + woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned + 
                 woe.AutoWorstRatingP12Months.binned + woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
                 woe.MortgageOpenBalance.binned + woe.HETotalAvailableLOC.binned + 
                 woe.IRA_StaticpoolFlag.binned + woe.PRODUCT_SAVINGS_Q1.binned + 
                 woe.RealEstate_Month_to_Maturity.binned + woe.HEWorstRatingP12Months.binned, 
               family = binomial(logit), data = df14)

a8 <- Anova(logreg8,type = "II",test = "Wald" )

v8 <- vif(logreg8)

write.csv(a8,"ANOVA8.csv")

write.csv(v8,"VIF8.csv")

summary(logreg8)

df15 = subset(df14,select = -woe.HEWorstRatingP12Months.binned)
dim(df15) # 83 vars

# Iteration 9 :
sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list9 = colnames(subset(df15,select = - AL_TargetFlag))
stepwise_9 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list9, data = df15, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

logreg9 <- glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AutoLoanOrgBalanceP12Months.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
                 woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.StudentLoanOpenCount.binned + 
                 woe.UnsecuredLoan_Month_to_Maturity.binned + woe.ChargeOffTotalBalance.binned + 
                 woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned + woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned + 
                 woe.AutoWorstRatingP12Months.binned + woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
                 woe.MortgageOpenBalance.binned + woe.HETotalAvailableLOC.binned + 
                 woe.IRA_StaticpoolFlag.binned + woe.PRODUCT_SAVINGS_Q1.binned + 
                 woe.RealEstate_Month_to_Maturity.binned, family = binomial(logit), 
               data = df15)

a9 <- Anova(logreg9,type = "II",test = "Wald" )

v9 <- vif(logreg9)

write.csv(a9,"ANOVA9.csv")

write.csv(v9,"VIF9.csv")

summary(logreg9)

df16 = subset(df15,select = -woe.MortgageOpenBalance.binned)
dim(df16) # 82 vars

# Iteration 10 :
sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list10 = colnames(subset(df16,select = - AL_TargetFlag))
stepwise_10 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list10, data = df16, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

logreg10 <- glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
                  woe.Days.Since.Last.Login.binned + woe.AutoLoanOrgBalanceP12Months.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
                  woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.StudentLoanOpenCount.binned + 
                  woe.UnsecuredLoan_Month_to_Maturity.binned + woe.ChargeOffTotalBalance.binned + 
                  woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned + woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned + 
                  woe.AutoWorstRatingP12Months.binned + woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
                  woe.MortgageWorstRatingP12Months.binned + woe.HETotalAvailableLOC.binned + 
                  woe.IRA_StaticpoolFlag.binned + woe.PRODUCT_SAVINGS_Q1.binned + 
                  woe.RealEstate_Month_to_Maturity.binned, family = binomial(logit), 
                data = df16)

a10 <- Anova(logreg10,type = "II",test = "Wald" )

v10 <- vif(logreg10)

write.csv(a10,"ANOVA10.csv")

write.csv(v10,"VIF10.csv")

summary(logreg10)

df17 = subset(df16,select = -woe.MortgageWorstRatingP12Months.binned)
dim(df17) # 81 vars

# Iteration 11 :

# prints recorded time
sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list11 = colnames(subset(df17,select = - AL_TargetFlag))
stepwise_11 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list11, data = df17, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

logreg11 <-glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AutoLoanOrgBalanceP12Months.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
                 woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.StudentLoanOpenCount.binned + 
                 woe.UnsecuredLoan_Month_to_Maturity.binned + woe.ChargeOffTotalBalance.binned + 
                 woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned + woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned + 
                 woe.AutoWorstRatingP12Months.binned + woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
                 woe.HETotalAvailableLOC.binned + woe.IRA_StaticpoolFlag.binned + 
                 woe.PRODUCT_SAVINGS_Q1.binned, family = binomial(logit), 
               data = df17)


a11 <- Anova(logreg11,type = "II",test = "Wald" )

v11 <- vif(logreg11)

write.csv(a11,"ANOVA11.csv")

write.csv(v11,"VIF11.csv")

summary(logreg11)

df18 = subset(df17,select = -woe.ChargeOffTotalBalance.binned)
dim(df18) # 80 vars

# Iteration 12 :  
  
# prints recorded time
sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list12 = colnames(subset(df18,select = - AL_TargetFlag))
stepwise_12 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list12, data = df18, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

logreg12 <-  glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
                   woe.Days.Since.Last.Login.binned + woe.AutoLoanOrgBalanceP12Months.binned + 
                   woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
                   woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.StudentLoanOpenCount.binned + 
                   woe.UnsecuredLoan_Month_to_Maturity.binned + woe.ChargeOffTradeCountP12Months.binned + 
                   woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned + woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned + 
                   woe.AutoWorstRatingP12Months.binned + woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
                   woe.HETotalAvailableLOC.binned + woe.IRA_StaticpoolFlag.binned + 
                   woe.PRODUCT_SAVINGS_Q1.binned, family = binomial(logit), 
                 data = df18)

a12 <- Anova(logreg12,type = "II",test = "Wald" )

v12 <- vif(logreg12)

write.csv(a12,"ANOVA12.csv")

write.csv(v12,"VIF12.csv")

summary(logreg12)

df19 = subset(df18,select = -woe.ChargeOffTradeCountP12Months.binned)
dim(df19) # 79 vars

head(df4)

# Iteration 13 :

# prints recorded time
sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list13 = colnames(subset(df19,select = - AL_TargetFlag))
stepwise_13 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list13, data = df19, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

logreg13 <- glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
                  woe.Days.Since.Last.Login.binned + woe.AutoLoanOrgBalanceP12Months.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
                  woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.StudentLoanOpenCount.binned + 
                  woe.UnsecuredLoan_Month_to_Maturity.binned + woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned + 
                  woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned + woe.AutoWorstRatingP12Months.binned + 
                  woe.TRANSACTION_COUNT_DEPOSITS_Q1.binned + woe.HETotalAvailableLOC.binned + 
                  woe.IRA_StaticpoolFlag.binned + woe.PRODUCT_SAVINGS_Q1.binned, 
                family = binomial(logit), data = df19)
  
a13 <- Anova(logreg13,type = "II",test = "Wald" )

v13 <- vif(logreg13)

write.csv(a13,"ANOVA13.csv")

write.csv(v13,"VIF13.csv")

summary(logreg13)

df20 = subset(df19,select = -c(woe.StudentLoanOpenCount.binned,woe.AutoWorstRatingP12Months.binned,woe.NumberInquiriesP6Months.binned))
dim(df20) # 76 vars

# Iteration 14 :

# prints recorded time
sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list14 = colnames(subset(df20,select = - AL_TargetFlag))
stepwise_14 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list14, data = df20, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

logreg14 <-glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AutoLoanOrgBalanceP12Months.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
                 woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.UnsecuredLoan_Month_to_Maturity.binned + 
                 woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned + woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned + 
                 woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + woe.RealEstate_Month_to_Maturity.binned + 
                 woe.IRA_StaticpoolFlag.binned + woe.PRODUCT_SAVINGS_Q1.binned, 
               family = binomial(logit), data = df20)

a14 <- Anova(logreg14,type = "II",test = "Wald" )

v14 <- vif(logreg14)

write.csv(a14,"ANOVA14.csv")

write.csv(v14,"VIF14.csv")

summary(logreg14)

################################################################################
###############  Final Iteration with Model creation   #########################
################################################################################

###Original Variable relationship & VIF (Main Model on Test data set)

Original_Model <- glm(formula = AL_TargetFlag ~ 
                        NumberInquiriesP6Months + 
                        Days.Since.Last.Login + 
                        AutoLoanOrgBalanceP12Months + 
                        AVG_MONTH_END_BALANCE_DEPOSITS_Q1 + 
                        MOB_DEPOSITS + 
                        DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3 + 
                        UnsecuredLoan_Month_to_Maturity + 
                        DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3 + 
                        DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3 + 
                        DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2 + 
                        RealEstate_Month_to_Maturity + 
                        IRA_StaticpoolFlag + 
                        PRODUCT_SAVINGS_Q1, 
                       family = binomial(logit), data = NAReplace_train)

summary(Original_Model)

Original_vif <- vif(Original_Model)

write.csv(Original_vif,"Original_vif.csv")

#Selecting Test (original) data 13 variable For KS Lift (Using Traing model in decidle) (to check decile)
Test_Data = subset(AL_test,select = c(AL_TargetFlag,
                                      NumberInquiriesP6Months,
                                      AutoLoanOrgBalanceP12Months,
                                      Days.Since.Last.Login,
                                      MOB_DEPOSITS,
                                      AVG_MONTH_END_BALANCE_DEPOSITS_Q1,
                                      UnsecuredLoan_Month_to_Maturity,
                                      DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3,
                                      DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3,
                                      DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2,
                                      RealEstate_Month_to_Maturity,
                                      IRA_StaticpoolFlag,
                                      DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3,
                                      PRODUCT_SAVINGS_Q1,
                                      DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2
                                      ))

#removing NA
Test_Data$IRA_StaticpoolFlag = replace(Test_Data$IRA_StaticpoolFlag,
                                                is.na(Test_Data$IRA_StaticpoolFlag),0)

# Replace NA
dftest <- replace(Test_Data,is.na(Test_Data),-9999999)

# Test date Transformation into WOE 
AL_binning_Testmodel <- woe.binning(dftest,'AL_TargetFlag',dftest)
AL_test_woe <- woe.binning.deploy(dftest,AL_binning_Testmodel,add.woe.or.dum.var = "woe")

# Checking Accuracy of Test
blr_gains_table(logreg14,data = AL_test_woe)

# Checking Accuracy of Train
blr_gains_table(logreg14,data = df20)


# 2nd MODEL (to check VIF and Relationship)
Original_Model1 <- glm(formula = AL_TargetFlag ~ 
                        NumberInquiriesP6Months + 
                        Days.Since.Last.Login + 
                        AutoLoanOrgBalanceP12Months + 
                        AVG_MONTH_END_BALANCE_DEPOSITS_Q1 + 
                        MOB_DEPOSITS +  
                        UnsecuredLoan_Month_to_Maturity + 
                        DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3 + 
                        DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3 + 
                        DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2 + 
                        RealEstate_Month_to_Maturity + 
                        IRA_StaticpoolFlag + 
                        PRODUCT_SAVINGS_Q1, 
                      family = binomial(logit), data = NAReplace_train)

summary(Original_Model1)

Original_vif1 <- vif(Original_Model1)

write.csv(Original_vif1,"Original_vif1.csv")

# TRAIN MODEL 2
trainmodel2 <-glm(formula = AL_TargetFlag ~ 
                  woe.NumberInquiriesP6Months.binned + 
                  woe.Days.Since.Last.Login.binned + 
                  woe.AutoLoanOrgBalanceP12Months.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                  woe.MOB_DEPOSITS.binned + 
                  woe.UnsecuredLoan_Month_to_Maturity.binned + 
                  woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned + 
                  woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
                  woe.RealEstate_Month_to_Maturity.binned + 
                  woe.IRA_StaticpoolFlag.binned + 
                  woe.PRODUCT_SAVINGS_Q1.binned, 
               family = binomial(logit), data = df20)


trainmodel2_anova <- Anova(trainmodel2,type = "II",test = "Wald" )

trainmodel2_vif <- vif(trainmodel2)

write.csv(trainmodel2_anova,"trainmodel2_anova.csv")

write.csv(trainmodel2_vif,"trainmodel2_vif.csv")

summary(trainmodel2)

# Checking Accuracy of test
blr_gains_table(trainmodel2,data = AL_test_woe)

# Checking Accuracy of train
blr_gains_table(trainmodel2,data = df20)


dim(df_target)

colnames(AL_train_woe)


# (removing all unwanted variable)selecting onlu final variable) -- All final variable from model2

df_target = subset(AL_train_woe,select = c(AL_TargetFlag,
                                  woe.NumberInquiriesP6Months.binned,
                                  woe.Days.Since.Last.Login.binned,
                                  woe.AutoLoanOrgBalanceP12Months.binned,
                                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned,
                                  woe.MOB_DEPOSITS.binned,
                                  woe.UnsecuredLoan_Month_to_Maturity.binned,
                                  woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned,
                                  woe.IRA_StaticpoolFlag.binned,
                                  woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2.binned))
                                  #woe.RealEstate_Month_to_Maturity.binned
                                  #woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned,                                 
                                  #woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned,
                                  #woe.PRODUCT_SAVINGS_Q1.binned))




# TRAIN MODEL 3
trainmodel3 <-glm(formula = AL_TargetFlag ~ 
                    woe.NumberInquiriesP6Months.binned + 
                    woe.Days.Since.Last.Login.binned + 
                    woe.AutoLoanOrgBalanceP12Months.binned + 
                    woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                    woe.MOB_DEPOSITS.binned + 
                    woe.UnsecuredLoan_Month_to_Maturity.binned  +
                    woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned
                    # woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2.binned
                  #woe.IRA_StaticpoolFlag.binned
                  ,family = binomial(logit), data = df_target)


trainmodel3_anova <- Anova(trainmodel3,type = "II",test = "Wald" )
trainmodel3_anova

trainmodel3_vif <- vif(trainmodel3)

write.csv(trainmodel3_anova,"trainmodel3_anova.csv")

write.csv(trainmodel3_vif,"trainmodel3_vif.csv")

summary(trainmodel3)

# Checking Accuracy of train
blr_gains_table(trainmodel3,data = df_target)

# Checking Accuracy of test
blr_gains_table(trainmodel3,data = AL_test_woe)



# 3rd MODEL (to check VIF and Relationship)
Original_Model2 <- glm(formula = AL_TargetFlag ~ 
                         NumberInquiriesP6Months + 
                         Days.Since.Last.Login + 
                         AutoLoanOrgBalanceP12Months + 
                         AVG_MONTH_END_BALANCE_DEPOSITS_Q1 + 
                         MOB_DEPOSITS + 
                         UnsecuredLoan_Month_to_Maturity + 
                         DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3, 
                       family = binomial(logit), data = NAReplace_train)

summary(Original_Model2)
v2023 = vif(Original_Model2)

write.csv(v2023,"trainmodel3_vif.csv")


# TRAIN MODEL 4
trainmodel4 <-glm(formula = AL_TargetFlag ~ 
                    woe.NumberInquiriesP6Months.binned + 
                    woe.Days.Since.Last.Login.binned + 
                    woe.AutoLoanOrgBalanceP12Months.binned + 
                    woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                    woe.MOB_DEPOSITS.binned + 
                    woe.UnsecuredLoan_Month_to_Maturity.binned  +
                    woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned+
                    woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2.binned
                  #woe.IRA_StaticpoolFlag.binned
                  ,family = binomial(logit), data = df_target)


trainmodel4_anova <- Anova(trainmodel4,type = "II",test = "Wald" )
trainmodel4_anova

trainmodel4_vif <- vif(trainmodel4)

write.csv(trainmodel4_anova,"trainmodel4_anova.csv")

write.csv(trainmodel4_vif,"trainmodel4_vif.csv")

summary(trainmodel4)

# Checking Accuracy of train
blr_gains_table(trainmodel4,data = df_target)

# Checking Accuracy of test
blr_gains_table(trainmodel4,data = AL_test_woe)


# 3rd MODEL (to check VIF and Relationship)
Original_Model4 <- glm(formula = AL_TargetFlag ~ 
                         NumberInquiriesP6Months + 
                         Days.Since.Last.Login + 
                         AutoLoanOrgBalanceP12Months + 
                         AVG_MONTH_END_BALANCE_DEPOSITS_Q1 + 
                         MOB_DEPOSITS + 
                         UnsecuredLoan_Month_to_Maturity + 
                         DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3+
                         DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2, 
                       family = binomial(logit), data = NAReplace_train)

summary(Original_Model4)
v2024 = vif(Original_Model4)

write.csv(v2024,"trainmodel4_vif.csv")


df21 = subset(df20,select = -woe.AutoLoanOrgBalanceP12Months.binned)
dim(df21) # 76

# Iteration 15 :

# prints recorded time
sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list15 = colnames(subset(df21,select = - AL_TargetFlag))
stepwise_15 <- My.stepwise.glm(Y = "AL_TargetFlag", variable_list15, data = df21, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()


log_reg15 = glm(formula = AL_TargetFlag ~ woe.NumberInquiriesP6Months.binned + 
                  woe.Days.Since.Last.Login.binned + woe.AutoOpenTradeBalance.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_DEPOSITS.binned + 
                  woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.UnsecuredLoan_Month_to_Maturity.binned + 
                  woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned + woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + woe.RealEstate_Month_to_Maturity.binned + 
                  woe.IRA_StaticpoolFlag.binned + woe.PRODUCT_SAVINGS_Q1.binned, 
                family = binomial(logit), data = df21)
a15 = Anova(log_reg15,type="II",test="Wald")
v15 = vif(log_reg15)
write.csv(a15,"FINAL ANOVA.csv")
write.csv(v15,"Final VIF.csv")
summary(log_reg15)
blr_gains_table(log_reg15,data=df21)
org_mod15 = glm(AL_TargetFlag~NumberInquiriesP6Months+
                  Days.Since.Last.Login+
                  AutoOpenTradeBalance+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MOB_DEPOSITS+
                  DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3+
                  UnsecuredLoan_Month_to_Maturity+
                  DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3+
                  DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3+
                  DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2+
                  RealEstate_Month_to_Maturity+
                  IRA_StaticpoolFlag+
                  PRODUCT_SAVINGS_Q1
                ,data=NAReplace_train,family=binomial(link="logit"))
summary(org_mod15)
o15 = vif(org_mod15)
write.csv(o15,"Final VIF.csv")



##STEP1 FINAL TRAIN MODEL
new = glm(formula = AL_TargetFlag ~ 
            woe.Days.Since.Last.Login.binned + 
            woe.AutoOpenTradeCount.binned + 
            woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
            woe.UnsecuredLoan_Month_to_Maturity.binned + 
            woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned + 
            woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned + 
            woe.MOB_DEPOSITS.binned + 
            woe.HETotalAvailableLOC.binned + 
            woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
            woe.HELOCWorstRatingP12Months.binned + 
            woe.IRA_StaticpoolFlag.binned + 
            woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned 
            #woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
            #woe.TRANSACTION_COUNT_DEPOSITS_Q1.binned
            , family = binomial(logit), data = df20)

blr_gains_table(new ,data=df20)
blr_gains_table(new,test_woe)

a15new = Anova(new,type="II",test="Wald")
a15new
v15new = vif(new)
v15new
summary(new)

write.csv(a15new,"FINAL ANOVAnew.csv")
write.csv(v15new,"Final VIFnew.csv")



#STEP2(to check original varible VIF and Relationship)

new1 <- glm(formula = AL_TargetFlag ~ 
              Days.Since.Last.Login + 
              AutoOpenTradeCount + 
              AVG_MONTH_END_BALANCE_DEPOSITS_Q1 + 
              UnsecuredLoan_Month_to_Maturity + 
              DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3 + 
              DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3 + 
              MOB_DEPOSITS + 
              HETotalAvailableLOC + 
              DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2 + 
              HELOCWorstRatingP12Months + 
              IRA_StaticpoolFlag + 
              DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3 
            #WITHDRAWAL_AMOUNT_DEPOSITS_Q1 + 
            #TRANSACTION_COUNT_DEPOSITS_Q1 
              ,family = binomial(logit), data = NAReplace_train)

summary(new1)
Anova(new1,type = "II",test = "Wald" )
v2023 = vif(new1)
v2023
write.csv(v2023,"trainnew1_vif.csv")

#STEP3 to get test ks
test_target = subset(AL_test,select = c( AL_TargetFlag ,
                                           Days.Since.Last.Login , 
                                           AutoOpenTradeCount , 
                                           AVG_MONTH_END_BALANCE_DEPOSITS_Q1 , 
                                           UnsecuredLoan_Month_to_Maturity , 
                                           DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3 , 
                                           DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3 , 
                                           MOB_DEPOSITS , 
                                           HETotalAvailableLOC , 
                                           DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2 , 
                                           HELOCWorstRatingP12Months , 
                                           IRA_StaticpoolFlag , 
                                           DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3 ))
                                         #WITHDRAWAL_AMOUNT_DEPOSITS_Q1 , 
                                         #TRANSACTION_COUNT_DEPOSITS_Q1 ))

NAReplace_Test = replace(test_target,is.na(test_target),-9999999)

TEST_model <- woe.binning(NAReplace_Test,'AL_TargetFlag',NAReplace_Test)
test_woe <- woe.binning.deploy(NAReplace_Test,TEST_model,add.woe.or.dum.var = "woe")

blr_gains_table(new,test_woe)


















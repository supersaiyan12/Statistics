/******* Temp Master Data ********/
Drop table if exists ##TempTableA
SELECT  * 
into ##TempTableA
FROM Analytics.dbo.REVISED_MASTER_DATA_Sep2024

Drop table if exists ##TempTableB
use [Analytics]
select COLUMN_NAME 
into ##TempTableB
from INFORMATION_SCHEMA.COLUMNS
where TABLE_NAME = 'REVISED_MASTER_DATA_Sep2024'
and (COLUMN_NAME like  '%auto%' or  COLUMN_NAME like '%Vehicle%')
order by 1

--select top 3 * from ##TempTableA

-- Step 1: Construct the dynamic SQL to drop columns
DECLARE @sql NVARCHAR(MAX) = '';
DECLARE @columnName NVARCHAR(255);

-- Create the DROP COLUMN statements
DECLARE drop_cursor CURSOR FOR
SELECT COLUMN_NAME
FROM ##TempTableB;

OPEN drop_cursor;
FETCH NEXT FROM drop_cursor INTO @columnName;

WHILE @@FETCH_STATUS = 0
BEGIN
    -- Append each DROP COLUMN statement to the @sql variable
    SET @sql = @sql + 'ALTER TABLE ##TempTableA DROP COLUMN ' + QUOTENAME(@columnName) + '; ';
    
    FETCH NEXT FROM drop_cursor INTO @columnName;
END

CLOSE drop_cursor;
DEALLOCATE drop_cursor;

-- Step 2: Execute the dynamic SQL
EXEC sp_executesql @sql;

-- Optional: Check the remaining columns in #TempTableA
SELECT top 2 * FROM ##TempTableA;


/*** Defining dates  ****/

Drop table if exists #processdate2
	Select Process_date,max(ProcessDate) Max_ProcessDate
	into #processdate2
	from (select ProcessDate,left(ProcessDate,6) Process_date from arcusym000.dbo.SAVINGS ) A
	 where Process_Date>202309 and Process_date<=202409
--	and Process_Date<=202112
	group by Process_date


--=====Auto Loan Member at staticpool ====
--========================================
DECLARE @staticpooldate DATE;

set @staticpooldate = '2023-09-30'

 drop table if exists #temp3
select distinct a.PARENTACCOUNT,a.ID, concat(a.PARENTACCOUNT,a.id) UNID,a.BALANCE,c.SSN,
a.OPENDATE
--1 as Grenstate_Auto_Loan
--,datefromparts(left(a.ProcessDate,4),right(left(a.ProcessDate,6),2),right(a.ProcessDate,2)) date 
into #temp3
from ARCUSYM000.dbo.loan a
left join [ARCUSYM000].[arcu].ARCULoanCategory b	
on b.loantype=a.TYPE
left join
arcusym000.dbo.name c
on a.PARENTACCOUNT=c.PARENTACCOUNT
--and a.ID=c.PARENTID
where 
 --b.ShareCategory1 = 'Consumer' and
B.LOANCATEGORY1 = 'CONSUMER' AND
B.LOANCATEGORY2='VEHICLE'
AND A.PROCESSDATE =  CONVERT(INT, FORMAT(@staticpooldate, 'yyyyMMdd'))
AND  LOANCATEGORY4 NOT IN ('WRITEOFF','WORKOUT/TDR','BUSINESS VEHICLE')
AND A.OPENDATE IS NOT NULL 
AND A.CLOSEDATE IS NULL 
AND A.CHARGEOFFDATE IS NULL
--AND  LOANCATEGORY3 IN ('INDIRECT')

--select distinct PARENTACCOUNT,id from #temp3

 ---Open account after 1 year 


drop table if exists #temp5
select distinct a.PARENTACCOUNT,a.ID, concat(a.PARENTACCOUNT,a.id) UNID,c.SSN,
a.OPENDATE
into #temp5
from ARCUSYM000.dbo.loan a
left join [ARCUSYM000].[arcu].ARCULoanCategory b	
on b.loantype=a.TYPE
left join
arcusym000.dbo.NAME c
on a.PARENTACCOUNT=c.PARENTACCOUNT
--and a.ID=c.PARENTID
where 
 --b.ShareCategory1 = 'Consumer' and
B.LOANCATEGORY1 = 'CONSUMER' AND
B.LOANCATEGORY2='VEHICLE'
--AND A.PROCESSDATE =  CONVERT(INT, FORMAT(@staticpooldate, 'yyyyMMdd'))
AND  LOANCATEGORY4 NOT IN ('WRITEOFF','WORKOUT/TDR','BUSINESS VEHICLE')
 and a.ProcessDate  in (select Max_ProcessDate from #processdate2)
 and a.PARENTACCOUNT not in (select PARENTACCOUNT from #temp3 )
-- and c.ssn in 
-- ( (select distinct AccountPrimeNameSSN from ARCUSYM000.arcu.ARCUAccountDetailed 
--where ProcessDate = 20240930 and 
--datediff(MONTH,AccountOpenDate,'2023-09-30') >= 6
--and AccountCloseDate is null ))
and OPENDATE between '2023-10-01' and '2024-09-30'
 --and DATEADD(mm,ProcessDate,OPENDATE) mob
and a.OPENDATE is not null 
and a.CLOSEDATE is null 
and a.CHARGEOFFDATE is null

select  count (*) from #temp5

 --Master data copy

-- Drop table if exists #1
--SELECT  * 
--into #1
-- FROM
-- Analytics.dbo.REVISED_MASTER_DATA_Sep2024  --Analytics..REVISED_MASTER_DATA

--  select top 10 * from Analytics.dbo.REVISED_MASTER_DATA_Sep2024
 
--alter table #1 drop column
--        [TRANSACTION_COUNT_CHECKING_Q1]
--      ,[DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2]
--      ,[DFT_TRANSACTION_COUNT_CHECKING_Q1_Q3]
--      ,[TRANSACTION_AMOUNT_CHECKING_Q1]
--      ,[DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2]
--      ,[DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3]
--      ,[AVG_TRANSACTION_CHECKING_Q1]
--      ,[DFT_AVG_TRANSACTION_CHECKING_Q1_Q2]
--      ,[DFT_AVG_TRANSACTION_CHECKING_Q1_Q3]
--      ,[DEPOSITED_AMOUNT_CHECKING_Q1]
--      ,[DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2]
--      ,[DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3]
--      ,[DEPOSITED_COUNT_CHECKING_Q1]
--      ,[DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2]
--      ,[DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3]
--      ,[WITHDRAWAL_AMOUNT_CHECKING_Q1]
--      ,[DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2]
--      ,[DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q3]
--      ,[WITHDRAWAL_COUNT_CHECKING_Q1]
--      ,[DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2]
--      ,[DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q3]
--      ,[SUM_INTEREST_CHECKING_Q1]
--      ,[DFT_SUM_INTEREST_CHECKING_Q1_Q2]
--      ,[DFT_SUM_INTEREST_CHECKING_Q1_Q3],[CHECKING_Q1Flag],[CHECKING_StaticpoolFlag],[PRODUCT_CHECKING_SP]
--      ,[PRODUCT_CHECKING_Q1]
--      ,[DFT_PRODUCT_CHECKING_Q1_Q2]
--      ,[DFT_PRODUCT_CHECKING_Q1_Q3]
--      --,[TYPE_CHECKING_SP]
--      --,[TYPE_CHECKING_Q1]
--      --,[DFT_TYPE_CHECKING_Q1_Q2]
--      --,[DFT_TYPE_CHECKING_Q1_Q3]
--      ,[MOB_CHECKING]
--      ,[AVG_MONTH_END_BALANCE_CHECKING_Q1]
--      ,[DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2]
--      ,[DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3]
--      ,[SUM_LASTDIVAMOUNT_CHECKING_Q1]
--      ,[DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2]
--      ,[DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q3]
--      ,[AVG_CHARGEOFFAMOUNT_CHECKING_SP]
--      ,[AVG_CHARGEOFFAMOUNT_CHECKING_Q1]
--      ,[DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q2]
--      ,[DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q3]

--Select distinct ssn that not in #temp3
Drop table if exists #final
SELECT SSN003 
INTO #final 
FROM ##TempTableA
EXCEPT 
SELECT SSN 
FROM #temp3


--select count(SSN003) from #1

--Flag creation 

drop table if exists #Auto_NBP
SELECT  a.*
,CASE WHEN A.SSN003 = B.SSN THEN 1 ELSE 0 end  autoloan_Targetflag
into #Auto_NBP
FROM ##TempTableA a 
LEFT JOIN #temp5 b
on A.SSN003 = B.SSN 
where 
A.SSN003 IN (SELECT * FROM #final)
and 
A.SSN003 in (select distinct AccountPrimeNameSSN from ARCUSYM000.arcu.ARCUAccountDetailed 
where ProcessDate = 20230930 and datediff(MONTH,AccountOpenDate,'2023-09-30') >= 6 )



Drop table if exists Analytics.dbo.Autoloan_nbp
select *
into Analytics.dbo.Autoloan_nbp
from #Auto_NBP

select autoloan_Targetflag,count(*) from #Auto_NBP group by autoloan_Targetflag
--where autoloan_Targetflag=1




-- /********** -- #1 loan table at Staticpool 2023-08-31 (2021-12-31) -- **********/
--		--  All Loan TABLE  at StaticPool

--    DROP TABLE  IF EXISTS #AUTOLOAN_SP -- STATIC POOL
--    SELECT A.PARENTACCOUNT,A.ID,A.OPENDATE,A.CLOSEDATE,A.CHARGEOFFDATE,A.PROCESSDATE,B.LOANCATEGORY2,B.LOANCATEGORY3,B.LOANCATEGORY4
--    INTO #AUTOLOAN_SP
--    FROM ARCUSYM000.DBO.LOAN A
--    LEFT JOIN [ARCUSYM000].[ARCU].[ARCULOANCATEGORY] B
--    ON B.LOANTYPE=A.TYPE
--    WHERE 1 = 1
--	AND A.PROCESSDATE = 20230831 
--	AND (A.CLOSEDATE IS NULL OR  A.CLOSEDATE >  '2023-08-31' )-- CAHNGE MADE OF OPEN < STATICPOOL
--	AND (A.OPENDATE IS NOT NULL OR A.OPENDATE < '2023-08-31' )-- CAHNGE MADE OF OPEN < STATICPOOL
--	AND (A.CHARGEOFFDATE > 2023-08-31 OR A.CHARGEOFFDATE IS NULL) --165953

--	--select count(1) FROM #Autoloan_SP

--/********** -- #2 LOAN AT STATICPOOL (Vehicle) -- **********/
		
--	drop table if exists #AL_SP -- distinct parent account from static pool
--	SELECT Distinct PARENTACCOUNT
--	into #AL_SP
--	FROM #Autoloan_SP 
--	WHERE LOANCATEGORY2 ='VEHICLE' 
--	AND LOANCATEGORY3 NOT IN ('INDIRECT') 
--	AND LOANCATEGORY4 NOT IN ('WRITEOFF','WORKOUT/TDR') --21208 

--	--select * FROM #AL_SP

--/********** -- #3 Loan table AFTER StaticPool -- **********/

--    DROP TABLE IF EXISTS #loan_aftr_SP -- one year after static pool
--    select a.PARENTACCOUNT,a.ID,a.OPENDATE,a.CLOSEDATE,a.ProcessDate,b.LoanCategory2,b.LoanCategory3,b.LoanCategory4
--    into #loan_aftr_SP
--    from ARCUSYM000.dbo.LOAN a
--    left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
--    on b.loantype=a.TYPE
--    where a.ProcessDate BETWEEN 20230930 and 20240831
--	and a.CLOSEDATE is null and a.OPENDATE is not null
--	and (a.CHARGEOFFDATE > 2023-08-31 or a.CHARGEOFFDATE is NULL) -- 14799393

 
--/********** -- #4 Loan table without MEMBER Having Vehicle Loan AT StaticPool -- **********/

--    DROP TABLE IF EXISTS #loan_without_SP
--    SELECT *
--    INTO #loan_without_SP
--    FROM
--    (
--    SELECT A.*, CASE WHEN A.PARENTACCOUNT = B.PARENTACCOUNT THEN 0 ELSE 1 END [NOALINSP]
--    FROM #loan_aftr_SP A
--    LEFT JOIN #AL_SP B
--    ON A.PARENTACCOUNT = B.PARENTACCOUNT
--    ) P
--    WHERE [NOALINSP] = 1  --5592976 

--	--select * from #loan_without_SP 

--/********** -- #5 PARENTACCOUNT WHO ARE HAVING Vehicle LOAN AFTER STATICPOOL -- **********/
	
--	DROP TABLE IF EXISTS #AUTOLOAN_TARGET
--	SELECT 
--	DISTINCT PARENTACCOUNT
--	INTO #AUTOLOAN_TARGET
--	FROM #LOAN_WITHOUT_SP 
--	WHERE LOANCATEGORY2 ='VEHICLE' 
--	AND LOANCATEGORY3 NOT IN ('INDIRECT') 
--	AND LOANCATEGORY4 NOT IN ('WRITEOFF','WORKOUT/TDR') --40026

--/********** -- #6  MAPPING THIS PARENTACCOUNT WITH SSN -- **********/

--    DROP TABLE IF EXISTS #AL_target_SSN
--    SELECT distinct SSN
--    into #AL_target_SSN
--    from
--    (
--    SELECT  SSN,B.PARENTACCOUNT,CASE WHEN A.PARENTACCOUNT = B.PARENTACCOUNT then 1 else 0 end [match] 
--    FROM ARCUSYM000.dbo.NAME A
--    LEFT JOIN #Autoloan_target B
--    ON A.PARENTACCOUNT = B.PARENTACCOUNT
--    ) W
--    where [match] = 1 --40770


--/********** -- #7  MAPPING PARENTACCOUNT OF #AL_SP WITH SSN (SSN HAVING AUTO LOAN AT STATIC POOL) -- **********/

--		DROP TABLE IF EXISTS #AL_SP_SSN
--		SELECT DISTINCT E.SSN 
--		INTO #AL_SP_SSN
--		FROM
--		(
--		SELECT A.*,CASE WHEN A.PARENTACCOUNT = B.PARENTACCOUNT THEN 1 ELSE 0 END [ALInSP]
--		FROM ARCUSYM000..NAME A
--		LEFT JOIN #AL_SP B
--		ON A.PARENTACCOUNT = B.PARENTACCOUNT
--		) E
--		WHERE [ALInSP] = 1  -- 105495

--/********** -- #8  EXCLUDING ALL THOSE SSN HAVING AUTO LOAN IN SP -- **********/

--DROP TABLE IF EXISTS #temp_AL_exclusion_SP 
--SELECT F.*
--INTO #temp_AL_exclusion_SP
--FROM
--(
--SELECT A.*, CASE WHEN A.SSN003 = B.SSN THEN 0 ELSE 1 END [NoALInSP]
--FROM Analytics.dbo.REVISED_MASTER_DATA_AUG2023 A--#AutoLoan_NBP A
--LEFT JOIN #AL_SP_SSN B
--ON A.SSN003 = B.SSN
--) F
--WHERE [NoALInSP] = 1 -- 251835


--/********** -- #9 DROPPING [NoALInSP] (we dont need it in final Dataset) -- **********/

-- ALTER TABLE #temp_AL_exclusion_SP DROP COLUMN [NoALInSP]


--/********** -- #10 Creating Target Flag -- **********/

--DROP TABLE IF EXISTS #Auto_TargetFlag
--SELECT A.*,CASE WHEN A.SSN003 = B.SSN THEN 1 ELSE 0 END [AL_TargetFlag]
--INTO #Auto_TargetFlag
--FROM #temp_AL_exclusion_SP A
--LEFT JOIN #AL_target_SSN B
--ON A.SSN003 = B.SSN         -- 251835

----select * from #Auto_TargetFlag
--/*********** #11 Dropping Members who have MOB less than 6 months (Analytics.dbo.NBP_AutoLoan_202209) *******************/

--drop table if exists Analytics.dbo.NBP_AutoLoan_202212
--select *
--into Analytics.dbo.NBP_AutoLoan_202212
--from #Auto_TargetFlag 
--where SSN003 in (select distinct AccountPrimeNameSSN from ARCUSYM000.arcu.ARCUAccountDetailed where ProcessDate = 20211231 and datediff(MONTH,AccountOpenDate,'2021-12-31') >= 6 ) --264701



	  -- drop table if exists #1
		select distinct  SSN,AccountNumber PARENTACCOUNT  
		into #1 
		from AE_EDW..D_Member
		where SSN is not null	

		go

		-- drop table if exists #multi_SSN
		select PARENTACCOUNT,count(distinct SSN) Counts 
		into #multi_SSN
		from #1
		group by PARENTACCOUNT
		having count(distinct SSN)>1

		go

		select * 
		into #11
		from #1
		where ssn not in (select PARENTACCOUNT from #multi_SSN)

		go
		--	drop table if exists #2
		select distinct  SSN,PARENTACCOUNT
		 into #2
		 from ARCUSYM000..NAME
		 where PARENTACCOUNT not in (select PARENTACCOUNT from #11)
		 and SSN is not null
			
			go

			select PARENTACCOUNT,count(distinct SSN) Counts 
			into #3
			from #2
			group by PARENTACCOUNT
		having count(distinct SSN)>1

			go

			select * 
			into #22
			from #2
			where PARENTACCOUNT not in (select PARENTACCOUNT from #3 )
			-- drop table if exists analytics..R2_CC_Member
			--select * 
			--into analytics..R2_CC_Member
			--from
			--(select * from #NAME3
			--union
			--select * from #member_ssn ) A

			go
			-- drop table if exists #NAME
			select * 
			into #NAME
			from
			(select * from #11
			union
			select * from #22 ) A
	 
	 go
	 -- Drop table if exists #real_estate
	 select * 
		into #real_estate
		from 
	 (select distinct  a.PARENTACCOUNT,id,a.type,OPEN_DATE,CLOSE_DATE,b.loancategory1,SSN,LoanType
		,case when OPEN_DATE >'2018-04-30'  then 1 else 0 end home_equity_loan_Flag
		
		from (select PARENTACCOUNT,id
		,TYPE
		,cast (OPENDATE as date) Open_date
		,cast (CLOSEDATE as date) Close_date from [ARCUSYM000]..loan) as a
	 left join ARCUSYM000.arcu.ARCULoanCategory b
	 on a.type=b.LoanType
	 left join #NAME C
		on a.PARENTACCOUNT=c.PARENTACCOUNT
		) AA
		where LoanType in (1023,1024,1025,1026,1028,100,101,102,150,151,152,501,1020,1030)
		--LoanType in (100,101,102,150,151,152,501,1020,1030) 

		go
		-- drop table if exists Analytics..Home_equity_loan_april18
		select a.*
		,case when home_equity_loan_Flag is null or home_equity_loan_Flag=0 then 0 else 1 end Home_Equity_loan_Flag
	into Analytics..Home_equity_loan_april18
	from
	 Analytics..Master_table_April2018 a
	 left join #real_estate b
	 on a.ssn=b.SSN
	 where (Staticpool_real_estate2_loan_flag=0 or Staticpool_real_estate2_loan_flag is null) 
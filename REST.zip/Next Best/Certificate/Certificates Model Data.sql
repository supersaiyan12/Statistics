  -- drop table if exists #D_Member
		select distinct  SSN,AccountNumber PARENTACCOUNT  
		into #D_Member 
		from AE_EDW..D_Member
		where SSN is not null	

		go

		-- drop table if exists #multi_SSN_D_Member
		select PARENTACCOUNT,count(distinct SSN) Counts 
		into #multi_SSN_D_Member
		from #D_Member
		group by PARENTACCOUNT
		having count(distinct SSN)>1

		go
		-- drop table if exists #Distinct_SSN_only
		select * 
		into #Distinct_SSN_only
		from #D_Member
		where ssn not in (select PARENTACCOUNT from #multi_SSN_D_Member)

		go
		--	drop table if exists #2
		select distinct  SSN,PARENTACCOUNT
		 into #Distinct_SSN1
		 from ARCUSYM000..NAME
		 where PARENTACCOUNT not in (select PARENTACCOUNT from #Distinct_SSN_only)
		 and SSN is not null
			
			go
			-- drop table #Distinct_SSN11
			select PARENTACCOUNT,count(distinct SSN) Counts 
			into #Distinct_SSN11
			from #Distinct_SSN1
			group by PARENTACCOUNT
		having count(distinct SSN)>1

			go
			-- drop table #Distinct_SSN1_only
			select * 
			into #Distinct_SSN1_only
			from #Distinct_SSN1
			where PARENTACCOUNT not in (select PARENTACCOUNT from #Distinct_SSN11 )
			-- drop table if exists analytics..R2_CC_Member
			--select * 
			--into analytics..R2_CC_Member
			--from
			--(select * from #NAME3
			--union
			--select * from #member_ssn ) A

			go
			-- drop table if exists #NAME
			select * 
			into #NAME
			from
			(select * from #Distinct_SSN_only
			union
			select * from #Distinct_SSN1_only ) A

			


			go



		go
		-- drop table if exists Analytics..master_table_data
		-- drop table if exists  Analytics..Certificate_loan_model_data
		
		select *,case when Certificates_ACCT_Flag is null or Certificates_ACCT_Flag=0 then 0 else 1 end Final_Certificates_flag
		into  Analytics..Certificate_loan_model_data
		from 
		Analytics..Master_table_data_V2
		where (Staticpool_Certificates_flag=0 or Staticpool_Certificates_flag is null)
		and MOB_Savings is not null and SSN!='000000000' and ssn in (select ssn from #NAME)


		


		
		

	


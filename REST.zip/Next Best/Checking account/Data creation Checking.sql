
				 -- drop table if exists #Temp_1
		select distinct  SSN,AccountNumber PARENTACCOUNT  
		into #Temp_1 
		from AE_EDW..D_Member
		where SSN is not null	

		

		-- drop table if exists #Temp_multi_SSN
		select PARENTACCOUNT,count(distinct SSN) Counts 
		into #Temp_multi_SSN
		from #Temp_1
		group by PARENTACCOUNT
		having count(distinct SSN)>1

		
		--	drop table if exists #Temp_11
		select * 
		into #Temp_11
		from #Temp_1
		where PARENTACCOUNT not in (select PARENTACCOUNT from #Temp_multi_SSN)

		
		
		--	drop table if exists #Temp_2
		select distinct SSN,PARENTACCOUNT 
		into #Temp_2
		from
		(select distinct  SSN,PARENTACCOUNT
		 
		 from ARCUSYM000..NAME
		 where PARENTACCOUNT not in (select PARENTACCOUNT from #Temp_11) 
		 and SSN is not null) a
		 where 
		  SSN not in (select SSN from #Temp_11)
			
			

			-- drop table if exists #temp_3
			select distinct max(ProcessDate) Max_processdate,PARENTACCOUNT,SSN 
			into #Temp_333
			from ARCUSYM000..name
			where PARENTACCOUNT in 
			 ( select PARENTACCOUNT from (select PARENTACCOUNT,count(distinct SSN) Counts 
			--into #Temp_3
			from #Temp_2
			group by PARENTACCOUNT
		having count(distinct SSN)>1 ) a ) and ORDINAL=0
		group by PARENTACCOUNT,SSN
		order by PARENTACCOUNT,SSN

		select max(Max_processdate) Max_processdate,PARENTACCOUNT 
		into #temp_33
		from #Temp_333
		group by PARENTACCOUNT
		order by PARENTACCOUNT

		select a.PARENTACCOUNT,a.SSN 
		into #Temp_3333
		from #Temp_333 a
		inner join #temp_33 b
		on a.Max_processdate=b.Max_processdate
		and a.PARENTACCOUNT=b.PARENTACCOUNT
		-- drop table if exists #Temp_3
		select * 
		into #Temp_3
		from #Temp_3333
		where ssn not in (select ssn from 
		(select SSN,count(distinct PARENTACCOUNT) counts from #Temp_3333
		group by SSN
		having count(distinct PARENTACCOUNT) >1 ) sa )

			

			-- drop table if exists analytics..R2_CC_Member
			--select * 
			--into analytics..R2_CC_Member
			--from
			--(select * from #NAME3
			--union
			--select * from #member_ssn ) A

			
			-- drop table if exists #NAME
			select * 
			into #NAME
			from
			(select * from #Temp_11
			union
			select * from #Temp_3 ) A

			



		go
		
		-- drop table if exists  Analytics..Checking_loan_model_data_april2018
		
		select *,case when Checking_ACCT_Flag is null or Checking_ACCT_Flag=0 then 0 else 1 end Final_Checking_flag
		into  Analytics..Checking_loan_model_data_april2018
		from 
		Analytics..Master_table_data_V2
		where (Staticpool_Checking_flag=0 or Staticpool_Checking_flag is null) and OPEN_DATE_Checkings is null
		and MOB_Savings is not null and SSN!='000000000' and ssn in (select ssn from #NAME)

		


		


		
		

	


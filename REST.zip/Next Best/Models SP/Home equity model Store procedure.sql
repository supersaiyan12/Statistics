			
			
			

					
alter procedure dbo.HomeEquityModel @staticpooldate as date
as 
	begin
	--declare @staticpooldate as date
	--	set @staticpooldate='2019-04-30'
		
		drop table if exists #Static_SSN_account_final
		drop table if exists #Static_SSN_account
		drop table if exists #Account_SSN_Name
		drop table if exists #groupproducttype_Deposits
		drop table if exists ##Saving_transaction
		drop table if exists #saving_account_data
		drop table if exists #Deposit_Product_all_data
		drop table if exists ##Checkings_transaction
		drop table if exists #Checkings_account_data
		drop table if exists #masterdata
		drop table if exists #Checking_model_data
		drop table if exists ##1
		drop table if exists ##targetList_HomeEquity
		drop table if exists #Saving_account_Summary
		drop table if exists #LOAN_TRANSACITON_DATA
		drop table if exists #Vehicle
		drop table if exists #Distinct_SSN_only
		drop table if exists #Distinct_SSN1_only
		drop table if exists #age
		drop table if exists #Distinct_SSN1
		drop table if exists #Distinct_SSN11
		drop table if exists #D_Member
		drop table if exists #multi_SSN_D_Member
		drop table if exists #Loan_product_summary
		drop table if exists ##targetList_DirectVehicle
		drop table if exists #Homeequity_model_data
		drop table if exists ##Home_Equity_loan_v
		drop table if exists ##Deposit_transaction
		
		drop table if exists #NAME
		
	
				select distinct a.PARENTACCOUNT,SSN 
		into #NAME
		from 
		(select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date from ARCUSYM000..NAME) a
		left join ARCUSYM000..SAVINGS b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		and a.ProcessDate=b.ProcessDate
		where a.TYPE=0
		and a.Process_date=@staticpooldate
		and b.SHARECODE=0 
		and b.IRSCODE=0
		and b.TYPE<9000
		and b.type<>10 
		and b.type<>11
		and b.type<>12
		and b.type<>14
		and b.type<>113
		and b.type<>510
		and b.type<>512
		and b.ORIGINALDEPOSITDATE is not null
		and b.CLOSEDATE is null 
		and b.CHARGEOFFDATE is null
			
		-- drop table if exists #Static_SSN_account_final
		select distinct  SSN 
		into #Static_SSN_account_final
		 from
		(select b.SSN,a.PARENTACCOUNT,id
		,cast(OPENDATE as date) OPEN_DATE
		,cast(CLOSEDATE as date) CLOSE_DATE
		,cast(CHARGEOFFDATE as date) CHARGEOFFDATE
		,left(a.ProcessDate,6) ProcessDate_V
		,datefromparts(left(a.ProcessDate ,4),right(left(a.ProcessDate,6),2),right(a.ProcessDate,2)) Process_date
		,case when len(month(closedate))=1 then CONCAT(year(closedate),0,month(closedate)) 
		else CONCAT(year(closedate),month(closedate)) end closed_date_Savings 
		,case when len(month(OpenDate))=1 then CONCAT(year(OpenDate),0,month(OpenDate)) 
		else CONCAT(year(OpenDate),month(OpenDate))end  OPEN_date_INT_Savings
		,case when len(month(CHARGEOFFDATE))=1 then CONCAT(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE)) 
		else CONCAT(year(CHARGEOFFDATE),month(CHARGEOFFDATE))end  Chargeoff_date_Savings
		
		from ARCUSYM000..SAVINGS a
		left join #NAME b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		) aa
		left join 
		(select ssn SSN1,DATEDIFF(month,min_opendate,@staticpooldate) Savings_ACCT_MOB from(
		select ssn,min(Min_Opendate) Min_Opendate from
		(
		select PARENTACCOUNT,id,MIn(cast(OPENDATE as date)) Min_Opendate
		from ARCUSYM000..SAVINGS
		group by PARENTACCOUNT,ID ) F
		left join ARCUSYM000..name G
		on f.PARENTACCOUNT=g.PARENTACCOUNT 
		group by ssn ) A ) AB
		on aa.SSN=ab.SSN1
		where ssn is not null and Savings_ACCT_MOB>=12 and 
		 OPEN_DATE<@staticpooldate  
		 and (CLOSE_DATE is null or CLOSE_DATE>@staticpooldate)
		and (CHARGEOFFDATE is null or CHARGEOFFDATE>@staticpooldate)  
		and Process_date=@staticpooldate 
		
	
		
			--	go
		
			-- drop table if exists #Static_SSN_account
	
			select distinct 
			PARENTACCOUNT AccountNumber,SSN
			into #Static_SSN_account
			from #NAME
		


	-----------------------------------------------------------------------------------------
	-- drop table if exists #Account_SSN_Name
			select distinct  PARENTACCOUNT,ssn 
			Into #Account_SSN_Name
			from #NAME
		
		

		--  Group by product type

		-- 
		
		select *
		,case when ProductName like '%money%'  or ProductName like '% MM %' then 'Money Market'
		when ProductName='Youth Savings' and ApplicationDescription='Certificates' then 'Savings'
		when ProductName='40 Month CD' and ApplicationDescription='Certificates' then 'Checking'
		when ProductName='Certificate' and ApplicationDescription='Certificates' then 'Checking' 
		when ProductName='Public Funds' and ApplicationDescription='Certificates' then 'Certificates' 
		 else ApplicationDescription end Product_Group_wise
		into #groupproducttype_Deposits
		from
		(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName
		,ApplicationDescription,ApplicationTableName
		 from [AE_EDW].[tempods].[S_CRMProductType] a
		left join [AE_EDW].[tempods].[S_CRMApplicationType] b
		on a.ApplicationTypeID=b.ApplicationTypeID
		where ApplicationDescription is not null
		and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a
		
		
		
		--  drop table if exists #savings_account

		
				-- closed_flag will remove the account closed account in any time 
		
		select ssn,UNID,Process_Date,PARENTACCOUNT,id,TYPE,LASTDIVAMOUNT,BALANCE Month_end_balance
		--,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE
		,Closed_flag,Close_date,OPEN_DATE 
		,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    
			when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    
			when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
		   ,DATEDIFF(MONTH,OPEN_DATE,@staticpooldate) MOB
		 into #savings_account 
		from 
		(
		select  
		d.SSN
		,aa.*,c.Closed_flag
		
		,case when aa.OPEN_DATE=aa.CLOSE_DATE then 0 else 1 end Funded_loan_flag
		,E.ProductName,E.Product_Group_wise	
		from 
		(select 
		CONCAT(PARENTACCOUNT,id) UNID
		,Process_Date,PARENTACCOUNT,ID,TYPE
		,cast(OPENDATE as date) OPEN_DATE,cast(CLOSEDATE as date)  CLOSE_DATE,LASTDIVDATE
		,LASTDIVAMOUNT
		--,DIVTYPE,DIVRATE
		--,PENALTYTYPE,PENALTYYTD
		,BALANCE
		--,ORIGINALBALANCE,MINIMUMBALANCE,YEARENDBALANCE,WITHDRAWNFROMOPEN,WITHDRAWALFEETYPE,WITHDRAWALFEECOUNT
		,DESCRIPTION
		--,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE
		--,COURTESYFEELY,COURTESYFEEMTD,ACTIVITYDATE,NSFMONTHTODATE,nsffeemtd,FEECOUNT1,FEECOUNT2,FEECOUNT3,FEECOUNT4
		 from (select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
		 from ARCUSYM000..savings) a 
		 where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) ) aa
		left join 
		(select UNID,max(closed_flag) Closed_flag
		from
		(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when CLOSEDATE is null then 0 else 1 end closed_flag
		
		from 
		(select distinct PARENTACCOUNT,ID,CLOSEDATE 
		from ARCUSYM000..SAVINGS
		 where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
		 ) a )b
		group by UNID
		) c
		on aa.UNID=c.UNID
		left join #Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join #groupproducttype_Deposits E
		on e.ProductCode=aa.TYPE
		where Process_Date between DATEADD(month,-12,@staticpooldate) and @staticpooldate
		and PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) ) ZZ
		where Product_Group_wise='Savings'  and OPEN_DATE<(DATEADD(month,-1,@staticpooldate))
		 and Close_date is null
		 -- removed as in staticpool there wont be closed after staticpool
		 -- or Close_date>@staticpooldate)
		and Funded_loan_flag=1 
		order by UNID,Process_Date,TYPE
		


		

		------------------
		------------------   Transaciton data 

			
			-- 
		

		select PARENTACCOUNT,PARENTID,UNID
			,count(*) Transaction_COUNT
			,avg(BALANCECHANGE) AVG_BALANCECHANGE
			,sum(Deposited_amount) Deposited_amount
			,count(Deposited_amount) Deposited_count
			,sum(withdrawl_amount) withdrawal_amount
			,count(withdrawl_amount) withdrawal_count
			,EFFECTIVEDATE
		into ##Saving_transaction
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      ,[POSTDATE]
      ,[POSTTIME]
     ,BALANCECHANGE
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	 
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
  
  FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
  WHERE PARENTACCOUNT IN (SELECT PARENTACCOUNT FROM #savings_account)
  and PARENTID in (select ID from #savings_account) 
   AND ACTIONCODE!='C') A
	where [EFFECTIVEDATE] between DATEADD(month,-12,@staticpooldate) and @staticpooldate
      group by PARENTACCOUNT,PARENTID,UNID,[EFFECTIVEDATE]
			order by PARENTACCOUNT,PARENTID,UNID,[EFFECTIVEDATE]
	 
	 
		

	----******///// merging the saving and transaciton table 

		-- drop table if exists #saving_account_data
		
		select a.*
		,b.Transaction_COUNT
		,b.Deposited_amount
		,Deposited_count
		,withdrawal_amount
		,withdrawal_count
		,AVG_BALANCECHANGE
		into #Saving_account_data
		 from #savings_account a
		left join ##Saving_transaction b
		on a.UNID=b.UNID
		and Process_Date=b.EFFECTIVEDATE

		

		-- Drop talbe if exists #Saving_account_Summary
		
		select SSN00
			,avg(case when Quarters='Staticpool' then avg_Deposited_count_savings end) avg_Deposited_count_savings_Staticpool
			,sum(case when Quarters='Q1' then sum_Month_end_balance_savings  END)-
			sum(case when Quarters='Q4' then sum_Month_end_balance_savings  END) Diff_Month_end_balance_savings_Q1_Q4
		INTO #Saving_account_Summary
		from
				(
				select ssn as ssn00,Quarters
				,avg(Deposited_count) avg_Deposited_count_savings
				,sum(Month_end_balance) sum_Month_end_balance_savings
				from #Saving_account_data
				where Process_Date=@staticpooldate and SSN is not null
				and OPEN_DATE<@staticpooldate and (Close_date>@staticpooldate or Close_date is null)
				group by ssn,Quarters ) A
		group by ssn00
		order by SSN00

		
		
		-------------------------------------------------------------------------------------------------------------------
		------------------------------------------------------------------------------------------------------------------

		-------------------------------*************Checking Account ***************-----------------------------------
		              
		
		--  drop table if exists #Checkings_account

				-- closed_flag will remove the account closed account in any time 
		
		select ssn,UNID,Process_Date,PARENTACCOUNT,id,TYPE,LASTDIVAMOUNT,BALANCE Month_end_balance
		,Closed_flag,Close_date,OPEN_DATE,FEECOUNT1
		
		,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    
			when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    
			when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
		   ,DATEDIFF(MONTH,OPEN_DATE,@staticpooldate) MOB
		 into #Checkings_account 
		from 
		(
		select  
		d.SSN
		,aa.*,c.Closed_flag
		,case when aa.OPEN_DATE=aa.CLOSE_DATE then 0 else 1 end Funded_loan_flag
		,E.ProductName,E.Product_Group_wise		
		from 
		(select 
		CONCAT(PARENTACCOUNT,id) UNID
		,PARENTACCOUNT,ID,TYPE
		,Process_Date,Open_date,Close_date
		,LASTDIVDATE
		,LASTDIVAMOUNT,DIVTYPE,DIVRATE
		,PENALTYTYPE,PENALTYYTD
		,BALANCE,ORIGINALBALANCE,MINIMUMBALANCE,YEARENDBALANCE,FEECOUNT1
		
		,DESCRIPTION
		 from (select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
		 ,cast(OPENDATE as date) Open_date ,cast(CLOSEDATE as date) Close_date
		 from ARCUSYM000..savings) a 
		  where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) ) aa
		left join 
		(select UNID,max(closed_flag) Closed_flag
		from
		(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when closedate is null then 0 else 1 end closed_flag
		
		from 
		(select distinct PARENTACCOUNT,ID,CLOSEDATE 
		from ARCUSYM000..SAVINGS
		 where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
		 ) a )b
		group by UNID
		) c
		on aa.UNID=c.UNID
		left join #Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join  #groupproducttype_Deposits E
		on e.ProductCode=aa.TYPE
		where Process_Date between DATEADD(month,-12,@staticpooldate) and @staticpooldate
		
		and PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) ) ZZ
		where Product_Group_wise='checking'  and OPEN_DATE<@staticpooldate and (Close_date>@staticpooldate or Close_date is null)
		and Funded_loan_flag=1 
		order by UNID,Process_Date,TYPE

		

		------------------
		------------------   Transaciton data 

			
			-- drop table if exists ##Checkings_transaction
		

		select PARENTACCOUNT,PARENTID,UNID
			,count(*) Transaction_COUNT
			,sum(BALANCECHANGE) Transaction_amount
			,AVG(BALANCECHANGE) AVG_BALANCECHANGE
			,sum(Deposited_amount) Deposited_amount
			,count(Deposited_amount) Deposited_count
			,sum(withdrawl_amount) withdrawal_amount
			,count(withdrawl_amount) withdrawal_count
			,sum(INTEREST) Sum_INTEREST
			,[EFFECTIVEDATE]
		into ##Checkings_transaction
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      
      ,[DESCRIPTION]
      ,[ACTIONCODE]
      ,[SOURCECODE]
      ,[BALANCECHANGE]
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	  
      ,[INTEREST]
      
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
  
  FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
  WHERE PARENTACCOUNT IN (SELECT PARENTACCOUNT FROM #Checkings_account)
  and PARENTID in (select ID from #Checkings_account) 
   AND ACTIONCODE!='C') A
	where EFFECTIVEDATE in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate)
			,DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate)
      group by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE
			order by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE
	 
	
		
		
		----
		----******///// merging the saving and transaciton table 

		-- drop table if exists #Checkings_account_data
		
		select a.*
		,b.Transaction_COUNT
		,b.Transaction_amount
		,AVG_BALANCECHANGE
		,b.Deposited_amount
		,Deposited_count
		,withdrawal_amount
		,withdrawal_count
		,sum_interest
		into #Checkings_account_data
		from #Checkings_account a
		left join ##Checkings_transaction b
		on a.UNID=b.UNID
		and a.Process_Date=b.EFFECTIVEDATE

		------------------------------////********Loan Product Summary*******************\\\\\\\\\\--------------------------------------
		-- Droptable if exists #Loan_product_summary
		

		select * 
		into #Loan_product_summary
		from
		(select 
			SSN SSN01
			,count(distinct UNID) Count_Account_Total_loan_ACCT
			,count(distinct TYPE) Total_product_Total_loan_ACCT
			,min(OPENDATE) MIn_opendate_Total_loan_ACCT
			,max(CLOSEDATE) Max_CLOSEDATE_Total_loan_ACCT
			,Max(MOB) MAX_MOB__Total_loan_ACCT
			,max(Month_to_Maturity) Max_Month_to_Maturity_Total_loan_ACCT
			,sum(PAYMENTFREQUENCY) SUM_PAYMENTFREQUENCY_Total_loan_ACCT
			,sum(PAYMENT) SUM_PAYMENT_Total_loan_ACCT
			,sum(PARTIALPAYMENT) SUM_PARTIALPAYMENT_Total_loan_ACCT
			,sum(PAYMENTCOUNT) SUM_PAYMENTCOUNT_Total_loan_ACCT
			,max(DUEDAY1) Max_DUEDAY1_Total_loan_ACCT
			,Sum(ORIGINALBALANCE) SUM_ORIGINALBALANCE_Total_loan_ACCT
			,sum(CREDITLIMIT) SUM_CreditLimit_Total_loan_ACCT
			,max(CREDITSCORE) Max_CreditScore_Total_loan_ACCT
			,min(CREDITSCORE) MIN_CREDITSCORE_Total_loan_ACCT
			,sum(ADVANCEAMOUNT) SUM_ADVANCEAMOUNT_Total_loan_ACCT
			,max(CRPMTCURRENT) Max_Delinquency
			from
			(
			select [ProcessDate],left(ProcessDate,6) ProcessDate_V,Process_Date,Open_date,Close_date
			,d.SSN
			,[PARENTACCOUNT]
			,[ID]
			,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
			,case when len(month(a.closedate))=1 then CONCAT(year(a.closedate),0,month(a.closedate))
			else CONCAT(year(a.closedate),month(a.closedate)) end  Closed_date_INT
			,case when len(month(a.opendate))=1 then CONCAT(year(a.opendate),0,month(a.opendate))
			else CONCAT(year(a.opendate),month(a.opendate)) end  OPEN_date_INT_INT
			,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
			,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
			,[TYPE]
			,[LASTFMDATE]
			,[LASTTRANDATE]
			,[ORIGINALDATE]
			,a.[OPENDATE]
			,a.[CLOSEDATE]
			,[LOANCODE]
			,[APPROVALCODE]
			,[APPROVALDATE]
			,[PAYMENTFREQUENCY]
			,[PARTIALPAYMENT]
			,[PAYMENT]
			,[PAYMENTCOUNT]
			,[DUEDAY1]
			,[INTERESTRATE]
			,[ORIGINALBALANCE]
			,[CREDITLIMIT]
			,[DESCRIPTION]
			,[NSFMONTHTODATE]
			,[MATURITYDATE]
			,[APR]
			,[CREDITSCORE]
			,[ADVANCEAMOUNT],CRPMTCURRENT
			,b.LoanCategory1
			,b.LoanTypeDescription
			from	
					(select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2)
					,right(ProcessDate,2)) Process_Date,cast(OPENDATE as date) Open_date,cast(CLOSEDATE as date) Close_date
					,cast(MATURITYDATE as date) as MATURITY_DATE from ARCUSYM000..LOAN) a
			left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
		on b.loantype=a.TYPE
		left join  #Static_SSN_account d
		on a.PARENTACCOUNT=d.AccountNumber
		
			where  ORIGINALDATE is not null and a.OpenDate is not null and a.Open_date < @staticpooldate and
		(a.CLOSEDATE is null or a.Close_date>@staticpooldate)   
			and  Process_Date =@staticpooldate 
		and  PARENTACCOUNT in (select AccountNumber from #Static_SSN_account )
		) AA
		where  OPEN_DATE<@staticpooldate and (Close_date is null or Close_date>@staticpooldate) and ORIGINALDATE>= Open_date 
		group by SSN
		) aa

		

		----------------------------------------------------------------------------------------------------------
		------------------------//////********** Deposit table summary************\\\\\\\\---------------------
		
		

		select ssn,UNID,ProcessDate,PARENTACCOUNT,id,TYPE,OPENDATE,CLOSEDATE,LASTDIVAMOUNT,BALANCE Month_end_balance
		,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE,Closed_flag,Close_date,OPEN_DATE ,left(ProcessDate,6) ProcessDate_v 
		,Process_Date
		   ,DATEDIFF(MONTH,OPEN_DATE,@staticpooldate) MOB
		 into #Deposit_account_data 
		from 
				(
				select  
				d.SSN
				,aa.*,c.Closed_flag
		
				,case when aa.closedate is null then '' 
				when len(month(aa.closedate))=1 then CONCAT(year(aa.closedate),0,month(aa.closedate))
				else CONCAT(year(aa.closedate),month(aa.closedate)) end  Closed_date_INT
				,case when len(month(aa.opendate))=1 then CONCAT(year(aa.OPENDATE),0,month(aa.OPENDATE))
				else CONCAT(year(aa.OPENDATE),month(aa.OPENDATE)) end  OPEN_date_INT_INT
				,case when aa.OPENDATE=aa.CLOSEDATE then 0 else 1 end Funded_loan_flag
				,E.ProductName,E.Product_Group_wise	
				from 
						(select 
						CONCAT(PARENTACCOUNT,id) UNID
						,ProcessDate,PARENTACCOUNT,ID,TYPE,OPENDATE,CLOSEDATE
						,cast(OPENDATE as date) OPEN_DATE,cast(CLOSEDATE as date)  CLOSE_DATE,LASTDIVDATE
						,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2)
									,right(ProcessDate,2)) Process_Date
						,LASTDIVAMOUNT,DIVTYPE,DIVRATE
						,PENALTYTYPE,PENALTYYTD
						,BALANCE,ORIGINALBALANCE,MINIMUMBALANCE,YEARENDBALANCE
						,WITHDRAWNFROMOPEN,WITHDRAWALFEETYPE,WITHDRAWALFEECOUNT
						,DESCRIPTION,NSFMONTHTODATE,nsffeemtd,FEECOUNT1,FEECOUNT2,FEECOUNT3,FEECOUNT4
						,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE,ACTIVITYDATE
						,COURTESYFEELY,COURTESYFEEMTD
						 from [ARCUSYM000]..SAVINGS where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) ) aa
						left join 
						(select UNID,max(closed_flag) Closed_flag
						from
						(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when CLOSEDATE is null then 0 else 1 end closed_flag
		
						from 
						(select distinct PARENTACCOUNT,ID,CLOSEDATE 
						from [ARCUSYM000]..SAVINGS
						 where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
						 ) a )b
						group by UNID
						) c
						on aa.UNID=c.UNID
						left join #Static_SSN_account d
						on aa.PARENTACCOUNT=d.AccountNumber
						left join #groupproducttype_Deposits E
						on e.ProductCode=aa.TYPE
						where aa.Process_Date in (@staticpooldate)
						and PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) ) ZZ
						where OPEN_DATE<@staticpooldate and (Close_date is null or Close_date>@staticpooldate)
						and Funded_loan_flag=1 
						order by UNID,ProcessDate,TYPE

		

		

		------------------
		------------------   Transaciton data 

			
			-- drop table if exists ##Deposit_transaction
		

		select PARENTACCOUNT,PARENTID,UNID
			,count(*) Transaction_COUNT
			,sum(BALANCECHANGE) Transaction_amount
			,AVG(BALANCECHANGE) AVG_BALANCECHANGE
			,sum(Deposited_amount) Deposited_amount
			,count(Deposited_amount) Deposited_count
			,sum(withdrawl_amount) withdrawal_amount
			,count(withdrawl_amount) withdrawal_count
			,EFFECTIVEDATE_v1
		into ##Deposit_transaction
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      ,[COMMENTCODE]
      ,[TRANSFERCODE]
      ,[ADJUSTMENTCODE]
      ,[REGECODE]
      ,[REGDCHECKCODE]
      ,[REGDTRANSFERCODE]
      ,[VOIDCODE]
      ,[SUBACTIONCODE]
      ,[SEQUENCENUMBER]
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      ,[POSTDATE]
      ,[POSTTIME]
      ,[USERNUMBER]
      ,[USEROVERRIDE]
      ,[SECURITYLEVELS]
      ,[DESCRIPTION]
      ,[ACTIONCODE]
      ,[SOURCECODE]
      ,[BALANCECHANGE]
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	  
      ,[INTEREST]
      ,[NEWBALANCE]
      ,[FEEAMOUNT]
      ,[ESCROWAMOUNT]
      ,[LASTTRANDATE]
      ,[MATURITYLOANDUEDATE]
      ,[COMMENT]
      ,[BRANCH]
      ,[CONSOLENUMBER]
      ,[BATCHSEQUENCE]
      ,[SALESTAXAMOUNT]
      ,[ACTIVITYDATE]
      ,[BILLEDFEEAMOUNT]
      ,[PROCESSORUSER]
      ,[MEMBERBRANCH]
      ,[PREVAVAILBALANCE]
      ,[SUBSOURCE]
      ,[CONFIRMATIONSEQ]
      ,[MICRACCTNUM]
      ,[MICRRT]
      ,[RECURRINGTRAN]
      ,[FEEEXMTCRTSYAMT]
      ,[ESCROWUNPAIDBALCHG]
      ,[ESCROWAPPLIEDBALCHG]
      ,[UNAPPLIEDPARTIALPMTCHG]
      ,[FEECOUNTBY]
      ,[BALSEGCOUNT]
      ,[LATECHGWAIVEDAMT]
      ,[LATECHGUNPAIDCHGAMT]
      ,[PREVLATECHGDATE]
      ,[PREVLATECHGACCRUED]
      ,[LATECHGFIELDSVALID]
      ,[BALSEGID1]
      ,[BALSEGPMTCHANGEDATE1]
      ,[INTEFFECTDATE]
      ,[BALSEGPREVFIRSTPMTDATE1]
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
  
  FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION] 
  WHERE ACTIONCODE!='C') A
	where EFFECTIVEDATE_v1 = cast(left(convert(varchar,@staticpooldate,112),6) as int)
	      group by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1
			order by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE_v1
	 
	 		
		
		

		----
		----******///// merging the saving and transaciton table 

		-- drop table if exists #Deposit_Product_all_data
		

		select a.*
		,b.Transaction_COUNT
		,b.Transaction_amount
		,AVG_BALANCECHANGE
		,b.Deposited_amount
		,Deposited_count
		,withdrawal_amount
		,withdrawal_count
		into #Deposit_Product_all_data
		 from #Deposit_account_data a
		left join ##Deposit_transaction b
		on a.UNID=b.UNID
		and ProcessDate_v=b.EFFECTIVEDATE_v1

		

		-- Drop talbe if exists #Deposit_summary
		

		select ssn ssn00,count(distinct UNID) Count_Total_Deposit_ACCT, count(distinct type) Count_product_Total_Deposit_ACCT 
		,min(opendate) MIN_OPENDATE_Total_Deposit_ACCT,MAX(CLOSEDATE) Max_closedate_Total_Deposit_ACCT
		,Sum(LASTDIVAMOUNT) SUM_LASTDIVAMOUNT_Total_Deposit_ACCT,AVG(LASTDIVAMOUNT) Avg_LASTDIVAMOUNT_Total_Deposit_ACCT
		,SUM(Month_end_balance) SUM_Month_end_balance_Total_Deposit_ACCT,avg(Month_end_balance) AVG_Month_end_balance_Total_Deposit_ACCT
		,sum(CHARGEOFFAMOUNT) SUM_CHARGEOFFAMOUNT_Total_Deposit_ACCT,avg(CHARGEOFFAMOUNT) AVG_CHARGEOFFAMOUNT_Total_Deposit_ACCT
		,sum(Closed_flag) SUM_Closed_flag_Total_Deposit_ACCT
		,max(MOB) MAX_MOB_Total_Deposit_ACCT,SUM(Transaction_COUNT) SUM_Transaction_COUNT_Total_Deposit_ACCT
		,AVg(Transaction_COUNT) AVG_Transaction_COUNT_Total_Deposit_ACCT
		,SUM(Deposited_amount) SUM_Deposited_amount_Total_Deposit_ACCT,avg(Deposited_amount) AVG_Deposited_amount_Total_Deposit_ACCT
		,sum(Deposited_count) SUM_Deposited_count_Total_Deposit_ACCT,avg(Deposited_count) AVG_Deposited_count_Total_Deposit_ACCT
		,sum(withdrawal_amount) SUM_withdrawal_amount_Total_Deposit_ACCT,avg(withdrawal_amount) AVG_withdrawal_amount_Total_Deposit_ACCT
		,sum(withdrawal_count) SUM_withdrawal_count_Total_Deposit_ACCT,avg(withdrawal_count) AVG_withdrawal_count_Total_Deposit_ACCT
		INTO #Deposit_summary
		from #Deposit_Product_all_data
		where Process_Date=@staticpooldate and SSN is not null
		and OPEN_DATE<@staticpooldate and (Close_date>@staticpooldate or Close_date is null)
		group by ssn
		order by SSN
		
		-------- data Vehicle Loan 

		---- drop table if exists #vehicle

			select 
			*
			into #Vehicles
			from
			(
			select [ProcessDate],left(ProcessDate,6) ProcessDate_V
			,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		    when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		    when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
			,case when Process_Date =@staticpooldate then 1 else 0 end Staticpool_Vehicles_loan_flag
			,d.SSN
			,[PARENTACCOUNT]
			,[ID]
			,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
			,a.Close_date,a.Open_date
			,DATEDIFF(month,a.Open_date,@staticpooldate) MOB
			,DATEDIFF(month,@staticpooldate,[MATURITYDATE]) Month_to_Maturity
			,[TYPE]
			,[ORIGINALDATE]
			,a.[OPENDATE]
			,[CHARGEOFFDATE]
			,a.[CLOSEDATE]
			,[INTERESTRATE]
			,[BALANCE]
			,b.LoanCategory1
			,b.LoanTypeDescription
			from
			(select * ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
			,cast(OPENDATE as date) Open_date ,cast(CLOSEDATE as date) Close_date from [ARCUSYM000]..LOAN) a
			left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
			on b.loantype=a.TYPE
			left join  #Static_SSN_account d
			on a.PARENTACCOUNT=d.AccountNumber
			where  ORIGINALDATE is not null and a.Open_Date is not null and a.Open_date <@staticpooldate and
			(a.CLOSE_DATE is null or a.CLOSE_DATE>@staticpooldate)   
			and  Process_Date between DATEADD(month,-12,@staticpooldate) and @staticpooldate
			and  PARENTACCOUNT in (select AccountNumber from #Static_SSN_account )
			) AA
			where  LoanCategory1='Vehicles'  
			and OPEN_DATE<@staticpooldate and (Close_date is null or Close_date>@staticpooldate) and ORIGINALDATE>= OPEN_DATE

		
				
		
		


			
		------------- /////////////******* adding age in data

	
	

		-- drop table if exists #D_Member
		select distinct  SSN,AccountNumber PARENTACCOUNT,DATEDIFF(YEAR,DateofBirth,GETDATE()) birthdate  
		into #D_Member 
		from AE_EDW..D_Member
		where SSN is not null	

		

		-- drop table if exists #multi_SSN_D_Member
		select PARENTACCOUNT,count(distinct SSN) Counts 
		into #multi_SSN_D_Member
		from #D_Member
		group by PARENTACCOUNT
		having count(distinct SSN)>1

		
		-- drop table if exists #Distinct_SSN_only
		select * 
		into #Distinct_SSN_only
		from #D_Member
		where ssn not in (select PARENTACCOUNT from #multi_SSN_D_Member)

		
		--	drop table if exists #2
		select distinct  SSN,PARENTACCOUNT,DATEDIFF(YEAR,BIRTHDATE,GETDATE()) birthdate  
		 into #Distinct_SSN1
		 from ARCUSYM000..NAME
		 where PARENTACCOUNT not in (select PARENTACCOUNT from #Distinct_SSN_only)
		 and SSN is not null
			
			
			-- drop table #Distinct_SSN11
			select PARENTACCOUNT,count(distinct SSN) Counts 
			into #Distinct_SSN11
			from #Distinct_SSN1
			group by PARENTACCOUNT
		having count(distinct SSN)>1

			
			-- drop table #Distinct_SSN1_only
			select * 
			into #Distinct_SSN1_only
			from #Distinct_SSN1
			where PARENTACCOUNT not in (select PARENTACCOUNT from #Distinct_SSN11 )
			-- drop table if exists analytics..R2_CC_Member
			--select * 
			--into analytics..R2_CC_Member
			--from
			--(select * from #NAME3
			--union
			--select * from #member_ssn ) A

			
			-- drop table if exists #age
			select * 
			into #age
			from
			(select * from #Distinct_SSN_only
			union
			select * from #Distinct_SSN1_only ) A	

			
			
			
		
		
  -- drop table if exists #CC_Members_Static
	  select distinct [Social Security Number] 
	  into #CC_Members_Static
	  from analytics..cardholder 
	  where Active_Flag=1 and [External Status Code]='' and [Internal Status Code] in ('N','')
	  and extract_datepart=left(convert(varchar,@staticpooldate,112),6)

			
			-- drop table if exists #CC_data	
		
		
		select * 
		into #CC_data
		from 
		(
		SELECT  [Durable_Key]
		,case when extract_datepart in (left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-11,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-10,@staticpooldate),112),6)) then 'Q4'
		    when extract_datepart in (left(convert(varchar,dateadd(month,-9,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-8,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-7,@staticpooldate),112),6)) then 'Q3'
		    when extract_datepart in (left(convert(varchar,dateadd(month,-6,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-5,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-4,@staticpooldate),112),6)) then 'Q2'
		    when extract_datepart in (left(convert(varchar,dateadd(month,-3,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-2,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-1,@staticpooldate),112),6)) then 'Q1'
		    when extract_datepart in (left(convert(varchar,@staticpooldate,112),6)) then 'Staticpool' end Quarters
       ,[Social Security Number]
	   ,[Last Statement Average Daily Balance Amount]
	   ,[mob]
	   FROM [Analytics].[dbo].[cardholder]
  where [Social Security Number] in (select [Social Security Number] from #CC_Members_Static)
  and Active_Flag=1 ) a where  quarters is not null and mob>=12

  -- Drop table if exists #Credit_Card_data
		select 
		SSN_CC,[Last.Statement.Average.Daily.Balance.Amount_CC_Q1]
		into #Credit_Card_data
		from 
		(
		select [Social Security Number] SSN_CC
		,SUM(case when Quarters='Q1' then [Last Statement Average Daily Balance Amount] end) [Last.Statement.Average.Daily.Balance.Amount_CC_Q1]
		 from #CC_data
			  group by [Social Security Number] ) AA

			
		
			 
			 
		--------------------------------------------------------------------------------------------------------------------------------------------
										--  Merging the data
		--------------------------------------------------------------------------------------------------------------------------------------------

		
			---------------------------------------------------------------------------------------------------------------------------
				-------------------MERGING ALL LOAN TALBE---------------------------------------------------------------------------

				-- drop table if exists analytics.dbo.Master_table_April2019
				-- drop table #masterdata
				select AA.SSN
				,avg_Deposited_amount_Checkings_Staticpool
				,Max_Month_to_Maturity_Total_loan_ACCT
				,Avg_LASTDIVAMOUNT_Total_Deposit_ACCT
				,Diff_Month_end_balance_savings_Q1_Q4
				,Month_to_Maturity_Vehicles
				,[Last.Statement.Average.Daily.Balance.Amount_CC_Q1]
				,Sum_LASTDIVAMOUNT_Checkings_Q4

				into
				 #masterdata
				
				from 
				(SELECT distinct ssn
				
				 FROM #Static_SSN_account_Final ) AA
				 left join #Deposit_summary TT
				 on aa.SSN=tt.ssn00
			left join #age GG
			on aa.SSN=gg.SSN
			left join #Loan_product_summary LL
			on aa.SSN=ll.SSN01
			left join #Credit_Card_data CCC
			on aa.ssn =ccc.SSN_CC

			-- drop table if exists #Checking
			Left join 
			(

			select aa.SSN SSN20
		
		
				,sum(case when Quarters='Q4' then SUM_LASTDIVAMOUNT_checkings End) Sum_LASTDIVAMOUNT_Checkings_Q4
				,avg(case when Quarters='staticpool' then avg_Deposited_amount_Checkings End) avg_Deposited_amount_Checkings_Staticpool

			from
			(
			select 
			SSN,Quarters
			,sum(FEECOUNT1) sum_FEECOUNT1_checkings
			,sum(LASTDIVAMOUNT) Sum_LASTDIVAMOUNT_Checkings
			,avg(Deposited_amount) Avg_Deposited_amount_checkings
			 from  #Checkings_account_data 
			group by ssn,Quarters ) AA
			left join 
				(		
				select SSN,count(distinct UNID) Total_No_Account_Checkings,count(distinct type) Total_type_account_Checkings
				,min(Open_date) opendate_Checkings,max(CLOSE_DATE) CLOSEDATE_Checkings
				,max(MOB) MOB_Checkings,min(OPEN_DATE) OPEN_DATE_Checkings,max(Close_date) Close_date_Checkings
				from
				#Checkings_account_data
				group by SSN
				) AB
					on aa.SSN=ab.SSN
					group by aa.SSN,ab.Total_No_Account_Checkings,Total_type_account_Checkings
					,opendate_Checkings,Close_date_Checkings,MOB_Checkings,OPEN_DATE_Checkings,Close_date_Checkings
					 ) U
					ON AA.SSN=U.SSN20
					left join #Saving_account_Summary ZZ
					on aa.ssn=zz.ssn00
					left join 
			(
			 select SSN SSN6
			,max(Month_to_Maturity) Month_to_Maturity_Vehicles
			from #Vehicles
			group by SSN
			 ) F
			 ON F.SSN6=AA.SSN
		
			
		
		
			 -- Drop table if exists #Home_Equity_loan_v
		select distinct SSN 
		into ##Home_Equity_loan_v
		from 
		(select distinct a.PARENTACCOUNT,id,a.type,OPEN_DATE,CLOSE_DATE,b.loancategory1,SSN,LoanType
		
		from 
				(select PARENTACCOUNT,id
				,TYPE
				,cast (OPENDATE as date) Open_date
				,cast (CLOSEDATE as date) Close_date from [ARCUSYM000]..loan) as a
	 
			 left join ARCUSYM000.arcu.ARCULoanCategory b
			 on a.type=b.LoanType
			 left join #NAME C
				on a.PARENTACCOUNT=c.PARENTACCOUNT
				where LoanType in (1023,1024,1025,1026,1028,100,101,102,150,151,152,501,1020,1030) and Open_date <= @staticpooldate
				) AA
		

		
				-- drop table if exists ##1
			
			select distinct SSN 
			into ##1
			from 
			(select distinct a.SSN ,b.SSN SSN_B
			 from #masterdata a
			left join  ##Home_Equity_loan_v b
			on a.SSN=b.SSN ) S
			where SSN_B is null
			

		

		
		-- drop table if exists #Creditcard_data
		
		
		select	 SSN		
				,case when Max_Month_to_Maturity_Total_loan_ACCT is null  then -21.8
				when  Max_Month_to_Maturity_Total_loan_ACCT is not null then  98.8
				end Max_Month_to_Maturity_Total_loan_ACCT
				
				,case when avg_Deposited_amount_Checkings_Staticpool is null or avg_Deposited_amount_Checkings_Staticpool <=2174.185 then -46.6 
				when avg_Deposited_amount_Checkings_Staticpool > 2174.185 then 76.6
				 end avg_Deposited_amount_Checkings_Staticpool
				
				,case when Avg_LASTDIVAMOUNT_Total_Deposit_ACCT is null or Avg_LASTDIVAMOUNT_Total_Deposit_ACCT  <= 0 then -48
				when Avg_LASTDIVAMOUNT_Total_Deposit_ACCT <=0.915  then 13.1 
				when Avg_LASTDIVAMOUNT_Total_Deposit_ACCT <=21.061  then 65.4
				when Avg_LASTDIVAMOUNT_Total_Deposit_ACCT <=57.82911  then -48.4
				when Avg_LASTDIVAMOUNT_Total_Deposit_ACCT >57.82911  then -220.8 end Avg_LASTDIVAMOUNT_Total_Deposit_ACCT
				
				,case when Diff_Month_end_balance_savings_Q1_Q4 is null or Diff_Month_end_balance_savings_Q1_Q4 <=-10856.32 then 9.1
				when Diff_Month_end_balance_savings_Q1_Q4 <=-3273.276 then 56.1
				when Diff_Month_end_balance_savings_Q1_Q4 <=-59.252 then 9.1
				when Diff_Month_end_balance_savings_Q1_Q4 <= -5 then -30.9
				when Diff_Month_end_balance_savings_Q1_Q4 <= 417.848 then 33.1
				when Diff_Month_end_balance_savings_Q1_Q4 > 417.848 then 81.8
				end Diff_Month_end_balance_savings_Q1_Q4
				 
				,case when Month_to_Maturity_Vehicles is null  then -23
				when Month_to_Maturity_Vehicles is not null then 92.5
				 end Month_to_Maturity_Vehicles
				
				,case when [Last.Statement.Average.Daily.Balance.Amount_CC_Q1] is null then -13.7
				when [Last.Statement.Average.Daily.Balance.Amount_CC_Q1] is not null then 73.3 end [Last.Statement.Average.Daily.Balance.Amount_CC_Q1]

				,case when Sum_LASTDIVAMOUNT_Checkings_Q4 is null or Sum_LASTDIVAMOUNT_Checkings_Q4 <=0 then -31.5
				when Sum_LASTDIVAMOUNT_Checkings_Q4 <=140.424 then 63.1
				when Sum_LASTDIVAMOUNT_Checkings_Q4 > 140.424 then -36.9 end Sum_LASTDIVAMOUNT_Checkings_Q4
		
		into #Homeequity_model_data
		from 
		#masterdata
		where ssn in (select ssn from ##1)


			select * 
			,NTILE (10) OVER ( order by Ranks) Decile
			into ##targetList_HomeEquity
			from
			(select *
		
			,Row_number() over(order by score desc)  Ranks
			from
			(
				select *
				
						, EXP(-3.9256285+(0.0060259*avg_Deposited_amount_Checkings_Staticpool)
							+(0.0056362*Max_Month_to_Maturity_Total_loan_ACCT)
							+(0.0038116*Avg_LASTDIVAMOUNT_Total_Deposit_ACCT)
							+(0.0041232*Diff_Month_end_balance_savings_Q1_Q4)
							+(0.0028832*Month_to_Maturity_Vehicles)
							+(0.0030938*[Last.Statement.Average.Daily.Balance.Amount_CC_Q1])
							+(0.0014651*Sum_LASTDIVAMOUNT_Checkings_Q4))
				/(1+EXP(-3.9256285+(0.0060259*avg_Deposited_amount_Checkings_Staticpool)
							+(0.0056362*Max_Month_to_Maturity_Total_loan_ACCT)
							+(0.0038116*Avg_LASTDIVAMOUNT_Total_Deposit_ACCT)
							+(0.0041232*Diff_Month_end_balance_savings_Q1_Q4)
							+(0.0028832*Month_to_Maturity_Vehicles)
							+(0.0030938*[Last.Statement.Average.Daily.Balance.Amount_CC_Q1])
							+(0.0014651*Sum_LASTDIVAMOUNT_Checkings_Q4)))   as score
				from #Homeequity_model_data ) a ) B
				order by score desc

			end	
			
			
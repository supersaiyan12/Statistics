USE [Analytics]
GO
/****** Object:  StoredProcedure [dbo].[Checking_Propensity_Target List]    Script Date: 13-Jan-25 6:10:54 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

       --Declaring the STATIC POOL

 ALTER PROCEDURE [dbo].[Checking_Propensity_Target List]
AS 
Begin


/***QUERY WILL NOT SHIFT TO DEADLOCK ***/
SET NOCOUNT ON
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

DECLARE @staticpooldate DATE;
DECLARE @eomDate DATE;

-- Determine the end of the current or previous month
SET @eomDate = CASE 
                   WHEN EOMONTH(GETDATE()) = CAST(GETDATE() AS DATE) 
                   THEN EOMONTH(GETDATE()) 
                   ELSE EOMONTH(DATEADD(MONTH, -1, GETDATE())) 
               END;

			   PRINT @eomDate;

-- Get the maximum ProcessDate corresponding to the determined end of month
SET @staticpooldate = (
    SELECT MAX(DATEFROMPARTS(LEFT(ProcessDate, 4), 
                              RIGHT(LEFT(ProcessDate, 6), 2), 
                              RIGHT(ProcessDate, 2)) 
              )
    FROM ARCUSYM000.dbo.SAVINGS 
    WHERE DATEFROMPARTS(LEFT(ProcessDate, 4), 
                        RIGHT(LEFT(ProcessDate, 6), 2), 
                        RIGHT(ProcessDate, 2)) = @eomDate
);

PRINT @staticpooldate;


/***QUERY WILL NOT SHIFT TO DEADLOCK ***/
SET NOCOUNT ON
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED

		--Taking Member Having General membership of Greenstate

		drop table if exists #Name
		select distinct a.PARENTACCOUNT,SSN 

		into #NAME
		from 
		(select *,datefromparts(left(ProcessDate ,4),
		right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date from ARCUSYM000.dbo.NAME) a
		left join ARCUSYM000.dbo.SAVINGS b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		and a.ProcessDate=b.ProcessDate
		where a.TYPE=0
		and a.Process_date=@staticpooldate
		
		
		---- SAVING ACCOUNTS DETAIL
		 drop table if exists #Static_SSN_account_final
		select distinct  SSN 
		--,PARENTACCOUNT,Process_date
		into #Static_SSN_account_final
		from
		(    
			select  b.SSN
					,a.PARENTACCOUNT
					,id
					,cast(OPENDATE as date) OPEN_DATE
					,cast(CLOSEDATE as date) CLOSE_DATE
					,cast(CHARGEOFFDATE as date) CHARGEOFFDATE
					,left(a.ProcessDate,6) ProcessDate_V
					,datefromparts(left(a.ProcessDate ,4),right(left(a.ProcessDate,6),2),right(a.ProcessDate,2)) Process_date
					,case when len(month(closedate))=1 then CONCAT(year(closedate),0,month(closedate)) 
						  else CONCAT(year(closedate),month(closedate)) end CLOSED_DATE_SAVINGS 
					,case when len(month(OpenDate))=1 then CONCAT(year(OpenDate),0,month(OpenDate)) 
					      else CONCAT(year(OpenDate),month(OpenDate))end  OPEN_DATE_INT_SAVINGS
					,case when len(month(CHARGEOFFDATE))=1 then CONCAT(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE)) 
					      else CONCAT(year(CHARGEOFFDATE),month(CHARGEOFFDATE))end  CHARGEOFF_DATE_SAVINGS
		
			from ARCUSYM000.dbo.SAVINGS a
			left join #NAME b 
			on a.PARENTACCOUNT=b.PARENTACCOUNT
		) aa
		where ssn is not null 
			and OPEN_DATE<@staticpooldate  
			and (CLOSE_DATE is null or CLOSE_DATE>@staticpooldate)
			and (CHARGEOFFDATE is null or CHARGEOFFDATE>@staticpooldate)  
			and Process_date=@staticpooldate 
		
		
		-- Re-Naming ParentAccount to account name
		drop table if exists #Static_SSN_account
			select distinct 
				PARENTACCOUNT AccountNumber
				,SSN
			into #Static_SSN_account
			from #NAME

        ------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Loan Membership Master Data ***\\\-------------------------------------------------------------------
			 drop table if exists #membership_loan
			
			--select distinct parentaccount from #commercial_loan
			select 
				*
				,case when  (LoanCategory1 like 'commercial%')
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then  'Commercial_loan'
                 --when LoanCategory3 = '1st Mortgage'
				 --and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 --and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 --then 'Real_Estate_loan1'
				 --when LoanCategory3 = '2nd Mortgage'
				 --and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 --and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 --then 'Real_Estate_loan2'
				 when LoanCategory3 in ('1st Mortgage','2nd Mortgage')
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then 'Real_Estate_loan'
                when LoanCategory3 = 'Secured'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then 'SecuredLoan' 
                when LoanCategory3 = 'Unsecured'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				  then 'UnsecuredLoan' 
				when LoanCategory2 ='Vehicle'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				  then 'Vehicleloan' else 'Others' end as Product_Flag
							into #membership_loan
			from
			(
					select [ProcessDate]
						   ,left(ProcessDate,6) ProcessDate_V
						   ,Process_Date
						   ,Open_date
						   ,Close_date
						   ,case when Process_Date in (eomonth((DATEADD(month,-12,@staticpooldate))),(eomonth(DATEADD(month,-11,@staticpooldate))),(eomonth(DATEADD(month,-10,@staticpooldate) ))) then 'Q4'
		                         when Process_Date in (eomonth((DATEADD(month,-9,@staticpooldate ))),(eomonth(DATEADD(month,-8,@staticpooldate))) ,(eomonth(DATEADD(month,-7,@staticpooldate)))) then 'Q3'
 								 when Process_Date in (eomonth((DATEADD(month,-6,@staticpooldate ))),(eomonth(DATEADD(month,-5,@staticpooldate))) ,(eomonth(DATEADD(month,-4,@staticpooldate)))) then 'Q2'
								 when Process_Date in (eomonth((DATEADD(month,-3,@staticpooldate))) ,(eomonth(DATEADD(month,-2,@staticpooldate ))),(eomonth(DATEADD(month,-1,@staticpooldate )))) then 'Q1'
								 when Process_Date in (@staticpooldate) then 'Staticpool'
							end Quarters
							,d.SSN
							,[PARENTACCOUNT]
							,[ID]
							,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
							,case when len(month(a.closedate))=1 then CONCAT(year(a.closedate),0,month(a.closedate))
							      else CONCAT(year(a.closedate),month(a.closedate)) end  Closed_date_INT
							,case when len(month(a.opendate))=1 then CONCAT(year(a.opendate),0,month(a.opendate))
							      else CONCAT(year(a.opendate),month(a.opendate)) end  OPEN_date_INT
							,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
							,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
							,[TYPE]
							,[LASTFMDATE]
							,[LASTTRANDATE]
							,[ORIGINALDATE]
							,a.[OPENDATE]
							,a.[CLOSEDATE]
							,[LOANCODE]
							,[APPROVALCODE]
							,[APPROVALDATE]
							,[PAYMENTFREQUENCY]
							,[PARTIALPAYMENT]
							,[PAYMENT]
							,[PAYMENTCOUNT]
							,[DUEDAY1]
							,[DUEDAY2]
							,[INTERESTRATE]
							,[ORIGINALBALANCE]
							,BALANCE
							,[CREDITLIMIT]
							,[DESCRIPTION]
							,[NSFMONTHTODATE]
							,[MATURITYDATE]
							,[APR]
							,[CREDITSCORE]
							--,(BALANCE/CREDITLIMIT) [UTILIZATION_RATE]
							,[ADVANCEAMOUNT]
							,b.LoanCategory1
							,b.LoanCategory2
							,b.LoanCategory3
							,b.LoanCategory4
							,b.LoanCategory5
							,b.LoanTypeDescription
							,CRPMTCURRENT
					  from 
					 (
						 select * 
						 ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
						 ,cast(OPENDATE as date) Open_date
						 ,cast(CLOSEDATE as date) Close_date,cast(MATURITYDATE as date) as MATURITY_DATE 
						 from ARCUSYM000.dbo.LOAN 
				     ) a
			
					left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
					on b.loantype=a.TYPE
					left join  #Static_SSN_account d
					on a.PARENTACCOUNT=d.AccountNumber
					where  ORIGINALDATE is not null 
					and a.OpenDate is not null and a.Open_date < @staticpooldate  
					and (a.CLOSEDATE is null or a.Close_date>@staticpooldate )   
					and process_date between (select dateadd(MM,-12,@staticpooldate)) and (select dateadd(MM,12,@staticpooldate)) 
					and  PARENTACCOUNT in (select distinct AccountNumber PARENTACCOUNT from #Static_SSN_account )
		) AA
		where		LoanCategory3 not in ('Writeoff','Workout/TDR')
				    and LoanCategory4 not in ('Writeoff','Workout/TDR')
					and OPEN_DATE<@staticpooldate
					and (Close_date is null or Close_date>@staticpooldate) 
					and ORIGINALDATE <= Open_date 
					and Quarters is not null

		--SELECT count( ssn) FROM #membership_loan  -- 152347 out of 1944047 (On an Average Each member holds 12 product)

		-- SSN having loan accounts except  Credit Cards

		DROP TABLE IF EXISTS #loan_woCC

		SELECT DISTINCT SSN
		INTO #loan_woCC
		FROM #membership_loan -- 152345

-- Derived variables for product holdings for loan variables without Credit Card

		DROP TABLE IF EXISTS #loan_product_holdings
		SELECT SSN [SSN001]
			   
			   ,#Products_Loan_Q1 [PRODUCT_Loan_Q1]
			
			   ,[UnsecuredLoan_Month_to_Maturity]
			   

		into #loan_product_holdings
		FROM
		(
		SELECT *
		FROM
		 (SELECT  SSN [SSN]
				
		
				
				,COUNT(Distinct CASE WHEN Quarters = 'Q1' THEN UNID END) as [#Products_Loan_Q1]       
		

				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' THEN Month_to_Maturity END) [UnsecuredLoan_Month_to_Maturity]
				

             
			 
					 from #membership_loan
					group by SSN ) B) D

			 DROP TABLE IF EXISTS #static_unid
			 SELECT DISTINCT UNID,PARENTACCOUNT,Product_Flag into #static_unid FROM #membership_loan


			  DROP TABLE IF EXISTS #loan_product_summary
			 
			 SELECT A.* 
			  into #loan_product_summary
			   --FROM #loan_accounts A
			   --left join
			   FROM #loan_product_holdings A
		
			   --SELECT DISTINCT SSN001 from #loan_product_holdings where SSN001 not in (SELECT DISTINCT SSN002 FROM #LOAN_TRANSACTION_MASTER) --27399


------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Credit Card ***\\\-------------------------------------------------------------------
--		DECLARE @staticpooldate DATE;
--DECLARE @eomDate DATE;

---- Determine the end of the current or previous month
--SET @eomDate = CASE 
--                   WHEN EOMONTH(GETDATE()) = CAST(GETDATE() AS DATE) 
--                   THEN EOMONTH(GETDATE()) 
--                   ELSE EOMONTH(DATEADD(MONTH, -1, GETDATE())) 
--               END;

--			   PRINT @eomDate;

---- Get the maximum ProcessDate corresponding to the determined end of month
--SET @staticpooldate = (
--    SELECT MAX(DATEFROMPARTS(LEFT(ProcessDate, 4), 
--                              RIGHT(LEFT(ProcessDate, 6), 2), 
--                              RIGHT(ProcessDate, 2)) 
--              )
--    FROM ARCUSYM000.dbo.SAVINGS 
--    WHERE DATEFROMPARTS(LEFT(ProcessDate, 4), 
--                        RIGHT(LEFT(ProcessDate, 6), 2), 
--                        RIGHT(ProcessDate, 2)) = @eomDate
--);

--PRINT @staticpooldate;	

--DECLARE @staticpooldate DATE;
DECLARE @checkDate DATE
DECLARE @fallbackDate DATE

-- Set the initial static pool date
--SET @staticpooldate = '2024-07-31'; -- Adjust as needed
SET @checkDate = @staticpooldate
SET @fallbackDate = EOMONTH(DATEADD(MONTH, -1, @staticpooldate)); -- Last day of last month

-- Check if data exists for the specified date
IF NOT EXISTS (
    SELECT 1 
    FROM TMGData.dbo.cardholder 
    WHERE Active_Flag = 1
      AND ([External Status Code] = '' OR [Internal Status Code] IN ('N', ''))
      AND extract_datepart = LEFT(CONVERT(VARCHAR, @checkDate, 112), 6)
)
BEGIN
    SET @checkDate = @fallbackDate; -- Adjust to last month if not found
END



--Print @staticpooldate
--Print @fallbackDate
--Print @checkDate
--Print @staticpooldate
--print left(convert(varchar,@checkdate,112),6)


			 
  drop table if exists #CC_Members_Static
  

	  select distinct [Social Security Number] 
	  into #CC_Members_Static
	  from TMGData.dbo.cardholder 
	  where Active_Flag=1 and ([External Status Code]='' or [Internal Status Code] in ('N',''))
	  and extract_datepart=left(convert(varchar,@checkdate,112),6)

		 drop table if exists #CC_data	
		
		
		select * 
		into #CC_data
		from 
		(
		SELECT  [Durable_Key]
		,case when extract_datepart in (left(convert(varchar,eomonth(dateadd(month,-12,@checkdate)),112),6),left(convert(varchar,eomonth(dateadd(month,-11,@checkdate)),112),6),left(convert(varchar,eomonth(dateadd(month,-10,@checkdate)),112),6)) then 'Q4'
		    when extract_datepart in (left(convert(varchar  ,eomonth(dateadd(month,-9,@checkdate)),112),6),left(convert(varchar ,eomonth(dateadd(month,-8,@checkdate)),112),6),left(convert(varchar ,eomonth(dateadd(month,-7,@checkdate)),112),6)) then 'Q3'
		    when extract_datepart in (left(convert(varchar  ,eomonth(dateadd(month,-6,@checkdate)),112),6),left(convert(varchar ,eomonth(dateadd(month,-5,@checkdate)),112),6),left(convert(varchar ,eomonth(dateadd(month,-4,@checkdate)),112),6)) then 'Q2'
		    when extract_datepart in (left(convert(varchar  ,eomonth(dateadd(month,-3,@checkdate)),112),6),left(convert(varchar ,eomonth(dateadd(month,-2,@checkdate)),112),6),left(convert(varchar ,eomonth(dateadd(month,-1,@checkdate)),112),6)) then 'Q1'
		    when extract_datepart in (left(convert(varchar,@checkdate,112),6)) then 'Staticpool' end Quarters
       ,[Social Security Number]
     
  FROM TMGData.dbo.cardholder 	-- Changed 042222
  where [Social Security Number] in (select [Social Security Number] from #CC_Members_Static)
  and Active_Flag=1
   ) a
    where  quarters is not null 
  ----and mob>=12  ---commented by nikita on 05/10/2022

--- Drift of CC data

		 Drop table if exists #Credit_Card_data
		select 
		SSN_CC
		,PRODUCT_CC_Q1
		
		into #Credit_Card_data
		from 
		(
		select [Social Security Number] SSN_CC
		    
			,COUNT(DISTINCT CASE WHEN Quarters = 'Q1' THEN Durable_Key END) [PRODUCT_CC_Q1]
			  from #CC_data
			  group by [Social Security Number]
			  ) a

			 
			 
			 DROP TABLE IF EXISTS #loan_product_master		   

			 SELECT a.* ,b.*
			 INTO #loan_product_master
			 FROM #loan_product_summary A
			 LEFT JOIN
			 #Credit_Card_data B
			 on A.SSN001 = B.SSN_CC --157375

------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** DEPOSITS ***\\\-------------------------------------------------------------------

		

	  DROP TABLE IF EXISTS #ShareCategory
	 -- Consumer & Commercial Category in Money Market
		SELECT *
		into #ShareCategory
		FROM
		(
  		SELECT *,CASE WHEN ShareCategory2 ='Savings' and ShareCategory3='IRA' then 1 else 0 end [IRA_SAVINGS_FLAG]  
		from ARCUSYM000.ARCU.ARCUShareCategory
		) S
		where 1=1
			--and ShareCategory3 not in ('HSA','IRA') 
			and ShareCategory1 <> 'Non-Member'
			and ShareType <> '9997'   --(excluding Greenstate Corporate Checking)
			and IRA_SAVINGS_FLAG = 0
   
------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Membership Data (ShareCategorywise) ***\\\-------------------------------------------------------------------

    DROP TABLE IF EXISTS #deposits_account_data

		select SSN
		      ,UNID
			  ,ProcessDate
			  ,PARENTACCOUNT
			  ,id
			  ,TYPE
			  ,LASTDIVAMOUNT
			  ,BALANCE Month_end_balance
	
			  ,Closed_flag
			  ,left(ProcessDate,6) ProcessDate_v
		      ,close_date,open_date
			  ,process_date 
			  ,Quarters
			  ,MOB
			  ,
			  --,StaticPool_Saving_flag
			  CASE WHEN (ShareCategory2 = 'Savings' and ShareCategory3 not in ('IRA','HSA')) then 'Savings'
			         WHEN (ShareCategory2 = 'Checking' and ShareCategory3 not in ('IRA','HSA')) then 'Checking'
					 WHEN (ShareCategory2 = 'CD' and ShareCategory3 not in ('IRA','HSA'))  then 'Certificates'
					 WHEN (ShareCategory2 = 'Money Market' and ShareCategory3 not in ('IRA','HSA')) then 'MoneyMarket' 
					 WHEN (ShareCategory2 in ('CD','Money Market') and ShareCategory3 = 'IRA')  then 'IRA'
					 WHEN (ShareCategory2 in ('Checking','Savings') and ShareCategory3 = 'HSA')  then 'HSA'
					 ELSE 'OTHERS' END [Deposit_Flag] --GREENSTATE CORPORATE CHECKING is the only in others
			 
		into #deposits_account_data 
		from 
		(
		select  
		d.SSN
		,case when Process_Date in (eomonth(DATEADD(month,-12,@staticpooldate )),eomonth(DATEADD(month,-11,@staticpooldate)),eomonth(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		   when Process_Date in (eomonth(DATEADD(month,-9,@staticpooldate )),eomonth(DATEADD(month,-8,@staticpooldate)),eomonth(DATEADD(month,-7,@staticpooldate )))  then 'Q3'
		   when Process_Date in (eomonth(DATEADD(month,-6,@staticpooldate )),eomonth(DATEADD(month,-5,@staticpooldate)),eomonth(DATEADD(month,-4,@staticpooldate ))) then 'Q2'
		   when Process_Date in (eomonth(DATEADD(month,-3,@staticpooldate )),eomonth(DATEADD(month,-2,@staticpooldate)),eomonth(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		   when Process_Date in (@staticpooldate) then 'Staticpool'
		  end Quarters
		   ,DATEDIFF(MONTH,OPEN_DATE,@staticpooldate) MOB
		   --,case when ShareCategory2='savings' and Process_Date =@staticpooldate then 1 else 0 end StaticPool_Saving_flag
		,aa.*,c.Closed_flag
		,case when aa.close_date is null then '' 
		when len(month(aa.close_date))=1 then CONCAT(year(aa.close_date),0,month(aa.close_date))
		else CONCAT(year(aa.close_date),month(aa.close_date)) end  Closed_date_INT
		,case when len(month(aa.open_date))=1 then CONCAT(year(aa.open_date),0,month(aa.open_date))
		else CONCAT(year(aa.open_date),month(aa.open_date)) end  OPEN_date_INT_INT
		,E.ShareTypeDescription,E.ShareCategory2,E.ShareCategory3
		,case when ShareCategory2='CD' and BALANCE=0 then 0 else 1 end carryforward_flag ----not understood
		from 
					(select * from
							(	select *,case when [EOM_Process Date]=[Process Date] then 1 else 0 end EOM_flag 
										,case when (closedate is null and CHARGEOFFDATE is null) or ProcessDate_v=Close_date_v 
										or ProcessDate_v=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
										,case when OPEN_DATE=CLOSE_DATE then 0 else 1 end Funded_loan_flag
										,lag(Open_date,1) over (partition by Concat(parentaccount,id) order by processdate) Lag_opendate
											,lag(type,1) over (partition by Concat(parentaccount,id) order by processdate) Lag_Type
											,concat(PARENTACCOUNT,ID) UNID
										from
											(select a.*,EOMONTH([Process Date]) [EOM_Process Date]
											,case when ProcessDate_v=CHARGEOFFDATE_v then CHARGEOFFAMOUNT else 0 end CHARGEOFFAMOUNT_v
											,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
											else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date_v
											,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
											,cast(OPENDATE as date) Open_date
											,cast(CLOSEDATE as date) Close_date
											 from 
												 ( select * ,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
												 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v
												 ,left(ProcessDate,6) ProcessDate_v
												,datefromparts(left(processdate,4),right(left(processdate,6),2),right(processdate,2)) [Process Date] 
												from arcusym000.dbo.SAVINGS
												--where (chargeoffdate is null or chargeoffdate>='2021-11-01')
												) a
												 
											) F
								 ) aaa
								  where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
					 ) aa
		left join 
				(select UNID,max(closed_flag) Closed_flag
				from
						(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when CLOSEDATE is null then 0 else 1 end closed_flag
						from 
								(select distinct PARENTACCOUNT,ID,CLOSEDATE 
								from [ARCUSYM000].dbo.SAVINGS
								 where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
								 ) a 
						 )b
				group by UNID
				) c
		on aa.UNID=c.UNID
		left join #Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join #ShareCategory E
		on e.ShareType=aa.TYPE
		where Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate))
		and PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
		) ZZ
		where 1 = 1
		--and ShareCategory2 ='Savings'  
		and open_date<@staticpooldate and (close_date is null or close_date>@staticpooldate)
		and Funded_loan_flag=1 and Quarters is not null and Open_Flag=1 and carryforward_flag=1
		order by UNID,ProcessDate,TYPE

		--SELECT DISTINCT SSN FROM #deposits_account_data where Process_Date = '2021-08-31' -- 321868

		DROP TABLE IF EXISTS #membership_deposits

		SELECT A.SSN [SSN003]

			  ,SUM_LASTDIVAMOUNT_MONEYMARKET_Q1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 IS NULL AND SUM_LASTDIVAMOUNT_MONEYMARKET_Q2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q2,0)) end [DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2]
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 IS NULL AND SUM_LASTDIVAMOUNT_MONEYMARKET_Q3 IS  NULL ) THEN SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q3,0)) end [DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q3]
			   ,AVG_MONTH_END_BALANCE_DEPOSITS_Q1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_DEPOSITS_Q1 IS NULL AND AVG_MONTH_END_BALANCE_DEPOSITS_Q2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_DEPOSITS_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q2,0)) end [DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2] 
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_DEPOSITS_Q1 IS NULL AND AVG_MONTH_END_BALANCE_DEPOSITS_Q3 IS  NULL ) THEN AVG_MONTH_END_BALANCE_DEPOSITS_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q3,0)) end [DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3]
			  ,MOB_DEPOSITS
			  ,[PRODUCT_DEPOSITS_Q1]

		into #membership_deposits
		FROM 
		(
	     (SELECT * 
					 ,CASE WHEN PRODUCT_IRA_SP > 0 THEN 1 ELSE 0 END [IRA_StaticpoolFlag]
		
		   FROM
		  (
			 SELECT SSN
             

			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' then MOB END) [MOB_SAVINGS]
	

			       ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Staticpool') then UNID END) [PRODUCT_IRA_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q1') then UNID END) [PRODUCT_IRA_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q2') then UNID END) [PRODUCT_IRA_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q3') then UNID END) [PRODUCT_IRA_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q4') then UNID END) [PRODUCT_IRA_Q4]
					

              ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q4]
			  ,AVG(CASE WHEN Quarters = 'Q1' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q1]
			  ,AVG(CASE WHEN Quarters = 'Q2' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q2]
			  ,AVG(CASE WHEN Quarters = 'Q3' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q3]
			  ,AVG(CASE WHEN Quarters = 'Q4' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q4]


		    FROM #deposits_account_data
		    group by SSN
			 ) P
			) A
			LEFT JOIN 
			(
			SELECT SSN
		      ,COUNT(DISTINCT CASE WHEN Quarters = 'Q1'then UNID END) [PRODUCT_DEPOSITS_Q1]
			 

			  ,MAX( MOB ) [MOB_DEPOSITS]
			  
		
			FROM #deposits_account_data
			group by SSN
			) B
			ON A.SSN = B.SSN
		 
		) 


------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Transaction Data (ShareCategorywise) ***\\\-----------------------------------------------

     DROP TABLE IF EXISTS #static_unid_deposits
     
     SELECT UNID,PARENTACCOUNT,Deposit_Flag,Process_Date
     into #static_unid_deposits
     from #deposits_account_data

     DROP TABLE IF EXISTS #deposit_transaction_temp1
     SELECT B.Deposit_Flag
	  ,case when A.EFFECTIVEDATE_v1 in ((left(convert(varchar,eomonth(dateadd(month,-10,@staticpooldate)),112),6)),(left(convert(varchar,eomonth(dateadd(month,-11,@staticpooldate)),112),6)),(left(convert(varchar,eomonth(dateadd(month,-12,@staticpooldate)),112),6))) then 'Q4'
		    when A.EFFECTIVEDATE_v1 in ((left(convert(varchar,eomonth(dateadd(month,-7,@staticpooldate)),112),6)),(left(convert(varchar, eomonth(dateadd(month,-8,@staticpooldate)),112),6)),(left(convert(varchar, eomonth(dateadd(month,-9,@staticpooldate)),112),6))) then 'Q3'
		    when A.EFFECTIVEDATE_v1 in ((left(convert(varchar,eomonth(dateadd(month,-4,@staticpooldate)),112),6)),(left(convert(varchar, eomonth(dateadd(month,-5,@staticpooldate)),112),6)),(left(convert(varchar, eomonth(dateadd(month,-6,@staticpooldate)),112),6))) then 'Q2'
		    when A.EFFECTIVEDATE_v1 in ((left(convert(varchar,eomonth(dateadd(month,-3,@staticpooldate)),112),6)),(left(convert(varchar, eomonth(dateadd(month,-2,@staticpooldate)),112),6)),(left(convert(varchar, eomonth(dateadd(month,-1,@staticpooldate)),112),6))) then 'Q1'
		    when A.EFFECTIVEDATE_v1 in (left(convert(varchar,@staticpooldate,112),6)) then 'Staticpool' end Quarters
	 ,A.*
	 ,C.SSN
	    into #deposit_transaction_temp1
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      
      ,[BALANCECHANGE]
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	  
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
	 FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
	  WHERE  ACTIONCODE!='C') A
	 left join #static_unid_deposits B
	 ON A.UNID = B.UNID
	 left join #Static_SSN_account C
	 on A.PARENTACCOUNT = C.AccountNumber
	 --and A.EFFECTIVEDATE_v1 = B.Process_Date
	-- day wise data include all dates 
	where EFFECTIVEDATE_v1 between left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6) and left(convert(varchar,@staticpooldate,112),6)
  


        DROP TABLE IF EXISTS #deposit_transaction_temp2
            

		 SELECT * 
		 INTO #deposit_transaction_temp2 
		 FROM
		 (
          (SELECT  SSN

                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_Q1]

        from #deposit_transaction_temp1
        --group by PARENTACCOUNT
		group by SSN ) P
		LEFT JOIN 
		(SELECT SSN [SSN_D]
		 ,SUM(CASE WHEN Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q4]
		 
            
                ,SUM(CASE WHEN Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q4]
   
           	
		FROM #deposit_transaction_temp1
		--group by PARENTACCOUNT 
		group by SSN) Q
		ON P.SSN = Q.SSN_D
		) 
  --      left join #Static_SSN_account B
  --      on A.PARENTACCOUNT = B.AccountNumber

		DROP TABLE IF EXISTS #deposits_transaction

		SELECT SSN [SSN004]
		      
			  , [TRANSACTION_AMOUNT_CERTIFICATES_Q1]				  
			 		      , [TRANSACTION_COUNT_DEPOSITS_Q1] 
			  , CASE WHEN ( TRANSACTION_COUNT_DEPOSITS_Q1 IS NULL AND TRANSACTION_COUNT_DEPOSITS_Q2 IS  NULL ) THEN TRANSACTION_COUNT_DEPOSITS_Q1 else (ISNULL(TRANSACTION_COUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_COUNT_DEPOSITS_Q2,0)) end DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q2
			  , CASE WHEN ( TRANSACTION_COUNT_DEPOSITS_Q1 IS NULL AND TRANSACTION_COUNT_DEPOSITS_Q3 IS  NULL ) THEN TRANSACTION_COUNT_DEPOSITS_Q1 else (ISNULL(TRANSACTION_COUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_COUNT_DEPOSITS_Q3,0)) end DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3
		   
		     

			  , [WITHDRAWAL_AMOUNT_DEPOSITS_Q1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_DEPOSITS_Q1 IS NULL AND WITHDRAWAL_AMOUNT_DEPOSITS_Q2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_DEPOSITS_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q2,0)) end [DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_DEPOSITS_Q1 IS NULL AND WITHDRAWAL_AMOUNT_DEPOSITS_Q3 IS  NULL ) THEN WITHDRAWAL_AMOUNT_DEPOSITS_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q3,0)) end [DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_AMOUNT_DEPOSITS_Q1 IS NULL AND WITHDRAWAL_AMOUNT_DEPOSITS_Q4 IS  NULL ) THEN WITHDRAWAL_AMOUNT_DEPOSITS_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q4,0)) end [DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q4]
			
		into #deposits_transaction
		from #deposit_transaction_temp2

		DROP TABLE IF EXISTS #deposits_summary
		SELECT * 
		into #deposits_summary 
		FROM #membership_deposits A
		left join #deposits_transaction B
		on A.SSN003  = B.SSN004

	

		DROP TABLE IF EXISTS #merged_loan_deposits_summary
		SELECT * 
		into #merged_loan_deposits_summary
		FROM #deposits_summary A
		left join 
		#loan_product_master B
		on A.SSN003 = B.SSN001

--	DECLARE @staticpooldate DATE;
--DECLARE @eomDate DATE;
----DECLARE @BUreaudate Varchar(6)
--Select count(*) from #merged_loan_deposits_summary

---- Determine the end of the current or previous month
--SET @eomDate = CASE 
--                   WHEN EOMONTH(GETDATE()) = CAST(GETDATE() AS DATE) 
--                   THEN EOMONTH(GETDATE()) 
--                   ELSE EOMONTH(DATEADD(MONTH, -1, GETDATE())) 
--               END;

--			   PRINT @eomDate;

---- Get the maximum ProcessDate corresponding to the determined end of month
--SET @staticpooldate = (
--    SELECT MAX(DATEFROMPARTS(LEFT(ProcessDate, 4), 
--                              RIGHT(LEFT(ProcessDate, 6), 2), 
--                              RIGHT(ProcessDate, 2)) 
--              )
--    FROM ARCUSYM000.dbo.SAVINGS 
--    WHERE DATEFROMPARTS(LEFT(ProcessDate, 4), 
--                        RIGHT(LEFT(ProcessDate, 6), 2), 
--                        RIGHT(ProcessDate, 2)) = @eomDate
--);	

--Set @BUreaudate = LEFT(CONVERT(VARCHAR, @staticpooldate, 112), 6)
	/* Appending OnlineBanking data to Master data  */

	drop table if exists #loan_dep_onlinebanking
	select  A.*,DATEDIFF ( day, LastLogon, @staticpooldate) AS "Days Since Last Login" 
	into #loan_dep_onlinebanking -- new copy of master data
	from #merged_loan_deposits_summary as A
	LEFT join Q2EVE.[dbo].[vwMemberOnlineBankingSummary] as B
	on A.SSN003 = B.SSN

--Select count(*) from #loan_dep_onlinebanking


	--SELECT COUNT(SSN003) FROM #loan_dep_onlinebanking
	--SELECT COUNT(DISTINCT SSN003) FROM #loan_dep_onlinebanking

	/** Appending Bureau Data to master data 202212 **/


--DECLARE @maxDate VARCHAR(6); -- Assuming the date is in YYYYMM format
--DECLARE @sql NVARCHAR(MAX);

---- Get the maximum date in YYYYMM format
--SELECT @maxDate = CONVERT(VARCHAR(6), MAX([date]), 112)
--FROM OPENQUERY(gsdwsql01, 'SELECT [date] FROM BureauData.[dbo].[TransUnionAttributeHistory]');


--declare @date as int
--set @date = 202205

--SELECT b.[date]
--from #test a 
--left join gsdwsql01.BureauData.[dbo].[TransUnionAttributeHistory]  b
--on a.ssn = b.ssn 
--where b.[date] = @date


--DECLARE @staticpooldate DATE;
--DECLARE @eomDate DATE;

---- Determine the end of the current or previous month
--SET @eomDate = CASE 
--                   WHEN EOMONTH(GETDATE()) = CAST(GETDATE() AS DATE) 
--                   THEN EOMONTH(GETDATE()) 
--                   ELSE EOMONTH(DATEADD(MONTH, -1, GETDATE())) 
--               END;

--			   PRINT @eomDate;

---- Get the maximum ProcessDate corresponding to the determined end of month
--SET @staticpooldate = (
--    SELECT MAX(DATEFROMPARTS(LEFT(ProcessDate, 4), 
--                              RIGHT(LEFT(ProcessDate, 6), 2), 
--                              RIGHT(ProcessDate, 2)) 
--              )
--    FROM ARCUSYM000.dbo.SAVINGS 
--    WHERE DATEFROMPARTS(LEFT(ProcessDate, 4), 
--                        RIGHT(LEFT(ProcessDate, 6), 2), 
--                        RIGHT(ProcessDate, 2)) = @eomDate
--);

--PRINT @staticpooldate;


--DECLARE @staticpool date;
--set @staticpool = '2024-01-01'


DECLARE @date int;
SET @date = LEFT(CONVERT(VARCHAR(6), @staticpooldate, 112), 6);

PRINT @date;

-- --Constructing the SQL query string
drop table if exists #MAsterData
SELECT A.*,b.*
                    --B.[CCAPREstimate],
                    --B.[AggregatedSpendPast3Months],
                    --B.[OpenTradeCount],                   
                    --B.[OpenTradeBalance],                  
                    --B.[AutoOpenTradeCount],               
                    --B.[AutoLoanOrgBalanceP12Months],
                    --B.[AutoOpenTradeBalance],             
                    --B.[CCCount],
                    --B.[CCOpenCount],                      
                    --B.[CCTotalAvailableLOC],              
                    --B.[CCOpenBalance], 
                    --B.[NumberInquiriesP6Months], 
                    --B.[HEOpenCount],                    
                    --B.[HETotalAvailableLOC],            
                    --B.[HEOpenBalance],                 
                    --B.[HELOCOpenCount],
                    --B.[HELOCTotalAvailableLOC],
                    --B.[HELOCOpenBalance],
                    --B.[MortgageOpenCount],             
                    --B.[MortgageOpenBalance],  
                    --B.[CCRevolvingBalance]
            INTO #MAsterData
         FROM #loan_dep_onlinebanking AS A
			left join gsdwsql01.BureauData.[dbo].[TransUnionAttributeHistory]  b
			on  cast(a.SSN003  as bigint) = cast(b.ssn  as bigint)
			and b.[date] = @date

--Select count(*) from #MAsterData

--select max(date) from gsdwsql01.BureauData.[dbo].[TransUnionAttributeHistory]

---- Execute the constructed SQL
--EXEC sp_executesql @sql;

--Print @sql
		
--		Select top 100 * from #MAsterData
--		----New Varibles
--DECLARE @sql NVARCHAR(MAX);
--DECLARE @maxDate VARCHAR(10);

---- Assuming @maxDate is already set and properly formatted
--SET @maxDate = CONVERT(VARCHAR(10), @maxDate, 120);

---- Build the SQL string
--SET @sql = 'SELECT * 
--             FROM OPENQUERY(gsdwsql01, 
--             ''SELECT * 
--               FROM BureauData.[dbo].[TransUnionAttributeHistory] 
--               WHERE [date] = ''''' + @maxDate + ''''') AS B;';

---- Execute the SQL statement
--EXEC sp_executesql @sql;
--Select * from #MAsterData

----EXEC sp_executesql @sql;

--print @sql


		-----------Adding checking Targte list steps  -----------------------------





		
--===================================================fetching active Cheking on latest data --========================================

 drop table if exists #1
  select distinct ssn into #1 from
    (
    select 
        ssn
    from ARCUSYM000.dbo.NAME N
    join ARCUSYM000.dbo.SAVINGS S
        on S.ProcessDate = N.ProcessDate
        AND S.PARENTACCOUNT = N.PARENTACCOUNT
    join ARCUSYM000.arcu.arcusharecategory SC
        ON SC.sharetype = S.type
    where N.ProcessDate = (SELECT MAX(ProcessDate) FROM ARCUSYM000.dbo.IRS)
        AND N.type = 0
        AND N.EXPIRATIONDATE is null
        AND SC.ShareCategory2 = 'checking'
        AND S.CLOSEDATE is null
        AND S.CHARGEOFFDATE is null

    UNION ALL

    select 
        ssn
    from ARCUSYM000.dbo.SAVINGSNAME N
    join ARCUSYM000.dbo.SAVINGS S
        on S.ProcessDate = N.ProcessDate
        AND S.PARENTACCOUNT = N.PARENTACCOUNT
        AND S.ID = N.PARENTID
    join ARCUSYM000.arcu.arcusharecategory SC
        ON SC.sharetype = S.type
    where N.ProcessDate = (SELECT MAX(ProcessDate) FROM ARCUSYM000.dbo.IRS)
        AND N.type in (1,6)
        AND N.EXPIRATIONDATE is null
        AND SC.ShareCategory2 = 'checking'
        AND S.CLOSEDATE is null
        AND S.CHARGEOFFDATE is null
    ) SSN



 --==================fetching model varible and excluding checking members ==============================

Drop table if exists #temp
select  distinct ssn003,
(isnull(PRODUCT_DEPOSITS_Q1,0)+isnull(PRODUCT_CC_Q1,0)+isnull(PRODUCT_Loan_Q1,0))   TOTAL_PRODUCT_Q1,
--PRODUCT_DEPOSITS_Q1,PRODUCT_CC_Q1,PRODUCT_Loan_Q1,
TRANSACTION_AMOUNT_CERTIFICATES_Q1,
DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3,
UnsecuredLoan_Month_to_Maturity,
MortgageOpenBalance,
MOB_Deposits MOB_SAVINGS,
DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2
into #temp
from #MAsterData
where 1=1
AND SSN003 NOT IN (SELECT DISTINCT  SSN FROM #1 where ssn is not null )

--select * from #temp WHERE TOTAL_PRODUCT_Q1 = 0
--===================WOE Transformation ===========================

-- Drop temporary table if it exists
-- Drop temporary table if it exists
DROP TABLE IF EXISTS #temp1;

-- Create a new temporary table with WOE transformations
SELECT 
    *,

    -- Apply WOE for TOTAL_PRODUCT_Q1
    CASE 
        WHEN TOTAL_PRODUCT_Q1 <= 1.0 THEN -1.631706540273838
        WHEN TOTAL_PRODUCT_Q1 > 1.0 AND TOTAL_PRODUCT_Q1 <= 2.0 THEN 0.04522774477393882
        WHEN TOTAL_PRODUCT_Q1 > 2.0 AND TOTAL_PRODUCT_Q1 <= 559.0 THEN 0.9386455987760666
        ELSE NULL  -- Handle unexpected values
    END AS WOE_TOTAL_PRODUCT_Q1,TOTAL_PRODUCT_Q1 cc,

    -- Apply WOE for TRANSACTION_AMOUNT_CERTIFICATES_Q1
    CASE 
        WHEN TRANSACTION_AMOUNT_CERTIFICATES_Q1 <= -217459140.211 THEN -0.15993493375553636
        WHEN TRANSACTION_AMOUNT_CERTIFICATES_Q1 > -217459140.211 AND TRANSACTION_AMOUNT_CERTIFICATES_Q1 <= 803.523 THEN -0.15993493375553636
        WHEN TRANSACTION_AMOUNT_CERTIFICATES_Q1 > 803.523 AND TRANSACTION_AMOUNT_CERTIFICATES_Q1 <= 7512.18 THEN 0.7141193297227466
        WHEN TRANSACTION_AMOUNT_CERTIFICATES_Q1 > 7512.18 AND TRANSACTION_AMOUNT_CERTIFICATES_Q1 <= 40000000.0 THEN 0.03534796834129548
        ELSE -0.022551750414879612  -- NA case
    END AS WOE_TRANSACTION_AMOUNT_CERTIFICATES_Q1,TRANSACTION_AMOUNT_CERTIFICATES_Q1 ccc,

    -- Apply WOE for DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3
    CASE 
        WHEN DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3 <= -19942.001 THEN 0.6648737916073587
        WHEN DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3 > -19942.001 AND DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3 <= -15.0 THEN 0.6648737916073587
        WHEN DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3 > -15.0 AND DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3 <= 23.0 THEN -0.2732734683744902
        WHEN DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3 > 23.0 AND DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3 <= 156013.0 THEN 1.0668352302425261
        ELSE -1.4814799752076626  -- NA case
    END AS WOE_DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3,DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3 cccc,

    -- Apply WOE for UnsecuredLoan_Month_to_Maturity
    CASE 
        WHEN UnsecuredLoan_Month_to_Maturity <= -335.001 THEN 0.5801146270277979
        WHEN UnsecuredLoan_Month_to_Maturity > -335.001 AND UnsecuredLoan_Month_to_Maturity <= 25.0 THEN 0.5801146270277979
        WHEN UnsecuredLoan_Month_to_Maturity > 25.0 AND UnsecuredLoan_Month_to_Maturity <= 44.0 THEN 1.0881483103835936
        WHEN UnsecuredLoan_Month_to_Maturity > 44.0 AND UnsecuredLoan_Month_to_Maturity <= 352.0 THEN 0.9559342078436476
        ELSE -0.08332794086647137  -- NA case
    END AS WOE_UnsecuredLoan_Month_to_Maturity,

    -- Apply WOE for MortgageOpenBalance
    CASE 
        WHEN MortgageOpenBalance <= -4.001 THEN 0.15445997445523424
        WHEN MortgageOpenBalance > -4.001 AND MortgageOpenBalance <= -1.0 THEN 0.15445997445523424
        WHEN MortgageOpenBalance > -1.0 AND MortgageOpenBalance <= 100588.0 THEN 0.022756102257162732
        WHEN MortgageOpenBalance > 100588.0 AND MortgageOpenBalance <= 7952522.0 THEN 0.7159238973749488
        ELSE -1.026021071818676  -- NA case
    END AS WOE_MortgageOpenBalance,

    -- Apply WOE for MOB_SAVINGS
    CASE 
        WHEN MOB_SAVINGS <= -0.001 THEN -0.24403861121660642
        WHEN MOB_SAVINGS > -0.001 AND MOB_SAVINGS <= 23.0 THEN -0.24403861121660642
        WHEN MOB_SAVINGS > 23.0 AND MOB_SAVINGS <= 51.0 THEN -0.2701875678046595
        WHEN MOB_SAVINGS > 51.0 AND MOB_SAVINGS <= 818.0 THEN 0.3715305735033479
        ELSE 0.33846677957711524  -- NA case
    END AS WOE_MOB_SAVINGS,

    -- Apply WOE for DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2
    CASE 
        WHEN DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2 <= -1027040.881 THEN 0.8703864719886367
        WHEN DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2 > -1027040.881 AND DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2 <= 0.0 THEN 0.8703864719886367
        WHEN DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2 > 0.0 AND DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2 <= 2.19 THEN 0.7511884085031055
        WHEN DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2 > 2.19 AND DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2 <= 218961.77 THEN 1.0456063095504082
        ELSE -0.04502737768328255  -- NA case
    END AS WOE_DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2

INTO #temp1
FROM #temp;

	--===========================Probability score ==================

drop table if exists  #temp2
	   select 
	   *
	   ,EXP(
        -5.2069
        + 0.3945 * WOE_TOTAL_PRODUCT_Q1
        + 0.4656 * WOE_TRANSACTION_AMOUNT_CERTIFICATES_Q1
        + 0.7121 * WOE_DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3
        + 0.2686 * WOE_UnsecuredLoan_Month_to_Maturity
        + 0.7168 * WOE_MortgageOpenBalance
        + 0.1241 * WOE_MOB_SAVINGS
        + 0.1390 * WOE_DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2)
		/
		(1 +
		(EXP ( -5.2069
        + 0.3945 * WOE_TOTAL_PRODUCT_Q1
        + 0.4656 * WOE_TRANSACTION_AMOUNT_CERTIFICATES_Q1
        + 0.7121 * WOE_DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3
        + 0.2686 * WOE_UnsecuredLoan_Month_to_Maturity
        + 0.7168 * WOE_MortgageOpenBalance
        + 0.1241 * WOE_MOB_SAVINGS
        + 0.1390 * WOE_DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2
		)
		)
		) as [Probability Value]
		 
        into #temp2
	   from #temp1

	Drop table if exists #tempp
	select min([Probability Value]) MIN_Prob,Max([Probability Value]) Max_Prob  into #tempp from #temp2

	--select* from #tempp


	--===propensity score and decile =============================
	DROP TABLE IF EXISTS #temp3

SELECT 
  SSN003,
  [Probability Value],
  ROUND((([Probability Value]) - (SELECT MIN_Prob FROM #tempp)) / ((SELECT Max_Prob FROM #tempp) - (SELECT MIN_Prob FROM #tempp)) * 1000,0) AS propensity_score,
  NTILE(10) OVER (ORDER BY [Probability Value] DESC) AS Decile,
  TOTAL_PRODUCT_Q1,
TRANSACTION_AMOUNT_CERTIFICATES_Q1,
DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3,
UnsecuredLoan_Month_to_Maturity,
MortgageOpenBalance,
MOB_SAVINGS,
DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2
INTO #temp3
FROM #temp2
GROUP BY
  SSN003,
  [Probability Value],
 TOTAL_PRODUCT_Q1,
TRANSACTION_AMOUNT_CERTIFICATES_Q1,
DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3,
UnsecuredLoan_Month_to_Maturity,
MortgageOpenBalance,
MOB_SAVINGS,
DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2



--Select top 1* from #temp3


	   --Select * from #temp3 order by [Probability Value] desc

	   --====================Creating mailing list -==================================

Drop table if exists #Mailing
	Select 
	*
	into #Mailing
	from 
	(Select 
	distinct SSN,
			Street as [Address 1],ExtraAddress as [Address 2],City,State,ZipCode,
			namemailflag,MailingOnly,EStatementsEnabled,AddressTypeDescription
			,ROW_NUMBER() Over(Partition by ssn order by EStatementsEnabled desc,namemailflag desc) as rank
	from UICCU.bi.vwMailingAddressCurrent
	where ssn in (select SSN from #temp3)
	and  ssn is not null 
	and  NameType = 'PRIMARY'
			and ParentAccount in 
			(select distinct ParentAccount 		from ARCUSYM000..NAME	
			where ProcessDate in (select max(ProcessDate) from ARCUSYM000..NAME	) and ADDRESSTYPE = 0 
			and SSN is not null and EXPIRATIONDATE is null and DEATHDATE is null and type = 0 
			and SSN in (select distinct  SSN from #temp3 ))
			and addressTypeDescription = 'Domestic Address'
			) a
	where rank=1


	drop table if exists #checking
	select * into #checking 
	from #temp3 a
	left join #Mailing b
	on a.SSN003=b.SSN
	where  ssn is not null 

	--Select count(*) from #temp3
	-------Dynamic table creation 

DECLARE @TableName NVARCHAR(255)
DECLARE @SQL NVARCHAR(MAX)

-- Generate a unique table name using the current date formatted as YYYYMM
SET @TableName = 'analytics.dbo.Checking_Propensity_Target_List_' + 
                 CONVERT(NVARCHAR(8), GETDATE(), 112)  -- Format: YYYYMM
PRINT @TableName

-- Drop the table if it already exists (optional)
 EXEC('DROP TABLE IF EXISTS ' + @TableName)

-- Create the new table with the unique name
SET @SQL = 'SELECT * INTO ' + @TableName + ' FROM #checking'



-- Use EXEC sp_executesql for safer execution of dynamic SQL

EXEC sp_executesql @SQL




Print @sql
	End
---
--CREATE CLUSTERED INDEX IDX_Checking_Propensity_Target_List_Clustered
--ON analytics.dbo.Checking_Propensity_Target_List_20241105 (propensity_score DESC);

--EXEC [dbo].[Checking_Propensity_Target List]	


--******************************************************************************************************Validation***************************************************************************
--*****************************************************************************************************************************************************************************************


--Select count(*) from #MAsterData
--Select count(*) from analytics.dbo.Checking_Propensity_Target_List_202409
--Select count(*) from analytics.dbo.Checking_Propensity_Target_List_20241105
--sELECT  count(*) FROM #1

--sELECT MAX(PROPENSITY_SCORE) FROM analytics.dbo.Checking_Propensity_Target_List_20241105
--sELECT MIN(PROPENSITY_SCORE) FROM analytics.dbo.Checking_Propensity_Target_List_20241105

--Select count(*) from analytics.dbo.Checking_Propensity_Target_List_202409
--Select count(*) from analytics.dbo.Checking_Propensity_Target_List_20241105
--Select * from analytics.dbo.Checking_Propensity_Target_List_20241105 order by propensity_score desc


--sELECT PROPENSITY_SCORE,COUNT(*) FROM analytics.dbo.Checking_Propensity_Target_List_20241105 GROUP BY PROPENSITY_SCORE ORDER BY 1


		

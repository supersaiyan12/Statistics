			
alter procedure dbo.Staticpooldateset @staticpooldate as date
as 
	begin
	--declare @staticpooldate as date
	--	set @staticpooldate='2019-04-30'
		
		drop table if exists #Static_SSN_account_final
		drop table if exists ##Static_SSN_account
		drop table if exists #Account_SSN_Name
		drop table if exists #groupproducttype_Deposits
		drop table if exists ##Saving_transaction
		drop table if exists #saving_account_data
		drop table if exists #Deposit_Product_all_data
		drop table if exists ##Checkings_transaction
		drop table if exists #Checkings_account_data
		drop table if exists #masterdata
		drop table if exists #Money_Market_data
		drop table if exists ##1
		drop table if exists ##targetList

		declare @Savings table
		(
		PARENTACCOUNT varchar(25),
		id varchar(10),
		UNID varchar(35),
		OPEN_DATE date,
		CLOSE_DATE date,
		CHARGEOFFDATE date,
		Process_Date date,
		[TYPE] smallint,
		LASTDIVAMOUNT money,
		Month_end_balance money,
		[DESCRIPTION] varchar(50),
		Funded_loan_flag varchar(4)
		)

		insert into @Savings
		select PARENTACCOUNT,
		id,
		CONCAT(PARENTACCOUNT,ID) UNID,
		cast(OPENDATE as date) OPEN_DATE,
		cast(CLOSEDATE as date) CLOSE_DATE,
		cast(CHARGEOFFDATE as date) CHARGEOFFDATE,
		datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) as Process_Date,
		case when OPENDATE = CLOSEDATE then 0 else 1 end Funded_loan_flag,
		[TYPE],
		LASTDIVAMOUNT,
		BALANCE as Month_end_balance,
		[DESCRIPTION] from ARCUSYM000..SAVINGS

		declare @Name table
		(
		SSN varchar(20),
		AccountNumber varchar(20)
		)

		insert into @Name
		select SSN,PARENTACCOUNT as AccountNumber from ARCUSYM000..[NAME]

		select distinct  SSN 
		into #Static_SSN_account_final
		 from
			(select a.*,b.SSN from 
			(select PARENTACCOUNT,id
			,Process_date
			,OPEN_DATE		
			from @Savings
			where CLOSE_DATE is null or CLOSE_DATE > @staticpooldate
			and CHARGEOFFDATE is null or CHARGEOFFDATE > @staticpooldate  
			and Process_Date = @staticpooldate  ) a
			left join @Name b
			on a.PARENTACCOUNT=b.AccountNumber
			) aa
			left join 
			(select ssn SSN1,DATEDIFF(month,min_opendate,@staticpooldate) Savings_ACCT_MOB from
				(select ssn,min(Min_Opendate) Min_Opendate from
					(select PARENTACCOUNT,id,MIn(OPEN_DATE) Min_Opendate
					from @Savings
					group by PARENTACCOUNT,ID ) F
			left join @Name G
			on f.PARENTACCOUNT=g.AccountNumber 
			group by ssn ) A ) AB
		on aa.SSN=ab.SSN1
		where ssn is not null and Savings_ACCT_MOB>=12 and 
		 OPEN_DATE<@staticpooldate  
		
		

		

		
		
	
	
	select distinct 
	AccountNumber,SSN
	into ##Static_SSN_account
	from @Name

	-----------------------------------------------------------------------------------------
	-- 
	select distinct  AccountNumber,ssn 
	Into #Account_SSN_Name
	from @Name
	where AccountNumber not in (select AccountNumber from
	(select AccountNumber,count(distinct ssn) Count_ssn
	from @Name
	group by AccountNumber
	having count(distinct ssn)>1) a )
		

		--  Group by product type

		
		select b.ApplicationTypeID,
		cast(a.ProductCode as int) ProductCode,
		case when a.ProductName like '%money%'  or ProductName like '% MM %' then 'Money Market' else ApplicationDescription end Product_Group_wise,
		b.ApplicationDescription,
		b.ApplicationTableName
		into #groupproducttype_Deposits
		from [AE_EDW].[tempods].[S_CRMProductType] a
		left join [AE_EDW].[tempods].[S_CRMApplicationType] b
		on a.ApplicationTypeID=b.ApplicationTypeID
		where ApplicationDescription is not null
		and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits'
		
		
		--  drop table if exists @Savings_account

		
				-- closed_flag will remove the account closed account in any time 
		
		select ssn,UNID,Process_Date,PARENTACCOUNT,id,TYPE,LASTDIVAMOUNT,Month_end_balance
		--,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE
		,Close_date,OPEN_DATE 
		,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
			when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
			when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
		   ,DATEDIFF(MONTH,OPEN_DATE,@staticpooldate) MOB
		 into #Savings_account 
		from @Savings aa
		left join ##Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join #groupproducttype_Deposits E
		on e.ProductCode=aa.TYPE
		where Process_Date between DATEADD(month,-12,@staticpooldate) and @staticpooldate
		and PARENTACCOUNT in (select AccountNumber from ##Static_SSN_account ) 
		and Product_Group_wise='Savings'  and OPEN_DATE<DATEADD(month,-1,@staticpooldate)
		and (Close_date>@staticpooldate or Close_date is null)
		 -- removed as in staticpool there wont be closed after staticpool
		 -- or Close_date>@staticpooldate)
		and Funded_loan_flag=1 
		order by UNID,Process_Date,TYPE
		

		------------------
		------------------   Transaciton data 

		
		select PARENTACCOUNT,PARENTID,UNID
			,count(*) Transaction_COUNT
			
			,sum(Deposited_amount) Deposited_amount
			,count(Deposited_amount) Deposited_count
			,sum(withdrawl_amount) withdrawal_amount
			,count(withdrawl_amount) withdrawal_count
			,EFFECTIVEDATE
		into ##Saving_transaction
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      ,[POSTDATE]
      ,[POSTTIME]
     
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	 
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
  
  FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
  WHERE PARENTACCOUNT IN (SELECT PARENTACCOUNT FROM #Savings_account)
  and PARENTID in (select ID from #Savings_account) 
   AND ACTIONCODE!='C') A
	where [EFFECTIVEDATE] between DATEADD(month,-12,@staticpooldate) and @staticpooldate
      group by PARENTACCOUNT,PARENTID,UNID,[EFFECTIVEDATE]
			order by PARENTACCOUNT,PARENTID,UNID,[EFFECTIVEDATE]
	 
	 
			

		-- drop table if exists #Deposit_Product_all_data
		
		select a.*
		,b.Transaction_COUNT
		
		,b.Deposited_amount
		,Deposited_count
		,withdrawal_amount
		,withdrawal_count
		into #Deposit_Product_all_data
		 from #Savings_account a
		left join ##Saving_transaction b
		on a.UNID=b.UNID
		and Process_Date=b.EFFECTIVEDATE

		

		-- Drop talbe if exists #Deposit_summary
		select ssn ssn00
		,Sum(LASTDIVAMOUNT) SUM_LASTDIVAMOUNT_Total_Deposit_ACCT
		INTO #Deposit_summary
		from #Deposit_Product_all_data
		where Process_Date=@staticpooldate and SSN is not null
		and OPEN_DATE<@staticpooldate and (Close_date>@staticpooldate or Close_date is null)
		group by ssn
		order by SSN

		
		
		-------------------------------------------------------------------------------------------------------------------
		------------------------------------------------------------------------------------------------------------------

		-------------------------------*************Checking Account ***************-----------------------------------
		              
		
		--  drop table if exists #Checkings_account

				-- closed_flag will remove the account closed account in any time 
		
		
		select ssn,UNID,Process_Date,PARENTACCOUNT,id,TYPE,LASTDIVAMOUNT,Month_end_balance
		--,CHARGEOFFAMOUNT,CHARGEOFFDATE,CHARGEOFFTYPE
		,Close_date,OPEN_DATE 
		,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
			when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
			when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		    when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		    when Process_Date in (@staticpooldate) then 'Staticpool'
		    end Quarters
		   ,DATEDIFF(MONTH,OPEN_DATE,@staticpooldate) MOB
		 into #Checkings_account 
		from @Savings aa
		left join ##Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join #groupproducttype_Deposits E
		on e.ProductCode=aa.TYPE
		where Process_Date between DATEADD(month,-12,@staticpooldate) and @staticpooldate
		and PARENTACCOUNT in (select AccountNumber from ##Static_SSN_account ) 
		and Product_Group_wise='Checking'  and OPEN_DATE<DATEADD(month,-1,@staticpooldate)
		and (Close_date>@staticpooldate or Close_date is null)
		 -- removed as in staticpool there wont be closed after staticpool
		 -- or Close_date>@staticpooldate)
		and Funded_loan_flag=1 
		order by UNID,Process_Date,TYPE

		

		------------------
		------------------   Transaciton data 

			
			-- drop table if exists ##Checkings_transaction
		

		select PARENTACCOUNT,PARENTID,UNID
			,count(*) Transaction_COUNT
			,sum(BALANCECHANGE) Transaction_amount
			,AVG(BALANCECHANGE) AVG_BALANCECHANGE
			,sum(Deposited_amount) Deposited_amount
			,count(Deposited_amount) Deposited_count
			,sum(withdrawl_amount) withdrawal_amount
			,count(withdrawl_amount) withdrawal_count
			
			,[EFFECTIVEDATE]
		into ##Checkings_transaction
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      ,[POSTDATE]
      ,[POSTTIME]
      ,[USERNUMBER]
      ,[USEROVERRIDE]
      ,[SECURITYLEVELS]
      ,[DESCRIPTION]
      ,[ACTIONCODE]
      ,[SOURCECODE]
      ,[BALANCECHANGE]
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
  
  FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
  WHERE PARENTACCOUNT IN (SELECT PARENTACCOUNT FROM #Checkings_account)
  and PARENTID in (select ID from #Checkings_account) 
   AND ACTIONCODE!='C') A
	where EFFECTIVEDATE in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate)
			,DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate)
      group by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE
			order by PARENTACCOUNT,PARENTID,UNID,EFFECTIVEDATE
	 
	
		

		----
		----******///// merging the saving and transaciton table 

		-- drop table if exists #Checkings_account_data
		
		select a.*
		,b.Transaction_COUNT
		,b.Transaction_amount
		,AVG_BALANCECHANGE
		,b.Deposited_amount
		,Deposited_count
		,withdrawal_amount
		,withdrawal_count
		into #Checkings_account_data
		from #Checkings_account a
		left join ##Checkings_transaction b
		on a.UNID=b.UNID
		and a.Process_Date=b.EFFECTIVEDATE
		
		
				 
		--------------------------------------------------------------------------------------------------------------------------------------------
										--  Merging the data
		--------------------------------------------------------------------------------------------------------------------------------------------

		
			---------------------------------------------------------------------------------------------------------------------------
				-------------------MERGING ALL LOAN TALBE---------------------------------------------------------------------------

				-- drop table if exists analytics.dbo.Master_table_April2019
				-- drop table #masterdata
				select AA.SSN
				,Avg_Month_end_balance_Checkings_Staticpool
				,SUM_LASTDIVAMOUNT_Total_Deposit_ACCT
				,sum_Month_end_balance_Checkings_Q3
				,Avg_Month_end_balance_Checkings_Q2
				,avg_Deposited_amount_Checkings_Q2
				

				into
				 #masterdata
				--analytics.dbo.Master_table_April2019
				from 
				(SELECT distinct ssn
				
				 FROM #Static_SSN_account_Final ) AA
			

		-- drop table if exists #Checking
		Left join 
		(

		select aa.SSN SSN20

			,sum(case when Quarters='Q2' then Avg_Month_end_balance_Checkings End) Avg_Month_end_balance_Checkings_Q2
			,sum(case when Quarters='Q2' then avg_Deposited_amount_Checkings End) avg_Deposited_amount_Checkings_Q2
			,sum(case when Quarters='Q3' then sum_Month_end_balance_Checkings End) sum_Month_end_balance_Checkings_Q3
			,sum(case when Quarters='Staticpool' then Avg_Month_end_balance_Checkings End) Avg_Month_end_balance_Checkings_Staticpool
			

			
		from
		(
		select 
		SSN,Quarters
		,avg(Month_end_balance) Avg_Month_end_balance_Checkings
		,sum(Month_end_balance) sum_Month_end_balance_Checkings
		,avg(Deposited_amount) avg_Deposited_amount_Checkings
		
		 from  #Checkings_account_data 
		group by ssn,Quarters ) AA
		left join 
		(		
		select SSN,count(distinct UNID) Total_No_Account_Checkings,count(distinct type) Total_type_account_Checkings
		,min(Open_date) opendate_Checkings,max(CLOSE_DATE) CLOSEDATE_Checkings
		,max(MOB) MOB_Checkings,min(OPEN_DATE) OPEN_DATE_Checkings,max(Close_date) Close_date_Checkings
		 
		 from
		#Checkings_account_data
		group by SSN
		) AB
		on aa.SSN=ab.SSN
		group by aa.SSN,ab.Total_No_Account_Checkings,Total_type_account_Checkings
		,opendate_Checkings,Close_date_Checkings,MOB_Checkings,OPEN_DATE_Checkings,Close_date_Checkings
		 ) U
		ON AA.SSN=U.SSN20
		
		
		left join #Deposit_summary ZZ
		on aa.ssn=zz.ssn00
		order by aa.SSN

		
		--	-- drop table if exists #groupproducttype_Deposits0
		
		--select *
		--,case when ProductName like '%money%'  or ProductName like '% MM %' then 'Money Market' else ApplicationDescription end Product_Group_wise
		--into #groupproducttype_Deposits0
		--from
		--(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName
		--,ApplicationDescription,ApplicationTableName
		-- from [AE_EDW].[tempods].[S_CRMProductType] a
		--left join [AE_EDW].[tempods].[S_CRMApplicationType] b
		--on a.ApplicationTypeID=b.ApplicationTypeID
		--where ApplicationDescription is not null
		--and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a


		
				-- drop table if exists ##1
			select distinct SSN 
			into ##1 from 
			(select *
		,case when Product_Group_wise='Certificates' then 1 else 0 end Target_Certificates
		,case when Product_Group_wise='Savings' then 1 else 0 end Target_Savings
		,case when Product_Group_wise='Checking' then 1 else 0 end Target_Checking
		,case when Product_Group_wise='Money Market' then 1 else 0 end Target_Money_market
		 from  @Savings A
		 left join #groupproducttype_Deposits b
		on a.type=b.ProductCode
		where Process_date=@staticpooldate ) BB
		left join @Name c
		on BB.PARENTACCOUNT=c.AccountNumber
		where target_money_market=0  

		

		select SSN
		,case when Avg_Month_end_balance_Checkings_Staticpool is null or Avg_Month_end_balance_Checkings_Staticpool <=4461.002  then -69.1
		when Avg_Month_end_balance_Checkings_Staticpool >4461.002 then 137.2
		end Avg_Month_end_balance_Checkings_Staticpool

		,case when sum_Month_end_balance_Checkings_Q3 is null or sum_Month_end_balance_Checkings_Q3 <= 16314.495 then -68.6
		when sum_Month_end_balance_Checkings_Q3 >16314.495 then 136.8 end sum_Month_end_balance_Checkings_Q3

		,case when Avg_Month_end_balance_Checkings_Q2 is null or Avg_Month_end_balance_Checkings_Q2 <= 4942.6883 then -69.4
		when Avg_Month_end_balance_Checkings_Q2 >4942.6883 then 137.4 end Avg_Month_end_balance_Checkings_Q2

		,case when avg_Deposited_amount_Checkings_Q2 is null then -65.6
		when avg_Deposited_amount_Checkings_Q2 <= 4473.04566 then 5.2
		when avg_Deposited_amount_Checkings_Q2 >4473.04566 then 98.4 end avg_Deposited_amount_Checkings_Q2

		,case when SUM_LASTDIVAMOUNT_Total_Deposit_ACCT is null or SUM_LASTDIVAMOUNT_Total_Deposit_ACCT <= 0 then -2.3
		when SUM_LASTDIVAMOUNT_Total_Deposit_ACCT <= 0.05 then -69.8 
		when SUM_LASTDIVAMOUNT_Total_Deposit_ACCT >0.05 then 51.5 
		
		end SUM_LASTDIVAMOUNT_Total_Deposit_ACCT
		into #Money_Market_data
		from 
		#masterdata


			select * 
			,NTILE (10) OVER ( order by Ranks) Decile
			into ##targetList
			from
			(select *
		
			,Row_number() over(order by score desc)  Ranks
			from
			(
				select * 
		
				,EXP(0.02008+(0.00008164*Avg_Month_end_balance_Checkings_Staticpool)+(0.00006058*SUM_LASTDIVAMOUNT_Total_Deposit_ACCT)
				+(0.00006887*sum_Month_end_balance_Checkings_Q3)
				+(0.00005089*Avg_Month_end_balance_Checkings_Q2)+(0.000006755*avg_Deposited_amount_Checkings_Q2))
				/(1+EXP(0.02008+(0.00008164*Avg_Month_end_balance_Checkings_Staticpool)+(0.00006058*SUM_LASTDIVAMOUNT_Total_Deposit_ACCT)
				+(0.00006887*sum_Month_end_balance_Checkings_Q3)
				+(0.00005089*Avg_Month_end_balance_Checkings_Q2)+(0.000006755*avg_Deposited_amount_Checkings_Q2)))   as score
				from #Money_Market_data ) a ) B
				order by score desc

			end	
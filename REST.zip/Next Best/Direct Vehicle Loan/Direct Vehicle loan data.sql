
	
	
	

	 go

	  -- drop table if exists #1
		select distinct  SSN,AccountNumber PARENTACCOUNT  
		into #1 
		from AE_EDW..D_Member
		where SSN is not null	

		go

		-- drop table if exists #multi_SSN
		select PARENTACCOUNT,count(distinct SSN) Counts 
		into #multi_SSN
		from #1
		group by PARENTACCOUNT
		having count(distinct SSN)>1

		go

		select * 
		into #11
		from #1
		where ssn not in (select PARENTACCOUNT from #multi_SSN)

		go
		--	drop table if exists #2
		select distinct  SSN,PARENTACCOUNT
		 into #2
		 from ARCUSYM000..NAME
		 where PARENTACCOUNT not in (select PARENTACCOUNT from #11)
		 and SSN is not null
			
			go

			select PARENTACCOUNT,count(distinct SSN) Counts 
			into #3
			from #2
			group by PARENTACCOUNT
		having count(distinct SSN)>1

			go

			select * 
			into #22
			from #2
			where PARENTACCOUNT not in (select PARENTACCOUNT from #3 )
			-- drop table if exists analytics..R2_CC_Member
			--select * 
			--into analytics..R2_CC_Member
			--from
			--(select * from #NAME3
			--union
			--select * from #member_ssn ) A

			go
			-- drop table if exists #NAME
			select * 
			into #NAME
			from
			(select * from #11
			union
			select * from #22 ) A
	 
	 go
	 -- Drop table if exists #Direct_Vehicle_loan
	 select * 
		into #Direct_Vehicle_loan
		from 
	 (select distinct  a.PARENTACCOUNT,id,a.type,OPEN_DATE,CLOSE_DATE,b.loancategory1,SSN,LoanType
		,case when OPEN_DATE >'2018-04-30'  then 1 else 0 end Direct_vehicle_loan_Flag
		
		from (select PARENTACCOUNT,id
		,TYPE
		,cast (OPENDATE as date) Open_date
		,cast (CLOSEDATE as date) Close_date from [ARCUSYM000]..loan) as a
	 left join ARCUSYM000.arcu.ARCULoanCategory b
	 on a.type=b.LoanType
	 left join #NAME C
		on a.PARENTACCOUNT=c.PARENTACCOUNT
		) AA
		where LoanType in (601,611,600,610,1,3,70,0,2)

		go
		-- drop table if exists Analytics..Master_table_April2018
		select a.*
		,case when Direct_vehicle_loan_Flag is null or Direct_vehicle_loan_Flag=0 then 0 else 1 end Direct_vehicle_loan_Flag
	into Analytics..Direct_vehicle_loan
	from
	 Analytics..Master_table_April2018 a
	 left join #Direct_Vehicle_loan b
	 on a.ssn=b.SSN
	 where (Staticpool_Vehicles_loan_flag=0 or Staticpool_Vehicles_loan_flag is null) 


	 
###################################### Next Best Product Certificates Model (12/26/2022) ###############################
## STATIC POOL : 9/30/2021

# Loading the Train Data :

rm(list=ls())
getwd()
install.packages('RODBC')
library(RODBC)
databaseConnection <- odbcDriverConnect("Driver={SQL Server};server=ACARCU01;trusted_connection=true")
CD_train <- sqlQuery(databaseConnection, "select * from  [Analytics].[dbo].[NBP_Certificates_train_202209]")
CD_train <- data.frame(CD_train,stringsAsFactors=FALSE)
dim(CD_train) # 977 vars 185291 rows

# Loading the Test data

CD_test <- sqlQuery(databaseConnection, "select * from  [Analytics].[dbo].[NBP_Certificates_test_202209]")
CD_test <- data.frame(CD_test,stringsAsFactors=FALSE)
dim(CD_test) # 977 vars 79410 rows

##1. Extracting out the date and char variable.

type = sapply(CD_train,class)
write.csv(type,"CLASS OF Certificates.csv")

df1 = CD_train[,!sapply(CD_train,is.character)]   ## Excluding character variable
dim(df1) # 976 vars

install.packages("lubridate")
library(lubridate)
df2 =  df1[,!sapply(df1,is.POSIXct)]   ## Excluding date variable
dim(df2) # 962 vars

df3 =  df2[,!sapply(df2,is.factor)]   ## Here factor variables also contains the date variables. So removing it
dim(df3) # 962 vars

df4 =  df3[,!sapply(df3,is.logical)]   ## Here logical variables also contains NULL variables. So removing it
dim(df4) # 910 vars

### 2. Removing the i.i.d. variables (Uniqueidentifier variables)

df5 = subset(df4,select = - c(SSN,SSN_CC,SSN001,SSN002,SSN003,SSN004))
dim(df5) # 904 vars

### 3. Creating the summary function

Summary_Function <- function(data)
{
  a <- data.frame()
  e <- data.frame()
  f <- data.frame()
  G <- data.frame()
  H <- data.frame()
  I <- data.frame()
  J <- data.frame()
  K <- data.frame()
  L <- data.frame()
  M <- data.frame()
  N <- data.frame()
  Col_bined <- data.frame()
  
  
  for (i in 1:ncol(data))
  {
    if(class(data[,c(i)])!="factor") {
      Total_count <- NROW(data)-(sum(is.na(data[,c(i)]))+sum(data[,c(i)]==0,na.rm = TRUE))
      Count_NA <- data.frame(sum(is.na(data[,c(i)])))
      Count_zero <- data.frame(sum(data[,c(i)]==0,na.rm = TRUE))
      Mean_1 <- data.frame(mean(data[,c(i)],na.rm = TRUE))
      Median_1 <- data.frame(median(data[,c(i)],na.rm = TRUE))
      std <- data.frame(sd(data[,c(i)],na.rm = TRUE))
      Max_1 <- data.frame(max(data[,c(i)],na.rm = TRUE))
      Min_1 <- data.frame(min(data[,c(i)],na.rm = TRUE))
      b <-data.frame(colnames(data)[i],quantile(data[,c(i)],.25,na.rm = TRUE))
      c <-data.frame(quantile(data[,c(i)],.75,na.rm = TRUE))
      d <-data.frame(quantile(data[,c(i)],.99,na.rm = TRUE))
      row.names(Count_NA) <- NULL
      row.names(Count_zero) <- NULL
      row.names(Mean_1) <- NULL
      row.names(Median_1) <- NULL
      row.names(std) <- NULL
      row.names(Max_1) <- NULL
      row.names(Min_1) <- NULL
      row.names(Total_count) <- NULL
      row.names(b) <- NULL
      row.names(c) <- NULL
      row.names(d) <- NULL
      
      a <- rbind(b,a)
      e <- rbind(c,e)
      f <- rbind(d,f)
      
      G <- rbind(Count_NA,G)
      H <- rbind(Count_zero,H)
      I <- rbind(Mean_1,I)
      J <- rbind(Median_1,J)
      K <- rbind(Max_1,K)
      L <- rbind(Min_1,L)
      M <- rbind(std,M)
      N <- rbind(Total_count,N)
      Col_bined <- data.frame(cbind(a,e,f,N,G,H,I,J,M,K,L))
      colnames(Col_bined) <- c("Variables","Percentile 25%","Percentile 75%","Percentile 99%"
                               ,"Total_No_obs","Count_NA","Count_zero","Mean","Median","Standard_Deviation","Max","Min")
      
    }
    
  }
  
  Col_bined1<- data.frame(apply(Col_bined,2,rev))
  
  write.csv(Col_bined1,"Summary of Certificates Propensity Model.csv")
}


Summary_Function(df5)

# 2. NULL VARIABLE REMOVAL :

df6 = subset(df5,select = -c(AVG_CHARGEOFFAMOUNT_SAVINGS_SP,
                             AVG_CHARGEOFFAMOUNT_SAVINGS_Q1,
                             DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q2,
                             DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q3,
                             AVG_CHARGEOFFAMOUNT_CHECKING_SP,
                             AVG_CHARGEOFFAMOUNT_CHECKING_Q1,
                             DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q2,
                             DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q3,
                             AVG_CHARGEOFFAMOUNT_MONEYMARKET_SP,
                             AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1,
                             DFT_AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1_Q2,
                             DFT_AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1_Q3,
                             AVG_CHARGEOFFAMOUNT_IRA_Q1,
                             DFT_AVG_CHARGEOFFAMOUNT_IRA_Q1_Q2,
                             PRODUCT_HSA_SP,
                             PRODUCT_HSA_Q1,
                             DFT_PRODUCT_HSA_Q1_Q2,
                             DFT_PRODUCT_HSA_Q1_Q3,
                             TYPE_HSA_SP,
                             TYPE_HSA_Q1,
                             DFT_TYPE_HSA_Q1_Q2,
                             DFT_TYPE_HSA_Q1_Q3,
                             MOB_HSA,
                             AVG_CHARGEOFFAMOUNT_DEPOSITS_SP,
                             AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1,
                             DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q2,
                             DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q3,
                             HSA_StaticpoolFlag,
                             HSA_Q1Flag,
                             SUM_INTEREST_SAVINGS_Q1,
                             DFT_SUM_INTEREST_SAVINGS_Q1_Q2,
                             DFT_SUM_INTEREST_SAVINGS_Q1_Q3,
                             SUM_INTEREST_CHECKING_Q1,
                             DFT_SUM_INTEREST_CHECKING_Q1_Q2,
                             DFT_SUM_INTEREST_CHECKING_Q1_Q3,
                             SUM_INTEREST_MONEYMARKET_Q1,
                             DFT_SUM_INTEREST_MONEYMARKET_Q1_Q2,
                             DFT_SUM_INTEREST_MONEYMARKET_Q1_Q3,
                             SUM_INTEREST_IRA_Q1,
                             DFT_SUM_INTEREST_IRA_Q1_Q2,
                             DFT_SUM_INTEREST_IRA_Q1_Q3,
                             TRANSACTION_COUNT_HSA_Q1,
                             DFT_TRANSACTION_COUNT_HSA_Q1_Q2,
                             DFT_TRANSACTION_COUNT_HSA_Q1_Q3,
                             WITHDRAWAL_COUNT_HSA_Q1,
                             DFT_WITHDRAWAL_COUNT_HSA_Q1_Q2,
                             DFT_WITHDRAWAL_COUNT_HSA_Q1_Q3,
                             PRODUCT_CommercialLoan_Q1,
                             DFT_PRODUCT_CommercialLoan_Q1_Q2,
                             DFT_PRODUCT_CommercialLoan_Q1_Q3,
                             PRODUCT_Others_Q1,
                             DFT_PRODUCT_Others_Q1_Q2,
                             DFT_PRODUCT_Others_Q1_Q3,
                             TYPE_CommercialLoan_Q1,
                             DFT_TYPE_CommercialLoan_Q1_Q2,
                             DFT_TYPE_CommercialLoan_Q1_Q3,
                             TYPE_Others_Q1,
                             DFT_TYPE_Others_Q1_Q2,
                             DFT_TYPE_Others_Q1_Q3,
                             CommercialLoan_MOB,
                             Others_MOB,
                             PAYMENTCOUNT_CommercialLoan_Q1,
                             DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q2,
                             DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q3,
                             PAYMENTCOUNT_Others_Q1,
                             DFT_PAYMENTCOUNT_Others_Q1_Q2,
                             DFT_PAYMENTCOUNT_Others_Q1_Q3,
                             SUM_OriginalBalance_Others_Q1,
                             DFT_SUM_OriginalBalance_Others_Q1_Q2,
                             DFT_SUM_OriginalBalance_Others_Q1_Q3,
                             SUM_PAYMENT_Others_Q1,
                             DFT_SUM_PAYMENT_Others_Q1_Q2,
                             DFT_SUM_PAYMENT_Others_Q1_Q3,
                             MAX_INTERESTRATE_CommercialLoan_Q1,
                             DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q2,
                             DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q3,
                             MAX_INTERESTRATE_Others_Q1,
                             DFT_MAX_INTERESTRATE_Others_Q1_Q2,
                             DFT_MAX_INTERESTRATE_Others_Q1_Q3,
                             MAX_CREDITLIMIT_RealEstate_Q1,
                             DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q2,
                             DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q3,
                             MAX_CREDITLIMIT_SecuredLoan_Q1,
                             DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q2,
                             DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q3,
                             MAX_CREDITLIMIT_UnsecuredLoan_Q1,
                             DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q2,
                             DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q3,
                             MAX_CREDITLIMIT_VehicleLoan_Q1,
                             DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q2,
                             DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q3,
                             MAX_CREDITLIMIT_Others_Q1,
                             DFT_MAX_CREDITLIMIT_Others_Q1_Q2,
                             DFT_MAX_CREDITLIMIT_Others_Q1_Q3,
                             MAX_CREDITLIMIT_Loan_Q1,
                             DFT_MAX_CREDITLIMIT_Loan_Q1_Q2,
                             DFT_MAX_CREDITLIMIT_Loan_Q1_Q3,
                             CommercialLoan_Month_to_Maturity,
                             Others_Month_to_Maturity,
                             CommercialLoan_StaticPoolFlag,
                             CommercialLoan_Q1Flag,
                             COUNT_PAYROLL_STATICPOOL,
                             COUNT_PAYROLL_Q1,
                             DFT_COUNT_PAYROLL_Q1_Q2,
                             DFT_COUNT_PAYROLL_Q1_Q3,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_STATICPOOL,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_Q1,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q2,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q3,
                             COUNT_LOAN_ADDON_CommercialLoan_Q1,
                             DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q2,
                             DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q3,
                             COUNT_NEW_LOAN_CommercialLoan_Q1,
                             COUNT_NEW_LOAN_CommercialLoan_Q1_Q2,
                             COUNT_NEW_LOAN_CommercialLoan_Q1_Q3,
                             COUNT_LOAN_PAYMENT_CommercialLoan_Q1,
                             DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q2,
                             DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q3,
                             COUNT_CASH_CommercialLoan_Q1,
                             DFT_COUNT_CASH_CommercialLoan_Q1_Q2,
                             DFT_COUNT_CASH_CommercialLoan_Q1_Q3,
                             COUNT_DRAFT_CommercialLoan_Q1,
                             DFT_COUNT_DRAFT_CommercialLoan_Q1_Q2,
                             DFT_COUNT_DRAFT_CommercialLoan_Q1_Q3,
                             COUNT_ACH_CommercialLoan_Q1,
                             DFT_COUNT_ACH_CommercialLoan_Q1_Q2,
                             DFT_COUNT_ACH_CommercialLoan_Q1_Q3,
                             COUNT_FEE_CommercialLoan_Q1,
                             DFT_COUNT_FEE_CommercialLoan_Q1_Q2,
                             DFT_COUNT_FEE_CommercialLoan_Q1_Q3,
                             COUNT_HOMEBANKING_CommercialLoan_Q1,
                             DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q2,
                             DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q3,
                             COUNT_INSURANCE_CommercialLoan_Q1,
                             DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q2,
                             DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q3,
                             COUNT_CHECKS_CommercialLoan_Q1,
                             DFT_COUNT_CHECKS_CommercialLoan_Q1_Q2,
                             DFT_COUNT_CHECKS_CommercialLoan_Q1_Q3,
                             COUNT_PAYROLL_CommercialLoan_Q1,
                             DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q2,
                             DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q3,
                             COUNT_KIOSK_CommercialLoan_Q1,
                             DFT_COUNT_KIOSK_CommercialLoan_Q1_Q2,
                             DFT_COUNT_KIOSK_CommercialLoan_Q1_Q3,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q2,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q3,
                             COUNT_PAYROLL_RealEstate_Q1,
                             DFT_COUNT_PAYROLL_RealEstate_Q1_Q2,
                             DFT_COUNT_PAYROLL_RealEstate_Q1_Q3,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q2,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q3,
                             COUNT_PAYROLL_SecuredLoan_Q1,
                             DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q2,
                             DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q3,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q2,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q3,
                             COUNT_PAYROLL_UnsecuredLoan_Q1,
                             DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q2,
                             DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q3,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q2,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q3,
                             COUNT_PAYROLL_VehicleLoan_Q1,
                             DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q2,
                             DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q3,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q2,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q3,
                             COUNT_LOAN_ADDON_Others_Q1,
                             DFT_COUNT_LOAN_ADDON_Others_Q1_Q2,
                             DFT_COUNT_LOAN_ADDON_Others_Q1_Q3,
                             COUNT_NEW_LOAN_Others_Q1,
                             COUNT_NEW_LOAN_Others_Q1_Q2,
                             COUNT_NEW_LOAN_Others_Q1_Q3,
                             COUNT_LOAN_PAYMENT_Others_Q1,
                             DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q2,
                             DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q3,
                             COUNT_CASH_Others_Q1,
                             DFT_COUNT_CASH_Others_Q1_Q2,
                             DFT_COUNT_CASH_Others_Q1_Q3,
                             COUNT_DRAFT_Others_Q1,
                             DFT_COUNT_DRAFT_Others_Q1_Q2,
                             DFT_COUNT_DRAFT_Others_Q1_Q3,
                             COUNT_ACH_Others_Q1,
                             DFT_COUNT_ACH_Others_Q1_Q2,
                             DFT_COUNT_ACH_Others_Q1_Q3,
                             COUNT_FEE_Others_Q1,
                             DFT_COUNT_FEE_Others_Q1_Q2,
                             DFT_COUNT_FEE_Others_Q1_Q3,
                             COUNT_HOMEBANKING_Others_Q1,
                             DFT_COUNT_HOMEBANKING_Others_Q1_Q2,
                             DFT_COUNT_HOMEBANKING_Others_Q1_Q3,
                             COUNT_INSURANCE_Others_Q1,
                             DFT_COUNT_INSURANCE_Others_Q1_Q2,
                             DFT_COUNT_INSURANCE_Others_Q1_Q3,
                             COUNT_CHECKS_Others_Q1,
                             DFT_COUNT_CHECKS_Others_Q1_Q2,
                             DFT_COUNT_CHECKS_Others_Q1_Q3,
                             COUNT_PAYROLL_Others_Q1,
                             DFT_COUNT_PAYROLL_Others_Q1_Q2,
                             DFT_COUNT_PAYROLL_Others_Q1_Q3,
                             COUNT_KIOSK_Others_Q1,
                             DFT_COUNT_KIOSK_Others_Q1_Q2,
                             DFT_COUNT_KIOSK_Others_Q1_Q3,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q2,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q3,
                             LOAN_TRANSACTION_AMOUNT_Others_Q1,
                             DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q2,
                             DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q3,
                             INTEREST_AMOUNT_Others_Q1,
                             DFT_INTEREST_AMOUNT_Others_Q1_Q2,
                             DFT_INTEREST_AMOUNT_Others_Q1_Q3,
                             FEEAMOUNT_Others_Q1,
                             DFT_FEEAMOUNT_Others_Q1_Q2,
                             DFT_FEEAMOUNT_Others_Q1_Q3,
                             AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1,
                             DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q2,
                             DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q3,
                             AVG_NEWBALANCE_Others_Q1,
                             DFT_AVG_NEWBALANCE_Others_Q1_Q2,
                             DFT_AVG_NEWBALANCE_Others_Q1_Q3,
                             AVG_FEEAMOUNT_Others_Q1,
                             DFT_AVG_FEEAMOUNT_Others_Q1_Q2,
                             DFT_AVG_FEEAMOUNT_Others_Q1_Q3,
                             Last.Statement.External.Fee.Amount_CC_Q1,
                             DFT_Last.Statement.External.Fee.Amount_CC_Q1_Q2,
                             DFT_Last.Statement.External.Fee.Amount_CC_Q1_Q3,
                             Last.Statement.Credit.Life.Change.Amount_CC_Q1,
                             DFT_Last.Statement.Credit.Life.Change.Amount_CC_Q1_Q2,
                             DFT_Last.Statement.Credit.Life.Change.Amount_CC_Q1_Q3,
                             Last.Statement.Charge.Overlimit.Amount_CC_Q1,
                             DFT_Last.Statement.Charge.Overlimit.Amount_CC_Q1_Q2,
                             DFT_Last.Statement.Charge.Overlimit.Amount_CC_Q1_Q3,
                             FICO,
                             ForeclosureCountP12Months,
                             ForeclosureTotalBalance))
dim(df6) # 663 vars


##5.WOE binning

# a. WOE Binning on train data

df6$CreditCard_StaticpoolFlag = replace(df6$CreditCard_StaticpoolFlag,is.na(df6$CreditCard_StaticpoolFlag),0)
df6$CreditCard_Q1Flag = replace(df6$CreditCard_Q1Flag,is.na(df6$CreditCard_Q1Flag),0)

df6$RealEstate_StaticPoolFlag = replace(df6$RealEstate_StaticPoolFlag,is.na(df6$RealEstate_StaticPoolFlag),0)
df6$RealEstate_Q1Flag = replace(df6$RealEstate_Q1Flag,is.na(df6$RealEstate_Q1Flag),0)

df6$SecuredLoan_StaticPoolFlag = replace(df6$SecuredLoan_StaticPoolFlag,is.na(df6$SecuredLoan_StaticPoolFlag),0)
df6$SecuredLoan_Q1Flag = replace(df6$SecuredLoan_Q1Flag,is.na(df6$SecuredLoan_Q1Flag),0)

df6$UnsecuredLoan_StaticPoolFlag = replace(df6$UnsecuredLoan_StaticPoolFlag,is.na(df6$UnsecuredLoan_StaticPoolFlag),0)
df6$UnsecuredLoan_Q1Flag = replace(df6$UnsecuredLoan_Q1Flag,is.na(df6$UnsecuredLoan_Q1Flag),0)

df6$VehicleLoan_StaticPoolFlag = replace(df6$VehicleLoan_StaticPoolFlag,is.na(df6$VehicleLoan_StaticPoolFlag),0)
df6$VehicleLoan_Q1Flag = replace(df6$VehicleLoan_Q1Flag,is.na(df6$VehicleLoan_Q1Flag),0)

df6$MONEYMARKET_StaticpoolFlag = replace(df6$MONEYMARKET_StaticpoolFlag ,is.na(df6$MONEYMARKET_StaticpoolFlag ),0)
df6$MONEYMARKET_Q1Flag = replace(df6$MONEYMARKET_Q1Flag,is.na(df6$MONEYMARKET_Q1Flag),0)

df6$CHECKING_StaticpoolFlag = replace(df6$CHECKING_StaticpoolFlag,is.na(df6$CHECKING_StaticpoolFlag),0)
df6$CHECKING_Q1Flag = replace(df6$CHECKING_Q1Flag,is.na(df6$CHECKING_Q1Flag),0)

df6$SAVINGS_StaticpoolFlag = replace(df6$SAVINGS_StaticpoolFlag,is.na(df6$SAVINGS_StaticpoolFlag),0)
df6$SAVINGS_Q1Flag = replace(df6$SAVINGS_Q1Flag,is.na(df6$SAVINGS_Q1Flag),0)

df6$IRA_StaticpoolFlag = replace(df6$IRA_StaticpoolFlag,is.na(df6$IRA_StaticpoolFlag),0)
df6$IRA_Q1Flag = replace(df6$IRA_Q1Flag,is.na(df6$IRA_Q1Flag),0)

# df6$HSA_StaticpoolFlag = replace(df6$HSA_StaticpoolFlag,is.na(df6$HSA_StaticpoolFlag),0)
# df6$HSA_Q1Flag = replace(df6$HSA_Q1Flag,is.na(df6$HSA_Q1Flag),0)

NAReplace_train <- replace(df6,is.na(df6),-9999999)
sum(is.na(NAReplace_train)) 

install.packages("woeBinning")
library(woeBinning)

CD_binning_model <- woe.binning(NAReplace_train,'CD_TargetFlag',NAReplace_train)
CD_train_woe <- woe.binning.deploy(NAReplace_train,CD_binning_model,add.woe.or.dum.var = "woe")
index_number4 <- colnames(CD_train_woe)
write.csv(index_number4,"Combined CERTIFICATES WOE variables.csv") 

df_train_woe = subset(CD_train_woe,select = c(woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned,
                                              woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned,
                                              woe.DEPOSITED_COUNT_MONEYMARKET_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_MONEYMARKET_Q1.binned,
                                              woe.AVG_BALANCECHANGE_MONEYMARKET_Q1.binned,
                                              woe.TRANSACTION_AMOUNT_MONEYMARKET_Q1.binned,
                                              woe.TRANSACTION_COUNT_MONEYMARKET_Q1.binned,
                                              woe.MONEYMARKET_StaticpoolFlag.binned,
                                              woe.TYPE_MONEYMARKET_SP.binned,
                                              woe.PRODUCT_MONEYMARKET_SP.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q2.binned,
                                              woe.DFT_AVG_BALANCECHANGE_MONEYMARKET_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q3.binned,
                                              woe.DFT_AVG_BALANCECHANGE_MONEYMARKET_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q3.binned,
                                              woe.MOB_MONEYMARKET.binned,
                                              woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned,
                                              woe.MONEYMARKET_Q1Flag.binned,
                                              woe.SUM_LASTDIVAMOUNT_MONEYMARKET_Q1.binned,
                                              woe.AVG_MONTH_END_BALANCE_MONEYMARKET_Q1.binned,
                                              woe.TYPE_MONEYMARKET_Q1.binned,
                                              woe.PRODUCT_MONEYMARKET_Q1.binned,
                                              woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q3.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q3.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned,
                                              woe.WITHDRAWAL_COUNT_DEPOSITS_Q1.binned,
                                              woe.TRANSACTION_COUNT_DEPOSITS_Q1.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.SUM_INTEREST_DEPOSITS_Q1.binned,
                                              woe.DEPOSITED_COUNT_DEPOSITS_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned,
                                              woe.TRANSACTION_AMOUNT_DEPOSITS_Q1.binned,
                                              woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned,
                                              woe.PRODUCT_DEPOSITS_Q1.binned,
                                              woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_SUM_INTEREST_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.PRODUCT_DEPOSITS_SP.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_SUM_INTEREST_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.TYPE_DEPOSITS_Q1.binned,
                                              woe.MAX_INTERESTRATE_Loan_Q1.binned,
                                              woe.MAX_INTERESTRATE_VehicleLoan_Q1.binned,
                                              woe.MAX_Loan_MOB.binned,
                                              woe.DFT_TYPE_Loan_Q1_Q3.binned,
                                              woe.DFT_TYPE_Loan_Q1_Q2.binned,
                                              woe.TYPE_Loan_Q1.binned,
                                              woe.DFT_TYPE_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_TYPE_VehicleLoan_Q1_Q2.binned,
                                              woe.TYPE_VehicleLoan_Q1.binned,
                                              woe.DFT_TYPE_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_TYPE_UnsecuredLoan_Q1_Q2.binned,
                                              woe.TYPE_UnsecuredLoan_Q1.binned,
                                              woe.DFT_TYPE_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_TYPE_SecuredLoan_Q1_Q2.binned,
                                              woe.TYPE_SecuredLoan_Q1.binned,
                                              woe.DFT_TYPE_RealEstate_Q1_Q3.binned,
                                              woe.DFT_TYPE_RealEstate_Q1_Q2.binned,
                                              woe.TYPE_RealEstate_Q1.binned,
                                              woe.DFT_PRODUCT_Loan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_Loan_Q1_Q2.binned,
                                              woe.PRODUCT_Loan_Q1.binned,
                                              woe.DFT_PRODUCT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_VehicleLoan_Q1_Q2.binned,
                                              woe.PRODUCT_VehicleLoan_Q1.binned,
                                              woe.DFT_PRODUCT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.PRODUCT_UnsecuredLoan_Q1.binned,
                                              woe.DFT_PRODUCT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_SecuredLoan_Q1_Q2.binned,
                                              woe.PRODUCT_SecuredLoan_Q1.binned,
                                              woe.DFT_PRODUCT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_RealEstate_Q1_Q2.binned,
                                              woe.PRODUCT_RealEstate_Q1.binned,
                                              woe.Max_Loan_Month_to_Maturity.binned,
                                              woe.DFT_MAX_INTERESTRATE_Loan_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_Loan_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_Loan_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_Loan_Q1_Q2.binned,
                                              woe.WITHDRAWAL_COUNT_CHECKING_Q1.binned,
                                              woe.DFT_MAX_INTERESTRATE_Loan_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_Loan_Q1_Q3.binned,
                                              woe.DFT_SUM_OriginalBalance_Loan_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_Loan_Q1_Q3.binned,
                                              woe.SUM_PAYMENT_Loan_Q1.binned,
                                              woe.SUM_OriginalBalance_Loan_Q1.binned,
                                              woe.PAYMENTCOUNT_Loan_Q1.binned,
                                              woe.OpenTradeBalance.binned,
                                              woe.DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned,
                                              woe.VehicleLoan_Q1Flag.binned,
                                              woe.SUM_PAYMENT_VehicleLoan_Q1.binned,
                                              woe.SUM_OriginalBalance_VehicleLoan_Q1.binned,
                                              woe.PAYMENTCOUNT_VehicleLoan_Q1.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_IRA_Q1_Q2.binned,
                                              woe.WITHDRAWAL_COUNT_IRA_Q1.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q2.binned,
                                              woe.WITHDRAWAL_COUNT_MONEYMARKET_Q1.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned,
                                              woe.WITHDRAWAL_COUNT_SAVINGS_Q1.binned,
                                              woe.DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.Vehicleloan_MOB.binned,
                                              woe.Vehicleloan_Month_to_Maturity.binned,
                                              woe.VehicleLoan_StaticPoolFlag.binned,
                                              woe.DFT_COUNT_KIOSK_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_Q1_Q3.binned,
                                              woe.DFT_COUNT_NEW_LOAN_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_Q1_Q3.binned,
                                              woe.COUNT_HOMEBANKING_Q1.binned,
                                              woe.COUNT_ACH_Q1.binned,
                                              woe.DFT_COUNT_KIOSK_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_Q1_Q2.binned,
                                              woe.DFT_COUNT_NEW_LOAN_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_Q1_Q2.binned,
                                              woe.AutoOpenTradeCount.binned,
                                              woe.AutoOpenTradeBalance.binned,
                                              woe.AutoLoanOrgBalanceP12Months.binned,
                                              woe.CCRevolvingBalance.binned,
                                              woe.COUNT_HOMEBANKING_STATICPOOL.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q3.binned,
                                              woe.COUNT_KIOSK_Q1.binned,
                                              woe.COUNT_CHECKS_Q1.binned,
                                              woe.COUNT_INSURANCE_Q1.binned,
                                              woe.COUNT_FEE_Q1.binned,
                                              woe.COUNT_DRAFT_Q1.binned,
                                              woe.COUNT_CASH_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_Q1.binned,
                                              woe.COUNT_NEW_LOAN_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_Q1.binned,
                                              woe.COUNT_ACH_STATICPOOL.binned,
                                              woe.AutoWorstRatingP12Months.binned,
                                              woe.COUNT_ACH_VehicleLoan_Q1.binned,
                                              woe.DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_FEEAMOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_KIOSK_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q3.binned,
                                              woe.COUNT_NEW_LOAN_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned,
                                              woe.COUNT_KIOSK_STATICPOOL.binned,
                                              woe.COUNT_CHECKS_STATICPOOL.binned,
                                              woe.COUNT_INSURANCE_STATICPOOL.binned,
                                              woe.COUNT_FEE_STATICPOOL.binned,
                                              woe.COUNT_DRAFT_STATICPOOL.binned,
                                              woe.COUNT_CASH_STATICPOOL.binned,
                                              woe.COUNT_LOAN_PAYMENT_STATICPOOL.binned,
                                              woe.COUNT_NEW_LOAN_STATICPOOL.binned,
                                              woe.COUNT_LOAN_ADDON_STATICPOOL.binned,
                                              woe.SUM_LASTDIVAMOUNT_CHECKING_Q1.binned,
                                              woe.DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_FEEAMOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_KIOSK_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q2.binned,
                                              woe.COUNT_NEW_LOAN_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q2.binned,
                                              woe.AVG_FEEAMOUNT_VehicleLoan_Q1.binned,
                                              woe.AVG_NEWBALANCE_VehicleLoan_Q1.binned,
                                              woe.AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1.binned,
                                              woe.FEEAMOUNT_VehicleLoan_Q1.binned,
                                              woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned,
                                              woe.LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1.binned,
                                              woe.COUNT_KIOSK_VehicleLoan_Q1.binned,
                                              woe.COUNT_CHECKS_VehicleLoan_Q1.binned,
                                              woe.COUNT_INSURANCE_VehicleLoan_Q1.binned,
                                              woe.COUNT_HOMEBANKING_VehicleLoan_Q1.binned,
                                              woe.COUNT_FEE_VehicleLoan_Q1.binned,
                                              woe.COUNT_DRAFT_VehicleLoan_Q1.binned,
                                              woe.COUNT_CASH_VehicleLoan_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_VehicleLoan_Q1.binned,
                                              woe.COUNT_NEW_LOAN_VehicleLoan_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_VehicleLoan_Q1.binned,
                                              woe.MOB_DEPOSITS.binned,
                                              woe.AVG_BALANCECHANGE_CHECKING_Q1.binned,
                                              woe.TRANSACTION_COUNT_CHECKING_Q1.binned,
                                              woe.StudentLoanOpenBalance.binned,
                                              woe.StudentLoanOpenCount.binned,
                                              woe.CCAPREstimate.binned,
                                              woe.MOB_SAVINGS.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned,
                                              woe.CCOpenBalance.binned,
                                              woe.TRANSACTION_AMOUNT_CHECKING_Q1.binned,
                                              woe.CCTotalAvailableLOC.binned,
                                              woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2.binned,
                                              woe.MOB_CHECKING.binned,
                                              woe.NumberInquiriesP6Months.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned,
                                              woe.SUM_LASTDIVAMOUNT_SAVINGS_Q1.binned,
                                              woe.DEPOSITED_COUNT_CHECKING_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_CHECKING_Q1.binned,
                                              woe.DFT_PRODUCT_MONEYMARKET_Q1_Q3.binned,
                                              woe.MortgageOpenCount.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_COUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_COUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_AVG_BALANCECHANGE_IRA_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_COUNT_IRA_Q1_Q3.binned,
                                              woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned,
                                              woe.DFT_TYPE_MONEYMARKET_Q1_Q3.binned,
                                              woe.MOB_IRA.binned,
                                              woe.WITHDRAWAL_AMOUNT_IRA_Q1.binned,
                                              woe.DEPOSITED_COUNT_IRA_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_IRA_Q1.binned,
                                              woe.AVG_BALANCECHANGE_IRA_Q1.binned,
                                              woe.TRANSACTION_AMOUNT_IRA_Q1.binned,
                                              woe.TRANSACTION_COUNT_IRA_Q1.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_COUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_AVG_BALANCECHANGE_IRA_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_IRA_Q1_Q2.binned,
                                              woe.Days.Since.Last.Login.binned,
                                              woe.DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q3.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q2.binned,
                                              woe.IRA_Q1Flag.binned,
                                              woe.SUM_LASTDIVAMOUNT_IRA_Q1.binned,
                                              woe.AVG_MONTH_END_BALANCE_IRA_Q1.binned,
                                              woe.TYPE_IRA_Q1.binned,
                                              woe.PRODUCT_IRA_Q1.binned,
                                              woe.ChargeOffTradeCountP12Months.binned,
                                              woe.ChargeOffTotalBalance.binned,
                                              woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q3.binned,
                                              woe.OpenTradeCount.binned,
                                              woe.TopOfWalletCCCurrentBalance.binned,
                                              woe.IRA_StaticpoolFlag.binned,
                                              woe.TYPE_IRA_SP.binned,
                                              woe.PRODUCT_IRA_SP.binned,
                                              woe.CHECKING_StaticpoolFlag.binned,
                                              woe.TYPE_CHECKING_SP.binned,
                                              woe.PRODUCT_CHECKING_SP.binned,
                                              woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2.binned,
                                              woe.TopOfWalletCCAnnualSpend.binned,
                                              woe.CCWorstRatingP12Months.binned,
                                              woe.CHECKING_Q1Flag.binned,
                                              woe.TYPE_CHECKING_Q1.binned,
                                              woe.PRODUCT_CHECKING_Q1.binned,
                                              woe.UnsecuredLoan_Month_to_Maturity.binned,
                                              woe.CCCount.binned,
                                              woe.DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned,
                                              woe.UnsecuredLoan_MOB.binned,
                                              woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned,
                                              woe.AVG_FEEAMOUNT_UnsecuredLoan_Q1.binned,
                                              woe.AVG_NEWBALANCE_UnsecuredLoan_Q1.binned,
                                              woe.AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1.binned,
                                              woe.FEEAMOUNT_UnsecuredLoan_Q1.binned,
                                              woe.INTEREST_AMOUNT_UnsecuredLoan_Q1.binned,
                                              woe.LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_KIOSK_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_CHECKS_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_INSURANCE_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_HOMEBANKING_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_FEE_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_ACH_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_DRAFT_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_CASH_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_NEW_LOAN_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_UnsecuredLoan_Q1.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3.binned,
                                              woe.UnsecuredLoan_StaticPoolFlag.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned,
                                              woe.AggregatedSpendPast3Months.binned,
                                              woe.DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.UnsecuredLoan_Q1Flag.binned,
                                              woe.MAX_INTERESTRATE_UnsecuredLoan_Q1.binned,
                                              woe.SUM_PAYMENT_UnsecuredLoan_Q1.binned,
                                              woe.SUM_OriginalBalance_UnsecuredLoan_Q1.binned,
                                              woe.PAYMENTCOUNT_UnsecuredLoan_Q1.binned,
                                              woe.MortgageOpenBalance.binned,
                                              woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q3.binned,
                                              woe.DEPOSITED_COUNT_SAVINGS_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_SAVINGS_Q1.binned,
                                              woe.RevolvingBalance_CC_Q1.binned,
                                              woe.AVG_BALANCECHANGE_SAVINGS_Q1.binned,
                                              woe.TRANSACTION_AMOUNT_SAVINGS_Q1.binned,
                                              woe.WITHDRAWAL_AMOUNT_SAVINGS_Q1.binned,
                                              woe.HEOpenCount.binned,
                                              woe.HEOpenBalance.binned,
                                              woe.HETotalAvailableLOC.binned,
                                              woe.HEWorstRatingP12Months.binned,
                                              woe.Last.Statement.Average.Daily.Balance.Amount_CC_Q1.binned,
                                              woe.RevolvingAccountCount.binned,
                                              woe.MortgageWorstRatingP12Months.binned,
                                              woe.TRANSACTION_COUNT_SAVINGS_Q1.binned,
                                              woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned,
                                              woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned,
                                              woe.CCOpenCount.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_PRODUCT_MONEYMARKET_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_TYPE_MONEYMARKET_Q1_Q2.binned,
                                              woe.DFT_TYPE_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned,
                                              woe.PRODUCT_SAVINGS_SP.binned,
                                              woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2.binned,
                                              woe.PRODUCT_SAVINGS_Q1.binned,
                                              woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.SecuredLoan_Month_to_Maturity.binned,
                                              woe.SecuredLoan_MOB.binned,
                                              woe.DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_AVG_NEWBALANCE_RealEstate_Q1_Q3.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_FEEAMOUNT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_INTEREST_AMOUNT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_KIOSK_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q3.binned,
                                              woe.COUNT_NEW_LOAN_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q3.binned,
                                              woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.SecuredLoan_StaticPoolFlag.binned,
                                              woe.SecuredLoan_Q1Flag.binned,
                                              woe.MAX_INTERESTRATE_SecuredLoan_Q1.binned,
                                              woe.SUM_PAYMENT_SecuredLoan_Q1.binned,
                                              woe.SUM_OriginalBalance_SecuredLoan_Q1.binned,
                                              woe.PAYMENTCOUNT_SecuredLoan_Q1.binned,
                                              woe.DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_FEEAMOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_KIOSK_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q2.binned,
                                              woe.COUNT_NEW_LOAN_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_AVG_NEWBALANCE_RealEstate_Q1_Q2.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_FEEAMOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_INTEREST_AMOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_KIOSK_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q2.binned,
                                              woe.COUNT_NEW_LOAN_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q2.binned,
                                              woe.AVG_FEEAMOUNT_RealEstate_Q1.binned,
                                              woe.AVG_NEWBALANCE_RealEstate_Q1.binned,
                                              woe.AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1.binned,
                                              woe.FEEAMOUNT_RealEstate_Q1.binned,
                                              woe.INTEREST_AMOUNT_RealEstate_Q1.binned,
                                              woe.LOAN_TRANSACTION_AMOUNT_RealEstate_Q1.binned,
                                              woe.COUNT_KIOSK_RealEstate_Q1.binned,
                                              woe.COUNT_CHECKS_RealEstate_Q1.binned,
                                              woe.COUNT_INSURANCE_RealEstate_Q1.binned,
                                              woe.COUNT_HOMEBANKING_RealEstate_Q1.binned,
                                              woe.COUNT_FEE_RealEstate_Q1.binned,
                                              woe.COUNT_ACH_RealEstate_Q1.binned,
                                              woe.COUNT_DRAFT_RealEstate_Q1.binned,
                                              woe.COUNT_CASH_RealEstate_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_RealEstate_Q1.binned,
                                              woe.COUNT_NEW_LOAN_RealEstate_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_RealEstate_Q1.binned,
                                              woe.DFT_TYPE_IRA_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_IRA_Q1_Q3.binned,
                                              woe.BankruptcyCount.binned,
                                              woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q2.binned,
                                              woe.AVG_FEEAMOUNT_SecuredLoan_Q1.binned,
                                              woe.AVG_NEWBALANCE_SecuredLoan_Q1.binned,
                                              woe.AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1.binned,
                                              woe.FEEAMOUNT_SecuredLoan_Q1.binned,
                                              woe.INTEREST_AMOUNT_SecuredLoan_Q1.binned,
                                              woe.LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1.binned,
                                              woe.COUNT_KIOSK_SecuredLoan_Q1.binned,
                                              woe.COUNT_CHECKS_SecuredLoan_Q1.binned,
                                              woe.COUNT_INSURANCE_SecuredLoan_Q1.binned,
                                              woe.COUNT_HOMEBANKING_SecuredLoan_Q1.binned,
                                              woe.COUNT_FEE_SecuredLoan_Q1.binned,
                                              woe.COUNT_ACH_SecuredLoan_Q1.binned,
                                              woe.COUNT_DRAFT_SecuredLoan_Q1.binned,
                                              woe.COUNT_CASH_SecuredLoan_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_SecuredLoan_Q1.binned,
                                              woe.COUNT_NEW_LOAN_SecuredLoan_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_SecuredLoan_Q1.binned,
                                              woe.RealEstate_StaticPoolFlag.binned,
                                              woe.DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_FEEAMOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_KIOSK_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q3.binned,
                                              woe.COUNT_NEW_LOAN_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_SAVINGS_Q1_Q3.binned,
                                              woe.RealEstate_MOB.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3.binned,
                                              woe.RealEstate_Month_to_Maturity.binned,
                                              woe.TRIP_FLAG_staticpool.binned,
                                              woe.MOB_CC_staticPool.binned,
                                              woe.CL_CC_StaticPool.binned,
                                              woe.ChargeoffAmount_final_CC.binned,
                                              woe.Max_MOB_CC.binned,
                                              woe.Max_Extract_ACCOUNT_OPEN_DATE_CC.binned,
                                              woe.max_age_member_CC.binned,
                                              woe.max_credit_Limit.binned,
                                              woe.Count_Durable_CC.binned,
                                              woe.Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Staticpool.binned,
                                              woe.DFT_PRODUCT_CC_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_CC_Q1_Q2.binned,
                                              woe.PRODUCT_CC_Q1.binned,
                                              woe.CreditCard_StaticpoolFlag.binned,
                                              woe.HELOCOpenCount.binned,
                                              woe.RealEstate_Q1Flag.binned,
                                              woe.MAX_INTERESTRATE_RealEstate_Q1.binned,
                                              woe.SUM_PAYMENT_RealEstate_Q1.binned,
                                              woe.SUM_OriginalBalance_RealEstate_Q1.binned,
                                              woe.PAYMENTCOUNT_RealEstate_Q1.binned,
                                              woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q3.binned,
                                              woe.DFT_RevolvingBalance_CC_Q1_Q3.binned,
                                              woe.DFT_Promo_Current_Interest_CC_Q1_Q3.binned,
                                              woe.DFT_Protected_Current_Interest_CC_Q1_Q3.binned,
                                              woe.DFT_Promo_Balance_CC_Q1_Q3.binned,
                                              woe.DFT_Protected_Balance_CC_Q1_Q3.binned,
                                              woe.DFT_spend_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Charge.Sale.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Charge.Cash.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Charge.Late.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Return.Count_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Cash.Advance.Count_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Sale.Count_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Return.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Cash.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Sale.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Payment.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Payment.Count_CC_Q1_Q3.binned,
                                              woe.CL_DIFF_past_oneyear.binned,
                                              woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned,
                                              woe.AVG_UTILIZATION_RATE_CC_Q1.binned,
                                              woe.DFT_RevolvingBalance_CC_Q1_Q2.binned,
                                              woe.DFT_Promo_Current_Interest_CC_Q1_Q2.binned,
                                              woe.Promo_Current_Interest_CC_Q1.binned,
                                              woe.DFT_Protected_Current_Interest_CC_Q1_Q2.binned,
                                              woe.Protected_Current_Interest_CC_Q1.binned,
                                              woe.DFT_Promo_Balance_CC_Q1_Q2.binned,
                                              woe.Promo_Balance_CC_Q1.binned,
                                              woe.DFT_Protected_Balance_CC_Q1_Q2.binned,
                                              woe.Protected_Balance_CC_Q1.binned,
                                              woe.DFT_spend_CC_Q1_Q2.binned,
                                              woe.spend_CC_Q1.binned,
                                              woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                              woe.Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1.binned,
                                              woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Charge.Sale.Amount_CC_Q1_Q2.binned,
                                              woe.Last.Statement.Charge.Sale.Amount_CC_Q1.binned,
                                              woe.DFT_Last.Statement.Charge.Cash.Amount_CC_Q1_Q2.binned,
                                              woe.Last.Statement.Charge.Cash.Amount_CC_Q1.binned,
                                              woe.DFT_Last.Statement.Charge.Late.Amount_CC_Q1_Q2.binned,
                                              woe.Last.Statement.Charge.Late.Amount_CC_Q1.binned,
                                              woe.DFT_Last.Statement.Return.Count_CC_Q1_Q2.binned,
                                              woe.Last.Statement.Return.Count_CC_Q1.binned,
                                              woe.DFT_Last.Statement.Cash.Advance.Count_CC_Q1_Q2.binned,
                                              woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned,
                                              woe.DFT_Last.Statement.Sale.Count_CC_Q1_Q2.binned,
                                              woe.Last.Statement.Sale.Count_CC_Q1.binned,
                                              woe.DFT_Last.Statement.Return.Amount_CC_Q1_Q2.binned,
                                              woe.Last.Statement.Return.Amount_CC_Q1.binned,
                                              woe.DFT_Last.Statement.Cash.Amount_CC_Q1_Q2.binned,
                                              woe.Last.Statement.Cash.Amount_CC_Q1.binned,
                                              woe.DFT_Last.Statement.Sale.Amount_CC_Q1_Q2.binned,
                                              woe.Last.Statement.Sale.Amount_CC_Q1.binned,
                                              woe.DFT_Last.Statement.Payment.Amount_CC_Q1_Q2.binned,
                                              woe.Last.Statement.Payment.Amount_CC_Q1.binned,
                                              woe.DFT_Last.Statement.Payment.Count_CC_Q1_Q2.binned,
                                              woe.Last.Statement.Payment.Count_CC_Q1.binned,
                                              woe.CreditCard_Q1Flag.binned,
                                              woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_RealEstate_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_SUM_OriginalBalance_RealEstate_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_RealEstate_Q1_Q3.binned,
                                              woe.Max_Closed_account_flag_CC.binned,
                                              woe.DFT_PRODUCT_IRA_Q1_Q2.binned,
                                              woe.DFT_PRODUCT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_TYPE_IRA_Q1_Q2.binned,
                                              woe.DFT_TYPE_DEPOSITS_Q1_Q2.binned,
                                              woe.Max_chargoff_date_CC.binned,
                                              woe.DFT_TYPE_CHECKING_Q1_Q2.binned,
                                              woe.DFT_TYPE_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_PRODUCT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_TYPE_CHECKING_Q1_Q3.binned,
                                              woe.SAVINGS_StaticpoolFlag.binned,
                                              woe.TYPE_SAVINGS_SP.binned,
                                              woe.DFT_PRODUCT_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_TYPE_DEPOSITS_Q1_Q3.binned,
                                              woe.HELOCWorstRatingP12Months.binned,
                                              woe.DFT_PRODUCT_CHECKING_Q1_Q3.binned,
                                              woe.HELOCOpenBalance.binned,
                                              woe.HELOCTotalAvailableLOC.binned,
                                              woe.TYPE_SAVINGS_Q1.binned,
                                              woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned,
                                              woe.SAVINGS_Q1Flag.binned,
                                              CD_TargetFlag))

dim(df_train_woe) # 663 vars

# 6. Random Forest Feature Selection

install.packages("randomForest")
install.packages('e1071')
install.packages('caret')
install.packages('ROCR')

library(randomForest)
library(e1071)
library(caret)
library(ROCR)
set.seed(2022)

RF_CD <- randomForest(CD_TargetFlag ~.,data = df_train_woe,ntree=50)
Important_vr <- importance(RF_CD)
write.csv(Important_vr,"Important Variables for Certificates.csv")

# 7. Selected variables from Random Forest :

df7 = subset(df_train_woe,select = c(woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned,
                                     woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned,
                                     woe.MOB_SAVINGS.binned,
                                     woe.MOB_DEPOSITS.binned,
                                     woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned,
                                     woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q3.binned,
                                     woe.Days.Since.Last.Login.binned,
                                     woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned,
                                     woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q3.binned,
                                     woe.CCCount.binned,
                                     woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                     woe.TopOfWalletCCAnnualSpend.binned,
                                     woe.OpenTradeBalance.binned,
                                     woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned,
                                     woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned,
                                     woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned,
                                     woe.SUM_LASTDIVAMOUNT_SAVINGS_Q1.binned,
                                     woe.RevolvingAccountCount.binned,
                                     woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned,
                                     woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned,
                                     woe.TRANSACTION_COUNT_SAVINGS_Q1.binned,
                                     woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q2.binned,
                                     woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3.binned,
                                     woe.DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2.binned,
                                     woe.OpenTradeCount.binned,
                                     woe.MOB_CHECKING.binned,
                                     woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned,
                                     woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3.binned,
                                     woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2.binned,
                                     woe.TRANSACTION_COUNT_MONEYMARKET_Q1.binned,
                                     woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3.binned,
                                     woe.MortgageOpenCount.binned,
                                     woe.CCOpenBalance.binned,
                                     woe.NumberInquiriesP6Months.binned,
                                     woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned,
                                     woe.CCAPREstimate.binned,
                                     woe.AVG_BALANCECHANGE_CHECKING_Q1.binned,
                                     woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned,
                                     woe.PRODUCT_DEPOSITS_Q1.binned,
                                     woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2.binned,
                                     woe.DEPOSITED_COUNT_MONEYMARKET_Q1.binned,
                                     woe.TRANSACTION_AMOUNT_CHECKING_Q1.binned,
                                     woe.DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2.binned,
                                     woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q2.binned,
                                     woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned,
                                     woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned,
                                     woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned,
                                     woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                     woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2.binned,
                                     woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned,
                                     woe.AggregatedSpendPast3Months.binned,
                                     woe.TRANSACTION_AMOUNT_MONEYMARKET_Q1.binned,
                                     woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2.binned,
                                     woe.PRODUCT_DEPOSITS_SP.binned,
                                     woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                     woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                     woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2.binned,
                                     woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3.binned,
                                     woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3.binned,
                                     woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3.binned,
                                     woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned,
                                     woe.TopOfWalletCCCurrentBalance.binned,
                                     woe.HELOCOpenCount.binned,
                                     woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2.binned,
                                     woe.CCOpenCount.binned,
                                     woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned,
                                     woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3.binned,
                                     woe.AVG_BALANCECHANGE_MONEYMARKET_Q1.binned,
                                     woe.SAVINGS_StaticpoolFlag.binned,
                                     woe.DFT_PRODUCT_IRA_Q1_Q3.binned,
                                     woe.COUNT_ACH_VehicleLoan_Q1.binned,
                                     woe.MOB_MONEYMARKET.binned,
                                     woe.COUNT_HOMEBANKING_STATICPOOL.binned,
                                     woe.VehicleLoan_StaticPoolFlag.binned,
                                     woe.CHECKING_StaticpoolFlag.binned,
                                     woe.IRA_StaticpoolFlag.binned,
                                     woe.MONEYMARKET_StaticpoolFlag.binned,
                                     CD_TargetFlag))
dim(df7) # 78 vars

# 8 . Stepwise Logistic Regression :

install.packages("My.stepwise")
install.packages("carData")
install.packages("car")
install.packages("blorr")
library(My.stepwise)
library(carData)
library(car)
library(blorr)

# Iteration 1 :

variable_list1 = colnames(subset(df7,select = - CD_TargetFlag))
stepwise_1 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list1, data = df7, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg1 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                 woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                 woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                 woe.SAVINGS_StaticpoolFlag.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                 woe.VehicleLoan_StaticPoolFlag.binned + woe.MOB_SAVINGS.binned + 
                 woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3.binned + woe.CCOpenBalance.binned + 
                 woe.NumberInquiriesP6Months.binned + woe.Days.Since.Last.Login.binned + 
                 woe.CHECKING_StaticpoolFlag.binned + woe.AggregatedSpendPast3Months.binned + 
                 woe.MortgageOpenCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + 
                 woe.RevolvingAccountCount.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                 woe.CCOpenCount.binned + woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.COUNT_HOMEBANKING_STATICPOOL.binned + woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + 
                 woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned,  data = df7 ,family = binomial(link='logit'))

a1 = Anova(log_reg1,type="II",test="Wald")
v1 = vif(log_reg1)

summary(log_reg1)

# woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3.binned has high p value and negative estimate. So removing it.

# Iteration 2

df8 = subset(df7,select = -woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3.binned)
dim(df8) # 77 vars 

variable_list2 = colnames(subset(df8,select = - CD_TargetFlag))
stepwise_2 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list2, data = df8, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg2 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                 woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                 woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                 woe.SAVINGS_StaticpoolFlag.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                 woe.VehicleLoan_StaticPoolFlag.binned + woe.MOB_SAVINGS.binned + 
                 woe.NumberInquiriesP6Months.binned + woe.CCOpenBalance.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.CHECKING_StaticpoolFlag.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.RevolvingAccountCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + 
                 woe.MortgageOpenCount.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                 woe.CCOpenCount.binned + woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + woe.COUNT_HOMEBANKING_STATICPOOL.binned + 
                 woe.PRODUCT_DEPOSITS_Q1.binned + woe.PRODUCT_DEPOSITS_SP.binned + 
                 woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3.binned, 
               family = binomial(logit), data = df8)

a2 = Anova(log_reg2,type="II",test="Wald")
v2 = vif(log_reg2)

summary(log_reg2)

# woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3.binned has the high p value and negative estimate.

# Iteration 3

df9 = subset(df8,select = -woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3.binned)
dim(df9) # 76 vars

variable_list3 = colnames(subset(df9,select = - CD_TargetFlag))
stepwise_3 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list3, data = df9, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg3 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                 woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                 woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                 woe.SAVINGS_StaticpoolFlag.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                 woe.VehicleLoan_StaticPoolFlag.binned + woe.MOB_SAVINGS.binned + 
                 woe.NumberInquiriesP6Months.binned + woe.CCOpenBalance.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.CHECKING_StaticpoolFlag.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.RevolvingAccountCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + 
                 woe.MortgageOpenCount.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                 woe.CCOpenCount.binned + woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + woe.COUNT_HOMEBANKING_STATICPOOL.binned + 
                 woe.PRODUCT_DEPOSITS_Q1.binned + woe.PRODUCT_DEPOSITS_SP.binned + 
                 woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned,  data = df9, family = binomial(logit))

a3 = Anova(log_reg3,type="II",test="Wald")
v3 = vif(log_reg3)

summary(log_reg3)

# woe.PRODUCT_DEPOSITS_SP.binned has high p value and negative estimate. So removing it.

# Iteration 4

df10 = subset(df9,select = -woe.PRODUCT_DEPOSITS_SP.binned)
dim(df10) # 75 vars

variable_list4 = colnames(subset(df10,select = - CD_TargetFlag))
stepwise_4 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list4, data = df10, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg4 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                 woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                 woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                 woe.SAVINGS_StaticpoolFlag.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                 woe.VehicleLoan_StaticPoolFlag.binned + woe.MOB_SAVINGS.binned + 
                 woe.NumberInquiriesP6Months.binned + woe.CCOpenBalance.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.CHECKING_StaticpoolFlag.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.RevolvingAccountCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + 
                 woe.MortgageOpenCount.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                 woe.CCOpenCount.binned + woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + woe.COUNT_HOMEBANKING_STATICPOOL.binned + 
                 woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + woe.PRODUCT_DEPOSITS_Q1.binned + 
                 woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned,data = df10, family = binomial(logit))

a4 = Anova(log_reg4,type="II",test="Wald")
v4 = vif(log_reg4)

write.csv(a4,"Anova.csv")
write.csv(v4,"VIF.csv")

summary(log_reg4)

# woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned has high p value and negative estimate

# Iteration 5

df11 = subset(df10,select = -woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned)
dim(df11) # 74 vars

variable_list5 = colnames(subset(df11,select = - CD_TargetFlag))
stepwise_5 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list5, data = df11, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg5 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                 woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                 woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                 woe.SAVINGS_StaticpoolFlag.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                 woe.VehicleLoan_StaticPoolFlag.binned + woe.MOB_SAVINGS.binned + 
                 woe.NumberInquiriesP6Months.binned + woe.CCOpenBalance.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.CHECKING_StaticpoolFlag.binned + 
                 woe.Days.Since.Last.Login.binned + woe.RevolvingAccountCount.binned + 
                 woe.MortgageOpenCount.binned + woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + 
                 woe.DFT_PRODUCT_IRA_Q1_Q3.binned + woe.CCOpenCount.binned + 
                 woe.PRODUCT_DEPOSITS_Q1.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + 
                 woe.COUNT_HOMEBANKING_STATICPOOL.binned + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + 
                 woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.TRANSACTION_COUNT_SAVINGS_Q1.binned + 
                 woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + woe.CCCount.binned, 
               family = binomial(logit), data = df11)

a5 = Anova(log_reg5,type="II",test="Wald")
v5 = vif(log_reg5)

summary(log_reg5)

# woe.TRANSACTION_COUNT_SAVINGS_Q1.binned has high p value and negative estimate

# Iteration 6

df12 = subset(df11,select = -woe.TRANSACTION_COUNT_SAVINGS_Q1.binned)
dim(df12) # 73 vars

variable_list6 = colnames(subset(df12,select = - CD_TargetFlag))
stepwise_6 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list6, data = df12, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg6 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                 woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                 woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                 woe.SAVINGS_StaticpoolFlag.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                 woe.VehicleLoan_StaticPoolFlag.binned + woe.MOB_SAVINGS.binned + 
                 woe.NumberInquiriesP6Months.binned + woe.CCOpenBalance.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.CHECKING_StaticpoolFlag.binned + 
                 woe.Days.Since.Last.Login.binned + woe.RevolvingAccountCount.binned + 
                 woe.MortgageOpenCount.binned + woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + 
                 woe.DFT_PRODUCT_IRA_Q1_Q3.binned + woe.CCOpenCount.binned + 
                 woe.PRODUCT_DEPOSITS_Q1.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + 
                 woe.COUNT_HOMEBANKING_STATICPOOL.binned + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + 
                 woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3.binned + woe.CCCount.binned, 
               family = binomial(logit), data = df12)

a6 = Anova(log_reg6,type="II",test="Wald")
v6 = vif(log_reg6)

write.csv(a6,"Anova.csv")
write.csv(v6,"VIF.csv")

summary(log_reg6)

# woe.SAVINGS_StaticpoolFlag.binned has high p value and negative estimate.

# Iteration 7

df13 = subset(df12,select = -woe.SAVINGS_StaticpoolFlag.binned)
dim(df13) # 72 vars

variable_list7 = colnames(subset(df13,select = - CD_TargetFlag))
stepwise_7 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list7, data = df13, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg7 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                 woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                 woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                 woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.MOB_SAVINGS.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + woe.VehicleLoan_StaticPoolFlag.binned + 
                 woe.CCOpenBalance.binned + woe.NumberInquiriesP6Months.binned + 
                 woe.Days.Since.Last.Login.binned + woe.CHECKING_StaticpoolFlag.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.PRODUCT_DEPOSITS_Q1.binned + 
                 woe.RevolvingAccountCount.binned + woe.MortgageOpenCount.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + 
                 woe.CCOpenCount.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                 woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + woe.COUNT_HOMEBANKING_STATICPOOL.binned + 
                 woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned, family = binomial(logit), 
               data = df13)

a7 = Anova(log_reg7,type="II",test="Wald")
v7 = vif(log_reg7)


summary(log_reg7)

# woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned has high p value and negative estimate

# Iteration 8

df14 = subset(df13,select = -woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned)
dim(df14) # 71 vars

variable_list8 = colnames(subset(df14,select = - CD_TargetFlag))
stepwise_8 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list8, data = df14, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg8 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                 woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                 woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                 woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.MOB_SAVINGS.binned + 
                 woe.NumberInquiriesP6Months.binned + woe.Days.Since.Last.Login.binned + 
                 woe.CHECKING_StaticpoolFlag.binned + woe.PRODUCT_DEPOSITS_Q1.binned + 
                 woe.CCOpenBalance.binned + woe.VehicleLoan_StaticPoolFlag.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                 woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + woe.MortgageOpenCount.binned + 
                 woe.CCOpenCount.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned + 
                 woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + 
                 woe.COUNT_HOMEBANKING_STATICPOOL.binned + woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned, 
               family = binomial(logit), data = df14)

a8 = Anova(log_reg8,type="II",test="Wald")
v8 = vif(log_reg8)

summary(log_reg8)

# woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned has high p value and negative estimate

# Iteration 9

df15 = subset(df14,select = -woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned)
dim(df15) # 70 vars

variable_list9 = colnames(subset(df15,select = - CD_TargetFlag))
stepwise_9 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list9, data = df15, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg9 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                 woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                 woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                 woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.MOB_SAVINGS.binned + 
                 woe.NumberInquiriesP6Months.binned + woe.Days.Since.Last.Login.binned + 
                 woe.CHECKING_StaticpoolFlag.binned + woe.PRODUCT_DEPOSITS_Q1.binned + 
                 woe.CCOpenBalance.binned + woe.VehicleLoan_StaticPoolFlag.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                 woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + woe.MortgageOpenCount.binned + 
                 woe.CCOpenCount.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned + 
                 woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + 
                 woe.COUNT_HOMEBANKING_STATICPOOL.binned, family = binomial(logit), data = df15)

a9 = Anova(log_reg9,type="II",test="Wald")
v9 = vif(log_reg9)

summary(log_reg9)

# woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned has high p value and negative estimate

# Iteration 10

df16 = subset(df15,select=-woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned)
dim(df16) # 69 vars

variable_list10 = colnames(subset(df16,select = - CD_TargetFlag))
stepwise_10 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list10, data = df16, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg10 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.MOB_SAVINGS.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.Days.Since.Last.Login.binned + 
                  woe.CHECKING_StaticpoolFlag.binned + woe.PRODUCT_DEPOSITS_Q1.binned + 
                  woe.CCOpenBalance.binned + woe.VehicleLoan_StaticPoolFlag.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                  woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + woe.MortgageOpenCount.binned + 
                  woe.CCOpenCount.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + 
                  woe.COUNT_HOMEBANKING_STATICPOOL.binned, family = binomial(logit), 
                data = df16)

a10 = Anova(log_reg10,type="II",test="Wald")
v10 = vif(log_reg10)

summary(log_reg10)

# woe.CHECKING_StaticpoolFlag.binned has high p value and negative estimate

# Iteration 11

df17 = subset(df16,select = -woe.CHECKING_StaticpoolFlag.binned)
dim(df17) # 68 vars

variable_list11 = colnames(subset(df17,select = - CD_TargetFlag))
stepwise_11 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list11, data = df17, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg11 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.MOB_SAVINGS.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.Days.Since.Last.Login.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.CCOpenBalance.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                  woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3.binned + woe.MortgageOpenCount.binned + 
                  woe.DFT_PRODUCT_IRA_Q1_Q3.binned + woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.PRODUCT_DEPOSITS_Q1.binned + woe.CCOpenCount.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + 
                  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + woe.COUNT_HOMEBANKING_STATICPOOL.binned, 
                data=df17,family = binomial(link='logit'))

a11 = Anova(log_reg11,type='II',test='Wald')
v11 = vif(log_reg11)

summary(log_reg11)

# woe.DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2.binned has high p value and negative estimate.

# Iteration 12

df18 = subset(df17,select = -woe.DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2.binned)
dim(df18) # 67 vars

variable_list12 = colnames(subset(df18,select = - CD_TargetFlag))
stepwise_12 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list12, data = df18, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg12 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.MOB_SAVINGS.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.Days.Since.Last.Login.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.CCOpenBalance.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                  woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3.binned + woe.MortgageOpenCount.binned + 
                  woe.DFT_PRODUCT_IRA_Q1_Q3.binned + woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.PRODUCT_DEPOSITS_Q1.binned + woe.CCOpenCount.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + woe.COUNT_HOMEBANKING_STATICPOOL.binned, 
                data = df18,family = binomial(logit))

a12 = Anova(log_reg12,type="II",test="Wald")
v12 = vif(log_reg12)

summary(log_reg12)

# woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3.binned has high p value and negative estimate.

# Iteration 13

df19 = subset(df18,select = -woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3.binned)
dim(df19) # 66 vars

variable_list13 = colnames(subset(df19,select = - CD_TargetFlag))
stepwise_13 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list13, data = df19, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg13 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.MOB_SAVINGS.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.Days.Since.Last.Login.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.CCOpenBalance.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                  woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3.binned + woe.MortgageOpenCount.binned + 
                  woe.DFT_PRODUCT_IRA_Q1_Q3.binned + woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.PRODUCT_DEPOSITS_Q1.binned + woe.CCOpenCount.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + woe.COUNT_HOMEBANKING_STATICPOOL.binned, 
                data=df19,family = binomial(logit))

a13 = Anova(log_reg13,type="II",test="Wald")
v13 = vif(log_reg13)

summary(log_reg13)

# woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3.binned has high p value and negative estimate.

# Iteration 14

df20 = subset(df19,select = -woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3.binned)
dim(df20) # 65 vars

variable_list14 = colnames(subset(df20,select = - CD_TargetFlag))
stepwise_14 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list14, data = df20, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg14 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.MOB_SAVINGS.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.Days.Since.Last.Login.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.CCOpenBalance.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                  woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2.binned + woe.MortgageOpenCount.binned + 
                  woe.DFT_PRODUCT_IRA_Q1_Q3.binned + woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.PRODUCT_DEPOSITS_Q1.binned + woe.CCOpenCount.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + 
                  woe.COUNT_HOMEBANKING_STATICPOOL.binned, family = binomial(logit), 
                data = df20)

a14 = Anova(log_reg14,type="II",test="Wald")
v14 = vif(log_reg14)

summary(log_reg14)

# woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2.binned has the negative estimate and high p value

# Iteration 15

df21 = subset(df20,select = -woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2.binned)
dim(df21) #64 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list15 = colnames(subset(df21,select = - CD_TargetFlag))
stepwise_15 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list15, data = df21, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg15 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.MOB_SAVINGS.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.Days.Since.Last.Login.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.CCOpenBalance.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                  woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2.binned + woe.MortgageOpenCount.binned + 
                  woe.DFT_PRODUCT_IRA_Q1_Q3.binned + woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.PRODUCT_DEPOSITS_Q1.binned + woe.CCOpenCount.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + 
                  woe.COUNT_HOMEBANKING_STATICPOOL.binned ,data = df21, family = binomial(logit))

a15 = Anova(log_reg15,type="II",test="Wald")
v15 = vif(log_reg15)

summary(log_reg15)

# woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2.binned has high p value and negative estimate

# Iteration 16

df22 = subset(df21,select = -woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2.binned)
dim(df22) # 63 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list16 = colnames(subset(df22,select = - CD_TargetFlag))
stepwise_16 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list16, data = df22, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg16 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.MOB_SAVINGS.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.Days.Since.Last.Login.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.CCOpenBalance.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                  woe.MortgageOpenCount.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                  woe.CCOpenCount.binned + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + 
                  woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + woe.TRANSACTION_AMOUNT_CHECKING_Q1.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + woe.COUNT_HOMEBANKING_STATICPOOL.binned + 
                  woe.PRODUCT_DEPOSITS_Q1.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + 
                  woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3.binned,data = df22, family = binomial(logit))

a16 = Anova(log_reg16,type = "II",test="Wald")
v16 = vif(log_reg16)

summary(log_reg16)

# woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3.binned has the high p value and negative estimate.

# Iteration 17

df23 = subset(df22,select = -woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3.binned)
dim(df23) # 62 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list17 = colnames(subset(df23,select = - CD_TargetFlag))
stepwise_17 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list17, data = df23, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg17 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.MOB_SAVINGS.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.Days.Since.Last.Login.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.CCOpenBalance.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                  woe.MortgageOpenCount.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                  woe.CCOpenCount.binned + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + 
                  woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + woe.TRANSACTION_AMOUNT_CHECKING_Q1.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + woe.COUNT_HOMEBANKING_STATICPOOL.binned + 
                  woe.PRODUCT_DEPOSITS_Q1.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + 
                  woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2.binned,  data = df23, family = binomial(logit))

a17 = Anova(log_reg17,type="II",test="Wald")
v17 = vif(log_reg17)

summary(log_reg17)

# woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2.binned has high p value and negative estimate

# Iteration 18

df24 = subset(df23,select = -woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2.binned)
dim(df24) # 61 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list18 = colnames(subset(df24,select = - CD_TargetFlag))
stepwise_18 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list18, data = df24, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)


log_reg18 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.MOB_SAVINGS.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.Days.Since.Last.Login.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.CCOpenBalance.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                  woe.MortgageOpenCount.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                  woe.CCOpenCount.binned + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + 
                  woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + woe.TRANSACTION_AMOUNT_CHECKING_Q1.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + woe.COUNT_HOMEBANKING_STATICPOOL.binned + 
                  woe.PRODUCT_DEPOSITS_Q1.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned, 
                family = binomial(logit), data = df24)

a18 = Anova(log_reg18,type="II",test="Wald")
v18 = vif(log_reg18)

summary(log_reg18)

# woe.TRANSACTION_AMOUNT_CHECKING_Q1.binned has high p value and negative estimate

# Iteration 19

df25 = subset(df24,select = -woe.TRANSACTION_AMOUNT_CHECKING_Q1.binned)
dim(df25) #60 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list19 = colnames(subset(df25,select = - CD_TargetFlag))
stepwise_19 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list19, data = df25, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg19 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.MOB_SAVINGS.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.Days.Since.Last.Login.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.CCOpenBalance.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                  woe.MortgageOpenCount.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                  woe.CCOpenCount.binned + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + 
                  woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + 
                  woe.COUNT_HOMEBANKING_STATICPOOL.binned ,data = df25, family = binomial(logit))

a19 = Anova(log_reg19,type="II",test="Wald")
v19 = vif(log_reg19)

summary(log_reg19)

# woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned has the high p value and negative estimate

# Iteration 20

df26 = subset(df25,select = -woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned)
dim(df26) # 59 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list20 = colnames(subset(df26,select = - CD_TargetFlag))
stepwise_20 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list20, data = df26, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)


log_reg20 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned + 
                  woe.CCCount.binned + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                  woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2.binned + woe.CCAPREstimate.binned + 
                  woe.MOB_SAVINGS.binned + woe.CCOpenBalance.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.RevolvingAccountCount.binned + 
                  woe.DFT_PRODUCT_IRA_Q1_Q3.binned + woe.MortgageOpenCount.binned + 
                  woe.CCOpenCount.binned + woe.MOB_CHECKING.binned + woe.Days.Since.Last.Login.binned + 
                  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + woe.COUNT_HOMEBANKING_STATICPOOL.binned + 
                  woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q3.binned , data = df26, family = binomial(logit))

a20 = Anova(log_reg20,type="II",test="Wald")
v20 = vif(log_reg20)

summary(log_reg20)

# woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q3.binned has high p value and negative estimate.

# Iteration 21

df27 = subset(df26,select = -woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q3.binned)
dim(df27) # 58 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list21 = colnames(subset(df27,select = - CD_TargetFlag))
stepwise_21 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list21, data = df27, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg21 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned + 
                  woe.CCCount.binned + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                  woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2.binned + woe.CCAPREstimate.binned + 
                  woe.MOB_SAVINGS.binned + woe.CCOpenBalance.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.RevolvingAccountCount.binned + 
                  woe.DFT_PRODUCT_IRA_Q1_Q3.binned + woe.MortgageOpenCount.binned + 
                  woe.CCOpenCount.binned + woe.MOB_CHECKING.binned + woe.Days.Since.Last.Login.binned + 
                  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + woe.COUNT_HOMEBANKING_STATICPOOL.binned + 
                  woe.IRA_StaticpoolFlag.binned, data=df27, family = binomial(logit))

a21 = Anova(log_reg21,type="II",test="Wald")
v21 = vif(log_reg21)

summary(log_reg21)

# woe.MOB_CHECKING.binned has high p value and negative estimate.

# Iteration 22

df28 = subset(df27,select=-woe.MOB_CHECKING.binned)
dim(df28) # 57 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list22 = colnames(subset(df28,select = - CD_TargetFlag))
stepwise_22 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list22, data = df28, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg22 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned + 
                  woe.CCCount.binned + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                  woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2.binned + woe.CCAPREstimate.binned + 
                  woe.MOB_SAVINGS.binned + woe.CCOpenBalance.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.RevolvingAccountCount.binned + 
                  woe.DFT_PRODUCT_IRA_Q1_Q3.binned + woe.MortgageOpenCount.binned + 
                  woe.CCOpenCount.binned + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + 
                  woe.Days.Since.Last.Login.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + woe.IRA_StaticpoolFlag.binned + 
                  woe.COUNT_HOMEBANKING_STATICPOOL.binned,data=df28, family = binomial(logit))

a22 = Anova(log_reg22,type="II",test="Wald")
v22 = vif(log_reg22)

summary(log_reg22)

# woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned has high p value and negative estimate. 

# Iteration 23

df29 = subset(df28,select = -woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned)
dim(df29) #56 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list23 = colnames(subset(df29,select = - CD_TargetFlag))
stepwise_23 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list23, data = df29, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg23 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.NumberInquiriesP6Months.binned + 
                  woe.MOB_SAVINGS.binned + woe.VehicleLoan_StaticPoolFlag.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                  woe.DFT_PRODUCT_IRA_Q1_Q3.binned + woe.MortgageOpenCount.binned + 
                  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + woe.CCOpenCount.binned + 
                  woe.CCOpenBalance.binned + woe.AVG_BALANCECHANGE_CHECKING_Q1.binned + 
                  woe.Days.Since.Last.Login.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + 
                  woe.IRA_StaticpoolFlag.binned + woe.CCCount.binned + woe.COUNT_HOMEBANKING_STATICPOOL.binned, 
                data = df29, family = binomial(logit))

a23 = Anova(log_reg23,type="II",test="Wald")
v23 = vif(log_reg23)

summary(log_reg23)

# woe.AVG_BALANCECHANGE_CHECKING_Q1.binned has high p value and negative estimate.

# Iteration 24

df30 = subset(df29,select = -woe.AVG_BALANCECHANGE_CHECKING_Q1.binned)
dim(df30) # 55 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list24 = colnames(subset(df30,select = - CD_TargetFlag))
stepwise_24 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list24, data = df30, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg24 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.NumberInquiriesP6Months.binned + 
                  woe.MOB_SAVINGS.binned + woe.VehicleLoan_StaticPoolFlag.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                  woe.DFT_PRODUCT_IRA_Q1_Q3.binned + woe.MortgageOpenCount.binned + 
                  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + woe.CCOpenCount.binned + 
                  woe.CCOpenBalance.binned + woe.IRA_StaticpoolFlag.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + woe.Days.Since.Last.Login.binned + 
                  woe.DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2.binned + woe.CCCount.binned + 
                  woe.COUNT_HOMEBANKING_STATICPOOL.binned,data = df30, family = binomial(logit))
a24 = Anova(log_reg24,type="II",test="Wald")
v24 = vif(log_reg24)

summary(log_reg24)

# woe.DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2.binned has high p value and negative estimate.

# Iteration 25

df31 = subset(df30,select = -woe.DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2.binned)
dim(df31) # 54 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list25 = colnames(subset(df31,select = - CD_TargetFlag))
stepwise_25 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list25, data = df31, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg25 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.NumberInquiriesP6Months.binned + 
                  woe.MOB_SAVINGS.binned + woe.VehicleLoan_StaticPoolFlag.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.RevolvingAccountCount.binned + 
                  woe.DFT_PRODUCT_IRA_Q1_Q3.binned + woe.MortgageOpenCount.binned + 
                  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + woe.CCOpenCount.binned + 
                  woe.CCOpenBalance.binned + woe.IRA_StaticpoolFlag.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + woe.Days.Since.Last.Login.binned + 
                  woe.CCCount.binned + woe.COUNT_HOMEBANKING_STATICPOOL.binned,data = df31, 
                family = binomial(logit))

a25 = Anova(log_reg25,type="II",test="Wald")
v25 = vif(log_reg25)

summary(log_reg25)

# woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2.binned has negative estimate.

# Iteration 26

df32 = subset(df31,select = -woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2.binned)
dim(df32) #53 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list26 = colnames(subset(df32,select = - CD_TargetFlag))
stepwise_26 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list26, data = df32, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg26 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.NumberInquiriesP6Months.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.IRA_StaticpoolFlag.binned + 
                  woe.PRODUCT_DEPOSITS_Q1.binned + woe.VehicleLoan_StaticPoolFlag.binned + 
                  woe.RevolvingAccountCount.binned + woe.CCOpenBalance.binned + 
                  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + woe.MortgageOpenCount.binned + 
                  woe.MOB_SAVINGS.binned + woe.CCOpenCount.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned, 
                data=df32,family = binomial(logit))

a26 = Anova(log_reg26,type="II",test="Wald")
v26 = vif(log_reg26)

summary(log_reg26)

# woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned has high p value and negative estimate

# Iteration 27 

df33 = subset(df32,select = -woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned)
dim(df33) #52 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list27 = colnames(subset(df33,select = - CD_TargetFlag))
stepwise_27 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list27, data = df33, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg27 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.NumberInquiriesP6Months.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.IRA_StaticpoolFlag.binned + 
                  woe.PRODUCT_DEPOSITS_Q1.binned + woe.VehicleLoan_StaticPoolFlag.binned + 
                  woe.RevolvingAccountCount.binned + woe.CCOpenBalance.binned + 
                  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + woe.MortgageOpenCount.binned + 
                  woe.MOB_SAVINGS.binned + woe.CCOpenCount.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned, 
                data= df33, family = binomial(logit))

a27 = Anova(log_reg27,type="II",test="Wald")
v27 = vif(log_reg27)

summary(log_reg27)

# woe.PRODUCT_DEPOSITS_Q1.binned has negative estimate.

# Iteration 28

df34 = subset(df33,select = -woe.PRODUCT_DEPOSITS_Q1.binned)
dim(df34) # 51 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list28 = colnames(subset(df34,select = - CD_TargetFlag))
stepwise_28 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list28, data = df34, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg28 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.NumberInquiriesP6Months.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.IRA_StaticpoolFlag.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.RevolvingAccountCount.binned + 
                  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + woe.MortgageOpenCount.binned + 
                  woe.MOB_SAVINGS.binned + woe.CCOpenCount.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + 
                  woe.DFT_PRODUCT_IRA_Q1_Q3.binned + woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2.binned + 
                  woe.MOB_DEPOSITS.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + woe.CCOpenBalance.binned, 
                data=df34, family = binomial(logit))

a28 = Anova(log_reg28,type="II",test="Wald")
v28 = vif(log_reg28)

summary(log_reg28)

# woe.MOB_DEPOSITS.binned has high p value and negative estimate.

# Iteration 29

df35 = subset(df34,select = -woe.MOB_DEPOSITS.binned)
dim(df35) #50 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list29 = colnames(subset(df35,select = - CD_TargetFlag))
stepwise_29 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list29, data = df35, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg29 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.NumberInquiriesP6Months.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.IRA_StaticpoolFlag.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.RevolvingAccountCount.binned + 
                  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + woe.TopOfWalletCCCurrentBalance.binned + 
                  woe.MortgageOpenCount.binned + woe.MOB_SAVINGS.binned + woe.CCOpenCount.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                  woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + 
                  woe.AggregatedSpendPast3Months.binned,data=df35, family = binomial(logit))

a29 = Anova(log_reg29,type="II",test="Wald")
v29 = vif(log_reg29)

summary(log_reg29)

# woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2.binned has negative estimate

# Iteration 30

df36 = subset(df35,select = -woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2.binned)
dim(df36) #49 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list30 = colnames(subset(df36,select = - CD_TargetFlag))
stepwise_30 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list30, data = df36, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg30 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MONEYMARKET_StaticpoolFlag.binned + 
                  woe.OpenTradeBalance.binned + woe.NumberInquiriesP6Months.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned + woe.CCAPREstimate.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.IRA_StaticpoolFlag.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + woe.RevolvingAccountCount.binned + 
                  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned + woe.TopOfWalletCCCurrentBalance.binned + 
                  woe.MortgageOpenCount.binned + woe.MOB_SAVINGS.binned + woe.CCOpenCount.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned + woe.DFT_PRODUCT_IRA_Q1_Q3.binned + 
                  woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + 
                  woe.AggregatedSpendPast3Months.binned,data=df36, family = binomial(logit))

a30 = Anova(log_reg30,type="II",test="Wald")
v30 = vif(log_reg30)

summary(log_reg30)

# woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2.binned has negative estimate

# Iteration 31

df37 = subset(df36,select=-woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2.binned)
dim(df37) # 48 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list31 = colnames(subset(df37,select = - CD_TargetFlag))
stepwise_31 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list31, data = df37, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

# MODEL 1 :

log_reg31 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned
                + woe.MONEYMARKET_StaticpoolFlag.binned 
                + woe.OpenTradeBalance.binned
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.CCAPREstimate.binned
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned 
                + woe.IRA_StaticpoolFlag.binned 
                + woe.VehicleLoan_StaticPoolFlag.binned
                + woe.RevolvingAccountCount.binned
                + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                + woe.TopOfWalletCCCurrentBalance.binned 
                + woe.MortgageOpenCount.binned 
                + woe.MOB_SAVINGS.binned 
                + woe.CCOpenCount.binned
                + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned 
                + woe.DFT_PRODUCT_IRA_Q1_Q3.binned 
                + woe.AggregatedSpendPast3Months.binned
                , data=df37,family = binomial(logit))

a31 = Anova(log_reg31,type="II",test="Wald")
v31 = vif(log_reg31)

write.csv(a31,"Anova.csv")
write.csv(v31,"VIF.csv")

summary(log_reg31)

org_reg31 = glm(CD_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3+
                  NumberInquiriesP6Months+
                  OpenTradeBalance+
                  RevolvingAccountCount+
                  DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3+
                  CCAPREstimate+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  VehicleLoan_StaticPoolFlag+
                  IRA_StaticpoolFlag+
                  TopOfWalletCCCurrentBalance+
                  WITHDRAWAL_AMOUNT_MONEYMARKET_Q1+
                  CCOpenCount+
                  MortgageOpenCount+
                  MONEYMARKET_StaticpoolFlag+
                  DFT_PRODUCT_IRA_Q1_Q3+
                  MOB_SAVINGS+
                  DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2+
                  AggregatedSpendPast3Months
                ,data = NAReplace_train,family = binomial(link = 'logit'))

summary(org_reg31)
o31 = vif(org_reg31)
write.csv(o31,"VIF.csv")

# WOE on the Test data

test_final = subset(CD_test,select=c(WITHDRAWAL_AMOUNT_MONEYMARKET_Q1 ,
                                     AVG_MONTH_END_BALANCE_DEPOSITS_Q1 ,
                                     NumberInquiriesP6Months ,
                                     DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3 ,
                                     AVG_BALANCECHANGE_MONEYMARKET_Q1,
                                     MortgageOpenCount,
                                     CCCount,
                                     CCOpenBalance,
                                     AVG_BALANCECHANGE_DEPOSITS_Q1 ,
                                     VehicleLoan_StaticPoolFlag ,
                                     IRA_StaticpoolFlag ,
                                     CCAPREstimate ,
                                     DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2 ,
                                     MOB_SAVINGS ,
                                     MOB_MONEYMARKET ,
                                     DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3 ,
                                     COUNT_HOMEBANKING_STATICPOOL,
                                     TopOfWalletCCAnnualSpend,
                                     DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3,
                                     COUNT_HOMEBANKING_Q1,
                                     DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3,
                                     DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3,
                                     SUM_LASTDIVAMOUNT_SAVINGS_Q1,
                                     DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3,
                                     MOB_MONEYMARKET,
                                     COUNT_ACH_VehicleLoan_Q1,
                                     DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2,
                                     CD_TargetFlag))


test_final$VehicleLoan_StaticPoolFlag = replace(test_final$VehicleLoan_StaticPoolFlag,is.na(test_final$VehicleLoan_StaticPoolFlag),0)
# test_final$MONEYMARKET_StaticpoolFlag = replace(test_final$MONEYMARKET_StaticpoolFlag ,is.na(test_final$MONEYMARKET_StaticpoolFlag),0)
test_final$IRA_StaticpoolFlag = replace(test_final$IRA_StaticpoolFlag ,is.na(test_final$IRA_StaticpoolFlag),0)

NAReplace_test <- replace(test_final,is.na(test_final),-9999999)
sum(is.na(NAReplace_test)) 

CD_binning_test_model <- woe.binning(NAReplace_test,'CD_TargetFlag',NAReplace_test)
CD_test_woe <- woe.binning.deploy(NAReplace_test,CD_binning_test_model,add.woe.or.dum.var = "woe")

# Accuracy of MODEL 1

train1 = blr_gains_table(log_reg31,data=df37)
train1

test1 = blr_gains_table(log_reg31,data = CD_test_woe)
test1


# MODEL 2 :

log_reg32 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned
                + woe.MONEYMARKET_StaticpoolFlag.binned 
                + woe.OpenTradeBalance.binned
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.CCAPREstimate.binned
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned 
                + woe.IRA_StaticpoolFlag.binned 
                + woe.VehicleLoan_StaticPoolFlag.binned
                + woe.RevolvingAccountCount.binned
                + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                + woe.TopOfWalletCCCurrentBalance.binned 
                + woe.MortgageOpenCount.binned 
                + woe.MOB_SAVINGS.binned 
                + woe.CCOpenCount.binned
                + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned 
                + woe.DFT_PRODUCT_IRA_Q1_Q3.binned 
                # + woe.AggregatedSpendPast3Months.binned
                , data=df37,family = binomial(logit))

a32 = Anova(log_reg32,type="II",test="Wald")
v32 = vif(log_reg32)

write.csv(a32,"Anova.csv")
write.csv(v32,"VIF.csv")

summary(log_reg32)

org_reg32 = glm(CD_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1
                + DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3
                + NumberInquiriesP6Months
                + OpenTradeBalance
                + RevolvingAccountCount
                + DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3
                + CCAPREstimate
                + AVG_BALANCECHANGE_DEPOSITS_Q1
                + VehicleLoan_StaticPoolFlag
                + IRA_StaticpoolFlag
                + TopOfWalletCCCurrentBalance
                + WITHDRAWAL_AMOUNT_MONEYMARKET_Q1
                + CCOpenCount
                + MortgageOpenCount
                + MONEYMARKET_StaticpoolFlag
                + DFT_PRODUCT_IRA_Q1_Q3
                + MOB_SAVINGS
                + DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2
                # + AggregatedSpendPast3Months
                ,data = NAReplace_train,family = binomial(link = 'logit'))

summary(org_reg32)
o32 = vif(org_reg32)
write.csv(o32,"VIF.csv")

# Accuracy of Model 2

train2 = blr_gains_table(log_reg32,data=df37)
train2

test2 = blr_gains_table(log_reg32,data = CD_test_woe)
test2


# MODEL 3 :

log_reg33 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned
                + woe.MONEYMARKET_StaticpoolFlag.binned 
                + woe.OpenTradeBalance.binned
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.CCAPREstimate.binned
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned 
                + woe.IRA_StaticpoolFlag.binned 
                + woe.VehicleLoan_StaticPoolFlag.binned
                + woe.RevolvingAccountCount.binned
                + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                + woe.TopOfWalletCCCurrentBalance.binned 
                + woe.MortgageOpenCount.binned 
                + woe.MOB_SAVINGS.binned 
                # + woe.CCOpenCount.binned #2
                + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned 
                + woe.DFT_PRODUCT_IRA_Q1_Q3.binned 
                # + woe.AggregatedSpendPast3Months.binned #1
                , data=df37,family = binomial(logit))

a33 = Anova(log_reg33,type="II",test="Wald")
v33 = vif(log_reg33)

write.csv(a33,"Anova.csv")
write.csv(v33,"VIF.csv")

summary(log_reg33)

org_reg33 = glm(CD_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1
                + DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3
                + NumberInquiriesP6Months
                + OpenTradeBalance
                + RevolvingAccountCount
                + DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3
                + CCAPREstimate
                + AVG_BALANCECHANGE_DEPOSITS_Q1
                + VehicleLoan_StaticPoolFlag
                + IRA_StaticpoolFlag
                + TopOfWalletCCCurrentBalance
                + WITHDRAWAL_AMOUNT_MONEYMARKET_Q1
                # + CCOpenCount #2
                + MortgageOpenCount
                + MONEYMARKET_StaticpoolFlag
                + DFT_PRODUCT_IRA_Q1_Q3
                + MOB_SAVINGS
                + DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2
                # + AggregatedSpendPast3Months #1
                ,data = NAReplace_train,family = binomial(link = 'logit'))

summary(org_reg33)
o33 = vif(org_reg33)
write.csv(o33,"VIF.csv")

# Accuracy of Model 3

train3 = blr_gains_table(log_reg33,data=df37)
train3

test3 = blr_gains_table(log_reg33,data = CD_test_woe)
test3


# MODEL 4 :

log_reg34 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned
                + woe.MONEYMARKET_StaticpoolFlag.binned 
                # + woe.OpenTradeBalance.binned #3
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.CCAPREstimate.binned
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned 
                + woe.IRA_StaticpoolFlag.binned 
                + woe.VehicleLoan_StaticPoolFlag.binned
                + woe.RevolvingAccountCount.binned
                + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                + woe.TopOfWalletCCCurrentBalance.binned 
                + woe.MortgageOpenCount.binned 
                + woe.MOB_SAVINGS.binned 
                # + woe.CCOpenCount.binned #2
                + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned 
                + woe.DFT_PRODUCT_IRA_Q1_Q3.binned 
                # + woe.AggregatedSpendPast3Months.binned #1
                , data=df37,family = binomial(logit))

a34 = Anova(log_reg34,type="II",test="Wald")
v34 = vif(log_reg34)

write.csv(a34,"Anova.csv")
write.csv(v34,"VIF.csv")

summary(log_reg34)

org_reg34 = glm(CD_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1
                + DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3
                + NumberInquiriesP6Months
                # + OpenTradeBalance #3
                + RevolvingAccountCount
                + DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3
                + CCAPREstimate
                + AVG_BALANCECHANGE_DEPOSITS_Q1
                + VehicleLoan_StaticPoolFlag
                + IRA_StaticpoolFlag
                + TopOfWalletCCCurrentBalance
                + WITHDRAWAL_AMOUNT_MONEYMARKET_Q1
                # + CCOpenCount #2
                + MortgageOpenCount
                + MONEYMARKET_StaticpoolFlag
                + DFT_PRODUCT_IRA_Q1_Q3
                + MOB_SAVINGS
                + DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2
                # + AggregatedSpendPast3Months #1
                ,data = NAReplace_train,family = binomial(link = 'logit'))

summary(org_reg34)
o34 = vif(org_reg34)
write.csv(o34,"VIF.csv")

# Accuracy of Model 4

train4 = blr_gains_table(log_reg34,data=df37)
train4

test4 = blr_gains_table(log_reg34,data = CD_test_woe)
test4

# MODEL 5 :

log_reg35 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned
                # + woe.MONEYMARKET_StaticpoolFlag.binned #4
                # + woe.OpenTradeBalance.binned #3
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.CCAPREstimate.binned
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned 
                + woe.IRA_StaticpoolFlag.binned 
                + woe.VehicleLoan_StaticPoolFlag.binned
                + woe.RevolvingAccountCount.binned
                + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                + woe.TopOfWalletCCCurrentBalance.binned 
                + woe.MortgageOpenCount.binned 
                + woe.MOB_SAVINGS.binned 
                # + woe.CCOpenCount.binned #2
                + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned 
                + woe.DFT_PRODUCT_IRA_Q1_Q3.binned 
                # + woe.AggregatedSpendPast3Months.binned #1
                , data=df37,family = binomial(logit))

a35 = Anova(log_reg35,type="II",test="Wald")
v35 = vif(log_reg35)

write.csv(a35,"Anova.csv")
write.csv(v35,"VIF.csv")

summary(log_reg35)

org_reg35 = glm(CD_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1
                + DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3
                + NumberInquiriesP6Months
                # + OpenTradeBalance #3
                + RevolvingAccountCount
                + DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3
                + CCAPREstimate
                + AVG_BALANCECHANGE_DEPOSITS_Q1
                + VehicleLoan_StaticPoolFlag
                + IRA_StaticpoolFlag
                + TopOfWalletCCCurrentBalance
                + WITHDRAWAL_AMOUNT_MONEYMARKET_Q1
                # + CCOpenCount #2
                + MortgageOpenCount
                # + MONEYMARKET_StaticpoolFlag #4
                + DFT_PRODUCT_IRA_Q1_Q3
                + MOB_SAVINGS
                + DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2
                # + AggregatedSpendPast3Months #1
                ,data = NAReplace_train,family = binomial(link = 'logit'))

summary(org_reg35)
o35 = vif(org_reg35)
write.csv(o35,"VIF.csv")

# Accuracy of Model 5

train5 = blr_gains_table(log_reg35,data=df37)
train5

test5 = blr_gains_table(log_reg35,data = CD_test_woe)
test5

# MODEL 6 :

log_reg36 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned
                # + woe.MONEYMARKET_StaticpoolFlag.binned #4
                # + woe.OpenTradeBalance.binned #3
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.CCAPREstimate.binned
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned 
                + woe.IRA_StaticpoolFlag.binned 
                + woe.VehicleLoan_StaticPoolFlag.binned
                # + woe.RevolvingAccountCount.binned #5
                + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                + woe.TopOfWalletCCCurrentBalance.binned 
                + woe.MortgageOpenCount.binned 
                + woe.MOB_SAVINGS.binned 
                # + woe.CCOpenCount.binned #2
                + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned 
                + woe.DFT_PRODUCT_IRA_Q1_Q3.binned 
                # + woe.AggregatedSpendPast3Months.binned #1
                , data=df37,family = binomial(logit))

a36 = Anova(log_reg36,type="II",test="Wald")
v36 = vif(log_reg36)

write.csv(a36,"Anova.csv")
write.csv(v36,"VIF.csv")

summary(log_reg36)

org_reg36 = glm(CD_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1
                + DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3
                + NumberInquiriesP6Months
                # + OpenTradeBalance #3
                # + RevolvingAccountCount #5
                + DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3
                + CCAPREstimate
                + AVG_BALANCECHANGE_DEPOSITS_Q1
                + VehicleLoan_StaticPoolFlag
                + IRA_StaticpoolFlag
                + TopOfWalletCCCurrentBalance
                + WITHDRAWAL_AMOUNT_MONEYMARKET_Q1
                # + CCOpenCount #2
                + MortgageOpenCount
                # + MONEYMARKET_StaticpoolFlag #4
                + DFT_PRODUCT_IRA_Q1_Q3
                + MOB_SAVINGS
                + DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2
                # + AggregatedSpendPast3Months #1
                ,data = NAReplace_train,family = binomial(link = 'logit'))

summary(org_reg36)
o36 = vif(org_reg36)
write.csv(o36,"VIF.csv")

# Accuracy of Model 6

train6 = blr_gains_table(log_reg36,data=df37)
train6

test6 = blr_gains_table(log_reg36,data = CD_test_woe)
test6


# MODEL 7 :

log_reg37 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned
                # + woe.MONEYMARKET_StaticpoolFlag.binned #4
                # + woe.OpenTradeBalance.binned #3
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.CCAPREstimate.binned
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned
                + woe.IRA_StaticpoolFlag.binned 
                + woe.VehicleLoan_StaticPoolFlag.binned
                # + woe.RevolvingAccountCount.binned #5
                + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                + woe.TopOfWalletCCCurrentBalance.binned 
                + woe.MortgageOpenCount.binned 
                + woe.MOB_SAVINGS.binned 
                # + woe.CCOpenCount.binned #2
                # + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned #6
                + woe.DFT_PRODUCT_IRA_Q1_Q3.binned 
                # + woe.AggregatedSpendPast3Months.binned #1
                , data=df37,family = binomial(logit))

a37 = Anova(log_reg37,type="II",test="Wald")
v37 = vif(log_reg37)

write.csv(a37,"Anova.csv")
write.csv(v37,"VIF.csv")

summary(log_reg37)

org_reg37 = glm(CD_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1
                + DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3
                + NumberInquiriesP6Months
                # + OpenTradeBalance #3
                # + RevolvingAccountCount #5
                + DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3
                + CCAPREstimate
                + AVG_BALANCECHANGE_DEPOSITS_Q1
                + VehicleLoan_StaticPoolFlag
                + IRA_StaticpoolFlag
                + TopOfWalletCCCurrentBalance
                + WITHDRAWAL_AMOUNT_MONEYMARKET_Q1
                # + CCOpenCount #2
                + MortgageOpenCount
                # + MONEYMARKET_StaticpoolFlag #4
                + DFT_PRODUCT_IRA_Q1_Q3
                + MOB_SAVINGS
                # + DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2
                # + AggregatedSpendPast3Months #1
                ,data = NAReplace_train,family = binomial(link = 'logit'))

summary(org_reg37)
o37 = vif(org_reg37)
write.csv(o37,"VIF.csv")

# Accuracy of Model 7

train7 = blr_gains_table(log_reg37,data=df37)
train7

test7 = blr_gains_table(log_reg37,data = CD_test_woe)
test7



# MODEL 8 :

log_reg38 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned
                # + woe.MONEYMARKET_StaticpoolFlag.binned #4
                # + woe.OpenTradeBalance.binned #3
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.CCAPREstimate.binned
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned
                + woe.IRA_StaticpoolFlag.binned 
                + woe.VehicleLoan_StaticPoolFlag.binned
                # + woe.RevolvingAccountCount.binned #5
                + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                + woe.TopOfWalletCCCurrentBalance.binned 
                + woe.MortgageOpenCount.binned 
                + woe.MOB_SAVINGS.binned 
                # + woe.CCOpenCount.binned #2
                # + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned #6
                # + woe.DFT_PRODUCT_IRA_Q1_Q3.binned #7
                # + woe.AggregatedSpendPast3Months.binned #1
                , data=df37,family = binomial(logit))

a38 = Anova(log_reg38,type="II",test="Wald")
v38 = vif(log_reg38)

write.csv(a38,"Anova.csv")
write.csv(v38,"VIF.csv")

summary(log_reg38)

org_reg38 = glm(CD_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1
                + DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3
                + NumberInquiriesP6Months
                # + OpenTradeBalance #3
                # + RevolvingAccountCount #5
                + DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3
                + CCAPREstimate
                + AVG_BALANCECHANGE_DEPOSITS_Q1
                + VehicleLoan_StaticPoolFlag
                + IRA_StaticpoolFlag
                + TopOfWalletCCCurrentBalance
                + WITHDRAWAL_AMOUNT_MONEYMARKET_Q1
                # + CCOpenCount #2
                + MortgageOpenCount
                # + MONEYMARKET_StaticpoolFlag #4
                # + DFT_PRODUCT_IRA_Q1_Q3 #7
                + MOB_SAVINGS
                # + DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2 #6
                # + AggregatedSpendPast3Months #1
                ,data = NAReplace_train,family = binomial(link = 'logit'))

summary(org_reg38)
o38 = vif(org_reg38)
write.csv(o38,"VIF.csv")

# Accuracy of Model 7

train8 = blr_gains_table(log_reg38,data=df37)
train8

test8 = blr_gains_table(log_reg38,data = CD_test_woe)
test8

# MODEL 9 :

log_reg39 = glm(formula = CD_TargetFlag ~ woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned
                # + woe.MONEYMARKET_StaticpoolFlag.binned #4
                # + woe.OpenTradeBalance.binned #3
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.CCAPREstimate.binned
                # + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned
                + woe.IRA_StaticpoolFlag.binned 
                + woe.VehicleLoan_StaticPoolFlag.binned
                # + woe.RevolvingAccountCount.binned #5
                # + woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned
                + woe.TopOfWalletCCCurrentBalance.binned 
                + woe.MortgageOpenCount.binned 
                + woe.MOB_SAVINGS.binned 
                # + woe.CCOpenCount.binned #2
                # + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned #6
                # + woe.DFT_PRODUCT_IRA_Q1_Q3.binned #7
                # + woe.AggregatedSpendPast3Months.binned #1
                # + woe.MOB_MONEYMARKET.binned
                + woe.CCCount.binned
                , data=df37,family = binomial(logit))

a38 = Anova(log_reg38,type="II",test="Wald")
v38 = vif(log_reg38)

write.csv(a38,"Anova.csv")
write.csv(v38,"VIF.csv")

summary(log_reg38)

org_reg38 = glm(CD_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1
                + DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3
                + NumberInquiriesP6Months
                # + OpenTradeBalance #3
                # + RevolvingAccountCount #5
                + DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3
                + CCAPREstimate
                + AVG_BALANCECHANGE_DEPOSITS_Q1
                + VehicleLoan_StaticPoolFlag
                + IRA_StaticpoolFlag
                + TopOfWalletCCCurrentBalance
                + WITHDRAWAL_AMOUNT_MONEYMARKET_Q1
                # + CCOpenCount #2
                + MortgageOpenCount
                # + MONEYMARKET_StaticpoolFlag #4
                # + DFT_PRODUCT_IRA_Q1_Q3 #7
                + MOB_SAVINGS
                # + DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2 #6
                # + AggregatedSpendPast3Months #1
                ,data = NAReplace_train,family = binomial(link = 'logit'))

summary(org_reg38)
o38 = vif(org_reg38)
write.csv(o38,"VIF.csv")

# Accuracy of Model 7

train9 = blr_gains_table(log_reg39,data=df37)
train9

test9 = blr_gains_table(log_reg39,data = CD_test_woe)
test9




# MODEL (Another Approach) :

df38 = subset(df37,select = -c(woe.MONEYMARKET_StaticpoolFlag.binned,
                               woe.RevolvingAccountCount.binned,
                               woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned,
                               woe.DFT_PRODUCT_IRA_Q1_Q3.binned,
                               woe.TopOfWalletCCCurrentBalance.binned,
                               woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned,
                               woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned,
                               woe.OpenTradeBalance.binned,
                               woe.CCOpenCount.binned,
                               woe.AggregatedSpendPast3Months.binned))

dim(df38) # 38 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list38 = colnames(subset(df38,select = - CD_TargetFlag))
stepwise_38 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list38, data = df38, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

# Model 9

log_reg39 = glm(formula = CD_TargetFlag ~ woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                +  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned 
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.MortgageOpenCount.binned
                + woe.CCCount.binned
                + woe.CCOpenBalance.binned
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned
                + woe.VehicleLoan_StaticPoolFlag.binned 
                + woe.IRA_StaticpoolFlag.binned 
                + woe.CCAPREstimate.binned 
                + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned
                + woe.MOB_SAVINGS.binned
                + woe.MOB_MONEYMARKET.binned
                + woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3.binned
                + woe.COUNT_HOMEBANKING_STATICPOOL.binned, 
                family = binomial(logit), data = df38)
a39 = Anova(log_reg39,type="II",test="Wald")
v39 = vif(log_reg39)

write.csv(a39,"Anova.csv")
write.csv(v39,"VIF.csv")

summary(log_reg39)

org_reg39 = glm(CD_TargetFlag ~ WITHDRAWAL_AMOUNT_MONEYMARKET_Q1+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  NumberInquiriesP6Months+
                  DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3+
                  MortgageOpenCount+
                  CCCount+
                  CCOpenBalance+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  VehicleLoan_StaticPoolFlag+
                  IRA_StaticpoolFlag+
                  CCAPREstimate+
                  DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2+
                  MOB_SAVINGS+
                  MOB_MONEYMARKET+
                  DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3+
                  COUNT_HOMEBANKING_STATICPOOL
                ,data=NAReplace_train,family=binomial(link = 'logit'))

summary(org_reg39)

o39 = vif(org_reg39)
write.csv(o39,"VIF.csv")

# Model 10

log_reg40 = glm(formula = CD_TargetFlag ~ woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                +  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned 
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.MortgageOpenCount.binned
                + woe.CCCount.binned
                + woe.CCOpenBalance.binned
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned
                + woe.VehicleLoan_StaticPoolFlag.binned 
                + woe.IRA_StaticpoolFlag.binned 
                + woe.CCAPREstimate.binned 
                # + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned #1
                + woe.MOB_SAVINGS.binned
                + woe.MOB_MONEYMARKET.binned
                + woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3.binned
                + woe.COUNT_HOMEBANKING_STATICPOOL.binned, 
                family = binomial(logit), data = df38)
a40 = Anova(log_reg40,type="II",test="Wald")
v40 = vif(log_reg40)

write.csv(a40,"Anova.csv")
write.csv(v40,"VIF.csv")

summary(log_reg40)

org_reg40 = glm(CD_TargetFlag ~ WITHDRAWAL_AMOUNT_MONEYMARKET_Q1+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  NumberInquiriesP6Months+
                  DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3+
                  MortgageOpenCount+
                  CCCount+
                  CCOpenBalance+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  VehicleLoan_StaticPoolFlag+
                  IRA_StaticpoolFlag+
                  CCAPREstimate+
                  # DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2+ #1
                  MOB_SAVINGS+
                  MOB_MONEYMARKET+
                  DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3+
                  COUNT_HOMEBANKING_STATICPOOL
                ,data=NAReplace_train,family=binomial(link = 'logit'))

summary(org_reg40)

o40 = vif(org_reg40)
write.csv(o40,"VIF.csv")

# Model 11

log_reg41 = glm(formula = CD_TargetFlag ~ woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                +  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned 
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.MortgageOpenCount.binned
                # + woe.CCCount.binned #2
                + woe.CCOpenBalance.binned
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned
                + woe.VehicleLoan_StaticPoolFlag.binned 
                + woe.IRA_StaticpoolFlag.binned 
                + woe.CCAPREstimate.binned 
                # + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned #1
                + woe.MOB_SAVINGS.binned
                + woe.MOB_MONEYMARKET.binned
                + woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3.binned
                + woe.COUNT_HOMEBANKING_STATICPOOL.binned, 
                family = binomial(logit), data = df38)
a41 = Anova(log_reg41,type="II",test="Wald")
v41 = vif(log_reg41)

write.csv(a41,"Anova.csv")
write.csv(v41,"VIF.csv")

summary(log_reg41)

org_reg41 = glm(CD_TargetFlag ~ WITHDRAWAL_AMOUNT_MONEYMARKET_Q1+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  NumberInquiriesP6Months+
                  DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3+
                  MortgageOpenCount+
                  # CCCount+ #2
                  CCOpenBalance+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  VehicleLoan_StaticPoolFlag+
                  IRA_StaticpoolFlag+
                  CCAPREstimate+
                  # DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2+ #1
                  MOB_SAVINGS+
                  MOB_MONEYMARKET+
                  DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3+
                  COUNT_HOMEBANKING_STATICPOOL
                ,data=NAReplace_train,family=binomial(link = 'logit'))

summary(org_reg41)

o41 = vif(org_reg41)
write.csv(o41,"VIF.csv")

# Model 12

log_reg42 = glm(formula = CD_TargetFlag ~ woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                +  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned 
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.MortgageOpenCount.binned
                # + woe.CCCount.binned #2
                + woe.CCOpenBalance.binned
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned
                + woe.VehicleLoan_StaticPoolFlag.binned 
                + woe.IRA_StaticpoolFlag.binned 
                + woe.CCAPREstimate.binned 
                # + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned #1
                + woe.MOB_SAVINGS.binned
                # + woe.MOB_MONEYMARKET.binned #3
                + woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3.binned
                + woe.COUNT_HOMEBANKING_STATICPOOL.binned, 
                family = binomial(logit), data = df38)

a42 = Anova(log_reg42,type="II",test="Wald")
v42 = vif(log_reg42)

write.csv(a42,"Anova.csv")
write.csv(v42,"VIF.csv")

summary(log_reg42)

org_reg42 = glm(CD_TargetFlag ~ WITHDRAWAL_AMOUNT_MONEYMARKET_Q1+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  NumberInquiriesP6Months+
                  DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3+
                  MortgageOpenCount+
                  # CCCount+
                  CCOpenBalance+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  VehicleLoan_StaticPoolFlag+
                  IRA_StaticpoolFlag+
                  CCAPREstimate+
                  # DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2+ #1
                  MOB_SAVINGS+
                  # MOB_MONEYMARKET+ #3
                  DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3+
                  COUNT_HOMEBANKING_STATICPOOL
                ,data=NAReplace_train,family=binomial(link = 'logit'))

summary(org_reg42)

o42 = vif(org_reg42)
write.csv(o42,"VIF.csv")

# Accuracy 

train12 = blr_gains_table(log_reg42,data = df38)
test12 = blr_gains_table(log_reg42,data = CD_test_woe)

# Model 13

log_reg43 = glm(formula = CD_TargetFlag ~ woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                +  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned 
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.MortgageOpenCount.binned
                # + woe.CCCount.binned #2
                + woe.CCOpenBalance.binned
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned
                + woe.VehicleLoan_StaticPoolFlag.binned 
                + woe.IRA_StaticpoolFlag.binned 
                + woe.CCAPREstimate.binned
                # + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned #1
                + woe.MOB_SAVINGS.binned 
                # + woe.MOB_MONEYMARKET.binned #3
                # + woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3.binned # 4
                + woe.COUNT_HOMEBANKING_STATICPOOL.binned 
                ,family = binomial(logit), data = df38)

a43 = Anova(log_reg43,type="II",test="Wald")
v43 = vif(log_reg43)

write.csv(a43,"Anova.csv")
write.csv(v43,"VIF.csv")

summary(log_reg43)

org_reg43 = glm(CD_TargetFlag ~ WITHDRAWAL_AMOUNT_MONEYMARKET_Q1+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  NumberInquiriesP6Months+
                  DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3+
                  MortgageOpenCount+
                  # CCCount+ #2
                  CCOpenBalance+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  VehicleLoan_StaticPoolFlag+
                  IRA_StaticpoolFlag+
                  CCAPREstimate+
                  # DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2+ #1
                  MOB_SAVINGS +
                  # MOB_MONEYMARKET+ #3
                  # DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3+ #4
                  COUNT_HOMEBANKING_STATICPOOL
                ,data=NAReplace_train,family=binomial(link = 'logit'))

summary(org_reg43)

o43 = vif(org_reg43)
write.csv(o43,"VIF.csv")

# Accuracy 

train13 = blr_gains_table(log_reg43,data = df38)
test13 = blr_gains_table(log_reg43,data = CD_test_woe)

# Model 14

df39 = subset(df38,select = -c( woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned,woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3.binned
                                ,woe.CCCount.binned,woe.CCOpenBalance.binned,woe.MOB_MONEYMARKET.binned ))
dim(df39) #33 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list39 = colnames(subset(df39,select = - CD_TargetFlag))
stepwise_39 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list39, data = df39, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg44 = glm(CD_TargetFlag ~ woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned 
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned
                + woe.MortgageOpenCount.binned 
                + woe.VehicleLoan_StaticPoolFlag.binned 
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned
                + woe.CCAPREstimate.binned
                + woe.IRA_StaticpoolFlag.binned
                + woe.MOB_SAVINGS.binned
                + woe.TopOfWalletCCAnnualSpend.binned
                + woe.COUNT_HOMEBANKING_STATICPOOL.binned
                + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3.binned
                ,data = df39,family = binomial(logit))

a44 = Anova(log_reg44,type="II",test="Wald")
v44 = vif(log_reg44)
summary(log_reg44)

write.csv(a44,"Anova.csv")
write.csv(v44,"VIF.csv")

org_reg44 = glm(CD_TargetFlag ~ WITHDRAWAL_AMOUNT_MONEYMARKET_Q1+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MortgageOpenCount+
                  DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3+
                  NumberInquiriesP6Months+
                  IRA_StaticpoolFlag+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  CCAPREstimate+
                  MOB_SAVINGS+
                  VehicleLoan_StaticPoolFlag+
                  TopOfWalletCCAnnualSpend+
                  COUNT_HOMEBANKING_STATICPOOL+
                  DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3
                ,data = NAReplace_train,family = binomial(link="logit"))
summary(org_reg44)
o44=vif(org_reg44)
write.csv(o44,"VIF.csv")

train14 = blr_gains_table(log_reg44,data=df39)
test14 = blr_gains_table(log_reg44,data=CD_test_woe)

# MODEL 15

log_reg45 = glm(CD_TargetFlag ~ woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned 
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned
                + woe.MortgageOpenCount.binned 
                + woe.VehicleLoan_StaticPoolFlag.binned 
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned
                + woe.CCAPREstimate.binned
                + woe.IRA_StaticpoolFlag.binned
                + woe.MOB_SAVINGS.binned
                + woe.TopOfWalletCCAnnualSpend.binned
                + woe.COUNT_HOMEBANKING_STATICPOOL.binned
                # + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3.binned #1
                ,data = df39,family = binomial(logit))

a45 = Anova(log_reg45,type="II",test="Wald")
v45 = vif(log_reg45)
summary(log_reg45)

write.csv(a45,"Anova.csv")
write.csv(v45,"VIF.csv")

org_reg45 = glm(CD_TargetFlag ~ WITHDRAWAL_AMOUNT_MONEYMARKET_Q1+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MortgageOpenCount+
                  DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3+
                  NumberInquiriesP6Months+
                  IRA_StaticpoolFlag+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  CCAPREstimate+
                  MOB_SAVINGS+
                  VehicleLoan_StaticPoolFlag+
                  TopOfWalletCCAnnualSpend+
                  COUNT_HOMEBANKING_STATICPOOL
                # +DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3 #1
                ,data = NAReplace_train,family = binomial(link="logit"))
summary(org_reg45)
o45=vif(org_reg45)
write.csv(o45,"VIF.csv")

train15 = blr_gains_table(log_reg45,data=df39)
test15 = blr_gains_table(log_reg45,data=CD_test_woe)

# Model 16

log_reg46 = glm(CD_TargetFlag ~ woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned 
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned
                + woe.MortgageOpenCount.binned 
                + woe.VehicleLoan_StaticPoolFlag.binned 
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned
                + woe.CCAPREstimate.binned
                + woe.IRA_StaticpoolFlag.binned
                + woe.MOB_SAVINGS.binned
                # + woe.TopOfWalletCCAnnualSpend.binned #2
                + woe.COUNT_HOMEBANKING_STATICPOOL.binned
                # + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3.binned #1
                ,data = df39,family = binomial(logit))

a46 = Anova(log_reg46,type="II",test="Wald")
v46 = vif(log_reg46)
summary(log_reg46)

write.csv(a46,"Anova.csv")
write.csv(v46,"VIF.csv")

org_reg46 = glm(CD_TargetFlag ~ WITHDRAWAL_AMOUNT_MONEYMARKET_Q1+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MortgageOpenCount+
                  DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3+
                  NumberInquiriesP6Months+
                  IRA_StaticpoolFlag+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  CCAPREstimate+
                  MOB_SAVINGS+
                  VehicleLoan_StaticPoolFlag+
                  # TopOfWalletCCAnnualSpend+ #2
                  COUNT_HOMEBANKING_STATICPOOL
                # +DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3 #1
                ,data = NAReplace_train,family = binomial(link="logit"))
summary(org_reg46)
o46=vif(org_reg46)
write.csv(o46,"VIF.csv")

train16 = blr_gains_table(log_reg46,data=df39)
test16 = blr_gains_table(log_reg46,data=CD_test_woe)




#######################################################
###################### Start FROM HERE
#######################################################


# Model 17
df40 = subset(df39,select = -c(woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2.binned ,woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned ,woe.TopOfWalletCCAnnualSpend.binned,woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3.binned))
dim(df40) #31 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list40 = colnames(subset(df40,select = - CD_TargetFlag))
stepwise_40 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list40, data = df40, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)


log_reg46 = glm(CD_TargetFlag ~  woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned +
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned +
                  woe.NumberInquiriesP6Months.binned + 
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned +
                  woe.MortgageOpenCount.binned + 
                  woe.VehicleLoan_StaticPoolFlag.binned + 
                  woe.IRA_StaticpoolFlag.binned + 
                  woe.CCAPREstimate.binned +
                  woe.MOB_SAVINGS.binned +
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned +
                  woe.COUNT_HOMEBANKING_STATICPOOL.binned +
                  woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned
                ,data = df39,family = binomial(logit))

a46 = Anova(log_reg46,type="II",test="Wald")
v46 = vif(log_reg46)
summary(log_reg46)

write.csv(a45,"Anova.csv")
write.csv(v45,"VIF.csv")

org_reg46 = glm(CD_TargetFlag ~WITHDRAWAL_AMOUNT_MONEYMARKET_Q1 + 
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1 +
                  NumberInquiriesP6Months + 
                  DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3 +
                  MortgageOpenCount + 
                  VehicleLoan_StaticPoolFlag + 
                  IRA_StaticpoolFlag + 
                  CCAPREstimate +
                  MOB_SAVINGS +
                  DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3 +
                  COUNT_HOMEBANKING_STATICPOOL + 
                  DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3
                ,data = NAReplace_train,family = binomial(link="logit"))

summary(org_reg46)
o46=vif(org_reg46)
write.csv(o45,"VIF.csv")

train16 = blr_gains_table(log_reg46,data=df39)
test16 = blr_gains_table(log_reg46,data=CD_test_woe)

# Model 18

log_reg45 = glm(CD_TargetFlag ~ woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                # + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned 
                + woe.NumberInquiriesP6Months.binned 
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned
                + woe.MortgageOpenCount.binned 
                + woe.VehicleLoan_StaticPoolFlag.binned 
                # + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned
                # + woe.CCAPREstimate.binned
                + woe.IRA_StaticpoolFlag.binned
                + woe.MOB_SAVINGS.binned
                # + woe.TopOfWalletCCAnnualSpend.binned
                + woe.COUNT_HOMEBANKING_STATICPOOL.binned
                + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3.binned
                # +woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned #Added1
                ,data = df39,family = binomial(logit))

a44 = Anova(log_reg45,type="II",test="Wald")
v44 = vif(log_reg45)
summary(log_reg44)

write.csv(a44,"Anova.csv")
write.csv(v44,"VIF.csv")

org_reg45 = glm(CD_TargetFlag ~ WITHDRAWAL_AMOUNT_MONEYMARKET_Q1+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MortgageOpenCount+
                  # DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3+
                  NumberInquiriesP6Months+
                  IRA_StaticpoolFlag+
                  # AVG_BALANCECHANGE_DEPOSITS_Q1+
                  # CCAPREstimate+
                  MOB_SAVINGS+
                  VehicleLoan_StaticPoolFlag+
                  # TopOfWalletCCAnnualSpend+
                  COUNT_HOMEBANKING_STATICPOOL+
                  DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3
                # DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3
                ,data = NAReplace_train,family = binomial(link="logit"))
summary(org_reg45)
o44=vif(org_reg45)
write.csv(o44,"VIF.csv")

train15 = blr_gains_table(log_reg45,data=df39)
test15 = blr_gains_table(log_reg45,data=CD_test_woe)

# Model 19

df_target = subset(df_train_woe,select = c(woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned,
                                           woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned,
                                           woe.MortgageOpenCount.binned,
                                           woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned,
                                           woe.NumberInquiriesP6Months.binned,
                                           woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned,
                                           woe.IRA_StaticpoolFlag.binned,
                                           woe.CCAPREstimate.binned,
                                           woe.MOB_SAVINGS.binned,
                                           CD_TargetFlag))
dim(df_target) #10 vars

log_reg50 = glm(CD_TargetFlag ~ woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned+
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned+
                  woe.MortgageOpenCount.binned+
                  woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned+
                  woe.NumberInquiriesP6Months.binned+
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned+
                  woe.IRA_StaticpoolFlag.binned+
                  woe.CCAPREstimate.binned+
                  woe.MOB_SAVINGS.binned
                ,data = df_target,family = binomial(logit))

a50 = Anova(log_reg50,type="II",test="Wald")
v50 = vif(log_reg50)
summary(log_reg50)

write.csv(a50,"Anova.csv")
write.csv(v50,"VIF.csv")

org_reg50 = glm(CD_TargetFlag ~ WITHDRAWAL_AMOUNT_MONEYMARKET_Q1+
              AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
              MortgageOpenCount+
              DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3+
              NumberInquiriesP6Months+
              AVG_BALANCECHANGE_DEPOSITS_Q1+
              IRA_StaticpoolFlag+
              CCAPREstimate+
              MOB_SAVINGS
            ,data = NAReplace_train,family = binomial(link="logit"))

summary(org_reg50)

o50 = vif(org_reg50)
write.csv(o50,"VIF.csv")

blr_gains_table(log_reg50,data=df_target)
blr_gains_table(log_reg50,data=CD_test_woe)


# Model 20

df41 = subset(df39,select = -c(woe.MortgageOpenCount.binned,woe.COUNT_ACH_VehicleLoan_Q1.binned,  woe.TopOfWalletCCAnnualSpend.binned,woe.COUNT_HOMEBANKING_STATICPOOL.binned,woe.VehicleLoan_StaticPoolFlag.binned))
dim(df41) #31 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list41 = colnames(subset(df41,select = - CD_TargetFlag))
stepwise_41 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list41, data = df41, sle = 0.05,sls = 0.05, myfamily="binomial")




log_reg51 = glm(formula = CD_TargetFlag ~ woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned
                + woe.NumberInquiriesP6Months.binned
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.MortgageOpenCount.binned 
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned 
                + woe.CCAPREstimate.binned 
                + woe.IRA_StaticpoolFlag.binned 
                + woe.MOB_SAVINGS.binned 
                # + woe.COUNT_ACH_VehicleLoan_Q1.binned 
                # + woe.TopOfWalletCCAnnualSpend.binned
                + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3.binned
                , family = binomial(logit), 
                data = df_target)

a50 = Anova(log_reg51,type="II",test="Wald")
v50 = vif(log_reg51)
summary(log_reg50)

write.csv(a50,"Anova.csv")
write.csv(v50,"VIF.csv")

org_reg50 = glm(CD_TargetFlag ~ WITHDRAWAL_AMOUNT_MONEYMARKET_Q1+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MortgageOpenCount+
                  DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3+
                  NumberInquiriesP6Months+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  IRA_StaticpoolFlag+
                  CCAPREstimate+
                  MOB_SAVINGS+
                  DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3
                ,data = NAReplace_train,family = binomial(link="logit"))

summary(org_reg50)

o50 = vif(org_reg50)
write.csv(o50,"VIF.csv")

blr_gains_table(log_reg51,data=df_target)
blr_gains_table(log_reg51,data=CD_test_woe)

# Model 21

df_target1 = subset(df_train_woe,select = c(woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned,
                                           woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned,
                                           woe.MortgageOpenCount.binned,
                                           woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned,
                                           woe.NumberInquiriesP6Months.binned,
                                           woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned,
                                           woe.IRA_StaticpoolFlag.binned,
                                           woe.CCAPREstimate.binned,
                                           woe.MOB_SAVINGS.binned,
                                           woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned,
                                           woe.TopOfWalletCCAnnualSpend.binned,
                                           CD_TargetFlag))
dim(df_target1)


log_reg52 = glm(formula = CD_TargetFlag ~ woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned
                + woe.NumberInquiriesP6Months.binned
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.MortgageOpenCount.binned
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned
                + woe.CCAPREstimate.binned
                + woe.IRA_StaticpoolFlag.binned 
                + woe.MOB_SAVINGS.binned 
                # + woe.COUNT_ACH_VehicleLoan_Q1.binned
                # + woe.TopOfWalletCCAnnualSpend.binned
                + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned
                , family = binomial(logit), 
                data = df_target1)

a52 = Anova(log_reg52,type="II",test="Wald")
v52 = vif(log_reg52)
summary(log_reg52)

write.csv(a52,"Anova.csv")
write.csv(v52,"VIF.csv")

org_reg52 = glm(CD_TargetFlag ~ WITHDRAWAL_AMOUNT_MONEYMARKET_Q1+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MortgageOpenCount+
                  DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3+
                  NumberInquiriesP6Months+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  IRA_StaticpoolFlag+
                  CCAPREstimate+
                  MOB_SAVINGS+
                  DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2
                ,data = NAReplace_train,family = binomial(link="logit"))

summary(org_reg52)

o52 = vif(org_reg52)
write.csv(o52,"VIF.csv")

blr_gains_table(log_reg52,data=df_target1)
blr_gains_table(log_reg52,data=CD_test_woe)


# Model 22

df41 = subset(df39,select = -c(woe.MortgageOpenCount.binned,woe.COUNT_ACH_VehicleLoan_Q1.binned,  woe.TopOfWalletCCAnnualSpend.binned,woe.COUNT_HOMEBANKING_STATICPOOL.binned,woe.VehicleLoan_StaticPoolFlag.binned))
dim(df41) #31 vars

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list41 = colnames(subset(df41,select = - CD_TargetFlag))
stepwise_41 <- My.stepwise.glm(Y = "CD_TargetFlag", variable_list41, data = df41, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg53 = glm(formula = CD_TargetFlag ~ woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned 
                + woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned
                + woe.NumberInquiriesP6Months.binned
                + woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned 
                + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned
                + woe.CCAPREstimate.binned
                + woe.IRA_StaticpoolFlag.binned 
                + woe.MOB_SAVINGS.binned 
                + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3.binned
                , family = binomial(logit), 
                data = df41)

a53 = Anova(log_reg53,type="II",test="Wald")
v53 = vif(log_reg53)
summary(log_reg53)

write.csv(a53,"Anova.csv")
write.csv(v53,"VIF.csv")

org_reg53 = glm(CD_TargetFlag ~ WITHDRAWAL_AMOUNT_MONEYMARKET_Q1+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3+
                  NumberInquiriesP6Months+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  IRA_StaticpoolFlag+
                  CCAPREstimate+
                  MOB_SAVINGS+
                  DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3
                ,data = NAReplace_train,family = binomial(link="logit"))

summary(org_reg53)

o53 = vif(org_reg53)
write.csv(o53,"VIF.csv")

blr_gains_table(log_reg53,data=df41)
blr_gains_table(log_reg53,data=CD_test_woe)


/********************************************************************** NEXT BEST PRODUCT : CERTIFICATE MODEL *************************************************************************/


/********* DROPPING CERTIFICATE RELATED VARIABLES FROM THE REVISED MASTER DATA ********/

DROP TABLE IF EXISTS #MASTER_DATA

SELECT *

  INTO #MASTER_DATA
  FROM Analytics.dbo.REVISED_MASTER_DATA_juLY2023

  /***************************************************************************** TARGET FLAG CREATION **************************************************************************/

   DROP TABLE IF EXISTS #ShareCategory
 -- Consumer & Commercial Category in Money Market
    SELECT *
	into #ShareCategory
	FROM
	(
  	SELECT *,CASE WHEN ShareCategory2 ='Savings' and ShareCategory3='IRA' then 1 else 0 end [IRA_SAVINGS_FLAG]  
	from ARCUSYM000.ARCU.ARCUShareCategory
	) S
	where 1=1
	    --and ShareCategory3 not in ('HSA','IRA') 
		and ShareCategory1 <> 'Non-Member'
		and ShareType <> '9997'   --(excluding Greenstate Corporate Checking)
		and IRA_SAVINGS_FLAG = 0
		
--  All Savings TABLE  at StaticPool

DECLARE @staticpooldate date
		set @staticpooldate = '2023-07-31' 

DROP TABLE IF EXISTS #savings_SP

SELECT a.PARENTACCOUNT
      ,a.ID
	  ,a.OPENDATE
	  ,a.CLOSEDATE
	  ,a.CHARGEOFFDATE
	  ,a.ProcessDate
	  ,a.BALANCE
	  ,b.ShareTypeDescription
	  ,b.ShareCategory1
	  ,b.ShareCategory2
	  ,b.ShareCategory3
into #savings_SP
FROM [ARCUSYM000].dbo.SAVINGS A
LEFT JOIN #ShareCategory B
ON A.TYPE = B.ShareType
WHERE 1 = 1
and a.ProcessDate = 20230731
--and a.OPENDATE <> a.CLOSEDATE
and (a.OPENDATE is not null or a.openDATE < @staticpooldate)
and ( a.CLOSEDATE is null or a.CLOSEDATE > @staticpooldate)
and ( a.CHARGEOFFDATE > @staticpooldate or 
a.CHARGEOFFDATE is NULL)  --  529251

--  CERTIFICATES AT STATICPOOL 

DROP TABLE IF EXISTS #CD_SP

SELECT DISTINCT PARENTACCOUNT
into #CD_SP
FROM #savings_SP
where ShareCategory2 = 'CD'
and ShareCategory3 not in ('IRA','HSA') -- 16051

--SELECT TOP 100 * FROM #savings_SP
--SELECT * FROM #ShareCategory

-- Mapping the parentaccount of the members having CERTIFICATES on SP to SSN

DROP TABLE IF EXISTS #SSN_CD_SP
SELECT DISTINCT SSN 
INTO #SSN_CD_SP
FROM
(
SELECT A.SSN, CASE WHEN A.PARENTACCOUNT = B.PARENTACCOUNT THEN 1 ELSE 0 END [HaveCDonSP]
FROM ARCUSYM000..NAME A
LEFT JOIN #CD_SP B
ON A.PARENTACCOUNT = B.PARENTACCOUNT
) R
WHERE [HaveCDonSP] = 1 --15420

-- Savings table AFTER StaticPool

DROP TABLE IF EXISTS #savings_after_SP

SELECT a.PARENTACCOUNT
      ,a.ID
	  ,a.OPENDATE
	  ,a.CLOSEDATE
	  ,a.CHARGEOFFDATE
	  ,a.ProcessDate
	  ,case when B.ShareCategory2 = 'CD' and A.BALANCE = 0 then 0 else 1 end [carryforwardflag]
	  ,b.ShareTypeDescription
	  ,b.ShareCategory1
	  ,b.ShareCategory2
	  ,b.ShareCategory3
into #savings_after_SP
FROM [ARCUSYM000].dbo.SAVINGS A
LEFT JOIN #ShareCategory B
ON A.TYPE = B.ShareType
WHERE 1 = 1
and a.ProcessDate BETWEEN 20230731 and 20240630
--and a.OPENDATE <> a.CLOSEDATE
and (a.OPENDATE is not null or a.OPENDATE < @staticpooldate)
and ( a.CLOSEDATE is null
or a.CLOSEDATE > @staticpooldate)
and ( a.CHARGEOFFDATE > @staticpooldate or 
a.CHARGEOFFDATE is NULL)   -- 15737491

--select top 10 * from #savings_after_SP where PARENTACCOUNT ='0014621084' and ID = '0001' order by ProcessDate

-- Savings table without members having CERTIFICATES on Static Pool

DROP TABLE IF EXISTS #savings_wo_CDSP
SELECT *
INTO #savings_wo_CDSP
FROM
(
SELECT a.*
     , CASE WHEN a.PARENTACCOUNT = b.PARENTACCOUNT THEN 0 ELSE 1 END [NoCDinSP]  
FROM #savings_after_SP a
LEFT JOIN #CD_SP b
on a.PARENTACCOUNT = b.PARENTACCOUNT
) M
WHERE [NoCDinSP] = 1 
and carryforwardflag = 1-- 13908836

--  ParentAccount who take CERTIFICATES after SP (Does not have MoneyMarket before SP)

DROP TABLE IF EXISTS #Par_CD_after_SP
SELECT Distinct PARENTACCOUNT
into #Par_CD_after_SP
FROM #savings_wo_CDSP
WHERE ShareCategory2 = 'CD'
and ShareCategory3 not in ('IRA','HSA')  --7393

--  Mapping the ParentAccount to SSN

DROP TABLE IF EXISTS #SSN_Target_CD
SELECT DISTINCT SSN
INTO #SSN_Target_CD
FROM
(
SELECT A.SSN, CASE WHEN A.PARENTACCOUNT = B.PARENTACCOUNT THEN 1 ELSE 0 END [match]
FROM ARCUSYM000..NAME A
LEFT JOIN #Par_CD_after_SP B
ON A.PARENTACCOUNT = B.PARENTACCOUNT
) S
where [match] = 1 -- 7116


-- Final Table Creation :

/*excluding all those SSN having CERTIFICATES in SP*/

DROP TABLE IF EXISTS #temp_CD_exclusion_SP 
SELECT F.*
INTO #temp_CD_exclusion_SP
FROM
(
SELECT A.*, CASE WHEN A.SSN003 = B.SSN THEN 0 ELSE 1 END [NoCDInSP]
FROM #MASTER_DATA A
LEFT JOIN #SSN_CD_SP B
ON A.SSN003 = B.SSN
) F
WHERE [NoCDInSP] = 1  --328564

--DROPPING [NoMMInSP] (we dont need it in final ds)
 
 ALTER TABLE #temp_CD_exclusion_SP DROP COLUMN [NoCDInSP]

 -- FINAL TABLE : Analytics.dbo.NBP_Certificates_202208

DROP TABLE IF EXISTS #temp13

SELECT  A.*,CASE WHEN A.SSN003 = B.SSN THEN 1 ELSE 0 END [CD_TargetFlag]
INTO #temp13
FROM #temp_CD_exclusion_SP A
LEFT JOIN #SSN_Target_CD B
ON A.SSN003 = B.SSN 

/*********** Dropping Members who have MOB less than 6 months *******************/
--select distinct SSN003 from #temp13 --328564
alter table #temp13
drop column ssn001

DECLARE @staticpooldate date
		set @staticpooldate = '2023-07-31' 
drop table if exists Analytics.dbo.NBP_Certificates_validation
select *,ROW_NUMBER() over  (order by ssn003) rnnumber
into Analytics.dbo.NBP_Certificates_validation
from #temp13 
where SSN003 in (select distinct AccountPrimeNameSSN from ARCUSYM000.arcu.ARCUAccountDetailed where ProcessDate = 20230731 and datediff(MONTH,AccountOpenDate,@staticpooldate) >= 6 ) --264701

--SELECT [CD_TargetFlag], Count(*)  FROM Analytics.dbo.NBP_Certificates_validation group by [CD_TargetFlag] --2534
-- Step 1: Calculate NULL percentages for each column
-- Assuming your table name is 'your_table_name'

-- Create a temporary table to store the results
--CREATE PROCEDURE DropColumnsWithHighNulls


SET STATISTICS TIME ON;
SET STATISTICS IO ON;



DECLARE @tableName NVARCHAR(128) = 'NBP_Certificates_validation'
DECLARE @nullPercentageThreshold DECIMAL(10, 2) = 60.0;

SET NOCOUNT ON;

DECLARE @sql NVARCHAR(MAX);
DECLARE @column_name NVARCHAR(128);

-- Temporary table to store null counts
CREATE TABLE #null_counts (
    column_name NVARCHAR(128),
    null_percentage DECIMAL(10, 2)
);

--select * from #null_counts


-- Cursor to iterate over column names
DECLARE cur CURSOR FOR
SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA  + '.' + TABLE_NAME = @tableName;

OPEN cur;
FETCH NEXT FROM cur INTO @column_name;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @sql = '
        INSERT INTO #null_counts (column_name, null_percentage)
        SELECT
            ''' + @column_name + ''' AS column_name,
            100.0 * SUM(CASE WHEN ' + QUOTENAME(@column_name) + ' IS NULL THEN 1 ELSE 0 END) / COUNT(*) AS null_percentage
        FROM ' + @tableName + ';
    ';

    EXEC sp_executesql @sql;

    FETCH NEXT FROM cur INTO @column_name;
END

CLOSE cur;
DEALLOCATE cur;

select * from #null_counts

-- Drop columns where null_percentage >= threshold
DECLARE @columns_to_drop NVARCHAR(MAX) = '';

SELECT @columns_to_drop = @columns_to_drop + 'ALTER TABLE ' + @tableName + ' DROP COLUMN ' + QUOTENAME(column_name) + ';' + CHAR(13)
FROM #null_counts
WHERE null_percentage >= @nullPercentageThreshold;

-- Execute the drop column statements
IF @columns_to_drop <> ''
BEGIN
    BEGIN TRY
        -- Start transaction
        BEGIN TRANSACTION;

        EXEC sp_executesql @columns_to_drop;

        -- Commit transaction
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        -- Rollback transaction if error occurs
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        -- Handle error as per your requirement
        THROW;
    END CATCH
END

-- Clean up
DROP TABLE #null_counts;







-----------------------------------------------
/****** Splitting of Train & Test Data *******/
----------------------------------------------

--	DROP TABLE IF EXISTS Analytics.dbo.NBP_Certificates_train_202209
--	DROP TABLE IF EXISTS Analytics.dbo.NBP_Certificates_test_202209

--		--Creating Training set Template
--	SELECT * 
--	into Analytics.dbo.NBP_Certificates_train_202209
--	FROM Analytics.dbo.NBP_Certificates_202209
--	where 1=0
	
--		--Creating Training set Template
--	SELECT * 
--	into Analytics.dbo.NBP_Certificates_test_202209
--	FROM Analytics.dbo.NBP_Certificates_202209
--	where 1=0
	
--	INSERT INTO Analytics.dbo.NBP_Certificates_train_202209
--	     EXEC sp_execute_external_script
--		             @language = N'R'
--					 , @script = N'

--					 library(caret)

--					 Data1 <- data.frame(Demo1_New)
--					 set.seed(129)
--					 train_indi <- createDataPartition(Data1$CD_TargetFlag,p=0.7,list=F)
--					 train_data <- data.frame(Data1[train_indi,]);
--					 train_data
--					 '
--	     , @output_data_1_name = N'train_data'
--		     ,@input_data_1 = N'SELECT * FROM Analytics.dbo.NBP_Certificates_202209'
--			 , @input_data_1_name = N'Demo1_New'

--INSERT INTO Analytics.dbo.NBP_Certificates_test_202209
--SELECT * 
--from Analytics.dbo.NBP_Certificates_202209
----WHERE SSN003 not in (SELECT SSN from Analytics.dbo.NBP_Certificates_train_202209)
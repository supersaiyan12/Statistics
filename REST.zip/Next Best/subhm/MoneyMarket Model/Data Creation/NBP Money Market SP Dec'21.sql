       
	   /*************************************************************************************************************************************************************************/
	      /*********************************************************** Next Best Product (Money Market) **********************************************************************/ 
	 
	   
	   /****** 1. Declaring the STATIC POOL ******/

		DECLARE @staticpooldate date
		set @staticpooldate = '2021-12-31'


	  /******* 2. ShareCategory Description (CATEGORY = 0) *******/

	  	DROP TABLE IF EXISTS #ShareCategory
	 -- Consumer & Commercial Category in Money Market
		SELECT *
		into #ShareCategory
		FROM
		(
  		SELECT *,CASE WHEN ShareCategory2 ='Savings' and ShareCategory3='IRA' then 1 else 0 end [IRA_SAVINGS_FLAG]  
		from ARCUSYM000.ARCU.ARCUShareCategory
		) S
		where 1=1
			--and ShareCategory3 not in ('HSA','IRA') 
			and ShareCategory1 <> 'Non-Member'
			and ShareType <> '9997'   --(excluding Greenstate Corporate Checking)
			and IRA_SAVINGS_FLAG = 0

		--SELECT * FROM #ShareCategory
		
       /******* 3. Target Flag Creation *********/
	    /******* a. All Savings products at StaticPool ********/

		DROP TABLE IF EXISTS #savings_SP

		SELECT a.PARENTACCOUNT
			  ,a.ID
			  ,a.OPENDATE
			  ,a.CLOSEDATE
			  ,a.CHARGEOFFDATE
			  ,a.ProcessDate
			  ,a.BALANCE
			  ,b.ShareTypeDescription
			  ,b.ShareCategory1
			  ,b.ShareCategory2
			  ,b.ShareCategory3
		into #savings_SP
		FROM (select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date from [ARCUSYM000].dbo.SAVINGS) A
		LEFT JOIN #ShareCategory B
		ON A.TYPE = B.ShareType
		WHERE 1 = 1
		and a.Process_date = @staticpooldate
		and (a.OPENDATE is not null OR  a.OPENDATE < @staticpooldate)
		and ( a.CLOSEDATE is null OR a.CLOSEDATE > @staticpooldate)
		and ( a.CHARGEOFFDATE > @staticpooldate OR a.CHARGEOFFDATE is NULL)  --  538031

			--where ssn is not null 
			 --and Savings_ACCT_MOB>=12  ---commented by nikita on 05/10/2022
			-- and OPEN_DATE<@staticpooldate  
			-- and (CLOSE_DATE is null or CLOSE_DATE>@staticpooldate)
			--and (CHARGEOFFDATE is null or CHARGEOFFDATE>@staticpooldate)  
			--and Process_date=@staticpooldate 

		-- 528554

		/**********  MONEYMARKET AT STATICPOOL ****************/ 


		DROP TABLE IF EXISTS #moneymarket_SP

		SELECT DISTINCT PARENTACCOUNT
		into #moneymarket_SP
		FROM #savings_SP
		where ShareCategory2 = 'Money Market'
		and ShareCategory3 not in ('IRA','HSA') -- 10537

		--SELECT * FROM #moneymarket_SP
		--SELECT * FROM #ShareCategory

 /********** 4. FETCHING SSN ALONG WITH WEHTHER THEY HAVE MONEYMARKET ON STATIC POOL ****************/ 

		DROP TABLE IF EXISTS #SSN_moneymarket_SP
		SELECT DISTINCT SSN 
		INTO #SSN_moneymarket_SP
		FROM
		(
		SELECT A.SSN, CASE WHEN A.PARENTACCOUNT = B.PARENTACCOUNT THEN 1 ELSE 0 END [HaveMMonSP]
		FROM ARCUSYM000..NAME A
		LEFT JOIN #moneymarket_SP B
		ON A.PARENTACCOUNT = B.PARENTACCOUNT
		) R
		WHERE [HaveMMonSP] = 1 --10537

			--SELECT * FROM #SSN_moneymarket_SP

		/********* b. 5.Savings table AFTER StaticPool (scenario after 1 year staticpool) *********/

		DROP TABLE IF EXISTS #savings_after_SP

		SELECT a.PARENTACCOUNT
			  ,a.ID
			  ,a.OPENDATE
			  ,a.CLOSEDATE
			  ,a.CHARGEOFFDATE
			  ,a.ProcessDate
			  ,case when B.ShareCategory2 = 'CD' and A.BALANCE = 0 then 0 else 1 end [carryforwardflag]
			  ,b.ShareTypeDescription
			  ,b.ShareCategory1
			  ,b.ShareCategory2
			  ,b.ShareCategory3
		into #savings_after_SP
		FROM (select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date from [ARCUSYM000].dbo.SAVINGS) A
		LEFT JOIN #ShareCategory B
		ON A.TYPE = B.ShareType
		WHERE 1 = 1
		and a.Process_date BETWEEN DATEADD(MM,1,@staticpooldate) and DATEADD(MM,12,@staticpooldate)
		--and a.OPENDATE <> a.CLOSEDATE
		and (a.OPENDATE is not null or a.OPENDATE < @staticpooldate )
		and ( a.CLOSEDATE is null  or a.CLOSEDATE > @staticpooldate)
		and ( a.CHARGEOFFDATE > @staticpooldate or a.CHARGEOFFDATE is NULL )  -- 6274598

		--select  count(1) from #savings_after_SP where PARENTACCOUNT ='0014621084' and ID = '0001' order by ProcessDate

		/************************ 6.Savings table without members having Money Market on Static Pool and 12 month more ************************************/

		DROP TABLE IF EXISTS #savings_wo_MMSP
		SELECT *
		INTO #savings_wo_MMSP
		FROM
		(
		SELECT a.*
			 , CASE WHEN a.PARENTACCOUNT = b.PARENTACCOUNT THEN 0 ELSE 1 END [NoMMinSP]  
		FROM #savings_after_SP a
		LEFT JOIN #moneymarket_SP b
		on a.PARENTACCOUNT = b.PARENTACCOUNT
		) M
		WHERE [NoMMinSP] = 1 
		and carryforwardflag = 1-- 5879014

		/************************  7. ParentAccount who take MoneyMarket after SP (Does not have MoneyMarket before SP) *************/

		DROP TABLE IF EXISTS #Par_MM_after_SP
		SELECT Distinct PARENTACCOUNT
		into #Par_MM_after_SP
		FROM #savings_wo_MMSP
		WHERE ShareCategory2 = 'Money Market'
		and ShareCategory3 not in ('IRA','HSA')  --1769

		--select * from #Par_MM_after_SP -- 1777

		/************************  8. Mapping the ParentAccount to SSN ***********************/

		DROP TABLE IF EXISTS #SSN_Target_MM
		SELECT DISTINCT SSN
		INTO #SSN_Target_MM
		FROM
		(
		SELECT A.SSN, CASE WHEN A.PARENTACCOUNT = B.PARENTACCOUNT THEN 1 ELSE 0 END [match]
		FROM ARCUSYM000..NAME A
		LEFT JOIN #Par_MM_after_SP B
		ON A.PARENTACCOUNT = B.PARENTACCOUNT
		) S
		where [match] = 1 -- 1707

		--select * from #SSN_Target_MM -- 1712


       /******* 4. Final Table Creation ********/
	   /******* a. TAKING ALL THE VARIABLES EXCEPT THE MONEYMARKET VARIABLES FROM REVISED MASTER DATA *********/

		   DROP TABLE IF EXISTS #NBP_MoneyMarket

		   SELECT  [SSN003]
		  ,[PRODUCT_SAVINGS_SP]
		  ,[PRODUCT_SAVINGS_Q1]
		  ,[DFT_PRODUCT_SAVINGS_Q1_Q2]
		  ,[DFT_PRODUCT_SAVINGS_Q1_Q3]
		  ,[TYPE_SAVINGS_SP]
		  ,[TYPE_SAVINGS_Q1]
		  ,[DFT_TYPE_SAVINGS_Q1_Q2]
		  ,[DFT_TYPE_SAVINGS_Q1_Q3]
		  ,[MOB_SAVINGS]
		  ,[AVG_MONTH_END_BALANCE_SAVINGS_Q1]
		  ,[DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2]
		  ,[DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3]
		  ,[SUM_LASTDIVAMOUNT_SAVINGS_Q1]
		  ,[DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2]
		  ,[DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3]
		  ,[AVG_CHARGEOFFAMOUNT_SAVINGS_SP]
		  ,[AVG_CHARGEOFFAMOUNT_SAVINGS_Q1]
		  ,[DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q2]
		  ,[DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q3]
		  ,[PRODUCT_CHECKING_SP]
		  ,[PRODUCT_CHECKING_Q1]
		  ,[DFT_PRODUCT_CHECKING_Q1_Q2]
		  ,[DFT_PRODUCT_CHECKING_Q1_Q3]
		  ,[TYPE_CHECKING_SP]
		  ,[TYPE_CHECKING_Q1]
		  ,[DFT_TYPE_CHECKING_Q1_Q2]
		  ,[DFT_TYPE_CHECKING_Q1_Q3]
		  ,[MOB_CHECKING]
		  ,[AVG_MONTH_END_BALANCE_CHECKING_Q1]
		  ,[DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2]
		  ,[DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3]
		  ,[SUM_LASTDIVAMOUNT_CHECKING_Q1]
		  ,[DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2]
		  ,[DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q3]
		  ,[AVG_CHARGEOFFAMOUNT_CHECKING_SP]
		  ,[AVG_CHARGEOFFAMOUNT_CHECKING_Q1]
		  ,[DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q2]
		  ,[DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q3]
		  ,[PRODUCT_CERTIFICATES_SP]
		  ,[PRODUCT_CERTIFICATES_Q1]
		  ,[DFT_PRODUCT_CERTIFICATES_Q1_Q2]
		  ,[DFT_PRODUCT_CERTIFICATES_Q1_Q3]
		  ,[TYPE_CERTIFICATES_SP]
		  ,[TYPE_CERTIFICATES_Q1]
		  ,[DFT_TYPE_CERTIFICATES_Q1_Q2]
		  ,[DFT_TYPE_CERTIFICATES_Q1_Q3]
		  ,[MOB_CERTIFICATES]
		  ,[AVG_MONTH_END_BALANCE_CERTIFICATES_Q1]
		  ,[DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2]
		  ,[DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q3]
		  ,[SUM_LASTDIVAMOUNT_CERTIFICATES_Q1]
		  ,[DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q2]
		  ,[DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q3]
		  ,[AVG_CHARGEOFFAMOUNT_CERTIFICATES_SP]
		  ,[AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1]
		  ,[DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q2]
		  ,[DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q3]
		  ,[PRODUCT_IRA_SP]
		  ,[PRODUCT_IRA_Q1]
		  ,[DFT_PRODUCT_IRA_Q1_Q2]
		  ,[DFT_PRODUCT_IRA_Q1_Q3]
		  ,[TYPE_IRA_SP]
		  ,[TYPE_IRA_Q1]
		  ,[DFT_TYPE_IRA_Q1_Q2]
		  ,[DFT_TYPE_IRA_Q1_Q3]
		  ,[MOB_IRA]
		  ,[AVG_MONTH_END_BALANCE_IRA_Q1]
		  ,[DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q2]
		  ,[DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q3]
		  ,[SUM_LASTDIVAMOUNT_IRA_Q1]
		  ,[DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q2]
		  ,[DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q3]
		  ,[AVG_CHARGEOFFAMOUNT_IRA_Q1]
		  ,[DFT_AVG_CHARGEOFFAMOUNT_IRA_Q1_Q2]
		  ,[PRODUCT_HSA_SP]
		  ,[PRODUCT_HSA_Q1]
		  ,[DFT_PRODUCT_HSA_Q1_Q2]
		  ,[DFT_PRODUCT_HSA_Q1_Q3]
		  ,[TYPE_HSA_SP]
		  ,[TYPE_HSA_Q1]
		  ,[DFT_TYPE_HSA_Q1_Q2]
		  ,[DFT_TYPE_HSA_Q1_Q3]
		  ,[MOB_HSA]
		  ,[AVG_MONTH_END_BALANCE_HSA_Q1]
		  ,[DFT_AVG_MONTH_END_BALANCE_HSA_Q1_Q2]
		  ,[DFT_AVG_MONTH_END_BALANCE_HSA_Q1_Q3]
		  ,[SUM_LASTDIVAMOUNT_HSA_Q1]
		  ,[DFT_SUM_LASTDIVAMOUNT_HSA_Q1_Q2]
		  ,[DFT_SUM_LASTDIVAMOUNT_HSA_Q1_Q3]
		  ,[AVG_CHARGEOFFAMOUNT_HSA_Q1]
		  ,[PRODUCT_DEPOSITS_SP]
		  ,[PRODUCT_DEPOSITS_Q1]
		  ,[DFT_PRODUCT_DEPOSITS_Q1_Q2]
		  ,[DFT_PRODUCT_DEPOSITS_Q1_Q3]
		  ,[TYPE_DEPOSITS_Q1]
		  ,[DFT_TYPE_DEPOSITS_Q1_Q2]
		  ,[DFT_TYPE_DEPOSITS_Q1_Q3]
		  ,[MOB_DEPOSITS]
		  ,[AVG_MONTH_END_BALANCE_DEPOSITS_Q1]
		  ,[DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2]
		  ,[DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3]
		  ,[SUM_LASTDIVAMOUNT_DEPOSITS_Q1]
		  ,[DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2]
		  ,[DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3]
		  ,[AVG_CHARGEOFFAMOUNT_DEPOSITS_SP]
		  ,[AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1]
		  ,[DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q2]
		  ,[DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q3]
		  ,[SAVINGS_StaticpoolFlag]
		  ,[CHECKING_StaticpoolFlag]
		  ,[CERTIFICATES_StaticpoolFlag]
		  ,[IRA_StaticpoolFlag]
		  ,[HSA_StaticpoolFlag]
		  ,[SAVINGS_Q1Flag]
		  ,[CHECKING_Q1Flag]
		  ,[CERTIFICATES_Q1Flag]
		  ,[IRA_Q1Flag]
		  ,[HSA_Q1Flag]
		  ,[SSN004]
		  ,[TRANSACTION_COUNT_SAVINGS_Q1]
		  ,[DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2]
		  ,[DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3]
		  ,[TRANSACTION_AMOUNT_SAVINGS_Q1]
		  ,[DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2]
		  ,[DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3]
		  ,[AVG_TRANSACTION_SAVINGS_Q1]
		  ,[DFT_AVG_TRANSACTION_SAVINGS_Q1_Q2]
		  ,[DFT_AVG_TRANSACTION_SAVINGS_Q1_Q3]
		  ,[DEPOSITED_AMOUNT_SAVINGS_Q1]
		  ,[DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2]
		  ,[DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3]
		  ,[DEPOSITED_COUNT_SAVINGS_Q1]
		  ,[DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2]
		  ,[DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3]
		  ,[WITHDRAWAL_AMOUNT_SAVINGS_Q1]
		  ,[DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2]
		  ,[DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3]
		  ,[WITHDRAWAL_COUNT_SAVINGS_Q1]
		  ,[DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2]
		  ,[DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q3]
		  ,[SUM_INTEREST_SAVINGS_Q1]
		  ,[DFT_SUM_INTEREST_SAVINGS_Q1_Q2]
		  ,[DFT_SUM_INTEREST_SAVINGS_Q1_Q3]
		  ,[TRANSACTION_COUNT_CHECKING_Q1]
		  ,[DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2]
		  ,[DFT_TRANSACTION_COUNT_CHECKING_Q1_Q3]
		  ,[TRANSACTION_AMOUNT_CHECKING_Q1]
		  ,[DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2]
		  ,[DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3]
		  ,[AVG_TRANSACTION_CHECKING_Q1]
		  ,[DFT_AVG_TRANSACTION_CHECKING_Q1_Q2]
		  ,[DFT_AVG_TRANSACTION_CHECKING_Q1_Q3]
		  ,[DEPOSITED_AMOUNT_CHECKING_Q1]
		  ,[DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2]
		  ,[DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3]
		  ,[DEPOSITED_COUNT_CHECKING_Q1]
		  ,[DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2]
		  ,[DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3]
		  ,[WITHDRAWAL_AMOUNT_CHECKING_Q1]
		  ,[DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2]
		  ,[DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q3]
		  ,[WITHDRAWAL_COUNT_CHECKING_Q1]
		  ,[DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2]
		  ,[DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q3]
		  ,[SUM_INTEREST_CHECKING_Q1]
		  ,[DFT_SUM_INTEREST_CHECKING_Q1_Q2]
		  ,[DFT_SUM_INTEREST_CHECKING_Q1_Q3]
		  ,[TRANSACTION_COUNT_CERTIFICATES_Q1]
		  ,[DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q2]
		  ,[DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q3]
		  ,[TRANSACTION_AMOUNT_CERTIFICATES_Q1]
		  ,[DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q2]
		  ,[DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q3]
		  ,[AVG_TRANSACTION_CERTIFICATES_Q1]
		  ,[DFT_AVG_TRANSACTION_CERTIFICATES_Q1_Q2]
		  ,[DFT_AVG_TRANSACTION_CERTIFICATES_Q1_Q3]
		  ,[DEPOSITED_AMOUNT_CERTIFICATES_Q1]
		  ,[DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q2]
		  ,[DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q3]
		  ,[DEPOSITED_COUNT_CERTIFICATES_Q1]
		  ,[DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q2]
		  ,[DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q3]
		  ,[WITHDRAWAL_AMOUNT_CERTIFICATES_Q1]
		  ,[DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q2]
		  ,[DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q3]
		  ,[WITHDRAWAL_COUNT_CERTIFICATES_Q1]
		  ,[DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q2]
		  ,[DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q3]
		  ,[SUM_INTEREST_CERTIFICATES_Q1]
		  ,[DFT_SUM_INTEREST_CERTIFICATES_Q1_Q2]
		  ,[DFT_SUM_INTEREST_CERTIFICATES_Q1_Q3]
		  ,[TRANSACTION_COUNT_IRA_Q1]
		  ,[DFT_TRANSACTION_COUNT_IRA_Q1_Q2]
		  ,[DFT_TRANSACTION_COUNT_IRA_Q1_Q3]
		  ,[TRANSACTION_AMOUNT_IRA_Q1]
		  ,[DFT_TRANSACTION_AMOUNT_IRA_Q1_Q2]
		  ,[DFT_TRANSACTION_AMOUNT_IRA_Q1_Q3]
		  ,[AVG_TRANSACTION_IRA_Q1]
		  ,[DFT_AVG_TRANSACTION_IRA_Q1_Q2]
		  ,[DFT_AVG_TRANSACTION_IRA_Q1_Q3]
		  ,[DEPOSITED_AMOUNT_IRA_Q1]
		  ,[DFT_DEPOSITED_AMOUNT_IRA_Q1_Q2]
		  ,[DFT_DEPOSITED_AMOUNT_IRA_Q1_Q3]
		  ,[DEPOSITED_COUNT_IRA_Q1]
		  ,[DFT_DEPOSITED_COUNT_IRA_Q1_Q2]
		  ,[DFT_DEPOSITED_COUNT_IRA_Q1_Q3]
		  ,[WITHDRAWAL_AMOUNT_IRA_Q1]
		  ,[DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q2]
		  ,[DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q3]
		  ,[WITHDRAWAL_COUNT_IRA_Q1]
		  ,[DFT_WITHDRAWAL_COUNT_IRA_Q1_Q2]
		  ,[DFT_WITHDRAWAL_COUNT_IRA_Q1_Q3]
		  ,[SUM_INTEREST_IRA_Q1]
		  ,[DFT_SUM_INTEREST_IRA_Q1_Q2]
		  ,[DFT_SUM_INTEREST_IRA_Q1_Q3]
		  ,[TRANSACTION_COUNT_HSA_Q1]
		  ,[DFT_TRANSACTION_COUNT_HSA_Q1_Q2]
		  ,[DFT_TRANSACTION_COUNT_HSA_Q1_Q3]
		  ,[TRANSACTION_AMOUNT_HSA_Q1]
		  ,[DFT_TRANSACTION_AMOUNT_HSA_Q1_Q2]
		  ,[DFT_TRANSACTION_AMOUNT_HSA_Q1_Q3]
		  ,[AVG_TRANSACTION_HSA_Q1]
		  ,[DFT_AVG_TRANSACTION_HSA_Q1_Q2]
		  ,[DFT_AVG_TRANSACTION_HSA_Q1_Q3]
		  ,[DEPOSITED_AMOUNT_HSA_Q1]
		  ,[DFT_DEPOSITED_AMOUNT_HSA_Q1_Q2]
		  ,[DFT_DEPOSITED_AMOUNT_HSA_Q1_Q3]
		  ,[DEPOSITED_COUNT_HSA_Q1]
		  ,[DFT_DEPOSITED_COUNT_HSA_Q1_Q2]
		  ,[DFT_DEPOSITED_COUNT_HSA_Q1_Q3]
		  ,[WITHDRAWAL_AMOUNT_HSA_Q1]
		  ,[DFT_WITHDRAWAL_AMOUNT_HSA_Q1_Q2]
		  ,[DFT_WITHDRAWAL_AMOUNT_HSA_Q1_Q3]
		  ,[WITHDRAWAL_COUNT_HSA_Q1]
		  ,[DFT_WITHDRAWAL_COUNT_HSA_Q1_Q2]
		  ,[DFT_WITHDRAWAL_COUNT_HSA_Q1_Q3]
		  ,[SUM_INTEREST_HSA_Q1]
		  ,[DFT_SUM_INTEREST_HSA_Q1_Q2]
		  ,[DFT_SUM_INTEREST_HSA_Q1_Q3]
		  ,[TRANSACTION_COUNT_DEPOSITS_Q1]
		  ,[DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q2]
		  ,[DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3]
		  ,[TRANSACTION_AMOUNT_DEPOSITS_Q1]
		  ,[DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2]
		  ,[DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3]
		  ,[AVG_TRANSACTION_DEPOSITS_Q1]
		  ,[DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q2]
		  ,[DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q3]
		  ,[DEPOSITED_AMOUNT_DEPOSITS_Q1]
		  ,[DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2]
		  ,[DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3]
		  ,[DEPOSITED_COUNT_DEPOSITS_Q1]
		  ,[DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2]
		  ,[DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q3]
		  ,[WITHDRAWAL_AMOUNT_DEPOSITS_Q1]
		  ,[DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2]
		  ,[DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q3]
		  ,[WITHDRAWAL_COUNT_DEPOSITS_Q1]
		  ,[DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2]
		  ,[DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3]
		  ,[SUM_INTEREST_DEPOSITS_Q1]
		  ,[DFT_SUM_INTEREST_DEPOSITS_Q1_Q2]
		  ,[DFT_SUM_INTEREST_DEPOSITS_Q1_Q3]
		  ,[SSN001]
		  ,[PRODUCT_CommercialLoan_Q1]
		  ,[DFT_PRODUCT_CommercialLoan_Q1_Q2]
		  ,[DFT_PRODUCT_CommercialLoan_Q1_Q3]
		  ,[PRODUCT_RealEstate_Q1]
		  ,[DFT_PRODUCT_RealEstate_Q1_Q2]
		  ,[DFT_PRODUCT_RealEstate_Q1_Q3]
		  ,[PRODUCT_SecuredLoan_Q1]
		  ,[DFT_PRODUCT_SecuredLoan_Q1_Q2]
		  ,[DFT_PRODUCT_SecuredLoan_Q1_Q3]
		  ,[PRODUCT_UnsecuredLoan_Q1]
		  ,[DFT_PRODUCT_UnsecuredLoan_Q1_Q2]
		  ,[DFT_PRODUCT_UnsecuredLoan_Q1_Q3]
		  ,[PRODUCT_VehicleLoan_Q1]
		  ,[DFT_PRODUCT_VehicleLoan_Q1_Q2]
		  ,[DFT_PRODUCT_VehicleLoan_Q1_Q3]
		  ,[PRODUCT_Others_Q1]
		  ,[DFT_PRODUCT_Others_Q1_Q2]
		  ,[DFT_PRODUCT_Others_Q1_Q3]
		  ,[PRODUCT_Loan_Q1]
		  ,[DFT_PRODUCT_Loan_Q1_Q2]
		  ,[DFT_PRODUCT_Loan_Q1_Q3]
		  ,[TYPE_CommercialLoan_Q1]
		  ,[DFT_TYPE_CommercialLoan_Q1_Q2]
		  ,[DFT_TYPE_CommercialLoan_Q1_Q3]
		  ,[TYPE_RealEstate_Q1]
		  ,[DFT_TYPE_RealEstate_Q1_Q2]
		  ,[DFT_TYPE_RealEstate_Q1_Q3]
		  ,[TYPE_SecuredLoan_Q1]
		  ,[DFT_TYPE_SecuredLoan_Q1_Q2]
		  ,[DFT_TYPE_SecuredLoan_Q1_Q3]
		  ,[TYPE_UnsecuredLoan_Q1]
		  ,[DFT_TYPE_UnsecuredLoan_Q1_Q2]
		  ,[DFT_TYPE_UnsecuredLoan_Q1_Q3]
		  ,[TYPE_VehicleLoan_Q1]
		  ,[DFT_TYPE_VehicleLoan_Q1_Q2]
		  ,[DFT_TYPE_VehicleLoan_Q1_Q3]
		  ,[TYPE_Others_Q1]
		  ,[DFT_TYPE_Others_Q1_Q2]
		  ,[DFT_TYPE_Others_Q1_Q3]
		  ,[TYPE_Loan_Q1]
		  ,[DFT_TYPE_Loan_Q1_Q2]
		  ,[DFT_TYPE_Loan_Q1_Q3]
		  ,[CommercialLoan_MOB]
		  ,[RealEstate_MOB]
		  ,[SecuredLoan_MOB]
		  ,[UnsecuredLoan_MOB]
		  ,[Vehicleloan_MOB]
		  ,[Others_MOB]
		  ,[MAX_Loan_MOB]
		  ,[PAYMENTCOUNT_CommercialLoan_Q1]
		  ,[DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q2]
		  ,[DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q3]
		  ,[PAYMENTCOUNT_RealEstate_Q1]
		  ,[DFT_PAYMENTCOUNT_RealEstate_Q1_Q2]
		  ,[DFT_PAYMENTCOUNT_RealEstate_Q1_Q3]
		  ,[PAYMENTCOUNT_SecuredLoan_Q1]
		  ,[DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q2]
		  ,[DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q3]
		  ,[PAYMENTCOUNT_UnsecuredLoan_Q1]
		  ,[DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q2]
		  ,[DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q3]
		  ,[PAYMENTCOUNT_VehicleLoan_Q1]
		  ,[DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q2]
		  ,[DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q3]
		  ,[PAYMENTCOUNT_Others_Q1]
		  ,[DFT_PAYMENTCOUNT_Others_Q1_Q2]
		  ,[DFT_PAYMENTCOUNT_Others_Q1_Q3]
		  ,[PAYMENTCOUNT_Loan_Q1]
		  ,[DFT_PAYMENTCOUNT_Loan_Q1_Q2]
		  ,[DFT_PAYMENTCOUNT_Loan_Q1_Q3]
		  ,[SUM_OriginalBalance_CommercialLoan_Q1]
		  ,[DFT_SUM_OriginalBalance_CommercialLoan_Q1_Q2]
		  ,[DFT_SUM_OriginalBalance_CommercialLoan_Q1_Q3]
		  ,[SUM_OriginalBalance_RealEstate_Q1]
		  ,[DFT_SUM_OriginalBalance_RealEstate_Q1_Q2]
		  ,[DFT_SUM_OriginalBalance_RealEstate_Q1_Q3]
		  ,[SUM_OriginalBalance_SecuredLoan_Q1]
		  ,[DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q2]
		  ,[DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q3]
		  ,[SUM_OriginalBalance_UnsecuredLoan_Q1]
		  ,[DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q2]
		  ,[DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q3]
		  ,[SUM_OriginalBalance_VehicleLoan_Q1]
		  ,[DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q2]
		  ,[DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q3]
		  ,[SUM_OriginalBalance_Others_Q1]
		  ,[DFT_SUM_OriginalBalance_Others_Q1_Q2]
		  ,[DFT_SUM_OriginalBalance_Others_Q1_Q3]
		  ,[SUM_OriginalBalance_Loan_Q1]
		  ,[DFT_SUM_OriginalBalance_Loan_Q1_Q2]
		  ,[DFT_SUM_OriginalBalance_Loan_Q1_Q3]
		  ,[SUM_PAYMENT_CommercialLoan_Q1]
		  ,[DFT_SUM_PAYMENT_CommercialLoan_Q1_Q2]
		  ,[DFT_SUM_PAYMENT_CommercialLoan_Q1_Q3]
		  ,[SUM_PAYMENT_RealEstate_Q1]
		  ,[DFT_SUM_PAYMENT_RealEstate_Q1_Q2]
		  ,[DFT_SUM_PAYMENT_RealEstate_Q1_Q3]
		  ,[SUM_PAYMENT_SecuredLoan_Q1]
		  ,[DFT_SUM_PAYMENT_SecuredLoan_Q1_Q2]
		  ,[DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3]
		  ,[SUM_PAYMENT_UnsecuredLoan_Q1]
		  ,[DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q2]
		  ,[DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q3]
		  ,[SUM_PAYMENT_VehicleLoan_Q1]
		  ,[DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2]
		  ,[DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3]
		  ,[SUM_PAYMENT_Others_Q1]
		  ,[DFT_SUM_PAYMENT_Others_Q1_Q2]
		  ,[DFT_SUM_PAYMENT_Others_Q1_Q3]
		  ,[SUM_PAYMENT_Loan_Q1]
		  ,[DFT_SUM_PAYMENT_Loan_Q1_Q2]
		  ,[DFT_SUM_PAYMENT_Loan_Q1_Q3]
		  ,[MAX_INTERESTRATE_CommercialLoan_Q1]
		  ,[DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q2]
		  ,[DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q3]
		  ,[MAX_INTERESTRATE_RealEstate_Q1]
		  ,[DFT_MAX_INTERESTRATE_RealEstate_Q1_Q2]
		  ,[DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3]
		  ,[MAX_INTERESTRATE_SecuredLoan_Q1]
		  ,[DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q2]
		  ,[DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3]
		  ,[MAX_INTERESTRATE_UnsecuredLoan_Q1]
		  ,[DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q2]
		  ,[DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q3]
		  ,[MAX_INTERESTRATE_VehicleLoan_Q1]
		  ,[DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q2]
		  ,[DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q3]
		  ,[MAX_INTERESTRATE_Others_Q1]
		  ,[DFT_MAX_INTERESTRATE_Others_Q1_Q2]
		  ,[DFT_MAX_INTERESTRATE_Others_Q1_Q3]
		  ,[MAX_INTERESTRATE_Loan_Q1]
		  ,[DFT_MAX_INTERESTRATE_Loan_Q1_Q2]
		  ,[DFT_MAX_INTERESTRATE_Loan_Q1_Q3]
		  ,[MAX_CREDITLIMIT_CommercialLoan_Q1]
		  ,[DFT_MAX_CREDITLIMIT_CommercialLoan_Q1_Q2]
		  ,[DFT_MAX_CREDITLIMIT_CommercialLoan_Q1_Q3]
		  ,[MAX_CREDITLIMIT_RealEstate_Q1]
		  ,[DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q2]
		  ,[DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q3]
		  ,[MAX_CREDITLIMIT_SecuredLoan_Q1]
		  ,[DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q2]
		  ,[DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q3]
		  ,[MAX_CREDITLIMIT_UnsecuredLoan_Q1]
		  ,[DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q2]
		  ,[DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q3]
		  ,[MAX_CREDITLIMIT_VehicleLoan_Q1]
		  ,[DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q2]
		  ,[DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q3]
		  ,[MAX_CREDITLIMIT_Others_Q1]
		  ,[DFT_MAX_CREDITLIMIT_Others_Q1_Q2]
		  ,[DFT_MAX_CREDITLIMIT_Others_Q1_Q3]
		  ,[MAX_CREDITLIMIT_Loan_Q1]
		  ,[DFT_MAX_CREDITLIMIT_Loan_Q1_Q2]
		  ,[DFT_MAX_CREDITLIMIT_Loan_Q1_Q3]
		  ,[CommercialLoan_Month_to_Maturity]
		  ,[RealEstate_Month_to_Maturity]
		  ,[SecuredLoan_Month_to_Maturity]
		  ,[UnsecuredLoan_Month_to_Maturity]
		  ,[Vehicleloan_Month_to_Maturity]
		  ,[Others_Month_to_Maturity]
		  ,[Max_Loan_Month_to_Maturity]
		  ,[CommercialLoan_OPENDATE]
		  ,[CommercialLoan_CLOSEDATE]
		  ,[RealEstate_OPENDATE]
		  ,[RealEstate_CLOSEDATE]
		  ,[SecuredLoan_OPENDATE]
		  ,[SecuredLoan_CLOSEDATE]
		  ,[UnsecuredLoan_OPENDATE]
		  ,[UnsecuredLoan_CLOSEDATE]
		  ,[Vehicleloan_OPENDATE]
		  ,[Vehicleloan_CLOSEDATE]
		  ,[Others_OPENDATE]
		  ,[Others_CLOSEDATE]
		  ,[Min_Loan_OPENDATE]
		  ,[Max_Loan_CLOSEDATE]
		  ,[CommercialLoan_StaticPoolFlag]
		  ,[RealEstate_StaticPoolFlag]
		  ,[SecuredLoan_StaticPoolFlag]
		  ,[UnsecuredLoan_StaticPoolFlag]
		  ,[VehicleLoan_StaticPoolFlag]
		  ,[CommercialLoan_Q1Flag]
		  ,[RealEstate_Q1Flag]
		  ,[SecuredLoan_Q1Flag]
		  ,[UnsecuredLoan_Q1Flag]
		  ,[VehicleLoan_Q1Flag]
		  ,[SSN002]
		  ,[COUNT_LOAN_ADDON_STATICPOOL]
		  ,[COUNT_LOAN_ADDON_Q1]
		  ,[DFT_COUNT_LOAN_ADDON_Q1_Q2]
		  ,[DFT_COUNT_LOAN_ADDON_Q1_Q3]
		  ,[COUNT_NEW_LOAN_STATICPOOL]
		  ,[COUNT_NEW_LOAN_Q1]
		  ,[DFT_COUNT_NEW_LOAN_Q1_Q2]
		  ,[DFT_COUNT_NEW_LOAN_Q1_Q3]
		  ,[COUNT_LOAN_PAYMENT_STATICPOOL]
		  ,[COUNT_LOAN_PAYMENT_Q1]
		  ,[DFT_COUNT_LOAN_PAYMENT_Q1_Q2]
		  ,[DFT_COUNT_LOAN_PAYMENT_Q1_Q3]
		  ,[COUNT_CASH_STATICPOOL]
		  ,[COUNT_CASH_Q1]
		  ,[DFT_COUNT_CASH_Q1_Q2]
		  ,[DFT_COUNT_CASH_Q1_Q3]
		  ,[COUNT_DRAFT_STATICPOOL]
		  ,[COUNT_DRAFT_Q1]
		  ,[DFT_COUNT_DRAFT_Q1_Q2]
		  ,[DFT_COUNT_DRAFT_Q1_Q3]
		  ,[COUNT_ACH_STATICPOOL]
		  ,[COUNT_ACH_Q1]
		  ,[DFT_COUNT_ACH_Q1_Q2]
		  ,[DFT_COUNT_ACH_Q1_Q3]
		  ,[COUNT_FEE_STATICPOOL]
		  ,[COUNT_FEE_Q1]
		  ,[DFT_COUNT_FEE_Q1_Q2]
		  ,[DFT_COUNT_FEE_Q1_Q3]
		  ,[COUNT_HOMEBANKING_STATICPOOL]
		  ,[COUNT_HOMEBANKING_Q1]
		  ,[DFT_COUNT_HOMEBANKING_Q1_Q2]
		  ,[DFT_COUNT_HOMEBANKING_Q1_Q3]
		  ,[COUNT_INSURANCE_STATICPOOL]
		  ,[COUNT_INSURANCE_Q1]
		  ,[DFT_COUNT_INSURANCE_Q1_Q2]
		  ,[DFT_COUNT_INSURANCE_Q1_Q3]
		  ,[COUNT_CHECKS_STATICPOOL]
		  ,[COUNT_CHECKS_Q1]
		  ,[DFT_COUNT_CHECKS_Q1_Q2]
		  ,[DFT_COUNT_CHECKS_Q1_Q3]
		  ,[COUNT_PAYROLL_STATICPOOL]
		  ,[COUNT_PAYROLL_Q1]
		  ,[DFT_COUNT_PAYROLL_Q1_Q2]
		  ,[DFT_COUNT_PAYROLL_Q1_Q3]
		  ,[COUNT_KIOSK_STATICPOOL]
		  ,[COUNT_KIOSK_Q1]
		  ,[DFT_COUNT_KIOSK_Q1_Q2]
		  ,[DFT_COUNT_KIOSK_Q1_Q3]
		  ,[COUNT_AUDIO_RESPONSE_TELEPHONE_STATICPOOL]
		  ,[COUNT_AUDIO_RESPONSE_TELEPHONE_Q1]
		  ,[DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q2]
		  ,[DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q3]
		  ,[COUNT_LOAN_ADDON_CommercialLoan_Q1]
		  ,[DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q2]
		  ,[DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q3]
		  ,[COUNT_NEW_LOAN_CommercialLoan_Q1]
		  ,[COUNT_NEW_LOAN_CommercialLoan_Q1_Q2]
		  ,[COUNT_NEW_LOAN_CommercialLoan_Q1_Q3]
		  ,[COUNT_LOAN_PAYMENT_CommercialLoan_Q1]
		  ,[DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q2]
		  ,[DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q3]
		  ,[COUNT_CASH_CommercialLoan_Q1]
		  ,[DFT_COUNT_CASH_CommercialLoan_Q1_Q2]
		  ,[DFT_COUNT_CASH_CommercialLoan_Q1_Q3]
		  ,[COUNT_DRAFT_CommercialLoan_Q1]
		  ,[DFT_COUNT_DRAFT_CommercialLoan_Q1_Q2]
		  ,[DFT_COUNT_DRAFT_CommercialLoan_Q1_Q3]
		  ,[COUNT_ACH_CommercialLoan_Q1]
		  ,[DFT_COUNT_ACH_CommercialLoan_Q1_Q2]
		  ,[DFT_COUNT_ACH_CommercialLoan_Q1_Q3]
		  ,[COUNT_FEE_CommercialLoan_Q1]
		  ,[DFT_COUNT_FEE_CommercialLoan_Q1_Q2]
		  ,[DFT_COUNT_FEE_CommercialLoan_Q1_Q3]
		  ,[COUNT_HOMEBANKING_CommercialLoan_Q1]
		  ,[DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q2]
		  ,[DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q3]
		  ,[COUNT_INSURANCE_CommercialLoan_Q1]
		  ,[DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q2]
		  ,[DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q3]
		  ,[COUNT_CHECKS_CommercialLoan_Q1]
		  ,[DFT_COUNT_CHECKS_CommercialLoan_Q1_Q2]
		  ,[DFT_COUNT_CHECKS_CommercialLoan_Q1_Q3]
		  ,[COUNT_PAYROLL_CommercialLoan_Q1]
		  ,[DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q2]
		  ,[DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q3]
		  ,[COUNT_KIOSK_CommercialLoan_Q1]
		  ,[DFT_COUNT_KIOSK_CommercialLoan_Q1_Q2]
		  ,[DFT_COUNT_KIOSK_CommercialLoan_Q1_Q3]
		  ,[COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1]
		  ,[DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q2]
		  ,[DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q3]
		  ,[LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1]
		  ,[DFT_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q2]
		  ,[DFT_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q3]
		  ,[INTEREST_AMOUNT_CommercialLoan_Q1]
		  ,[DFT_INTEREST_AMOUNT_CommercialLoan_Q1_Q2]
		  ,[DFT_INTEREST_AMOUNT_CommercialLoan_Q1_Q3]
		  ,[FEEAMOUNT_CommercialLoan_Q1]
		  ,[DFT_FEEAMOUNT_CommercialLoan_Q1_Q2]
		  ,[DFT_FEEAMOUNT_CommercialLoan_Q1_Q3]
		  ,[AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1]
		  ,[DFT_AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q2]
		  ,[DFT_AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q3]
		  ,[AVG_NEWBALANCE_CommercialLoan_Q1]
		  ,[DFT_AVG_NEWBALANCE_CommercialLoan_Q1_Q2]
		  ,[DFT_AVG_NEWBALANCE_CommercialLoan_Q1_Q3]
		  ,[AVG_FEEAMOUNT_CommercialLoan_Q1]
		  ,[DFT_AVG_FEEAMOUNT_CommercialLoan_Q1_Q2]
		  ,[DFT_AVG_FEEAMOUNT_CommercialLoan_Q1_Q3]
		  ,[COUNT_LOAN_ADDON_RealEstate_Q1]
		  ,[DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q2]
		  ,[DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q3]
		  ,[COUNT_NEW_LOAN_RealEstate_Q1]
		  ,[COUNT_NEW_LOAN_RealEstate_Q1_Q2]
		  ,[COUNT_NEW_LOAN_RealEstate_Q1_Q3]
		  ,[COUNT_LOAN_PAYMENT_RealEstate_Q1]
		  ,[DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q2]
		  ,[DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q3]
		  ,[COUNT_CASH_RealEstate_Q1]
		  ,[DFT_COUNT_CASH_RealEstate_Q1_Q2]
		  ,[DFT_COUNT_CASH_RealEstate_Q1_Q3]
		  ,[COUNT_DRAFT_RealEstate_Q1]
		  ,[DFT_COUNT_DRAFT_RealEstate_Q1_Q2]
		  ,[DFT_COUNT_DRAFT_RealEstate_Q1_Q3]
		  ,[COUNT_ACH_RealEstate_Q1]
		  ,[DFT_COUNT_ACH_RealEstate_Q1_Q2]
		  ,[DFT_COUNT_ACH_RealEstate_Q1_Q3]
		  ,[COUNT_FEE_RealEstate_Q1]
		  ,[DFT_COUNT_FEE_RealEstate_Q1_Q2]
		  ,[DFT_COUNT_FEE_RealEstate_Q1_Q3]
		  ,[COUNT_HOMEBANKING_RealEstate_Q1]
		  ,[DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q2]
		  ,[DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q3]
		  ,[COUNT_INSURANCE_RealEstate_Q1]
		  ,[DFT_COUNT_INSURANCE_RealEstate_Q1_Q2]
		  ,[DFT_COUNT_INSURANCE_RealEstate_Q1_Q3]
		  ,[COUNT_CHECKS_RealEstate_Q1]
		  ,[DFT_COUNT_CHECKS_RealEstate_Q1_Q2]
		  ,[DFT_COUNT_CHECKS_RealEstate_Q1_Q3]
		  ,[COUNT_PAYROLL_RealEstate_Q1]
		  ,[DFT_COUNT_PAYROLL_RealEstate_Q1_Q2]
		  ,[DFT_COUNT_PAYROLL_RealEstate_Q1_Q3]
		  ,[COUNT_KIOSK_RealEstate_Q1]
		  ,[DFT_COUNT_KIOSK_RealEstate_Q1_Q2]
		  ,[DFT_COUNT_KIOSK_RealEstate_Q1_Q3]
		  ,[COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1]
		  ,[DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q2]
		  ,[DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q3]
		  ,[LOAN_TRANSACTION_AMOUNT_RealEstate_Q1]
		  ,[DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2]
		  ,[DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q3]
		  ,[INTEREST_AMOUNT_RealEstate_Q1]
		  ,[DFT_INTEREST_AMOUNT_RealEstate_Q1_Q2]
		  ,[DFT_INTEREST_AMOUNT_RealEstate_Q1_Q3]
		  ,[FEEAMOUNT_RealEstate_Q1]
		  ,[DFT_FEEAMOUNT_RealEstate_Q1_Q2]
		  ,[DFT_FEEAMOUNT_RealEstate_Q1_Q3]
		  ,[AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1]
		  ,[DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2]
		  ,[DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q3]
		  ,[AVG_NEWBALANCE_RealEstate_Q1]
		  ,[DFT_AVG_NEWBALANCE_RealEstate_Q1_Q2]
		  ,[DFT_AVG_NEWBALANCE_RealEstate_Q1_Q3]
		  ,[AVG_FEEAMOUNT_RealEstate_Q1]
		  ,[DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q2]
		  ,[DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q3]
		  ,[COUNT_LOAN_ADDON_SecuredLoan_Q1]
		  ,[DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q3]
		  ,[COUNT_NEW_LOAN_SecuredLoan_Q1]
		  ,[COUNT_NEW_LOAN_SecuredLoan_Q1_Q2]
		  ,[COUNT_NEW_LOAN_SecuredLoan_Q1_Q3]
		  ,[COUNT_LOAN_PAYMENT_SecuredLoan_Q1]
		  ,[DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q3]
		  ,[COUNT_CASH_SecuredLoan_Q1]
		  ,[DFT_COUNT_CASH_SecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_CASH_SecuredLoan_Q1_Q3]
		  ,[COUNT_DRAFT_SecuredLoan_Q1]
		  ,[DFT_COUNT_DRAFT_SecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_DRAFT_SecuredLoan_Q1_Q3]
		  ,[COUNT_ACH_SecuredLoan_Q1]
		  ,[DFT_COUNT_ACH_SecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_ACH_SecuredLoan_Q1_Q3]
		  ,[COUNT_FEE_SecuredLoan_Q1]
		  ,[DFT_COUNT_FEE_SecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_FEE_SecuredLoan_Q1_Q3]
		  ,[COUNT_HOMEBANKING_SecuredLoan_Q1]
		  ,[DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q3]
		  ,[COUNT_INSURANCE_SecuredLoan_Q1]
		  ,[DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q3]
		  ,[COUNT_CHECKS_SecuredLoan_Q1]
		  ,[DFT_COUNT_CHECKS_SecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_CHECKS_SecuredLoan_Q1_Q3]
		  ,[COUNT_PAYROLL_SecuredLoan_Q1]
		  ,[DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q3]
		  ,[COUNT_KIOSK_SecuredLoan_Q1]
		  ,[DFT_COUNT_KIOSK_SecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_KIOSK_SecuredLoan_Q1_Q3]
		  ,[COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1]
		  ,[DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q3]
		  ,[LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1]
		  ,[DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2]
		  ,[DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q3]
		  ,[INTEREST_AMOUNT_SecuredLoan_Q1]
		  ,[DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q2]
		  ,[DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q3]
		  ,[FEEAMOUNT_SecuredLoan_Q1]
		  ,[DFT_FEEAMOUNT_SecuredLoan_Q1_Q2]
		  ,[DFT_FEEAMOUNT_SecuredLoan_Q1_Q3]
		  ,[AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1]
		  ,[DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2]
		  ,[DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q3]
		  ,[AVG_NEWBALANCE_SecuredLoan_Q1]
		  ,[DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q2]
		  ,[DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q3]
		  ,[AVG_FEEAMOUNT_SecuredLoan_Q1]
		  ,[DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q2]
		  ,[DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q3]
		  ,[COUNT_LOAN_ADDON_UnsecuredLoan_Q1]
		  ,[DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q3]
		  ,[COUNT_NEW_LOAN_UnsecuredLoan_Q1]
		  ,[COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q2]
		  ,[COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q3]
		  ,[COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1]
		  ,[DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q3]
		  ,[COUNT_CASH_UnsecuredLoan_Q1]
		  ,[DFT_COUNT_CASH_UnsecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_CASH_UnsecuredLoan_Q1_Q3]
		  ,[COUNT_DRAFT_UnsecuredLoan_Q1]
		  ,[DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q3]
		  ,[COUNT_ACH_UnsecuredLoan_Q1]
		  ,[DFT_COUNT_ACH_UnsecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_ACH_UnsecuredLoan_Q1_Q3]
		  ,[COUNT_FEE_UnsecuredLoan_Q1]
		  ,[DFT_COUNT_FEE_UnsecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_FEE_UnsecuredLoan_Q1_Q3]
		  ,[COUNT_HOMEBANKING_UnsecuredLoan_Q1]
		  ,[DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q3]
		  ,[COUNT_INSURANCE_UnsecuredLoan_Q1]
		  ,[DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q3]
		  ,[COUNT_CHECKS_UnsecuredLoan_Q1]
		  ,[DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q3]
		  ,[COUNT_PAYROLL_UnsecuredLoan_Q1]
		  ,[DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q3]
		  ,[COUNT_KIOSK_UnsecuredLoan_Q1]
		  ,[DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q3]
		  ,[COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1]
		  ,[DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q2]
		  ,[DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q3]
		  ,[LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1]
		  ,[DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2]
		  ,[DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q3]
		  ,[INTEREST_AMOUNT_UnsecuredLoan_Q1]
		  ,[DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q2]
		  ,[DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q3]
		  ,[FEEAMOUNT_UnsecuredLoan_Q1]
		  ,[DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q2]
		  ,[DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q3]
		  ,[AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1]
		  ,[DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2]
		  ,[DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q3]
		  ,[AVG_NEWBALANCE_UnsecuredLoan_Q1]
		  ,[DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q2]
		  ,[DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q3]
		  ,[AVG_FEEAMOUNT_UnsecuredLoan_Q1]
		  ,[DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q2]
		  ,[DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q3]
		  ,[COUNT_LOAN_ADDON_VehicleLoan_Q1]
		  ,[DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q2]
		  ,[DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q3]
		  ,[COUNT_NEW_LOAN_VehicleLoan_Q1]
		  ,[COUNT_NEW_LOAN_VehicleLoan_Q1_Q2]
		  ,[COUNT_NEW_LOAN_VehicleLoan_Q1_Q3]
		  ,[COUNT_LOAN_PAYMENT_VehicleLoan_Q1]
		  ,[DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q2]
		  ,[DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q3]
		  ,[COUNT_CASH_VehicleLoan_Q1]
		  ,[DFT_COUNT_CASH_VehicleLoan_Q1_Q2]
		  ,[DFT_COUNT_CASH_VehicleLoan_Q1_Q3]
		  ,[COUNT_DRAFT_VehicleLoan_Q1]
		  ,[DFT_COUNT_DRAFT_VehicleLoan_Q1_Q2]
		  ,[DFT_COUNT_DRAFT_VehicleLoan_Q1_Q3]
		  ,[COUNT_ACH_VehicleLoan_Q1]
		  ,[DFT_COUNT_ACH_VehicleLoan_Q1_Q2]
		  ,[DFT_COUNT_ACH_VehicleLoan_Q1_Q3]
		  ,[COUNT_FEE_VehicleLoan_Q1]
		  ,[DFT_COUNT_FEE_VehicleLoan_Q1_Q2]
		  ,[DFT_COUNT_FEE_VehicleLoan_Q1_Q3]
		  ,[COUNT_HOMEBANKING_VehicleLoan_Q1]
		  ,[DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q2]
		  ,[DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q3]
		  ,[COUNT_INSURANCE_VehicleLoan_Q1]
		  ,[DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q2]
		  ,[DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q3]
		  ,[COUNT_CHECKS_VehicleLoan_Q1]
		  ,[DFT_COUNT_CHECKS_VehicleLoan_Q1_Q2]
		  ,[DFT_COUNT_CHECKS_VehicleLoan_Q1_Q3]
		  ,[COUNT_PAYROLL_VehicleLoan_Q1]
		  ,[DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q2]
		  ,[DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q3]
		  ,[COUNT_KIOSK_VehicleLoan_Q1]
		  ,[DFT_COUNT_KIOSK_VehicleLoan_Q1_Q2]
		  ,[DFT_COUNT_KIOSK_VehicleLoan_Q1_Q3]
		  ,[COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1]
		  ,[DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q2]
		  ,[DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q3]
		  ,[LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1]
		  ,[DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2]
		  ,[DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3]
		  ,[INTEREST_AMOUNT_VehicleLoan_Q1]
		  ,[DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2]
		  ,[DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q3]
		  ,[FEEAMOUNT_VehicleLoan_Q1]
		  ,[DFT_FEEAMOUNT_VehicleLoan_Q1_Q2]
		  ,[DFT_FEEAMOUNT_VehicleLoan_Q1_Q3]
		  ,[AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1]
		  ,[DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2]
		  ,[DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3]
		  ,[AVG_NEWBALANCE_VehicleLoan_Q1]
		  ,[DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2]
		  ,[DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q3]
		  ,[AVG_FEEAMOUNT_VehicleLoan_Q1]
		  ,[DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q2]
		  ,[DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q3]
		  ,[COUNT_LOAN_ADDON_Others_Q1]
		  ,[DFT_COUNT_LOAN_ADDON_Others_Q1_Q2]
		  ,[DFT_COUNT_LOAN_ADDON_Others_Q1_Q3]
		  ,[COUNT_NEW_LOAN_Others_Q1]
		  ,[COUNT_NEW_LOAN_Others_Q1_Q2]
		  ,[COUNT_NEW_LOAN_Others_Q1_Q3]
		  ,[COUNT_LOAN_PAYMENT_Others_Q1]
		  ,[DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q2]
		  ,[DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q3]
		  ,[COUNT_CASH_Others_Q1]
		  ,[DFT_COUNT_CASH_Others_Q1_Q2]
		  ,[DFT_COUNT_CASH_Others_Q1_Q3]
		  ,[COUNT_DRAFT_Others_Q1]
		  ,[DFT_COUNT_DRAFT_Others_Q1_Q2]
		  ,[DFT_COUNT_DRAFT_Others_Q1_Q3]
		  ,[COUNT_ACH_Others_Q1]
		  ,[DFT_COUNT_ACH_Others_Q1_Q2]
		  ,[DFT_COUNT_ACH_Others_Q1_Q3]
		  ,[COUNT_FEE_Others_Q1]
		  ,[DFT_COUNT_FEE_Others_Q1_Q2]
		  ,[DFT_COUNT_FEE_Others_Q1_Q3]
		  ,[COUNT_HOMEBANKING_Others_Q1]
		  ,[DFT_COUNT_HOMEBANKING_Others_Q1_Q2]
		  ,[DFT_COUNT_HOMEBANKING_Others_Q1_Q3]
		  ,[COUNT_INSURANCE_Others_Q1]
		  ,[DFT_COUNT_INSURANCE_Others_Q1_Q2]
		  ,[DFT_COUNT_INSURANCE_Others_Q1_Q3]
		  ,[COUNT_CHECKS_Others_Q1]
		  ,[DFT_COUNT_CHECKS_Others_Q1_Q2]
		  ,[DFT_COUNT_CHECKS_Others_Q1_Q3]
		  ,[COUNT_PAYROLL_Others_Q1]
		  ,[DFT_COUNT_PAYROLL_Others_Q1_Q2]
		  ,[DFT_COUNT_PAYROLL_Others_Q1_Q3]
		  ,[COUNT_KIOSK_Others_Q1]
		  ,[DFT_COUNT_KIOSK_Others_Q1_Q2]
		  ,[DFT_COUNT_KIOSK_Others_Q1_Q3]
		  ,[COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1]
		  ,[DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q2]
		  ,[DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q3]
		  ,[LOAN_TRANSACTION_AMOUNT_Others_Q1]
		  ,[DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q2]
		  ,[DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q3]
		  ,[INTEREST_AMOUNT_Others_Q1]
		  ,[DFT_INTEREST_AMOUNT_Others_Q1_Q2]
		  ,[DFT_INTEREST_AMOUNT_Others_Q1_Q3]
		  ,[FEEAMOUNT_Others_Q1]
		  ,[DFT_FEEAMOUNT_Others_Q1_Q2]
		  ,[DFT_FEEAMOUNT_Others_Q1_Q3]
		  ,[AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1]
		  ,[DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q2]
		  ,[DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q3]
		  ,[AVG_NEWBALANCE_Others_Q1]
		  ,[DFT_AVG_NEWBALANCE_Others_Q1_Q2]
		  ,[DFT_AVG_NEWBALANCE_Others_Q1_Q3]
		  ,[AVG_FEEAMOUNT_Others_Q1]
		  ,[DFT_AVG_FEEAMOUNT_Others_Q1_Q2]
		  ,[DFT_AVG_FEEAMOUNT_Others_Q1_Q3]
		  ,[SSN_CC]
		  ,[CreditCard_StaticpoolFlag]
		  ,[CreditCard_Q1Flag]
		  ,[PRODUCT_CC_Q1]
		  ,[DFT_PRODUCT_CC_Q1_Q2]
		  ,[DFT_PRODUCT_CC_Q1_Q3]
		  ,[Last Statement Payment Count_CC_Q1]
		  ,[DFT_Last Statement Payment Count_CC_Q1_Q2]
		  ,[DFT_Last Statement Payment Count_CC_Q1_Q3]
		  ,[Last Statement Payment Amount_CC_Q1]
		  ,[DFT_Last Statement Payment Amount_CC_Q1_Q2]
		  ,[DFT_Last Statement Payment Amount_CC_Q1_Q3]
		  ,[Last Statement Sale Amount_CC_Q1]
		  ,[DFT_Last Statement Sale Amount_CC_Q1_Q2]
		  ,[DFT_Last Statement Sale Amount_CC_Q1_Q3]
		  ,[Last Statement Cash Amount_CC_Q1]
		  ,[DFT_Last Statement Cash Amount_CC_Q1_Q2]
		  ,[DFT_Last Statement Cash Amount_CC_Q1_Q3]
		  ,[Last Statement Return Amount_CC_Q1]
		  ,[DFT_Last Statement Return Amount_CC_Q1_Q2]
		  ,[DFT_Last Statement Return Amount_CC_Q1_Q3]
		  ,[Last Statement Sale Count_CC_Q1]
		  ,[DFT_Last Statement Sale Count_CC_Q1_Q2]
		  ,[DFT_Last Statement Sale Count_CC_Q1_Q3]
		  ,[Last Statement Cash Advance Count_CC_Q1]
		  ,[DFT_Last Statement Cash Advance Count_CC_Q1_Q2]
		  ,[DFT_Last Statement Cash Advance Count_CC_Q1_Q3]
		  ,[Last Statement Return Count_CC_Q1]
		  ,[DFT_Last Statement Return Count_CC_Q1_Q2]
		  ,[DFT_Last Statement Return Count_CC_Q1_Q3]
		  ,[Last Statement External Fee Amount_CC_Q1]
		  ,[DFT_Last Statement External Fee Amount_CC_Q1_Q2]
		  ,[DFT_Last Statement External Fee Amount_CC_Q1_Q3]
		  ,[Last Statement Credit Life Change Amount_CC_Q1]
		  ,[DFT_Last Statement Credit Life Change Amount_CC_Q1_Q2]
		  ,[DFT_Last Statement Credit Life Change Amount_CC_Q1_Q3]
		  ,[Last Statement Charge Late Amount_CC_Q1]
		  ,[DFT_Last Statement Charge Late Amount_CC_Q1_Q2]
		  ,[DFT_Last Statement Charge Late Amount_CC_Q1_Q3]
		  ,[Last Statement Charge Cash Amount_CC_Q1]
		  ,[DFT_Last Statement Charge Cash Amount_CC_Q1_Q2]
		  ,[DFT_Last Statement Charge Cash Amount_CC_Q1_Q3]
		  ,[Last Statement Charge Overlimit Amount_CC_Q1]
		  ,[DFT_Last Statement Charge Overlimit Amount_CC_Q1_Q2]
		  ,[DFT_Last Statement Charge Overlimit Amount_CC_Q1_Q3]
		  ,[Last Statement Charge Sale Amount_CC_Q1]
		  ,[DFT_Last Statement Charge Sale Amount_CC_Q1_Q2]
		  ,[DFT_Last Statement Charge Sale Amount_CC_Q1_Q3]
		  ,[Last Statement Merchandise Average Daily Balance Amount_CC_Q1]
		  ,[DFT_Last Statement Merchandise Average Daily Balance Amount_CC_Q1_Q2]
		  ,[DFT_Last Statement Merchandise Average Daily Balance Amount_CC_Q1_Q3]
		  ,[Last Statement Cash Average Daily Balance Amount_CC_Staticpool]
		  ,[Last Statement Cash Average Daily Balance Amount_CC_Q1]
		  ,[DFT_Last Statement Cash Average Daily Balance Amount_CC_Q1_Q2]
		  ,[DFT_Last Statement Cash Average Daily Balance Amount_CC_Q1_Q3]
		  ,[Last Statement Average Daily Balance Amount_CC_Q1]
		  ,[DFT_Last Statement Average Daily Balance Amount_CC_Q1_Q2]
		  ,[DFT_Last Statement Average Daily Balance Amount_CC_Q1_Q3]
		  ,[spend_CC_Q1]
		  ,[DFT_spend_CC_Q1_Q2]
		  ,[DFT_spend_CC_Q1_Q3]
		  ,[Protected_Balance_CC_Q1]
		  ,[DFT_Protected_Balance_CC_Q1_Q2]
		  ,[DFT_Protected_Balance_CC_Q1_Q3]
		  ,[Promo_Balance_CC_Q1]
		  ,[DFT_Promo_Balance_CC_Q1_Q2]
		  ,[DFT_Promo_Balance_CC_Q1_Q3]
		  ,[Protected_Current_Interest_CC_Q1]
		  ,[DFT_Protected_Current_Interest_CC_Q1_Q2]
		  ,[DFT_Protected_Current_Interest_CC_Q1_Q3]
		  ,[Promo_Current_Interest_CC_Q1]
		  ,[DFT_Promo_Current_Interest_CC_Q1_Q2]
		  ,[DFT_Promo_Current_Interest_CC_Q1_Q3]
		  ,[RevolvingBalance_CC_Q1]
		  ,[DFT_RevolvingBalance_CC_Q1_Q2]
		  ,[DFT_RevolvingBalance_CC_Q1_Q3]
		  ,[AVG_UTILIZATION_RATE_CC_Q1]
		  ,[DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2]
		  ,[DFT_AVG_UTILIZATION_RATE_CC_Q1_Q3]
		  ,[Count_Durable_CC]
		  ,[max_credit_Limit]
		  ,[max_age_member_CC]
		  ,[Max_Extract_ACCOUNT_OPEN_DATE_CC]
		  ,[Max_Closed_account_flag_CC]
		  ,[Max_MOB_CC]
		  ,[ChargeoffAmount_final_CC]
		  ,[Max_chargoff_date_CC]
		  ,[CL_CC_StaticPool]
		  ,[MOB_CC_staticPool]
		  ,[TRIP_FLAG_staticpool]
		  ,[CL_DIFF_past_oneyear]
		  ,[Days Since Last Login]
		  ,[FICO]
		  ,[CCAPREstimate]
		  ,[AggregatedSpendPast3Months]
		  ,[TopOfWalletCCAnnualSpend]
		  ,[TopOfWalletCCCurrentBalance]
		  ,[OpenTradeCount]
		  ,[OpenTradeBalance]
		  ,[AutoOpenTradeCount]
		  ,[AutoLoanOrgBalanceP12Months]
		  ,[AutoOpenTradeBalance]
		  ,[CCCount]
		  ,[CCOpenCount]
		  ,[CCTotalAvailableLOC]
		  ,[CCOpenBalance]
		  ,[ChargeOffTradeCountP12Months]
		  ,[ChargeOffTotalBalance]
		  ,[ForeclosureCountP12Months]
		  ,[ForeclosureTotalBalance]
		  ,[BankruptcyCount]
		  ,[NumberInquiriesP6Months]
		  ,[CCWorstRatingP12Months]
		  ,[AutoWorstRatingP12Months]
		  ,[MortgageWorstRatingP12Months]
		  ,[HELOCWorstRatingP12Months]
		  ,[HEWorstRatingP12Months]
		  ,[HEOpenCount]
		  ,[HETotalAvailableLOC]
		  ,[HEOpenBalance]
		  ,[HELOCOpenCount]
		  ,[HELOCTotalAvailableLOC]
		  ,[HELOCOpenBalance]
		  ,[MortgageOpenCount]
		  ,[MortgageOpenBalance]
		  ,[RevolvingAccountCount]
		  ,[CCRevolvingBalance]
		  ,[CCTripTypeP6Months]
		  ,[StudentLoanOpenCount]
		  ,[StudentLoanOpenBalance]
	  INTO #NBP_MoneyMarket
	  FROM [Analytics].[dbo].[REVISED_MASTER_DATA]--358769

		/****** b. 10.EXCLUDING ALL THOSE SSN HAVING MONEYMARKET IN SP ******/

		DROP TABLE IF EXISTS #temp_MM_exclusion_SP 
		SELECT F.*
		INTO #temp_MM_exclusion_SP
		FROM
		(
		SELECT A.*, CASE WHEN A.SSN003 = B.SSN THEN 0 ELSE 1 END [NoMMInSP]
		FROM #NBP_MoneyMarket A -- REVISED MASTER DATA WITHOUT MONEY MARKET VARIABLE
		LEFT JOIN #SSN_moneymarket_SP B
		ON A.SSN003 = B.SSN
		) F
		WHERE [NoMMInSP] = 1  --348369

		--DROPPING [NoMMInSP] (we dont need it in final ds)
 
		 ALTER TABLE #temp_MM_exclusion_SP DROP COLUMN [NoMMInSP]

		 /********* 11.FINAL TABLE : Analytics.dbo.NBP_MoneyMarket : Creating the TargetFlag ********/

		DROP TABLE IF EXISTS #temp13

		SELECT A.SSN003[SSN], A.*,CASE WHEN A.SSN003 = B.SSN THEN 1 ELSE 0 END [MM_TargetFlag]
		INTO #temp13
		FROM #temp_MM_exclusion_SP A
		LEFT JOIN #SSN_Target_MM B
		ON A.SSN003 = B.SSN -- 347893


		/*********** 12.Dropping Members who have MOB less than 6 months *******************/
		--select distinct ssn from #temp13 --261000

		drop table if exists Analytics.dbo.NBP_MoneyMarket
		select *
		into Analytics.dbo.NBP_MoneyMarket
		from #temp13 
		where SSN003 in (select distinct AccountPrimeNameSSN from  
		(select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date from ARCUSYM000.arcu.ARCUAccountDetailed) W
		 where Process_date = @staticpooldate and datediff(MONTH,AccountOpenDate,@staticpooldate) >= 6 ) -- 301437

		SELECT [MM_TargetFlag], Count(*)  FROM Analytics.dbo.NBP_MoneyMarket group by [MM_TargetFlag] -- 1808

-----------------------------------------------
/****** Splitting of Train & Test Data *******/
----------------------------------------------

	DROP TABLE IF EXISTS Analytics.dbo.NBP_MoneyMarket_train
	DROP TABLE IF EXISTS Analytics.dbo.NBP_MoneyMarket_test

	SELECT * 
	into Analytics.dbo.NBP_MoneyMarket_train
	FROM Analytics.dbo.NBP_MoneyMarket
	where 1=0
	
	SELECT * 
	into Analytics.dbo.NBP_MoneyMarket_test
	FROM Analytics.dbo.NBP_MoneyMarket
	where 1=0
	
	INSERT INTO Analytics.dbo.NBP_MoneyMarket_train
	     EXEC sp_execute_external_script
		             @language = N'R'
					 , @script = N'

					 library(caret)

					 Data1 <- data.frame(Demo1_New)
					 set.seed(129)
					 train_indi <- createDataPartition(Data1$MM_TargetFlag,p=0.7,list=F)
					 train_data <- data.frame(Data1[train_indi,]);
					 train_data
					 '
	     , @output_data_1_name = N'train_data'
		     ,@input_data_1 = N'SELECT * FROM Analytics.dbo.NBP_MoneyMarket'
			 , @input_data_1_name = N'Demo1_New'

INSERT INTO Analytics.dbo.NBP_MoneyMarket_test
SELECT * 
from Analytics.dbo.NBP_MoneyMarket
WHERE SSN003 not in (SELECT SSN from Analytics.dbo.NBP_MoneyMarket_train)


###################################### Next Best Product MoneyMarket Model (12/01/2022) ###############################
## STATIC POOL : 9/30/2021

# Loading the Train Data :

rm(list=ls())
getwd()
install.packages('RODBC')
library(RODBC)
databaseConnection <- odbcDriverConnect("Driver={SQL Server};server=ACARCU01;trusted_connection=true")
MM_train <- sqlQuery(databaseConnection, "select * from  [Analytics].[dbo].[NBP_MoneyMarket_train_202209]")
MM_train <- data.frame(MM_train,stringsAsFactors=FALSE)
dim(MM_train) # 976 vars 201304 rows

# Loading the Test data

MM_test <- sqlQuery(databaseConnection, "select * from  [Analytics].[dbo].[NBP_MoneyMarket_test_202209]")
MM_test <- data.frame(MM_test,stringsAsFactors=FALSE)
dim(MM_test) # 976 vars 78941 rows

##1. Extracting out the date and char variable.

type = sapply(MM_train,class)
write.csv(type,"CLASS OF MoneyMarket.csv")

df1 = MM_train[,!sapply(MM_train,is.character)]   ## Excluding character variable
dim(df1) # 975 vars

install.packages("lubridate")
library(lubridate)
df2 =  df1[,!sapply(df1,is.POSIXct)]   ## Excluding date variable
dim(df2) # 961 vars

df3 =  df2[,!sapply(df2,is.factor)]   ## Here factor variables also contains the date variables. So removing it
dim(df3) # 961 vars

df4 =  df3[,!sapply(df3,is.logical)]   ## Here logical variables also contains NULL variables. So removing it
dim(df4) # 909 vars

### 2. Removing the i.i.d. variables (Uniqueidentifier variables)

df5 = subset(df4,select = - c(SSN,SSN_CC,SSN001,SSN002,SSN003,SSN004,PARENTACCOUNT))
dim(df5) # 902 vars

### 3. Creating the summary function

Summary_Function <- function(data)
{
  a <- data.frame()
  e <- data.frame()
  f <- data.frame()
  G <- data.frame()
  H <- data.frame()
  I <- data.frame()
  J <- data.frame()
  K <- data.frame()
  L <- data.frame()
  M <- data.frame()
  N <- data.frame()
  Col_bined <- data.frame()
  
  
  for (i in 1:ncol(data))
  {
    if(class(data[,c(i)])!="factor") {
      Total_count <- NROW(data)-(sum(is.na(data[,c(i)]))+sum(data[,c(i)]==0,na.rm = TRUE))
      Count_NA <- data.frame(sum(is.na(data[,c(i)])))
      Count_zero <- data.frame(sum(data[,c(i)]==0,na.rm = TRUE))
      Mean_1 <- data.frame(mean(data[,c(i)],na.rm = TRUE))
      Median_1 <- data.frame(median(data[,c(i)],na.rm = TRUE))
      std <- data.frame(sd(data[,c(i)],na.rm = TRUE))
      Max_1 <- data.frame(max(data[,c(i)],na.rm = TRUE))
      Min_1 <- data.frame(min(data[,c(i)],na.rm = TRUE))
      b <-data.frame(colnames(data)[i],quantile(data[,c(i)],.25,na.rm = TRUE))
      c <-data.frame(quantile(data[,c(i)],.75,na.rm = TRUE))
      d <-data.frame(quantile(data[,c(i)],.99,na.rm = TRUE))
      row.names(Count_NA) <- NULL
      row.names(Count_zero) <- NULL
      row.names(Mean_1) <- NULL
      row.names(Median_1) <- NULL
      row.names(std) <- NULL
      row.names(Max_1) <- NULL
      row.names(Min_1) <- NULL
      row.names(Total_count) <- NULL
      row.names(b) <- NULL
      row.names(c) <- NULL
      row.names(d) <- NULL
      
      a <- rbind(b,a)
      e <- rbind(c,e)
      f <- rbind(d,f)
      
      G <- rbind(Count_NA,G)
      H <- rbind(Count_zero,H)
      I <- rbind(Mean_1,I)
      J <- rbind(Median_1,J)
      K <- rbind(Max_1,K)
      L <- rbind(Min_1,L)
      M <- rbind(std,M)
      N <- rbind(Total_count,N)
      Col_bined <- data.frame(cbind(a,e,f,N,G,H,I,J,M,K,L))
      colnames(Col_bined) <- c("Variables","Percentile 25%","Percentile 75%","Percentile 99%"
                               ,"Total_No_obs","Count_NA","Count_zero","Mean","Median","Standard_Deviation","Max","Min")
      
    }
    
  }
  
  Col_bined1<- data.frame(apply(Col_bined,2,rev))
  
  write.csv(Col_bined1,"Summary of Money Market Propensity Model.csv")
}


Summary_Function(df5)

# Selecting variables with missing values less than 95%:

df6 = subset(df5,select = - c(AVG_CHARGEOFFAMOUNT_SAVINGS_SP,
                              AVG_CHARGEOFFAMOUNT_SAVINGS_Q1,
                              DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q2,
                              DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q3,
                              AVG_CHARGEOFFAMOUNT_CHECKING_SP,
                              AVG_CHARGEOFFAMOUNT_CHECKING_Q1,
                              DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q2,
                              DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q3,
                              AVG_CHARGEOFFAMOUNT_CERTIFICATES_SP,
                              AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1,
                              DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q2,
                              DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q3,
                              AVG_CHARGEOFFAMOUNT_IRA_Q1,
                              DFT_AVG_CHARGEOFFAMOUNT_IRA_Q1_Q2,
                              PRODUCT_HSA_SP,
                              PRODUCT_HSA_Q1,
                              DFT_PRODUCT_HSA_Q1_Q2,
                              DFT_PRODUCT_HSA_Q1_Q3,
                              TYPE_HSA_SP,
                              TYPE_HSA_Q1,
                              DFT_TYPE_HSA_Q1_Q2,
                              DFT_TYPE_HSA_Q1_Q3,
                              MOB_HSA,
                              AVG_CHARGEOFFAMOUNT_DEPOSITS_SP,
                              AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1,
                              DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q2,
                              DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q3,
                              HSA_StaticpoolFlag,
                              HSA_Q1Flag,
                              SUM_INTEREST_SAVINGS_Q1,
                              DFT_SUM_INTEREST_SAVINGS_Q1_Q2,
                              DFT_SUM_INTEREST_SAVINGS_Q1_Q3,
                              SUM_INTEREST_CHECKING_Q1,
                              DFT_SUM_INTEREST_CHECKING_Q1_Q2,
                              DFT_SUM_INTEREST_CHECKING_Q1_Q3,
                              SUM_INTEREST_IRA_Q1,
                              DFT_SUM_INTEREST_IRA_Q1_Q3,
                              TRANSACTION_COUNT_HSA_Q1,
                              DFT_TRANSACTION_COUNT_HSA_Q1_Q2,
                              DFT_TRANSACTION_COUNT_HSA_Q1_Q3,
                              WITHDRAWAL_COUNT_HSA_Q1,
                              DFT_WITHDRAWAL_COUNT_HSA_Q1_Q2,
                              DFT_WITHDRAWAL_COUNT_HSA_Q1_Q3,
                              PRODUCT_CommercialLoan_Q1,
                              DFT_PRODUCT_CommercialLoan_Q1_Q2,
                              DFT_PRODUCT_CommercialLoan_Q1_Q3,
                              PRODUCT_Others_Q1,
                              DFT_PRODUCT_Others_Q1_Q2,
                              DFT_PRODUCT_Others_Q1_Q3,
                              TYPE_CommercialLoan_Q1,
                              DFT_TYPE_CommercialLoan_Q1_Q2,
                              DFT_TYPE_CommercialLoan_Q1_Q3,
                              TYPE_Others_Q1,
                              DFT_TYPE_Others_Q1_Q2,
                              DFT_TYPE_Others_Q1_Q3,
                              CommercialLoan_MOB,
                              Others_MOB,
                              PAYMENTCOUNT_CommercialLoan_Q1,
                              DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q2,
                              DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q3,
                              PAYMENTCOUNT_Others_Q1,
                              DFT_PAYMENTCOUNT_Others_Q1_Q2,
                              DFT_PAYMENTCOUNT_Others_Q1_Q3,
                              SUM_OriginalBalance_Others_Q1,
                              DFT_SUM_OriginalBalance_Others_Q1_Q2,
                              DFT_SUM_OriginalBalance_Others_Q1_Q3,
                              SUM_PAYMENT_Others_Q1,
                              DFT_SUM_PAYMENT_Others_Q1_Q2,
                              DFT_SUM_PAYMENT_Others_Q1_Q3,
                              MAX_INTERESTRATE_CommercialLoan_Q1,
                              DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q2,
                              DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q3,
                              MAX_INTERESTRATE_Others_Q1,
                              DFT_MAX_INTERESTRATE_Others_Q1_Q2,
                              DFT_MAX_INTERESTRATE_Others_Q1_Q3,
                              MAX_CREDITLIMIT_SecuredLoan_Q1,
                              DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q2,
                              DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q3,
                              MAX_CREDITLIMIT_VehicleLoan_Q1,
                              DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q2,
                              DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q3,
                              MAX_CREDITLIMIT_Others_Q1,
                              DFT_MAX_CREDITLIMIT_Others_Q1_Q2,
                              DFT_MAX_CREDITLIMIT_Others_Q1_Q3,
                              CommercialLoan_Month_to_Maturity,
                              Others_Month_to_Maturity,
                              CommercialLoan_StaticPoolFlag,
                              CommercialLoan_Q1Flag,
                              COUNT_PAYROLL_STATICPOOL,
                              COUNT_PAYROLL_Q1,
                              DFT_COUNT_PAYROLL_Q1_Q2,
                              DFT_COUNT_PAYROLL_Q1_Q3,
                              COUNT_AUDIO_RESPONSE_TELEPHONE_STATICPOOL,
                              COUNT_AUDIO_RESPONSE_TELEPHONE_Q1,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q2,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q3,
                              COUNT_LOAN_ADDON_CommercialLoan_Q1,
                              DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q2,
                              DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q3,
                              COUNT_NEW_LOAN_CommercialLoan_Q1,
                              COUNT_NEW_LOAN_CommercialLoan_Q1_Q2,
                              COUNT_NEW_LOAN_CommercialLoan_Q1_Q3,
                              COUNT_LOAN_PAYMENT_CommercialLoan_Q1,
                              DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q2,
                              DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q3,
                              COUNT_CASH_CommercialLoan_Q1,
                              DFT_COUNT_CASH_CommercialLoan_Q1_Q2,
                              DFT_COUNT_CASH_CommercialLoan_Q1_Q3,
                              COUNT_DRAFT_CommercialLoan_Q1,
                              DFT_COUNT_DRAFT_CommercialLoan_Q1_Q2,
                              DFT_COUNT_DRAFT_CommercialLoan_Q1_Q3,
                              COUNT_ACH_CommercialLoan_Q1,
                              DFT_COUNT_ACH_CommercialLoan_Q1_Q2,
                              DFT_COUNT_ACH_CommercialLoan_Q1_Q3,
                              COUNT_FEE_CommercialLoan_Q1,
                              DFT_COUNT_FEE_CommercialLoan_Q1_Q2,
                              DFT_COUNT_FEE_CommercialLoan_Q1_Q3,
                              COUNT_HOMEBANKING_CommercialLoan_Q1,
                              DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q2,
                              DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q3,
                              COUNT_INSURANCE_CommercialLoan_Q1,
                              DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q2,
                              DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q3,
                              COUNT_CHECKS_CommercialLoan_Q1,
                              DFT_COUNT_CHECKS_CommercialLoan_Q1_Q2,
                              DFT_COUNT_CHECKS_CommercialLoan_Q1_Q3,
                              COUNT_PAYROLL_CommercialLoan_Q1,
                              DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q2,
                              DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q3,
                              COUNT_KIOSK_CommercialLoan_Q1,
                              DFT_COUNT_KIOSK_CommercialLoan_Q1_Q2,
                              DFT_COUNT_KIOSK_CommercialLoan_Q1_Q3,
                              COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q2,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q3,
                              COUNT_PAYROLL_RealEstate_Q1,
                              DFT_COUNT_PAYROLL_RealEstate_Q1_Q2,
                              DFT_COUNT_PAYROLL_RealEstate_Q1_Q3,
                              COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q2,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q3,
                              COUNT_PAYROLL_SecuredLoan_Q1,
                              DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q2,
                              DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q3,
                              COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q2,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q3,
                              COUNT_PAYROLL_UnsecuredLoan_Q1,
                              DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q2,
                              DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q3,
                              COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q2,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q3,
                              COUNT_PAYROLL_VehicleLoan_Q1,
                              DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q2,
                              DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q3,
                              COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q2,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q3,
                              COUNT_LOAN_ADDON_Others_Q1,
                              DFT_COUNT_LOAN_ADDON_Others_Q1_Q2,
                              DFT_COUNT_LOAN_ADDON_Others_Q1_Q3,
                              COUNT_NEW_LOAN_Others_Q1,
                              COUNT_NEW_LOAN_Others_Q1_Q2,
                              COUNT_NEW_LOAN_Others_Q1_Q3,
                              COUNT_LOAN_PAYMENT_Others_Q1,
                              DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q2,
                              DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q3,
                              COUNT_CASH_Others_Q1,
                              DFT_COUNT_CASH_Others_Q1_Q2,
                              DFT_COUNT_CASH_Others_Q1_Q3,
                              COUNT_DRAFT_Others_Q1,
                              DFT_COUNT_DRAFT_Others_Q1_Q2,
                              DFT_COUNT_DRAFT_Others_Q1_Q3,
                              COUNT_ACH_Others_Q1,
                              DFT_COUNT_ACH_Others_Q1_Q2,
                              DFT_COUNT_ACH_Others_Q1_Q3,
                              COUNT_FEE_Others_Q1,
                              DFT_COUNT_FEE_Others_Q1_Q2,
                              DFT_COUNT_FEE_Others_Q1_Q3,
                              COUNT_HOMEBANKING_Others_Q1,
                              DFT_COUNT_HOMEBANKING_Others_Q1_Q2,
                              DFT_COUNT_HOMEBANKING_Others_Q1_Q3,
                              COUNT_INSURANCE_Others_Q1,
                              DFT_COUNT_INSURANCE_Others_Q1_Q2,
                              DFT_COUNT_INSURANCE_Others_Q1_Q3,
                              COUNT_CHECKS_Others_Q1,
                              DFT_COUNT_CHECKS_Others_Q1_Q2,
                              DFT_COUNT_CHECKS_Others_Q1_Q3,
                              COUNT_PAYROLL_Others_Q1,
                              DFT_COUNT_PAYROLL_Others_Q1_Q2,
                              DFT_COUNT_PAYROLL_Others_Q1_Q3,
                              COUNT_KIOSK_Others_Q1,
                              DFT_COUNT_KIOSK_Others_Q1_Q2,
                              DFT_COUNT_KIOSK_Others_Q1_Q3,
                              COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q2,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q3,
                              LOAN_TRANSACTION_AMOUNT_Others_Q1,
                              DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q2,
                              DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q3,
                              INTEREST_AMOUNT_Others_Q1,
                              DFT_INTEREST_AMOUNT_Others_Q1_Q2,
                              DFT_INTEREST_AMOUNT_Others_Q1_Q3,
                              FEEAMOUNT_Others_Q1,
                              DFT_FEEAMOUNT_Others_Q1_Q2,
                              DFT_FEEAMOUNT_Others_Q1_Q3,
                              AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1,
                              DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q2,
                              DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q3,
                              AVG_NEWBALANCE_Others_Q1,
                              DFT_AVG_NEWBALANCE_Others_Q1_Q2,
                              DFT_AVG_NEWBALANCE_Others_Q1_Q3,
                              AVG_FEEAMOUNT_Others_Q1,
                              DFT_AVG_FEEAMOUNT_Others_Q1_Q2,
                              DFT_AVG_FEEAMOUNT_Others_Q1_Q3,
                              Last.Statement.External.Fee.Amount_CC_Q1,
                              DFT_Last.Statement.External.Fee.Amount_CC_Q1_Q2,
                              DFT_Last.Statement.External.Fee.Amount_CC_Q1_Q3,
                              Last.Statement.Credit.Life.Change.Amount_CC_Q1,
                              DFT_Last.Statement.Credit.Life.Change.Amount_CC_Q1_Q2,
                              DFT_Last.Statement.Credit.Life.Change.Amount_CC_Q1_Q3,
                              Last.Statement.Charge.Overlimit.Amount_CC_Q1,
                              DFT_Last.Statement.Charge.Overlimit.Amount_CC_Q1_Q2,
                              DFT_Last.Statement.Charge.Overlimit.Amount_CC_Q1_Q3,
                              ForeclosureCountP12Months,
                              ForeclosureTotalBalance))
dim(df6) # 675 vars


##5.WOE binning

# a. WOE Binning on train data

df6$CreditCard_StaticpoolFlag = replace(df6$CreditCard_StaticpoolFlag,is.na(df6$CreditCard_StaticpoolFlag),0)
df6$CreditCard_Q1Flag = replace(df6$CreditCard_Q1Flag,is.na(df6$CreditCard_Q1Flag),0)

df6$RealEstate_StaticPoolFlag = replace(df6$RealEstate_StaticPoolFlag,is.na(df6$RealEstate_StaticPoolFlag),0)
df6$RealEstate_Q1Flag = replace(df6$RealEstate_Q1Flag,is.na(df6$RealEstate_Q1Flag),0)

df6$SecuredLoan_StaticPoolFlag = replace(df6$SecuredLoan_StaticPoolFlag,is.na(df6$SecuredLoan_StaticPoolFlag),0)
df6$SecuredLoan_Q1Flag = replace(df6$SecuredLoan_Q1Flag,is.na(df6$SecuredLoan_Q1Flag),0)

df6$UnsecuredLoan_StaticPoolFlag = replace(df6$UnsecuredLoan_StaticPoolFlag,is.na(df6$UnsecuredLoan_StaticPoolFlag),0)
df6$UnsecuredLoan_Q1Flag = replace(df6$UnsecuredLoan_Q1Flag,is.na(df6$UnsecuredLoan_Q1Flag),0)

df6$VehicleLoan_StaticPoolFlag = replace(df6$VehicleLoan_StaticPoolFlag,is.na(df6$VehicleLoan_StaticPoolFlag),0)
df6$VehicleLoan_Q1Flag = replace(df6$VehicleLoan_Q1Flag,is.na(df6$VehicleLoan_Q1Flag),0)

df6$CERTIFICATES_StaticpoolFlag = replace(df6$CERTIFICATES_StaticpoolFlag,is.na(df6$CERTIFICATES_StaticpoolFlag),0)
df6$CERTIFICATES_Q1Flag = replace(df6$CERTIFICATES_Q1Flag,is.na(df6$CERTIFICATES_Q1Flag),0)

df6$CHECKING_StaticpoolFlag = replace(df6$CHECKING_StaticpoolFlag,is.na(df6$CHECKING_StaticpoolFlag),0)
df6$CHECKING_Q1Flag = replace(df6$CHECKING_Q1Flag,is.na(df6$CHECKING_Q1Flag),0)

df6$SAVINGS_StaticpoolFlag = replace(df6$SAVINGS_StaticpoolFlag,is.na(df6$SAVINGS_StaticpoolFlag),0)
df6$SAVINGS_Q1Flag = replace(df6$SAVINGS_Q1Flag,is.na(df6$SAVINGS_Q1Flag),0)

df6$IRA_StaticpoolFlag = replace(df6$IRA_StaticpoolFlag,is.na(df6$IRA_StaticpoolFlag),0)
df6$IRA_Q1Flag = replace(df6$IRA_Q1Flag,is.na(df6$IRA_Q1Flag),0)

# df6$HSA_StaticpoolFlag = replace(df6$HSA_StaticpoolFlag,is.na(df6$HSA_StaticpoolFlag),0)
# df6$HSA_Q1Flag = replace(df6$HSA_Q1Flag,is.na(df6$HSA_Q1Flag),0)

NAReplace_train <- replace(df6,is.na(df6),-9999999)
sum(is.na(NAReplace_train)) 

install.packages("woeBinning")
library(woeBinning)

MM_binning_model <- woe.binning(NAReplace_train,'MM_TargetFlag',NAReplace_train)
MM_train_woe <- woe.binning.deploy(NAReplace_train,MM_binning_model,add.woe.or.dum.var = "woe")
index_number4 <- colnames(MM_train_woe)
write.csv(index_number4,"Combined Money market WOE variables.csv") 

df_train_woe = subset(MM_train_woe,select = c(woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned,
                                              woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned,
                                              woe.TYPE_DEPOSITS_Q1.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.PRODUCT_DEPOSITS_SP.binned,
                                              woe.PRODUCT_DEPOSITS_Q1.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned,
                                              woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned,
                                              woe.TRANSACTION_AMOUNT_DEPOSITS_Q1.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.MOB_CERTIFICATES.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q3.binned,
                                              woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned,
                                              woe.SUM_INTEREST_DEPOSITS_Q1.binned,
                                              woe.WITHDRAWAL_COUNT_DEPOSITS_Q1.binned,
                                              woe.DEPOSITED_COUNT_DEPOSITS_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned,
                                              woe.TRANSACTION_COUNT_DEPOSITS_Q1.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2.binned,
                                              woe.CERTIFICATES_Q1Flag.binned,
                                              woe.SUM_LASTDIVAMOUNT_CERTIFICATES_Q1.binned,
                                              woe.AVG_MONTH_END_BALANCE_CERTIFICATES_Q1.binned,
                                              woe.TYPE_CERTIFICATES_Q1.binned,
                                              woe.PRODUCT_CERTIFICATES_Q1.binned,
                                              woe.CERTIFICATES_StaticpoolFlag.binned,
                                              woe.TYPE_CERTIFICATES_SP.binned,
                                              woe.PRODUCT_CERTIFICATES_SP.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_AVG_BALANCECHANGE_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_SUM_INTEREST_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_SUM_INTEREST_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_AVG_BALANCECHANGE_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q2.binned,
                                              woe.WITHDRAWAL_AMOUNT_CERTIFICATES_Q1.binned,
                                              woe.TRANSACTION_AMOUNT_CERTIFICATES_Q1.binned,
                                              woe.SUM_INTEREST_CERTIFICATES_Q1.binned,
                                              woe.DEPOSITED_COUNT_CERTIFICATES_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_CERTIFICATES_Q1.binned,
                                              woe.AVG_BALANCECHANGE_CERTIFICATES_Q1.binned,
                                              woe.TRANSACTION_COUNT_CERTIFICATES_Q1.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.FICO.binned,
                                              woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_IRA_Q1_Q2.binned,
                                              woe.WITHDRAWAL_COUNT_IRA_Q1.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q2.binned,
                                              woe.WITHDRAWAL_COUNT_CERTIFICATES_Q1.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2.binned,
                                              woe.WITHDRAWAL_COUNT_CHECKING_Q1.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned,
                                              woe.WITHDRAWAL_COUNT_SAVINGS_Q1.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned,
                                              woe.SUM_LASTDIVAMOUNT_CHECKING_Q1.binned,
                                              woe.CCRevolvingBalance.binned,
                                              woe.MOB_CHECKING.binned,
                                              woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned,
                                              woe.CHECKING_StaticpoolFlag.binned,
                                              woe.TYPE_CHECKING_SP.binned,
                                              woe.PRODUCT_CHECKING_SP.binned,
                                              woe.AVG_BALANCECHANGE_CHECKING_Q1.binned,
                                              woe.CHECKING_Q1Flag.binned,
                                              woe.TYPE_CHECKING_Q1.binned,
                                              woe.PRODUCT_CHECKING_Q1.binned,
                                              woe.SUM_LASTDIVAMOUNT_SAVINGS_Q1.binned,
                                              woe.TRANSACTION_AMOUNT_CHECKING_Q1.binned,
                                              woe.MOB_DEPOSITS.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q3.binned,
                                              woe.DEPOSITED_COUNT_CHECKING_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_CHECKING_Q1.binned,
                                              woe.OpenTradeBalance.binned,
                                              woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2.binned,
                                              woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned,
                                              woe.MOB_SAVINGS.binned,
                                              woe.Days.Since.Last.Login.binned,
                                              woe.CCTotalAvailableLOC.binned,
                                              woe.TRANSACTION_COUNT_CHECKING_Q1.binned,
                                              woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_COUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3.binned,
                                              woe.COUNT_HOMEBANKING_Q1.binned,
                                              woe.MAX_INTERESTRATE_VehicleLoan_Q1.binned,
                                              woe.TopOfWalletCCAnnualSpend.binned,
                                              woe.CCOpenBalance.binned,
                                              woe.RealEstate_Q1Flag.binned,
                                              woe.TYPE_RealEstate_Q1.binned,
                                              woe.PRODUCT_RealEstate_Q1.binned,
                                              woe.Vehicleloan_MOB.binned,
                                              woe.Vehicleloan_Month_to_Maturity.binned,
                                              woe.SUM_OriginalBalance_VehicleLoan_Q1.binned,
                                              woe.RealEstate_StaticPoolFlag.binned,
                                              woe.DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.VehicleLoan_Q1Flag.binned,
                                              woe.TYPE_VehicleLoan_Q1.binned,
                                              woe.PRODUCT_VehicleLoan_Q1.binned,
                                              woe.COUNT_ACH_Q1.binned,
                                              woe.COUNT_HOMEBANKING_STATICPOOL.binned,
                                              woe.VehicleLoan_StaticPoolFlag.binned,
                                              woe.AutoOpenTradeCount.binned,
                                              woe.TopOfWalletCCCurrentBalance.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.COUNT_ACH_VehicleLoan_Q1.binned,
                                              woe.PAYMENTCOUNT_Loan_Q1.binned,
                                              woe.AggregatedSpendPast3Months.binned,
                                              woe.Max_Loan_Month_to_Maturity.binned,
                                              woe.COUNT_ACH_STATICPOOL.binned,
                                              woe.CCWorstRatingP12Months.binned,
                                              woe.DFT_MAX_CREDITLIMIT_Loan_Q1_Q3.binned,
                                              woe.DFT_MAX_INTERESTRATE_Loan_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_Loan_Q1_Q3.binned,
                                              woe.DFT_SUM_OriginalBalance_Loan_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_Loan_Q1_Q3.binned,
                                              woe.SUM_PAYMENT_VehicleLoan_Q1.binned,
                                              woe.PAYMENTCOUNT_VehicleLoan_Q1.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.OpenTradeCount.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2.binned,
                                              woe.UnsecuredLoan_Q1Flag.binned,
                                              woe.SecuredLoan_Q1Flag.binned,
                                              woe.UnsecuredLoan_StaticPoolFlag.binned,
                                              woe.SecuredLoan_StaticPoolFlag.binned,
                                              woe.MAX_Loan_MOB.binned,
                                              woe.DFT_TYPE_Loan_Q1_Q3.binned,
                                              woe.DFT_TYPE_Loan_Q1_Q2.binned,
                                              woe.TYPE_Loan_Q1.binned,
                                              woe.DFT_TYPE_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_TYPE_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_TYPE_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_TYPE_UnsecuredLoan_Q1_Q2.binned,
                                              woe.TYPE_UnsecuredLoan_Q1.binned,
                                              woe.DFT_TYPE_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_TYPE_SecuredLoan_Q1_Q2.binned,
                                              woe.TYPE_SecuredLoan_Q1.binned,
                                              woe.DFT_TYPE_RealEstate_Q1_Q3.binned,
                                              woe.DFT_TYPE_RealEstate_Q1_Q2.binned,
                                              woe.DFT_PRODUCT_Loan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_Loan_Q1_Q2.binned,
                                              woe.PRODUCT_Loan_Q1.binned,
                                              woe.DFT_PRODUCT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_PRODUCT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.PRODUCT_UnsecuredLoan_Q1.binned,
                                              woe.DFT_PRODUCT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_SecuredLoan_Q1_Q2.binned,
                                              woe.PRODUCT_SecuredLoan_Q1.binned,
                                              woe.DFT_PRODUCT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_RealEstate_Q1_Q2.binned,
                                              woe.SUM_OriginalBalance_Loan_Q1.binned,
                                              woe.DEPOSITED_COUNT_SAVINGS_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_SAVINGS_Q1.binned,
                                              woe.TRANSACTION_AMOUNT_SAVINGS_Q1.binned,
                                              woe.PRODUCT_SAVINGS_Q1.binned,
                                              woe.DFT_MAX_CREDITLIMIT_Loan_Q1_Q2.binned,
                                              woe.DFT_MAX_INTERESTRATE_Loan_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_Loan_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_Loan_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_Loan_Q1_Q2.binned,
                                              woe.MOB_IRA.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q3.binned,
                                              woe.AVG_BALANCECHANGE_SAVINGS_Q1.binned,
                                              woe.DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_FEEAMOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_KIOSK_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q3.binned,
                                              woe.COUNT_NEW_LOAN_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q3.binned,
                                              woe.MAX_CREDITLIMIT_Loan_Q1.binned,
                                              woe.MAX_INTERESTRATE_Loan_Q1.binned,
                                              woe.SUM_PAYMENT_Loan_Q1.binned,
                                              woe.PRODUCT_SAVINGS_SP.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3.binned,
                                              woe.IRA_Q1Flag.binned,
                                              woe.SUM_LASTDIVAMOUNT_IRA_Q1.binned,
                                              woe.AVG_MONTH_END_BALANCE_IRA_Q1.binned,
                                              woe.TYPE_IRA_Q1.binned,
                                              woe.PRODUCT_IRA_Q1.binned,
                                              woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_FEEAMOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_KIOSK_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q2.binned,
                                              woe.COUNT_NEW_LOAN_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_KIOSK_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_Q1_Q3.binned,
                                              woe.DFT_COUNT_NEW_LOAN_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_Q1_Q3.binned,
                                              woe.IRA_StaticpoolFlag.binned,
                                              woe.TYPE_IRA_SP.binned,
                                              woe.PRODUCT_IRA_SP.binned,
                                              woe.DFT_COUNT_KIOSK_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_Q1_Q2.binned,
                                              woe.DFT_COUNT_NEW_LOAN_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_Q1_Q2.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2.binned,
                                              woe.CCCount.binned,
                                              woe.AVG_FEEAMOUNT_VehicleLoan_Q1.binned,
                                              woe.AVG_NEWBALANCE_VehicleLoan_Q1.binned,
                                              woe.AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1.binned,
                                              woe.FEEAMOUNT_VehicleLoan_Q1.binned,
                                              woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned,
                                              woe.LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1.binned,
                                              woe.COUNT_KIOSK_VehicleLoan_Q1.binned,
                                              woe.COUNT_CHECKS_VehicleLoan_Q1.binned,
                                              woe.COUNT_INSURANCE_VehicleLoan_Q1.binned,
                                              woe.COUNT_HOMEBANKING_VehicleLoan_Q1.binned,
                                              woe.COUNT_FEE_VehicleLoan_Q1.binned,
                                              woe.COUNT_DRAFT_VehicleLoan_Q1.binned,
                                              woe.COUNT_CASH_VehicleLoan_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_VehicleLoan_Q1.binned,
                                              woe.COUNT_NEW_LOAN_VehicleLoan_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_VehicleLoan_Q1.binned,
                                              woe.COUNT_KIOSK_Q1.binned,
                                              woe.COUNT_CHECKS_Q1.binned,
                                              woe.COUNT_INSURANCE_Q1.binned,
                                              woe.COUNT_FEE_Q1.binned,
                                              woe.COUNT_DRAFT_Q1.binned,
                                              woe.COUNT_CASH_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_Q1.binned,
                                              woe.COUNT_NEW_LOAN_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_Q1.binned,
                                              woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_SUM_INTEREST_IRA_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_COUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_AVG_BALANCECHANGE_IRA_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_IRA_Q1_Q2.binned,
                                              woe.WITHDRAWAL_AMOUNT_SAVINGS_Q1.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_COUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_AVG_BALANCECHANGE_IRA_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_AMOUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_COUNT_IRA_Q1_Q3.binned,
                                              woe.TRANSACTION_COUNT_SAVINGS_Q1.binned,
                                              woe.MortgageOpenCount.binned,
                                              woe.WITHDRAWAL_AMOUNT_IRA_Q1.binned,
                                              woe.DEPOSITED_COUNT_IRA_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_IRA_Q1.binned,
                                              woe.AVG_BALANCECHANGE_IRA_Q1.binned,
                                              woe.TRANSACTION_AMOUNT_IRA_Q1.binned,
                                              woe.TRANSACTION_COUNT_IRA_Q1.binned,
                                              woe.RevolvingAccountCount.binned,
                                              woe.COUNT_KIOSK_STATICPOOL.binned,
                                              woe.COUNT_CHECKS_STATICPOOL.binned,
                                              woe.COUNT_INSURANCE_STATICPOOL.binned,
                                              woe.COUNT_FEE_STATICPOOL.binned,
                                              woe.COUNT_DRAFT_STATICPOOL.binned,
                                              woe.COUNT_CASH_STATICPOOL.binned,
                                              woe.COUNT_LOAN_PAYMENT_STATICPOOL.binned,
                                              woe.COUNT_NEW_LOAN_STATICPOOL.binned,
                                              woe.COUNT_LOAN_ADDON_STATICPOOL.binned,
                                              woe.HELOCOpenCount.binned,
                                              woe.AutoOpenTradeBalance.binned,
                                              woe.AutoLoanOrgBalanceP12Months.binned,
                                              woe.CCOpenCount.binned,
                                              woe.DFT_TYPE_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_CERTIFICATES_Q1_Q3.binned,
                                              woe.StudentLoanOpenCount.binned,
                                              woe.StudentLoanOpenBalance.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2.binned,
                                              woe.CCAPREstimate.binned,
                                              woe.AutoWorstRatingP12Months.binned,
                                              woe.ChargeOffTradeCountP12Months.binned,
                                              woe.ChargeOffTotalBalance.binned,
                                              woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_TYPE_CERTIFICATES_Q1_Q2.binned,
                                              woe.NumberInquiriesP6Months.binned,
                                              woe.DFT_TYPE_DEPOSITS_Q1_Q2.binned,
                                              woe.RevolvingBalance_CC_Q1.binned,
                                              woe.HEOpenCount.binned,
                                              woe.TYPE_SAVINGS_Q1.binned,
                                              woe.HELOCWorstRatingP12Months.binned,
                                              woe.TYPE_SAVINGS_SP.binned,
                                              woe.DFT_PRODUCT_CERTIFICATES_Q1_Q2.binned,
                                              woe.Last.Statement.Average.Daily.Balance.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned,
                                              woe.DFT_PRODUCT_DEPOSITS_Q1_Q2.binned,
                                              woe.UnsecuredLoan_Month_to_Maturity.binned,
                                              woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_TYPE_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_TYPE_IRA_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                              woe.HELOCTotalAvailableLOC.binned,
                                              woe.HELOCOpenBalance.binned,
                                              woe.AVG_FEEAMOUNT_UnsecuredLoan_Q1.binned,
                                              woe.AVG_NEWBALANCE_UnsecuredLoan_Q1.binned,
                                              woe.AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1.binned,
                                              woe.FEEAMOUNT_UnsecuredLoan_Q1.binned,
                                              woe.INTEREST_AMOUNT_UnsecuredLoan_Q1.binned,
                                              woe.LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_KIOSK_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_CHECKS_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_INSURANCE_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_HOMEBANKING_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_FEE_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_ACH_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_DRAFT_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_CASH_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_NEW_LOAN_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_UnsecuredLoan_Q1.binned,
                                              woe.MortgageOpenBalance.binned,
                                              woe.BankruptcyCount.binned,
                                              woe.DFT_PRODUCT_IRA_Q1_Q3.binned,
                                              woe.UnsecuredLoan_MOB.binned,
                                              woe.DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.MAX_CREDITLIMIT_UnsecuredLoan_Q1.binned,
                                              woe.MAX_INTERESTRATE_UnsecuredLoan_Q1.binned,
                                              woe.SUM_PAYMENT_UnsecuredLoan_Q1.binned,
                                              woe.SUM_OriginalBalance_UnsecuredLoan_Q1.binned,
                                              woe.PAYMENTCOUNT_UnsecuredLoan_Q1.binned,
                                              woe.DFT_TYPE_IRA_Q1_Q2.binned,
                                              woe.DFT_TYPE_CHECKING_Q1_Q2.binned,
                                              woe.DFT_PRODUCT_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Sale.Count_CC_Q1_Q3.binned,
                                              woe.DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_TYPE_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_IRA_Q1_Q2.binned,
                                              woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned,
                                              woe.HEOpenBalance.binned,
                                              woe.HETotalAvailableLOC.binned,
                                              woe.DFT_PRODUCT_CHECKING_Q1_Q2.binned,
                                              woe.Max_Closed_account_flag_CC.binned,
                                              woe.CL_DIFF_past_oneyear.binned,
                                              woe.AVG_UTILIZATION_RATE_CC_Q1.binned,
                                              woe.Promo_Current_Interest_CC_Q1.binned,
                                              woe.Protected_Current_Interest_CC_Q1.binned,
                                              woe.Promo_Balance_CC_Q1.binned,
                                              woe.Protected_Balance_CC_Q1.binned,
                                              woe.spend_CC_Q1.binned,
                                              woe.Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Charge.Sale.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Charge.Cash.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Charge.Late.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Return.Count_CC_Q1.binned,
                                              woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned,
                                              woe.Last.Statement.Sale.Count_CC_Q1.binned,
                                              woe.Last.Statement.Return.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Cash.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Sale.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Payment.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Payment.Count_CC_Q1.binned,
                                              woe.CreditCard_Q1Flag.binned,
                                              woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned,
                                              woe.DFT_RevolvingBalance_CC_Q1_Q2.binned,
                                              woe.DFT_Promo_Current_Interest_CC_Q1_Q2.binned,
                                              woe.DFT_Protected_Current_Interest_CC_Q1_Q2.binned,
                                              woe.DFT_Promo_Balance_CC_Q1_Q2.binned,
                                              woe.DFT_Protected_Balance_CC_Q1_Q2.binned,
                                              woe.DFT_spend_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Charge.Sale.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Charge.Cash.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Charge.Late.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Return.Count_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Cash.Advance.Count_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Sale.Count_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Return.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Cash.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Sale.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Payment.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Payment.Count_CC_Q1_Q2.binned,
                                              woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q3.binned,
                                              woe.DFT_RevolvingBalance_CC_Q1_Q3.binned,
                                              woe.DFT_Promo_Current_Interest_CC_Q1_Q3.binned,
                                              woe.DFT_Protected_Current_Interest_CC_Q1_Q3.binned,
                                              woe.DFT_Promo_Balance_CC_Q1_Q3.binned,
                                              woe.DFT_Protected_Balance_CC_Q1_Q3.binned,
                                              woe.DFT_spend_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Charge.Sale.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Charge.Cash.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Charge.Late.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Return.Count_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Cash.Advance.Count_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Return.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Cash.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Sale.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Payment.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Payment.Count_CC_Q1_Q3.binned,
                                              woe.TRIP_FLAG_staticpool.binned,
                                              woe.MOB_CC_staticPool.binned,
                                              woe.CL_CC_StaticPool.binned,
                                              woe.ChargeoffAmount_final_CC.binned,
                                              woe.Max_MOB_CC.binned,
                                              woe.Max_Extract_ACCOUNT_OPEN_DATE_CC.binned,
                                              woe.max_age_member_CC.binned,
                                              woe.max_credit_Limit.binned,
                                              woe.Count_Durable_CC.binned,
                                              woe.Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Staticpool.binned,
                                              woe.DFT_PRODUCT_CC_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_CC_Q1_Q2.binned,
                                              woe.PRODUCT_CC_Q1.binned,
                                              woe.CreditCard_StaticpoolFlag.binned,
                                              woe.DFT_PRODUCT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_TYPE_CHECKING_Q1_Q3.binned,
                                              woe.Max_chargoff_date_CC.binned,
                                              woe.DFT_PRODUCT_SAVINGS_Q1_Q3.binned,
                                              woe.MortgageWorstRatingP12Months.binned,
                                              woe.HEWorstRatingP12Months.binned,
                                              woe.DFT_TYPE_SAVINGS_Q1_Q2.binned,
                                              woe.RealEstate_Month_to_Maturity.binned,
                                              woe.RealEstate_MOB.binned,
                                              woe.DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_SUM_OriginalBalance_RealEstate_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_AVG_NEWBALANCE_RealEstate_Q1_Q3.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_FEEAMOUNT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_INTEREST_AMOUNT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_KIOSK_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q3.binned,
                                              woe.COUNT_NEW_LOAN_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q3.binned,
                                              woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_AVG_NEWBALANCE_RealEstate_Q1_Q2.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_FEEAMOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_INTEREST_AMOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_KIOSK_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q2.binned,
                                              woe.COUNT_NEW_LOAN_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q2.binned,
                                              woe.AVG_FEEAMOUNT_RealEstate_Q1.binned,
                                              woe.AVG_NEWBALANCE_RealEstate_Q1.binned,
                                              woe.AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1.binned,
                                              woe.FEEAMOUNT_RealEstate_Q1.binned,
                                              woe.INTEREST_AMOUNT_RealEstate_Q1.binned,
                                              woe.LOAN_TRANSACTION_AMOUNT_RealEstate_Q1.binned,
                                              woe.COUNT_KIOSK_RealEstate_Q1.binned,
                                              woe.COUNT_CHECKS_RealEstate_Q1.binned,
                                              woe.COUNT_INSURANCE_RealEstate_Q1.binned,
                                              woe.COUNT_HOMEBANKING_RealEstate_Q1.binned,
                                              woe.COUNT_FEE_RealEstate_Q1.binned,
                                              woe.COUNT_ACH_RealEstate_Q1.binned,
                                              woe.COUNT_DRAFT_RealEstate_Q1.binned,
                                              woe.COUNT_CASH_RealEstate_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_RealEstate_Q1.binned,
                                              woe.COUNT_NEW_LOAN_RealEstate_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_RealEstate_Q1.binned,
                                              woe.MAX_CREDITLIMIT_RealEstate_Q1.binned,
                                              woe.MAX_INTERESTRATE_RealEstate_Q1.binned,
                                              woe.SUM_PAYMENT_RealEstate_Q1.binned,
                                              woe.SUM_OriginalBalance_RealEstate_Q1.binned,
                                              woe.PAYMENTCOUNT_RealEstate_Q1.binned,
                                              woe.DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_RealEstate_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.MAX_INTERESTRATE_SecuredLoan_Q1.binned,
                                              woe.SUM_PAYMENT_SecuredLoan_Q1.binned,
                                              woe.SUM_OriginalBalance_SecuredLoan_Q1.binned,
                                              woe.PAYMENTCOUNT_SecuredLoan_Q1.binned,
                                              woe.DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_FEEAMOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_KIOSK_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q3.binned,
                                              woe.COUNT_NEW_LOAN_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_FEEAMOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_KIOSK_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q2.binned,
                                              woe.COUNT_NEW_LOAN_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q2.binned,
                                              woe.SecuredLoan_Month_to_Maturity.binned,
                                              woe.SecuredLoan_MOB.binned,
                                              woe.AVG_FEEAMOUNT_SecuredLoan_Q1.binned,
                                              woe.AVG_NEWBALANCE_SecuredLoan_Q1.binned,
                                              woe.AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1.binned,
                                              woe.FEEAMOUNT_SecuredLoan_Q1.binned,
                                              woe.INTEREST_AMOUNT_SecuredLoan_Q1.binned,
                                              woe.LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1.binned,
                                              woe.COUNT_KIOSK_SecuredLoan_Q1.binned,
                                              woe.COUNT_CHECKS_SecuredLoan_Q1.binned,
                                              woe.COUNT_INSURANCE_SecuredLoan_Q1.binned,
                                              woe.COUNT_HOMEBANKING_SecuredLoan_Q1.binned,
                                              woe.COUNT_FEE_SecuredLoan_Q1.binned,
                                              woe.COUNT_ACH_SecuredLoan_Q1.binned,
                                              woe.COUNT_DRAFT_SecuredLoan_Q1.binned,
                                              woe.COUNT_CASH_SecuredLoan_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_SecuredLoan_Q1.binned,
                                              woe.COUNT_NEW_LOAN_SecuredLoan_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_SecuredLoan_Q1.binned,
                                              woe.SAVINGS_Q1Flag.binned,
                                              woe.SAVINGS_StaticpoolFlag.binned,
                                              MM_TargetFlag))

df_train_woe$MM_TargetFlag = as.factor(df_train_woe$MM_TargetFlag)
dim(df_train_woe) #675 vars

# 6. Random Forest Feature Selection

install.packages("randomForest")
install.packages('e1071')
install.packages('caret')
install.packages('ROCR')

library(randomForest)
library(e1071)
library(caret)
library(ROCR)
set.seed(2022)

RF_MM <- randomForest(MM_TargetFlag ~.,data = df_train_woe,ntree=50)
Important_vr <- importance(RF_MM)
write.csv(Important_vr,"Important Variables for MoneyMarket.csv")

# Selecting variables with MeanGiniIndex more than 10:

df7 = subset(df_train_woe,select =c(woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned,
                                    # woe.FICO.binned,
                                    woe.NumberInquiriesP6Months.binned,
                                    woe.TopOfWalletCCCurrentBalance.binned,
                                    woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned,
                                    woe.MOB_DEPOSITS.binned,
                                    woe.MortgageOpenCount.binned,
                                    woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned,
                                    woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned,
                                    woe.CCTotalAvailableLOC.binned,
                                    woe.OpenTradeCount.binned,
                                    woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                    woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q2.binned,
                                    woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3.binned,
                                    woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q3.binned,
                                    woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                    woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2.binned,
                                    woe.MOB_SAVINGS.binned,
                                    woe.MortgageOpenBalance.binned,
                                    woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned,
                                    woe.Days.Since.Last.Login.binned,
                                    woe.AutoOpenTradeCount.binned,
                                    woe.TRANSACTION_AMOUNT_DEPOSITS_Q1.binned,
                                    woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned,
                                    woe.AVG_BALANCECHANGE_CHECKING_Q1.binned,
                                    woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned,
                                    woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned,
                                    woe.TRANSACTION_AMOUNT_CHECKING_Q1.binned,
                                    woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned,
                                    woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned,
                                    woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned,
                                    woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q3.binned,
                                    woe.TRANSACTION_AMOUNT_SAVINGS_Q1.binned,
                                    woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2.binned,
                                    woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3.binned,
                                    woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2.binned,
                                    woe.OpenTradeBalance.binned,
                                    woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned,
                                    woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2.binned,
                                    woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                    woe.DEPOSITED_AMOUNT_SAVINGS_Q1.binned,
                                    woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2.binned,
                                    woe.MOB_CHECKING.binned,
                                    woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned,
                                    woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned,
                                    woe.AggregatedSpendPast3Months.binned,
                                    woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q2.binned,
                                    woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2.binned,
                                    woe.AVG_BALANCECHANGE_SAVINGS_Q1.binned,
                                    woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q3.binned,
                                    woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned,
                                    woe.DEPOSITED_COUNT_SAVINGS_Q1.binned,
                                    woe.TopOfWalletCCAnnualSpend.binned,
                                    woe.HEOpenCount.binned,
                                    woe.CCOpenBalance.binned,
                                    woe.SUM_LASTDIVAMOUNT_SAVINGS_Q1.binned,
                                    woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned,
                                    woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned,
                                    woe.HELOCOpenCount.binned,
                                    woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned,
                                    woe.DEPOSITED_COUNT_CHECKING_Q1.binned,
                                    woe.DEPOSITED_AMOUNT_CHECKING_Q1.binned,
                                    woe.CCAPREstimate.binned,
                                    woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned,
                                    woe.MortgageWorstRatingP12Months.binned,
                                    woe.CCRevolvingBalance.binned,
                                    woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3.binned,
                                    woe.PRODUCT_SAVINGS_Q1.binned,
                                    woe.PRODUCT_DEPOSITS_Q1.binned,
                                    woe.PRODUCT_SAVINGS_SP.binned,
                                    woe.AutoWorstRatingP12Months.binned,
                                    woe.CERTIFICATES_StaticpoolFlag.binned,
                                    woe.MOB_CERTIFICATES.binned,
                                    woe.DFT_AVG_BALANCECHANGE_CERTIFICATES_Q1_Q3.binned,
                                    woe.Last.Statement.Average.Daily.Balance.Amount_CC_Q1.binned,
                                    woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned,
                                    woe.DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q2.binned,
                                    woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned,
                                    woe.VehicleLoan_StaticPoolFlag.binned,
                                    woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                    woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                    woe.CHECKING_StaticpoolFlag.binned,
                                    woe.IRA_StaticpoolFlag.binned,
                                    woe.RealEstate_StaticPoolFlag.binned,
                                    woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2.binned,
                                    woe.DFT_SUM_INTEREST_CERTIFICATES_Q1_Q3.binned,
                                    woe.DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q3.binned,
                                    woe.COUNT_ACH_VehicleLoan_Q1.binned,
                                    woe.Vehicleloan_Month_to_Maturity.binned,
                                    woe.DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q3.binned,
                                    woe.SUM_OriginalBalance_VehicleLoan_Q1.binned,
                                    woe.DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q3.binned,
                                    woe.PRODUCT_CERTIFICATES_Q1.binned,
                                    MM_TargetFlag))
dim(df7) # 93 vars



# 8 a. Stepwise Regression on Original variables

df_original = subset(NAReplace_train,select = c(DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3,
                                                # FICO,
                                                NumberInquiriesP6Months,
                                                TopOfWalletCCCurrentBalance,
                                                DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3,
                                                MOB_DEPOSITS,
                                                MortgageOpenCount,
                                                DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2,
                                                DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2,
                                                CCTotalAvailableLOC,
                                                OpenTradeCount,
                                                DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2,
                                                DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q2,
                                                DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3,
                                                DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q3,
                                                DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2,
                                                DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2,
                                                MOB_SAVINGS,
                                                MortgageOpenBalance,
                                                DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3,
                                                Days.Since.Last.Login,
                                                AutoOpenTradeCount,
                                                TRANSACTION_AMOUNT_DEPOSITS_Q1,
                                                DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2,
                                                AVG_BALANCECHANGE_CHECKING_Q1,
                                                DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2,
                                                AVG_MONTH_END_BALANCE_CHECKING_Q1,
                                                TRANSACTION_AMOUNT_CHECKING_Q1,
                                                DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3,
                                                AVG_BALANCECHANGE_DEPOSITS_Q1,
                                                SUM_LASTDIVAMOUNT_DEPOSITS_Q1,
                                                DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q3,
                                                TRANSACTION_AMOUNT_SAVINGS_Q1,
                                                DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2,
                                                DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3,
                                                DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2,
                                                OpenTradeBalance,
                                                AVG_MONTH_END_BALANCE_DEPOSITS_Q1,
                                                DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2,
                                                DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3,
                                                DEPOSITED_AMOUNT_SAVINGS_Q1,
                                                DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2,
                                                MOB_CHECKING,
                                                DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2,
                                                DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3,
                                                AggregatedSpendPast3Months,
                                                DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q2,
                                                DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2,
                                                AVG_BALANCECHANGE_SAVINGS_Q1,
                                                DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q3,
                                                DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3,
                                                DEPOSITED_COUNT_SAVINGS_Q1,
                                                TopOfWalletCCAnnualSpend,
                                                HEOpenCount,
                                                CCOpenBalance,
                                                SUM_LASTDIVAMOUNT_SAVINGS_Q1,
                                                DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2,
                                                WITHDRAWAL_AMOUNT_CHECKING_Q1,
                                                HELOCOpenCount,
                                                DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3,
                                                DEPOSITED_COUNT_CHECKING_Q1,
                                                DEPOSITED_AMOUNT_CHECKING_Q1,
                                                CCAPREstimate,
                                                AVG_MONTH_END_BALANCE_SAVINGS_Q1,
                                                MortgageWorstRatingP12Months,
                                                CCRevolvingBalance,
                                                DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3,
                                                PRODUCT_SAVINGS_Q1,
                                                PRODUCT_DEPOSITS_Q1,
                                                PRODUCT_SAVINGS_SP,
                                                AutoWorstRatingP12Months,
                                                CERTIFICATES_StaticpoolFlag,
                                                MOB_CERTIFICATES,
                                                DFT_AVG_BALANCECHANGE_CERTIFICATES_Q1_Q3,
                                                Last.Statement.Average.Daily.Balance.Amount_CC_Q1,
                                                Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1,
                                                DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q2,
                                                DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3,
                                                VehicleLoan_StaticPoolFlag,
                                                DFT_Last.Statement.Average.Daily.Balance.Amount_CC_Q1_Q2,
                                                DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1_Q2,
                                                CHECKING_StaticpoolFlag,
                                                IRA_StaticpoolFlag,
                                                RealEstate_StaticPoolFlag,
                                                DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2,
                                                DFT_SUM_INTEREST_CERTIFICATES_Q1_Q3,
                                                DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q3,
                                                COUNT_ACH_VehicleLoan_Q1,
                                                Vehicleloan_Month_to_Maturity,
                                                DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q3,
                                                SUM_OriginalBalance_VehicleLoan_Q1,
                                                DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q3,
                                                PRODUCT_CERTIFICATES_Q1,
                                                SUM_OriginalBalance_VehicleLoan_Q1,
                                                DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q3,
                                                WITHDRAWAL_AMOUNT_CERTIFICATES_Q1,
                                                DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3,
                                                MM_TargetFlag))


variable_list_original = colnames(subset(df_original,select = - MM_TargetFlag))
stepwise_original <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list_original, data = df_original, sle = 0.05,sls = 0.05, myfamily="binomial")

log_original1 = glm(formula = MM_TargetFlag ~ MOB_CERTIFICATES + CHECKING_StaticpoolFlag + 
                      AVG_BALANCECHANGE_DEPOSITS_Q1 + CCTotalAvailableLOC + CCOpenBalance + 
                      CCAPREstimate + HELOCOpenCount + AutoWorstRatingP12Months + 
                      Days.Since.Last.Login + AVG_BALANCECHANGE_CHECKING_Q1 + CERTIFICATES_StaticpoolFlag + 
                      MortgageOpenBalance + MortgageWorstRatingP12Months + IRA_StaticpoolFlag + 
                      DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3 + RealEstate_StaticPoolFlag + 
                      MortgageOpenCount + OpenTradeBalance + DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q2 + 
                      SUM_OriginalBalance_VehicleLoan_Q1 + MOB_DEPOSITS + NumberInquiriesP6Months + 
                      PRODUCT_SAVINGS_Q1,data=df_original, family = binomial(logit))
vif(log_original1)

# CCTotalAvailableLOC is removed for high vif

log_original2 = glm(formula = MM_TargetFlag ~ MOB_CERTIFICATES + CHECKING_StaticpoolFlag + 
                      AVG_BALANCECHANGE_DEPOSITS_Q1 + CCOpenBalance + 
                      CCAPREstimate + HELOCOpenCount + AutoWorstRatingP12Months + 
                      Days.Since.Last.Login + AVG_BALANCECHANGE_CHECKING_Q1 + CERTIFICATES_StaticpoolFlag + 
                      MortgageOpenBalance + MortgageWorstRatingP12Months + IRA_StaticpoolFlag + 
                      DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3 + RealEstate_StaticPoolFlag + 
                      MortgageOpenCount + OpenTradeBalance + DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q2 + 
                      SUM_OriginalBalance_VehicleLoan_Q1 + MOB_DEPOSITS + NumberInquiriesP6Months + 
                      PRODUCT_SAVINGS_Q1,data=df_original, family = binomial(logit))
vif(log_original2)

# OpenTradeBalance is removed for high vif

log_original3 = glm(formula = MM_TargetFlag ~ MOB_CERTIFICATES + CHECKING_StaticpoolFlag + 
                      AVG_BALANCECHANGE_DEPOSITS_Q1 + CCOpenBalance + 
                      CCAPREstimate + HELOCOpenCount + AutoWorstRatingP12Months + 
                      Days.Since.Last.Login + AVG_BALANCECHANGE_CHECKING_Q1 + CERTIFICATES_StaticpoolFlag + 
                      MortgageOpenBalance + MortgageWorstRatingP12Months + IRA_StaticpoolFlag + 
                      DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3 + RealEstate_StaticPoolFlag + 
                      MortgageOpenCount + DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q2 + 
                      SUM_OriginalBalance_VehicleLoan_Q1 + MOB_DEPOSITS + NumberInquiriesP6Months + 
                      PRODUCT_SAVINGS_Q1,data=df_original, family = binomial(logit))
vif(log_original3)

# SUM_OriginalBalance_VehicleLoan_Q1 is removed for high vif.

log_original4 = glm(formula = MM_TargetFlag ~ MOB_CERTIFICATES + CHECKING_StaticpoolFlag + 
                      AVG_BALANCECHANGE_DEPOSITS_Q1 + CCOpenBalance + 
                      CCAPREstimate + HELOCOpenCount + AutoWorstRatingP12Months + 
                      Days.Since.Last.Login + AVG_BALANCECHANGE_CHECKING_Q1 + CERTIFICATES_StaticpoolFlag + 
                      MortgageOpenBalance + MortgageWorstRatingP12Months + IRA_StaticpoolFlag + 
                      DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3 + RealEstate_StaticPoolFlag + 
                      MortgageOpenCount + DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q2 + 
                      MOB_DEPOSITS + NumberInquiriesP6Months + 
                      PRODUCT_SAVINGS_Q1,data=df_original, family = binomial(logit))

vif(log_original4)

# 8 b. Stepwise Logistic Regression :

install.packages("My.stepwise")
install.packages("carData")
install.packages("car")
install.packages("blorr")
library(My.stepwise)
library(carData)
library(car)
library(blorr)

# Iteration 1 :

variable_list1 = colnames(subset(df7,select = - MM_TargetFlag))
stepwise_1 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list1, data = df7, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg1 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                 woe.CCTotalAvailableLOC.binned + woe.OpenTradeBalance.binned + 
                 woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                 woe.CCRevolvingBalance.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.Days.Since.Last.Login.binned + woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned + woe.TRANSACTION_AMOUNT_DEPOSITS_Q1.binned + 
                 woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2.binned + woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                 woe.SUM_LASTDIVAMOUNT_SAVINGS_Q1.binned,data = df7 ,family = binomial(link='logit'))

a1 = Anova(log_reg1,type="II",test="Wald")
summary(log_reg1)
v1 = vif(log_reg1)
write.csv(v1,"VIF1.csv")

# woe.TRANSACTION_AMOUNT_DEPOSITS_Q1.binned should be removed as it is giving negative estimate and has lowest p value.

# Including some more variables to df7 :

df7_updated = subset(df_train_woe,select =c(woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned,
                                            # woe.FICO.binned,
                                            woe.NumberInquiriesP6Months.binned,
                                            woe.TopOfWalletCCCurrentBalance.binned,
                                            woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned,
                                            woe.MOB_DEPOSITS.binned,
                                            woe.MortgageOpenCount.binned,
                                            woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned,
                                            woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned,
                                            woe.CCTotalAvailableLOC.binned,
                                            woe.OpenTradeCount.binned,
                                            woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                            woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q2.binned,
                                            woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3.binned,
                                            woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q3.binned,
                                            woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                            woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2.binned,
                                            woe.MOB_SAVINGS.binned,
                                            woe.MortgageOpenBalance.binned,
                                            woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned,
                                            woe.Days.Since.Last.Login.binned,
                                            woe.AutoOpenTradeCount.binned,
                                            woe.TRANSACTION_AMOUNT_DEPOSITS_Q1.binned,
                                            woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned,
                                            woe.AVG_BALANCECHANGE_CHECKING_Q1.binned,
                                            woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned,
                                            woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned,
                                            woe.TRANSACTION_AMOUNT_CHECKING_Q1.binned,
                                            woe.DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3.binned,
                                            woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned,
                                            woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned,
                                            woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q3.binned,
                                            woe.TRANSACTION_AMOUNT_SAVINGS_Q1.binned,
                                            woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2.binned,
                                            woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3.binned,
                                            woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2.binned,
                                            woe.OpenTradeBalance.binned,
                                            woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned,
                                            woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2.binned,
                                            woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                            woe.DEPOSITED_AMOUNT_SAVINGS_Q1.binned,
                                            woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2.binned,
                                            woe.MOB_CHECKING.binned,
                                            woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned,
                                            woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned,
                                            woe.AggregatedSpendPast3Months.binned,
                                            woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q2.binned,
                                            woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2.binned,
                                            woe.AVG_BALANCECHANGE_SAVINGS_Q1.binned,
                                            woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q3.binned,
                                            woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned,
                                            woe.DEPOSITED_COUNT_SAVINGS_Q1.binned,
                                            woe.TopOfWalletCCAnnualSpend.binned,
                                            woe.HEOpenCount.binned,
                                            woe.CCOpenBalance.binned,
                                            woe.SUM_LASTDIVAMOUNT_SAVINGS_Q1.binned,
                                            woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned,
                                            woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned,
                                            woe.HELOCOpenCount.binned,
                                            woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned,
                                            woe.DEPOSITED_COUNT_CHECKING_Q1.binned,
                                            woe.DEPOSITED_AMOUNT_CHECKING_Q1.binned,
                                            woe.CCAPREstimate.binned,
                                            woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned,
                                            woe.MortgageWorstRatingP12Months.binned,
                                            woe.CCRevolvingBalance.binned,
                                            woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3.binned,
                                            woe.PRODUCT_SAVINGS_Q1.binned,
                                            woe.PRODUCT_DEPOSITS_Q1.binned,
                                            woe.PRODUCT_SAVINGS_SP.binned,
                                            woe.AutoWorstRatingP12Months.binned,
                                            woe.CERTIFICATES_StaticpoolFlag.binned,
                                            woe.MOB_CERTIFICATES.binned,
                                            woe.DFT_AVG_BALANCECHANGE_CERTIFICATES_Q1_Q3.binned,
                                            woe.Last.Statement.Average.Daily.Balance.Amount_CC_Q1.binned,
                                            woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned,
                                            woe.DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q2.binned,
                                            woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned,
                                            woe.VehicleLoan_StaticPoolFlag.binned,
                                            woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                            woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                            woe.CHECKING_StaticpoolFlag.binned,
                                            woe.IRA_StaticpoolFlag.binned,
                                            woe.RealEstate_StaticPoolFlag.binned,
                                            woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2.binned,
                                            woe.DFT_SUM_INTEREST_CERTIFICATES_Q1_Q3.binned,
                                            woe.DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q3.binned,
                                            woe.COUNT_ACH_VehicleLoan_Q1.binned,
                                            woe.Vehicleloan_Month_to_Maturity.binned,
                                            woe.DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q3.binned,
                                            woe.SUM_OriginalBalance_VehicleLoan_Q1.binned,
                                            woe.DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q3.binned,
                                            woe.PRODUCT_CERTIFICATES_Q1.binned,
                                            woe.SUM_OriginalBalance_VehicleLoan_Q1.binned,
                                            woe.DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q3.binned,
                                            woe.WITHDRAWAL_AMOUNT_CERTIFICATES_Q1.binned,
                                            woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned,
                                            MM_TargetFlag))

# Removing woe.TRANSACTION_AMOUNT_DEPOSITS_Q1.binned for high p value and negative estimate

df8 = subset(df7_updated,select = -woe.TRANSACTION_AMOUNT_DEPOSITS_Q1.binned)
dim(df8) #96 vars


# Iteration 2 :

variable_list2 = colnames(subset(df8,select = - MM_TargetFlag))
stepwise_2 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list2, data = df8, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg2 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                 woe.CCTotalAvailableLOC.binned + woe.OpenTradeBalance.binned + 
                 woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                 woe.CCRevolvingBalance.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.Days.Since.Last.Login.binned + woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned + woe.AggregatedSpendPast3Months.binned + 
                 woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                 woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2.binned + woe.TRANSACTION_AMOUNT_CHECKING_Q1.binned + 
                 woe.AVG_BALANCECHANGE_CHECKING_Q1.binned,data = df8, family = binomial(logit))

a2 = Anova(log_reg2,type="II",test="Wald")
summary(log_reg2)
v2 = vif(log_reg2)

# woe.TRANSACTION_AMOUNT_CHECKING_Q1.binned has negative estimate and high p value . So removing it.

df9 = subset(df8, select = -woe.TRANSACTION_AMOUNT_CHECKING_Q1.binned)
dim(df9) # 95 vars

# Iteration 3 :

variable_list3 = colnames(subset(df9,select = - MM_TargetFlag))
stepwise_3 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list3, data = df9, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg3 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                 woe.CCTotalAvailableLOC.binned + woe.OpenTradeBalance.binned + 
                 woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                 woe.CCRevolvingBalance.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.Days.Since.Last.Login.binned + woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned + woe.AggregatedSpendPast3Months.binned + 
                 woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                 woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2.binned + woe.PRODUCT_SAVINGS_Q1.binned + 
                 woe.CCAPREstimate.binned,data=df9, family = binomial(link='logit'))

a3 = Anova(log_reg3,type="II",test="Wald")
summary(log_reg3)

v3 = vif(log_reg3)

# woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned has the high p value and negative estimate. So removing it.

df10 = subset(df9,select = -woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned)
dim(df10) # 94 vars

# Iteration 4:

variable_list4 = colnames(subset(df10,select = - MM_TargetFlag))
stepwise_4 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list4, data = df10, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg4 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                 woe.CCTotalAvailableLOC.binned + woe.OpenTradeBalance.binned + 
                 woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                 woe.CCRevolvingBalance.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.Days.Since.Last.Login.binned + woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned + woe.AggregatedSpendPast3Months.binned + 
                 woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                 woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2.binned + woe.PRODUCT_SAVINGS_Q1.binned + 
                 woe.CCAPREstimate.binned,data = df10 ,family = binomial(link='logit'))

a4 = Anova(log_reg4,type="II",test="Wald")
summary(log_reg4)

v4 = vif(log_reg4)

# woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned has high p value and negative estimate. So removing it.

df11 = subset(df10,select = -woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned)
dim(df11) #93 vars

# Iteration 5

variable_list5 = colnames(subset(df11,select = - MM_TargetFlag))
stepwise_5 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list5, data = df11, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg5 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                 woe.CCTotalAvailableLOC.binned + woe.OpenTradeBalance.binned + 
                 woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                 woe.CCRevolvingBalance.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.Days.Since.Last.Login.binned + woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned + woe.MortgageOpenCount.binned + 
                 woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q3.binned + 
                 woe.SUM_LASTDIVAMOUNT_SAVINGS_Q1.binned,data = df11, family = binomial(logit)) 

a5 = Anova(log_reg5,type = "II",test = "Wald")               
summary(log_reg5)

v5 = vif(log_reg5)

# woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q3.binned has high p value. So removing it.

df12 = subset(df11,select = -woe.DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q3.binned)
dim(df12) #92 vars

# Iteration 6

variable_list6 = colnames(subset(df12,select = - MM_TargetFlag))
stepwise_6 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list6, data = df12, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg6 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                 woe.CCTotalAvailableLOC.binned + woe.OpenTradeBalance.binned + 
                 woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                 woe.CCRevolvingBalance.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.Days.Since.Last.Login.binned + woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned + woe.MortgageOpenCount.binned + 
                 woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.RealEstate_StaticPoolFlag.binned + 
                 woe.PRODUCT_SAVINGS_Q1.binned,data=df12, family = binomial(logit))
a6 = Anova(log_reg6,type = "II",test="Wald")
summary(log_reg6)
v6 = vif(log_reg6)
write.csv(v6,"VIF1.csv")

df13 = subset(df12,select = -c(woe.CCRevolvingBalance.binned,woe.CCTotalAvailableLOC.binned,woe.RealEstate_StaticPoolFlag.binned))
dim(df13) # 89 vars

# Iteartion 7

variable_list7 = colnames(subset(df13,select = - MM_TargetFlag))
stepwise_7 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list7, data = df13, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg7 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                 woe.OpenTradeBalance.binned + woe.AggregatedSpendPast3Months.binned + 
                 woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.CCAPREstimate.binned + woe.MortgageOpenCount.binned + 
                 woe.CERTIFICATES_StaticpoolFlag.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned + woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned + 
                 woe.AutoOpenTradeCount.binned + woe.PRODUCT_SAVINGS_Q1.binned, data = df13,
               family = binomial(logit))

a7 = Anova(log_reg7,type="II",test="Wald")
write.csv(a7,"Anova1.csv")
summary(log_reg7)

v7 = vif(log_reg7)

df14 = subset(df13,select = -c(woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned,woe.CCAPREstimate.binned))
dim(df14) # 87 vars

# Iteration 8

variable_list8 = colnames(subset(df14,select = - MM_TargetFlag))
stepwise_8 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list8, data = df14, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg8 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                 woe.OpenTradeBalance.binned + woe.AggregatedSpendPast3Months.binned + 
                 woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.AutoOpenTradeCount.binned + 
                 woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned + 
                 woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned + woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2.binned + 
                 woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                 woe.TopOfWalletCCCurrentBalance.binned,data = df14, family = binomial(logit))

a8 = Anova(log_reg8,type="II",test="Wald")
write.csv(a8,"Anova1.csv")
summary(log_reg8)

v8 = vif(log_reg8)
write.csv(v8,"VIF1.csv")

df15 = subset(df14,select = -woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2.binned)
dim(df15) # 86 vars

# Iteration 9

variable_list9 = colnames(subset(df15,select = - MM_TargetFlag))
stepwise_9 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list9, data = df15, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg9 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                 woe.OpenTradeBalance.binned + woe.AggregatedSpendPast3Months.binned + 
                 woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.AutoOpenTradeCount.binned + 
                 woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned + 
                 woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned + woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned + 
                 woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                 woe.TopOfWalletCCCurrentBalance.binned + woe.MortgageOpenBalance.binned,data = df15,
               family = binomial(logit))
a9 = Anova(log_reg9,type="II",test="Wald")
v9 = vif(log_reg9)
summary(log_reg9)

df16 = subset(df15,select=-woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned)
dim(df16) # 85 vars 


# Iteration 10

variable_list10 = colnames(subset(df16,select = - MM_TargetFlag))
stepwise_10 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list10, data = df16, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg10 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                  woe.OpenTradeBalance.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                  woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.AutoOpenTradeCount.binned + 
                  woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned + 
                  woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned + woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                  woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3.binned + woe.TopOfWalletCCCurrentBalance.binned + 
                  woe.MortgageOpenBalance.binned,data = df16, family = binomial(logit))
a10 = Anova(log_reg10,type="II",test="Wald")
write.csv(a10,"Anova1.csv")
vif10 = vif(log_reg10)
write.csv(vif10,"VIF1.csv")
summary(log_reg10)

df17 = subset(df16,select = -woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3.binned)
dim(df17) # 84 vars


# Iteration 11

variable_list11 = colnames(subset(df17,select = - MM_TargetFlag))
stepwise_11 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list11, data = df17, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg11 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                  woe.OpenTradeBalance.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                  woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.AutoOpenTradeCount.binned + 
                  woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned + woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned + 
                  woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned + woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                  woe.TopOfWalletCCCurrentBalance.binned + woe.MortgageOpenBalance.binned, data=df17,
                family = binomial(logit))
a11 = Anova(log_reg11,type="II",test="Wald")
v11 = vif(log_reg11)
summary(log_reg11)

df18 = subset(df17,select=-woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned)
dim(df18) # 83 vars


# Iteration 12

variable_list12 = colnames(subset(df18,select = - MM_TargetFlag))
stepwise_12 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list12, data = df18, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg12 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                  woe.OpenTradeBalance.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                  woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.AutoOpenTradeCount.binned + 
                  woe.CHECKING_StaticpoolFlag.binned + woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                  woe.TopOfWalletCCCurrentBalance.binned + woe.MortgageOpenBalance.binned, data = df18,
                family = binomial(logit))
a12 = Anova(log_reg12,type="II",test="Wald")
v12 = vif(log_reg12)
summary(log_reg12)

df19 = subset(df18,select = -woe.CHECKING_StaticpoolFlag.binned)
dim(df19) #82 vars

# Iteration 13

variable_list13 = colnames(subset(df19,select = - MM_TargetFlag))
stepwise_13 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list13, data = df19, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg13 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                  woe.OpenTradeBalance.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                  woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.AutoOpenTradeCount.binned + 
                  woe.MOB_CHECKING.binned + woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                  woe.TopOfWalletCCCurrentBalance.binned,data=df19, family = binomial(logit))
a13 = Anova(log_reg13,type ="II",test="Wald")
v13 = vif(log_reg13)
summary(log_reg13)

df20 = subset(df19,select=-woe.MOB_CHECKING.binned)
dim(df20) #81 vars

# Iteration 14

variable_list14 = colnames(subset(df20,select = - MM_TargetFlag))
stepwise_14 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list14, data = df20, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg14 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                  woe.OpenTradeBalance.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                  woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.AutoOpenTradeCount.binned + 
                  woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned + woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned, 
                data=df20, family = binomial(logit))
a14 = Anova(log_reg14,type="II",test="Wald")
v14 = vif(log_reg14)
summary(log_reg14)

df21 = subset(df20,select = -woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned)
dim(df21) # 80 vars

# Iteration 15

variable_list15 = colnames(subset(df21,select = - MM_TargetFlag))
stepwise_15 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list15, data = df21, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg15 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                  woe.OpenTradeBalance.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                  woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.AutoOpenTradeCount.binned + 
                  woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                  woe.IRA_StaticpoolFlag.binned,data = df21, family = binomial(logit))

# WOE Binning on Test data

df_test = subset(MM_test,select = c(TopOfWalletCCAnnualSpend ,  TopOfWalletCCCurrentBalance,MortgageOpenBalance,CCOpenBalance,AVG_MONTH_END_BALANCE_DEPOSITS_Q1,DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2,	MOB_CERTIFICATES,	OpenTradeBalance,	AVG_BALANCECHANGE_DEPOSITS_Q1,	SUM_LASTDIVAMOUNT_DEPOSITS_Q1,	AggregatedSpendPast3Months,	HELOCOpenCount,	AVG_MONTH_END_BALANCE_SAVINGS_Q1,	Days.Since.Last.Login,	MortgageOpenCount,	CERTIFICATES_StaticpoolFlag,	DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3,	AutoOpenTradeCount,	DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3,	IRA_StaticpoolFlag,MM_TargetFlag))
dim(df_test) # 16 vars
df_test$CERTIFICATES_StaticpoolFlag = replace(df_test$CERTIFICATES_StaticpoolFlag,is.na(df_test$CERTIFICATES_StaticpoolFlag),0)
df_test$IRA_StaticpoolFlag = replace(df_test$IRA_StaticpoolFlag,is.na(df_test$IRA_StaticpoolFlag),0)

NAReplace_test <- replace(df_test,is.na(df_test),-9999999)
sum(is.na(NAReplace_test)) 

MM_binning_test <- woe.binning(NAReplace_test,'MM_TargetFlag',NAReplace_test)
MM_test_woe <- woe.binning.deploy(NAReplace_test,MM_binning_test,add.woe.or.dum.var = "woe")
MM_test_woe$MM_TargetFlag = as.factor(MM_test_woe$MM_TargetFlag)

# Final Model Selection

log_reg15 = glm(formula = MM_TargetFlag ~ woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned + 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + woe.MOB_CERTIFICATES.binned + 
                  woe.OpenTradeBalance.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.HELOCOpenCount.binned + 
                  woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.AutoOpenTradeCount.binned + 
                  woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                  woe.IRA_StaticpoolFlag.binned,data = df21, family = binomial(logit))
a15 = Anova(log_reg15,type="II",test="Wald")
v15 = vif(log_reg15)
summary(log_reg15)

org_reg15 = glm(MM_TargetFlag ~ SUM_LASTDIVAMOUNT_DEPOSITS_Q1+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MOB_CERTIFICATES+
                  OpenTradeBalance+
                  AggregatedSpendPast3Months+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  HELOCOpenCount+
                  Days.Since.Last.Login+
                  AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                  MortgageOpenCount+
                  CERTIFICATES_StaticpoolFlag+
                  DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                  AutoOpenTradeCount+
                  DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3+
                  IRA_StaticpoolFlag,data = NAReplace_train,family = binomial(link='logit'))
summary(org_reg15)
v015 = vif(org_reg15)
write.csv(v015,"VIF1.csv")

t1 = blr_gains_table(log_reg15,data=df21)
t1
test1 = blr_gains_table(log_reg15,MM_test_woe)
test1

# SUM_LASTDIVAMOUNT_DEPOSITS_Q1 has high vif. So removing it.

df22 = subset(df21,select = -woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned)
dim(df22) # 79 vars

# Iteration 16

variable_list16 = colnames(subset(df22,select = - MM_TargetFlag))
stepwise_16 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list16, data = df22, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg16 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                  woe.MOB_CERTIFICATES.binned + woe.OpenTradeBalance.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                  woe.HELOCOpenCount.binned + woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned + 
                  woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                  woe.AutoOpenTradeCount.binned + woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.IRA_StaticpoolFlag.binned + 
                  woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2.binned, family = binomial(logit), 
                data = df22)

# woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2.binned has negative estimate So removing it.

df23 = subset(df22,select=-woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2.binned )
dim(df23) #78 vars


# Iteration 17

variable_list17 = colnames(subset(df23,select = - MM_TargetFlag))
stepwise_17 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list17, data = df23, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg17 =glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned + woe.OpenTradeBalance.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                 woe.HELOCOpenCount.binned + woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.MortgageOpenCount.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.AutoOpenTradeCount.binned + woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.IRA_StaticpoolFlag.binned, 
               family = binomial(logit), data = df23)
a17 = Anova(log_reg17,type="II",test="Wald")
v17 = vif(log_reg17)
summary(log_reg17)

org_reg17 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MOB_CERTIFICATES+
                  OpenTradeBalance+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  AggregatedSpendPast3Months+
                  HELOCOpenCount+
                  Days.Since.Last.Login+
                  AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                  DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2+
                  MortgageOpenCount+
                  CERTIFICATES_StaticpoolFlag+
                  AutoOpenTradeCount+
                  DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                  IRA_StaticpoolFlag+
                  DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3
                ,data = NAReplace_train,family = binomial(link='logit'))
summary(org_reg17)
v017 = vif(org_reg17)

train2 = blr_gains_table(log_reg17,data = df23)
train2

test2 = blr_gains_table(log_reg17,data=MM_test_woe)
test2

# DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2 has high vif. So it must be removed.

df24 = subset(df23,select = - c(woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned, woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned))
dim(df24) # 76

# Iteration 18

variable_list18 = colnames(subset(df24,select = - MM_TargetFlag))
stepwise_18 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list18, data = df24, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg18 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                  woe.MOB_CERTIFICATES.binned + woe.OpenTradeBalance.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                  woe.HELOCOpenCount.binned + woe.Days.Since.Last.Login.binned + 
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                  woe.MortgageOpenCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                  woe.AutoOpenTradeCount.binned + woe.IRA_StaticpoolFlag.binned + 
                  woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned, 
                family = binomial(logit), data = df24)

a18 = Anova(log_reg18,type="II",test="Wald")
v18 = vif(log_reg18)
summary(log_reg18)

org_reg18 = glm(MM_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MOB_CERTIFICATES+
                  OpenTradeBalance+
                  AggregatedSpendPast3Months+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  HELOCOpenCount+
                  Days.Since.Last.Login+
                  AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                  CERTIFICATES_StaticpoolFlag+
                  MortgageOpenCount+
                  DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                  AutoOpenTradeCount+
                  IRA_StaticpoolFlag+
                  DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3,data=NAReplace_train,family = binomial(link = "logit"))
summary(org_reg18)
vo18 = vif(org_reg18)
write.csv(vo18,"VIF1.csv")

train3 =blr_gains_table(log_reg18,df24)
train3

test3 = blr_gains_table(log_reg18,MM_test_woe)
test3

# woe.OpenTradeBalance.binned has high original variable. So removing it.

df25 = subset(df24,select = -woe.OpenTradeBalance.binned)
dim(df25) # 75 vars

# Iteration 19

variable_list19 = colnames(subset(df25,select = - MM_TargetFlag))
stepwise_19 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list19, data = df25, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg19 =glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned + woe.AggregatedSpendPast3Months.binned + 
                 woe.CCOpenBalance.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                 woe.MortgageOpenCount.binned + woe.HELOCOpenCount.binned + 
                 woe.Days.Since.Last.Login.binned + woe.AutoOpenTradeCount.binned + 
                 woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.IRA_StaticpoolFlag.binned + 
                 woe.MortgageOpenBalance.binned + woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned, 
               family = binomial(logit), data = df25)

a19 = Anova(log_reg19,type="II",test="Wald")
v19 = vif(log_reg19)
summary(log_reg19)

org_reg19 = glm(MM_TargetFlag ~ MortgageOpenBalance+
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MOB_CERTIFICATES+
                  AggregatedSpendPast3Months+
                  HELOCOpenCount+
                  MortgageOpenCount+
                  CCOpenBalance+
                  Days.Since.Last.Login+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  CERTIFICATES_StaticpoolFlag+
                  AutoOpenTradeCount+
                  DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3+
                  AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                  IRA_StaticpoolFlag+
                  DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3
                ,data = NAReplace_train,family = binomial(link='logit'))
summary(org_reg19)
o19=vif(org_reg19)

train4 = blr_gains_table(log_reg19,data=df25)
train4
test4 = blr_gains_table(log_reg19,data = MM_test_woe)
test4

df26 = subset(df25,select=-woe.AggregatedSpendPast3Months.binned)
dim(df26) # 74 vars

# Iteration 20

variable_list20 = colnames(subset(df26,select = - MM_TargetFlag))
stepwise_20 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list20, data = df26, sle = 0.05,sls = 0.05, myfamily="binomial")

log_reg20 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                  woe.MOB_CERTIFICATES.binned + woe.TopOfWalletCCAnnualSpend.binned + 
                  woe.TopOfWalletCCCurrentBalance.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                  woe.MortgageOpenCount.binned + woe.HELOCOpenCount.binned + 
                  woe.Days.Since.Last.Login.binned + woe.AutoOpenTradeCount.binned + 
                  woe.CERTIFICATES_StaticpoolFlag.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.IRA_StaticpoolFlag.binned + 
                  woe.MortgageOpenBalance.binned + woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned, 
                data = df26,family = binomial(logit))
a20 = Anova(log_reg20,type="II",test="Wald")
v20 = vif(log_reg20)
summary(log_reg20)

org_reg20 = glm(MM_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1 + 
                  MOB_CERTIFICATES + TopOfWalletCCAnnualSpend + 
                  TopOfWalletCCCurrentBalance + AVG_BALANCECHANGE_DEPOSITS_Q1 + 
                  MortgageOpenCount + HELOCOpenCount + 
                  Days.Since.Last.Login + AutoOpenTradeCount + 
                  CERTIFICATES_StaticpoolFlag + AVG_MONTH_END_BALANCE_SAVINGS_Q1 + 
                  DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3 + IRA_StaticpoolFlag + 
                  MortgageOpenBalance + DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3, 
                data = NAReplace_train,family = binomial(logit))
summary(org_reg20)
vif(org_reg20)
train5 = blr_gains_table(log_reg20,data=df26)
train5
test5 = blr_gains_table(log_reg20,MM_test_woe)
test5

# Iteration 21 (Continuation after Iteration 19)

log_reg21 = glm(MM_TargetFlag ~  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned+
                  woe.MOB_CERTIFICATES.binned+
                  woe.AggregatedSpendPast3Months.binned+
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned+
                  woe.HELOCOpenCount.binned+
                  woe.Days.Since.Last.Login.binned+
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned+
                  woe.CERTIFICATES_StaticpoolFlag.binned+
                  woe.MortgageOpenCount.binned+
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned+
                  woe.AutoOpenTradeCount.binned+
                  woe.IRA_StaticpoolFlag.binned +
                  woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned
                ,data = df25,family = binomial(link="logit"))

a21 = Anova(log_reg21,type="II",test="Wald")
write.csv(a21,"Anova1.csv")
v21 = vif(log_reg21)
write.csv(v21,"VIF1.csv")
summary(log_reg21)

org_reg21 = glm(MM_TargetFlag ~
                  AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MOB_CERTIFICATES+
                  AggregatedSpendPast3Months+
                  AVG_BALANCECHANGE_DEPOSITS_Q1+
                  MortgageOpenCount+
                  Days.Since.Last.Login+
                  HELOCOpenCount+
                  AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                  AutoOpenTradeCount  +
                  CERTIFICATES_StaticpoolFlag+
                  IRA_StaticpoolFlag +
                  DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2+
                  DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3
                ,data = NAReplace_train,family = binomial(link="logit"))
summary(org_reg21)
vo21 = vif(org_reg21)
write.csv(vo21,"VIF1.csv")

train6 = blr_gains_table(log_reg21,data= df25)
train6
test6 = blr_gains_table(log_reg21,data=MM_test_woe)
test6

# Iteration 22

df27 = subset(df25,select = - c(woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned, woe.CERTIFICATES_StaticpoolFlag.binned))
dim(df27) #73 vars

variable_list22 = colnames(subset(df27,select = - MM_TargetFlag))
stepwise_22 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list22, data = df27, sle = 0.05,sls = 0.05, myfamily="binomial")


log_reg22 =glm(formula = MM_TargetFlag ~ woe.MOB_CERTIFICATES.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned + woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + 
                 woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + woe.AggregatedSpendPast3Months.binned + 
                 woe.MortgageOpenCount.binned + woe.PRODUCT_DEPOSITS_Q1.binned + 
                 woe.AutoOpenTradeCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned + 
                 woe.CCOpenBalance.binned + woe.HELOCOpenCount.binned + woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + woe.AVG_BALANCECHANGE_SAVINGS_Q1.binned + 
                 woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q3.binned + woe.Days.Since.Last.Login.binned + 
                 woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                 woe.MortgageOpenBalance.binned + woe.PRODUCT_CERTIFICATES_Q1.binned + 
                 woe.SUM_LASTDIVAMOUNT_SAVINGS_Q1.binned + woe.NumberInquiriesP6Months.binned, 
               family = binomial(logit), data = df27)

summary(log_reg22)

# Iteration 23

df28 = subset(df25,select = - c(woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned,woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned,woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned, woe.CERTIFICATES_StaticpoolFlag.binned))
dim(df28) #73 vars
variable_list23 = colnames(subset(df28,select = - MM_TargetFlag))
stepwise_23 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list23, data = df28, sle = 0.05,sls = 0.05, myfamily="binomial")


log_reg23 = glm(formula = MM_TargetFlag ~ woe.MOB_CERTIFICATES.binned + woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned + 
                  woe.AVG_BALANCECHANGE_DEPOSITS_Q1.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.PRODUCT_DEPOSITS_Q1.binned + 
                  woe.MortgageOpenCount.binned + woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3.binned + 
                  woe.AutoOpenTradeCount.binned + woe.DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q3.binned + 
                  woe.HELOCOpenCount.binned + woe.CCOpenBalance.binned + woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3.binned + 
                  woe.IRA_StaticpoolFlag.binned + woe.AVG_BALANCECHANGE_SAVINGS_Q1.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned + woe.Days.Since.Last.Login.binned + 
                  woe.MortgageOpenBalance.binned + woe.SUM_LASTDIVAMOUNT_SAVINGS_Q1.binned + 
                  woe.PRODUCT_CERTIFICATES_Q1.binned + woe.NumberInquiriesP6Months.binned, 
                family = binomial(logit), data = df28)

###################################### Next Best Product MoneyMarket Model (1/31/2023) ###############################
## STATIC POOL : 12/31/2021

# Loading the Train Data :

rm(list=ls())
getwd()
install.packages('RODBC')
library(RODBC)
databaseConnection <- odbcDriverConnect("Driver={SQL Server};server=ACARCU01;trusted_connection=true")
MM_train <- sqlQuery(databaseConnection, "select * from  [Analytics].[dbo].[NBP_MoneyMarket_train]")
MM_train <- data.frame(MM_train,stringsAsFactors=FALSE)
dim(MM_train) # 977 vars 211006 rows

# Loading the Test data

MM_test <- sqlQuery(databaseConnection, "select * from  [Analytics].[dbo].[NBP_MoneyMarket_test]")
MM_test <- data.frame(MM_test,stringsAsFactors=FALSE)
dim(MM_test) # 977 vars 90431 rows

##1. Extracting out the date and char variable.

type = sapply(MM_train,class)
write.csv(type,"CLASS OF MoneyMarket.csv")

df1 = MM_train[,!sapply(MM_train,is.character)]   ## Excluding character variable
dim(df1) # 976 vars

install.packages("lubridate")
library(lubridate)
df2 =  df1[,!sapply(df1,is.POSIXct)]   ## Excluding date variable
dim(df2) # 962 vars

df3 =  df2[,!sapply(df2,is.factor)]   ## Here factor variables also contains the date variables. So removing it
dim(df3) # 962 vars

df4 =  df3[,!sapply(df3,is.logical)]   ## Here logical variables also contains NULL variables. So removing it
dim(df4) # 913 vars

### 2. Removing the i.i.d. variables (Uniqueidentifier variables)

df5 = subset(df4,select = - c(SSN,SSN_CC,SSN001,SSN002,SSN003,SSN004))
dim(df5) # 907 vars

### 3. Creating the summary function

Summary_Function <- function(data)
{
  a <- data.frame()
  e <- data.frame()
  f <- data.frame()
  G <- data.frame()
  H <- data.frame()
  I <- data.frame()
  J <- data.frame()
  K <- data.frame()
  L <- data.frame()
  M <- data.frame()
  N <- data.frame()
  Col_bined <- data.frame()
  
  
  for (i in 1:ncol(data))
  {
    if(class(data[,c(i)])!="factor") {
      Total_count <- NROW(data)-(sum(is.na(data[,c(i)]))+sum(data[,c(i)]==0,na.rm = TRUE))
      Count_NA <- data.frame(sum(is.na(data[,c(i)])))
      Count_zero <- data.frame(sum(data[,c(i)]==0,na.rm = TRUE))
      Mean_1 <- data.frame(mean(data[,c(i)],na.rm = TRUE))
      Median_1 <- data.frame(median(data[,c(i)],na.rm = TRUE))
      std <- data.frame(sd(data[,c(i)],na.rm = TRUE))
      Max_1 <- data.frame(max(data[,c(i)],na.rm = TRUE))
      Min_1 <- data.frame(min(data[,c(i)],na.rm = TRUE))
      b <-data.frame(colnames(data)[i],quantile(data[,c(i)],.25,na.rm = TRUE))
      c <-data.frame(quantile(data[,c(i)],.75,na.rm = TRUE))
      d <-data.frame(quantile(data[,c(i)],.99,na.rm = TRUE))
      row.names(Count_NA) <- NULL
      row.names(Count_zero) <- NULL
      row.names(Mean_1) <- NULL
      row.names(Median_1) <- NULL
      row.names(std) <- NULL
      row.names(Max_1) <- NULL
      row.names(Min_1) <- NULL
      row.names(Total_count) <- NULL
      row.names(b) <- NULL
      row.names(c) <- NULL
      row.names(d) <- NULL
      
      a <- rbind(b,a)
      e <- rbind(c,e)
      f <- rbind(d,f)
      
      G <- rbind(Count_NA,G)
      H <- rbind(Count_zero,H)
      I <- rbind(Mean_1,I)
      J <- rbind(Median_1,J)
      K <- rbind(Max_1,K)
      L <- rbind(Min_1,L)
      M <- rbind(std,M)
      N <- rbind(Total_count,N)
      Col_bined <- data.frame(cbind(a,e,f,N,G,H,I,J,M,K,L))
      colnames(Col_bined) <- c("Variables","Percentile 25%","Percentile 75%","Percentile 99%"
                               ,"Total_No_obs","Count_NA","Count_zero","Mean","Median","Standard_Deviation","Max","Min")
      
    }
    
  }
  
  Col_bined1<- data.frame(apply(Col_bined,2,rev))
  
  write.csv(Col_bined1,"Summary of Money Market Propensity Model.csv")
}


Summary_Function(df5)

# Summary Statistic Removal

df6 = subset(df5,select = -c(TYPE_SAVINGS_SP,
                             TYPE_SAVINGS_Q1,
                             DFT_TYPE_SAVINGS_Q1_Q2,
                             DFT_TYPE_SAVINGS_Q1_Q3,
                             AVG_CHARGEOFFAMOUNT_SAVINGS_SP,
                             AVG_CHARGEOFFAMOUNT_SAVINGS_Q1,
                             DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q2,
                             DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q3,
                             TYPE_CHECKING_SP,
                             TYPE_CHECKING_Q1,
                             DFT_TYPE_CHECKING_Q1_Q2,
                             DFT_TYPE_CHECKING_Q1_Q3,
                             AVG_CHARGEOFFAMOUNT_CHECKING_SP,
                             AVG_CHARGEOFFAMOUNT_CHECKING_Q1,
                             DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q2,
                             DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q3,
                             TYPE_CERTIFICATES_SP,
                             TYPE_CERTIFICATES_Q1,
                             DFT_TYPE_CERTIFICATES_Q1_Q2,
                             DFT_TYPE_CERTIFICATES_Q1_Q3,
                             AVG_CHARGEOFFAMOUNT_CERTIFICATES_SP,
                             AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1,
                             DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q2,
                             DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q3,
                             TYPE_IRA_SP,
                             TYPE_IRA_Q1,
                             DFT_TYPE_IRA_Q1_Q2,
                             DFT_TYPE_IRA_Q1_Q3,
                             AVG_CHARGEOFFAMOUNT_IRA_Q1,
                             DFT_AVG_CHARGEOFFAMOUNT_IRA_Q1_Q2,
                             PRODUCT_HSA_SP,
                             PRODUCT_HSA_Q1,
                             DFT_PRODUCT_HSA_Q1_Q2,
                             DFT_PRODUCT_HSA_Q1_Q3,
                             TYPE_HSA_SP,
                             TYPE_HSA_Q1,
                             DFT_TYPE_HSA_Q1_Q2,
                             DFT_TYPE_HSA_Q1_Q3,
                             MOB_HSA,
                             TYPE_DEPOSITS_Q1,
                             DFT_TYPE_DEPOSITS_Q1_Q2,
                             DFT_TYPE_DEPOSITS_Q1_Q3,
                             AVG_CHARGEOFFAMOUNT_DEPOSITS_SP,
                             AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1,
                             DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q2,
                             DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q3,
                             HSA_StaticpoolFlag,
                             HSA_Q1Flag,
                             TRANSACTION_AMOUNT_SAVINGS_Q1,
                             DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2,
                             DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3,
                             SUM_INTEREST_SAVINGS_Q1,
                             DFT_SUM_INTEREST_SAVINGS_Q1_Q2,
                             DFT_SUM_INTEREST_SAVINGS_Q1_Q3,
                             TRANSACTION_AMOUNT_CHECKING_Q1,
                             DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2,
                             DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3,
                             SUM_INTEREST_CHECKING_Q1,
                             DFT_SUM_INTEREST_CHECKING_Q1_Q2,
                             DFT_SUM_INTEREST_CHECKING_Q1_Q3,
                             TRANSACTION_AMOUNT_CERTIFICATES_Q1,
                             DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q2,
                             DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q3,
                             TRANSACTION_AMOUNT_IRA_Q1,
                             DFT_TRANSACTION_AMOUNT_IRA_Q1_Q2,
                             DFT_TRANSACTION_AMOUNT_IRA_Q1_Q3,
                             SUM_INTEREST_IRA_Q1,
                             DFT_SUM_INTEREST_IRA_Q1_Q2,
                             DFT_SUM_INTEREST_IRA_Q1_Q3,
                             TRANSACTION_COUNT_HSA_Q1,
                             DFT_TRANSACTION_COUNT_HSA_Q1_Q2,
                             DFT_TRANSACTION_COUNT_HSA_Q1_Q3,
                             DEPOSITED_COUNT_HSA_Q1,
                             DFT_DEPOSITED_COUNT_HSA_Q1_Q2,
                             DFT_DEPOSITED_COUNT_HSA_Q1_Q3,
                             WITHDRAWAL_COUNT_HSA_Q1,
                             DFT_WITHDRAWAL_COUNT_HSA_Q1_Q2,
                             DFT_WITHDRAWAL_COUNT_HSA_Q1_Q3,
                             TRANSACTION_AMOUNT_DEPOSITS_Q1,
                             DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2,
                             DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3,
                             PRODUCT_CommercialLoan_Q1,
                             DFT_PRODUCT_CommercialLoan_Q1_Q2,
                             DFT_PRODUCT_CommercialLoan_Q1_Q3,
                             PRODUCT_Others_Q1,
                             DFT_PRODUCT_Others_Q1_Q2,
                             DFT_PRODUCT_Others_Q1_Q3,
                             TYPE_CommercialLoan_Q1,
                             DFT_TYPE_CommercialLoan_Q1_Q2,
                             DFT_TYPE_CommercialLoan_Q1_Q3,
                             TYPE_RealEstate_Q1,
                             DFT_TYPE_RealEstate_Q1_Q2,
                             DFT_TYPE_RealEstate_Q1_Q3,
                             TYPE_SecuredLoan_Q1,
                             DFT_TYPE_SecuredLoan_Q1_Q2,
                             DFT_TYPE_SecuredLoan_Q1_Q3,
                             TYPE_UnsecuredLoan_Q1,
                             DFT_TYPE_UnsecuredLoan_Q1_Q2,
                             DFT_TYPE_UnsecuredLoan_Q1_Q3,
                             TYPE_VehicleLoan_Q1,
                             DFT_TYPE_VehicleLoan_Q1_Q2,
                             DFT_TYPE_VehicleLoan_Q1_Q3,
                             TYPE_Others_Q1,
                             DFT_TYPE_Others_Q1_Q2,
                             DFT_TYPE_Others_Q1_Q3,
                             TYPE_Loan_Q1,
                             DFT_TYPE_Loan_Q1_Q2,
                             DFT_TYPE_Loan_Q1_Q3,
                             CommercialLoan_MOB,
                             Others_MOB,
                             PAYMENTCOUNT_CommercialLoan_Q1,
                             DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q2,
                             DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q3,
                             PAYMENTCOUNT_Others_Q1,
                             DFT_PAYMENTCOUNT_Others_Q1_Q2,
                             DFT_PAYMENTCOUNT_Others_Q1_Q3,
                             SUM_OriginalBalance_Others_Q1,
                             DFT_SUM_OriginalBalance_Others_Q1_Q2,
                             DFT_SUM_OriginalBalance_Others_Q1_Q3,
                             SUM_PAYMENT_Others_Q1,
                             DFT_SUM_PAYMENT_Others_Q1_Q2,
                             DFT_SUM_PAYMENT_Others_Q1_Q3,
                             MAX_INTERESTRATE_CommercialLoan_Q1,
                             DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q2,
                             DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q3,
                             MAX_INTERESTRATE_Others_Q1,
                             DFT_MAX_INTERESTRATE_Others_Q1_Q2,
                             DFT_MAX_INTERESTRATE_Others_Q1_Q3,
                             MAX_CREDITLIMIT_RealEstate_Q1,
                             DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q2,
                             DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q3,
                             MAX_CREDITLIMIT_SecuredLoan_Q1,
                             DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q2,
                             DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q3,
                             MAX_CREDITLIMIT_UnsecuredLoan_Q1,
                             DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q2,
                             DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q3,
                             MAX_CREDITLIMIT_VehicleLoan_Q1,
                             DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q2,
                             DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q3,
                             MAX_CREDITLIMIT_Others_Q1,
                             DFT_MAX_CREDITLIMIT_Others_Q1_Q2,
                             DFT_MAX_CREDITLIMIT_Others_Q1_Q3,
                             MAX_CREDITLIMIT_Loan_Q1,
                             DFT_MAX_CREDITLIMIT_Loan_Q1_Q2,
                             DFT_MAX_CREDITLIMIT_Loan_Q1_Q3,
                             CommercialLoan_Month_to_Maturity,
                             Others_Month_to_Maturity,
                             CommercialLoan_StaticPoolFlag,
                             CommercialLoan_Q1Flag,
                             COUNT_PAYROLL_STATICPOOL,
                             COUNT_PAYROLL_Q1,
                             DFT_COUNT_PAYROLL_Q1_Q2,
                             DFT_COUNT_PAYROLL_Q1_Q3,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_STATICPOOL,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_Q1,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q2,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q3,
                             COUNT_LOAN_ADDON_CommercialLoan_Q1,
                             DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q2,
                             DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q3,
                             COUNT_NEW_LOAN_CommercialLoan_Q1,
                             COUNT_NEW_LOAN_CommercialLoan_Q1_Q2,
                             COUNT_NEW_LOAN_CommercialLoan_Q1_Q3,
                             COUNT_LOAN_PAYMENT_CommercialLoan_Q1,
                             DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q2,
                             DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q3,
                             COUNT_CASH_CommercialLoan_Q1,
                             DFT_COUNT_CASH_CommercialLoan_Q1_Q2,
                             DFT_COUNT_CASH_CommercialLoan_Q1_Q3,
                             COUNT_DRAFT_CommercialLoan_Q1,
                             DFT_COUNT_DRAFT_CommercialLoan_Q1_Q2,
                             DFT_COUNT_DRAFT_CommercialLoan_Q1_Q3,
                             COUNT_ACH_CommercialLoan_Q1,
                             DFT_COUNT_ACH_CommercialLoan_Q1_Q2,
                             DFT_COUNT_ACH_CommercialLoan_Q1_Q3,
                             COUNT_FEE_CommercialLoan_Q1,
                             DFT_COUNT_FEE_CommercialLoan_Q1_Q2,
                             DFT_COUNT_FEE_CommercialLoan_Q1_Q3,
                             COUNT_HOMEBANKING_CommercialLoan_Q1,
                             DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q2,
                             DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q3,
                             COUNT_INSURANCE_CommercialLoan_Q1,
                             DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q2,
                             DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q3,
                             COUNT_CHECKS_CommercialLoan_Q1,
                             DFT_COUNT_CHECKS_CommercialLoan_Q1_Q2,
                             DFT_COUNT_CHECKS_CommercialLoan_Q1_Q3,
                             COUNT_PAYROLL_CommercialLoan_Q1,
                             DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q2,
                             DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q3,
                             COUNT_KIOSK_CommercialLoan_Q1,
                             DFT_COUNT_KIOSK_CommercialLoan_Q1_Q2,
                             DFT_COUNT_KIOSK_CommercialLoan_Q1_Q3,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q2,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q3,
                             COUNT_PAYROLL_RealEstate_Q1,
                             DFT_COUNT_PAYROLL_RealEstate_Q1_Q2,
                             DFT_COUNT_PAYROLL_RealEstate_Q1_Q3,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q2,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q3,
                             LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,
                             DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2,
                             DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q3,
                             AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,
                             DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2,
                             DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q3,
                             COUNT_PAYROLL_SecuredLoan_Q1,
                             DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q2,
                             DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q3,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q2,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q3,
                             LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,
                             DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2,
                             DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q3,
                             AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,
                             DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2,
                             DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q3,
                             COUNT_PAYROLL_UnsecuredLoan_Q1,
                             DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q2,
                             DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q3,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q2,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q3,
                             LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,
                             DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2,
                             DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q3,
                             AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,
                             DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2,
                             DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q3,
                             COUNT_PAYROLL_VehicleLoan_Q1,
                             DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q2,
                             DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q3,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q2,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q3,
                             LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,
                             DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2,
                             DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3,
                             AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,
                             DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2,
                             DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3,
                             COUNT_LOAN_ADDON_Others_Q1,
                             DFT_COUNT_LOAN_ADDON_Others_Q1_Q2,
                             DFT_COUNT_LOAN_ADDON_Others_Q1_Q3,
                             COUNT_NEW_LOAN_Others_Q1,
                             COUNT_NEW_LOAN_Others_Q1_Q2,
                             COUNT_NEW_LOAN_Others_Q1_Q3,
                             COUNT_LOAN_PAYMENT_Others_Q1,
                             DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q2,
                             DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q3,
                             COUNT_CASH_Others_Q1,
                             DFT_COUNT_CASH_Others_Q1_Q2,
                             DFT_COUNT_CASH_Others_Q1_Q3,
                             COUNT_DRAFT_Others_Q1,
                             DFT_COUNT_DRAFT_Others_Q1_Q2,
                             DFT_COUNT_DRAFT_Others_Q1_Q3,
                             COUNT_ACH_Others_Q1,
                             DFT_COUNT_ACH_Others_Q1_Q2,
                             DFT_COUNT_ACH_Others_Q1_Q3,
                             COUNT_FEE_Others_Q1,
                             DFT_COUNT_FEE_Others_Q1_Q2,
                             DFT_COUNT_FEE_Others_Q1_Q3,
                             COUNT_HOMEBANKING_Others_Q1,
                             DFT_COUNT_HOMEBANKING_Others_Q1_Q2,
                             DFT_COUNT_HOMEBANKING_Others_Q1_Q3,
                             COUNT_INSURANCE_Others_Q1,
                             DFT_COUNT_INSURANCE_Others_Q1_Q2,
                             DFT_COUNT_INSURANCE_Others_Q1_Q3,
                             COUNT_CHECKS_Others_Q1,
                             DFT_COUNT_CHECKS_Others_Q1_Q2,
                             DFT_COUNT_CHECKS_Others_Q1_Q3,
                             COUNT_PAYROLL_Others_Q1,
                             DFT_COUNT_PAYROLL_Others_Q1_Q2,
                             DFT_COUNT_PAYROLL_Others_Q1_Q3,
                             COUNT_KIOSK_Others_Q1,
                             DFT_COUNT_KIOSK_Others_Q1_Q2,
                             DFT_COUNT_KIOSK_Others_Q1_Q3,
                             COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q2,
                             DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q3,
                             LOAN_TRANSACTION_AMOUNT_Others_Q1,
                             DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q2,
                             DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q3,
                             INTEREST_AMOUNT_Others_Q1,
                             DFT_INTEREST_AMOUNT_Others_Q1_Q2,
                             DFT_INTEREST_AMOUNT_Others_Q1_Q3,
                             FEEAMOUNT_Others_Q1,
                             DFT_FEEAMOUNT_Others_Q1_Q2,
                             DFT_FEEAMOUNT_Others_Q1_Q3,
                             AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1,
                             DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q2,
                             DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q3,
                             AVG_NEWBALANCE_Others_Q1,
                             DFT_AVG_NEWBALANCE_Others_Q1_Q2,
                             DFT_AVG_NEWBALANCE_Others_Q1_Q3,
                             AVG_FEEAMOUNT_Others_Q1,
                             DFT_AVG_FEEAMOUNT_Others_Q1_Q2,
                             DFT_AVG_FEEAMOUNT_Others_Q1_Q3,
                             Last.Statement.External.Fee.Amount_CC_Q1,
                             DFT_Last.Statement.External.Fee.Amount_CC_Q1_Q2,
                             DFT_Last.Statement.External.Fee.Amount_CC_Q1_Q3,
                             Last.Statement.Credit.Life.Change.Amount_CC_Q1,
                             DFT_Last.Statement.Credit.Life.Change.Amount_CC_Q1_Q2,
                             DFT_Last.Statement.Credit.Life.Change.Amount_CC_Q1_Q3,
                             Last.Statement.Charge.Overlimit.Amount_CC_Q1,
                             DFT_Last.Statement.Charge.Overlimit.Amount_CC_Q1_Q2,
                             DFT_Last.Statement.Charge.Overlimit.Amount_CC_Q1_Q3,
                             Max_Extract_ACCOUNT_OPEN_DATE_CC,
                             Max_Closed_account_flag_CC,
                             Max_chargoff_date_CC,
                             FICO,
                             ForeclosureCountP12Months,
                             ForeclosureTotalBalance))
dim(df6) # 590

# a. WOE Binning on train data

df6$CreditCard_StaticpoolFlag = replace(df6$CreditCard_StaticpoolFlag,is.na(df6$CreditCard_StaticpoolFlag),0)
df6$CreditCard_Q1Flag = replace(df6$CreditCard_Q1Flag,is.na(df6$CreditCard_Q1Flag),0)

df6$RealEstate_StaticPoolFlag = replace(df6$RealEstate_StaticPoolFlag,is.na(df6$RealEstate_StaticPoolFlag),0)
df6$RealEstate_Q1Flag = replace(df6$RealEstate_Q1Flag,is.na(df6$RealEstate_Q1Flag),0)

df6$SecuredLoan_StaticPoolFlag = replace(df6$SecuredLoan_StaticPoolFlag,is.na(df6$SecuredLoan_StaticPoolFlag),0)
df6$SecuredLoan_Q1Flag = replace(df6$SecuredLoan_Q1Flag,is.na(df6$SecuredLoan_Q1Flag),0)

df6$UnsecuredLoan_StaticPoolFlag = replace(df6$UnsecuredLoan_StaticPoolFlag,is.na(df6$UnsecuredLoan_StaticPoolFlag),0)
df6$UnsecuredLoan_Q1Flag = replace(df6$UnsecuredLoan_Q1Flag,is.na(df6$UnsecuredLoan_Q1Flag),0)

df6$VehicleLoan_StaticPoolFlag = replace(df6$VehicleLoan_StaticPoolFlag,is.na(df6$VehicleLoan_StaticPoolFlag),0)
df6$VehicleLoan_Q1Flag = replace(df6$VehicleLoan_Q1Flag,is.na(df6$VehicleLoan_Q1Flag),0)

df6$CERTIFICATES_StaticpoolFlag = replace(df6$CERTIFICATES_StaticpoolFlag,is.na(df6$CERTIFICATES_StaticpoolFlag),0)
df6$CERTIFICATES_Q1Flag = replace(df6$CERTIFICATES_Q1Flag,is.na(df6$CERTIFICATES_Q1Flag),0)

df6$CHECKING_StaticpoolFlag = replace(df6$CHECKING_StaticpoolFlag,is.na(df6$CHECKING_StaticpoolFlag),0)
df6$CHECKING_Q1Flag = replace(df6$CHECKING_Q1Flag,is.na(df6$CHECKING_Q1Flag),0)

df6$SAVINGS_StaticpoolFlag = replace(df6$SAVINGS_StaticpoolFlag,is.na(df6$SAVINGS_StaticpoolFlag),0)
df6$SAVINGS_Q1Flag = replace(df6$SAVINGS_Q1Flag,is.na(df6$SAVINGS_Q1Flag),0)

df6$IRA_StaticpoolFlag = replace(df6$IRA_StaticpoolFlag,is.na(df6$IRA_StaticpoolFlag),0)
df6$IRA_Q1Flag = replace(df6$IRA_Q1Flag,is.na(df6$IRA_Q1Flag),0)

# df6$HSA_StaticpoolFlag = replace(df6$HSA_StaticpoolFlag,is.na(df6$HSA_StaticpoolFlag),0)
# df6$HSA_Q1Flag = replace(df6$HSA_Q1Flag,is.na(df6$HSA_Q1Flag),0)

NAReplace_train <- replace(df6,is.na(df6),-9999999)
sum(is.na(NAReplace_train)) 

install.packages("woeBinning")
library(woeBinning)

MM_binning_model <- woe.binning(NAReplace_train,'MM_TargetFlag',NAReplace_train)
MM_train_woe <- woe.binning.deploy(NAReplace_train,MM_binning_model,add.woe.or.dum.var = "woe")
index_number4 <- colnames(MM_train_woe)
write.csv(index_number4,"Combined Money market WOE variables.csv") 

df_train_woe = subset(MM_train_woe,select = c(woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned,
                                              woe.DEPOSITED_COUNT_DEPOSITS_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned,
                                              woe.SUM_INTEREST_DEPOSITS_Q1.binned,
                                              woe.WITHDRAWAL_COUNT_DEPOSITS_Q1.binned,
                                              woe.AVG_TRANSACTION_DEPOSITS_Q1.binned,
                                              woe.TRANSACTION_COUNT_DEPOSITS_Q1.binned,
                                              woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.PRODUCT_DEPOSITS_Q1.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned,
                                              woe.PRODUCT_DEPOSITS_SP.binned,
                                              woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_SUM_INTEREST_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_SUM_INTEREST_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned,
                                              woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned,
                                              woe.SUM_LASTDIVAMOUNT_CHECKING_Q1.binned,
                                              woe.DEPOSITED_COUNT_CHECKING_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_CHECKING_Q1.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q3.binned,
                                              woe.CHECKING_StaticpoolFlag.binned,
                                              woe.PRODUCT_CHECKING_SP.binned,
                                              woe.WITHDRAWAL_COUNT_CHECKING_Q1.binned,
                                              woe.AVG_TRANSACTION_CHECKING_Q1.binned,
                                              woe.TRANSACTION_COUNT_CHECKING_Q1.binned,
                                              woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned,
                                              woe.CHECKING_Q1Flag.binned,
                                              woe.PRODUCT_CHECKING_Q1.binned,
                                              woe.WITHDRAWAL_COUNT_SAVINGS_Q1.binned,
                                              woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_AVG_TRANSACTION_CHECKING_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_AVG_TRANSACTION_CHECKING_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_COUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3.binned,
                                              woe.MOB_CHECKING.binned,
                                              woe.SUM_LASTDIVAMOUNT_SAVINGS_Q1.binned,
                                              woe.Days.Since.Last.Login.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned,
                                              woe.MOB_CERTIFICATES.binned,
                                              woe.DFT_SUM_INTEREST_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_AVG_TRANSACTION_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q3.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_SUM_INTEREST_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_AVG_TRANSACTION_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q2.binned,
                                              woe.SUM_INTEREST_CERTIFICATES_Q1.binned,
                                              woe.WITHDRAWAL_COUNT_CERTIFICATES_Q1.binned,
                                              woe.DEPOSITED_COUNT_CERTIFICATES_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_CERTIFICATES_Q1.binned,
                                              woe.AVG_TRANSACTION_CERTIFICATES_Q1.binned,
                                              woe.TRANSACTION_COUNT_CERTIFICATES_Q1.binned,
                                              woe.WITHDRAWAL_AMOUNT_CERTIFICATES_Q1.binned,
                                              woe.CERTIFICATES_Q1Flag.binned,
                                              woe.SUM_LASTDIVAMOUNT_CERTIFICATES_Q1.binned,
                                              woe.AVG_MONTH_END_BALANCE_CERTIFICATES_Q1.binned,
                                              woe.PRODUCT_CERTIFICATES_Q1.binned,
                                              woe.CERTIFICATES_StaticpoolFlag.binned,
                                              woe.PRODUCT_CERTIFICATES_SP.binned,
                                              woe.CCRevolvingBalance.binned,
                                              woe.MOB_DEPOSITS.binned,
                                              woe.MOB_SAVINGS.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2.binned,
                                              woe.WITHDRAWAL_AMOUNT_SAVINGS_Q1.binned,
                                              woe.DEPOSITED_COUNT_SAVINGS_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_SAVINGS_Q1.binned,
                                              woe.AVG_TRANSACTION_SAVINGS_Q1.binned,
                                              woe.TRANSACTION_COUNT_SAVINGS_Q1.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned,
                                              woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned,
                                              woe.CCOpenBalance.binned,
                                              woe.PRODUCT_SAVINGS_SP.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned,
                                              woe.TopOfWalletCCAnnualSpend.binned,
                                              woe.CCTotalAvailableLOC.binned,
                                              woe.TopOfWalletCCCurrentBalance.binned,
                                              woe.OpenTradeCount.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_AVG_TRANSACTION_SAVINGS_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2.binned,
                                              woe.OpenTradeBalance.binned,
                                              woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3.binned,
                                              woe.AggregatedSpendPast3Months.binned,
                                              woe.AutoOpenTradeCount.binned,
                                              woe.COUNT_HOMEBANKING_Q1.binned,
                                              woe.CCWorstRatingP12Months.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3.binned,
                                              woe.MortgageOpenCount.binned,
                                              woe.DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned,
                                              woe.PRODUCT_RealEstate_Q1.binned,
                                              woe.PRODUCT_SAVINGS_Q1.binned,
                                              woe.Vehicleloan_MOB.binned,
                                              woe.CCCount.binned,
                                              woe.COUNT_ACH_VehicleLoan_Q1.binned,
                                              woe.Vehicleloan_Month_to_Maturity.binned,
                                              woe.COUNT_ACH_Q1.binned,
                                              woe.DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.COUNT_ACH_STATICPOOL.binned,
                                              woe.MOB_IRA.binned,
                                              woe.CCOpenCount.binned,
                                              woe.VehicleLoan_Q1Flag.binned,
                                              woe.MAX_INTERESTRATE_VehicleLoan_Q1.binned,
                                              woe.SUM_PAYMENT_VehicleLoan_Q1.binned,
                                              woe.SUM_OriginalBalance_VehicleLoan_Q1.binned,
                                              woe.PAYMENTCOUNT_VehicleLoan_Q1.binned,
                                              woe.PRODUCT_VehicleLoan_Q1.binned,
                                              woe.HELOCOpenCount.binned,
                                              woe.RevolvingAccountCount.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_COUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_AVG_TRANSACTION_IRA_Q1_Q3.binned,
                                              woe.DFT_TRANSACTION_COUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_AVG_TRANSACTION_SAVINGS_Q1_Q3.binned,
                                              woe.DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_FEEAMOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_KIOSK_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q3.binned,
                                              woe.COUNT_NEW_LOAN_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q3.binned,
                                              woe.MAX_INTERESTRATE_Loan_Q1.binned,
                                              woe.VehicleLoan_StaticPoolFlag.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q3.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q3.binned,
                                              woe.DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_WITHDRAWAL_COUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_COUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_DEPOSITED_AMOUNT_IRA_Q1_Q2.binned,
                                              woe.DFT_AVG_TRANSACTION_IRA_Q1_Q2.binned,
                                              woe.DFT_TRANSACTION_COUNT_IRA_Q1_Q2.binned,
                                              woe.WITHDRAWAL_AMOUNT_IRA_Q1.binned,
                                              woe.WITHDRAWAL_COUNT_IRA_Q1.binned,
                                              woe.DEPOSITED_COUNT_IRA_Q1.binned,
                                              woe.DEPOSITED_AMOUNT_IRA_Q1.binned,
                                              woe.AVG_TRANSACTION_IRA_Q1.binned,
                                              woe.TRANSACTION_COUNT_IRA_Q1.binned,
                                              woe.IRA_StaticpoolFlag.binned,
                                              woe.PRODUCT_IRA_SP.binned,
                                              woe.IRA_Q1Flag.binned,
                                              woe.SUM_LASTDIVAMOUNT_IRA_Q1.binned,
                                              woe.AVG_MONTH_END_BALANCE_IRA_Q1.binned,
                                              woe.PRODUCT_IRA_Q1.binned,
                                              woe.Max_Loan_Month_to_Maturity.binned,
                                              woe.SAVINGS_StaticpoolFlag.binned,
                                              woe.PRODUCT_Loan_Q1.binned,
                                              woe.DFT_PRODUCT_CERTIFICATES_Q1_Q3.binned,
                                              woe.PAYMENTCOUNT_Loan_Q1.binned,
                                              woe.DFT_MAX_INTERESTRATE_Loan_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_Loan_Q1_Q3.binned,
                                              woe.DFT_SUM_OriginalBalance_Loan_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_Loan_Q1_Q3.binned,
                                              woe.DFT_COUNT_KIOSK_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_Q1_Q3.binned,
                                              woe.DFT_COUNT_NEW_LOAN_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_Q1_Q3.binned,
                                              woe.DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_FEEAMOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_KIOSK_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q2.binned,
                                              woe.COUNT_NEW_LOAN_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q2.binned,
                                              woe.AVG_FEEAMOUNT_VehicleLoan_Q1.binned,
                                              woe.AVG_NEWBALANCE_VehicleLoan_Q1.binned,
                                              woe.FEEAMOUNT_VehicleLoan_Q1.binned,
                                              woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned,
                                              woe.COUNT_KIOSK_VehicleLoan_Q1.binned,
                                              woe.COUNT_CHECKS_VehicleLoan_Q1.binned,
                                              woe.COUNT_INSURANCE_VehicleLoan_Q1.binned,
                                              woe.COUNT_HOMEBANKING_VehicleLoan_Q1.binned,
                                              woe.COUNT_FEE_VehicleLoan_Q1.binned,
                                              woe.COUNT_DRAFT_VehicleLoan_Q1.binned,
                                              woe.COUNT_CASH_VehicleLoan_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_VehicleLoan_Q1.binned,
                                              woe.COUNT_NEW_LOAN_VehicleLoan_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_VehicleLoan_Q1.binned,
                                              woe.MAX_Loan_MOB.binned,
                                              woe.DFT_PRODUCT_Loan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_Loan_Q1_Q2.binned,
                                              woe.DFT_PRODUCT_VehicleLoan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_VehicleLoan_Q1_Q2.binned,
                                              woe.DFT_PRODUCT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.PRODUCT_UnsecuredLoan_Q1.binned,
                                              woe.DFT_PRODUCT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_SecuredLoan_Q1_Q2.binned,
                                              woe.PRODUCT_SecuredLoan_Q1.binned,
                                              woe.DFT_PRODUCT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_RealEstate_Q1_Q2.binned,
                                              woe.SUM_PAYMENT_Loan_Q1.binned,
                                              woe.SUM_OriginalBalance_Loan_Q1.binned,
                                              woe.DFT_MAX_INTERESTRATE_Loan_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_Loan_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_Loan_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_Loan_Q1_Q2.binned,
                                              woe.COUNT_KIOSK_Q1.binned,
                                              woe.COUNT_CHECKS_Q1.binned,
                                              woe.COUNT_INSURANCE_Q1.binned,
                                              woe.COUNT_FEE_Q1.binned,
                                              woe.COUNT_DRAFT_Q1.binned,
                                              woe.COUNT_CASH_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_Q1.binned,
                                              woe.COUNT_NEW_LOAN_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_Q1.binned,
                                              woe.DFT_PRODUCT_DEPOSITS_Q1_Q2.binned,
                                              woe.AutoOpenTradeBalance.binned,
                                              woe.AutoLoanOrgBalanceP12Months.binned,
                                              woe.DFT_COUNT_KIOSK_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_Q1_Q2.binned,
                                              woe.DFT_COUNT_NEW_LOAN_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_Q1_Q2.binned,
                                              woe.DFT_PRODUCT_CERTIFICATES_Q1_Q2.binned,
                                              woe.COUNT_KIOSK_STATICPOOL.binned,
                                              woe.COUNT_CHECKS_STATICPOOL.binned,
                                              woe.COUNT_INSURANCE_STATICPOOL.binned,
                                              woe.COUNT_HOMEBANKING_STATICPOOL.binned,
                                              woe.COUNT_FEE_STATICPOOL.binned,
                                              woe.COUNT_DRAFT_STATICPOOL.binned,
                                              woe.COUNT_CASH_STATICPOOL.binned,
                                              woe.COUNT_LOAN_PAYMENT_STATICPOOL.binned,
                                              woe.COUNT_NEW_LOAN_STATICPOOL.binned,
                                              woe.COUNT_LOAN_ADDON_STATICPOOL.binned,
                                              woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned,
                                              woe.Last.Statement.Average.Daily.Balance.Amount_CC_Q1.binned,
                                              woe.CCAPREstimate.binned,
                                              woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned,
                                              woe.HEOpenCount.binned,
                                              woe.HELOCWorstRatingP12Months.binned,
                                              woe.StudentLoanOpenCount.binned,
                                              woe.AutoWorstRatingP12Months.binned,
                                              woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1_Q3.binned,
                                              woe.ChargeOffTradeCountP12Months.binned,
                                              woe.ChargeOffTotalBalance.binned,
                                              woe.HELOCTotalAvailableLOC.binned,
                                              woe.HELOCOpenBalance.binned,
                                              woe.StudentLoanOpenBalance.binned,
                                              woe.RealEstate_Month_to_Maturity.binned,
                                              woe.RealEstate_MOB.binned,
                                              woe.BankruptcyCount.binned,
                                              woe.CL_DIFF_past_oneyear.binned,
                                              woe.AVG_UTILIZATION_RATE_CC_Q1.binned,
                                              woe.RevolvingBalance_CC_Q1.binned,
                                              woe.Promo_Current_Interest_CC_Q1.binned,
                                              woe.Protected_Current_Interest_CC_Q1.binned,
                                              woe.Promo_Balance_CC_Q1.binned,
                                              woe.Protected_Balance_CC_Q1.binned,
                                              woe.spend_CC_Q1.binned,
                                              woe.Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Charge.Sale.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Charge.Cash.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Charge.Late.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Return.Count_CC_Q1.binned,
                                              woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned,
                                              woe.Last.Statement.Sale.Count_CC_Q1.binned,
                                              woe.Last.Statement.Return.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Cash.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Sale.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Payment.Amount_CC_Q1.binned,
                                              woe.Last.Statement.Payment.Count_CC_Q1.binned,
                                              woe.CreditCard_Q1Flag.binned,
                                              woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q3.binned,
                                              woe.DFT_RevolvingBalance_CC_Q1_Q3.binned,
                                              woe.DFT_Promo_Current_Interest_CC_Q1_Q3.binned,
                                              woe.DFT_Protected_Current_Interest_CC_Q1_Q3.binned,
                                              woe.DFT_Promo_Balance_CC_Q1_Q3.binned,
                                              woe.DFT_Protected_Balance_CC_Q1_Q3.binned,
                                              woe.DFT_spend_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Charge.Sale.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Charge.Cash.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Charge.Late.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Return.Count_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Cash.Advance.Count_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Sale.Count_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Return.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Cash.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Sale.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Payment.Amount_CC_Q1_Q3.binned,
                                              woe.DFT_Last.Statement.Payment.Count_CC_Q1_Q3.binned,
                                              woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned,
                                              woe.DFT_RevolvingBalance_CC_Q1_Q2.binned,
                                              woe.DFT_Promo_Current_Interest_CC_Q1_Q2.binned,
                                              woe.DFT_Protected_Current_Interest_CC_Q1_Q2.binned,
                                              woe.DFT_Promo_Balance_CC_Q1_Q2.binned,
                                              woe.DFT_Protected_Balance_CC_Q1_Q2.binned,
                                              woe.DFT_spend_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Charge.Sale.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Charge.Cash.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Charge.Late.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Return.Count_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Cash.Advance.Count_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Sale.Count_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Return.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Cash.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Sale.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Payment.Amount_CC_Q1_Q2.binned,
                                              woe.DFT_Last.Statement.Payment.Count_CC_Q1_Q2.binned,
                                              woe.MortgageWorstRatingP12Months.binned,
                                              woe.TRIP_FLAG_staticpool.binned,
                                              woe.MOB_CC_staticPool.binned,
                                              woe.CL_CC_StaticPool.binned,
                                              woe.ChargeoffAmount_final_CC.binned,
                                              woe.Max_MOB_CC.binned,
                                              woe.max_age_member_CC.binned,
                                              woe.max_credit_Limit.binned,
                                              woe.Count_Durable_CC.binned,
                                              woe.Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Staticpool.binned,
                                              woe.DFT_PRODUCT_CC_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_CC_Q1_Q2.binned,
                                              woe.PRODUCT_CC_Q1.binned,
                                              woe.CreditCard_StaticpoolFlag.binned,
                                              woe.DFT_PRODUCT_IRA_Q1_Q3.binned,
                                              woe.NumberInquiriesP6Months.binned,
                                              woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_RealEstate_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_PRODUCT_IRA_Q1_Q2.binned,
                                              woe.RealEstate_Q1Flag.binned,
                                              woe.MAX_INTERESTRATE_RealEstate_Q1.binned,
                                              woe.SUM_PAYMENT_RealEstate_Q1.binned,
                                              woe.SUM_OriginalBalance_RealEstate_Q1.binned,
                                              woe.PAYMENTCOUNT_RealEstate_Q1.binned,
                                              woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_SUM_OriginalBalance_RealEstate_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_RealEstate_Q1_Q3.binned,
                                              woe.RealEstate_StaticPoolFlag.binned,
                                              woe.UnsecuredLoan_StaticPoolFlag.binned,
                                              woe.AVG_FEEAMOUNT_UnsecuredLoan_Q1.binned,
                                              woe.AVG_NEWBALANCE_UnsecuredLoan_Q1.binned,
                                              woe.FEEAMOUNT_UnsecuredLoan_Q1.binned,
                                              woe.INTEREST_AMOUNT_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_KIOSK_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_CHECKS_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_INSURANCE_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_HOMEBANKING_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_FEE_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_ACH_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_DRAFT_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_CASH_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_NEW_LOAN_UnsecuredLoan_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_UnsecuredLoan_Q1.binned,
                                              woe.DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q2.binned,
                                              woe.MortgageOpenBalance.binned,
                                              woe.DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_CHECKING_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_SAVINGS_Q1_Q3.binned,
                                              woe.SecuredLoan_Month_to_Maturity.binned,
                                              woe.SecuredLoan_MOB.binned,
                                              woe.DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_AVG_NEWBALANCE_RealEstate_Q1_Q2.binned,
                                              woe.DFT_FEEAMOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_INTEREST_AMOUNT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_KIOSK_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q2.binned,
                                              woe.COUNT_NEW_LOAN_RealEstate_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q2.binned,
                                              woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.UnsecuredLoan_Q1Flag.binned,
                                              woe.MAX_INTERESTRATE_UnsecuredLoan_Q1.binned,
                                              woe.SUM_PAYMENT_UnsecuredLoan_Q1.binned,
                                              woe.SUM_OriginalBalance_UnsecuredLoan_Q1.binned,
                                              woe.PAYMENTCOUNT_UnsecuredLoan_Q1.binned,
                                              woe.DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q3.binned,
                                              woe.DFT_PRODUCT_SAVINGS_Q1_Q2.binned,
                                              woe.UnsecuredLoan_Month_to_Maturity.binned,
                                              woe.DFT_PRODUCT_CHECKING_Q1_Q2.binned,
                                              woe.DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_AVG_NEWBALANCE_RealEstate_Q1_Q3.binned,
                                              woe.DFT_FEEAMOUNT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_INTEREST_AMOUNT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_KIOSK_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q3.binned,
                                              woe.COUNT_NEW_LOAN_RealEstate_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q3.binned,
                                              woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.SecuredLoan_Q1Flag.binned,
                                              woe.MAX_INTERESTRATE_SecuredLoan_Q1.binned,
                                              woe.SUM_PAYMENT_SecuredLoan_Q1.binned,
                                              woe.SUM_OriginalBalance_SecuredLoan_Q1.binned,
                                              woe.PAYMENTCOUNT_SecuredLoan_Q1.binned,
                                              woe.AVG_FEEAMOUNT_RealEstate_Q1.binned,
                                              woe.AVG_NEWBALANCE_RealEstate_Q1.binned,
                                              woe.FEEAMOUNT_RealEstate_Q1.binned,
                                              woe.INTEREST_AMOUNT_RealEstate_Q1.binned,
                                              woe.COUNT_KIOSK_RealEstate_Q1.binned,
                                              woe.COUNT_CHECKS_RealEstate_Q1.binned,
                                              woe.COUNT_INSURANCE_RealEstate_Q1.binned,
                                              woe.COUNT_HOMEBANKING_RealEstate_Q1.binned,
                                              woe.COUNT_FEE_RealEstate_Q1.binned,
                                              woe.COUNT_ACH_RealEstate_Q1.binned,
                                              woe.COUNT_DRAFT_RealEstate_Q1.binned,
                                              woe.COUNT_CASH_RealEstate_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_RealEstate_Q1.binned,
                                              woe.COUNT_NEW_LOAN_RealEstate_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_RealEstate_Q1.binned,
                                              woe.DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_FEEAMOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_KIOSK_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CHECKS_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_FEE_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_ACH_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_DRAFT_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_CASH_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q3.binned,
                                              woe.COUNT_NEW_LOAN_SecuredLoan_Q1_Q3.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q3.binned,
                                              woe.SecuredLoan_StaticPoolFlag.binned,
                                              woe.HEWorstRatingP12Months.binned,
                                              woe.AVG_FEEAMOUNT_SecuredLoan_Q1.binned,
                                              woe.AVG_NEWBALANCE_SecuredLoan_Q1.binned,
                                              woe.FEEAMOUNT_SecuredLoan_Q1.binned,
                                              woe.INTEREST_AMOUNT_SecuredLoan_Q1.binned,
                                              woe.COUNT_KIOSK_SecuredLoan_Q1.binned,
                                              woe.COUNT_CHECKS_SecuredLoan_Q1.binned,
                                              woe.COUNT_INSURANCE_SecuredLoan_Q1.binned,
                                              woe.COUNT_HOMEBANKING_SecuredLoan_Q1.binned,
                                              woe.COUNT_FEE_SecuredLoan_Q1.binned,
                                              woe.COUNT_ACH_SecuredLoan_Q1.binned,
                                              woe.COUNT_DRAFT_SecuredLoan_Q1.binned,
                                              woe.COUNT_CASH_SecuredLoan_Q1.binned,
                                              woe.COUNT_LOAN_PAYMENT_SecuredLoan_Q1.binned,
                                              woe.COUNT_NEW_LOAN_SecuredLoan_Q1.binned,
                                              woe.COUNT_LOAN_ADDON_SecuredLoan_Q1.binned,
                                              woe.HEOpenBalance.binned,
                                              woe.HETotalAvailableLOC.binned,
                                              woe.UnsecuredLoan_MOB.binned,
                                              woe.DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_FEEAMOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_KIOSK_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CHECKS_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_FEE_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_ACH_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_DRAFT_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_CASH_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q2.binned,
                                              woe.COUNT_NEW_LOAN_SecuredLoan_Q1_Q2.binned,
                                              woe.DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q2.binned,
                                              woe.SAVINGS_Q1Flag.binned,
                                              MM_TargetFlag))
dim(df_train_woe) # 590

# 6. Random Forest Feature Selection

install.packages("randomForest")
install.packages('e1071')
install.packages('caret')
install.packages('ROCR')

library(randomForest)
library(e1071)
library(caret)
library(ROCR)
set.seed(2023)

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

RF_MM <- randomForest(MM_TargetFlag ~.,data = df_train_woe,ntree=50)

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

Important_vr <- importance(RF_MM)
write.csv(Important_vr,"Important Variables for MoneyMarket.csv")

df7 = subset(df_train_woe,select = c(woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned,
                                     woe.MOB_DEPOSITS.binned,
                                     woe.NumberInquiriesP6Months.binned,
                                     woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3.binned,
                                     woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned,
                                     woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned,
                                     woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned,
                                     woe.MOB_SAVINGS.binned,
                                     woe.AggregatedSpendPast3Months.binned,
                                     woe.StudentLoanOpenCount.binned,
                                     woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned,
                                     woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned,
                                     woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2.binned,
                                     woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                     woe.Days.Since.Last.Login.binned,
                                     woe.MortgageOpenCount.binned,
                                     woe.AutoOpenTradeCount.binned,
                                     woe.TopOfWalletCCCurrentBalance.binned,
                                     woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3.binned,
                                     woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q3.binned,
                                     woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned,
                                     woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                     woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3.binned,
                                     woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned,
                                     woe.MortgageOpenBalance.binned,
                                     woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3.binned,
                                     woe.HEOpenCount.binned,
                                     woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned,
                                     woe.PRODUCT_SAVINGS_SP.binned,
                                     woe.CCOpenBalance.binned,
                                     woe.CCAPREstimate.binned,
                                     woe.HELOCOpenCount.binned,
                                     woe.OpenTradeBalance.binned,
                                     woe.OpenTradeCount.binned,
                                     woe.CCTotalAvailableLOC.binned,
                                     woe.TopOfWalletCCAnnualSpend.binned,
                                     woe.PRODUCT_SAVINGS_Q1.binned,
                                     woe.RevolvingAccountCount.binned,
                                     woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned,
                                     woe.DEPOSITED_COUNT_DEPOSITS_Q1.binned,
                                     woe.CCRevolvingBalance.binned,
                                     woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned,
                                     woe.CCCount.binned,
                                     woe.DEPOSITED_COUNT_CHECKING_Q1.binned,
                                     woe.DEPOSITED_AMOUNT_CHECKING_Q1.binned,
                                     woe.Last.Statement.Average.Daily.Balance.Amount_CC_Q1.binned,
                                     woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned,
                                     woe.DFT_PRODUCT_CERTIFICATES_Q1_Q3.binned,
                                     woe.MOB_CERTIFICATES.binned,
                                     woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1_Q3.binned,
                                     woe.CERTIFICATES_StaticpoolFlag.binned,
                                     woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned,
                                     woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2.binned,
                                     woe.DFT_PRODUCT_CHECKING_Q1_Q3.binned,
                                     woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2.binned,
                                     woe.Vehicleloan_MOB.binned,
                                     woe.UnsecuredLoan_Month_to_Maturity.binned,
                                     woe.UnsecuredLoan_StaticPoolFlag.binned,
                                     woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned,
                                     woe.DEPOSITED_COUNT_SAVINGS_Q1.binned,
                                     woe.PRODUCT_RealEstate_Q1.binned,
                                     woe.VehicleLoan_StaticPoolFlag.binned,
                                     woe.IRA_StaticpoolFlag.binned,
                                     woe.COUNT_ACH_VehicleLoan_Q1.binned,
                                     woe.RealEstate_StaticPoolFlag.binned,
                                     woe.RealEstate_Month_to_Maturity.binned,
                                     woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned,
                                     woe.Vehicleloan_Month_to_Maturity.binned,
                                     woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3.binned,
                                     woe.DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q2.binned,
                                     woe.DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q3.binned,
                                     woe.DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q3.binned,
                                     woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned,
                                     woe.DFT_PRODUCT_SecuredLoan_Q1_Q2.binned,
                                     woe.DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q3.binned,
                                     woe.MAX_INTERESTRATE_RealEstate_Q1.binned,
                                     woe.DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q3.binned,
                                     woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned,
                                     woe.DFT_PAYMENTCOUNT_RealEstate_Q1_Q2.binned,
                                     woe.MAX_INTERESTRATE_VehicleLoan_Q1.binned,
                                     woe.DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q2.binned,
                                     woe.DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q3.binned,
                                     woe.DEPOSITED_AMOUNT_CERTIFICATES_Q1.binned,
                                     woe.WITHDRAWAL_AMOUNT_CERTIFICATES_Q1.binned,
                                     woe.DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q2.binned,
                                     woe.DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q3.binned,
                                     woe.SUM_INTEREST_CERTIFICATES_Q1.binned,
                                     woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2.binned,
                                     woe.DFT_Last.Statement.Return.Count_CC_Q1_Q3.binned,
                                     woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned,
                                     woe.DFT_Protected_Balance_CC_Q1_Q3.binned,
                                     woe.DFT_Last.Statement.Cash.Amount_CC_Q1_Q2.binned,
                                     woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q2.binned,
                                     woe.AutoWorstRatingP12Months.binned,
                                     MM_TargetFlag))
dim(df7) # 95

# 7.Stepwise Regession

install.packages("My.stepwise")
install.packages("carData")
install.packages("car")
install.packages("blorr")
library(My.stepwise)
library(carData)
library(car)
library(blorr)

# Iteration 1 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list1 = colnames(subset(df7,select = - MM_TargetFlag))
stepwise_1 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list1, data = df7, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_mod1 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned + woe.Days.Since.Last.Login.binned + 
                 woe.CCRevolvingBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.AutoWorstRatingP12Months.binned + 
                 woe.HELOCOpenCount.binned + woe.AggregatedSpendPast3Months.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + woe.IRA_StaticpoolFlag.binned + 
                 woe.MortgageOpenBalance.binned + woe.Vehicleloan_MOB.binned + 
                 woe.PRODUCT_SAVINGS_SP.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned + woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned + woe.CCAPREstimate.binned + 
                 woe.CCTotalAvailableLOC.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned + woe.DFT_PRODUCT_CERTIFICATES_Q1_Q3.binned,data = df7, 
               family = binomial(logit))

a1 = Anova(log_mod1,type = "II",test = "Wald")
v1 = vif(log_mod1)
write.csv(a1,"ANOVA.csv")
write.csv(v1, "VIF.csv")

summary(log_mod1)

org_mod1 = glm(MM_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                 Days.Since.Last.Login+
                 DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                 MOB_CERTIFICATES+
                 CCRevolvingBalance+
                 DEPOSITED_AMOUNT_DEPOSITS_Q1+
                 MortgageOpenCount+
                 HELOCOpenCount+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
                 MortgageOpenBalance+
                 AutoWorstRatingP12Months+
                 AggregatedSpendPast3Months+
                 WITHDRAWAL_AMOUNT_CHECKING_Q1+
                 PRODUCT_SAVINGS_SP+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2+
                 DFT_PRODUCT_DEPOSITS_Q1_Q3+
                 Vehicleloan_MOB+
                 AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                 IRA_StaticpoolFlag+
                 CERTIFICATES_StaticpoolFlag+
                 DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3+
                 DFT_PRODUCT_CERTIFICATES_Q1_Q3+
                 CCAPREstimate+
                 DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2+
                 CCTotalAvailableLOC,data = NAReplace_train,family = binomial(link = 'logit'))

summary(org_mod1)
o1 = vif(org_mod1)
write.csv(o1, "VIF.csv")

# woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned has negative estimate and high p value and woe.AutoWorstRatingP12Months.binned is a risk variable. So removing it.

df8 = subset(df7,select = -c(woe.AutoWorstRatingP12Months.binned,woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned))
dim(df8) # 93 vars

# Iteration 2 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list2 = colnames(subset(df8,select = - MM_TargetFlag))
stepwise_2 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list2, data = df8, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg2 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned + woe.Days.Since.Last.Login.binned + 
                 woe.CCRevolvingBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + woe.MortgageOpenBalance.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.PRODUCT_SAVINGS_SP.binned + 
                 woe.CCAPREstimate.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned + 
                 woe.AutoOpenTradeCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned + 
                 woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned + woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + 
                 woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned + woe.RealEstate_Month_to_Maturity.binned + 
                 woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned + woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
                 woe.CERTIFICATES_StaticpoolFlag.binned + woe.DFT_PRODUCT_CERTIFICATES_Q1_Q3.binned + 
                 woe.StudentLoanOpenCount.binned,data = df8 ,family = binomial(logit))

a2 = Anova(log_reg2,type = "II",test="Wald")
v2 = vif(log_reg2)
summary(log_reg2)
write.csv(a2,"ANOVA.csv")
write.csv(v2,"VIF.csv")

org_mod2 = glm(MM_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                 Days.Since.Last.Login+
                 DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                 MOB_CERTIFICATES+
                 CCRevolvingBalance+
                 DEPOSITED_AMOUNT_DEPOSITS_Q1+
                 AggregatedSpendPast3Months+
                 MortgageOpenBalance+
                 HELOCOpenCount+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
                 DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
                 MortgageOpenCount+
                 DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3+
                 DFT_PRODUCT_DEPOSITS_Q1_Q3+
                 PRODUCT_SAVINGS_SP+
                 AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                 IRA_StaticpoolFlag+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2+
                 DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
                 AutoOpenTradeCount+
                 WITHDRAWAL_AMOUNT_CHECKING_Q1+
                 CERTIFICATES_StaticpoolFlag+
                 RealEstate_Month_to_Maturity+
                 DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3+
                 CCAPREstimate+
                 DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2+
                 DFT_PRODUCT_CERTIFICATES_Q1_Q3+
                 StudentLoanOpenCount
               ,data = NAReplace_train,family = binomial(link = 'logit'))
summary(org_mod2)
o2=vif(org_mod2)
write.csv(o2,"VIF.csv")

# woe.DFT_PRODUCT_CERTIFICATES_Q1_Q3.binned has high p value and negative estimate. So removing it.

df9 = subset(df8,select = -woe.DFT_PRODUCT_CERTIFICATES_Q1_Q3.binned)
dim(df9) # 92 


# Iteration 3 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list3 = colnames(subset(df9,select = - MM_TargetFlag))
stepwise_3 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list3, data = df9, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg3 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned + woe.Days.Since.Last.Login.binned + 
                 woe.CCRevolvingBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + woe.MortgageOpenBalance.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.PRODUCT_SAVINGS_SP.binned + 
                 woe.CCAPREstimate.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned + 
                 woe.AutoOpenTradeCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned + 
                 woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned + woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + 
                 woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned + woe.RealEstate_Month_to_Maturity.binned + 
                 woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned + woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned + 
                 woe.CERTIFICATES_StaticpoolFlag.binned + woe.StudentLoanOpenCount.binned, data = df9,
               family = binomial(logit))

a3 = Anova(log_reg3,type="II",test="Wald")
v3 = vif(log_reg3)
summary(log_reg3)
write.csv(a3,"ANOVA.csv")
write.csv(v3,"VIF.csv")

org_mod3 = glm(MM_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                 Days.Since.Last.Login+
                 DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                 MOB_CERTIFICATES+
                 CCRevolvingBalance+
                 DEPOSITED_AMOUNT_DEPOSITS_Q1+
                 AggregatedSpendPast3Months+
                 HELOCOpenCount+
                 MortgageOpenBalance+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
                 DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
                 MortgageOpenCount+
                 PRODUCT_SAVINGS_SP+
                 DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3+
                 IRA_StaticpoolFlag+
                 AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2+
                 DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
                 AutoOpenTradeCount+
                 DFT_PRODUCT_DEPOSITS_Q1_Q3+
                 RealEstate_Month_to_Maturity+
                 WITHDRAWAL_AMOUNT_CHECKING_Q1+
                 DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3+
                 DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2+
                 CCAPREstimate+
                 StudentLoanOpenCount+
                 CERTIFICATES_StaticpoolFlag
               ,data=NAReplace_train,family = binomial(link = 'logit'))

summary(org_mod3)
o3 = vif(org_mod3)
write.csv(o3,"VIF.csv")

# woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned has high p value and negative estimate. So removing it.

df10 = subset(df9,select = -woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned)
dim(df10) # 91

# Iteration 4 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list4 = colnames(subset(df10,select = - MM_TargetFlag))
stepwise_4 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list4, data = df10, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg4 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned + woe.Days.Since.Last.Login.binned + 
                 woe.CCRevolvingBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + woe.MortgageOpenBalance.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.PRODUCT_SAVINGS_SP.binned + 
                 woe.CCAPREstimate.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned + 
                 woe.AutoOpenTradeCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned + 
                 woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned + woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + 
                 woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned + woe.RealEstate_Month_to_Maturity.binned + 
                 woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.StudentLoanOpenCount.binned,data = df10, family = binomial(logit))

a4 = Anova(log_reg4,type = "II",test = "Wald")
v4 = vif(log_reg4)
summary(log_reg4)
write.csv(a4,"ANOVA.csv")
write.csv(v4,"VIF.csv")

org_mod4 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                 Days.Since.Last.Login+
                 MOB_CERTIFICATES+
                 DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                 CCRevolvingBalance+
                 AggregatedSpendPast3Months+
                 HELOCOpenCount+
                 MortgageOpenBalance+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
                 MortgageOpenCount+
                 DEPOSITED_AMOUNT_DEPOSITS_Q1+
                 DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
                 PRODUCT_SAVINGS_SP+
                 DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3+
                 IRA_StaticpoolFlag+
                 AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2+
                 WITHDRAWAL_AMOUNT_CHECKING_Q1+
                 DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
                 AutoOpenTradeCount+
                 DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3+
                 RealEstate_Month_to_Maturity+
                 CCAPREstimate+
                 DFT_PRODUCT_DEPOSITS_Q1_Q3+
                 StudentLoanOpenCount+
                 CERTIFICATES_StaticpoolFlag
               ,data = NAReplace_train,family = binomial(link='logit'))

summary(org_mod4)
o4 = vif(org_mod4)
write.csv(o4,"VIF.csv")

# woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned has high p value and negative estimate

df11 = subset(df10,select = -woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3.binned)
dim(df11) # 90

# Iteration 5 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list5 = colnames(subset(df11,select = - MM_TargetFlag))
stepwise_5 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list5, data = df11, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg5 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned + woe.Days.Since.Last.Login.binned + 
                 woe.CCRevolvingBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + woe.MortgageOpenBalance.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.PRODUCT_SAVINGS_SP.binned + 
                 woe.CCAPREstimate.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned + 
                 woe.AutoOpenTradeCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned + 
                 woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned + 
                 woe.RealEstate_Month_to_Maturity.binned + woe.StudentLoanOpenCount.binned + 
                 woe.CERTIFICATES_StaticpoolFlag.binned + woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned,data = df11, 
               family = binomial(logit))

a5 = Anova(log_reg5,type="II",test="Wald")
v5 = vif(log_reg5)
summary(log_reg5)
write.csv(a5,"ANOVA.csv")
write.csv(v5,"VIF.csv")

org_mod5 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                 Days.Since.Last.Login+
                 MOB_CERTIFICATES+
                 DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                 CCRevolvingBalance+
                 AggregatedSpendPast3Months+
                 HELOCOpenCount+
                 MortgageOpenBalance+
                 DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
                 MortgageOpenCount+
                 AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                 DEPOSITED_AMOUNT_DEPOSITS_Q1+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
                 DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3+
                 PRODUCT_SAVINGS_SP+
                 IRA_StaticpoolFlag+
                 DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
                 AutoOpenTradeCount+
                 WITHDRAWAL_AMOUNT_CHECKING_Q1+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2+
                 RealEstate_Month_to_Maturity+
                 CCAPREstimate+
                 DFT_PRODUCT_DEPOSITS_Q1_Q3+
                 StudentLoanOpenCount+
                 CERTIFICATES_StaticpoolFlag
               ,data = NAReplace_train,family = binomial(link='logit'))
o5 = vif(org_mod5)
write.csv(o5,"VIF.csv")
summary(org_mod5)

# woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned has high p value and negative estimate

df12 = subset(df11,select = -woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned)
dim(df12) # 89

# Iteration 6 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list6 = colnames(subset(df12,select = - MM_TargetFlag))
stepwise_6 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list6, data = df12, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg6 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned + woe.Days.Since.Last.Login.binned + 
                 woe.CCRevolvingBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + woe.MortgageOpenBalance.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.PRODUCT_SAVINGS_SP.binned + 
                 woe.CCAPREstimate.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned + 
                 woe.AutoOpenTradeCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned + 
                 woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned + 
                 woe.RealEstate_Month_to_Maturity.binned + woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned + 
                 woe.CERTIFICATES_StaticpoolFlag.binned + woe.StudentLoanOpenCount.binned , data = df12, 
               family = binomial(logit))

a6 = Anova(log_reg6,type="II",test="Wald")
v6 = vif(log_reg6)
summary(log_reg6)

write.csv(a6,"ANOVA.csv")
write.csv(v6,"VIF.csv")

org_mod6 = glm(MM_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                 Days.Since.Last.Login+
                 MOB_CERTIFICATES+
                 DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                 CCRevolvingBalance+
                 AggregatedSpendPast3Months+
                 HELOCOpenCount+
                 MortgageOpenBalance+
                 DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
                 MortgageOpenCount+
                 AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                 DEPOSITED_AMOUNT_DEPOSITS_Q1+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
                 DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3+
                 PRODUCT_SAVINGS_SP+
                 IRA_StaticpoolFlag+
                 DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
                 AutoOpenTradeCount+
                 DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2+
                 RealEstate_Month_to_Maturity+
                 CCAPREstimate+
                 DFT_PRODUCT_DEPOSITS_Q1_Q3+
                 StudentLoanOpenCount+
                 CERTIFICATES_StaticpoolFlag
               ,data=NAReplace_train,family = binomial(link='logit'))
summary(org_mod6)
o6 = vif(org_mod6)
write.csv(o6,"VIF.csv")

# woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned has high p value and negative estimate. So removing it.

df13 = subset(df12,select=-woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned)
dim(df13) # 88


# Iteration 7 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list7 = colnames(subset(df13,select = - MM_TargetFlag))
stepwise_7 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list7, data = df13, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg7 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned + woe.Days.Since.Last.Login.binned + 
                 woe.CCRevolvingBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + woe.MortgageOpenBalance.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.PRODUCT_SAVINGS_SP.binned + 
                 woe.CCAPREstimate.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + woe.AutoOpenTradeCount.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned + woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + 
                 woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned + woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3.binned + 
                 woe.RealEstate_Month_to_Maturity.binned + woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned + 
                 woe.CERTIFICATES_StaticpoolFlag.binned + woe.StudentLoanOpenCount.binned,data = df13, 
               family = binomial(logit))

a7 = Anova(log_reg7,type="II",test="Wald")
v7 = vif(log_reg7)
summary(log_reg7)

write.csv(a7,"ANOVA.csv")
write.csv(v7,"VIF.csv")

org_mod7 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                 MOB_CERTIFICATES+
                 Days.Since.Last.Login+
                 DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                 CCRevolvingBalance+
                 AggregatedSpendPast3Months+
                 HELOCOpenCount+
                 MortgageOpenBalance+
                 DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
                 MortgageOpenCount+
                 AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
                 DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3+
                 DEPOSITED_AMOUNT_DEPOSITS_Q1+
                 PRODUCT_SAVINGS_SP+
                 IRA_StaticpoolFlag+
                 DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
                 AutoOpenTradeCount+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2+
                 CCAPREstimate+
                 RealEstate_Month_to_Maturity+
                 DFT_PRODUCT_DEPOSITS_Q1_Q3+
                 CERTIFICATES_StaticpoolFlag+
                 DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3+
                 StudentLoanOpenCount,
               data=NAReplace_train,family=binomial(link='logit'))

o7 = vif(org_mod7)
write.csv(o7,"VIF.csv")
summary(org_mod7)

# woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3.binned has negative estimate and high p value. So removing it.

df14 = subset(df13,select = -woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3.binned)
dim(df14) # 87


# Iteration 8 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list8 = colnames(subset(df14,select = - MM_TargetFlag))
stepwise_8 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list8, data = df14, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg8 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned + woe.Days.Since.Last.Login.binned + 
                 woe.CCRevolvingBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + woe.MortgageOpenBalance.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.PRODUCT_SAVINGS_SP.binned + 
                 woe.CCAPREstimate.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + woe.AutoOpenTradeCount.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned + woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + 
                 woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned + woe.RealEstate_Month_to_Maturity.binned + 
                 woe.CERTIFICATES_StaticpoolFlag.binned + woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned + 
                 woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3.binned + woe.StudentLoanOpenCount.binned,
               data=df14, family = binomial(logit))

a8 = Anova(log_reg8,type="II",test="Wald")
v8 = vif(log_reg8)
summary(log_reg8)

write.csv(a8,"ANOVA.csv")
write.csv(v8,"VIF.csv")

org_mod8 = glm(MM_TargetFlag~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                 MOB_CERTIFICATES+
                 Days.Since.Last.Login+
                 DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                 CCRevolvingBalance+
                 AggregatedSpendPast3Months+
                 HELOCOpenCount+
                 MortgageOpenBalance+
                 DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
                 MortgageOpenCount+
                 AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
                 DEPOSITED_AMOUNT_DEPOSITS_Q1+
                 IRA_StaticpoolFlag+
                 DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3+
                 PRODUCT_SAVINGS_SP+
                 DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
                 AutoOpenTradeCount+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2+
                 DFT_PRODUCT_DEPOSITS_Q1_Q3+
                 CCAPREstimate+
                 RealEstate_Month_to_Maturity+
                 DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3+
                 CERTIFICATES_StaticpoolFlag+
                 StudentLoanOpenCount
               ,data = NAReplace_train,family = binomial(link="logit"))

o8=vif(org_mod8)
write.csv(o8,"VIF.csv")
summary(org_mod8)

# woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3.binned has high p value and negative estimate. So removing it.

df15 = subset(df14,select = -woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3.binned)
dim(df15) # 86

# Iteration 9 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list9 = colnames(subset(df15,select = - MM_TargetFlag))
stepwise_9 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list9, data = df15, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg9 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned + woe.Days.Since.Last.Login.binned + 
                 woe.CCRevolvingBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + woe.MortgageOpenBalance.binned + 
                 woe.AggregatedSpendPast3Months.binned + woe.PRODUCT_SAVINGS_SP.binned + 
                 woe.CCAPREstimate.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                 woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + woe.AutoOpenTradeCount.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned + woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + 
                 woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned + woe.RealEstate_Month_to_Maturity.binned + 
                 woe.CERTIFICATES_StaticpoolFlag.binned + woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned + 
                 woe.StudentLoanOpenCount.binned, family = binomial(logit), 
               data = df15)

a9 = Anova(log_reg9,type="II",test= "Wald")
v9 = vif(log_reg9)
write.csv(a9,"ANOVA.csv")
write.csv(v9,"VIF.csv")
summary(log_reg9)

org_mod9 = glm(MM_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                 MOB_CERTIFICATES+
                 Days.Since.Last.Login+
                 CCRevolvingBalance+
                 DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                 MortgageOpenCount+
                 DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
                 HELOCOpenCount+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
                 IRA_StaticpoolFlag+
                 MortgageOpenBalance+
                 AggregatedSpendPast3Months+
                 PRODUCT_SAVINGS_SP+
                 CCAPREstimate+
                 AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                 DEPOSITED_AMOUNT_DEPOSITS_Q1+
                 AutoOpenTradeCount+
                 DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2+
                 DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
                 DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3+
                 RealEstate_Month_to_Maturity+
                 CERTIFICATES_StaticpoolFlag+
                 DFT_PRODUCT_DEPOSITS_Q1_Q3+
                 StudentLoanOpenCount
               ,data=NAReplace_train,family = binomial(link='logit'))

summary(org_mod9)
o9 = vif(org_mod9)

write.csv(o9,"VIF.csv")

# woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned has high p value and negative estimate.

df16 = subset(df15,select = -woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3.binned)
dim(df16) # 85


# Iteration 10 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list10 = colnames(subset(df16,select = - MM_TargetFlag))
stepwise_10 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list10, data = df16, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)


log_reg10 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                  woe.MOB_CERTIFICATES.binned + woe.Days.Since.Last.Login.binned + 
                  woe.CCRevolvingBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                  woe.MortgageOpenCount.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                  woe.HELOCOpenCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                  woe.IRA_StaticpoolFlag.binned + woe.MortgageOpenBalance.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.PRODUCT_SAVINGS_SP.binned + 
                  woe.CCAPREstimate.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + woe.AutoOpenTradeCount.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned + woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + 
                  woe.CERTIFICATES_StaticpoolFlag.binned + woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned + 
                  woe.StudentLoanOpenCount.binned, data=df16,family = binomial(logit))

a10 = Anova(log_reg10,type="II",test="Wald")
v10 = vif(log_reg10)
summary(log_reg10)

write.csv(a10,"ANOVA.csv")
write.csv(v10,"VIF.csv")

org_mod10 = glm(MM_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MOB_CERTIFICATES+
                  Days.Since.Last.Login+
                  CCRevolvingBalance+
                  DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                  MortgageOpenCount+
                  DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
                  HELOCOpenCount+
                  DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
                  IRA_StaticpoolFlag+
                  MortgageOpenBalance+
                  AggregatedSpendPast3Months+
                  PRODUCT_SAVINGS_SP+
                  CCAPREstimate+
                  AVG_MONTH_END_BALANCE_SAVINGS_Q1+
                  DEPOSITED_AMOUNT_DEPOSITS_Q1+
                  AutoOpenTradeCount+
                  DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2+
                  DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
                  CERTIFICATES_StaticpoolFlag+
                  DFT_PRODUCT_DEPOSITS_Q1_Q3+
                  StudentLoanOpenCount
                ,data = NAReplace_train,family=binomial(link="logit"))

o10 = vif(org_mod10)
write.csv(o10,"VIF.csv")
summary(org_mod10)

# woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned has negative estimate and high p value. So removing it. 

df17 = subset(df16,select = -woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned) 
dim(df17) # 84


# Iteration 11 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list11 = colnames(subset(df17,select = - MM_TargetFlag))
stepwise_11 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list11, data = df17, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg11 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                  woe.MOB_CERTIFICATES.binned + woe.Days.Since.Last.Login.binned + 
                  woe.CCRevolvingBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                  woe.MortgageOpenCount.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                  woe.HELOCOpenCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                  woe.IRA_StaticpoolFlag.binned + woe.MortgageOpenBalance.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.PRODUCT_SAVINGS_SP.binned + 
                  woe.CCAPREstimate.binned + woe.AutoOpenTradeCount.binned + 
                  woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                  woe.StudentLoanOpenCount.binned, family = binomial(logit), 
                data = df17)
a11 = Anova(log_reg11,type="II",test="Wald")
write.csv(a11,"ANOVA.csv")
v11 = vif(log_reg11)
write.csv(v11,"VIF.csv")

summary(log_reg11)

org_mod11 = glm(MM_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MOB_CERTIFICATES+
                  Days.Since.Last.Login+
                  CCRevolvingBalance+
                  DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                  MortgageOpenCount+
                  DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
                  HELOCOpenCount+
                  DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
                  IRA_StaticpoolFlag+
                  MortgageOpenBalance+
                  AggregatedSpendPast3Months+
                  PRODUCT_SAVINGS_SP+
                  CCAPREstimate+
                  AutoOpenTradeCount+
                  DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
                  DEPOSITED_AMOUNT_DEPOSITS_Q1+
                  DFT_PRODUCT_DEPOSITS_Q1_Q3+
                  CERTIFICATES_StaticpoolFlag+
                  StudentLoanOpenCount,
                data=NAReplace_train,family = binomial(link="logit"))

summary(org_mod11)

o11 = vif(org_mod11)
write.csv(o11,"VIF.csv")

# woe.MortgageOpenBalance.binned has high p value and negative estimate.

df18 = subset(df17,select=-woe.MortgageOpenBalance.binned)
dim(df18) # 83


# Iteration 12 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list12 = colnames(subset(df18,select = - MM_TargetFlag))
stepwise_12 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list12, data = df18, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg12 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                  woe.MOB_CERTIFICATES.binned + woe.Days.Since.Last.Login.binned + 
                  woe.CCRevolvingBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                  woe.MortgageOpenCount.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                  woe.HELOCOpenCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                  woe.IRA_StaticpoolFlag.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.CCAPREstimate.binned + woe.PRODUCT_SAVINGS_SP.binned + 
                  woe.AutoOpenTradeCount.binned + woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + 
                  woe.OpenTradeBalance.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                  woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned + woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.CCCount.binned + woe.CCTotalAvailableLOC.binned, family = binomial(logit), 
                data = df18)
a12 = Anova(log_reg12,type="II",test="Wald")
v12 = vif(log_reg12)
summary(log_reg12)
write.csv(a12,"ANOVA.csv")
write.csv(v12,"VIF.csv")

org_mod12 = glm(MM_TargetFlag ~ AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MOB_CERTIFICATES+
                  Days.Since.Last.Login+
                  CCRevolvingBalance+
                  DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                  MortgageOpenCount+
                  DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
                  HELOCOpenCount+
                  DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
                  IRA_StaticpoolFlag+
                  AggregatedSpendPast3Months+
                  CCAPREstimate+
                  PRODUCT_SAVINGS_SP+
                  AutoOpenTradeCount+
                  DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
                  OpenTradeBalance+
                  CERTIFICATES_StaticpoolFlag+
                  DFT_PRODUCT_DEPOSITS_Q1_Q3+
                  DEPOSITED_AMOUNT_DEPOSITS_Q1+
                  CCCount+
                  CCTotalAvailableLOC,data=NAReplace_train,family=binomial(link="logit"))
summary(org_mod12)
o12 = vif(org_mod12)
write.csv(o12,"VIF.csv")

# woe.CCCount.binned has negative estimate. So removing it.

df19 = subset(df18,select = -woe.CCCount.binned)
dim(df19) # 82

# Iteration 12 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list13 = colnames(subset(df19,select = - MM_TargetFlag))
stepwise_13 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list13, data = df19, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

train_target = subset(MM_train,select=c(AVG_MONTH_END_BALANCE_DEPOSITS_Q1,
                                        MOB_CERTIFICATES,
                                        DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3,
                                        Days.Since.Last.Login,
                                        DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3,
                                        DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3,
                                        CCRevolvingBalance,
                                        MortgageOpenCount,
                                        HELOCOpenCount,
                                        IRA_StaticpoolFlag,
                                        AggregatedSpendPast3Months,
                                        CCAPREstimate,
                                        DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3,
                                        AutoOpenTradeCount,
                                        DFT_PRODUCT_DEPOSITS_Q1_Q3,
                                        CERTIFICATES_StaticpoolFlag,
                                        PRODUCT_SAVINGS_SP,
                                        OpenTradeBalance,
                                        DEPOSITED_AMOUNT_DEPOSITS_Q1,
                                        StudentLoanOpenCount,
                                        MM_TargetFlag))



train_target$IRA_StaticpoolFlag = replace(train_target$IRA_StaticpoolFlag,is.na(train_target$IRA_StaticpoolFlag),0)
train_target$CERTIFICATES_StaticpoolFlag = replace(train_target$CERTIFICATES_StaticpoolFlag,is.na(train_target$CERTIFICATES_StaticpoolFlag),0)

NAReplace_train <- replace(train_target,is.na(train_target),-9999999)
sum(is.na(NAReplace_train)) 

MM_binning_train <- woe.binning(NAReplace_train,'MM_TargetFlag',NAReplace_train)
MM_train_woe <- woe.binning.deploy(NAReplace_train,MM_binning_train,add.woe.or.dum.var = "woe")
MM_train_woe$MM_TargetFlag = as.factor(MM_train_woe$MM_TargetFlag)

test_target = subset(MM_test,select=c(AVG_MONTH_END_BALANCE_DEPOSITS_Q1,
                                      MOB_CERTIFICATES,
                                      DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3,
                                      Days.Since.Last.Login,
                                      DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3,
                                      DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3,
                                      CCRevolvingBalance,
                                      MortgageOpenCount,
                                      HELOCOpenCount,
                                      IRA_StaticpoolFlag,
                                      AggregatedSpendPast3Months,
                                      CCAPREstimate,
                                      DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3,
                                      AutoOpenTradeCount,
                                      DFT_PRODUCT_DEPOSITS_Q1_Q3,
                                      CERTIFICATES_StaticpoolFlag,
                                      PRODUCT_SAVINGS_SP,
                                      OpenTradeBalance,
                                      DEPOSITED_AMOUNT_DEPOSITS_Q1,
                                      StudentLoanOpenCount,
                                      MM_TargetFlag))



test_target$IRA_StaticpoolFlag = replace(test_target$IRA_StaticpoolFlag,is.na(test_target$IRA_StaticpoolFlag),0)
test_target$CERTIFICATES_StaticpoolFlag = replace(test_target$CERTIFICATES_StaticpoolFlag,is.na(test_target$CERTIFICATES_StaticpoolFlag),0)

NAReplace_test <- replace(test_target,is.na(test_target),-9999999)
sum(is.na(NAReplace_test)) 

MM_binning_test <- woe.binning(NAReplace_test,'MM_TargetFlag',NAReplace_test)
MM_test_woe <- woe.binning.deploy(NAReplace_test,MM_binning_test,add.woe.or.dum.var = "woe")
MM_test_woe$MM_TargetFlag = as.factor(MM_test_woe$MM_TargetFlag)

# Model 1 :


log_reg13 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                  woe.MOB_CERTIFICATES.binned + woe.Days.Since.Last.Login.binned + 
                  woe.CCRevolvingBalance.binned + woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                  woe.MortgageOpenCount.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                  woe.HELOCOpenCount.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                  woe.IRA_StaticpoolFlag.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.CCAPREstimate.binned + woe.PRODUCT_SAVINGS_SP.binned + 
                  woe.AutoOpenTradeCount.binned + woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + 
                  woe.OpenTradeBalance.binned + woe.CERTIFICATES_StaticpoolFlag.binned + 
                  woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned + woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.StudentLoanOpenCount.binned, family = binomial(logit), 
                data = df19)
a13 = Anova(log_reg13,type="II",test="Wald")
write.csv(a13,"ANOVA.csv")
v13 = vif(log_reg13)
write.csv(v13,"VIF.csv")
summary(log_reg13)

org_mod13 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
                  MOB_CERTIFICATES+
                  Days.Since.Last.Login+
                  CCRevolvingBalance+
                  DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
                  MortgageOpenCount+
                  DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
                  HELOCOpenCount+
                  DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
                  IRA_StaticpoolFlag+
                  AggregatedSpendPast3Months+
                  CCAPREstimate+
                  PRODUCT_SAVINGS_SP+
                  AutoOpenTradeCount+
                  DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
                  OpenTradeBalance+
                  CERTIFICATES_StaticpoolFlag+
                  DFT_PRODUCT_DEPOSITS_Q1_Q3+
                  DEPOSITED_AMOUNT_DEPOSITS_Q1+
                  StudentLoanOpenCount
                ,data=NAReplace_train,family=binomial(link="logit"))
summary(org_mod13)
o13 = vif(org_mod13)
write.csv(o13,"VIF.csv")

train1 = blr_gains_table(log_reg13,df19)
test1 = blr_gains_table(log_reg13,MM_test_woe)

# Model 2

woe_mod2 = glm(MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned +
                 woe.Days.Since.Last.Login.binned + 
                 woe.CCRevolvingBalance.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + 
                 woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned +  
                 # woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + 
                 woe.AggregatedSpendPast3Months.binned + 
                 woe.CCAPREstimate.binned +
                 woe.PRODUCT_SAVINGS_SP.binned + 
                 woe.AutoOpenTradeCount.binned + 
                 woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + 
                 woe.OpenTradeBalance.binned +
                 woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned +
                 woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + 
                 woe.StudentLoanOpenCount.binned
               , family = binomial(logit), data = df19)
w2 = Anova(woe_mod2,type="II",test="Wald")
write.csv(w2,"ANOVA.csv")
wv2 = vif(woe_mod2)
write.csv(wv2,"VIF.csv")
summary(woe_mod2)

org2 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
             MOB_CERTIFICATES+
             Days.Since.Last.Login+
             CCRevolvingBalance+
             DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
             MortgageOpenCount+
             DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
             HELOCOpenCount+
             # DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
             IRA_StaticpoolFlag+
             AggregatedSpendPast3Months+
             CCAPREstimate+
             PRODUCT_SAVINGS_SP+
             AutoOpenTradeCount+
             DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
             OpenTradeBalance+
             CERTIFICATES_StaticpoolFlag+
             DFT_PRODUCT_DEPOSITS_Q1_Q3+
             DEPOSITED_AMOUNT_DEPOSITS_Q1+
             StudentLoanOpenCount
           ,data=NAReplace_train,family=binomial(link="logit"))
summary(org2)
ov2 = vif(org2)
write.csv(ov2,"VIF.csv")

train2 = blr_gains_table(woe_mod2,df19)
test2 = blr_gains_table(woe_mod2,MM_test_woe)


# Model 3

woe_mod3 = glm(MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned +
                 woe.Days.Since.Last.Login.binned + 
                 # woe.CCRevolvingBalance.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + 
                 woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned +  
                 # woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + 
                 woe.AggregatedSpendPast3Months.binned + 
                 woe.CCAPREstimate.binned +
                 woe.PRODUCT_SAVINGS_SP.binned + 
                 woe.AutoOpenTradeCount.binned + 
                 woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + 
                 woe.OpenTradeBalance.binned +
                 woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned +
                 woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + 
                 woe.StudentLoanOpenCount.binned
               , family = binomial(logit), data = df19)
w3 = Anova(woe_mod3,type="II",test="Wald")
write.csv(w3,"ANOVA.csv")
wv3 = vif(woe_mod3)
write.csv(wv3,"VIF.csv")
summary(woe_mod3)

org3 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
             MOB_CERTIFICATES+
             Days.Since.Last.Login+
             # CCRevolvingBalance+
             DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
             MortgageOpenCount+
             DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
             HELOCOpenCount+
             # DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
             IRA_StaticpoolFlag+
             AggregatedSpendPast3Months+
             CCAPREstimate+
             PRODUCT_SAVINGS_SP+
             AutoOpenTradeCount+
             DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
             OpenTradeBalance+
             CERTIFICATES_StaticpoolFlag+
             DFT_PRODUCT_DEPOSITS_Q1_Q3+
             DEPOSITED_AMOUNT_DEPOSITS_Q1+
             StudentLoanOpenCount
           ,data=NAReplace_train,family=binomial(link="logit"))
summary(org3)
ov3 = vif(org3)
write.csv(ov3,"VIF.csv")

train3 = blr_gains_table(woe_mod3,df19)
test3 = blr_gains_table(woe_mod3,MM_test_woe)

# Model 4

woe_mod4 = glm(MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned +
                 woe.Days.Since.Last.Login.binned + 
                 # woe.CCRevolvingBalance.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + 
                 woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned +  
                 # woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + 
                 woe.AggregatedSpendPast3Months.binned + 
                 woe.CCAPREstimate.binned +
                 woe.PRODUCT_SAVINGS_SP.binned + 
                 woe.AutoOpenTradeCount.binned + 
                 woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + 
                 # woe.OpenTradeBalance.binned +
                 woe.CERTIFICATES_StaticpoolFlag.binned + 
                 woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned +
                 woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + 
                 woe.StudentLoanOpenCount.binned
               , family = binomial(logit), data = df19)
w4 = Anova(woe_mod4,type="II",test="Wald")
write.csv(w4,"ANOVA.csv")
wv4 = vif(woe_mod4)
write.csv(wv4,"VIF.csv")
summary(woe_mod4)

org4 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
             MOB_CERTIFICATES+
             Days.Since.Last.Login+
             # CCRevolvingBalance+
             DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
             MortgageOpenCount+
             DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
             HELOCOpenCount+
             # DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
             IRA_StaticpoolFlag+
             AggregatedSpendPast3Months+
             CCAPREstimate+
             PRODUCT_SAVINGS_SP+
             AutoOpenTradeCount+
             DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
             # OpenTradeBalance+
             CERTIFICATES_StaticpoolFlag+
             DFT_PRODUCT_DEPOSITS_Q1_Q3+
             DEPOSITED_AMOUNT_DEPOSITS_Q1+
             StudentLoanOpenCount
           ,data=NAReplace_train,family=binomial(link="logit"))
summary(org4)
ov4 = vif(org4)
write.csv(ov4,"VIF.csv")

train4 = blr_gains_table(woe_mod4,df19)
test4 = blr_gains_table(woe_mod4,MM_test_woe)


# Model 5

woe_mod5 = glm(MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned +
                 woe.Days.Since.Last.Login.binned + 
                 # woe.CCRevolvingBalance.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + 
                 woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned +  
                 # woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + 
                 woe.AggregatedSpendPast3Months.binned + 
                 woe.CCAPREstimate.binned +
                 woe.PRODUCT_SAVINGS_SP.binned + 
                 woe.AutoOpenTradeCount.binned + 
                 woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + 
                 # woe.OpenTradeBalance.binned +
                 woe.CERTIFICATES_StaticpoolFlag.binned + 
                 # woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned +
                 woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + 
                 woe.StudentLoanOpenCount.binned
               , family = binomial(logit), data = df19)
w5 = Anova(woe_mod5,type="II",test="Wald")
write.csv(w5,"ANOVA.csv")
wv5 = vif(woe_mod5)
write.csv(wv5,"VIF.csv")
summary(woe_mod5)

org5 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
             MOB_CERTIFICATES+
             Days.Since.Last.Login+
             # CCRevolvingBalance+
             DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
             MortgageOpenCount+
             DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
             HELOCOpenCount+
             # DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
             IRA_StaticpoolFlag+
             AggregatedSpendPast3Months+
             CCAPREstimate+
             PRODUCT_SAVINGS_SP+
             AutoOpenTradeCount+
             DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
             # OpenTradeBalance+
             CERTIFICATES_StaticpoolFlag+
             # DFT_PRODUCT_DEPOSITS_Q1_Q3+
             DEPOSITED_AMOUNT_DEPOSITS_Q1+
             StudentLoanOpenCount
           ,data=NAReplace_train,family=binomial(link="logit"))
summary(org5)
ov5 = vif(org5)
write.csv(ov5,"VIF.csv")

train5 = blr_gains_table(woe_mod5,df19)
test5 = blr_gains_table(woe_mod5,MM_test_woe)

# Model 6

woe_mod6 = glm(MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                 woe.MOB_CERTIFICATES.binned +
                 woe.Days.Since.Last.Login.binned + 
                 # woe.CCRevolvingBalance.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + 
                 woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned +  
                 # woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + 
                 woe.AggregatedSpendPast3Months.binned + 
                 woe.CCAPREstimate.binned +
                 woe.PRODUCT_SAVINGS_SP.binned + 
                 woe.AutoOpenTradeCount.binned + 
                 woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + 
                 # woe.OpenTradeBalance.binned +
                 # woe.CERTIFICATES_StaticpoolFlag.binned + 
                 # woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned +
                 woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + 
                 woe.StudentLoanOpenCount.binned
               , family = binomial(logit), data = df19)
w6 = Anova(woe_mod6,type="II",test="Wald")
write.csv(w6,"ANOVA.csv")
wv6 = vif(woe_mod6)
write.csv(wv6,"VIF.csv")
summary(woe_mod6)

org6 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
             MOB_CERTIFICATES+
             Days.Since.Last.Login+
             # CCRevolvingBalance+
             DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
             MortgageOpenCount+
             DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
             HELOCOpenCount+
             # DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
             IRA_StaticpoolFlag+
             AggregatedSpendPast3Months+
             CCAPREstimate+
             PRODUCT_SAVINGS_SP+
             AutoOpenTradeCount+
             DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+
             # OpenTradeBalance+
             # CERTIFICATES_StaticpoolFlag+
             # DFT_PRODUCT_DEPOSITS_Q1_Q3+
             DEPOSITED_AMOUNT_DEPOSITS_Q1+
             StudentLoanOpenCount
           ,data=NAReplace_train,family=binomial(link="logit"))
summary(org6)
ov6 = vif(org6)
write.csv(ov6,"VIF.csv")

train6 = blr_gains_table(woe_mod6,df19)
test6 = blr_gains_table(woe_mod6,MM_test_woe)


# Model 7

woe_mod7 = glm(MM_TargetFlag ~ 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned +
                 woe.MOB_CERTIFICATES.binned +
                 woe.Days.Since.Last.Login.binned + 
                 # woe.CCRevolvingBalance.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + #5
                 woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned +  
                 # woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + 
                 woe.AggregatedSpendPast3Months.binned + 
                 woe.CCAPREstimate.binned +
                 woe.PRODUCT_SAVINGS_SP.binned + #4
                 woe.AutoOpenTradeCount.binned + 
                 woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned + #3
                 # woe.OpenTradeBalance.binned +
                 # woe.CERTIFICATES_StaticpoolFlag.binned + 
                 # woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned +
                 # woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + #1
                 woe.StudentLoanOpenCount.binned #2
               , family = binomial(logit), data = df19)
w7 = Anova(woe_mod7,type="II",test="Wald")
write.csv(w7,"ANOVA.csv")
wv7 = vif(woe_mod7)
write.csv(wv7,"VIF.csv")
summary(woe_mod7)

org7 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
             MOB_CERTIFICATES+
             Days.Since.Last.Login+
             # CCRevolvingBalance+
             DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
             MortgageOpenCount+ #5
             DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
             HELOCOpenCount+
             # DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
             IRA_StaticpoolFlag+
             AggregatedSpendPast3Months+
             CCAPREstimate+
             PRODUCT_SAVINGS_SP+ #4
             AutoOpenTradeCount+
             DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3+ #3
             # OpenTradeBalance+
             # CERTIFICATES_StaticpoolFlag+
             # DFT_PRODUCT_DEPOSITS_Q1_Q3+
             # DEPOSITED_AMOUNT_DEPOSITS_Q1+ #1
             StudentLoanOpenCount #2
           ,data=NAReplace_train,family=binomial(link="logit"))
summary(org7)
ov7 = vif(org7)
write.csv(ov7,"VIF.csv")

train7 = blr_gains_table(woe_mod7,df19)
test7 = blr_gains_table(woe_mod7,MM_test_woe)


# Model 8

woe_mod8 = glm(MM_TargetFlag ~ 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned +
                 woe.MOB_CERTIFICATES.binned +
                 woe.Days.Since.Last.Login.binned + 
                 # woe.CCRevolvingBalance.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + #5
                 woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned +  
                 # woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + 
                 woe.AggregatedSpendPast3Months.binned + 
                 woe.CCAPREstimate.binned +
                 woe.PRODUCT_SAVINGS_SP.binned + #4
                 woe.AutoOpenTradeCount.binned + 
                 woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned #+ #3
               # woe.OpenTradeBalance.binned +
               # woe.CERTIFICATES_StaticpoolFlag.binned + 
               # woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned +
               # woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + #1
               # woe.StudentLoanOpenCount.binned #2
               , family = binomial(logit), data = df19)
w8 = Anova(woe_mod8,type="II",test="Wald")
write.csv(w8,"ANOVA.csv")
wv8 = vif(woe_mod8)
write.csv(wv8,"VIF.csv")
summary(woe_mod8)

org8 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
             MOB_CERTIFICATES+
             Days.Since.Last.Login+
             # CCRevolvingBalance+
             DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
             MortgageOpenCount+ #5
             DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
             HELOCOpenCount+
             # DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
             IRA_StaticpoolFlag+
             AggregatedSpendPast3Months+
             CCAPREstimate+
             PRODUCT_SAVINGS_SP+ #4
             AutoOpenTradeCount+
             DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3#+ #3
           # OpenTradeBalance+
           # CERTIFICATES_StaticpoolFlag+
           # DFT_PRODUCT_DEPOSITS_Q1_Q3+
           # DEPOSITED_AMOUNT_DEPOSITS_Q1+ #1
           # StudentLoanOpenCount #2
           ,data=NAReplace_train,family=binomial(link="logit"))
summary(org8)
ov8 = vif(org8)
write.csv(ov8,"VIF.csv")

train8 = blr_gains_table(woe_mod8,df19)
test8 = blr_gains_table(woe_mod8,MM_test_woe)


# Model 9

woe_mod9 = glm(MM_TargetFlag ~ 
                 woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned +
                 woe.MOB_CERTIFICATES.binned +
                 woe.Days.Since.Last.Login.binned + 
                 # woe.CCRevolvingBalance.binned + 
                 woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                 woe.MortgageOpenCount.binned + #5
                 woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                 woe.HELOCOpenCount.binned +  
                 # woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                 woe.IRA_StaticpoolFlag.binned + 
                 woe.AggregatedSpendPast3Months.binned + 
                 woe.CCAPREstimate.binned +
                 woe.PRODUCT_SAVINGS_SP.binned + #4
                 woe.AutoOpenTradeCount.binned# + 
               # woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned #+ #3
               # woe.OpenTradeBalance.binned +
               # woe.CERTIFICATES_StaticpoolFlag.binned + 
               # woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned +
               # woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + #1
               # woe.StudentLoanOpenCount.binned #2
               , family = binomial(logit), data = df19)
w9 = Anova(woe_mod9,type="II",test="Wald")
write.csv(w9,"ANOVA.csv")
wv9 = vif(woe_mod9)
write.csv(wv9,"VIF.csv")
summary(woe_mod9)

org9 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
             MOB_CERTIFICATES+
             Days.Since.Last.Login+
             # CCRevolvingBalance+
             DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
             MortgageOpenCount+ #5
             DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
             HELOCOpenCount+
             # DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
             IRA_StaticpoolFlag+
             AggregatedSpendPast3Months+
             CCAPREstimate+
             PRODUCT_SAVINGS_SP+ #4
             AutoOpenTradeCount#+
           # DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3#+ #3
           # OpenTradeBalance+
           # CERTIFICATES_StaticpoolFlag+
           # DFT_PRODUCT_DEPOSITS_Q1_Q3+
           # DEPOSITED_AMOUNT_DEPOSITS_Q1+ #1
           # StudentLoanOpenCount #2
           ,data=NAReplace_train,family=binomial(link="logit"))
summary(org9)
ov9 = vif(org9)
write.csv(ov9,"VIF.csv")

train9 = blr_gains_table(woe_mod9,df19)
test9 = blr_gains_table(woe_mod9,MM_test_woe)

# Model 10

woe_mod10 = glm(MM_TargetFlag ~ 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned +
                  woe.MOB_CERTIFICATES.binned +
                  woe.Days.Since.Last.Login.binned + 
                  # woe.CCRevolvingBalance.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                  woe.MortgageOpenCount.binned + #5
                  woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                  woe.HELOCOpenCount.binned +  
                  # woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                  woe.IRA_StaticpoolFlag.binned + 
                  woe.AggregatedSpendPast3Months.binned + 
                  woe.CCAPREstimate.binned +
                  # woe.PRODUCT_SAVINGS_SP.binned + #4
                  woe.AutoOpenTradeCount.binned# + 
                # woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned #+ #3
                # woe.OpenTradeBalance.binned +
                # woe.CERTIFICATES_StaticpoolFlag.binned + 
                # woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned +
                # woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + #1
                # woe.StudentLoanOpenCount.binned #2
                , family = binomial(logit), data = df19)
w10 = Anova(woe_mod10,type="II",test="Wald")
write.csv(w10,"ANOVA.csv")
wv10 = vif(woe_mod10)
write.csv(wv10,"VIF.csv")
summary(woe_mod10)

org10 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
              MOB_CERTIFICATES+
              Days.Since.Last.Login+
              # CCRevolvingBalance+
              DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
              MortgageOpenCount+ #5
              DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
              HELOCOpenCount+
              # DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
              IRA_StaticpoolFlag+
              AggregatedSpendPast3Months+
              CCAPREstimate+
              # PRODUCT_SAVINGS_SP+ #4
              AutoOpenTradeCount#+
            # DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3#+ #3
            # OpenTradeBalance+
            # CERTIFICATES_StaticpoolFlag+
            # DFT_PRODUCT_DEPOSITS_Q1_Q3+
            # DEPOSITED_AMOUNT_DEPOSITS_Q1+ #1
            # StudentLoanOpenCount #2
            ,data=NAReplace_train,family=binomial(link="logit"))
summary(org10)
ov10 = vif(org10)
write.csv(ov10,"VIF.csv")

train10 = blr_gains_table(woe_mod10,df19)
test10 = blr_gains_table(woe_mod10,MM_test_woe)


# Model 11

woe_mod11 = glm(MM_TargetFlag ~ 
                  woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned +
                  woe.MOB_CERTIFICATES.binned +
                  woe.Days.Since.Last.Login.binned + 
                  # woe.CCRevolvingBalance.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + 
                  # woe.MortgageOpenCount.binned + #5
                  woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3.binned + 
                  woe.HELOCOpenCount.binned +  
                  # woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned + 
                  woe.IRA_StaticpoolFlag.binned + 
                  woe.AggregatedSpendPast3Months.binned + 
                  woe.CCAPREstimate.binned +
                  # woe.PRODUCT_SAVINGS_SP.binned + #4
                  woe.AutoOpenTradeCount.binned# + 
                # woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned #+ #3
                # woe.OpenTradeBalance.binned +
                # woe.CERTIFICATES_StaticpoolFlag.binned + 
                # woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned +
                # woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned + #1
                # woe.StudentLoanOpenCount.binned #2
                , family = binomial(logit), data = df19)
w11 = Anova(woe_mod11,type="II",test="Wald")
write.csv(w11,"ANOVA.csv")
wv11 = vif(woe_mod11)
write.csv(wv11,"VIF.csv")
summary(woe_mod10)

org11 = glm(MM_TargetFlag~AVG_MONTH_END_BALANCE_DEPOSITS_Q1+
              MOB_CERTIFICATES+
              Days.Since.Last.Login+
              # CCRevolvingBalance+
              DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3+
              # MortgageOpenCount+ #5
              DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3+
              HELOCOpenCount+
              # DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3+
              IRA_StaticpoolFlag+
              AggregatedSpendPast3Months+
              CCAPREstimate+
              # PRODUCT_SAVINGS_SP+ #4
              AutoOpenTradeCount#+
            # DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3#+ #3
            # OpenTradeBalance+
            # CERTIFICATES_StaticpoolFlag+
            # DFT_PRODUCT_DEPOSITS_Q1_Q3+
            # DEPOSITED_AMOUNT_DEPOSITS_Q1+ #1
            # StudentLoanOpenCount #2
            ,data=NAReplace_train,family=binomial(link="logit"))
summary(org11)
ov11 = vif(org11)
write.csv(ov11,"VIF.csv")

train11 = blr_gains_table(woe_mod11,df19)
test11 = blr_gains_table(woe_mod11,MM_test_woe)


df20 = subset(df19,select=-c( woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3.binned  ,
                                      woe.OpenTradeBalance.binned ,
                                      woe.CERTIFICATES_StaticpoolFlag.binned  ,
                                      woe.DFT_PRODUCT_DEPOSITS_Q1_Q3.binned ,
                                      woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned  ,
                                      woe.StudentLoanOpenCount.binned ,
                                      woe.CCRevolvingBalance.binned ,
                                      woe.MortgageOpenCount.binned,
                                      woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3.binned,
                                      woe.PRODUCT_SAVINGS_SP.binned ,
                                      woe.Days.Since.Last.Login.binned))


write.csv(colnames(df20),"COLNAMES.csv")

# MODEL 12

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list14 = colnames(subset(df20,select = - MM_TargetFlag))
stepwise_14 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list14, data = df20, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg20 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                  woe.MOB_CERTIFICATES.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.CCOpenBalance.binned + 
                  woe.AutoOpenTradeCount.binned + woe.HELOCOpenCount.binned + 
                  woe.DEPOSITED_COUNT_DEPOSITS_Q1.binned + woe.Vehicleloan_MOB.binned + 
                  woe.CCAPREstimate.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned + 
                  woe.IRA_StaticpoolFlag.binned + woe.CCTotalAvailableLOC.binned + 
                  woe.PRODUCT_SAVINGS_Q1.binned + woe.DEPOSITED_COUNT_SAVINGS_Q1.binned, 
                family = binomial(logit), data = df20)
a20=Anova(log_reg20,type="II",test="Wald")
v20=vif(log_reg20)
write.csv(a20,"ANOVA.csv")
write.csv(v20,"VIF.csv")
summary(log_reg20)

# woe.DEPOSITED_COUNT_SAVINGS_Q1.binned has negative estimate

df21 = subset(df20,select=-woe.DEPOSITED_COUNT_SAVINGS_Q1.binned)
dim(df21) #70


# MODEL 13

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list15 = colnames(subset(df21,select = - MM_TargetFlag))
stepwise_15 <- My.stepwise.glm(Y = "MM_TargetFlag", variable_list15, data = df21, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg21 = glm(formula = MM_TargetFlag ~ woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned + 
                  woe.MOB_CERTIFICATES.binned + woe.AggregatedSpendPast3Months.binned + 
                  woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3.binned + woe.CCOpenBalance.binned + 
                  woe.AutoOpenTradeCount.binned + woe.HELOCOpenCount.binned + 
                  woe.DEPOSITED_COUNT_DEPOSITS_Q1.binned + woe.Vehicleloan_MOB.binned + 
                  woe.CCAPREstimate.binned + woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned + 
                  woe.IRA_StaticpoolFlag.binned + woe.CCTotalAvailableLOC.binned + 
                  woe.PRODUCT_SAVINGS_Q1.binned, family = binomial(logit), 
                data = df21)

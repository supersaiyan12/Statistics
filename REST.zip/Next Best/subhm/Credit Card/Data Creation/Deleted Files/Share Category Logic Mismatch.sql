
	 drop table if exists #groupproducttype_Deposits  ---grouping table updated by Nikita 03/06/2022
		select *
		,case when ProductName like '%money%'  or ProductName like '% MM %' then 'MoneyMarket'
		when ProductName='Youth Savings' and ApplicationDescription='Certificates' then 'Savings'
		when ProductCode=0 and ApplicationDescription='Certificates' then 'Savings'
		when ProductName='40 Month CD' and ApplicationDescription='Certificates' then 'Checking'
		when ProductName='Certificate' and ApplicationDescription='Certificates' then 'Checking' 
		when ProductName='Public Funds' and ApplicationDescription='Certificates' then 'Certificates'
		when ProductName='Public Funds' and ApplicationDescription='Checking' then 'Certificates'
		when ProductName='Public Funds' and ApplicationDescription='Savings' then 'Certificates'  
		 else ApplicationDescription end Product_Group_wise,
		  case when productname like '%business%' or  productname like '%commercial%' or productname like '%professional%' or productcode in  ('143','5080','105','149','5013')
	 then 1 else 0 end Businessflag 
		into #groupproducttype_Deposits
		from
			(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName,ApplicationDescription,ApplicationTableName
			 from [AE_EDW].[tempods].[S_CRMProductType] a
			left join [AE_EDW].[tempods].[S_CRMApplicationType] b
			on a.ApplicationTypeID=b.ApplicationTypeID
			where ApplicationDescription is not null and ProductName!='IRA Savings'
			and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a

SELECT * FROM ARCUSYM000.ARCU.ARCUShareCategory
--WHERE ShareTypeDescription in(
SELECT * FROM #groupproducttype_Deposits
--)


		--	DROP TABLE IF EXISTS #tempsubham 
		--	select a.ApplicationTypeID
		--	,  case when productname like '%business%' or  productname like '%commercial%' or productname like '%professional%' or productcode in  ('143','5080','105','149','5013')
	 --then 1 else 0 end Businessflag 
		--	into #tempsubham
		--	 from [AE_EDW].[tempods].[S_CRMProductType] a
		--	left join [AE_EDW].[tempods].[S_CRMApplicationType] b
		--	on a.ApplicationTypeID=b.ApplicationTypeID
		--	where ApplicationDescription is not null and ProductName!='IRA Savings'
		--	and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits'

		--	SELECT * FROM #tempsubham a 
		--	left join 
		--	ARCUSYM000.ARCU.ARCUShareCategory b 
		--	on a.ApplicationTypeID = b.ShareType

		--SELECT * FROM	[AE_EDW].[tempods].[S_CRMProductType]

		
	
	--SELECT * FROM 
	--(
	--SELECT B.*,A.*
	--      ,CASE WHEN A.ProductName = B.ShareTypeDescription then 1 else 0 end [match] 
	--FROM #groupproducttype_Deposits A
 --RIGHT JOIN #www B
	--on A.ProductName = B.ShareTypeDescription
	--) D
	--where match = 0
	--SELECT * 
	----into #www 
	--from ARCUSYM000.ARCU.ARCUShareCategory
	--where ShareCategory3 not in ('HSA','IRA')
	--and ShareCategory1 ='Non-Member'
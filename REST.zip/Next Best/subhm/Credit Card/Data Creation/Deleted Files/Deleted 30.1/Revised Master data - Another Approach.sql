--/****************************************************************************************************/
--/*       NOTES BEFORE USING THIS CODE                                                               */
--/*                                                                                                  */
--/*       EXCLUSION *                                                                                */
--/*      Workout & Writeoff (add it back in case you're using for Attrition)                         */
--/*                                                                                                  */
--/*                                                                                                  */
--/*                                                                                                  */
--/*                                                                                                  */                                                                                                 */
--/*                                                                                                  */
--/*                                                                                                  */
--/*                                                                                                  */                                                                                                  */
--/*                                                                                                  */
--/*                                                                                                  */
--/*                                                                                                  */                                                                                                  */
--/*                                                                                                  */
--/*                                                                                                  */
--/*                                                                                                  */
--/****************************************************************************************************/

--Declaring the STATIC POOL

		DECLARE @staticpooldate date
		set @staticpooldate = '2021-09-30'

		--Taking Member Having General membership of Greenstate

		drop table if exists #Name
		select distinct a.PARENTACCOUNT,SSN 
		into #NAME
		from 
		(select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date from ARCUSYM000.dbo.NAME) a
		left join ARCUSYM000.dbo.SAVINGS b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		and a.ProcessDate=b.ProcessDate
		where a.TYPE=0
		and a.Process_date=@staticpooldate
		
		
		--
		 drop table if exists #Static_SSN_account_final
		select distinct  SSN 
		--,PARENTACCOUNT,Process_date
		into #Static_SSN_account_final
		from
		(    ---- SAving accounts detail
			select  b.SSN
					,a.PARENTACCOUNT
					,id
					,cast(OPENDATE as date) OPEN_DATE
					,cast(CLOSEDATE as date) CLOSE_DATE
					,cast(CHARGEOFFDATE as date) CHARGEOFFDATE
					,left(a.ProcessDate,6) ProcessDate_V
					,datefromparts(left(a.ProcessDate ,4),right(left(a.ProcessDate,6),2),right(a.ProcessDate,2)) Process_date
					,case when len(month(closedate))=1 then CONCAT(year(closedate),0,month(closedate)) 
						  else CONCAT(year(closedate),month(closedate)) end CLOSED_DATE_SAVINGS 
					,case when len(month(OpenDate))=1 then CONCAT(year(OpenDate),0,month(OpenDate)) 
					      else CONCAT(year(OpenDate),month(OpenDate))end  OPEN_DATE_INT_SAVINGS
					,case when len(month(CHARGEOFFDATE))=1 then CONCAT(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE)) 
					      else CONCAT(year(CHARGEOFFDATE),month(CHARGEOFFDATE))end  CHARGEOFF_DATE_SAVINGS
		
			from ARCUSYM000.dbo.SAVINGS a
			left join #NAME b 
			on a.PARENTACCOUNT=b.PARENTACCOUNT
		) aa
		where ssn is not null 
			and OPEN_DATE<@staticpooldate  
			and (CLOSE_DATE is null or CLOSE_DATE>@staticpooldate)
			and (CHARGEOFFDATE is null or CHARGEOFFDATE>@staticpooldate)  
			and Process_date=@staticpooldate 
		
		
		-- Remaning Parent to account name
		drop table if exists #Static_SSN_account
			select distinct 
				PARENTACCOUNT AccountNumber
				,SSN
			into #Static_SSN_account
			from #NAME

------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Loan Membership Master Data ***\\\-------------------------------------------------------------------
			 drop table if exists #membership_loan
			
			--select distinct parentaccount from #commercial_loan
			select 
				*
				,case when  (LoanCategory1 like 'commercial%')
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then  'Commercial_loan'
                 --when LoanCategory3 = '1st Mortgage'
				 --and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 --and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 --then 'Real_Estate_loan1'
				 --when LoanCategory3 = '2nd Mortgage'
				 --and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 --and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 --then 'Real_Estate_loan2'
				 when LoanCategory3 in ('1st Mortgage','2nd Mortgage')
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then 'Real_Estate_loan'
                when LoanCategory3 = 'Secured'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then 'SecuredLoan' 
                when LoanCategory3 = 'Unsecured'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				  then 'UnsecuredLoan' 
				when LoanCategory2 ='Vehicle'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				  then 'Vehicleloan' else 'Others' end as Product_Flag
							into #membership_loan
			from
			(
					select [ProcessDate]
						   ,left(ProcessDate,6) ProcessDate_V
						   ,Process_Date
						   ,Open_date
						   ,Close_date
						   ,case when Process_Date in ((DATEADD(month,-12,@staticpooldate)),(DATEADD(month,-11,@staticpooldate)),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		                         when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
 								 when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
								 when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
								 when Process_Date in (@staticpooldate) then 'Staticpool'
							end Quarters
							,d.SSN
							,[PARENTACCOUNT]
							,[ID]
							,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
							,case when len(month(a.closedate))=1 then CONCAT(year(a.closedate),0,month(a.closedate))
							      else CONCAT(year(a.closedate),month(a.closedate)) end  Closed_date_INT
							,case when len(month(a.opendate))=1 then CONCAT(year(a.opendate),0,month(a.opendate))
							      else CONCAT(year(a.opendate),month(a.opendate)) end  OPEN_date_INT
							,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
							,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
							,[TYPE]
							,[LASTFMDATE]
							,[LASTTRANDATE]
							,[ORIGINALDATE]
							,a.[OPENDATE]
							,a.[CLOSEDATE]
							,[LOANCODE]
							,[APPROVALCODE]
							,[APPROVALDATE]
							,[PAYMENTFREQUENCY]
							,[PARTIALPAYMENT]
							,[PAYMENT]
							,[PAYMENTCOUNT]
							,[DUEDAY1]
							--,[DUEDAY2]
							,[INTERESTRATE]
							,[ORIGINALBALANCE]
							,BALANCE
							,[CREDITLIMIT]
							,[DESCRIPTION]
							,[NSFMONTHTODATE]
							,[MATURITYDATE]
							,[APR]
							,[CREDITSCORE]
							,[ADVANCEAMOUNT]
							,b.LoanCategory1
							,b.LoanCategory2
							,b.LoanCategory3
							,b.LoanCategory4
							,b.LoanCategory5
							,b.LoanTypeDescription
							,CRPMTCURRENT
					  from 
					 (
						 select * 
						 ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
						 ,cast(OPENDATE as date) Open_date
						 ,cast(CLOSEDATE as date) Close_date,cast(MATURITYDATE as date) as MATURITY_DATE 
						 from ARCUSYM000.dbo.LOAN 
				     ) a
			
					left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
					on b.loantype=a.TYPE
					left join  #Static_SSN_account d
					on a.PARENTACCOUNT=d.AccountNumber
					where  ORIGINALDATE is not null 
					and a.OpenDate is not null 
					and a.Open_date < @staticpooldate  
					and (a.CLOSEDATE is null or a.Close_date>@staticpooldate )   
					and process_date between (select dateadd(MM,-12,@staticpooldate)) and (select dateadd(MM,12,@staticpooldate)) 
					and  PARENTACCOUNT in (select distinct AccountNumber PARENTACCOUNT from #Static_SSN_account )
		) AA
		where		LoanCategory3 not in ('Writeoff','Workout/TDR')
				    and LoanCategory4 not in ('Writeoff','Workout/TDR')
					and OPEN_DATE<@staticpooldate
					and (Close_date is null or Close_date>@staticpooldate) 
					and ORIGINALDATE <= Open_date 
					and Quarters is not null

		--SELECT count( ssn) FROM #membership_loan  -- 152347 out of 1944047 (On an Average Each member holds 12 product)

-- SSN having loan accounts except  Credit Cards

DROP TABLE IF EXISTS #loan_woCC

SELECT DISTINCT SSN
INTO #loan_woCC
FROM #membership_loan -- 152345

-- Derived variables for product holdings for loan variables without Creddit Card

DROP TABLE IF EXISTS #loan_product_holdings
--SELECT DISTINCT QUARTERS FROM #membership_loan
--SELECT DISTINCT Product_Flag FROM #membership_loan
SELECT SSN [SSN001]
       ,ISNULL(#Products_CommercialLoan_Q1,0) [PRODUCT_CommercialLoan_Q1]
	   ,(ISNULL(#Products_CommercialLoan_Q1,0) - ISNULL(#Products_CommercialLoan_Q2,0)) [DFT_PRODUCT_CommercialLoan_Q1_Q2]
	   ,(ISNULL(#Products_CommercialLoan_Q1,0) - ISNULL(#Products_CommercialLoan_Q3,0)) [DFT_PRODUCT_CommercialLoan_Q1_Q3]
	   --,(ISNULL(#Products_CommercialLoan_Q1,0) - ISNULL(#Products_CommercialLoan_Q4,0)) [DFT_PRODUCT_CommercialLoan_Q1_Q4]
	   --,ISNULL(#Products_RealEstate1_Q1,0) [PRODUCT_RealEstate1_Q1]
	   --,(ISNULL(#Products_RealEstate1_Q1,0) - ISNULL(#Products_RealEstate1_Q2,0)) [DFT_PRODUCT_RealEstate1_Q1_Q2]
	   --,(ISNULL(#Products_RealEstate1_Q1,0) - ISNULL(#Products_RealEstate1_Q3,0)) [DFT_PRODUCT_RealEstate1_Q1_Q3]
	   ----,(ISNULL(#Products_RealEstate1_Q1,0) - ISNULL(#Products_RealEstate1_Q4,0)) [DFT_PRODUCT_RealEstate1_Q1_Q4]
	   --,ISNULL(#Products_RealEstate2_Q1,0) [PRODUCT_RealEstate2_Q1]
	   --,(ISNULL(#Products_RealEstate2_Q1,0) - ISNULL(#Products_RealEstate2_Q2,0)) [DFT_PRODUCT_RealEstate2_Q1_Q2]
	   --,(ISNULL(#Products_RealEstate2_Q1,0) - ISNULL(#Products_RealEstate2_Q3,0)) [DFT_PRODUCT_RealEstate2_Q1_Q3]
	   ----,(ISNULL(#Products_RealEstate2_Q1,0) - ISNULL(#Products_RealEstate2_Q4,0)) [DFT_PRODUCT_RealEstate2_Q1_Q4]
	   ,ISNULL(#Products_RealEstate_Q1,0) [PRODUCT_RealEstate_Q1]
	   ,(ISNULL(#Products_RealEstate_Q1,0) - ISNULL(#Products_RealEstate_Q2,0)) [DFT_PRODUCT_RealEstate_Q1_Q2]
	   ,(ISNULL(#Products_RealEstate_Q1,0) - ISNULL(#Products_RealEstate_Q3,0)) [DFT_PRODUCT_RealEstate_Q1_Q3]
	   --,(ISNULL(#Products_RealEstate_Q1,0) - ISNULL(#Products_RealEstate_Q4,0)) [DFT_PRODUCT_RealEstate_Q1_Q4]
	   ,ISNULL(#Products_SecuredLoan_Q1,0) [PRODUCT_SecuredLoan_Q1]
	   ,(ISNULL(#Products_SecuredLoan_Q1,0) - ISNULL(#Products_SecuredLoan_Q2,0)) [DFT_PRODUCT_SecuredLoan_Q1_Q2]
	   ,(ISNULL(#Products_SecuredLoan_Q1,0) - ISNULL(#Products_SecuredLoan_Q3,0)) [DFT_PRODUCT_SecuredLoan_Q1_Q3]
	   --,(ISNULL(#Products_SecuredLoan_Q1,0) - ISNULL(#Products_SecuredLoan_Q4,0)) [DFT_PRODUCT_SecuredLoan_Q1_Q4]
	   ,ISNULL(#Products_UnsecuredLoan_Q1,0) [PRODUCT_UnsecuredLoan_Q1]
	   ,(ISNULL(#Products_UnsecuredLoan_Q1,0) - ISNULL(#Products_UnsecuredLoan_Q2,0)) [DFT_PRODUCT_UnsecuredLoan_Q1_Q2]
	   ,(ISNULL(#Products_UnsecuredLoan_Q1,0) - ISNULL(#Products_UnsecuredLoan_Q3,0)) [DFT_PRODUCT_UnsecuredLoan_Q1_Q3]
	   --,(ISNULL(#Products_UnsecuredLoan_Q1,0) - ISNULL(#Products_UnsecuredLoan_Q4,0)) [DFT_PRODUCT_UnsecuredLoan_Q1_Q4]
	   ,ISNULL(#Products_VehicleLoan_Q1,0) [PRODUCT_VehicleLoan_Q1]
	   ,(ISNULL(#Products_VehicleLoan_Q1,0) - ISNULL(#Products_VehicleLoan_Q2,0)) [DFT_PRODUCT_VehicleLoan_Q1_Q2]
	   ,(ISNULL(#Products_VehicleLoan_Q1,0) - ISNULL(#Products_VehicleLoan_Q3,0)) [DFT_PRODUCT_VehicleLoan_Q1_Q3]
	   --,(ISNULL(#Products_VehicleLoan_Q1,0) - ISNULL(#Products_VehicleLoan_Q4,0)) [DFT_PRODUCT_VehicleLoan_Q1_Q4]
	   ,ISNULL(#Products_Others_Q1,0) [PRODUCT_Others_Q1]
	   ,(ISNULL(#Products_Others_Q1,0) - ISNULL(#Products_Others_Q2,0)) [DFT_PRODUCT_Others_Q1_Q2]
	   ,(ISNULL(#Products_Others_Q1,0) - ISNULL(#Products_Others_Q3,0)) [DFT_PRODUCT_Others_Q1_Q3]
	   --,(ISNULL(#Products_Others_Q1,0) - ISNULL(#Products_Others_Q4,0)) [DFT_PRODUCT_Others_Q1_Q4]
	   ,ISNULL(#Products_Loan_Q1,0) [PRODUCT_Loan_Q1]
	   ,(ISNULL(#Products_Loan_Q1,0) - ISNULL(#Products_Loan_Q2,0)) [DFT_PRODUCT_Loan_Q1_Q2]
	   ,(ISNULL(#Products_Loan_Q1,0) - ISNULL(#Products_Loan_Q3,0)) [DFT_PRODUCT_Loan_Q1_Q3]

	   ,ISNULL(#Type_CommercialLoan_Q1,0) [TYPE_CommercialLoan_Q1]
	   ,(ISNULL(#Type_CommercialLoan_Q1,0) - ISNULL(#Type_CommercialLoan_Q2,0)) [DFT_TYPE_CommercialLoan_Q1_Q2]
	   ,(ISNULL(#Type_CommercialLoan_Q1,0) - ISNULL(#Type_CommercialLoan_Q3,0)) [DFT_TYPE_CommercialLoan_Q1_Q3]
	   --,(ISNULL(#Type_CommercialLoan_Q1,0) - ISNULL(#Type_CommercialLoan_Q4,0)) [DFT_TYPE_CommercialLoan_Q1_Q4]
	   ,ISNULL(#Type_RealEstate_Q1,0) [TYPE_RealEstate_Q1]
	   ,(ISNULL(#Type_RealEstate_Q1,0) - ISNULL(#Type_RealEstate_Q2,0)) [DFT_TYPE_RealEstate_Q1_Q2]
	   ,(ISNULL(#Type_RealEstate_Q1,0) - ISNULL(#Type_RealEstate_Q3,0)) [DFT_TYPE_RealEstate_Q1_Q3]
	   --,(ISNULL(#Type_RealEstate_Q1,0) - ISNULL(#Type_RealEstate_Q4,0)) [DFT_TYPE_RealEstate_Q1_Q4]
	   --,ISNULL(#Type_RealEstate1_Q1,0) [TYPE_RealEstate1_Q1]
	   --,(ISNULL(#Type_RealEstate1_Q1,0) - ISNULL(#Type_RealEstate1_Q2,0)) [DFT_TYPE_RealEstate1_Q1_Q2]
	   --,(ISNULL(#Type_RealEstate1_Q1,0) - ISNULL(#Type_RealEstate1_Q3,0)) [DFT_TYPE_RealEstate1_Q1_Q3]
	   ----,(ISNULL(#Type_RealEstate1_Q1,0) - ISNULL(#Type_RealEstate1_Q4,0)) [DFT_TYPE_RealEstate1_Q1_Q4]
	   --,ISNULL(#Type_RealEstate2_Q1,0) [TYPE_RealEstate2_Q1]
	   --,(ISNULL(#Type_RealEstate2_Q1,0) - ISNULL(#Type_RealEstate2_Q2,0)) [DFT_TYPE_RealEstate2_Q1_Q2]
	   --,(ISNULL(#Type_RealEstate2_Q1,0) - ISNULL(#Type_RealEstate2_Q3,0)) [DFT_TYPE_RealEstate2_Q1_Q3]
	   ----,(ISNULL(#Type_RealEstate2_Q1,0) - ISNULL(#Type_RealEstate2_Q4,0)) [DFT_TYPE_RealEstate2_Q1_Q4]
	   ,ISNULL(#Type_SecuredLoan_Q1,0) [TYPE_SecuredLoan_Q1]
	   ,(ISNULL(#Type_SecuredLoan_Q1,0) - ISNULL(#Type_SecuredLoan_Q2,0)) [DFT_TYPE_SecuredLoan_Q1_Q2]
	   ,(ISNULL(#Type_SecuredLoan_Q1,0) - ISNULL(#Type_SecuredLoan_Q3,0)) [DFT_TYPE_SecuredLoan_Q1_Q3]
	   --,(ISNULL(#Type_SecuredLoan_Q1,0) - ISNULL(#Type_SecuredLoan_Q4,0)) [DFT_TYPE_SecuredLoan_Q1_Q4]
	   ,ISNULL(#Type_UnsecuredLoan_Q1,0) [TYPE_UnsecuredLoan_Q1]
	   ,(ISNULL(#Type_UnsecuredLoan_Q1,0) - ISNULL(#Type_UnsecuredLoan_Q2,0)) [DFT_TYPE_UnsecuredLoan_Q1_Q2]
	   ,(ISNULL(#Type_UnsecuredLoan_Q1,0) - ISNULL(#Type_UnsecuredLoan_Q3,0)) [DFT_TYPE_UnsecuredLoan_Q1_Q3]
	   --,(ISNULL(#Type_UnsecuredLoan_Q1,0) - ISNULL(#Type_UnsecuredLoan_Q4,0)) [DFT_TYPE_UnsecuredLoan_Q1_Q4]
	   ,ISNULL(#Type_VehicleLoan_Q1,0) [TYPE_VehicleLoan_Q1]
	   ,(ISNULL(#Type_VehicleLoan_Q1,0) - ISNULL(#Type_VehicleLoan_Q2,0)) [DFT_TYPE_VehicleLoan_Q1_Q2]
	   ,(ISNULL(#Type_VehicleLoan_Q1,0) - ISNULL(#Type_VehicleLoan_Q3,0)) [DFT_TYPE_VehicleLoan_Q1_Q3]
	   --,(ISNULL(#Type_VehicleLoan_Q1,0) - ISNULL(#Type_VehicleLoan_Q4,0)) [DFT_TYPE_VehicleLoan_Q1_Q4]
	   ,ISNULL(#Type_Others_Q1,0) [TYPE_Others_Q1]
	   ,(ISNULL(#Type_Others_Q1,0) - ISNULL(#Type_Others_Q2,0)) [DFT_TYPE_Others_Q1_Q2]
	   ,(ISNULL(#Type_Others_Q1,0) - ISNULL(#Type_Others_Q3,0)) [DFT_TYPE_Others_Q1_Q3]
	   --,(ISNULL(#Type_Others_Q1,0) - ISNULL(#Type_Others_Q4,0)) [DFT_TYPE_Others_Q1_Q4]
	   ,ISNULL(#Type_Loan_Q1,0) [TYPE_Loan_Q1]
	   ,(ISNULL(#Type_Loan_Q1,0) - ISNULL(#Type_Loan_Q2,0)) [DFT_TYPE_Loan_Q1_Q2]
	   ,(ISNULL(#Type_Loan_Q1,0) - ISNULL(#Type_Loan_Q3,0)) [DFT_TYPE_Loan_Q1_Q3]
	    ,[CommercialLoan_MOB]
		,[RealEstate_MOB]
		--,[RealEstate1_MOB]
		--,[RealEstate2_MOB]
		,[SecuredLoan_MOB]
		,[UnsecuredLoan_MOB]
		,[Vehicleloan_MOB]
		,[Others_MOB]
		,MAX_Loan_MOB
	   ,ISNULL(PAYMENTCOUNT_CommercialLoan_Q1,0) [PAYMENTCOUNT_CommercialLoan_Q1]
	   ,(ISNULL(PAYMENTCOUNT_CommercialLoan_Q1,0) - ISNULL(PAYMENTCOUNT_CommercialLoan_Q2,0)) [DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q2]
	   ,(ISNULL(PAYMENTCOUNT_CommercialLoan_Q1,0) - ISNULL(PAYMENTCOUNT_CommercialLoan_Q3,0)) [DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q3]
	   --,(ISNULL(PAYMENTCOUNT_CommercialLoan_Q1,0) - ISNULL(PAYMENTCOUNT_CommercialLoan_Q4,0)) [DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q4]
	   ,ISNULL(PAYMENTCOUNT_RealEstate_Q1,0) [PAYMENTCOUNT_RealEstate_Q1]
	   ,(ISNULL(PAYMENTCOUNT_RealEstate_Q1,0) - ISNULL(PAYMENTCOUNT_RealEstate_Q2,0)) [DFT_PAYMENTCOUNT_RealEstate_Q1_Q2]
	   ,(ISNULL(PAYMENTCOUNT_RealEstate_Q1,0) - ISNULL(PAYMENTCOUNT_RealEstate_Q3,0)) [DFT_PAYMENTCOUNT_RealEstate_Q1_Q3]
	   --,(ISNULL(PAYMENTCOUNT_RealEstate_Q1,0) - ISNULL(PAYMENTCOUNT_RealEstate_Q4,0)) [DFT_PAYMENTCOUNT_RealEstate_Q1_Q4]
	   --,ISNULL(PAYMENTCOUNT_RealEstate1_Q1,0) [PAYMENTCOUNT_RealEstate1_Q1]
	   --,(ISNULL(PAYMENTCOUNT_RealEstate1_Q1,0) - ISNULL(PAYMENTCOUNT_RealEstate1_Q2,0)) [DFT_PAYMENTCOUNT_RealEstate1_Q1_Q2]
	   --,(ISNULL(PAYMENTCOUNT_RealEstate1_Q1,0) - ISNULL(PAYMENTCOUNT_RealEstate1_Q3,0)) [DFT_PAYMENTCOUNT_RealEstate1_Q1_Q3]
	   --,(ISNULL(PAYMENTCOUNT_RealEstate1_Q1,0) - ISNULL(PAYMENTCOUNT_RealEstate1_Q4,0)) [DFT_PAYMENTCOUNT_RealEstate1_Q1_Q4]
	   --,ISNULL(PAYMENTCOUNT_RealEstate2_Q1,0) [PAYMENTCOUNT_RealEstate2_Q1]
	   --,(ISNULL(PAYMENTCOUNT_RealEstate2_Q1,0) - ISNULL(PAYMENTCOUNT_RealEstate2_Q2,0)) [DFT_PAYMENTCOUNT_RealEstate2_Q1_Q2]
	   --,(ISNULL(PAYMENTCOUNT_RealEstate2_Q1,0) - ISNULL(PAYMENTCOUNT_RealEstate2_Q3,0)) [DFT_PAYMENTCOUNT_RealEstate2_Q1_Q3]
	   --,(ISNULL(PAYMENTCOUNT_RealEstate2_Q1,0) - ISNULL(PAYMENTCOUNT_RealEstate2_Q4,0)) [DFT_PAYMENTCOUNT_RealEstate2_Q1_Q4]
	   ,ISNULL(PAYMENTCOUNT_SecuredLoan_Q1,0) [PAYMENTCOUNT_SecuredLoan_Q1]
	   ,(ISNULL(PAYMENTCOUNT_SecuredLoan_Q1,0) - ISNULL(PAYMENTCOUNT_SecuredLoan_Q2,0)) [DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q2]
	   ,(ISNULL(PAYMENTCOUNT_SecuredLoan_Q1,0) - ISNULL(PAYMENTCOUNT_SecuredLoan_Q3,0)) [DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q3]
	   --,(ISNULL(PAYMENTCOUNT_SecuredLoan_Q1,0) - ISNULL(PAYMENTCOUNT_SecuredLoan_Q4,0)) [DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q4]
	   ,ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q1,0) [PAYMENTCOUNT_UnsecuredLoan_Q1]
	   ,(ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q1,0) - ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q2,0)) [DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q2]
	   ,(ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q1,0) - ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q3,0)) [DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q3]
	   --,(ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q1,0) - ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q4,0)) [DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q4]
	   ,ISNULL(PAYMENTCOUNT_VehicleLoan_Q1,0) [PAYMENTCOUNT_VehicleLoan_Q1]
	   ,(ISNULL(PAYMENTCOUNT_VehicleLoan_Q1,0) - ISNULL(PAYMENTCOUNT_VehicleLoan_Q2,0)) [DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q2]
	   ,(ISNULL(PAYMENTCOUNT_VehicleLoan_Q1,0) - ISNULL(PAYMENTCOUNT_VehicleLoan_Q3,0)) [DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q3]
	   --,(ISNULL(PAYMENTCOUNT_VehicleLoan_Q1,0) - ISNULL(PAYMENTCOUNT_VehicleLoan_Q4,0)) [DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q4]
	   ,ISNULL(PAYMENTCOUNT_Others_Q1,0) [PAYMENTCOUNT_Others_Q1]
	   ,(ISNULL(PAYMENTCOUNT_Others_Q1,0) - ISNULL(PAYMENTCOUNT_Others_Q2,0)) [DFT_PAYMENTCOUNT_Others_Q1_Q2]
	   ,(ISNULL(PAYMENTCOUNT_Others_Q1,0) - ISNULL(PAYMENTCOUNT_Others_Q3,0)) [DFT_PAYMENTCOUNT_Others_Q1_Q3]
	   --,(ISNULL(PAYMENTCOUNT_Others_Q1,0) - ISNULL(PAYMENTCOUNT_Others_Q4,0)) [DFT_PAYMENTCOUNT_Others_Q1_Q4]
	   ,ISNULL(PAYMENTCOUNT_Loan_Q1,0) [PAYMENTCOUNT_Loan_Q1]
	   ,(ISNULL(PAYMENTCOUNT_Loan_Q1,0) - ISNULL(PAYMENTCOUNT_Loan_Q2,0)) [DFT_PAYMENTCOUNT_Loan_Q1_Q2]
	   ,(ISNULL(PAYMENTCOUNT_Loan_Q1,0) - ISNULL(PAYMENTCOUNT_Loan_Q3,0)) [DFT_PAYMENTCOUNT_Loan_Q1_Q3]
	   --,ISNULL(MAX_OriginalBalance_CommercialLoan_Q1,0) [MAX_OriginalBalance_CommercialLoan_Q1]
	   --,(ISNULL(MAX_OriginalBalance_CommercialLoan_Q1,0) - ISNULL(MAX_OriginalBalance_CommercialLoan_Q2,0)) [DFT_MAX_OriginalBalance_CommercialLoan_Q1_Q2]
	   --,(ISNULL(MAX_OriginalBalance_CommercialLoan_Q1,0) - ISNULL(MAX_OriginalBalance_CommercialLoan_Q3,0)) [DFT_MAX_OriginalBalance_CommercialLoan_Q1_Q3]
	   ----,(ISNULL(MAX_OriginalBalance_CommercialLoan_Q1,0) - ISNULL(MAX_OriginalBalance_CommercialLoan_Q4,0)) [DFT_MAX_OriginalBalance_CommercialLoan_Q1_Q4]
	   --,ISNULL(MAX_OriginalBalance_RealEstate_Q1,0) [MAX_OriginalBalance_RealEstate_Q1]
	   --,(ISNULL(MAX_OriginalBalance_RealEstate_Q1,0) - ISNULL(MAX_OriginalBalance_RealEstate_Q2,0)) [DFT_MAX_OriginalBalance_RealEstate_Q1_Q2]
	   --,(ISNULL(MAX_OriginalBalance_RealEstate_Q1,0) - ISNULL(MAX_OriginalBalance_RealEstate_Q3,0)) [DFT_MAX_OriginalBalance_RealEstate_Q1_Q3]
	   --,(ISNULL(MAX_OriginalBalance_RealEstate_Q1,0) - ISNULL(MAX_OriginalBalance_RealEstate_Q4,0)) [DFT_MAX_OriginalBalance_RealEstate_Q1_Q4]
	   --,ISNULL(MAX_OriginalBalance_RealEstate1_Q1,0) [MAX_OriginalBalance_RealEstate1_Q1]
	   --,(ISNULL(MAX_OriginalBalance_RealEstate1_Q1,0) - ISNULL(MAX_OriginalBalance_RealEstate1_Q2,0)) [DFT_MAX_OriginalBalance_RealEstate1_Q1_Q2]
	   --,(ISNULL(MAX_OriginalBalance_RealEstate1_Q1,0) - ISNULL(MAX_OriginalBalance_RealEstate1_Q3,0)) [DFT_MAX_OriginalBalance_RealEstate1_Q1_Q3]
	   --,(ISNULL(MAX_OriginalBalance_RealEstate1_Q1,0) - ISNULL(MAX_OriginalBalance_RealEstate1_Q4,0)) [DFT_MAX_OriginalBalance_RealEstate1_Q1_Q4]
	   --,ISNULL(MAX_OriginalBalance_RealEstate2_Q1,0) [MAX_OriginalBalance_RealEstate2_Q1]
	   --,(ISNULL(MAX_OriginalBalance_RealEstate2_Q1,0) - ISNULL(MAX_OriginalBalance_RealEstate2_Q2,0)) [DFT_MAX_OriginalBalance_RealEstate2_Q1_Q2]
	   --,(ISNULL(MAX_OriginalBalance_RealEstate2_Q1,0) - ISNULL(MAX_OriginalBalance_RealEstate2_Q3,0)) [DFT_MAX_OriginalBalance_RealEstate2_Q1_Q3]
	   --,(ISNULL(MAX_OriginalBalance_RealEstate2_Q1,0) - ISNULL(MAX_OriginalBalance_RealEstate2_Q4,0)) [DFT_MAX_OriginalBalance_RealEstate2_Q1_Q4]
	   --,ISNULL(MAX_OriginalBalance_SecuredLoan_Q1,0) [MAX_OriginalBalance_SecuredLoan_Q1]
	   --,(ISNULL(MAX_OriginalBalance_SecuredLoan_Q1,0) - ISNULL(MAX_OriginalBalance_SecuredLoan_Q2,0)) [DFT_MAX_OriginalBalance_SecuredLoan_Q1_Q2]
	   --,(ISNULL(MAX_OriginalBalance_SecuredLoan_Q1,0) - ISNULL(MAX_OriginalBalance_SecuredLoan_Q3,0)) [DFT_MAX_OriginalBalance_SecuredLoan_Q1_Q3]
	   ----,(ISNULL(MAX_OriginalBalance_SecuredLoan_Q1,0) - ISNULL(MAX_OriginalBalance_SecuredLoan_Q4,0)) [DFT_MAX_OriginalBalance_SecuredLoan_Q1_Q4]
	   --,ISNULL(MAX_OriginalBalance_UnsecuredLoan_Q1,0) [MAX_OriginalBalance_UnsecuredLoan_Q1]
	   --,(ISNULL(MAX_OriginalBalance_UnsecuredLoan_Q1,0) - ISNULL(MAX_OriginalBalance_UnsecuredLoan_Q2,0)) [DFT_MAX_OriginalBalance_UnsecuredLoan_Q1_Q2]
	   --,(ISNULL(MAX_OriginalBalance_UnsecuredLoan_Q1,0) - ISNULL(MAX_OriginalBalance_UnsecuredLoan_Q3,0)) [DFT_MAX_OriginalBalance_UnsecuredLoan_Q1_Q3]
	   ----,(ISNULL(MAX_OriginalBalance_UnsecuredLoan_Q1,0) - ISNULL(MAX_OriginalBalance_UnsecuredLoan_Q4,0)) [DFT_MAX_OriginalBalance_UnsecuredLoan_Q1_Q4]
	   --,ISNULL(MAX_OriginalBalance_VehicleLoan_Q1,0) [MAX_OriginalBalance_VehicleLoan_Q1]
	   --,(ISNULL(MAX_OriginalBalance_VehicleLoan_Q1,0) - ISNULL(MAX_OriginalBalance_VehicleLoan_Q2,0)) [DFT_MAX_OriginalBalance_VehicleLoan_Q1_Q2]
	   --,(ISNULL(MAX_OriginalBalance_VehicleLoan_Q1,0) - ISNULL(MAX_OriginalBalance_VehicleLoan_Q3,0)) [DFT_MAX_OriginalBalance_VehicleLoan_Q1_Q3]
	   ----,(ISNULL(MAX_OriginalBalance_VehicleLoan_Q1,0) - ISNULL(MAX_OriginalBalance_VehicleLoan_Q4,0)) [DFT_MAX_OriginalBalance_VehicleLoan_Q1_Q4]
	   --,ISNULL(MAX_OriginalBalance_Others_Q1,0) [MAX_OriginalBalance_Others_Q1]
	   --,(ISNULL(MAX_OriginalBalance_Others_Q1,0) - ISNULL(MAX_OriginalBalance_Others_Q2,0)) [DFT_MAX_OriginalBalance_Others_Q1_Q2]
	   --,(ISNULL(MAX_OriginalBalance_Others_Q1,0) - ISNULL(MAX_OriginalBalance_Others_Q3,0)) [DFT_MAX_OriginalBalance_Others_Q1_Q3]
	   ----,(ISNULL(MAX_OriginalBalance_Others_Q1,0) - ISNULL(MAX_OriginalBalance_Others_Q4,0)) [DFT_MAX_OriginalBalance_Others_Q1_Q4]

	   ,ISNULL(SUM_OriginalBalance_CommercialLoan_Q1,0) [SUM_OriginalBalance_CommercialLoan_Q1]
	   ,(ISNULL(SUM_OriginalBalance_CommercialLoan_Q1,0) - ISNULL(SUM_OriginalBalance_CommercialLoan_Q2,0)) [DFT_SUM_OriginalBalance_CommercialLoan_Q1_Q2]
	   ,(ISNULL(SUM_OriginalBalance_CommercialLoan_Q1,0) - ISNULL(SUM_OriginalBalance_CommercialLoan_Q3,0)) [DFT_SUM_OriginalBalance_CommercialLoan_Q1_Q3]
	   --,(ISNULL(SUM_OriginalBalance_CommercialLoan_Q1,0) - ISNULL(SUM_OriginalBalance_CommercialLoan_Q4,0)) [DFT_SUM_OriginalBalance_CommercialLoan_Q1_Q4]
	   ,ISNULL(SUM_OriginalBalance_RealEstate_Q1,0) [SUM_OriginalBalance_RealEstate_Q1]
	   ,(ISNULL(SUM_OriginalBalance_RealEstate_Q1,0) - ISNULL(SUM_OriginalBalance_RealEstate_Q2,0)) [DFT_SUM_OriginalBalance_RealEstate_Q1_Q2]
	   ,(ISNULL(SUM_OriginalBalance_RealEstate_Q1,0) - ISNULL(SUM_OriginalBalance_RealEstate_Q3,0)) [DFT_SUM_OriginalBalance_RealEstate_Q1_Q3]
	   --,(ISNULL(SUM_OriginalBalance_RealEstate_Q1,0) - ISNULL(SUM_OriginalBalance_RealEstate_Q4,0)) [DFT_SUM_OriginalBalance_RealEstate_Q1_Q4]
	   --,ISNULL(SUM_OriginalBalance_RealEstate1_Q1,0) [SUM_OriginalBalance_RealEstate1_Q1]
	   --,(ISNULL(SUM_OriginalBalance_RealEstate1_Q1,0) - ISNULL(SUM_OriginalBalance_RealEstate1_Q2,0)) [DFT_SUM_OriginalBalance_RealEstate1_Q1_Q2]
	   --,(ISNULL(SUM_OriginalBalance_RealEstate1_Q1,0) - ISNULL(SUM_OriginalBalance_RealEstate1_Q3,0)) [DFT_SUM_OriginalBalance_RealEstate1_Q1_Q3]
	   --,(ISNULL(SUM_OriginalBalance_RealEstate1_Q1,0) - ISNULL(SUM_OriginalBalance_RealEstate1_Q4,0)) [DFT_SUM_OriginalBalance_RealEstate1_Q1_Q4]
	   --,ISNULL(SUM_OriginalBalance_RealEstate2_Q1,0) [SUM_OriginalBalance_RealEstate2_Q1]
	   --,(ISNULL(SUM_OriginalBalance_RealEstate2_Q1,0) - ISNULL(SUM_OriginalBalance_RealEstate2_Q2,0)) [DFT_SUM_OriginalBalance_RealEstate2_Q1_Q2]
	   --,(ISNULL(SUM_OriginalBalance_RealEstate2_Q1,0) - ISNULL(SUM_OriginalBalance_RealEstate2_Q3,0)) [DFT_SUM_OriginalBalance_RealEstate2_Q1_Q3]
	   --,(ISNULL(SUM_OriginalBalance_RealEstate2_Q1,0) - ISNULL(SUM_OriginalBalance_RealEstate2_Q4,0)) [DFT_SUM_OriginalBalance_RealEstate2_Q1_Q4]
	   ,ISNULL(SUM_OriginalBalance_SecuredLoan_Q1,0) [SUM_OriginalBalance_SecuredLoan_Q1]
	   ,(ISNULL(SUM_OriginalBalance_SecuredLoan_Q1,0) - ISNULL(SUM_OriginalBalance_SecuredLoan_Q2,0)) [DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q2]
	   ,(ISNULL(SUM_OriginalBalance_SecuredLoan_Q1,0) - ISNULL(SUM_OriginalBalance_SecuredLoan_Q3,0)) [DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q3]
	   --,(ISNULL(SUM_OriginalBalance_SecuredLoan_Q1,0) - ISNULL(SUM_OriginalBalance_SecuredLoan_Q4,0)) [DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q4]
	   ,ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q1,0) [SUM_OriginalBalance_UnsecuredLoan_Q1]
	   ,(ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q1,0) - ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q2,0)) [DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q2]
	   ,(ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q1,0) - ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q3,0)) [DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q3]
	   --,(ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q1,0) - ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q4,0)) [DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q4]
	   ,ISNULL(SUM_OriginalBalance_VehicleLoan_Q1,0) [SUM_OriginalBalance_VehicleLoan_Q1]
	   ,(ISNULL(SUM_OriginalBalance_VehicleLoan_Q1,0) - ISNULL(SUM_OriginalBalance_VehicleLoan_Q2,0)) [DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q2]
	   ,(ISNULL(SUM_OriginalBalance_VehicleLoan_Q1,0) - ISNULL(SUM_OriginalBalance_VehicleLoan_Q3,0)) [DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q3]
	   --,(ISNULL(SUM_OriginalBalance_VehicleLoan_Q1,0) - ISNULL(SUM_OriginalBalance_VehicleLoan_Q4,0)) [DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q4]
	   ,ISNULL(SUM_OriginalBalance_Others_Q1,0) [SUM_OriginalBalance_Others_Q1]
	   ,(ISNULL(SUM_OriginalBalance_Others_Q1,0) - ISNULL(SUM_OriginalBalance_Others_Q2,0)) [DFT_SUM_OriginalBalance_Others_Q1_Q2]
	   ,(ISNULL(SUM_OriginalBalance_Others_Q1,0) - ISNULL(SUM_OriginalBalance_Others_Q3,0)) [DFT_SUM_OriginalBalance_Others_Q1_Q3]
	   --,(ISNULL(SUM_OriginalBalance_Others_Q1,0) - ISNULL(SUM_OriginalBalance_Others_Q4,0)) [DFT_SUM_OriginalBalance_Others_Q1_Q4]
	   ,ISNULL(SUM_OriginalBalance_Loan_Q1,0) [SUM_OriginalBalance_Loan_Q1]
	   ,(ISNULL(SUM_OriginalBalance_Loan_Q1,0) - ISNULL(SUM_OriginalBalance_Loan_Q2,0)) [DFT_SUM_OriginalBalance_Loan_Q1_Q2]
	   ,(ISNULL(SUM_OriginalBalance_Loan_Q1,0) - ISNULL(SUM_OriginalBalance_Loan_Q3,0)) [DFT_SUM_OriginalBalance_Loan_Q1_Q3]

	   ,ISNULL(SUM_PAYMENT_CommercialLoan_Q1,0) [SUM_PAYMENT_CommercialLoan_Q1]
	   ,(ISNULL(SUM_PAYMENT_CommercialLoan_Q1,0) - ISNULL(SUM_PAYMENT_CommercialLoan_Q2,0)) [DFT_SUM_PAYMENT_CommercialLoan_Q1_Q2]
	   ,(ISNULL(SUM_PAYMENT_CommercialLoan_Q1,0) - ISNULL(SUM_PAYMENT_CommercialLoan_Q3,0)) [DFT_SUM_PAYMENT_CommercialLoan_Q1_Q3]
	   --,(ISNULL(SUM_PAYMENT_CommercialLoan_Q1,0) - ISNULL(SUM_PAYMENT_CommercialLoan_Q4,0)) [DFT_SUM_PAYMENT_CommercialLoan_Q1_Q4]
	   ,ISNULL(SUM_PAYMENT_RealEstate_Q1,0) [SUM_PAYMENT_RealEstate_Q1]
	   ,(ISNULL(SUM_PAYMENT_RealEstate_Q1,0) - ISNULL(SUM_PAYMENT_RealEstate_Q2,0)) [DFT_SUM_PAYMENT_RealEstate_Q1_Q2]
	   ,(ISNULL(SUM_PAYMENT_RealEstate_Q1,0) - ISNULL(SUM_PAYMENT_RealEstate_Q3,0)) [DFT_SUM_PAYMENT_RealEstate_Q1_Q3]
	   --,(ISNULL(SUM_PAYMENT_RealEstate_Q1,0) - ISNULL(SUM_PAYMENT_RealEstate_Q4,0)) [DFT_SUM_PAYMENT_RealEstate_Q1_Q4]
	   --,ISNULL(SUM_PAYMENT_RealEstate1_Q1,0) [SUM_PAYMENT_RealEstate1_Q1]
	   --,(ISNULL(SUM_PAYMENT_RealEstate1_Q1,0) - ISNULL(SUM_PAYMENT_RealEstate1_Q2,0)) [DFT_SUM_PAYMENT_RealEstate1_Q1_Q2]
	   --,(ISNULL(SUM_PAYMENT_RealEstate1_Q1,0) - ISNULL(SUM_PAYMENT_RealEstate1_Q3,0)) [DFT_SUM_PAYMENT_RealEstate1_Q1_Q3]
	   --,(ISNULL(SUM_PAYMENT_RealEstate1_Q1,0) - ISNULL(SUM_PAYMENT_RealEstate1_Q4,0)) [DFT_SUM_PAYMENT_RealEstate1_Q1_Q4]
	   --,ISNULL(SUM_PAYMENT_RealEstate2_Q1,0) [SUM_PAYMENT_RealEstate2_Q1]
	   --,(ISNULL(SUM_PAYMENT_RealEstate2_Q1,0) - ISNULL(SUM_PAYMENT_RealEstate2_Q2,0)) [DFT_SUM_PAYMENT_RealEstate2_Q1_Q2]
	   --,(ISNULL(SUM_PAYMENT_RealEstate2_Q1,0) - ISNULL(SUM_PAYMENT_RealEstate2_Q3,0)) [DFT_SUM_PAYMENT_RealEstate2_Q1_Q3]
	   --,(ISNULL(SUM_PAYMENT_RealEstate2_Q1,0) - ISNULL(SUM_PAYMENT_RealEstate2_Q4,0)) [DFT_SUM_PAYMENT_RealEstate2_Q1_Q4]
	   ,ISNULL(SUM_PAYMENT_SecuredLoan_Q1,0) [SUM_PAYMENT_SecuredLoan_Q1]
	   ,(ISNULL(SUM_PAYMENT_SecuredLoan_Q1,0) - ISNULL(SUM_PAYMENT_SecuredLoan_Q2,0)) [DFT_SUM_PAYMENT_SecuredLoan_Q1_Q2]
	   ,(ISNULL(SUM_PAYMENT_SecuredLoan_Q1,0) - ISNULL(SUM_PAYMENT_SecuredLoan_Q3,0)) [DFT_SUM_PAYMENT_SecuredLoan_Q1_Q3]
	   --,(ISNULL(SUM_PAYMENT_SecuredLoan_Q1,0) - ISNULL(SUM_PAYMENT_SecuredLoan_Q4,0)) [DFT_SUM_PAYMENT_SecuredLoan_Q1_Q4]
	   ,ISNULL(SUM_PAYMENT_UnsecuredLoan_Q1,0) [SUM_PAYMENT_UnsecuredLoan_Q1]
	   ,(ISNULL(SUM_PAYMENT_UnsecuredLoan_Q1,0) - ISNULL(SUM_PAYMENT_UnsecuredLoan_Q2,0)) [DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q2]
	   ,(ISNULL(SUM_PAYMENT_UnsecuredLoan_Q1,0) - ISNULL(SUM_PAYMENT_UnsecuredLoan_Q3,0)) [DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q3]
	   --,(ISNULL(SUM_PAYMENT_UnsecuredLoan_Q1,0) - ISNULL(SUM_PAYMENT_UnsecuredLoan_Q4,0)) [DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q4]
	   ,ISNULL(SUM_PAYMENT_VehicleLoan_Q1,0) [SUM_PAYMENT_VehicleLoan_Q1]
	   ,(ISNULL(SUM_PAYMENT_VehicleLoan_Q1,0) - ISNULL(SUM_PAYMENT_VehicleLoan_Q2,0)) [DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2]
	   ,(ISNULL(SUM_PAYMENT_VehicleLoan_Q1,0) - ISNULL(SUM_PAYMENT_VehicleLoan_Q3,0)) [DFT_SUM_PAYMENT_VehicleLoan_Q1_Q3]
	   --,(ISNULL(SUM_PAYMENT_VehicleLoan_Q1,0) - ISNULL(SUM_PAYMENT_VehicleLoan_Q4,0)) [DFT_SUM_PAYMENT_VehicleLoan_Q1_Q4]
	   ,ISNULL(SUM_PAYMENT_Others_Q1,0) [SUM_PAYMENT_Others_Q1]
	   ,(ISNULL(SUM_PAYMENT_Others_Q1,0) - ISNULL(SUM_PAYMENT_Others_Q2,0)) [DFT_SUM_PAYMENT_Others_Q1_Q2]
	   ,(ISNULL(SUM_PAYMENT_Others_Q1,0) - ISNULL(SUM_PAYMENT_Others_Q3,0)) [DFT_SUM_PAYMENT_Others_Q1_Q3]
	   --,(ISNULL(SUM_PAYMENT_Others_Q1,0) - ISNULL(SUM_PAYMENT_Others_Q4,0)) [DFT_SUM_PAYMENT_Others_Q1_Q4]

	   ,ISNULL(SUM_PAYMENT_Loan_Q1,0) [SUM_PAYMENT_Loan_Q1]
	   ,(ISNULL(SUM_PAYMENT_Loan_Q1,0) - ISNULL(SUM_PAYMENT_Loan_Q2,0)) [DFT_SUM_PAYMENT_Loan_Q1_Q2]
	   ,(ISNULL(SUM_PAYMENT_Loan_Q1,0) - ISNULL(SUM_PAYMENT_Loan_Q3,0)) [DFT_SUM_PAYMENT_Loan_Q1_Q3]
	   --,(ISNULL(SUM_PAYMENT_Loan_Q1,0) - ISNULL(SUM_PAYMENT_Loan_Q4,0)) [DFT_SUM_PAYMENT_Loan_Q1_Q4]

	   ,ISNULL(MAX_INTERESTRATE_CommercialLoan_Q1,0) [MAX_INTERESTRATE_CommercialLoan_Q1]
	   ,(ISNULL(MAX_INTERESTRATE_CommercialLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_CommercialLoan_Q2,0)) [DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q2]
	   ,(ISNULL(MAX_INTERESTRATE_CommercialLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_CommercialLoan_Q3,0)) [DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q3]
	   --,(ISNULL(MAX_INTERESTRATE_CommercialLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_CommercialLoan_Q4,0)) [DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q4]
	   ,ISNULL(MAX_INTERESTRATE_RealEstate_Q1,0) [MAX_INTERESTRATE_RealEstate_Q1]
	   ,(ISNULL(MAX_INTERESTRATE_RealEstate_Q1,0) - ISNULL(MAX_INTERESTRATE_RealEstate_Q2,0)) [DFT_MAX_INTERESTRATE_RealEstate_Q1_Q2]
	   ,(ISNULL(MAX_INTERESTRATE_RealEstate_Q1,0) - ISNULL(MAX_INTERESTRATE_RealEstate_Q3,0)) [DFT_MAX_INTERESTRATE_RealEstate_Q1_Q3]
	   --,(ISNULL(MAX_INTERESTRATE_RealEstate_Q1,0) - ISNULL(MAX_INTERESTRATE_RealEstate_Q4,0)) [DFT_MAX_INTERESTRATE_RealEstate_Q1_Q4]
	   --,ISNULL(MAX_INTERESTRATE_RealEstate1_Q1,0) [MAX_INTERESTRATE_RealEstate1_Q1]
	   --,(ISNULL(MAX_INTERESTRATE_RealEstate1_Q1,0) - ISNULL(MAX_INTERESTRATE_RealEstate1_Q2,0)) [DFT_MAX_INTERESTRATE_RealEstate1_Q1_Q2]
	   --,(ISNULL(MAX_INTERESTRATE_RealEstate1_Q1,0) - ISNULL(MAX_INTERESTRATE_RealEstate1_Q3,0)) [DFT_MAX_INTERESTRATE_RealEstate1_Q1_Q3]
	   --,(ISNULL(MAX_INTERESTRATE_RealEstate1_Q1,0) - ISNULL(MAX_INTERESTRATE_RealEstate1_Q4,0)) [DFT_MAX_INTERESTRATE_RealEstate1_Q1_Q4]
	   --,ISNULL(MAX_INTERESTRATE_RealEstate2_Q1,0) [MAX_INTERESTRATE_RealEstate2_Q1]
	   --,(ISNULL(MAX_INTERESTRATE_RealEstate2_Q1,0) - ISNULL(MAX_INTERESTRATE_RealEstate2_Q2,0)) [DFT_MAX_INTERESTRATE_RealEstate2_Q1_Q2]
	   --,(ISNULL(MAX_INTERESTRATE_RealEstate2_Q1,0) - ISNULL(MAX_INTERESTRATE_RealEstate2_Q3,0)) [DFT_MAX_INTERESTRATE_RealEstate2_Q1_Q3]
	   --,(ISNULL(MAX_INTERESTRATE_RealEstate2_Q1,0) - ISNULL(MAX_INTERESTRATE_RealEstate2_Q4,0)) [DFT_MAX_INTERESTRATE_RealEstate2_Q1_Q4]
	   ,ISNULL(MAX_INTERESTRATE_SecuredLoan_Q1,0) [MAX_INTERESTRATE_SecuredLoan_Q1]
	   ,(ISNULL(MAX_INTERESTRATE_SecuredLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_SecuredLoan_Q2,0)) [DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q2]
	   ,(ISNULL(MAX_INTERESTRATE_SecuredLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_SecuredLoan_Q3,0)) [DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q3]
	   --,(ISNULL(MAX_INTERESTRATE_SecuredLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_SecuredLoan_Q4,0)) [DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q4]
	   ,ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q1,0) [MAX_INTERESTRATE_UnsecuredLoan_Q1]
	   ,(ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q2,0)) [DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q2]
	   ,(ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q3,0)) [DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q3]
	   --,(ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q4,0)) [DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q4]
	   ,ISNULL(MAX_INTERESTRATE_VehicleLoan_Q1,0) [MAX_INTERESTRATE_VehicleLoan_Q1]
	   ,(ISNULL(MAX_INTERESTRATE_VehicleLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_VehicleLoan_Q2,0)) [DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q2]
	   ,(ISNULL(MAX_INTERESTRATE_VehicleLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_VehicleLoan_Q3,0)) [DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q3]
	   --,(ISNULL(MAX_INTERESTRATE_VehicleLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_VehicleLoan_Q4,0)) [DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q4]
	   ,ISNULL(MAX_INTERESTRATE_Others_Q1,0) [MAX_INTERESTRATE_Others_Q1]
	   ,(ISNULL(MAX_INTERESTRATE_Others_Q1,0) - ISNULL(MAX_INTERESTRATE_Others_Q2,0)) [DFT_MAX_INTERESTRATE_Others_Q1_Q2]
	   ,(ISNULL(MAX_INTERESTRATE_Others_Q1,0) - ISNULL(MAX_INTERESTRATE_Others_Q3,0)) [DFT_MAX_INTERESTRATE_Others_Q1_Q3]
	   --,(ISNULL(MAX_INTERESTRATE_Others_Q1,0) - ISNULL(MAX_INTERESTRATE_Others_Q4,0)) [DFT_MAX_INTERESTRATE_Others_Q1_Q4]
	    ,ISNULL(MAX_INTERESTRATE_Loan_Q1,0) [MAX_INTERESTRATE_Loan_Q1]
	   ,(ISNULL(MAX_INTERESTRATE_Loan_Q1,0) - ISNULL(MAX_INTERESTRATE_Loan_Q2,0)) [DFT_MAX_INTERESTRATE_Loan_Q1_Q2]
	   ,(ISNULL(MAX_INTERESTRATE_Loan_Q1,0) - ISNULL(MAX_INTERESTRATE_Loan_Q3,0)) [DFT_MAX_INTERESTRATE_Loan_Q1_Q3]
	   --,(ISNULL(MAX_INTERESTRATE_Loan_Q1,0) - ISNULL(MAX_INTERESTRATE_Loan_Q4,0)) [DFT_MAX_INTERESTRATE_Loan_Q1_Q4]
	   ,ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q1,0) [MAX_CREDITLIMIT_CommercialLoan_Q1]
	   ,(ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q2,0)) [DFT_MAX_CREDITLIMIT_CommercialLoan_Q1_Q2]
	   ,(ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q3,0)) [DFT_MAX_CREDITLIMIT_CommercialLoan_Q1_Q3]
	   --,(ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q4,0)) [DFT_MAX_CREDITLIMIT_CommercialLoan_Q1_Q4]
	   ,ISNULL(MAX_CREDITLIMIT_RealEstate_Q1,0) [MAX_CREDITLIMIT_RealEstate_Q1]
	   ,(ISNULL(MAX_CREDITLIMIT_RealEstate_Q1,0) - ISNULL(MAX_CREDITLIMIT_RealEstate_Q2,0)) [DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q2]
	   ,(ISNULL(MAX_CREDITLIMIT_RealEstate_Q1,0) - ISNULL(MAX_CREDITLIMIT_RealEstate_Q3,0)) [DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q3]
	   --,(ISNULL(MAX_CREDITLIMIT_RealEstate_Q1,0) - ISNULL(MAX_CREDITLIMIT_RealEstate_Q4,0)) [DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q4]
	   --,ISNULL(MAX_CREDITLIMIT_RealEstate1_Q1,0) [MAX_CREDITLIMIT_RealEstate1_Q1]
	   --,(ISNULL(MAX_CREDITLIMIT_RealEstate1_Q1,0) - ISNULL(MAX_CREDITLIMIT_RealEstate1_Q2,0)) [DFT_MAX_CREDITLIMIT_RealEstate1_Q1_Q2]
	   --,(ISNULL(MAX_CREDITLIMIT_RealEstate1_Q1,0) - ISNULL(MAX_CREDITLIMIT_RealEstate1_Q3,0)) [DFT_MAX_CREDITLIMIT_RealEstate1_Q1_Q3]
	   --,(ISNULL(MAX_CREDITLIMIT_RealEstate1_Q1,0) - ISNULL(MAX_CREDITLIMIT_RealEstate1_Q4,0)) [DFT_MAX_CREDITLIMIT_RealEstate1_Q1_Q4]
	   --,ISNULL(MAX_CREDITLIMIT_RealEstate2_Q1,0) [MAX_CREDITLIMIT_RealEstate2_Q1]
	   --,(ISNULL(MAX_CREDITLIMIT_RealEstate2_Q1,0) - ISNULL(MAX_CREDITLIMIT_RealEstate2_Q2,0)) [DFT_MAX_CREDITLIMIT_RealEstate2_Q1_Q2]
	   --,(ISNULL(MAX_CREDITLIMIT_RealEstate2_Q1,0) - ISNULL(MAX_CREDITLIMIT_RealEstate2_Q3,0)) [DFT_MAX_CREDITLIMIT_RealEstate2_Q1_Q3]
	   --,(ISNULL(MAX_CREDITLIMIT_RealEstate2_Q1,0) - ISNULL(MAX_CREDITLIMIT_RealEstate2_Q4,0)) [DFT_MAX_CREDITLIMIT_RealEstate2_Q1_Q4]
	   ,ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q1,0) [MAX_CREDITLIMIT_SecuredLoan_Q1]
	   ,(ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q2,0)) [DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q2]
	   ,(ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q3,0)) [DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q3]
	   --,(ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q4,0)) [DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q4]
	   ,ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q1,0) [MAX_CREDITLIMIT_UnsecuredLoan_Q1]
	   ,(ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q2,0)) [DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q2]
	   ,(ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q3,0)) [DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q3]
	   --,(ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q4,0)) [DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q4]
	   ,ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q1,0) [MAX_CREDITLIMIT_VehicleLoan_Q1]
	   ,(ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q2,0)) [DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q2]
	   ,(ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q3,0)) [DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q3]
	   --,(ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q4,0)) [DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q4]
	   ,ISNULL(MAX_CREDITLIMIT_Others_Q1,0) [MAX_CREDITLIMIT_Others_Q1]
	   ,(ISNULL(MAX_CREDITLIMIT_Others_Q1,0) - ISNULL(MAX_CREDITLIMIT_Others_Q2,0)) [DFT_MAX_CREDITLIMIT_Others_Q1_Q2]
	   ,(ISNULL(MAX_CREDITLIMIT_Others_Q1,0) - ISNULL(MAX_CREDITLIMIT_Others_Q3,0)) [DFT_MAX_CREDITLIMIT_Others_Q1_Q3]
	   --,(ISNULL(MAX_CREDITLIMIT_Others_Q1,0) - ISNULL(MAX_CREDITLIMIT_Others_Q4,0)) [DFT_MAX_CREDITLIMIT_Others_Q1_Q4]
	   ,ISNULL(MAX_CREDITLIMIT_Loan_Q1,0) [MAX_CREDITLIMIT_Loan_Q1]
	   ,(ISNULL(MAX_CREDITLIMIT_Loan_Q1,0) - ISNULL(MAX_CREDITLIMIT_Loan_Q2,0)) [DFT_MAX_CREDITLIMIT_Loan_Q1_Q2]
	   ,(ISNULL(MAX_CREDITLIMIT_Loan_Q1,0) - ISNULL(MAX_CREDITLIMIT_Loan_Q3,0)) [DFT_MAX_CREDITLIMIT_Loan_Q1_Q3]
	   --,(ISNULL(MAX_CREDITLIMIT_Loan_Q1,0) - ISNULL(MAX_CREDITLIMIT_Loan_Q4,0)) [DFT_MAX_CREDITLIMIT_Loan_Q1_Q4]
	   --,ISNULL(COUNT_DUEDAY1_CommercialLoan_Q1,0) [COUNT_DUEDAY1_CommercialLoan_Q1]
	   --,(ISNULL(COUNT_DUEDAY1_CommercialLoan_Q1,0) - ISNULL(COUNT_DUEDAY1_CommercialLoan_Q2,0)) [DFT_COUNT_DUEDAY1_CommercialLoan_Q1_Q2]
	   --,(ISNULL(COUNT_DUEDAY1_CommercialLoan_Q1,0) - ISNULL(COUNT_DUEDAY1_CommercialLoan_Q3,0)) [DFT_COUNT_DUEDAY1_CommercialLoan_Q1_Q3]
	   --,(ISNULL(COUNT_DUEDAY1_CommercialLoan_Q1,0) - ISNULL(COUNT_DUEDAY1_CommercialLoan_Q4,0)) [DFT_COUNT_DUEDAY1_CommercialLoan_Q1_Q4]
	   --,ISNULL(COUNT_DUEDAY1_RealEstate_Q1,0) [COUNT_DUEDAY1_RealEstate_Q1]
	   --,(ISNULL(COUNT_DUEDAY1_RealEstate_Q1,0) - ISNULL(COUNT_DUEDAY1_RealEstate_Q2,0)) [DFT_COUNT_DUEDAY1_RealEstate_Q1_Q2]
	   --,(ISNULL(COUNT_DUEDAY1_RealEstate_Q1,0) - ISNULL(COUNT_DUEDAY1_RealEstate_Q3,0)) [DFT_COUNT_DUEDAY1_RealEstate_Q1_Q3]
	   --,(ISNULL(COUNT_DUEDAY1_RealEstate_Q1,0) - ISNULL(COUNT_DUEDAY1_RealEstate_Q4,0)) [DFT_COUNT_DUEDAY1_RealEstate_Q1_Q4]
	   --,ISNULL(COUNT_DUEDAY1_RealEstate1_Q1,0) [COUNT_DUEDAY1_RealEstate1_Q1]
	   --,(ISNULL(COUNT_DUEDAY1_RealEstate1_Q1,0) - ISNULL(COUNT_DUEDAY1_RealEstate1_Q2,0)) [DFT_COUNT_DUEDAY1_RealEstate1_Q1_Q2]
	   --,(ISNULL(COUNT_DUEDAY1_RealEstate1_Q1,0) - ISNULL(COUNT_DUEDAY1_RealEstate1_Q3,0)) [DFT_COUNT_DUEDAY1_RealEstate1_Q1_Q3]
	   --,(ISNULL(COUNT_DUEDAY1_RealEstate1_Q1,0) - ISNULL(COUNT_DUEDAY1_RealEstate1_Q4,0)) [DFT_COUNT_DUEDAY1_RealEstate1_Q1_Q4]
	   --,ISNULL(COUNT_DUEDAY1_RealEstate2_Q1,0) [COUNT_DUEDAY1_RealEstate2_Q1]
	   --,(ISNULL(COUNT_DUEDAY1_RealEstate2_Q1,0) - ISNULL(COUNT_DUEDAY1_RealEstate2_Q2,0)) [DFT_COUNT_DUEDAY1_RealEstate2_Q1_Q2]
	   --,(ISNULL(COUNT_DUEDAY1_RealEstate2_Q1,0) - ISNULL(COUNT_DUEDAY1_RealEstate2_Q3,0)) [DFT_COUNT_DUEDAY1_RealEstate2_Q1_Q3]
	   --,(ISNULL(COUNT_DUEDAY1_RealEstate2_Q1,0) - ISNULL(COUNT_DUEDAY1_RealEstate2_Q4,0)) [DFT_COUNT_DUEDAY1_RealEstate2_Q1_Q4]
	   --,ISNULL(COUNT_DUEDAY1_SecuredLoan_Q1,0) [COUNT_DUEDAY1_SecuredLoan_Q1]
	   --,(ISNULL(COUNT_DUEDAY1_SecuredLoan_Q1,0) - ISNULL(COUNT_DUEDAY1_SecuredLoan_Q2,0)) [DFT_COUNT_DUEDAY1_SecuredLoan_Q1_Q2]
	   --,(ISNULL(COUNT_DUEDAY1_SecuredLoan_Q1,0) - ISNULL(COUNT_DUEDAY1_SecuredLoan_Q3,0)) [DFT_COUNT_DUEDAY1_SecuredLoan_Q1_Q3]
	   --,(ISNULL(COUNT_DUEDAY1_SecuredLoan_Q1,0) - ISNULL(COUNT_DUEDAY1_SecuredLoan_Q4,0)) [DFT_COUNT_DUEDAY1_SecuredLoan_Q1_Q4]
	   --,ISNULL(COUNT_DUEDAY1_UnsecuredLoan_Q1,0) [COUNT_DUEDAY1_UnsecuredLoan_Q1]
	   --,(ISNULL(COUNT_DUEDAY1_UnsecuredLoan_Q1,0) - ISNULL(COUNT_DUEDAY1_UnsecuredLoan_Q2,0)) [DFT_COUNT_DUEDAY1_UnsecuredLoan_Q1_Q2]
	   --,(ISNULL(COUNT_DUEDAY1_UnsecuredLoan_Q1,0) - ISNULL(COUNT_DUEDAY1_UnsecuredLoan_Q3,0)) [DFT_COUNT_DUEDAY1_UnsecuredLoan_Q1_Q3]
	   --,(ISNULL(COUNT_DUEDAY1_UnsecuredLoan_Q1,0) - ISNULL(COUNT_DUEDAY1_UnsecuredLoan_Q4,0)) [DFT_COUNT_DUEDAY1_UnsecuredLoan_Q1_Q4]
	   --,ISNULL(COUNT_DUEDAY1_VehicleLoan_Q1,0) [COUNT_DUEDAY1_VehicleLoan_Q1]
	   --,(ISNULL(COUNT_DUEDAY1_VehicleLoan_Q1,0) - ISNULL(COUNT_DUEDAY1_VehicleLoan_Q2,0)) [DFT_COUNT_DUEDAY1_VehicleLoan_Q1_Q2]
	   --,(ISNULL(COUNT_DUEDAY1_VehicleLoan_Q1,0) - ISNULL(COUNT_DUEDAY1_VehicleLoan_Q3,0)) [DFT_COUNT_DUEDAY1_VehicleLoan_Q1_Q3]
	   --,(ISNULL(COUNT_DUEDAY1_VehicleLoan_Q1,0) - ISNULL(COUNT_DUEDAY1_VehicleLoan_Q4,0)) [DFT_COUNT_DUEDAY1_VehicleLoan_Q1_Q4]
	   --,ISNULL(COUNT_DUEDAY1_Others_Q1,0) [COUNT_DUEDAY1_Others_Q1]
	   --,(ISNULL(COUNT_DUEDAY1_Others_Q1,0) - ISNULL(COUNT_DUEDAY1_Others_Q2,0)) [DFT_COUNT_DUEDAY1_Others_Q1_Q2]
	   --,(ISNULL(COUNT_DUEDAY1_Others_Q1,0) - ISNULL(COUNT_DUEDAY1_Others_Q3,0)) [DFT_COUNT_DUEDAY1_Others_Q1_Q3]
	   --,(ISNULL(COUNT_DUEDAY1_Others_Q1,0) - ISNULL(COUNT_DUEDAY1_Others_Q4,0)) [DFT_COUNT_DUEDAY1_Others_Q1_Q4]
       ,[CommercialLoan_Month_to_Maturity]
	   ,[RealEstate_Month_to_Maturity]
	   --,[RealEstateLoan1_Month_to_Maturity]
	   --,[RealEstateLoan2_Month_to_Maturity]
	   ,[SecuredLoan_Month_to_Maturity]
	   ,[UnsecuredLoan_Month_to_Maturity]
	   ,[Vehicleloan_Month_to_Maturity]
	   ,[Others_Month_to_Maturity] 	
	   ,Max_Loan_Month_to_Maturity
    --   ,[Delinquency_CommercialLoan_SP]
	   --,[Delinquency_RealEstate_SP]
	   --,[Delinquency_RealEstate1_SP]
	   --,[Delinquency_RealEstate2_SP]
	   --,[Delinquency_SecuredLoan_SP]
	   --,[Delinquency_UnsecuredLoan_SP]
	   --,[Delinquency_Vehicleloan_SP]
	   --,[Delinquency_Others_SP]
	   --,Delinquency_Loan_SP
	   ,CommercialLoan_OPENDATE
	   ,CommercialLoan_CLOSEDATE
	   ,RealEstate_OPENDATE
	   ,RealEstate_CLOSEDATE
	   ,SecuredLoan_OPENDATE
	   ,SecuredLoan_CLOSEDATE
	   ,UnsecuredLoan_OPENDATE
	   ,UnsecuredLoan_CLOSEDATE
	   ,Vehicleloan_OPENDATE
	   ,Vehicleloan_CLOSEDATE
	   ,Others_OPENDATE
	   ,Others_CLOSEDATE
	   ,Min_Loan_OPENDATE
	   ,Max_Loan_CLOSEDATE
into #loan_product_holdings
FROM
--#loan_woCC A
--LEFT JOIN
 (SELECT  SSN [SSN]
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_CommercialLoan_SP] 
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q1' THEN UNID END) as [#Products_CommercialLoan_Q1] 
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q2' THEN UNID END) as [#Products_CommercialLoan_Q2]
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q3' THEN UNID END) as [#Products_CommercialLoan_Q3]
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q4' THEN UNID END) as [#Products_CommercialLoan_Q4] 		 		 
		,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_RealEstate_SP] 
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q1' THEN UNID END) as  [#Products_RealEstate_Q1] 
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q2' THEN UNID END) as  [#Products_RealEstate_Q2]
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q3' THEN UNID END) as [#Products_RealEstate_Q3]
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q4' THEN UNID END) as [#Products_RealEstate_Q4]		
		--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_RealEstate1_SP] 
  --      ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q1' THEN UNID END) as  [#Products_RealEstate1_Q1] 
  --      ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q2' THEN UNID END) as  [#Products_RealEstate1_Q2]
  --      ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q3' THEN UNID END) as [#Products_RealEstate1_Q3]
  --      ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q4' THEN UNID END) as [#Products_RealEstate1_Q4]		 		 
		--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_RealEstate2_SP]
		--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q1' THEN UNID END) as [#Products_RealEstate2_Q1] 
		--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q2' THEN UNID END) as [#Products_RealEstate2_Q2]
		--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q3' THEN UNID END) as [#Products_RealEstate2_Q3]
		--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q4' THEN UNID END) as [#Products_RealEstate2_Q4] 		
		,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_SecuredLoan_SP]
		,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q1' THEN UNID END) as [#Products_SecuredLoan_Q1] 
		,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q2' THEN UNID END) as [#Products_SecuredLoan_Q2]
		,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q3' THEN UNID END) as [#Products_SecuredLoan_Q3]
		,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q4' THEN UNID END) as [#Products_SecuredLoan_Q4] 
		,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_UnsecuredLoan_SP]
		,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q1' THEN UNID END) as [#Products_UnsecuredLoan_Q1] 
		,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q2' THEN UNID END) as [#Products_UnsecuredLoan_Q2]
		,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q3' THEN UNID END) as [#Products_UnsecuredLoan_Q3]
		,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q4' THEN UNID END) as [#Products_UnsecuredLoan_Q4]
		,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_VehicleLoan_SP]
		,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q1' THEN UNID END) as [#Products_VehicleLoan_Q1]      
		,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q2' THEN UNID END) as [#Products_VehicleLoan_Q2]      
		,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q3' THEN UNID END) as [#Products_VehicleLoan_Q3]      
		,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q4' THEN UNID END) as [#Products_VehicleLoan_Q4]      
		,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_Others_SP]
		,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q1' THEN UNID END) as [#Products_Others_Q1]       
		,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q2' THEN UNID END) as [#Products_Others_Q2]       
		,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q3' THEN UNID END) as [#Products_Others_Q3]       
		,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q4' THEN UNID END) as [#Products_Others_Q4]     
		
		,COUNT(Distinct CASE WHEN Quarters = 'Staticpool' THEN UNID END) as [#Products_Loan_SP]
		,COUNT(Distinct CASE WHEN Quarters = 'Q1' THEN UNID END) as [#Products_Loan_Q1]       
		,COUNT(Distinct CASE WHEN Quarters = 'Q2' THEN UNID END) as [#Products_Loan_Q2]       
		,COUNT(Distinct CASE WHEN Quarters = 'Q3' THEN UNID END) as [#Products_Loan_Q3]       
		,COUNT(Distinct CASE WHEN Quarters = 'Q4' THEN UNID END) as [#Products_Loan_Q4]

		,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_CommercialLoan_SP] 
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q1' THEN [TYPE] END) as [#Type_CommercialLoan_Q1] 
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q2' THEN [TYPE] END) as [#Type_CommercialLoan_Q2]
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_CommercialLoan_Q3]
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_CommercialLoan_Q4] 		 		 
		,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_RealEstate_SP] 
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q1' THEN [TYPE] END) as  [#Type_RealEstate_Q1] 
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q2' THEN [TYPE] END) as  [#Type_RealEstate_Q2]
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_RealEstate_Q3]
        ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_RealEstate_Q4]			
		--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_RealEstate1_SP] 
        --,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q1' THEN [TYPE] END) as  [#Type_RealEstate1_Q1] 
        --,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q2' THEN [TYPE] END) as  [#Type_RealEstate1_Q2]
        --,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_RealEstate1_Q3]
        --,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan1' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_RealEstate1_Q4]		 		 
		--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_RealEstate2_SP]
		--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q1' THEN [TYPE] END) as [#Type_RealEstate2_Q1] 
		--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q2' THEN [TYPE] END) as [#Type_RealEstate2_Q2]
		--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_RealEstate2_Q3]
		--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan2' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_RealEstate2_Q4] 		
		,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_SecuredLoan_SP]
		,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q1' THEN [TYPE] END) as [#Type_SecuredLoan_Q1] 
		,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q2' THEN [TYPE] END) as [#Type_SecuredLoan_Q2]
		,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_SecuredLoan_Q3]
		,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_SecuredLoan_Q4] 
		,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_UnsecuredLoan_SP]
		,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q1' THEN [TYPE] END) as [#Type_UnsecuredLoan_Q1] 
		,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q2' THEN [TYPE] END) as [#Type_UnsecuredLoan_Q2]
		,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_UnsecuredLoan_Q3]
		,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_UnsecuredLoan_Q4]
		,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_VehicleLoan_SP]
		,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q1' THEN [TYPE] END) as [#Type_VehicleLoan_Q1]      
		,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q2' THEN [TYPE] END) as [#Type_VehicleLoan_Q2]      
		,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_VehicleLoan_Q3]      
		,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_VehicleLoan_Q4]      
		,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_Others_SP]
		,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q1' THEN [TYPE] END) as [#Type_Others_Q1]       
		,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q2' THEN [TYPE] END) as [#Type_Others_Q2]       
		,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q3' THEN [TYPE] END) as [#Type_Others_Q3]       
		,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q4' THEN [TYPE] END) as [#Type_Others_Q4]

	    ,COUNT(Distinct CASE WHEN Quarters = 'Staticpool' THEN [TYPE] END) as [#Type_Loan_SP]
		,COUNT(Distinct CASE WHEN Quarters = 'Q1' THEN [TYPE] END) as [#Type_Loan_Q1]       
		,COUNT(Distinct CASE WHEN Quarters = 'Q2' THEN [TYPE] END) as [#Type_Loan_Q2]       
		,COUNT(Distinct CASE WHEN Quarters = 'Q3' THEN [TYPE] END) as [#Type_Loan_Q3]       
		,COUNT(Distinct CASE WHEN Quarters = 'Q4' THEN [TYPE] END) as [#Type_Loan_Q4]

		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' THEN MOB END) [CommercialLoan_MOB]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' THEN MOB END) [RealEstate_MOB]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' THEN MOB END) [RealEstate1_MOB]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' THEN MOB END) [RealEstate2_MOB]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' THEN MOB END) [SecuredLoan_MOB]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' THEN MOB END) [UnsecuredLoan_MOB]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' THEN MOB END) [Vehicleloan_MOB]
		,MAX(CASE WHEN Product_Flag = 'Others' THEN MOB END) [Others_MOB] 
		,MAX(MOB) [MAX_Loan_MOB]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_CommercialLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_CommercialLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_CommercialLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_CommercialLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate_Q1]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate_Q2]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate_Q3]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate_Q4]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate1_Q1]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate1_Q2]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate1_Q3]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate1_Q4]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate2_Q1]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate2_Q2]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate2_Q3]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate2_Q4]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_SecuredLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_SecuredLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_SecuredLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_SecuredLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_UnsecuredLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_UnsecuredLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_UnsecuredLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_UnsecuredLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Vehicleloan_Q1]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Vehicleloan_Q2]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Vehicleloan_Q3]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Vehicleloan_Q4]	
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Others_Q1]
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Others_Q2]
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Others_Q3]
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Others_Q4]

		,MAX(CASE WHEN Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Loan_Q1]
		,MAX(CASE WHEN Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Loan_Q2]
		,MAX(CASE WHEN Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Loan_Q3]
		,MAX(CASE WHEN Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Loan_Q4]

		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_CommercialLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_CommercialLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_CommercialLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_CommercialLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate_Q1]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate_Q2]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate_Q3]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate_Q4]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate1_Q1]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate1_Q2]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate1_Q3]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate1_Q4]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate2_Q1]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate2_Q2]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate2_Q3]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_RealEstate2_Q4]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_SecuredLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_SecuredLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_SecuredLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_SecuredLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_UnsecuredLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_UnsecuredLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_UnsecuredLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_UnsecuredLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Vehicleloan_Q1]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Vehicleloan_Q2]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Vehicleloan_Q3]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Vehicleloan_Q4]
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Others_Q1]	
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Others_Q2]	
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Others_Q3]	
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Others_Q4]

		,MAX(CASE WHEN Quarters = 'Q1' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Loan_Q1]	
		,MAX(CASE WHEN Quarters = 'Q2' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Loan_Q2]	
		,MAX(CASE WHEN Quarters = 'Q3' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Loan_Q3]	
		,MAX(CASE WHEN Quarters = 'Q4' THEN ORIGINALBALANCE END) [MAX_OriginalBalance_Loan_Q4]

		,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_CommercialLoan_Q1]
		,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_CommercialLoan_Q2]
		,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_CommercialLoan_Q3]
		,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_CommercialLoan_Q4]
		,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate_Q1]
		,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate_Q2]
		,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate_Q3]
		,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate_Q4]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate1_Q1]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate1_Q2]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate1_Q3]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate1_Q4]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate2_Q1]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate2_Q2]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate2_Q3]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate2_Q4]
		,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_SecuredLoan_Q1]
		,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_SecuredLoan_Q2]
		,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_SecuredLoan_Q3]
		,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_SecuredLoan_Q4]
		,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_UnsecuredLoan_Q1]
		,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_UnsecuredLoan_Q2]
		,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_UnsecuredLoan_Q3]
		,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_UnsecuredLoan_Q4]
		,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Vehicleloan_Q1]
		,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Vehicleloan_Q2]
		,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Vehicleloan_Q3]
		,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Vehicleloan_Q4]
		,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Others_Q1]	
		,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Others_Q2]	
		,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Others_Q3]	
		,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Others_Q4]
		,SUM(CASE WHEN Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Loan_Q1]	
		,SUM(CASE WHEN Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Loan_Q2]	
		,SUM(CASE WHEN Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Loan_Q3]	
		,SUM(CASE WHEN Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Loan_Q4]
			
		,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_CommercialLoan_Q1]
		,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_CommercialLoan_Q2]
		,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_CommercialLoan_Q3]
		,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_CommercialLoan_Q4]
		,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_RealEstate_Q1]
		,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_RealEstate_Q2]
		,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_RealEstate_Q3]
		,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_RealEstate_Q4]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_RealEstate1_Q1]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_RealEstate1_Q2]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_RealEstate1_Q3]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_RealEstate1_Q4]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_RealEstate2_Q1]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_RealEstate2_Q2]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_RealEstate2_Q3]
		--,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_RealEstate2_Q4]
		,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_SecuredLoan_Q1]
		,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_SecuredLoan_Q2]
		,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_SecuredLoan_Q3]
		,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_SecuredLoan_Q4]
		,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_UnsecuredLoan_Q1]
		,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_UnsecuredLoan_Q2]
		,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_UnsecuredLoan_Q3]
		,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_UnsecuredLoan_Q4]
		,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_Vehicleloan_Q1]
		,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_Vehicleloan_Q2]
		,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_Vehicleloan_Q3]
		,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_Vehicleloan_Q4]
		,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_Others_Q1]	
		,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_Others_Q2]	
		,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_Others_Q3]	
		,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_Others_Q4]

		,SUM(CASE WHEN Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_Loan_Q1]	
		,SUM(CASE WHEN Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_Loan_Q2]	
		,SUM(CASE WHEN Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_Loan_Q3]	
		,SUM(CASE WHEN Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_Loan_Q4]

		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_CommercialLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_CommercialLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_CommercialLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_CommercialLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate_Q1]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate_Q2]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate_Q3]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate_Q4]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate1_Q1]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate1_Q2]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate1_Q3]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate1_Q4]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate2_Q1]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate2_Q2]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate2_Q3]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate2_Q4]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_SecuredLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_SecuredLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_SecuredLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_SecuredLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_UnsecuredLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_UnsecuredLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_UnsecuredLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_UnsecuredLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_Vehicleloan_Q1]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_Vehicleloan_Q2]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_Vehicleloan_Q3]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_Vehicleloan_Q4]
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_Others_Q1]	
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_Others_Q2]	
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_Others_Q3]	
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_Others_Q4]

		,MAX(CASE WHEN Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_Q1]	
		,MAX(CASE WHEN Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_Q2]	
		,MAX(CASE WHEN Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_Q3]	
		,MAX(CASE WHEN Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_Q4]

		--,CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q1' THEN (SELECT min(OPENDATE) FROM #membership_loan) ELSE NULL END [Total_CommercialLoan_Q4] 		 		 
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_CommercialLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_CommercialLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_CommercialLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_CommercialLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate_Q1]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate_Q2]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate_Q3]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate_Q4]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate1_Q1]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate1_Q2]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate1_Q3]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate1_Q4]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate2_Q1]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate2_Q2]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate2_Q3]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate2_Q4]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_SecuredLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_SecuredLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_SecuredLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_SecuredLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_UnsecuredLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_UnsecuredLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_UnsecuredLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_UnsecuredLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Vehicleloan_Q1]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Vehicleloan_Q2]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Vehicleloan_Q3]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Vehicleloan_Q4]
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Others_Q1]	
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Others_Q2]	
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Others_Q3]	
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Others_Q4]	
		
		,MAX(CASE WHEN Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Loan_Q1]	
		,MAX(CASE WHEN Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Loan_Q2]	
		,MAX(CASE WHEN Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Loan_Q3]	
		,MAX(CASE WHEN Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Loan_Q4]	

		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_CommercialLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_CommercialLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_CommercialLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_CommercialLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate_Q1]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate_Q2]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate_Q3]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate_Q4]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate1_Q1]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate1_Q2]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate1_Q3]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate1_Q4]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate2_Q1]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate2_Q2]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate2_Q3]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate2_Q4]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_SecuredLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_SecuredLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_SecuredLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_SecuredLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_UnsecuredLoan_Q1]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_UnsecuredLoan_Q2]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_UnsecuredLoan_Q3]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_UnsecuredLoan_Q4]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_Vehicleloan_Q1]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_Vehicleloan_Q2]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_Vehicleloan_Q3]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_Vehicleloan_Q4]
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_Others_Q1]	
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_Others_Q2]	
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_Others_Q3]	
		,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_Others_Q4]
		
		,MAX(CASE WHEN Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_Loan_Q1]	
		,MAX(CASE WHEN Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_Loan_Q2]	
		,MAX(CASE WHEN Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_Loan_Q3]	
		,MAX(CASE WHEN Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_Loan_Q4]
		
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' THEN Month_to_Maturity END) [CommercialLoan_Month_to_Maturity]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' THEN Month_to_Maturity END) [RealEstate_Month_to_Maturity]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' THEN Month_to_Maturity END) [RealEstateLoan1_Month_to_Maturity]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' THEN Month_to_Maturity END) [RealEstateLoan2_Month_to_Maturity]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' THEN Month_to_Maturity END) [SecuredLoan_Month_to_Maturity]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' THEN Month_to_Maturity END) [UnsecuredLoan_Month_to_Maturity]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' THEN Month_to_Maturity END) [Vehicleloan_Month_to_Maturity]
		,MAX(CASE WHEN Product_Flag = 'Others' THEN Month_to_Maturity END) [Others_Month_to_Maturity] 	
		,MAX(Month_to_Maturity) [Max_Loan_Month_to_Maturity]

		,MIN(CASE WHEN Product_Flag = 'Commercial_loan' THEN OPENDATE END) [CommercialLoan_OPENDATE]
		,MIN(CASE WHEN Product_Flag = 'Real_Estate_loan' THEN OPENDATE END) [RealEstate_OPENDATE]
		--,MIN(CASE WHEN Product_Flag = 'Real_Estate_loan1' THEN OPENDATE END) [RealEstateLoan1_OPENDATE]
		--,MIN(CASE WHEN Product_Flag = 'Real_Estate_loan2' THEN OPENDATE END) [RealEstateLoan2_OPENDATE]
		,MIN(CASE WHEN Product_Flag = 'SecuredLoan' THEN OPENDATE END) [SecuredLoan_OPENDATE]
		,MIN(CASE WHEN Product_Flag = 'UnsecuredLoan' THEN OPENDATE END) [UnsecuredLoan_OPENDATE]
		,MIN(CASE WHEN Product_Flag = 'Vehicleloan' THEN OPENDATE END) [Vehicleloan_OPENDATE]
		,MIN(CASE WHEN Product_Flag = 'Others' THEN OPENDATE END) [Others_OPENDATE] 
		,MIN(OPENDATE) [Min_Loan_OPENDATE] 

		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' THEN CLOSEDATE END) [CommercialLoan_CLOSEDATE]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' THEN CLOSEDATE END) [RealEstate_CLOSEDATE]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' THEN CLOSEDATE END) [RealEstate1_CLOSEDATE]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' THEN CLOSEDATE END) [RealEstate2_CLOSEDATE]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' THEN CLOSEDATE END) [SecuredLoan_CLOSEDATE]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' THEN CLOSEDATE END) [UnsecuredLoan_CLOSEDATE]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' THEN CLOSEDATE END) [Vehicleloan_CLOSEDATE]
		,MAX(CASE WHEN Product_Flag = 'Others' THEN CLOSEDATE END) [Others_CLOSEDATE]
		,MAX(CLOSEDATE) [Max_Loan_CLOSEDATE]
		,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_CommercialLoan_SP]
		,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_RealEstate_SP]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan1' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_RealEstate1_SP]
		--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan2' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_RealEstate2_SP]
		,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_SecuredLoan_SP]
		,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_UnsecuredLoan_SP]
		,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_Vehicleloan_SP]
		,MAX(CASE WHEN Product_Flag = 'Others'and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_Others_SP]
		,MAX(CASE WHEN Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_Loan_SP]			
					--,count(distinct UNID) Count_of_product_commercial_loan
			--,count(distinct TYPE) count_of_type_commercial_loan
			----,max(Staticpool_Commercial_loan_flag) Staticpool_Commercial_loan_flag
			--,min(OPENDATE) min_OPENDATE_commercial_loan,max(CLOSEDATE) max_CLOSEDATE_commercial_loan
			--,Max(MOB) Max_MOB_commercial_loan
			--,max(Month_to_Maturity) Month_to_Maturity_commercial_loan
			--,max(PAYMENTCOUNT) Max_paymentcount_commercial_loan
			--,max(DUEDAY1) max_Dueday1_commercial_loan
			--,max(ORIGINALBALANCE) max_ORIGINALBALANCE_commercial_loan
			--,max(INTERESTRATE) INTERESTRATE_commercial_loan
			--,max(CREDITLIMIT) max_CREDITLIMIT_commercial_loan
			--,sum(PAYMENT) Sum_PAYMENT_commercial_loan
			--,sum(ORIGINALBALANCE) Sum_ORIGINALBALANCE_commercial_loan
			--,max(CRPMTCURRENT) Max_delinquenty_commercial_loan
			 
			 from #membership_loan
			group by SSN ) B

			--ON A.SSN = B.SSN

			--group by SSN,Quarters,Product_Flag ) B
			--SELECT TOP 1000 * FROM #loan_product_holdings

			--SELECT TOP 1000 CRPMTCURRENT FROM ARCUSYM000..LOAN


-- DISTINCT UNID FROM #membership_loan			

     DROP TABLE IF EXISTS #static_unid
     SELECT DISTINCT UNID,PARENTACCOUNT,Product_Flag into #static_unid FROM #membership_loan

------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Loan Transaction Master Data ***\\\-------------------------------------------------------------------


			 DROP TABLE IF EXISTS #temp_loan_transaction
			 SELECT bb.*,Product_Flag 
			 into #temp_loan_transaction
			from 
			(

			select unid,PARENTACCOUNT
			,case when EFFECTIVEDATE_v1 in ((left(convert(varchar,dateadd(month,-10,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-11,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6))) then 'Q4'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,dateadd(month,-7,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-8,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-9,@staticpooldate),112),6))) then 'Q3'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,dateadd(month,-4,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-5,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-6,@staticpooldate),112),6))) then 'Q2'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,dateadd(month,-3,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-2,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-1,@staticpooldate),112),6))) then 'Q1'
		    when EFFECTIVEDATE_v1 in (left(convert(varchar,@staticpooldate,112),6)) then 'Staticpool' end Quarters
			,EFFECTIVEDATE_v1
			,ACTIONCODE,SOURCECODE
			,case when ACTIONCODE='A' then 1 else 0 end Loan_addon
			,case when ACTIONCODE='N' then 1 else 0 end New_loan
			,case when ACTIONCODE='N' then 1 else 0 end loan_payment
			,case when SOURCECODE='C' then 1 else 0 end CASH
			,case when SOURCECODE='D' then 1 else 0 end DRAFT
			,case when SOURCECODE='E' then 1 else 0 end ACH
			,case when SOURCECODE='F' then 1 else 0 end FEE
			,case when SOURCECODE='H' then 1 else 0 end HOMEBANKING
			,case when SOURCECODE='I' then 1 else 0 end INSURANCE
			,case when SOURCECODE='K' then 1 else 0 end CHECKS
			,case when SOURCECODE='P' then 1 else 0 end PAYROLL
			,case when SOURCECODE='S' then 1 else 0 end KIOSK
			,case when SOURCECODE='T' then 1 else 0 end  AUDIO_RESPONSE_TELEPHONE
			,CASE WHEN ACTIONCODE='A' AND SOURCECODE='C' THEN 'LOANADDON_CASH'
			WHEN ACTIONCODE='A' AND SOURCECODE='F' THEN 'LOANADDON_FEE'
			WHEN ACTIONCODE='A' AND SOURCECODE='H' THEN 'LOANADDON_HOMEBANKING'
			WHEN ACTIONCODE='A' AND SOURCECODE='I' THEN 'LOANADDON_INSURANCE'
			WHEN ACTIONCODE='A' AND SOURCECODE='K' THEN 'LOANADDON_CHECK'
			WHEN ACTIONCODE='A' AND SOURCECODE='T' THEN 'LOANADDON_RESPONSE_TELEPHONE'
			WHEN ACTIONCODE='A' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'LOANADDON'
			WHEN ACTIONCODE='N' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'NEWLOAN'
			WHEN ACTIONCODE='N' AND SOURCECODE='K' THEN 'NEWLOAN_CHECKS'
			WHEN ACTIONCODE='N' AND SOURCECODE='S' THEN 'NEWLOAN_KIOSK'
			WHEN ACTIONCODE='P' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'LOANPAYMENT'
			
			WHEN ACTIONCODE='P' AND SOURCECODE='C' THEN 'LOANPAYMENT_CASH'
			WHEN ACTIONCODE='P' AND SOURCECODE='D' THEN 'LOANPAYMENT_DRAFT'
			WHEN ACTIONCODE='P' AND SOURCECODE='E' THEN 'LOANPAYMENT_ACH'
			WHEN ACTIONCODE='P' AND SOURCECODE='H' THEN 'LOANPAYMENT_HOMEBANKING'
			WHEN ACTIONCODE='P' AND SOURCECODE='K' THEN 'LOANPAYMENT_CHECKS'
			WHEN ACTIONCODE='P' AND SOURCECODE='P' THEN 'LOANPAYMENT_PAYROLL'
			WHEN ACTIONCODE='P' AND SOURCECODE='S' THEN 'LOANPAYMENT_KIOSK'
			WHEN ACTIONCODE='P' AND SOURCECODE='T' THEN  'LOANPAYMENT_RESPONSE_TELEPHONE' end action_source_code
			,BALANCECHANGE Transaction_amount,NEWBALANCE
			,INTEREST Interest_amount, FEEAMOUNT
			from	(

					select CONCAT(PARENTACCOUNT,PARENTID) UNID
					,PARENTACCOUNT,PARENTID
					,TRANSFERCODE
					,case when len(month(effectivedate))=1 then CONCAT(year(effectivedate),0,month(effectivedate))
					else CONCAT(year(effectivedate),month(effectivedate)) end EFFECTIVEDATE_v1
					,cast(EFFECTIVEDATE as date) EFFECTIVEDATE ,POSTDATE
					,ACTIONCODE,SOURCECODE,BALANCECHANGE,NEWBALANCE,INTEREST,FEEAMOUNT
					from [ARCUSYM000].dbo.LOANTRANSACTION
					where
					ACTIONCODE in ('A','N','P') AND SOURCECODE in ('C','D','E','F','H','I','K','P','S','T')
					 and ACTIONCODE !='C' 
					  ) AA --where parentaccount=0014465465
			 )bb
			   left join #static_unid W
					  on bb.UNID = W.UNID
			 where bb.Quarters is not null 
			 and bb.EFFECTIVEDATE_v1 between (Cast((left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6)) as int)) 
			 and cast((left(convert(varchar,@staticpooldate,112),6)) as int)
			
			 --group by PARENTACCOUNT
			 --,UNID
			 --,Quarters,action_source_code

 drop table if exists #transaction_loan

			 SELECT  *
			 INTO #transaction_loan
			 from
			 ((
			 SELECT
			PARENTACCOUNT
			--,UNID
			--,Quarters
			--,action_source_code
			,sum(CASE WHEN Quarters = 'Staticpool' then Loan_addon END) COUNT_LOAN_ADDON_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then Loan_addon END) COUNT_LOAN_ADDON_Q1
			,sum(CASE WHEN Quarters = 'Q2' then Loan_addon END) COUNT_LOAN_ADDON_Q2
			,sum(CASE WHEN Quarters = 'Q3' then Loan_addon END) COUNT_LOAN_ADDON_Q3
			,sum(CASE WHEN Quarters = 'Q4' then Loan_addon END) COUNT_LOAN_ADDON_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then New_loan END) COUNT_NEW_LOAN_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then New_loan END) COUNT_NEW_LOAN_Q1
			,sum(CASE WHEN Quarters = 'Q2' then New_loan END) COUNT_NEW_LOAN_Q2
			,sum(CASE WHEN Quarters = 'Q3' then New_loan END) COUNT_NEW_LOAN_Q3
			,sum(CASE WHEN Quarters = 'Q4' then New_loan END) COUNT_NEW_LOAN_Q4	
			,sum(CASE WHEN Quarters = 'Staticpool' then loan_payment END) COUNT_LOAN_PAYMENT_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then loan_payment END) COUNT_LOAN_PAYMENT_Q1
			,sum(CASE WHEN Quarters = 'Q2' then loan_payment END) COUNT_LOAN_PAYMENT_Q2
			,sum(CASE WHEN Quarters = 'Q3' then loan_payment END) COUNT_LOAN_PAYMENT_Q3
			,sum(CASE WHEN Quarters = 'Q4' then loan_payment END) COUNT_LOAN_PAYMENT_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then CASH END) COUNT_CASH_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then CASH END) COUNT_CASH_Q1
			,sum(CASE WHEN Quarters = 'Q2' then CASH END) COUNT_CASH_Q2
			,sum(CASE WHEN Quarters = 'Q3' then CASH END) COUNT_CASH_Q3
			,sum(CASE WHEN Quarters = 'Q4' then CASH END) COUNT_CASH_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then DRAFT END) COUNT_DRAFT_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then DRAFT END) COUNT_DRAFT_Q1
			,sum(CASE WHEN Quarters = 'Q2' then DRAFT END) COUNT_DRAFT_Q2
			,sum(CASE WHEN Quarters = 'Q3' then DRAFT END) COUNT_DRAFT_Q3
			,sum(CASE WHEN Quarters = 'Q4' then DRAFT END) COUNT_DRAFT_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then ACH END) COUNT_ACH_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then ACH END) COUNT_ACH_Q1
			,sum(CASE WHEN Quarters = 'Q2' then ACH END) COUNT_ACH_Q2
			,sum(CASE WHEN Quarters = 'Q3' then ACH END) COUNT_ACH_Q3
			,sum(CASE WHEN Quarters = 'Q4' then ACH END) COUNT_ACH_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then FEE END) COUNT_FEE_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then FEE END) COUNT_FEE_Q1
			,sum(CASE WHEN Quarters = 'Q2' then FEE END) COUNT_FEE_Q2
			,sum(CASE WHEN Quarters = 'Q3' then FEE END) COUNT_FEE_Q3
			,sum(CASE WHEN Quarters = 'Q4' then FEE END) COUNT_FEE_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then HOMEBANKING END) COUNT_HOMEBANKING_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then HOMEBANKING END) COUNT_HOMEBANKING_Q1
			,sum(CASE WHEN Quarters = 'Q2' then HOMEBANKING END) COUNT_HOMEBANKING_Q2
			,sum(CASE WHEN Quarters = 'Q3' then HOMEBANKING END) COUNT_HOMEBANKING_Q3
			,sum(CASE WHEN Quarters = 'Q4' then HOMEBANKING END) COUNT_HOMEBANKING_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then INSURANCE END) COUNT_INSURANCE_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then INSURANCE END) COUNT_INSURANCE_Q1
			,sum(CASE WHEN Quarters = 'Q2' then INSURANCE END) COUNT_INSURANCE_Q2
			,sum(CASE WHEN Quarters = 'Q3' then INSURANCE END) COUNT_INSURANCE_Q3
			,sum(CASE WHEN Quarters = 'Q4' then INSURANCE END) COUNT_INSURANCE_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then CHECKS END) COUNT_CHECKS_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then CHECKS END) COUNT_CHECKS_Q1
			,sum(CASE WHEN Quarters = 'Q2' then CHECKS END) COUNT_CHECKS_Q2
			,sum(CASE WHEN Quarters = 'Q3' then CHECKS END) COUNT_CHECKS_Q3
			,sum(CASE WHEN Quarters = 'Q4' then CHECKS END) COUNT_CHECKS_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then PAYROLL END) COUNT_PAYROLL_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then PAYROLL END) COUNT_PAYROLL_Q1
			,sum(CASE WHEN Quarters = 'Q2' then PAYROLL END) COUNT_PAYROLL_Q2
			,sum(CASE WHEN Quarters = 'Q3' then PAYROLL END) COUNT_PAYROLL_Q3
			,sum(CASE WHEN Quarters = 'Q4' then PAYROLL END) COUNT_PAYROLL_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then KIOSK END) COUNT_KIOSK_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then KIOSK END) COUNT_KIOSK_Q1
			,sum(CASE WHEN Quarters = 'Q2' then KIOSK END) COUNT_KIOSK_Q2
			,sum(CASE WHEN Quarters = 'Q3' then KIOSK END) COUNT_KIOSK_Q3
			,sum(CASE WHEN Quarters = 'Q4' then KIOSK END) COUNT_KIOSK_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Q1
			,sum(CASE WHEN Quarters = 'Q2' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Q2
			,sum(CASE WHEN Quarters = 'Q3' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Q3
			,sum(CASE WHEN Quarters = 'Q4' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Q4
			--,sum(CASE WHEN Quarters = 'Staticpool' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_STATICPOOL
			--,sum(CASE WHEN Quarters = 'Q1' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Q1
			--,sum(CASE WHEN Quarters = 'Q2' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Q2
			--,sum(CASE WHEN Quarters = 'Q3' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Q3
			--,sum(CASE WHEN Quarters = 'Q4' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Q4
			--,sum(CASE WHEN Quarters = 'Staticpool' then Interest_amount END) INTEREST_AMOUNT_STATICPOOL
			--,sum(CASE WHEN Quarters = 'Q1' then Interest_amount END) INTEREST_AMOUNT_Q1
			--,sum(CASE WHEN Quarters = 'Q2' then Interest_amount END) INTEREST_AMOUNT_Q2
			--,sum(CASE WHEN Quarters = 'Q3' then Interest_amount END) INTEREST_AMOUNT_Q3
			--,sum(CASE WHEN Quarters = 'Q4' then Interest_amount END) INTEREST_AMOUNT_Q4
			--,sum(CASE WHEN Quarters = 'Staticpool' then FEEAMOUNT END) FEEAMOUNT_STATICPOOL
			--,sum(CASE WHEN Quarters = 'Q1' then FEEAMOUNT END) FEEAMOUNT_Q1
			--,sum(CASE WHEN Quarters = 'Q2' then FEEAMOUNT END) FEEAMOUNT_Q2
			--,sum(CASE WHEN Quarters = 'Q3' then FEEAMOUNT END) FEEAMOUNT_Q3
			--,sum(CASE WHEN Quarters = 'Q4' then FEEAMOUNT END) FEEAMOUNT_Q4
			--,AVG(CASE WHEN Quarters = 'Staticpool' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_STATICPOOL
			--,AVG(CASE WHEN Quarters = 'Q1' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Q1
			--,AVG(CASE WHEN Quarters = 'Q2' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Q2
			--,AVG(CASE WHEN Quarters = 'Q3' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Q3
			--,AVG(CASE WHEN Quarters = 'Q4' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Q4
			--,AVG(CASE WHEN Quarters = 'Staticpool' then NEWBALANCE END) AVG_NEWBALANCE_STATICPOOL
			--,AVG(CASE WHEN Quarters = 'Q1' then NEWBALANCE END) AVG_NEWBALANCE_Q1
			--,AVG(CASE WHEN Quarters = 'Q2' then NEWBALANCE END) AVG_NEWBALANCE_Q2
			--,AVG(CASE WHEN Quarters = 'Q3' then NEWBALANCE END) AVG_NEWBALANCE_Q3
			--,AVG(CASE WHEN Quarters = 'Q4' then NEWBALANCE END) AVG_NEWBALANCE_Q4
			--,AVG(CASE WHEN Quarters = 'Staticpool' then Interest_amount END) AVG_INTEREST_AMOUNT_STATICPOOL
			--,AVG(CASE WHEN Quarters = 'Q1' then Interest_amount END) AVG_INTEREST_AMOUNT_Q1
			--,AVG(CASE WHEN Quarters = 'Q2' then Interest_amount END) AVG_INTEREST_AMOUNT_Q2
			--,AVG(CASE WHEN Quarters = 'Q3' then Interest_amount END) AVG_INTEREST_AMOUNT_Q3
			--,AVG(CASE WHEN Quarters = 'Q4' then Interest_amount END) AVG_INTEREST_AMOUNT_Q4
			--,AVG(CASE WHEN Quarters = 'Staticpool' then FEEAMOUNT END) AVG_FEEAMOUNT_STATICPOOL
			--,AVG(CASE WHEN Quarters = 'Q1' then FEEAMOUNT END) AVG_FEEAMOUNT_Q1
			--,AVG(CASE WHEN Quarters = 'Q2' then FEEAMOUNT END) AVG_FEEAMOUNT_Q2
			--,AVG(CASE WHEN Quarters = 'Q3' then FEEAMOUNT END) AVG_FEEAMOUNT_Q3
			--,AVG(CASE WHEN Quarters = 'Q4' then FEEAMOUNT END) AVG_FEEAMOUNT_Q4

			--,sum(Loan_addon) Sum_count_loan_addon		
			--,sum(New_loan) Sum_count_New_loan
			--,sum(loan_payment) Sum_count_loan_payment
			--,sum(CASH) Sum_count_CASH
			--,sum(DRAFT) Sum_count_DRAFT
			--,sum(ACH) Sum_count_ACH
			--,sum(FEE) Sum_count_FEE
			--,sum(HOMEBANKING) Sum_count_HOMEBANKING
			--,sum(INSURANCE) Sum_count_INSURANCE
			--,sum(CHECKS) Sum_count_CHECKS
			--,sum(PAYROLL) Sum_count_PAYROLL
			--,sum(KIOSK) Sum_count_KIOSK
			--,sum(AUDIO_RESPONSE_TELEPHONE) Sum_count_AUDIO_RESPONSE_TELEPHONE
			--,avg(Transaction_amount) Avg_Transaction_amount
			--,avg(NEWBALANCE) Avg_NEWBALANCE
			--,avg(Interest_amount) avg_Interest_amount
			--,avg(FEEAMOUNT) avg_FEEAMOUNT
			--,sum(Transaction_amount) sum_Transaction_amount
			--,sum(Interest_amount) sum_Interest_amount
			--,sum(FEEAMOUNT) Sum_FEEAMOUNT
			 
			 from #temp_loan_transaction
			 group by PARENTACCOUNT) A
			 left join 
			 ( SELECT PARENTACCOUNT [PARENTACCOUNT00]
            ,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_Q4	
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCECommercialLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCE_CommercialLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCE_CommercialLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCE_CommercialLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCE_CommercialLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_Q4

,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_Q4	
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_Q4	
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_Q4	
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_VehicleLoan_Q4	
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_VehicleLoan_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_VehicleLoan_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_VehicleLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_VehicleLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_VehicleLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_VehicleLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_VehicleLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_VehicleLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_VehicleLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_VehicleLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_VehicleLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_VehicleLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_VehicleLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_VehicleLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_VehicleLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_VehicleLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_VehicleLoan_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_VehicleLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_VehicleLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_VehicleLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_VehicleLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_VehicleLoan_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_Q4	
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q4

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_Q4
			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_Q4
			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_Q4
			 FROM #temp_loan_transaction
			 group by PARENTACCOUNT
			 ) B
			 on A.PARENTACCOUNT = B.[PARENTACCOUNT00] )


--- Drift of the Loan Transaction data

			 DROP TABLE IF EXISTS #LOAN_TRANSACTION_derived_vars
			 SELECT PARENTACCOUNT
			        --,UNID
			        ,COUNT_LOAN_ADDON_STATICPOOL
			        ,COUNT_LOAN_ADDON_Q1
					,(ISNULL(COUNT_LOAN_ADDON_Q1,0)-ISNULL(COUNT_LOAN_ADDON_Q2,0)) DFT_COUNT_LOAN_ADDON_Q1_Q2
					,(ISNULL(COUNT_LOAN_ADDON_Q1,0)-ISNULL(COUNT_LOAN_ADDON_Q3,0)) DFT_COUNT_LOAN_ADDON_Q1_Q3
					--,(ISNULL(COUNT_LOAN_ADDON_Q1,0)-ISNULL(COUNT_LOAN_ADDON_Q4,0)) DFT_COUNT_LOAN_ADDON_Q1_Q4
					,COUNT_NEW_LOAN_STATICPOOL
					,COUNT_NEW_LOAN_Q1
					,(ISNULL(COUNT_NEW_LOAN_Q1,0)-ISNULL(COUNT_NEW_LOAN_Q2,0)) DFT_COUNT_NEW_LOAN_Q1_Q2
					,(ISNULL(COUNT_NEW_LOAN_Q1,0)-ISNULL(COUNT_NEW_LOAN_Q3,0)) DFT_COUNT_NEW_LOAN_Q1_Q3
					--,(ISNULL(COUNT_NEW_LOAN_Q1,0)-ISNULL(COUNT_NEW_LOAN_Q4,0)) DFT_COUNT_NEW_LOAN_Q1_Q4
					,COUNT_LOAN_PAYMENT_STATICPOOL
					,COUNT_LOAN_PAYMENT_Q1
					,(ISNULL(COUNT_LOAN_PAYMENT_Q1,0) - (ISNULL(COUNT_LOAN_PAYMENT_Q2,0))) DFT_COUNT_LOAN_PAYMENT_Q1_Q2
					,(ISNULL(COUNT_LOAN_PAYMENT_Q1,0) - (ISNULL(COUNT_LOAN_PAYMENT_Q3,0))) DFT_COUNT_LOAN_PAYMENT_Q1_Q3
					--,(ISNULL(COUNT_LOAN_PAYMENT_Q1,0) - (ISNULL(COUNT_LOAN_PAYMENT_Q4,0))) DFT_COUNT_LOAN_PAYMENT_Q1_Q4
					,COUNT_CASH_STATICPOOL
					,COUNT_CASH_Q1
					,(ISNULL(COUNT_CASH_Q1,0) - ISNULL(COUNT_CASH_Q2,0)) DFT_COUNT_CASH_Q1_Q2
					,(ISNULL(COUNT_CASH_Q1,0) - ISNULL(COUNT_CASH_Q3,0)) DFT_COUNT_CASH_Q1_Q3
					--,(ISNULL(COUNT_CASH_Q1,0) - ISNULL(COUNT_CASH_Q4,0)) DFT_COUNT_CASH_Q1_Q4
					,COUNT_DRAFT_STATICPOOL
					,COUNT_DRAFT_Q1
					,(ISNULL(COUNT_DRAFT_Q1,0)-ISNULL(COUNT_DRAFT_Q2,0)) DFT_COUNT_DRAFT_Q1_Q2
					,(ISNULL(COUNT_DRAFT_Q1,0)-ISNULL(COUNT_DRAFT_Q3,0)) DFT_COUNT_DRAFT_Q1_Q3
					--,(ISNULL(COUNT_DRAFT_Q1,0)-ISNULL(COUNT_DRAFT_Q4,0)) DFT_COUNT_DRAFT_Q1_Q4
					,COUNT_ACH_STATICPOOL
					,COUNT_ACH_Q1
					,(ISNULL(COUNT_ACH_Q1,0)-ISNULL(COUNT_ACH_Q2,0)) DFT_COUNT_ACH_Q1_Q2
					,(ISNULL(COUNT_ACH_Q1,0)-ISNULL(COUNT_ACH_Q3,0)) DFT_COUNT_ACH_Q1_Q3
					--,(ISNULL(COUNT_ACH_Q1,0)-ISNULL(COUNT_ACH_Q4,0)) DFT_COUNT_ACH_Q1_Q4
					,COUNT_FEE_STATICPOOL
					,COUNT_FEE_Q1
					,(ISNULL(COUNT_FEE_Q1,0)-ISNULL(COUNT_FEE_Q2,0)) DFT_COUNT_FEE_Q1_Q2
					,(ISNULL(COUNT_FEE_Q1,0)-ISNULL(COUNT_FEE_Q3,0)) DFT_COUNT_FEE_Q1_Q3
					--,(ISNULL(COUNT_FEE_Q1,0)-ISNULL(COUNT_FEE_Q4,0)) DFT_COUNT_FEE_Q1_Q4
					,COUNT_HOMEBANKING_STATICPOOL
					,COUNT_HOMEBANKING_Q1
					,(ISNULL(COUNT_HOMEBANKING_Q1,0)-ISNULL(COUNT_HOMEBANKING_Q2,0)) DFT_COUNT_HOMEBANKING_Q1_Q2
					,(ISNULL(COUNT_HOMEBANKING_Q1,0)-ISNULL(COUNT_HOMEBANKING_Q3,0)) DFT_COUNT_HOMEBANKING_Q1_Q3
					--,(ISNULL(COUNT_HOMEBANKING_Q1,0)-ISNULL(COUNT_HOMEBANKING_Q4,0)) DFT_COUNT_HOMEBANKING_Q1_Q4
					,COUNT_INSURANCE_STATICPOOL
					,COUNT_INSURANCE_Q1
					,(ISNULL(COUNT_INSURANCE_Q1,0)-ISNULL(COUNT_INSURANCE_Q2,0)) DFT_COUNT_INSURANCE_Q1_Q2
					,(ISNULL(COUNT_INSURANCE_Q1,0)-ISNULL(COUNT_INSURANCE_Q3,0)) DFT_COUNT_INSURANCE_Q1_Q3
					--,(ISNULL(COUNT_INSURANCE_Q1,0)-ISNULL(COUNT_INSURANCE_Q4,0)) DFT_COUNT_INSURANCE_Q1_Q4
					,COUNT_CHECKS_STATICPOOL
					,COUNT_CHECKS_Q1
					,(ISNULL(COUNT_CHECKS_Q1,0)-ISNULL(COUNT_CHECKS_Q2,0)) DFT_COUNT_CHECKS_Q1_Q2
					,(ISNULL(COUNT_CHECKS_Q1,0)-ISNULL(COUNT_CHECKS_Q3,0)) DFT_COUNT_CHECKS_Q1_Q3
					--,(ISNULL(COUNT_CHECKS_Q1,0)-ISNULL(COUNT_CHECKS_Q4,0)) DFT_COUNT_CHECKS_Q1_Q4
					,COUNT_PAYROLL_STATICPOOL
					,COUNT_PAYROLL_Q1
					,(ISNULL(COUNT_PAYROLL_Q1,0)-ISNULL(COUNT_PAYROLL_Q2,0)) DFT_COUNT_PAYROLL_Q1_Q2
					,(ISNULL(COUNT_PAYROLL_Q1,0)-ISNULL(COUNT_PAYROLL_Q3,0)) DFT_COUNT_PAYROLL_Q1_Q3
					--,(ISNULL(COUNT_PAYROLL_Q1,0)-ISNULL(COUNT_PAYROLL_Q4,0)) DFT_COUNT_PAYROLL_Q1_Q4
					,COUNT_KIOSK_STATICPOOL
					,COUNT_KIOSK_Q1
					,(ISNULL(COUNT_KIOSK_Q1,0)-ISNULL(COUNT_KIOSK_Q2,0)) DFT_COUNT_KIOSK_Q1_Q2
					,(ISNULL(COUNT_KIOSK_Q1,0)-ISNULL(COUNT_KIOSK_Q3,0)) DFT_COUNT_KIOSK_Q1_Q3
					--,(ISNULL(COUNT_KIOSK_Q1,0)-ISNULL(COUNT_KIOSK_Q4,0)) DFT_COUNT_KIOSK_Q1_Q4
					,COUNT_AUDIO_RESPONSE_TELEPHONE_STATICPOOL
					,COUNT_AUDIO_RESPONSE_TELEPHONE_Q1
					,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Q1,0)-ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Q2,0)) DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q2
					,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Q1,0)-ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Q3,0)) DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q3
					--,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Q1,0)-ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Q4,0)) DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q4
					--,LOAN_TRANSACTION_AMOUNT_STATICPOOL
					--,LOAN_TRANSACTION_AMOUNT_Q1
					--,(ISNULL(LOAN_TRANSACTION_AMOUNT_Q1,0)-ISNULL(LOAN_TRANSACTION_AMOUNT_Q2,0)) DFT_LOAN_TRANSACTION_AMOUNT_Q1_Q2
					--,(ISNULL(LOAN_TRANSACTION_AMOUNT_Q1,0)-ISNULL(LOAN_TRANSACTION_AMOUNT_Q3,0)) DFT_LOAN_TRANSACTION_AMOUNT_Q1_Q3
					----,(ISNULL(LOAN_TRANSACTION_AMOUNT_Q1,0)-ISNULL(LOAN_TRANSACTION_AMOUNT_Q4,0)) DFT_LOAN_TRANSACTION_AMOUNT_Q1_Q4
					--,INTEREST_AMOUNT_STATICPOOL
					--,INTEREST_AMOUNT_Q1
					--,(ISNULL(INTEREST_AMOUNT_Q1,0)-ISNULL(INTEREST_AMOUNT_Q2,0)) DFT_INTEREST_AMOUNT_Q1_Q2
					--,(ISNULL(INTEREST_AMOUNT_Q1,0)-ISNULL(INTEREST_AMOUNT_Q3,0)) DFT_INTEREST_AMOUNT_Q1_Q3
					----,(ISNULL(INTEREST_AMOUNT_Q1,0)-ISNULL(INTEREST_AMOUNT_Q4,0)) DFT_INTEREST_AMOUNT_Q1_Q4
					--,FEEAMOUNT_STATICPOOL
					--,FEEAMOUNT_Q1
					--,(ISNULL(FEEAMOUNT_Q1,0)-ISNULL(FEEAMOUNT_Q2,0)) DFT_FEEAMOUNT_Q1_Q2
					--,(ISNULL(FEEAMOUNT_Q1,0)-ISNULL(FEEAMOUNT_Q3,0)) DFT_FEEAMOUNT_Q1_Q3
					----,(ISNULL(FEEAMOUNT_Q1,0)-ISNULL(FEEAMOUNT_Q4,0)) DFT_FEEAMOUNT_Q1_Q4
					--,AVG_LOAN_TRANSACTION_AMOUNT_STATICPOOL
					--,AVG_LOAN_TRANSACTION_AMOUNT_Q1
					--,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Q1,0)-ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Q2,0)) DFT_AVG_LOAN_TRANSACTION_AMOUNT_Q1_Q2
					--,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Q1,0)-ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Q3,0)) DFT_AVG_LOAN_TRANSACTION_AMOUNT_Q1_Q3
					----,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Q1,0)-ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Q4,0)) DFT_AVG_LOAN_TRANSACTION_AMOUNT_Q1_Q4
					--,AVG_NEWBALANCE_STATICPOOL
					--,AVG_NEWBALANCE_Q1
					--,(ISNULL(AVG_NEWBALANCE_Q1,0)-ISNULL(AVG_NEWBALANCE_Q2,0)) DFT_AVG_NEWBALANCE_Q1_Q2
					--,(ISNULL(AVG_NEWBALANCE_Q1,0)-ISNULL(AVG_NEWBALANCE_Q3,0)) DFT_AVG_NEWBALANCE_Q1_Q3
					----,(ISNULL(AVG_NEWBALANCE_Q1,0)-ISNULL(AVG_NEWBALANCE_Q4,0)) DFT_AVG_NEWBALANCE_Q1_Q4
					--,AVG_INTEREST_AMOUNT_STATICPOOL
					--,AVG_INTEREST_AMOUNT_Q1
					--,(ISNULL(AVG_INTEREST_AMOUNT_Q1,0)-ISNULL(AVG_INTEREST_AMOUNT_Q2,0)) DFT_AVG_INTEREST_AMOUNT_Q1_Q2
					--,(ISNULL(AVG_INTEREST_AMOUNT_Q1,0)-ISNULL(AVG_INTEREST_AMOUNT_Q3,0)) DFT_AVG_INTEREST_AMOUNT_Q1_Q3
					----,(ISNULL(AVG_INTEREST_AMOUNT_Q1,0)-ISNULL(AVG_INTEREST_AMOUNT_Q4,0)) DFT_AVG_INTEREST_AMOUNT_Q1_Q4
					--,AVG_FEEAMOUNT_STATICPOOL
					--,AVG_FEEAMOUNT_Q1
					--,(ISNULL(AVG_FEEAMOUNT_Q1,0)-ISNULL(AVG_FEEAMOUNT_Q2,0)) DFT_AVG_FEEAMOUNT_Q1_Q2
					--,(ISNULL(AVG_FEEAMOUNT_Q1,0)-ISNULL(AVG_FEEAMOUNT_Q3,0)) DFT_AVG_FEEAMOUNT_Q1_Q3
					----,(ISNULL(AVG_FEEAMOUNT_Q1,0)-ISNULL(AVG_FEEAMOUNT_Q4,0)) DFT_AVG_FEEAMOUNT_Q1_Q4
	         --,COUNT_LOAN_ADDON_CommercialLoan_SP
	         ,COUNT_LOAN_ADDON_CommercialLoan_Q1
			 ,(ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q2,0)) [DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q2]
			 ,(ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q3,0)) [DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q3]
			 --,(ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q4,0)) [DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q4]
			 --,COUNT_NEW_LOAN_CommercialLoan_SP
			 ,COUNT_NEW_LOAN_CommercialLoan_Q1
			 ,(ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q2,0)) [COUNT_NEW_LOAN_CommercialLoan_Q1_Q2]
			 ,(ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q3,0)) [COUNT_NEW_LOAN_CommercialLoan_Q1_Q3]
			 --,(ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q4,0)) [COUNT_NEW_LOAN_CommercialLoan_Q1_Q4]
			 --,COUNT_LOAN_PAYMENT_CommercialLoan_SP
			 ,COUNT_LOAN_PAYMENT_CommercialLoan_Q1
			 ,(ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q2,0)) [DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q2]
			 ,(ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q3,0)) [DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q3]
			 --,(ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q4,0)) [DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q4]
			 --,COUNT_CASH_CommercialLoan_SP
			 ,COUNT_CASH_CommercialLoan_Q1
			 ,(ISNULL(COUNT_CASH_CommercialLoan_Q1,0) - ISNULL(COUNT_CASH_CommercialLoan_Q2,0)) [DFT_COUNT_CASH_CommercialLoan_Q1_Q2]
			 ,(ISNULL(COUNT_CASH_CommercialLoan_Q1,0) - ISNULL(COUNT_CASH_CommercialLoan_Q3,0)) [DFT_COUNT_CASH_CommercialLoan_Q1_Q3]
			 --,(ISNULL(COUNT_CASH_CommercialLoan_Q1,0) - ISNULL(COUNT_CASH_CommercialLoan_Q4,0)) [DFT_COUNT_CASH_CommercialLoan_Q1_Q4]
			 --,COUNT_DRAFT_CommercialLoan_SP
			 ,COUNT_DRAFT_CommercialLoan_Q1
			 ,(ISNULL(COUNT_DRAFT_CommercialLoan_Q1,0) - ISNULL(COUNT_DRAFT_CommercialLoan_Q2,0)) [DFT_COUNT_DRAFT_CommercialLoan_Q1_Q2]
			 ,(ISNULL(COUNT_DRAFT_CommercialLoan_Q1,0) - ISNULL(COUNT_DRAFT_CommercialLoan_Q3,0)) [DFT_COUNT_DRAFT_CommercialLoan_Q1_Q3]
			 --,(ISNULL(COUNT_DRAFT_CommercialLoan_Q1,0) - ISNULL(COUNT_DRAFT_CommercialLoan_Q4,0)) [DFT_COUNT_DRAFT_CommercialLoan_Q1_Q4]
			 --,COUNT_ACH_CommercialLoan_SP
			 ,COUNT_ACH_CommercialLoan_Q1
			 ,(ISNULL(COUNT_ACH_CommercialLoan_Q1,0) - ISNULL(COUNT_ACH_CommercialLoan_Q2,0)) [DFT_COUNT_ACH_CommercialLoan_Q1_Q2]
			 ,(ISNULL(COUNT_ACH_CommercialLoan_Q1,0) - ISNULL(COUNT_ACH_CommercialLoan_Q3,0)) [DFT_COUNT_ACH_CommercialLoan_Q1_Q3]
			 --,(ISNULL(COUNT_ACH_CommercialLoan_Q1,0) - ISNULL(COUNT_ACH_CommercialLoan_Q4,0)) [DFT_COUNT_ACH_CommercialLoan_Q1_Q4]
			 --,COUNT_FEE_CommercialLoan_SP
			 ,COUNT_FEE_CommercialLoan_Q1
			 ,(ISNULL(COUNT_FEE_CommercialLoan_Q1,0) - ISNULL(COUNT_FEE_CommercialLoan_Q2,0)) [DFT_COUNT_FEE_CommercialLoan_Q1_Q2]
			 ,(ISNULL(COUNT_FEE_CommercialLoan_Q1,0) - ISNULL(COUNT_FEE_CommercialLoan_Q3,0)) [DFT_COUNT_FEE_CommercialLoan_Q1_Q3]
			 --,(ISNULL(COUNT_FEE_CommercialLoan_Q1,0) - ISNULL(COUNT_FEE_CommercialLoan_Q4,0)) [DFT_COUNT_FEE_CommercialLoan_Q1_Q4]
			 --,COUNT_HOMEBANKING_CommercialLoan_SP
			 ,COUNT_HOMEBANKING_CommercialLoan_Q1
			 ,(ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q2,0)) [DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q2]
			 ,(ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q3,0)) [DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q3]
			 --,(ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q4,0)) [DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q4]
			 --,COUNT_INSURANCE_CommercialLoan_SP
			 ,COUNT_INSURANCE_CommercialLoan_Q1
			 ,(ISNULL(COUNT_INSURANCE_CommercialLoan_Q1,0) - ISNULL(COUNT_INSURANCE_CommercialLoan_Q2,0)) [DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q2]
			 ,(ISNULL(COUNT_INSURANCE_CommercialLoan_Q1,0) - ISNULL(COUNT_INSURANCE_CommercialLoan_Q3,0)) [DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q3]
			 --,(ISNULL(COUNT_INSURANCE_CommercialLoan_Q1,0) - ISNULL(COUNT_INSURANCE_CommercialLoan_Q4,0)) [DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q4]
			 --,COUNT_CHECKS_CommercialLoan_SP
			 ,COUNT_CHECKS_CommercialLoan_Q1
			 ,(ISNULL(COUNT_CHECKS_CommercialLoan_Q1,0) - ISNULL(COUNT_CHECKS_CommercialLoan_Q2,0)) [DFT_COUNT_CHECKS_CommercialLoan_Q1_Q2] 
			 ,(ISNULL(COUNT_CHECKS_CommercialLoan_Q1,0) - ISNULL(COUNT_CHECKS_CommercialLoan_Q3,0)) [DFT_COUNT_CHECKS_CommercialLoan_Q1_Q3]
			 --,(ISNULL(COUNT_CHECKS_CommercialLoan_Q1,0) - ISNULL(COUNT_CHECKS_CommercialLoan_Q4,0)) [DFT_COUNT_CHECKS_CommercialLoan_Q1_Q4]
			 --,COUNT_PAYROLL_CommercialLoan_SP
			 ,COUNT_PAYROLL_CommercialLoan_Q1
			 ,(ISNULL(COUNT_PAYROLL_CommercialLoan_Q1,0) - ISNULL(COUNT_PAYROLL_CommercialLoan_Q2,0)) [DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q2]
			 ,(ISNULL(COUNT_PAYROLL_CommercialLoan_Q1,0) - ISNULL(COUNT_PAYROLL_CommercialLoan_Q3,0)) [DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q3]
			 --,(ISNULL(COUNT_PAYROLL_CommercialLoan_Q1,0) - ISNULL(COUNT_PAYROLL_CommercialLoan_Q4,0)) [DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q4]
			 --,COUNT_KIOSK_CommercialLoan_SP
			 ,COUNT_KIOSK_CommercialLoan_Q1
			 ,(ISNULL(COUNT_KIOSK_CommercialLoan_Q1,0) - ISNULL(COUNT_KIOSK_CommercialLoan_Q2,0)) [DFT_COUNT_KIOSK_CommercialLoan_Q1_Q2]
			 ,(ISNULL(COUNT_KIOSK_CommercialLoan_Q1,0) - ISNULL(COUNT_KIOSK_CommercialLoan_Q3,0)) [DFT_COUNT_KIOSK_CommercialLoan_Q1_Q3]
			 --,(ISNULL(COUNT_KIOSK_CommercialLoan_Q1,0) - ISNULL(COUNT_KIOSK_CommercialLoan_Q4,0)) [DFT_COUNT_KIOSK_CommercialLoan_Q1_Q4]
			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_SP
			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1
			 ,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q2,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q2]
			 ,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q3,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q3]
			 --,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q4,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q4]

			 ,LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1
			 ,(ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2,0)) [DFT_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q2]
			 ,(ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3,0)) [DFT_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q3]
			 --,(ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4,0)) [DFT_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q4]
			 --,INTEREST_AMOUNT_CommercialLoan_SP
			 ,INTEREST_AMOUNT_CommercialLoan_Q1
			 ,(ISNULL(INTEREST_AMOUNT_CommercialLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_CommercialLoan_Q2,0)) [DFT_INTEREST_AMOUNT_CommercialLoan_Q1_Q2]
			 ,(ISNULL(INTEREST_AMOUNT_CommercialLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_CommercialLoan_Q3,0)) [DFT_INTEREST_AMOUNT_CommercialLoan_Q1_Q3]
			 --,(ISNULL(INTEREST_AMOUNT_CommercialLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_CommercialLoan_Q4,0)) [DFT_INTEREST_AMOUNT_CommercialLoan_Q1_Q4]
			 --,FEEAMOUNT_CommercialLoan_SP
			 ,FEEAMOUNT_CommercialLoan_Q1
			 ,(ISNULL(FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(FEEAMOUNT_CommercialLoan_Q2,0)) [DFT_FEEAMOUNT_CommercialLoan_Q1_Q2]
			 ,(ISNULL(FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(FEEAMOUNT_CommercialLoan_Q3,0)) [DFT_FEEAMOUNT_CommercialLoan_Q1_Q3]
			 --,(ISNULL(FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(FEEAMOUNT_CommercialLoan_Q4,0)) [DFT_FEEAMOUNT_CommercialLoan_Q1_Q4]
			 --,AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_SP
			 ,AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1
			 ,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q2]
			 ,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q3]
			 --,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q4]
			 ,AVG_NEWBALANCE_CommercialLoan_Q1
			 ,(ISNULL(AVG_NEWBALANCE_CommercialLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_CommercialLoan_Q2,0)) [DFT_AVG_NEWBALANCE_CommercialLoan_Q1_Q2]
			 ,(ISNULL(AVG_NEWBALANCE_CommercialLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_CommercialLoan_Q3,0)) [DFT_AVG_NEWBALANCE_CommercialLoan_Q1_Q3]
			 --,(ISNULL(AVG_NEWBALANCE_CommercialLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_CommercialLoan_Q4,0)) [DFT_AVG_NEWBALANCE_CommercialLoan_Q1_Q4]
			 --,AVG_FEEAMOUNT_CommercialLoan_SP
			 ,AVG_FEEAMOUNT_CommercialLoan_Q1
			 ,(ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q2,0)) [DFT_AVG_FEEAMOUNT_CommercialLoan_Q1_Q2]
			 ,(ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q3,0)) [DFT_AVG_FEEAMOUNT_CommercialLoan_Q1_Q3]
			 --,(ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q4,0)) [DFT_AVG_FEEAMOUNT_CommercialLoan_Q1_Q4]

	         --,COUNT_LOAN_ADDON_RealEstate_SP
	         ,COUNT_LOAN_ADDON_RealEstate_Q1
			 ,(ISNULL(COUNT_LOAN_ADDON_RealEstate_Q1,0) - ISNULL(COUNT_LOAN_ADDON_RealEstate_Q2,0)) [DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q2]
			 ,(ISNULL(COUNT_LOAN_ADDON_RealEstate_Q1,0) - ISNULL(COUNT_LOAN_ADDON_RealEstate_Q3,0)) [DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q3]
			 --,(ISNULL(COUNT_LOAN_ADDON_RealEstate_Q1,0) - ISNULL(COUNT_LOAN_ADDON_RealEstate_Q4,0)) [DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q4]
			 --,COUNT_NEW_LOAN_RealEstate_SP
			 ,COUNT_NEW_LOAN_RealEstate_Q1
			 ,(ISNULL(COUNT_NEW_LOAN_RealEstate_Q1,0) - ISNULL(COUNT_NEW_LOAN_RealEstate_Q2,0)) [COUNT_NEW_LOAN_RealEstate_Q1_Q2]
			 ,(ISNULL(COUNT_NEW_LOAN_RealEstate_Q1,0) - ISNULL(COUNT_NEW_LOAN_RealEstate_Q3,0)) [COUNT_NEW_LOAN_RealEstate_Q1_Q3]
			 --,(ISNULL(COUNT_NEW_LOAN_RealEstate_Q1,0) - ISNULL(COUNT_NEW_LOAN_RealEstate_Q4,0)) [COUNT_NEW_LOAN_RealEstate_Q1_Q4]
			 --,COUNT_LOAN_PAYMENT_RealEstate_SP
			 ,COUNT_LOAN_PAYMENT_RealEstate_Q1
			 ,(ISNULL(COUNT_LOAN_PAYMENT_RealEstate_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_RealEstate_Q2,0)) [DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q2]
			 ,(ISNULL(COUNT_LOAN_PAYMENT_RealEstate_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_RealEstate_Q3,0)) [DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q3]
			 --,(ISNULL(COUNT_LOAN_PAYMENT_RealEstate_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_RealEstate_Q4,0)) [DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q4]
			 --,COUNT_CASH_RealEstate_SP
			 ,COUNT_CASH_RealEstate_Q1
			 ,(ISNULL(COUNT_CASH_RealEstate_Q1,0) - ISNULL(COUNT_CASH_RealEstate_Q2,0)) [DFT_COUNT_CASH_RealEstate_Q1_Q2]
			 ,(ISNULL(COUNT_CASH_RealEstate_Q1,0) - ISNULL(COUNT_CASH_RealEstate_Q3,0)) [DFT_COUNT_CASH_RealEstate_Q1_Q3]
			 --,(ISNULL(COUNT_CASH_RealEstate_Q1,0) - ISNULL(COUNT_CASH_RealEstate_Q4,0)) [DFT_COUNT_CASH_RealEstate_Q1_Q4]
			 --,COUNT_DRAFT_RealEstate_SP
			 ,COUNT_DRAFT_RealEstate_Q1
			 ,(ISNULL(COUNT_DRAFT_RealEstate_Q1,0) - ISNULL(COUNT_DRAFT_RealEstate_Q2,0)) [DFT_COUNT_DRAFT_RealEstate_Q1_Q2]
			 ,(ISNULL(COUNT_DRAFT_RealEstate_Q1,0) - ISNULL(COUNT_DRAFT_RealEstate_Q3,0)) [DFT_COUNT_DRAFT_RealEstate_Q1_Q3]
			 --,(ISNULL(COUNT_DRAFT_RealEstate_Q1,0) - ISNULL(COUNT_DRAFT_RealEstate_Q4,0)) [DFT_COUNT_DRAFT_RealEstate_Q1_Q4]
			 --,COUNT_ACH_RealEstate_SP
			 ,COUNT_ACH_RealEstate_Q1
			 ,(ISNULL(COUNT_ACH_RealEstate_Q1,0) - ISNULL(COUNT_ACH_RealEstate_Q2,0)) [DFT_COUNT_ACH_RealEstate_Q1_Q2]
			 ,(ISNULL(COUNT_ACH_RealEstate_Q1,0) - ISNULL(COUNT_ACH_RealEstate_Q3,0)) [DFT_COUNT_ACH_RealEstate_Q1_Q3]
			 --,(ISNULL(COUNT_ACH_RealEstate_Q1,0) - ISNULL(COUNT_ACH_RealEstate_Q4,0)) [DFT_COUNT_ACH_RealEstate_Q1_Q4]
			 --,COUNT_FEE_RealEstate_SP
			 ,COUNT_FEE_RealEstate_Q1
			 ,(ISNULL(COUNT_FEE_RealEstate_Q1,0) - ISNULL(COUNT_FEE_RealEstate_Q2,0)) [DFT_COUNT_FEE_RealEstate_Q1_Q2]
			 ,(ISNULL(COUNT_FEE_RealEstate_Q1,0) - ISNULL(COUNT_FEE_RealEstate_Q3,0)) [DFT_COUNT_FEE_RealEstate_Q1_Q3]
			 --,(ISNULL(COUNT_FEE_RealEstate_Q1,0) - ISNULL(COUNT_FEE_RealEstate_Q4,0)) [DFT_COUNT_FEE_RealEstate_Q1_Q4]
			 --,COUNT_HOMEBANKING_RealEstate_SP
			 ,COUNT_HOMEBANKING_RealEstate_Q1
			 ,(ISNULL(COUNT_HOMEBANKING_RealEstate_Q1,0) - ISNULL(COUNT_HOMEBANKING_RealEstate_Q2,0)) [DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q2]
			 ,(ISNULL(COUNT_HOMEBANKING_RealEstate_Q1,0) - ISNULL(COUNT_HOMEBANKING_RealEstate_Q3,0)) [DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q3]
			 --,(ISNULL(COUNT_HOMEBANKING_RealEstate_Q1,0) - ISNULL(COUNT_HOMEBANKING_RealEstate_Q4,0)) [DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q4]
			 --,COUNT_INSURANCE_RealEstate_SP
			 ,COUNT_INSURANCE_RealEstate_Q1
			 ,(ISNULL(COUNT_INSURANCE_RealEstate_Q1,0) - ISNULL(COUNT_INSURANCE_RealEstate_Q2,0)) [DFT_COUNT_INSURANCE_RealEstate_Q1_Q2]
			 ,(ISNULL(COUNT_INSURANCE_RealEstate_Q1,0) - ISNULL(COUNT_INSURANCE_RealEstate_Q3,0)) [DFT_COUNT_INSURANCE_RealEstate_Q1_Q3]
			 --,(ISNULL(COUNT_INSURANCE_RealEstate_Q1,0) - ISNULL(COUNT_INSURANCE_RealEstate_Q4,0)) [DFT_COUNT_INSURANCE_RealEstate_Q1_Q4]
			 --,COUNT_CHECKS_RealEstate_SP
			 ,COUNT_CHECKS_RealEstate_Q1
			 ,(ISNULL(COUNT_CHECKS_RealEstate_Q1,0) - ISNULL(COUNT_CHECKS_RealEstate_Q2,0)) [DFT_COUNT_CHECKS_RealEstate_Q1_Q2] 
			 ,(ISNULL(COUNT_CHECKS_RealEstate_Q1,0) - ISNULL(COUNT_CHECKS_RealEstate_Q3,0)) [DFT_COUNT_CHECKS_RealEstate_Q1_Q3]
			 --,(ISNULL(COUNT_CHECKS_RealEstate_Q1,0) - ISNULL(COUNT_CHECKS_RealEstate_Q4,0)) [DFT_COUNT_CHECKS_RealEstate_Q1_Q4]
			 --,COUNT_PAYROLL_RealEstate_SP
			 ,COUNT_PAYROLL_RealEstate_Q1
			 ,(ISNULL(COUNT_PAYROLL_RealEstate_Q1,0) - ISNULL(COUNT_PAYROLL_RealEstate_Q2,0)) [DFT_COUNT_PAYROLL_RealEstate_Q1_Q2]
			 ,(ISNULL(COUNT_PAYROLL_RealEstate_Q1,0) - ISNULL(COUNT_PAYROLL_RealEstate_Q3,0)) [DFT_COUNT_PAYROLL_RealEstate_Q1_Q3]
			 --,(ISNULL(COUNT_PAYROLL_RealEstate_Q1,0) - ISNULL(COUNT_PAYROLL_RealEstate_Q4,0)) [DFT_COUNT_PAYROLL_RealEstate_Q1_Q4]
			 --,COUNT_KIOSK_RealEstate_SP
			 ,COUNT_KIOSK_RealEstate_Q1
			 ,(ISNULL(COUNT_KIOSK_RealEstate_Q1,0) - ISNULL(COUNT_KIOSK_RealEstate_Q2,0)) [DFT_COUNT_KIOSK_RealEstate_Q1_Q2]
			 ,(ISNULL(COUNT_KIOSK_RealEstate_Q1,0) - ISNULL(COUNT_KIOSK_RealEstate_Q3,0)) [DFT_COUNT_KIOSK_RealEstate_Q1_Q3]
			 --,(ISNULL(COUNT_KIOSK_RealEstate_Q1,0) - ISNULL(COUNT_KIOSK_RealEstate_Q4,0)) [DFT_COUNT_KIOSK_RealEstate_Q1_Q4]
			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_SP
			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1
			 ,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q2,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q2]
			 ,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q3,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q3]
			 --,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q4,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q4]

	         --,LOAN_TRANSACTION_AMOUNT_RealEstate_SP
			 ,LOAN_TRANSACTION_AMOUNT_RealEstate_Q1
			 ,(ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_Q2,0)) [DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2]
			 ,(ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_Q3,0)) [DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q3]
			 --,(ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_Q4,0)) [DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q4]
			 --,INTEREST_AMOUNT_RealEstate_SP
			 ,INTEREST_AMOUNT_RealEstate_Q1
			 ,(ISNULL(INTEREST_AMOUNT_RealEstate_Q1,0) - ISNULL(INTEREST_AMOUNT_RealEstate_Q2,0)) [DFT_INTEREST_AMOUNT_RealEstate_Q1_Q2]
			 ,(ISNULL(INTEREST_AMOUNT_RealEstate_Q1,0) - ISNULL(INTEREST_AMOUNT_RealEstate_Q3,0)) [DFT_INTEREST_AMOUNT_RealEstate_Q1_Q3]
			 --,(ISNULL(INTEREST_AMOUNT_RealEstate_Q1,0) - ISNULL(INTEREST_AMOUNT_RealEstate_Q4,0)) [DFT_INTEREST_AMOUNT_RealEstate_Q1_Q4]
			 --,FEEAMOUNT_RealEstate_SP
			 ,FEEAMOUNT_RealEstate_Q1
			 ,(ISNULL(FEEAMOUNT_RealEstate_Q1,0) - ISNULL(FEEAMOUNT_RealEstate_Q2,0)) [DFT_FEEAMOUNT_RealEstate_Q1_Q2]
			 ,(ISNULL(FEEAMOUNT_RealEstate_Q1,0) - ISNULL(FEEAMOUNT_RealEstate_Q3,0)) [DFT_FEEAMOUNT_RealEstate_Q1_Q3]
			 --,(ISNULL(FEEAMOUNT_RealEstate_Q1,0) - ISNULL(FEEAMOUNT_RealEstate_Q4,0)) [DFT_FEEAMOUNT_RealEstate_Q1_Q4]
			 ,AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_SP
			 ,AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1
			 ,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q2,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2]
			 ,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q3,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q3]
			 --,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q4,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q4]
			 ,AVG_NEWBALANCE_RealEstate_Q1
			 ,(ISNULL(AVG_NEWBALANCE_RealEstate_Q1,0) - ISNULL(AVG_NEWBALANCE_RealEstate_Q2,0)) [DFT_AVG_NEWBALANCE_RealEstate_Q1_Q2]
			 ,(ISNULL(AVG_NEWBALANCE_RealEstate_Q1,0) - ISNULL(AVG_NEWBALANCE_RealEstate_Q3,0)) [DFT_AVG_NEWBALANCE_RealEstate_Q1_Q3]
			 --,(ISNULL(AVG_NEWBALANCE_RealEstate_Q1,0) - ISNULL(AVG_NEWBALANCE_RealEstate_Q4,0)) [DFT_AVG_NEWBALANCE_RealEstate_Q1_Q4]
			 --,AVG_FEEAMOUNT_RealEstate_SP
			 ,AVG_FEEAMOUNT_RealEstate_Q1
			 ,(ISNULL(AVG_FEEAMOUNT_RealEstate_Q1,0) - ISNULL(AVG_FEEAMOUNT_RealEstate_Q2,0)) [DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q2]
			 ,(ISNULL(AVG_FEEAMOUNT_RealEstate_Q1,0) - ISNULL(AVG_FEEAMOUNT_RealEstate_Q3,0)) [DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q3]
			 --,(ISNULL(AVG_FEEAMOUNT_RealEstate_Q1,0) - ISNULL(AVG_FEEAMOUNT_RealEstate_Q4,0)) [DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q4]

			 --,COUNT_LOAN_ADDON_SecuredLoan_SP
	         ,COUNT_LOAN_ADDON_SecuredLoan_Q1
			 ,(ISNULL(COUNT_LOAN_ADDON_SecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_SecuredLoan_Q2,0)) [DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_LOAN_ADDON_SecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_SecuredLoan_Q3,0)) [DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_LOAN_ADDON_SecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_SecuredLoan_Q4,0)) [DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q4]
			 --,COUNT_NEW_LOAN_SecuredLoan_SP
			 ,COUNT_NEW_LOAN_SecuredLoan_Q1
			 ,(ISNULL(COUNT_NEW_LOAN_SecuredLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_SecuredLoan_Q2,0)) [COUNT_NEW_LOAN_SecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_NEW_LOAN_SecuredLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_SecuredLoan_Q3,0)) [COUNT_NEW_LOAN_SecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_NEW_LOAN_SecuredLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_SecuredLoan_Q4,0)) [COUNT_NEW_LOAN_SecuredLoan_Q1_Q4]
			 --,COUNT_LOAN_PAYMENT_SecuredLoan_SP
			 ,COUNT_LOAN_PAYMENT_SecuredLoan_Q1
			 ,(ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_Q2,0)) [DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_Q3,0)) [DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_Q4,0)) [DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q4]
			 --,COUNT_CASH_SecuredLoan_SP
			 ,COUNT_CASH_SecuredLoan_Q1
			 ,(ISNULL(COUNT_CASH_SecuredLoan_Q1,0) - ISNULL(COUNT_CASH_SecuredLoan_Q2,0)) [DFT_COUNT_CASH_SecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_CASH_SecuredLoan_Q1,0) - ISNULL(COUNT_CASH_SecuredLoan_Q3,0)) [DFT_COUNT_CASH_SecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_CASH_SecuredLoan_Q1,0) - ISNULL(COUNT_CASH_SecuredLoan_Q4,0)) [DFT_COUNT_CASH_SecuredLoan_Q1_Q4]
			 --,COUNT_DRAFT_SecuredLoan_SP
			 ,COUNT_DRAFT_SecuredLoan_Q1
			 ,(ISNULL(COUNT_DRAFT_SecuredLoan_Q1,0) - ISNULL(COUNT_DRAFT_SecuredLoan_Q2,0)) [DFT_COUNT_DRAFT_SecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_DRAFT_SecuredLoan_Q1,0) - ISNULL(COUNT_DRAFT_SecuredLoan_Q3,0)) [DFT_COUNT_DRAFT_SecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_DRAFT_SecuredLoan_Q1,0) - ISNULL(COUNT_DRAFT_SecuredLoan_Q4,0)) [DFT_COUNT_DRAFT_SecuredLoan_Q1_Q4]
			 --,COUNT_ACH_SecuredLoan_SP
			 ,COUNT_ACH_SecuredLoan_Q1
			 ,(ISNULL(COUNT_ACH_SecuredLoan_Q1,0) - ISNULL(COUNT_ACH_SecuredLoan_Q2,0)) [DFT_COUNT_ACH_SecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_ACH_SecuredLoan_Q1,0) - ISNULL(COUNT_ACH_SecuredLoan_Q3,0)) [DFT_COUNT_ACH_SecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_ACH_SecuredLoan_Q1,0) - ISNULL(COUNT_ACH_SecuredLoan_Q4,0)) [DFT_COUNT_ACH_SecuredLoan_Q1_Q4]
			 --,COUNT_FEE_SecuredLoan_SP
			 ,COUNT_FEE_SecuredLoan_Q1
			 ,(ISNULL(COUNT_FEE_SecuredLoan_Q1,0) - ISNULL(COUNT_FEE_SecuredLoan_Q2,0)) [DFT_COUNT_FEE_SecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_FEE_SecuredLoan_Q1,0) - ISNULL(COUNT_FEE_SecuredLoan_Q3,0)) [DFT_COUNT_FEE_SecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_FEE_SecuredLoan_Q1,0) - ISNULL(COUNT_FEE_SecuredLoan_Q4,0)) [DFT_COUNT_FEE_SecuredLoan_Q1_Q4]
			 --,COUNT_HOMEBANKING_SecuredLoan_SP
			 ,COUNT_HOMEBANKING_SecuredLoan_Q1
			 ,(ISNULL(COUNT_HOMEBANKING_SecuredLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_SecuredLoan_Q2,0)) [DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_HOMEBANKING_SecuredLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_SecuredLoan_Q3,0)) [DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_HOMEBANKING_SecuredLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_SecuredLoan_Q4,0)) [DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q4]
			 --,COUNT_INSURANCE_SecuredLoan_SP
			 ,COUNT_INSURANCE_SecuredLoan_Q1
			 ,(ISNULL(COUNT_INSURANCE_SecuredLoan_Q1,0) - ISNULL(COUNT_INSURANCE_SecuredLoan_Q2,0)) [DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_INSURANCE_SecuredLoan_Q1,0) - ISNULL(COUNT_INSURANCE_SecuredLoan_Q3,0)) [DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_INSURANCE_SecuredLoan_Q1,0) - ISNULL(COUNT_INSURANCE_SecuredLoan_Q4,0)) [DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q4]
			 --,COUNT_CHECKS_SecuredLoan_SP
			 ,COUNT_CHECKS_SecuredLoan_Q1
			 ,(ISNULL(COUNT_CHECKS_SecuredLoan_Q1,0) - ISNULL(COUNT_CHECKS_SecuredLoan_Q2,0)) [DFT_COUNT_CHECKS_SecuredLoan_Q1_Q2] 
			 ,(ISNULL(COUNT_CHECKS_SecuredLoan_Q1,0) - ISNULL(COUNT_CHECKS_SecuredLoan_Q3,0)) [DFT_COUNT_CHECKS_SecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_CHECKS_SecuredLoan_Q1,0) - ISNULL(COUNT_CHECKS_SecuredLoan_Q4,0)) [DFT_COUNT_CHECKS_SecuredLoan_Q1_Q4]
			 --,COUNT_PAYROLL_SecuredLoan_SP
			 ,COUNT_PAYROLL_SecuredLoan_Q1
			 ,(ISNULL(COUNT_PAYROLL_SecuredLoan_Q1,0) - ISNULL(COUNT_PAYROLL_SecuredLoan_Q2,0)) [DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_PAYROLL_SecuredLoan_Q1,0) - ISNULL(COUNT_PAYROLL_SecuredLoan_Q3,0)) [DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_PAYROLL_SecuredLoan_Q1,0) - ISNULL(COUNT_PAYROLL_SecuredLoan_Q4,0)) [DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q4]
			 --,COUNT_KIOSK_SecuredLoan_SP
			 ,COUNT_KIOSK_SecuredLoan_Q1
			 ,(ISNULL(COUNT_KIOSK_SecuredLoan_Q1,0) - ISNULL(COUNT_KIOSK_SecuredLoan_Q2,0)) [DFT_COUNT_KIOSK_SecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_KIOSK_SecuredLoan_Q1,0) - ISNULL(COUNT_KIOSK_SecuredLoan_Q3,0)) [DFT_COUNT_KIOSK_SecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_KIOSK_SecuredLoan_Q1,0) - ISNULL(COUNT_KIOSK_SecuredLoan_Q4,0)) [DFT_COUNT_KIOSK_SecuredLoan_Q1_Q4]
			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_SP
			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1
			 ,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q2,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q3,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q4,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q4]

	         --,LOAN_TRANSACTION_AMOUNT_SecuredLoan_SP
			 ,LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1
			 ,(ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2,0)) [DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2]
			 ,(ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q3,0)) [DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q3]
			 --,(ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q4,0)) [DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q4]
			 --,INTEREST_AMOUNT_SecuredLoan_SP
			 ,INTEREST_AMOUNT_SecuredLoan_Q1
			 ,(ISNULL(INTEREST_AMOUNT_SecuredLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_SecuredLoan_Q2,0)) [DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q2]
			 ,(ISNULL(INTEREST_AMOUNT_SecuredLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_SecuredLoan_Q3,0)) [DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q3]
			 --,(ISNULL(INTEREST_AMOUNT_SecuredLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_SecuredLoan_Q4,0)) [DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q4]
			 --,FEEAMOUNT_SecuredLoan_SP
			 ,FEEAMOUNT_SecuredLoan_Q1
			 ,(ISNULL(FEEAMOUNT_SecuredLoan_Q1,0) - ISNULL(FEEAMOUNT_SecuredLoan_Q2,0)) [DFT_FEEAMOUNT_SecuredLoan_Q1_Q2]
			 ,(ISNULL(FEEAMOUNT_SecuredLoan_Q1,0) - ISNULL(FEEAMOUNT_SecuredLoan_Q3,0)) [DFT_FEEAMOUNT_SecuredLoan_Q1_Q3]
			 --,(ISNULL(FEEAMOUNT_SecuredLoan_Q1,0) - ISNULL(FEEAMOUNT_SecuredLoan_Q4,0)) [DFT_FEEAMOUNT_SecuredLoan_Q1_Q4]
			 --,AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_SP
			 ,AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1
			 ,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2]
			 ,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q3,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q3]
			 --,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q4,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q4]
			 ,AVG_NEWBALANCE_SecuredLoan_Q1
			 ,(ISNULL(AVG_NEWBALANCE_SecuredLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_SecuredLoan_Q2,0)) [DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q2]
			 ,(ISNULL(AVG_NEWBALANCE_SecuredLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_SecuredLoan_Q3,0)) [DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q3]
			 --,(ISNULL(AVG_NEWBALANCE_SecuredLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_SecuredLoan_Q4,0)) [DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q4]
			 --,AVG_FEEAMOUNT_SecuredLoan_SP
			 ,AVG_FEEAMOUNT_SecuredLoan_Q1
			 ,(ISNULL(AVG_FEEAMOUNT_SecuredLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_SecuredLoan_Q2,0)) [DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q2]
			 ,(ISNULL(AVG_FEEAMOUNT_SecuredLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_SecuredLoan_Q3,0)) [DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q3]
			 --,(ISNULL(AVG_FEEAMOUNT_SecuredLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_SecuredLoan_Q4,0)) [DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q4]

			 --,COUNT_LOAN_ADDON_UnsecuredLoan_SP
	         ,COUNT_LOAN_ADDON_UnsecuredLoan_Q1
			 ,(ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_Q2,0)) [DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_Q3,0)) [DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_Q4,0)) [DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q4]
			 --,COUNT_NEW_LOAN_UnsecuredLoan_SP
			 ,COUNT_NEW_LOAN_UnsecuredLoan_Q1
			 ,(ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_Q2,0)) [COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_Q3,0)) [COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_Q4,0)) [COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q4]
			 --,COUNT_LOAN_PAYMENT_UnsecuredLoan_SP
			 ,COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1
			 ,(ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_Q2,0)) [DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_Q3,0)) [DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_Q4,0)) [DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q4]
			 --,COUNT_CASH_UnsecuredLoan_SP
			 ,COUNT_CASH_UnsecuredLoan_Q1
			 ,(ISNULL(COUNT_CASH_UnsecuredLoan_Q1,0) - ISNULL(COUNT_CASH_UnsecuredLoan_Q2,0)) [DFT_COUNT_CASH_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_CASH_UnsecuredLoan_Q1,0) - ISNULL(COUNT_CASH_UnsecuredLoan_Q3,0)) [DFT_COUNT_CASH_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_CASH_UnsecuredLoan_Q1,0) - ISNULL(COUNT_CASH_UnsecuredLoan_Q4,0)) [DFT_COUNT_CASH_UnsecuredLoan_Q1_Q4]
			 --,COUNT_DRAFT_UnsecuredLoan_SP
			 ,COUNT_DRAFT_UnsecuredLoan_Q1
			 ,(ISNULL(COUNT_DRAFT_UnsecuredLoan_Q1,0) - ISNULL(COUNT_DRAFT_UnsecuredLoan_Q2,0)) [DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_DRAFT_UnsecuredLoan_Q1,0) - ISNULL(COUNT_DRAFT_UnsecuredLoan_Q3,0)) [DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_DRAFT_UnsecuredLoan_Q1,0) - ISNULL(COUNT_DRAFT_UnsecuredLoan_Q4,0)) [DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q4]
			 --,COUNT_ACH_UnsecuredLoan_SP
			 ,COUNT_ACH_UnsecuredLoan_Q1
			 ,(ISNULL(COUNT_ACH_UnsecuredLoan_Q1,0) - ISNULL(COUNT_ACH_UnsecuredLoan_Q2,0)) [DFT_COUNT_ACH_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_ACH_UnsecuredLoan_Q1,0) - ISNULL(COUNT_ACH_UnsecuredLoan_Q3,0)) [DFT_COUNT_ACH_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_ACH_UnsecuredLoan_Q1,0) - ISNULL(COUNT_ACH_UnsecuredLoan_Q4,0)) [DFT_COUNT_ACH_UnsecuredLoan_Q1_Q4]
			 --,COUNT_FEE_UnsecuredLoan_SP
			 ,COUNT_FEE_UnsecuredLoan_Q1
			 ,(ISNULL(COUNT_FEE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_FEE_UnsecuredLoan_Q2,0)) [DFT_COUNT_FEE_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_FEE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_FEE_UnsecuredLoan_Q3,0)) [DFT_COUNT_FEE_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_FEE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_FEE_UnsecuredLoan_Q4,0)) [DFT_COUNT_FEE_UnsecuredLoan_Q1_Q4]
			 --,COUNT_HOMEBANKING_UnsecuredLoan_SP
			 ,COUNT_HOMEBANKING_UnsecuredLoan_Q1
			 ,(ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_Q2,0)) [DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_Q3,0)) [DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_Q4,0)) [DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q4]
			 --,COUNT_INSURANCE_UnsecuredLoan_SP
			 ,COUNT_INSURANCE_UnsecuredLoan_Q1
			 ,(ISNULL(COUNT_INSURANCE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_INSURANCE_UnsecuredLoan_Q2,0)) [DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_INSURANCE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_INSURANCE_UnsecuredLoan_Q3,0)) [DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_INSURANCE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_INSURANCE_UnsecuredLoan_Q4,0)) [DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q4]
			 --,COUNT_CHECKS_UnsecuredLoan_SP
			 ,COUNT_CHECKS_UnsecuredLoan_Q1
			 ,(ISNULL(COUNT_CHECKS_UnsecuredLoan_Q1,0) - ISNULL(COUNT_CHECKS_UnsecuredLoan_Q2,0)) [DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q2] 
			 ,(ISNULL(COUNT_CHECKS_UnsecuredLoan_Q1,0) - ISNULL(COUNT_CHECKS_UnsecuredLoan_Q3,0)) [DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_CHECKS_UnsecuredLoan_Q1,0) - ISNULL(COUNT_CHECKS_UnsecuredLoan_Q4,0)) [DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q4]
			 --,COUNT_PAYROLL_UnsecuredLoan_SP
			 ,COUNT_PAYROLL_UnsecuredLoan_Q1
			 ,(ISNULL(COUNT_PAYROLL_UnsecuredLoan_Q1,0) - ISNULL(COUNT_PAYROLL_UnsecuredLoan_Q2,0)) [DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_PAYROLL_UnsecuredLoan_Q1,0) - ISNULL(COUNT_PAYROLL_UnsecuredLoan_Q3,0)) [DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_PAYROLL_UnsecuredLoan_Q1,0) - ISNULL(COUNT_PAYROLL_UnsecuredLoan_Q4,0)) [DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q4]
			 --,COUNT_KIOSK_UnsecuredLoan_SP
			 ,COUNT_KIOSK_UnsecuredLoan_Q1
			 ,(ISNULL(COUNT_KIOSK_UnsecuredLoan_Q1,0) - ISNULL(COUNT_KIOSK_UnsecuredLoan_Q2,0)) [DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_KIOSK_UnsecuredLoan_Q1,0) - ISNULL(COUNT_KIOSK_UnsecuredLoan_Q3,0)) [DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_KIOSK_UnsecuredLoan_Q1,0) - ISNULL(COUNT_KIOSK_UnsecuredLoan_Q4,0)) [DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q4]
			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_SP
			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1
			 ,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q2,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q3,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q4,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q4]

			 ,(ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2,0)) [DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q3,0)) [DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q4,0)) [DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q4]
			 --,INTEREST_AMOUNT_UnsecuredLoan_SP
			 ,INTEREST_AMOUNT_UnsecuredLoan_Q1
			 ,(ISNULL(INTEREST_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_UnsecuredLoan_Q2,0)) [DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(INTEREST_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_UnsecuredLoan_Q3,0)) [DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(INTEREST_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_UnsecuredLoan_Q4,0)) [DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q4]
			 --,FEEAMOUNT_UnsecuredLoan_SP
			 ,FEEAMOUNT_UnsecuredLoan_Q1
			 ,(ISNULL(FEEAMOUNT_UnsecuredLoan_Q1,0) - ISNULL(FEEAMOUNT_UnsecuredLoan_Q2,0)) [DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(FEEAMOUNT_UnsecuredLoan_Q1,0) - ISNULL(FEEAMOUNT_UnsecuredLoan_Q3,0)) [DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(FEEAMOUNT_UnsecuredLoan_Q1,0) - ISNULL(FEEAMOUNT_UnsecuredLoan_Q4,0)) [DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q4]
			 --,AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_SP
			 ,AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1
			 ,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q3,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q4,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q4]
			 ,AVG_NEWBALANCE_UnsecuredLoan_Q1
			 ,(ISNULL(AVG_NEWBALANCE_UnsecuredLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_UnsecuredLoan_Q2,0)) [DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(AVG_NEWBALANCE_UnsecuredLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_UnsecuredLoan_Q3,0)) [DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(AVG_NEWBALANCE_UnsecuredLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_UnsecuredLoan_Q4,0)) [DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q4]
			 --,AVG_FEEAMOUNT_UnsecuredLoan_SP
			 ,AVG_FEEAMOUNT_UnsecuredLoan_Q1
			 ,(ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_Q2,0)) [DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q2]
			 ,(ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_Q3,0)) [DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q3]
			 --,(ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_Q4,0)) [DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q4]

			 --,COUNT_LOAN_ADDON_VehicleLoan_SP
	         ,COUNT_LOAN_ADDON_VehicleLoan_Q1
			 ,(ISNULL(COUNT_LOAN_ADDON_VehicleLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_VehicleLoan_Q2,0)) [DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q2]
			 ,(ISNULL(COUNT_LOAN_ADDON_VehicleLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_VehicleLoan_Q3,0)) [DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q3]
			 --,(ISNULL(COUNT_LOAN_ADDON_VehicleLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_VehicleLoan_Q4,0)) [DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q4]
			 --,COUNT_NEW_LOAN_VehicleLoan_SP
			 ,COUNT_NEW_LOAN_VehicleLoan_Q1
			 ,(ISNULL(COUNT_NEW_LOAN_VehicleLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_VehicleLoan_Q2,0)) [COUNT_NEW_LOAN_VehicleLoan_Q1_Q2]
			 ,(ISNULL(COUNT_NEW_LOAN_VehicleLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_VehicleLoan_Q3,0)) [COUNT_NEW_LOAN_VehicleLoan_Q1_Q3]
			 --,(ISNULL(COUNT_NEW_LOAN_VehicleLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_VehicleLoan_Q4,0)) [COUNT_NEW_LOAN_VehicleLoan_Q1_Q4]
			 --,COUNT_LOAN_PAYMENT_VehicleLoan_SP
			 ,COUNT_LOAN_PAYMENT_VehicleLoan_Q1
			 ,(ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_Q2,0)) [DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q2]
			 ,(ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_Q3,0)) [DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q3]
			 --,(ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_Q4,0)) [DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q4]
			 --,COUNT_CASH_VehicleLoan_SP
			 ,COUNT_CASH_VehicleLoan_Q1
			 ,(ISNULL(COUNT_CASH_VehicleLoan_Q1,0) - ISNULL(COUNT_CASH_VehicleLoan_Q2,0)) [DFT_COUNT_CASH_VehicleLoan_Q1_Q2]
			 ,(ISNULL(COUNT_CASH_VehicleLoan_Q1,0) - ISNULL(COUNT_CASH_VehicleLoan_Q3,0)) [DFT_COUNT_CASH_VehicleLoan_Q1_Q3]
			 --,(ISNULL(COUNT_CASH_VehicleLoan_Q1,0) - ISNULL(COUNT_CASH_VehicleLoan_Q4,0)) [DFT_COUNT_CASH_VehicleLoan_Q1_Q4]
			 --,COUNT_DRAFT_VehicleLoan_SP
			 ,COUNT_DRAFT_VehicleLoan_Q1
			 ,(ISNULL(COUNT_DRAFT_VehicleLoan_Q1,0) - ISNULL(COUNT_DRAFT_VehicleLoan_Q2,0)) [DFT_COUNT_DRAFT_VehicleLoan_Q1_Q2]
			 ,(ISNULL(COUNT_DRAFT_VehicleLoan_Q1,0) - ISNULL(COUNT_DRAFT_VehicleLoan_Q3,0)) [DFT_COUNT_DRAFT_VehicleLoan_Q1_Q3]
			 --,(ISNULL(COUNT_DRAFT_VehicleLoan_Q1,0) - ISNULL(COUNT_DRAFT_VehicleLoan_Q4,0)) [DFT_COUNT_DRAFT_VehicleLoan_Q1_Q4]
			 --,COUNT_ACH_VehicleLoan_SP
			 ,COUNT_ACH_VehicleLoan_Q1
			 ,(ISNULL(COUNT_ACH_VehicleLoan_Q1,0) - ISNULL(COUNT_ACH_VehicleLoan_Q2,0)) [DFT_COUNT_ACH_VehicleLoan_Q1_Q2]
			 ,(ISNULL(COUNT_ACH_VehicleLoan_Q1,0) - ISNULL(COUNT_ACH_VehicleLoan_Q3,0)) [DFT_COUNT_ACH_VehicleLoan_Q1_Q3]
			 --,(ISNULL(COUNT_ACH_VehicleLoan_Q1,0) - ISNULL(COUNT_ACH_VehicleLoan_Q4,0)) [DFT_COUNT_ACH_VehicleLoan_Q1_Q4]
			 --,COUNT_FEE_VehicleLoan_SP
			 ,COUNT_FEE_VehicleLoan_Q1
			 ,(ISNULL(COUNT_FEE_VehicleLoan_Q1,0) - ISNULL(COUNT_FEE_VehicleLoan_Q2,0)) [DFT_COUNT_FEE_VehicleLoan_Q1_Q2]
			 ,(ISNULL(COUNT_FEE_VehicleLoan_Q1,0) - ISNULL(COUNT_FEE_VehicleLoan_Q3,0)) [DFT_COUNT_FEE_VehicleLoan_Q1_Q3]
			 --,(ISNULL(COUNT_FEE_VehicleLoan_Q1,0) - ISNULL(COUNT_FEE_VehicleLoan_Q4,0)) [DFT_COUNT_FEE_VehicleLoan_Q1_Q4]
			 --,COUNT_HOMEBANKING_VehicleLoan_SP
			 ,COUNT_HOMEBANKING_VehicleLoan_Q1
			 ,(ISNULL(COUNT_HOMEBANKING_VehicleLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_VehicleLoan_Q2,0)) [DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q2]
			 ,(ISNULL(COUNT_HOMEBANKING_VehicleLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_VehicleLoan_Q3,0)) [DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q3]
			 --,(ISNULL(COUNT_HOMEBANKING_VehicleLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_VehicleLoan_Q4,0)) [DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q4]
			 --,COUNT_INSURANCE_VehicleLoan_SP
			 ,COUNT_INSURANCE_VehicleLoan_Q1
			 ,(ISNULL(COUNT_INSURANCE_VehicleLoan_Q1,0) - ISNULL(COUNT_INSURANCE_VehicleLoan_Q2,0)) [DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q2]
			 ,(ISNULL(COUNT_INSURANCE_VehicleLoan_Q1,0) - ISNULL(COUNT_INSURANCE_VehicleLoan_Q3,0)) [DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q3]
			 --,(ISNULL(COUNT_INSURANCE_VehicleLoan_Q1,0) - ISNULL(COUNT_INSURANCE_VehicleLoan_Q4,0)) [DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q4]
			 --,COUNT_CHECKS_VehicleLoan_SP
			 ,COUNT_CHECKS_VehicleLoan_Q1
			 ,(ISNULL(COUNT_CHECKS_VehicleLoan_Q1,0) - ISNULL(COUNT_CHECKS_VehicleLoan_Q2,0)) [DFT_COUNT_CHECKS_VehicleLoan_Q1_Q2] 
			 ,(ISNULL(COUNT_CHECKS_VehicleLoan_Q1,0) - ISNULL(COUNT_CHECKS_VehicleLoan_Q3,0)) [DFT_COUNT_CHECKS_VehicleLoan_Q1_Q3]
			 --,(ISNULL(COUNT_CHECKS_VehicleLoan_Q1,0) - ISNULL(COUNT_CHECKS_VehicleLoan_Q4,0)) [DFT_COUNT_CHECKS_VehicleLoan_Q1_Q4]
			 --,COUNT_PAYROLL_VehicleLoan_SP
			 ,COUNT_PAYROLL_VehicleLoan_Q1
			 ,(ISNULL(COUNT_PAYROLL_VehicleLoan_Q1,0) - ISNULL(COUNT_PAYROLL_VehicleLoan_Q2,0)) [DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q2]
			 ,(ISNULL(COUNT_PAYROLL_VehicleLoan_Q1,0) - ISNULL(COUNT_PAYROLL_VehicleLoan_Q3,0)) [DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q3]
			 --,(ISNULL(COUNT_PAYROLL_VehicleLoan_Q1,0) - ISNULL(COUNT_PAYROLL_VehicleLoan_Q4,0)) [DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q4]
			 --,COUNT_KIOSK_VehicleLoan_SP
			 ,COUNT_KIOSK_VehicleLoan_Q1
			 ,(ISNULL(COUNT_KIOSK_VehicleLoan_Q1,0) - ISNULL(COUNT_KIOSK_VehicleLoan_Q2,0)) [DFT_COUNT_KIOSK_VehicleLoan_Q1_Q2]
			 ,(ISNULL(COUNT_KIOSK_VehicleLoan_Q1,0) - ISNULL(COUNT_KIOSK_VehicleLoan_Q3,0)) [DFT_COUNT_KIOSK_VehicleLoan_Q1_Q3]
			 --,(ISNULL(COUNT_KIOSK_VehicleLoan_Q1,0) - ISNULL(COUNT_KIOSK_VehicleLoan_Q4,0)) [DFT_COUNT_KIOSK_VehicleLoan_Q1_Q4]
			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_SP
			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1
			 ,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q2,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q2]
			 ,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q3,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q3]
			 --,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q4,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q4]

	         --,LOAN_TRANSACTION_AMOUNT_VehicleLoan_SP
			 ,LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1
			 ,(ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q2,0)) [DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2]
			 ,(ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q3,0)) [DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3]
			 --,(ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q4,0)) [DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q4]
			 --,INTEREST_AMOUNT_VehicleLoan_SP
			 ,INTEREST_AMOUNT_VehicleLoan_Q1
			 ,(ISNULL(INTEREST_AMOUNT_VehicleLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_VehicleLoan_Q2,0)) [DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2]
			 ,(ISNULL(INTEREST_AMOUNT_VehicleLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_VehicleLoan_Q3,0)) [DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q3]
			 --,(ISNULL(INTEREST_AMOUNT_VehicleLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_VehicleLoan_Q4,0)) [DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q4]
			 --,FEEAMOUNT_VehicleLoan_SP
			 ,FEEAMOUNT_VehicleLoan_Q1
			 ,(ISNULL(FEEAMOUNT_VehicleLoan_Q1,0) - ISNULL(FEEAMOUNT_VehicleLoan_Q2,0)) [DFT_FEEAMOUNT_VehicleLoan_Q1_Q2]
			 ,(ISNULL(FEEAMOUNT_VehicleLoan_Q1,0) - ISNULL(FEEAMOUNT_VehicleLoan_Q3,0)) [DFT_FEEAMOUNT_VehicleLoan_Q1_Q3]
			 --,(ISNULL(FEEAMOUNT_VehicleLoan_Q1,0) - ISNULL(FEEAMOUNT_VehicleLoan_Q4,0)) [DFT_FEEAMOUNT_VehicleLoan_Q1_Q4]
			 --,AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_SP
			 ,AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1
			 ,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q2,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2]
			 ,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q3,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q3]
			 --,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q4,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q4]
			 ,AVG_NEWBALANCE_VehicleLoan_Q1
			 ,(ISNULL(AVG_NEWBALANCE_VehicleLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_VehicleLoan_Q2,0)) [DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2]
			 ,(ISNULL(AVG_NEWBALANCE_VehicleLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_VehicleLoan_Q3,0)) [DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q3]
			 --,(ISNULL(AVG_NEWBALANCE_VehicleLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_VehicleLoan_Q4,0)) [DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q4]
			 --,AVG_FEEAMOUNT_VehicleLoan_SP
			 ,AVG_FEEAMOUNT_VehicleLoan_Q1
			 ,(ISNULL(AVG_FEEAMOUNT_VehicleLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_VehicleLoan_Q2,0)) [DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q2]
			 ,(ISNULL(AVG_FEEAMOUNT_VehicleLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_VehicleLoan_Q3,0)) [DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q3]
			 --,(ISNULL(AVG_FEEAMOUNT_VehicleLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_VehicleLoan_Q4,0)) [DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q4]

	       --,COUNT_LOAN_ADDON_Others_SP
	         ,COUNT_LOAN_ADDON_Others_Q1
			 ,(ISNULL(COUNT_LOAN_ADDON_Others_Q1,0) - ISNULL(COUNT_LOAN_ADDON_Others_Q2,0)) [DFT_COUNT_LOAN_ADDON_Others_Q1_Q2]
			 ,(ISNULL(COUNT_LOAN_ADDON_Others_Q1,0) - ISNULL(COUNT_LOAN_ADDON_Others_Q3,0)) [DFT_COUNT_LOAN_ADDON_Others_Q1_Q3]
			 --,(ISNULL(COUNT_LOAN_ADDON_Others_Q1,0) - ISNULL(COUNT_LOAN_ADDON_Others_Q4,0)) [DFT_COUNT_LOAN_ADDON_Others_Q1_Q4]
			 --,COUNT_NEW_LOAN_Others_SP
			 ,COUNT_NEW_LOAN_Others_Q1
			 ,(ISNULL(COUNT_NEW_LOAN_Others_Q1,0) - ISNULL(COUNT_NEW_LOAN_Others_Q2,0)) [COUNT_NEW_LOAN_Others_Q1_Q2]
			 ,(ISNULL(COUNT_NEW_LOAN_Others_Q1,0) - ISNULL(COUNT_NEW_LOAN_Others_Q3,0)) [COUNT_NEW_LOAN_Others_Q1_Q3]
			 --,(ISNULL(COUNT_NEW_LOAN_Others_Q1,0) - ISNULL(COUNT_NEW_LOAN_Others_Q4,0)) [COUNT_NEW_LOAN_Others_Q1_Q4]
			 --,COUNT_LOAN_PAYMENT_Others_SP
			 ,COUNT_LOAN_PAYMENT_Others_Q1
			 ,(ISNULL(COUNT_LOAN_PAYMENT_Others_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_Others_Q2,0)) [DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q2]
			 ,(ISNULL(COUNT_LOAN_PAYMENT_Others_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_Others_Q3,0)) [DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q3]
			 --,(ISNULL(COUNT_LOAN_PAYMENT_Others_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_Others_Q4,0)) [DFT_COUNT_LOAN_PAYMENT_Others_Q1_Q4]
			 --,COUNT_CASH_Others_SP
			 ,COUNT_CASH_Others_Q1
			 ,(ISNULL(COUNT_CASH_Others_Q1,0) - ISNULL(COUNT_CASH_Others_Q2,0)) [DFT_COUNT_CASH_Others_Q1_Q2]
			 ,(ISNULL(COUNT_CASH_Others_Q1,0) - ISNULL(COUNT_CASH_Others_Q3,0)) [DFT_COUNT_CASH_Others_Q1_Q3]
			 --,(ISNULL(COUNT_CASH_Others_Q1,0) - ISNULL(COUNT_CASH_Others_Q4,0)) [DFT_COUNT_CASH_Others_Q1_Q4]
			 --,COUNT_DRAFT_Others_SP
			 ,COUNT_DRAFT_Others_Q1
			 ,(ISNULL(COUNT_DRAFT_Others_Q1,0) - ISNULL(COUNT_DRAFT_Others_Q2,0)) [DFT_COUNT_DRAFT_Others_Q1_Q2]
			 ,(ISNULL(COUNT_DRAFT_Others_Q1,0) - ISNULL(COUNT_DRAFT_Others_Q3,0)) [DFT_COUNT_DRAFT_Others_Q1_Q3]
			 --,(ISNULL(COUNT_DRAFT_Others_Q1,0) - ISNULL(COUNT_DRAFT_Others_Q4,0)) [DFT_COUNT_DRAFT_Others_Q1_Q4]
			 --,COUNT_ACH_Others_SP
			 ,COUNT_ACH_Others_Q1
			 ,(ISNULL(COUNT_ACH_Others_Q1,0) - ISNULL(COUNT_ACH_Others_Q2,0)) [DFT_COUNT_ACH_Others_Q1_Q2]
			 ,(ISNULL(COUNT_ACH_Others_Q1,0) - ISNULL(COUNT_ACH_Others_Q3,0)) [DFT_COUNT_ACH_Others_Q1_Q3]
			 --,(ISNULL(COUNT_ACH_Others_Q1,0) - ISNULL(COUNT_ACH_Others_Q4,0)) [DFT_COUNT_ACH_Others_Q1_Q4]
			 --,COUNT_FEE_Others_SP
			 ,COUNT_FEE_Others_Q1
			 ,(ISNULL(COUNT_FEE_Others_Q1,0) - ISNULL(COUNT_FEE_Others_Q2,0)) [DFT_COUNT_FEE_Others_Q1_Q2]
			 ,(ISNULL(COUNT_FEE_Others_Q1,0) - ISNULL(COUNT_FEE_Others_Q3,0)) [DFT_COUNT_FEE_Others_Q1_Q3]
			 --,(ISNULL(COUNT_FEE_Others_Q1,0) - ISNULL(COUNT_FEE_Others_Q4,0)) [DFT_COUNT_FEE_Others_Q1_Q4]
			 --,COUNT_HOMEBANKING_Others_SP
			 ,COUNT_HOMEBANKING_Others_Q1
			 ,(ISNULL(COUNT_HOMEBANKING_Others_Q1,0) - ISNULL(COUNT_HOMEBANKING_Others_Q2,0)) [DFT_COUNT_HOMEBANKING_Others_Q1_Q2]
			 ,(ISNULL(COUNT_HOMEBANKING_Others_Q1,0) - ISNULL(COUNT_HOMEBANKING_Others_Q3,0)) [DFT_COUNT_HOMEBANKING_Others_Q1_Q3]
			 --,(ISNULL(COUNT_HOMEBANKING_Others_Q1,0) - ISNULL(COUNT_HOMEBANKING_Others_Q4,0)) [DFT_COUNT_HOMEBANKING_Others_Q1_Q4]
			 --,COUNT_INSURANCE_Others_SP
			 ,COUNT_INSURANCE_Others_Q1
			 ,(ISNULL(COUNT_INSURANCE_Others_Q1,0) - ISNULL(COUNT_INSURANCE_Others_Q2,0)) [DFT_COUNT_INSURANCE_Others_Q1_Q2]
			 ,(ISNULL(COUNT_INSURANCE_Others_Q1,0) - ISNULL(COUNT_INSURANCE_Others_Q3,0)) [DFT_COUNT_INSURANCE_Others_Q1_Q3]
			 --,(ISNULL(COUNT_INSURANCE_Others_Q1,0) - ISNULL(COUNT_INSURANCE_Others_Q4,0)) [DFT_COUNT_INSURANCE_Others_Q1_Q4]
			 --,COUNT_CHECKS_Others_SP
			 ,COUNT_CHECKS_Others_Q1
			 ,(ISNULL(COUNT_CHECKS_Others_Q1,0) - ISNULL(COUNT_CHECKS_Others_Q2,0)) [DFT_COUNT_CHECKS_Others_Q1_Q2] 
			 ,(ISNULL(COUNT_CHECKS_Others_Q1,0) - ISNULL(COUNT_CHECKS_Others_Q3,0)) [DFT_COUNT_CHECKS_Others_Q1_Q3]
			 --,(ISNULL(COUNT_CHECKS_Others_Q1,0) - ISNULL(COUNT_CHECKS_Others_Q4,0)) [DFT_COUNT_CHECKS_Others_Q1_Q4]
			 --,COUNT_PAYROLL_Others_SP
			 ,COUNT_PAYROLL_Others_Q1
			 ,(ISNULL(COUNT_PAYROLL_Others_Q1,0) - ISNULL(COUNT_PAYROLL_Others_Q2,0)) [DFT_COUNT_PAYROLL_Others_Q1_Q2]
			 ,(ISNULL(COUNT_PAYROLL_Others_Q1,0) - ISNULL(COUNT_PAYROLL_Others_Q3,0)) [DFT_COUNT_PAYROLL_Others_Q1_Q3]
			 --,(ISNULL(COUNT_PAYROLL_Others_Q1,0) - ISNULL(COUNT_PAYROLL_Others_Q4,0)) [DFT_COUNT_PAYROLL_Others_Q1_Q4]
			 --,COUNT_KIOSK_Others_SP
			 ,COUNT_KIOSK_Others_Q1
			 ,(ISNULL(COUNT_KIOSK_Others_Q1,0) - ISNULL(COUNT_KIOSK_Others_Q2,0)) [DFT_COUNT_KIOSK_Others_Q1_Q2]
			 ,(ISNULL(COUNT_KIOSK_Others_Q1,0) - ISNULL(COUNT_KIOSK_Others_Q3,0)) [DFT_COUNT_KIOSK_Others_Q1_Q3]
			 --,(ISNULL(COUNT_KIOSK_Others_Q1,0) - ISNULL(COUNT_KIOSK_Others_Q4,0)) [DFT_COUNT_KIOSK_Others_Q1_Q4]
			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_Others_SP
			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1
			 ,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q2,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q2]
			 ,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q3,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q3]
			 --,(ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q4,0)) [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1_Q4]
           --,LOAN_TRANSACTION_AMOUNT_Others_SP
			 ,LOAN_TRANSACTION_AMOUNT_Others_Q1
			 ,(ISNULL(LOAN_TRANSACTION_AMOUNT_Others_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_Others_Q2,0)) [DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q2]
			 ,(ISNULL(LOAN_TRANSACTION_AMOUNT_Others_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_Others_Q3,0)) [DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q3]
			 --,(ISNULL(LOAN_TRANSACTION_AMOUNT_Others_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_Others_Q4,0)) [DFT_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q4]
			 --,INTEREST_AMOUNT_Others_SP
			 ,INTEREST_AMOUNT_Others_Q1
			 ,(ISNULL(INTEREST_AMOUNT_Others_Q1,0) - ISNULL(INTEREST_AMOUNT_Others_Q2,0)) [DFT_INTEREST_AMOUNT_Others_Q1_Q2]
			 ,(ISNULL(INTEREST_AMOUNT_Others_Q1,0) - ISNULL(INTEREST_AMOUNT_Others_Q3,0)) [DFT_INTEREST_AMOUNT_Others_Q1_Q3]
			 --,(ISNULL(INTEREST_AMOUNT_Others_Q1,0) - ISNULL(INTEREST_AMOUNT_Others_Q4,0)) [DFT_INTEREST_AMOUNT_Others_Q1_Q4]
			 --,FEEAMOUNT_Others_SP
			 ,FEEAMOUNT_Others_Q1
			 ,(ISNULL(FEEAMOUNT_Others_Q1,0) - ISNULL(FEEAMOUNT_Others_Q2,0)) [DFT_FEEAMOUNT_Others_Q1_Q2]
			 ,(ISNULL(FEEAMOUNT_Others_Q1,0) - ISNULL(FEEAMOUNT_Others_Q3,0)) [DFT_FEEAMOUNT_Others_Q1_Q3]
			 --,(ISNULL(FEEAMOUNT_Others_Q1,0) - ISNULL(FEEAMOUNT_Others_Q4,0)) [DFT_FEEAMOUNT_Others_Q1_Q4]
			 --,AVG_LOAN_TRANSACTION_AMOUNT_Others_SP
			 ,AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1
			 ,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Others_Q2,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q2]
			 ,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Others_Q3,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q3]
			 --,(ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_Others_Q4,0)) [DFT_AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1_Q4]
			 ,AVG_NEWBALANCE_Others_Q1
			 ,(ISNULL(AVG_NEWBALANCE_Others_Q1,0) - ISNULL(AVG_NEWBALANCE_Others_Q2,0)) [DFT_AVG_NEWBALANCE_Others_Q1_Q2]
			 ,(ISNULL(AVG_NEWBALANCE_Others_Q1,0) - ISNULL(AVG_NEWBALANCE_Others_Q3,0)) [DFT_AVG_NEWBALANCE_Others_Q1_Q3]
			 --,(ISNULL(AVG_NEWBALANCE_Others_Q1,0) - ISNULL(AVG_NEWBALANCE_Others_Q4,0)) [DFT_AVG_NEWBALANCE_Others_Q1_Q4]
			 --,AVG_FEEAMOUNT_Others_SP
			 ,AVG_FEEAMOUNT_Others_Q1
			 ,(ISNULL(AVG_FEEAMOUNT_Others_Q1,0) - ISNULL(AVG_FEEAMOUNT_Others_Q2,0)) [DFT_AVG_FEEAMOUNT_Others_Q1_Q2]
			 ,(ISNULL(AVG_FEEAMOUNT_Others_Q1,0) - ISNULL(AVG_FEEAMOUNT_Others_Q3,0)) [DFT_AVG_FEEAMOUNT_Others_Q1_Q3]
			 --,(ISNULL(AVG_FEEAMOUNT_Others_Q1,0) - ISNULL(AVG_FEEAMOUNT_Others_Q4,0)) [DFT_AVG_FEEAMOUNT_Others_Q1_Q4]
			  INTO #LOAN_TRANSACTION_derived_vars 
			  FROM #transaction_loan

			  DROP TABLE IF EXISTS #LOAN_TRANSACTION_MASTER
			  SELECT A.*,B.SSN SSN002
			   into #LOAN_TRANSACTION_MASTER
			   FROM 
			  #LOAN_TRANSACTION_derived_vars A
			  LEFT JOIN #Static_SSN_account B
			  ON A.PARENTACCOUNT = B.AccountNumber

			  --SELECT COUNT(DISTINCT SSN_000) FROM #LOAN_TRANSACTION_MASTER
			  --where SSN_000 not in (SELECT SSN from #loan_woCC) -- 3239

			  --SELECT COUNT(DISTINCT SSN) FROM #loan_woCC
			  --where SSN not in (SELECT SSN_000 from #LOAN_TRANSACTION_MASTER) --27399

			  DROP TABLE IF EXISTS #loan_product_summary
			 
			 SELECT A.*,B.*
			  into #loan_product_summary
			   FROM #loan_product_holdings A
			  LEFT JOIN
			  #LOAN_TRANSACTION_MASTER B
			  ON A.SSN001 = B.SSN002

			 --DROP TABLE IF EXISTS #updated_loan_product_summary
			 
			 --SELECT CASE WHEN A.SSN001 = B.SSN002 THEN A.SSN001
			 --            WHEN A.SSN001 is null then B.SSN002
			 --		       WHEN B.SSN002 is null then A.SSN001 END [SSN_LOAN]
			 --,A.*,B.*
			 -- into #updated_loan_product_summary
			 --  FROM #loan_product_holdings A
			 -- FULL OUTER JOIN
			 -- #LOAN_TRANSACTION_MASTER B
			 -- ON A.SSN001 = B.SSN002

			  --SELECT DISTINCT SSN002 FROM #LOAN_TRANSACTION_MASTER where SSN002 not in (SELECT DISTINCT SSN001 from #loan_product_holdings) --3239
			   --SELECT DISTINCT SSN001 from #loan_product_holdings where SSN001 not in (SELECT DISTINCT SSN002 FROM #LOAN_TRANSACTION_MASTER) --27399


------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Credit Card ***\\\-------------------------------------------------------------------
			

			 
  drop table if exists #CC_Members_Static
  

	  select distinct [Social Security Number] 
	  into #CC_Members_Static
	  from TMGData.dbo.cardholder 
	  where Active_Flag=1 and ([External Status Code]='' or [Internal Status Code] in ('N',''))
	  and extract_datepart=left(convert(varchar,@staticpooldate,112),6)
	  --and datediff(MONTH,[Date First Active New],@staticpooldate) >= 6   
	   

			


		 drop table if exists #CC_data	
		
		
		select * 
		into #CC_data
		from 
		(
		SELECT  [Durable_Key]
		,case when extract_datepart in (left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-11,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-10,@staticpooldate),112),6)) then 'Q4'
		    when extract_datepart in (left(convert(varchar,dateadd(month,-9,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-8,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-7,@staticpooldate),112),6)) then 'Q3'
		    when extract_datepart in (left(convert(varchar,dateadd(month,-6,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-5,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-4,@staticpooldate),112),6)) then 'Q2'
		    when extract_datepart in (left(convert(varchar,dateadd(month,-3,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-2,@staticpooldate),112),6),left(convert(varchar,dateadd(month,-1,@staticpooldate),112),6)) then 'Q1'
		    when extract_datepart in (left(convert(varchar,@staticpooldate,112),6)) then 'Staticpool' end Quarters
       ,[Social Security Number]
      ,[Credit Limit]
      ,[Extract Date]
       ,[AGE]
      ,[Account System Entry Date]
      ,[Card Account Debit Activity Code]
      ,[Last Statement Payment Count]
      ,[Last Statement Payment Amount]
      ,[Last Statement Sale Amount]
      ,[Last Statement Cash Amount]
      ,[Last Statement Return Amount]
      ,[Last Statment Sale Count]
      ,[Last Statement Cash Advance Count]
      ,[Last Statement Return Count]
      ,[Last Statement External Fee Amount]
      ,[Last Statement Credit Life Change Amount]
      ,[Last Statement Charge Late Amount]
      ,[Last Statement Charge Cash Amount]
      ,[Last Statement Charge Overlimit Amount]
      ,[Last Statement Charge Sale Amount]
      ,[Last Statement Merchandise Average Daily Balance Amount]
      ,[Last Statement Cash Average Daily Balance Amount]
      ,[Last Statement Average Daily Balance Amount]
      ,[Calc Norm Cash Annual Rate]
      ,[Calc Norm Mrch Annual Rate]
      ,[Charge-Off Amount]
      ,[Card Account Charge-Off Date]
      ,[Card Description]
      ,[Card Account Delinquent Day Account]
      ,[Total Amount Account Delinquency]
      ,[Last Statement Cash Interest Amount]
      ,[Accumulated Merchandise Interest Amount]
      ,[Last Statement Balance Amount]
      ,[Last Statement Revolving Merchandise Amount]
      ,[extract_datepart]
      ,[Extract_ACCOUNT_OPEN_DATE]
      ,[spend]
      ,[Protected_Balance]
      ,[Promo_Balance]
      ,[Protected_Current_Interest]
      ,[Promo_Current_Interest]
      ,[RevolvingBalance]
      ,[Closed_account_flag]
      ,[mob]
      ,[ChargeoffAmount_final]
      ,[ChargeOff_Extract_DatePart]
	   ,TRIPFLAG
  FROM TMGData.dbo.cardholder 	-- Changed 042222
  where [Social Security Number] in (select [Social Security Number] from #CC_Members_Static)
  and Active_Flag=1
   ) a
    where  quarters is not null 
  ----and mob>=12  ---commented by nikita on 05/10/2022

--- Drift of CC data

		 Drop table if exists #Credit_Card_data
		select 
		SSN_CC
		,[Last Statement Payment Count_CC_Staticpool]
		,[Last Statement Payment Count_CC_Q1]
		,(ISNULL([Last Statement Payment Count_CC_Q1],0)-ISNULL([Last Statement Payment Count_CC_Q2],0)) [DFT_Last Statement Payment Count_CC_Q1_Q2]
		,(ISNULL([Last Statement Payment Count_CC_Q1],0)-ISNULL([Last Statement Payment Count_CC_Q3],0)) [DFT_Last Statement Payment Count_CC_Q1_Q3]
		--,(ISNULL([Last Statement Payment Count_CC_Q1],0)-ISNULL([Last Statement Payment Count_CC_Q4],0)) [DFT_Last Statement Payment Count_CC_Q1_Q4]
		,[Last Statement Payment Amount)_CC_Staticpool]
		,[Last Statement Payment Amount_CC_Q1]
		,(ISNULL([Last Statement Payment Amount_CC_Q1],0)-ISNULL([Last Statement Payment Amount_CC_Q2],0)) [DFT_Last Statement Payment Amount_CC_Q1_Q2]
		,(ISNULL([Last Statement Payment Amount_CC_Q1],0)-ISNULL([Last Statement Payment Amount_CC_Q3],0)) [DFT_Last Statement Payment Amount_CC_Q1_Q3]
		--,(ISNULL([Last Statement Payment Amount_CC_Q1],0)-ISNULL([Last Statement Payment Amount_CC_Q4],0)) [DFT_Last Statement Payment Amount_CC_Q1_Q4]
		,[Last Statement Sale Amount_CC_Staticpool]
		,[Last Statement Sale Amount_CC_Q1]
		,(ISNULL([Last Statement Sale Amount_CC_Q1],0)-ISNULL([Last Statement Sale Amount_CC_Q2],0)) [DFT_Last Statement Sale Amount_CC_Q1_Q2]
		,(ISNULL([Last Statement Sale Amount_CC_Q1],0)-ISNULL([Last Statement Sale Amount_CC_Q3],0)) [DFT_Last Statement Sale Amount_CC_Q1_Q3]
		--,(ISNULL([Last Statement Sale Amount_CC_Q1],0)-ISNULL([Last Statement Sale Amount_CC_Q4],0)) [DFT_Last Statement Sale Amount_CC_Q1_Q4]
		,[Last Statement Cash Amount_CC_Staticpool]
		,[Last Statement Cash Amount_CC_Q1]
		,(ISNULL([Last Statement Cash Amount_CC_Q1],0)-ISNULL([Last Statement Cash Amount_CC_Q2],0)) [DFT_Last Statement Cash Amount_CC_Q1_Q2]
		,(ISNULL([Last Statement Cash Amount_CC_Q1],0)-ISNULL([Last Statement Cash Amount_CC_Q3],0)) [DFT_Last Statement Cash Amount_CC_Q1_Q3]
		--,(ISNULL([Last Statement Cash Amount_CC_Q1],0)-ISNULL([Last Statement Cash Amount_CC_Q4],0)) [DFT_Last Statement Cash Amount_CC_Q1_Q4]
		,[Last Statement Return Amount_CC_Staticpool]
		,[Last Statement Return Amount_CC_Q1]
		,(ISNULL([Last Statement Return Amount_CC_Q1],0)-ISNULL([Last Statement Return Amount_CC_Q2],0)) [DFT_Last Statement Return Amount_CC_Q1_Q2]
		,(ISNULL([Last Statement Return Amount_CC_Q1],0)-ISNULL([Last Statement Return Amount_CC_Q3],0)) [DFT_Last Statement Return Amount_CC_Q1_Q3]
		--,(ISNULL([Last Statement Return Amount_CC_Q1],0)-ISNULL([Last Statement Return Amount_CC_Q4],0)) [DFT_Last Statement Return Amount_CC_Q1_Q4]
		,[Last Statement Sale Count_CC_Staticpool]
		,[Last Statement Sale Count_CC_Q1]
		,(ISNULL([Last Statement Sale Count_CC_Q1],0)-ISNULL([Last Statement Sale Count_CC_Q2],0)) [DFT_Last Statement Sale Count_CC_Q1_Q2]
		,(ISNULL([Last Statement Sale Count_CC_Q1],0)-ISNULL([Last Statement Sale Count_CC_Q3],0)) [DFT_Last Statement Sale Count_CC_Q1_Q3]
		--,(ISNULL([Last Statement Sale Count_CC_Q1],0)-ISNULL([Last Statement Sale Count_CC_Q4],0)) [DFT_Last Statement Sale Count_CC_Q1_Q4]
		,[Last Statement Cash Advance Count_CC_Staticpool]
		,[Last Statement Cash Advance Count_CC_Q1]
		,(ISNULL([Last Statement Cash Advance Count_CC_Q1],0)-ISNULL([Last Statement Cash Advance Count_CC_Q2],0)) [DFT_Last Statement Cash Advance Count_CC_Q1_Q2]
		,(ISNULL([Last Statement Cash Advance Count_CC_Q1],0)-ISNULL([Last Statement Cash Advance Count_CC_Q3],0)) [DFT_Last Statement Cash Advance Count_CC_Q1_Q3]
		--,(ISNULL([Last Statement Cash Advance Count_CC_Q1],0)-ISNULL([Last Statement Cash Advance Count_CC_Q4],0)) [DFT_Last Statement Cash Advance Count_CC_Q1_Q4]
		,[Last Statement Return Count_CC_Staticpool]
		,[Last Statement Return Count_CC_Q1]
		,(ISNULL([Last Statement Return Count_CC_Q1],0)-ISNULL([Last Statement Return Count_CC_Q2],0)) [DFT_Last Statement Return Count_CC_Q1_Q2]
		,(ISNULL([Last Statement Return Count_CC_Q1],0)-ISNULL([Last Statement Return Count_CC_Q3],0)) [DFT_Last Statement Return Count_CC_Q1_Q3]
		--,(ISNULL([Last Statement Return Count_CC_Q1],0)-ISNULL([Last Statement Return Count_CC_Q4],0)) [DFT_Last Statement Return Count_CC_Q1_Q4]
		,[Last Statement External Fee Amount_CC_Staticpool]
		,[Last Statement External Fee Amount_CC_Q1]
		,(ISNULL([Last Statement External Fee Amount_CC_Q1],0)-ISNULL([Last Statement External Fee Amount_CC_Q2],0)) [DFT_Last Statement External Fee Amount_CC_Q1_Q2]
		,(ISNULL([Last Statement External Fee Amount_CC_Q1],0)-ISNULL([Last Statement External Fee Amount_CC_Q3],0)) [DFT_Last Statement External Fee Amount_CC_Q1_Q3]
		--,(ISNULL([Last Statement External Fee Amount_CC_Q1],0)-ISNULL([Last Statement External Fee Amount_CC_Q4],0)) [DFT_Last Statement External Fee Amount_CC_Q1_Q4]
		,[Last Statement Credit Life Change Amount_CC_Staticpool]
		,[Last Statement Credit Life Change Amount_CC_Q1]
		,(ISNULL([Last Statement Credit Life Change Amount_CC_Q1],0)-ISNULL([Last Statement Credit Life Change Amount_CC_Q2],0)) [DFT_Last Statement Credit Life Change Amount_CC_Q1_Q2]
		,(ISNULL([Last Statement Credit Life Change Amount_CC_Q1],0)-ISNULL([Last Statement Credit Life Change Amount_CC_Q3],0)) [DFT_Last Statement Credit Life Change Amount_CC_Q1_Q3]
		--,(ISNULL([Last Statement Credit Life Change Amount_CC_Q1],0)-ISNULL([Last Statement Credit Life Change Amount_CC_Q4],0)) [DFT_Last Statement Credit Life Change Amount_CC_Q1_Q4]
		,[Last Statement Charge Late Amount_CC_Staticpool]
		,[Last Statement Charge Late Amount_CC_Q1]
		,(ISNULL([Last Statement Charge Late Amount_CC_Q1],0)-ISNULL([Last Statement Charge Late Amount_CC_Q2],0)) [DFT_Last Statement Charge Late Amount_CC_Q1_Q2]
		,(ISNULL([Last Statement Charge Late Amount_CC_Q1],0)-ISNULL([Last Statement Charge Late Amount_CC_Q3],0)) [DFT_Last Statement Charge Late Amount_CC_Q1_Q3]
		--,(ISNULL([Last Statement Charge Late Amount_CC_Q1],0)-ISNULL([Last Statement Charge Late Amount_CC_Q4],0)) [DFT_Last Statement Charge Late Amount_CC_Q1_Q4]
		,[Last Statement Charge Cash Amount_CC_Staticpool]
		,[Last Statement Charge Cash Amount_CC_Q1]
		,(ISNULL([Last Statement Charge Cash Amount_CC_Q1],0)-ISNULL([Last Statement Charge Cash Amount_CC_Q2],0)) [DFT_Last Statement Charge Cash Amount_CC_Q1_Q2]
		,(ISNULL([Last Statement Charge Cash Amount_CC_Q1],0)-ISNULL([Last Statement Charge Cash Amount_CC_Q3],0)) [DFT_Last Statement Charge Cash Amount_CC_Q1_Q3]
		--,(ISNULL([Last Statement Charge Cash Amount_CC_Q1],0)-ISNULL([Last Statement Charge Cash Amount_CC_Q4],0)) [DFT_Last Statement Charge Cash Amount_CC_Q1_Q4]
		,[Last Statement Charge Overlimit Amount_CC_Staticpool]
		,[Last Statement Charge Overlimit Amount_CC_Q1]
		,(ISNULL([Last Statement Charge Overlimit Amount_CC_Q1],0)-ISNULL([Last Statement Charge Overlimit Amount_CC_Q2],0))  [DFT_Last Statement Charge Overlimit Amount_CC_Q1_Q2]
		,(ISNULL([Last Statement Charge Overlimit Amount_CC_Q1],0)-ISNULL([Last Statement Charge Overlimit Amount_CC_Q3],0))  [DFT_Last Statement Charge Overlimit Amount_CC_Q1_Q3]
		--,(ISNULL([Last Statement Charge Overlimit Amount_CC_Q1],0)-ISNULL([Last Statement Charge Overlimit Amount_CC_Q4],0))  [DFT_Last Statement Charge Overlimit Amount_CC_Q1_Q4]
		,[Last Statement Charge Sale Amount_CC_Staticpool]
		,[Last Statement Charge Sale Amount_CC_Q1]
		,(ISNULL([Last Statement Charge Sale Amount_CC_Q1],0) - ISNULL([Last Statement Charge Sale Amount_CC_Q2],0)) [DFT_Last Statement Charge Sale Amount_CC_Q1_Q2]
		,(ISNULL([Last Statement Charge Sale Amount_CC_Q1],0) - ISNULL([Last Statement Charge Sale Amount_CC_Q3],0)) [DFT_Last Statement Charge Sale Amount_CC_Q1_Q3]
		--,(ISNULL([Last Statement Charge Sale Amount_CC_Q1],0) - ISNULL([Last Statement Charge Sale Amount_CC_Q4],0)) [DFT_Last Statement Charge Sale Amount_CC_Q1_Q4]
		,[Last Statement Merchandise Average Daily Balance Amount_CC_Staticpool]
		,[Last Statement Merchandise Average Daily Balance Amount_CC_Q1]
		,(ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_Q1],0) - ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_Q2],0)) [DFT_Last Statement Merchandise Average Daily Balance Amount_CC_Q1_Q2]
		,(ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_Q1],0) - ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_Q3],0)) [DFT_Last Statement Merchandise Average Daily Balance Amount_CC_Q1_Q3]
		--,(ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_Q1],0) - ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_Q4],0)) [DFT_Last Statement Merchandise Average Daily Balance Amount_CC_Q1_Q4]
		,[Last Statement Cash Average Daily Balance Amount_CC_Staticpool]
		,[Last Statement Cash Average Daily Balance Amount_CC_Q1]
		,(ISNULL([Last Statement Cash Average Daily Balance Amount_CC_Q1],0)- ISNULL([Last Statement Cash Average Daily Balance Amount_CC_Q2],0)) [DFT_Last Statement Cash Average Daily Balance Amount_CC_Q1_Q2]
		,(ISNULL([Last Statement Cash Average Daily Balance Amount_CC_Q1],0)- ISNULL([Last Statement Cash Average Daily Balance Amount_CC_Q3],0)) [DFT_Last Statement Cash Average Daily Balance Amount_CC_Q1_Q3]
		--,(ISNULL([Last Statement Cash Average Daily Balance Amount_CC_Q1],0)- ISNULL([Last Statement Cash Average Daily Balance Amount_CC_Q4],0)) [DFT_Last Statement Cash Average Daily Balance Amount_CC_Q1_Q4]
		,[Last Statement Average Daily Balance Amount_CC_Staticpool]
		,[Last Statement Average Daily Balance Amount_CC_Q1]
		,(ISNULL([Last Statement Average Daily Balance Amount_CC_Q1],0)-ISNULL([Last Statement Average Daily Balance Amount_CC_Q2],0)) [DFT_Last Statement Average Daily Balance Amount_CC_Q1_Q2]
		,(ISNULL([Last Statement Average Daily Balance Amount_CC_Q1],0)-ISNULL([Last Statement Average Daily Balance Amount_CC_Q3],0)) [DFT_Last Statement Average Daily Balance Amount_CC_Q1_Q3]
		--,(ISNULL([Last Statement Average Daily Balance Amount_CC_Q1],0)-ISNULL([Last Statement Average Daily Balance Amount_CC_Q4],0)) [DFT_Last Statement Average Daily Balance Amount_CC_Q1_Q4]
		,[spend_CC_Staticpool]
		,[spend_CC_Q1]
		,(ISNULL(spend_CC_Q1,0)- ISNULL(spend_CC_Q2,0)) [DFT_spend_CC_Q1_Q2]
		,(ISNULL(spend_CC_Q1,0)- ISNULL(spend_CC_Q3,0)) [DFT_spend_CC_Q1_Q3]
		--,(ISNULL(spend_CC_Q1,0)- ISNULL(spend_CC_Q4,0)) [DFT_spend_CC_Q1_Q4]
		,[Protected_Balance_CC_Staticpool]
		,[Protected_Balance_CC_Q1]
		,(ISNULL([Protected_Balance_CC_Q1],0)-ISNULL([Protected_Balance_CC_Q2],0)) [DFT_Protected_Balance_CC_Q1_Q2]
		,(ISNULL([Protected_Balance_CC_Q1],0)-ISNULL([Protected_Balance_CC_Q3],0)) [DFT_Protected_Balance_CC_Q1_Q3]
		--,(ISNULL([Protected_Balance_CC_Q1],0)-ISNULL([Protected_Balance_CC_Q4],0)) [DFT_Protected_Balance_CC_Q1_Q4]
		,[Promo_Balance_CC_Staticpool]
		,[Promo_Balance_CC_Q1]
		,(ISNULL([Promo_Balance_CC_Q1],0)-ISNULL([Promo_Balance_CC_Q2],0)) [DFT_Promo_Balance_CC_Q1_Q2]
		,(ISNULL([Promo_Balance_CC_Q1],0)-ISNULL([Promo_Balance_CC_Q3],0)) [DFT_Promo_Balance_CC_Q1_Q3]
		--,(ISNULL([Promo_Balance_CC_Q1],0)-ISNULL([Promo_Balance_CC_Q4],0)) [DFT_Promo_Balance_CC_Q1_Q4]
		,[Protected_Current_Interest_CC_Staticpool]
		,[Protected_Current_Interest_CC_Q1]
		,(ISNULL([Protected_Current_Interest_CC_Q1],0)- ISNULL([Protected_Current_Interest_CC_Q2],0)) [DFT_Protected_Current_Interest_CC_Q1_Q2]
		,(ISNULL([Protected_Current_Interest_CC_Q1],0)- ISNULL([Protected_Current_Interest_CC_Q3],0)) [DFT_Protected_Current_Interest_CC_Q1_Q3]
		--,(ISNULL([Protected_Current_Interest_CC_Q1],0)- ISNULL([Protected_Current_Interest_CC_Q4],0)) [DFT_Protected_Current_Interest_CC_Q1_Q4]
		,[Promo_Current_Interest_CC_Staticpool]
		,[Promo_Current_Interest_CC_Q1]
		,(ISNULL([Promo_Current_Interest_CC_Q1],0)- ISNULL([Promo_Current_Interest_CC_Q2],0)) [DFT_Promo_Current_Interest_CC_Q1_Q2]
		,(ISNULL([Promo_Current_Interest_CC_Q1],0)- ISNULL([Promo_Current_Interest_CC_Q3],0)) [DFT_Promo_Current_Interest_CC_Q1_Q3]
		--,(ISNULL([Promo_Current_Interest_CC_Q1],0)- ISNULL([Promo_Current_Interest_CC_Q4],0)) [DFT_Promo_Current_Interest_CC_Q1_Q4]
		,[RevolvingBalance_CC_Staticpool]
		,[RevolvingBalance_CC_Q1]
		,(ISNULL([RevolvingBalance_CC_Q1],0)-ISNULL([RevolvingBalance_CC_Q2],0)) [DFT_RevolvingBalance_CC_Q1_Q2]
		,(ISNULL([RevolvingBalance_CC_Q1],0)-ISNULL([RevolvingBalance_CC_Q3],0)) [DFT_RevolvingBalance_CC_Q1_Q3]
		--,(ISNULL([RevolvingBalance_CC_Q1],0)-ISNULL([RevolvingBalance_CC_Q4],0)) [DFT_RevolvingBalance_CC_Q1_Q4]

		--,[Social Security Number_CC]
		,Count_Durable_CC
		,max_credit_Limit
		,max_age_member_CC
		,[Max_Extract_ACCOUNT_OPEN_DATE_CC]
		,[Max_Closed_account_flag_CC]
		,Max_MOB_CC
		,ChargeoffAmount_final_CC
		,Max_chargoff_date_CC

		--,SSN_00
		,CL_CC_StaticPool
		,MOB_CC_staticPool
		,TRIP_FLAG_staticpool

		,(CL_CC_StaticPool-CreditLimit_CC_Q1) CL_DIFF_past_oneyear
		into #Credit_Card_data
		from 
		(
		select [Social Security Number] SSN_CC
		
			,SUM(case when Quarters='Q1' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q1]
			,SUM(case when Quarters='Q1' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then [spend] END) [spend_CC_Q1]
			,SUM(case when Quarters='Q1' then [Protected_Balance] END) [Protected_Balance_CC_Q1]
			,SUM(case when Quarters='Q1' then [Promo_Balance] END) [Promo_Balance_CC_Q1]
			,SUM(case when Quarters='Q1' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q1]
			,SUM(case when Quarters='Q1' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q1]
			,SUM(case when Quarters='Q1' then [RevolvingBalance] END) [RevolvingBalance_CC_Q1]
			,max(case when Quarters='Q1' then [Credit Limit] end ) [CreditLimit_CC_Q1]

			,SUM(case when Quarters='Q2' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q2]
			,SUM(case when Quarters='Q2' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then [spend] END) [spend_CC_Q2]
			,SUM(case when Quarters='Q2' then [Protected_Balance] END) [Protected_Balance_CC_Q2]
			,SUM(case when Quarters='Q2' then [Promo_Balance] END) [Promo_Balance_CC_Q2]
			,SUM(case when Quarters='Q2' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q2]
			,SUM(case when Quarters='Q2' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q2]
			,SUM(case when Quarters='Q2' then [RevolvingBalance] END) [RevolvingBalance_CC_Q2]

			,SUM(case when Quarters='Q3' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q3]
			,SUM(case when Quarters='Q3' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then [spend] END) [spend_CC_Q3]
			,SUM(case when Quarters='Q3' then [Protected_Balance] END) [Protected_Balance_CC_Q3]
			,SUM(case when Quarters='Q3' then [Promo_Balance] END) [Promo_Balance_CC_Q3]
			,SUM(case when Quarters='Q3' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q3]
			,SUM(case when Quarters='Q3' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q3]
			,SUM(case when Quarters='Q3' then [RevolvingBalance] END) [RevolvingBalance_CC_Q3]

			,SUM(case when Quarters='Q4' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q4]
			,SUM(case when Quarters='Q4' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then [spend] END) [spend_CC_Q4]
			,SUM(case when Quarters='Q4' then [Protected_Balance] END) [Protected_Balance_CC_Q4]
			,SUM(case when Quarters='Q4' then [Promo_Balance] END) [Promo_Balance_CC_Q4]
			,SUM(case when Quarters='Q4' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q4]
			,SUM(case when Quarters='Q4' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q4]
			,SUM(case when Quarters='Q4' then [RevolvingBalance] END) [RevolvingBalance_CC_Q4]

			,SUM(case when Quarters='Staticpool' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Last Statement Payment Amount] END) [Last Statement Payment Amount)_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [spend] END) [spend_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Protected_Balance] END) [Protected_Balance_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Promo_Balance] END) [Promo_Balance_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [RevolvingBalance] END) [RevolvingBalance_CC_Staticpool]
			
			  from #CC_data
			  group by [Social Security Number]
			  ) a

		  left join (     
					  select [Social Security Number]  [Social Security Number_CC]
							,count(distinct Durable_Key) Count_Durable_CC
							,Max([Credit Limit]) max_credit_Limit
							,max(AGE) max_age_member_CC
							,max([Extract_ACCOUNT_OPEN_DATE]) [Max_Extract_ACCOUNT_OPEN_DATE_CC]
							,max([Closed_account_flag]) [Max_Closed_account_flag_CC]
						    ,max([mob]) Max_MOB_CC
					        ,sum([ChargeoffAmount_final]) ChargeoffAmount_final_CC
						    ,max([ChargeOff_Extract_DatePart]) Max_chargoff_date_CC
						 from #CC_data
						 group by [Social Security Number]
					 ) b
					 on a.SSN_CC=b.[Social Security Number_CC]
			 left join 			
					 (
					 select [Social Security Number] SSN_00,max([Credit Limit]) CL_CC_StaticPool
					 ,max(mob) MOB_CC_staticPool
					 ,max(case when TRIPFLAG='T' then 1
					 when TRIPFLAG='R' then 2
					 when TRIPFLAG='I' then 3
					 when TRIPFLAG='P' then 4 else null end) TRIP_FLAG_staticpool from #cc_data
					 where Quarters='staticpool'
					 group by [Social Security Number]
					 ) w
			 on a.ssn_cc=w.SSN_00	
			 
			 
			 DROP TABLE IF EXISTS #loan_product_master		   

			 SELECT a.* ,b.*
			 INTO #loan_product_master
			 FROM #loan_product_summary A
			 LEFT JOIN
			 #Credit_Card_data B
			 on A.SSN001 = B.SSN_CC --157375

			 --DROP TABLE IF EXISTS #updated_loan_product_master		   

			 --SELECT CASE WHEN A.SSN_LOAN = B.SSN_CC THEN SSN_LOAN
			 --            WHEN A.SSN_LOAN IS NULL THEN B.SSN_CC
			 --		       WHEN B.SSN_CC IS NULL THEN A.SSN_LOAN END [SSN_L],
			 --A.* ,B.*
			 --INTO #updated_loan_product_master	
			 --FROM #updated_loan_product_summary A
			 --FULL OUTER JOIN
			 --#Credit_Card_data B
			 --on A.SSN_LOAN = B.SSN_CC

			 --SELECT  SSN_CC FROM  #Credit_Card_data
			 --where SSN_CC not in (SELECT SSN FROM #loan_product_summary ) --0
			 --SELECT TOP 10 * into Analytics.dbo.SNSN FROM #loan_product_master

------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** DEPOSITS ***\\\-------------------------------------------------------------------

		--	  drop table if exists #groupproducttype_Deposits  ---grouping table updated by Nikita 03/06/2022
		--select *
		--,case when productname like '%business%' or  productname like '%commercial%'
		-- or productname like '%professional%' or productcode in  ('143','5080','105','149','5013')
	 --then 1 else 0 end Businessflag 
		--into #groupproducttype_Deposits
		--from
		--	(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName,ApplicationDescription,ApplicationTableName
		--	 from [AE_EDW].[tempods].[S_CRMProductType] a
		--	left join [AE_EDW].[tempods].[S_CRMApplicationType] b
		--	on a.ApplicationTypeID=b.ApplicationTypeID
		--	where ApplicationDescription is not null and ProductName!='IRA Savings'
		--	and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a

  --       DROP TABLE IF EXISTS #ShareCategory
  --       SELECT * 
  --       INTO #ShareCategory
  --       FROM
  --       (SELECT B.*,A.Businessflag 
		-- ,CASE WHEN A.ProductName = B.ShareTypeDescription THEN 1 ELSE 0 END [Description Flag]
		-- FROM #groupproducttype_Deposits A
  --       left Join 
  --       ARCUSYM000.ARCU.ARCUShareCategory B
  --       on A.ProductName = B.ShareTypeDescription) W
  --       where [Description Flag] = 1
  --       and ShareCategory3 not in ('IRA','HSA')

  DROP TABLE IF EXISTS #ShareCategory
 -- Consumer & Commercial Category in Money Market
  	SELECT * 
	into #ShareCategory 
	from ARCUSYM000.ARCU.ARCUShareCategory
	where ShareCategory3 not in ('HSA','IRA') 
		and ShareCategory1 <> 'Non-Member'
		and ShareType <> '9997'   --234 (excluding Greenstate Corporate Checking)
		
   
------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Membership Data (ShareCategorywise) ***\\\-------------------------------------------------------------------

    DROP TABLE IF EXISTS #deposits_account_data

		select SSN
		      ,UNID
			  ,ProcessDate
			  ,PARENTACCOUNT
			  ,id
			  ,TYPE
			  ,LASTDIVAMOUNT
			  ,BALANCE Month_end_balance
		      ,CHARGEOFFAMOUNT
			  ,CHARGEOFFDATE
			  ,CHARGEOFFTYPE
			  ,Closed_flag
			  ,left(ProcessDate,6) ProcessDate_v
		      ,close_date,open_date
			  ,process_date 
			  ,Quarters
			  ,MOB
			  --,StaticPool_Saving_flag
			  , CASE WHEN ShareCategory2 = 'Savings' then 'Savings'
			         WHEN ShareCategory2 = 'Checking' then 'Checking'
					 WHEN ShareCategory2 = 'CD' then 'Certificates'
					 WHEN ShareCategory2 = 'Money Market' then 'MoneyMarket' 
					 ELSE 'OTHERS' END [Deposit_Flag] --GREENSTATE CORPORATE CHECKING is the only in others
		into #deposits_account_data 
		from 
		(
		select  
		d.SSN
		,case when Process_Date in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		 when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
		  when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
		   when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
		   when Process_Date in (@staticpooldate) then 'Staticpool'
		  end Quarters
		   ,DATEDIFF(MONTH,OPEN_DATE,@staticpooldate) MOB
		   --,case when ShareCategory2='savings' and Process_Date =@staticpooldate then 1 else 0 end StaticPool_Saving_flag
		,aa.*,c.Closed_flag
		,case when aa.close_date is null then '' 
		when len(month(aa.close_date))=1 then CONCAT(year(aa.close_date),0,month(aa.close_date))
		else CONCAT(year(aa.close_date),month(aa.close_date)) end  Closed_date_INT
		,case when len(month(aa.open_date))=1 then CONCAT(year(aa.open_date),0,month(aa.open_date))
		else CONCAT(year(aa.open_date),month(aa.open_date)) end  OPEN_date_INT_INT
		,E.ShareTypeDescription,E.ShareCategory2
		,case when ShareCategory2='CD' and BALANCE=0 then 0 else 1 end carryforward_flag ----not understood
		from 
					(select * from
							(	select *,case when [EOM_Process Date]=[Process Date] then 1 else 0 end EOM_flag 
										,case when (closedate is null and CHARGEOFFDATE is null) or ProcessDate_v=Close_date_v 
										or ProcessDate_v=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
										,case when OPEN_DATE=CLOSE_DATE then 0 else 1 end Funded_loan_flag
										,lag(Open_date,1) over (partition by Concat(parentaccount,id) order by processdate) Lag_opendate
											,lag(type,1) over (partition by Concat(parentaccount,id) order by processdate) Lag_Type
											,concat(PARENTACCOUNT,ID) UNID
										from
											(select a.*,EOMONTH([Process Date]) [EOM_Process Date]
											,case when ProcessDate_v=CHARGEOFFDATE_v then CHARGEOFFAMOUNT else 0 end CHARGEOFFAMOUNT_v
											,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
											else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date_v
											,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
											,cast(OPENDATE as date) Open_date
											,cast(CLOSEDATE as date) Close_date
											 from 
												 ( select * ,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
												 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v
												 ,left(ProcessDate,6) ProcessDate_v
												,datefromparts(left(processdate,4),right(left(processdate,6),2),right(processdate,2)) [Process Date] 
												from arcusym000.dbo.SAVINGS
												--where (chargeoffdate is null or chargeoffdate>='2021-11-01')
												) a
												 
											) F
								 ) aaa
								  where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
					 ) aa
		left join 
				(select UNID,max(closed_flag) Closed_flag
				from
						(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when CLOSEDATE is null then 0 else 1 end closed_flag
						from 
								(select distinct PARENTACCOUNT,ID,CLOSEDATE 
								from [ARCUSYM000].dbo.SAVINGS
								 where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
								 ) a 
						 )b
				group by UNID
				) c
		on aa.UNID=c.UNID
		left join #Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join #ShareCategory E
		on e.ShareType=aa.TYPE
		where Process_Date in (DATEADD(month,-12,@staticpooldate),DATEADD(month,-11,@staticpooldate),DATEADD(month,-10,@staticpooldate),DATEADD(month,-9,@staticpooldate),DATEADD(month,-8,@staticpooldate)
			,DATEADD(month,-7,@staticpooldate),DATEADD(month,-6,@staticpooldate),DATEADD(month,-5,@staticpooldate),DATEADD(month,-4,@staticpooldate),DATEADD(month,-3,@staticpooldate),DATEADD(month,-2,@staticpooldate),DATEADD(month,-1,@staticpooldate)
			,@staticpooldate,DATEADD(month,1,@staticpooldate),DATEADD(month,2,@staticpooldate),DATEADD(month,3,@staticpooldate),DATEADD(month,4,@staticpooldate),DATEADD(month,5,@staticpooldate),DATEADD(month,6,@staticpooldate),DATEADD(month,7,@staticpooldate)
			,DATEADD(month,8,@staticpooldate),DATEADD(month,9,@staticpooldate),DATEADD(month,10,@staticpooldate),DATEADD(month,11,@staticpooldate),DATEADD(month,12,@staticpooldate))
		and PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
		) ZZ
		where 1 = 1
		--and ShareCategory2 ='Savings'  
		and open_date<@staticpooldate and (close_date is null or close_date>@staticpooldate)
		and Funded_loan_flag=1 and Quarters is not null and Open_Flag=1 and carryforward_flag=1
		order by UNID,ProcessDate,TYPE

		--SELECT DISTINCT SSN FROM #deposits_account_data where Process_Date = '2021-08-31' -- 321868

		DROP TABLE IF EXISTS #membership_deposits

		SELECT A.SSN [SSN003]
		      ,ISNULL(PRODUCT_SAVINGS_SP,0) [PRODUCT_SAVINGS_SP]
		      ,ISNULL(PRODUCT_SAVINGS_Q1,0) [PRODUCT_SAVINGS_Q1]
			  ,(ISNULL(PRODUCT_SAVINGS_Q1,0) - ISNULL(PRODUCT_SAVINGS_Q2,0)) [DFT_PRODUCT_SAVINGS_Q1_Q2]
			  ,(ISNULL(PRODUCT_SAVINGS_Q1,0) - ISNULL(PRODUCT_SAVINGS_Q3,0)) [DFT_PRODUCT_SAVINGS_Q1_Q3]
			  --,(ISNULL(PRODUCT_SAVINGS_Q1,0) - ISNULL(PRODUCT_SAVINGS_Q4,0)) [DFT_PRODUCT_SAVINGS_Q1_Q4]
			  --,ISNULL(TYPE_SAVINGS_SP,0) [TYPE_SAVINGS_SP]
			  ,ISNULL(TYPE_SAVINGS_Q1,0) [TYPE_SAVINGS_Q1]
			  ,(ISNULL(TYPE_SAVINGS_Q1,0) - ISNULL(TYPE_SAVINGS_Q2,0)) [DFT_TYPE_SAVINGS_Q1_Q2]
			  ,(ISNULL(TYPE_SAVINGS_Q1,0) - ISNULL(TYPE_SAVINGS_Q3,0)) [DFT_TYPE_SAVINGS_Q1_Q3]
			  --,(ISNULL(TYPE_SAVINGS_Q1,0) - ISNULL(TYPE_SAVINGS_Q4,0)) [DFT_TYPE_SAVINGS_Q1_Q4]
			  ,MOB_SAVINGS
			  --,SUM_MONTH_END_BALANCE_SAVINGS_Q1
			  --,(ISNULL(SUM_MONTH_END_BALANCE_SAVINGS_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_SAVINGS_Q2,0)) [DFT_SUM_MONTH_END_BALANCE_SAVINGS_Q1_Q2] 
			  --,(ISNULL(SUM_MONTH_END_BALANCE_SAVINGS_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_SAVINGS_Q3,0)) [DFT_SUM_MONTH_END_BALANCE_SAVINGS_Q1_Q3]
			  --,(ISNULL(SUM_MONTH_END_BALANCE_SAVINGS_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_SAVINGS_Q4,0)) [DFT_SUM_MONTH_END_BALANCE_SAVINGS_Q1_Q4]
			  ,AVG_MONTH_END_BALANCE_SAVINGS_Q1
			  ,(ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_Q2,0)) [DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2] 
			  ,(ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_Q3,0)) [DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q3]
			  --,(ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_Q4,0)) [DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q4]
			  ,SUM_LASTDIVAMOUNT_SAVINGS_Q1
			  ,(ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_Q2,0)) [DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2]
			  ,(ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_Q3,0)) [DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q3]
			  --,(ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_Q4,0)) [DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q4]
			  ,AVG_CHARGEOFFAMOUNT_SAVINGS_SP

			  ,ISNULL(PRODUCT_CHECKING_SP,0) [PRODUCT_CHECKING_SP]
		      ,ISNULL(PRODUCT_CHECKING_Q1,0) [PRODUCT_CHECKING_Q1]
			  ,(ISNULL(PRODUCT_CHECKING_Q1,0) - ISNULL(PRODUCT_CHECKING_Q2,0)) [DFT_PRODUCT_CHECKING_Q1_Q2]
			  ,(ISNULL(PRODUCT_CHECKING_Q1,0) - ISNULL(PRODUCT_CHECKING_Q3,0)) [DFT_PRODUCT_CHECKING_Q1_Q3]
			  --,(ISNULL(PRODUCT_CHECKING_Q1,0) - ISNULL(PRODUCT_CHECKING_Q4,0)) [DFT_PRODUCT_CHECKING_Q1_Q4]
			  ,ISNULL(TYPE_CHECKING_SP,0) [TYPE_CHECKING_SP]
			  ,ISNULL(TYPE_CHECKING_Q1,0) [TYPE_CHECKING_Q1]
			  ,(ISNULL(TYPE_CHECKING_Q1,0) - ISNULL(TYPE_CHECKING_Q2,0)) [DFT_TYPE_CHECKING_Q1_Q2]
			  ,(ISNULL(TYPE_CHECKING_Q1,0) - ISNULL(TYPE_CHECKING_Q3,0)) [DFT_TYPE_CHECKING_Q1_Q3]
			  --,(ISNULL(TYPE_CHECKING_Q1,0) - ISNULL(TYPE_CHECKING_Q4,0)) [DFT_TYPE_CHECKING_Q1_Q4]
			  ,MOB_CHECKING
			  --,SUM_MONTH_END_BALANCE_CHECKING_Q1
			  --,(ISNULL(SUM_MONTH_END_BALANCE_CHECKING_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_CHECKING_Q2,0)) [DFT_SUM_MONTH_END_BALANCE_CHECKING_Q1_Q2] 
			  --,(ISNULL(SUM_MONTH_END_BALANCE_CHECKING_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_CHECKING_Q3,0)) [DFT_SUM_MONTH_END_BALANCE_CHECKING_Q1_Q3]
			  --,(ISNULL(SUM_MONTH_END_BALANCE_CHECKING_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_CHECKING_Q4,0)) [DFT_SUM_MONTH_END_BALANCE_CHECKING_Q1_Q4]
			  ,AVG_MONTH_END_BALANCE_CHECKING_Q1
			  ,(ISNULL(AVG_MONTH_END_BALANCE_CHECKING_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_CHECKING_Q2,0)) [DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2] 
			  ,(ISNULL(AVG_MONTH_END_BALANCE_CHECKING_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_CHECKING_Q3,0)) [DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3]
			  --,(ISNULL(AVG_MONTH_END_BALANCE_CHECKING_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_CHECKING_Q4,0)) [DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q4]
			  ,SUM_LASTDIVAMOUNT_CHECKING_Q1
			  ,(ISNULL(SUM_LASTDIVAMOUNT_CHECKING_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_CHECKING_Q2,0)) [DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2]
			  ,(ISNULL(SUM_LASTDIVAMOUNT_CHECKING_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_CHECKING_Q3,0)) [DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q3]
			  --,(ISNULL(SUM_LASTDIVAMOUNT_CHECKING_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_CHECKING_Q4,0)) [DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q4]
			  ,AVG_CHARGEOFFAMOUNT_CHECKING_SP

		      ,ISNULL(PRODUCT_CERTIFICATES_SP,0) [PRODUCT_CERTIFICATES_SP]
		      ,ISNULL(PRODUCT_CERTIFICATES_Q1,0) [PRODUCT_CERTIFICATES_Q1]
			  ,(ISNULL(PRODUCT_CERTIFICATES_Q1,0) - ISNULL(PRODUCT_CERTIFICATES_Q2,0)) [DFT_PRODUCT_CERTIFICATES_Q1_Q2]
			  ,(ISNULL(PRODUCT_CERTIFICATES_Q1,0) - ISNULL(PRODUCT_CERTIFICATES_Q3,0)) [DFT_PRODUCT_CERTIFICATES_Q1_Q3]
			  --,(ISNULL(PRODUCT_CERTIFICATES_Q1,0) - ISNULL(PRODUCT_CERTIFICATES_Q4,0)) [DFT_PRODUCT_CERTIFICATES_Q1_Q4]
			  ,ISNULL(TYPE_CERTIFICATES_SP,0) [TYPE_CERTIFICATES_SP]
			  ,ISNULL(TYPE_CERTIFICATES_Q1,0) [TYPE_CERTIFICATES_Q1]
			  ,(ISNULL(TYPE_CERTIFICATES_Q1,0) - ISNULL(TYPE_CERTIFICATES_Q2,0)) [DFT_TYPE_CERTIFICATES_Q1_Q2]
			  ,(ISNULL(TYPE_CERTIFICATES_Q1,0) - ISNULL(TYPE_CERTIFICATES_Q3,0)) [DFT_TYPE_CERTIFICATES_Q1_Q3]
			  --,(ISNULL(TYPE_CERTIFICATES_Q1,0) - ISNULL(TYPE_CERTIFICATES_Q4,0)) [DFT_TYPE_CERTIFICATES_Q1_Q4]
			  ,MOB_CERTIFICATES
			  --,SUM_MONTH_END_BALANCE_CERTIFICATES_Q1
			  --,(ISNULL(SUM_MONTH_END_BALANCE_CERTIFICATES_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_CERTIFICATES_Q2,0)) [DFT_SUM_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2] 
			  --,(ISNULL(SUM_MONTH_END_BALANCE_CERTIFICATES_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_CERTIFICATES_Q3,0)) [DFT_SUM_MONTH_END_BALANCE_CERTIFICATES_Q1_Q3]
			  --,(ISNULL(SUM_MONTH_END_BALANCE_CERTIFICATES_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_CERTIFICATES_Q4,0)) [DFT_SUM_MONTH_END_BALANCE_CERTIFICATES_Q1_Q4]
			  ,AVG_MONTH_END_BALANCE_CERTIFICATES_Q1
			  ,(ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_Q2,0)) [DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2] 
			  ,(ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_Q3,0)) [DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q3]
			  --,(ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_Q4,0)) [DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q4]
			  ,SUM_LASTDIVAMOUNT_CERTIFICATES_Q1
			  ,(ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_Q2,0)) [DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q2]
			  ,(ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_Q3,0)) [DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q3]
			  --,(ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_Q4,0)) [DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q4]
			  ,AVG_CHARGEOFFAMOUNT_CERTIFICATES_SP

		      ,ISNULL(PRODUCT_MONEYMARKET_SP,0) [PRODUCT_MONEYMARKET_SP]
		      ,ISNULL(PRODUCT_MONEYMARKET_Q1,0) [PRODUCT_MONEYMARKET_Q1]
			  ,(ISNULL(PRODUCT_MONEYMARKET_Q1,0) - ISNULL(PRODUCT_MONEYMARKET_Q2,0)) [DFT_PRODUCT_MONEYMARKET_Q1_Q2]
			  ,(ISNULL(PRODUCT_MONEYMARKET_Q1,0) - ISNULL(PRODUCT_MONEYMARKET_Q3,0)) [DFT_PRODUCT_MONEYMARKET_Q1_Q3]
			  --,(ISNULL(PRODUCT_MONEYMARKET_Q1,0) - ISNULL(PRODUCT_MONEYMARKET_Q4,0)) [DFT_PRODUCT_MONEYMARKET_Q1_Q4]
			  ,ISNULL(TYPE_MONEYMARKET_SP,0) [TYPE_MONEYMARKET_SP]
			  ,ISNULL(TYPE_MONEYMARKET_Q1,0) [TYPE_MONEYMARKET_Q1]
			  ,(ISNULL(TYPE_MONEYMARKET_Q1,0) - ISNULL(TYPE_MONEYMARKET_Q2,0)) [DFT_TYPE_MONEYMARKET_Q1_Q2]
			  ,(ISNULL(TYPE_MONEYMARKET_Q1,0) - ISNULL(TYPE_MONEYMARKET_Q3,0)) [DFT_TYPE_MONEYMARKET_Q1_Q3]
			  --,(ISNULL(TYPE_MONEYMARKET_Q1,0) - ISNULL(TYPE_MONEYMARKET_Q4,0)) [DFT_TYPE_MONEYMARKET_Q1_Q4]
			  ,MOB_MONEYMARKET
			  --,SUM_MONTH_END_BALANCE_MONEYMARKET_Q1
			  --,(ISNULL(SUM_MONTH_END_BALANCE_MONEYMARKET_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_MONEYMARKET_Q2,0)) [DFT_SUM_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2] 
			  --,(ISNULL(SUM_MONTH_END_BALANCE_MONEYMARKET_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_MONEYMARKET_Q3,0)) [DFT_SUM_MONTH_END_BALANCE_MONEYMARKET_Q1_Q3]
			  --,(ISNULL(SUM_MONTH_END_BALANCE_MONEYMARKET_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_MONEYMARKET_Q4,0)) [DFT_SUM_MONTH_END_BALANCE_MONEYMARKET_Q1_Q4]
			  ,AVG_MONTH_END_BALANCE_MONEYMARKET_Q1
			  ,(ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_Q2,0)) [DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2] 
			  ,(ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_Q3,0)) [DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q3]
			  --,(ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_Q4,0)) [DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q4]
			  ,SUM_LASTDIVAMOUNT_MONEYMARKET_Q1
			  ,(ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q2,0)) [DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2]
			  ,(ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q3,0)) [DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q3]
			  --,(ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q4,0)) [DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q4]
			  ,AVG_CHARGEOFFAMOUNT_MONEYMARKET_SP

			  ,ISNULL(PRODUCT_DEPOSITS_SP,0) [PRODUCT_DEPOSITS_SP]
		      ,ISNULL(PRODUCT_DEPOSITS_Q1,0) [PRODUCT_DEPOSITS_Q1]
			  ,(ISNULL(PRODUCT_DEPOSITS_Q1,0) - ISNULL(PRODUCT_DEPOSITS_Q2,0)) [DFT_PRODUCT_DEPOSITS_Q1_Q2]
			  ,(ISNULL(PRODUCT_DEPOSITS_Q1,0) - ISNULL(PRODUCT_DEPOSITS_Q3,0)) [DFT_PRODUCT_DEPOSITS_Q1_Q3]
			  --,(ISNULL(PRODUCT_DEPOSITS_Q1,0) - ISNULL(PRODUCT_DEPOSITS_Q4,0)) [DFT_PRODUCT_DEPOSITS_Q1_Q4]
			  ,ISNULL(TYPE_DEPOSITS_SP,0) [TYPE_DEPOSITS_SP]
			  ,ISNULL(TYPE_DEPOSITS_Q1,0) [TYPE_DEPOSITS_Q1]
			  ,(ISNULL(TYPE_DEPOSITS_Q1,0) - ISNULL(TYPE_DEPOSITS_Q2,0)) [DFT_TYPE_DEPOSITS_Q1_Q2]
			  ,(ISNULL(TYPE_DEPOSITS_Q1,0) - ISNULL(TYPE_DEPOSITS_Q3,0)) [DFT_TYPE_DEPOSITS_Q1_Q3]
			  --,(ISNULL(TYPE_DEPOSITS_Q1,0) - ISNULL(TYPE_DEPOSITS_Q4,0)) [DFT_TYPE_DEPOSITS_Q1_Q4]
			  ,MOB_DEPOSITS
			  --,SUM_MONTH_END_BALANCE_DEPOSITS_Q1
			  --,(ISNULL(SUM_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_DEPOSITS_Q2,0)) [DFT_SUM_MONTH_END_BALANCE_DEPOSITS_Q1_Q2] 
			  --,(ISNULL(SUM_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_DEPOSITS_Q3,0)) [DFT_SUM_MONTH_END_BALANCE_DEPOSITS_Q1_Q3]
			  --,(ISNULL(SUM_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(SUM_MONTH_END_BALANCE_DEPOSITS_Q4,0)) [DFT_SUM_MONTH_END_BALANCE_DEPOSITS_Q1_Q4]
			  ,AVG_MONTH_END_BALANCE_DEPOSITS_Q1
			  ,(ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q2,0)) [DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2] 
			  ,(ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q3,0)) [DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q3]
			  --,(ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q4,0)) [DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q4]
			  ,SUM_LASTDIVAMOUNT_DEPOSITS_Q1
			  ,(ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_Q2,0)) [DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2]
			  ,(ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_Q3,0)) [DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q3]
			  --,(ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_Q4,0)) [DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q4]
			  ,AVG_CHARGEOFFAMOUNT_DEPOSITS_SP

		into #membership_deposits
		FROM 
		(
	    	(SELECT SSN
              ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Staticpool') then UNID END) [PRODUCT_SAVINGS_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then UNID END) [PRODUCT_SAVINGS_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then UNID END) [PRODUCT_SAVINGS_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then UNID END) [PRODUCT_SAVINGS_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then UNID END) [PRODUCT_SAVINGS_Q4]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Staticpool') then TYPE END) [TYPE_SAVINGS_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then TYPE END) [TYPE_SAVINGS_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then TYPE END) [TYPE_SAVINGS_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then TYPE END) [TYPE_SAVINGS_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then TYPE END) [TYPE_SAVINGS_Q4]
			  ,MIN(CASE WHEN Deposit_Flag = 'Savings' then Open_date END) [OPENDATE_SAVINGS]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' then Close_date END) [CLOSEDATE_SAVINGS]

			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' then MOB END) [MOB_SAVINGS]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_SAVINGS_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_SAVINGS_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_SAVINGS_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_SAVINGS_Q4]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_SAVINGS_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_SAVINGS_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_SAVINGS_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_SAVINGS_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_SAVINGS_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_SAVINGS_Q4]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_SAVINGS_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_SAVINGS_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_SAVINGS_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_SAVINGS_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_SAVINGS_Q4]

					       --- Previously only SUM_LASTDIVAMOUNT_SAVINGS_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SAVINGS_SP]

			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Staticpool') then UNID END) [PRODUCT_CHECKING_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then UNID END) [PRODUCT_CHECKING_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then UNID END) [PRODUCT_CHECKING_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then UNID END) [PRODUCT_CHECKING_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then UNID END) [PRODUCT_CHECKING_Q4]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Staticpool') then TYPE END) [TYPE_CHECKING_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then TYPE END) [TYPE_CHECKING_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then TYPE END) [TYPE_CHECKING_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then TYPE END) [TYPE_CHECKING_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then TYPE END) [TYPE_CHECKING_Q4]

			  ,MIN(CASE WHEN Deposit_Flag = 'Checking' then Open_date END) [OPENDATE_CHECKING]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' then Close_date END) [CLOSEDATE_CHECKING]

			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' then MOB END) [MOB_CHECKING]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CHECKING_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CHECKING_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CHECKING_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CHECKING_Q4]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_CHECKING_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_CHECKING_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CHECKING_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CHECKING_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CHECKING_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CHECKING_Q4]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_CHECKING_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CHECKING_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CHECKING_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CHECKING_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CHECKING_Q4]

					       --- Previously only SUM_LASTDIVAMOUNT_CHECKING_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CHECKING_SP]

              ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Staticpool') then UNID END) [PRODUCT_CERTIFICATES_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then UNID END) [PRODUCT_CERTIFICATES_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then UNID END) [PRODUCT_CERTIFICATES_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then UNID END) [PRODUCT_CERTIFICATES_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then UNID END) [PRODUCT_CERTIFICATES_Q4]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Staticpool') then TYPE END) [TYPE_CERTIFICATES_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then TYPE END) [TYPE_CERTIFICATES_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then TYPE END) [TYPE_CERTIFICATES_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then TYPE END) [TYPE_CERTIFICATES_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then TYPE END) [TYPE_CERTIFICATES_Q4]

			  ,MIN(CASE WHEN Deposit_Flag = 'Certificates' then Open_date END) [OPENDATE_CERTIFICATES]
			  ,MAX(CASE WHEN Deposit_Flag = 'Certificates' then Close_date END) [CLOSEDATE_CERTIFICATES]

			  ,MAX(CASE WHEN Deposit_Flag = 'Certificates' then MOB END) [MOB_CERTIFICATES]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CERTIFICATES_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CERTIFICATES_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CERTIFICATES_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CERTIFICATES_Q4]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_CERTIFICATES_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CERTIFICATES_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CERTIFICATES_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CERTIFICATES_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CERTIFICATES_Q4]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_CERTIFICATES_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CERTIFICATES_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CERTIFICATES_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CERTIFICATES_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CERTIFICATES_Q4]

					       --- Previously only SUM_LASTDIVAMOUNT_CERTIFICATES_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CERTIFICATES_SP]

              ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Staticpool') then UNID END) [PRODUCT_MONEYMARKET_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then UNID END) [PRODUCT_MONEYMARKET_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then UNID END) [PRODUCT_MONEYMARKET_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then UNID END) [PRODUCT_MONEYMARKET_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then UNID END) [PRODUCT_MONEYMARKET_Q4]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Staticpool') then TYPE END) [TYPE_MONEYMARKET_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then TYPE END) [TYPE_MONEYMARKET_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then TYPE END) [TYPE_MONEYMARKET_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then TYPE END) [TYPE_MONEYMARKET_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then TYPE END) [TYPE_MONEYMARKET_Q4]
			  ,MIN(CASE WHEN Deposit_Flag = 'MoneyMarket' then Open_date END) [OPENDATE_MONEYMARKET]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' then Close_date END) [CLOSEDATE_MONEYMARKET]

			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' then MOB END) [MOB_MONEYMARKET]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_MONEYMARKET_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_MONEYMARKET_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_MONEYMARKET_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_MONEYMARKET_Q4]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_MONEYMARKET_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_MONEYMARKET_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_MONEYMARKET_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_MONEYMARKET_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_MONEYMARKET_Q4]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_MONEYMARKET_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q4]

					       --- Previously only SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_MONEYMARKET_SP]


		    FROM #deposits_account_data
		    group by SSN
			) A
			LEFT JOIN 
			(
			SELECT SSN
              ,COUNT(DISTINCT CASE WHEN Quarters = 'Staticpool' then UNID END) [PRODUCT_DEPOSITS_SP]
		      ,COUNT(DISTINCT CASE WHEN Quarters = 'Q1'then UNID END) [PRODUCT_DEPOSITS_Q1]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q2'then UNID END) [PRODUCT_DEPOSITS_Q2]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q3'then UNID END) [PRODUCT_DEPOSITS_Q3]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q4'then UNID END) [PRODUCT_DEPOSITS_Q4]
					
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Staticpool' then TYPE END) [TYPE_DEPOSITS_SP]
		      ,COUNT(DISTINCT CASE WHEN Quarters = 'Q1' then TYPE END) [TYPE_DEPOSITS_Q1]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q2' then TYPE END) [TYPE_DEPOSITS_Q2]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q3' then TYPE END) [TYPE_DEPOSITS_Q3]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q4' then TYPE END) [TYPE_DEPOSITS_Q4]
			  ,MIN(Open_date) [MIN_OPENDATE_DEPOSITS]
			  ,MAX(Close_date) [MAX_CLOSEDATE_DEPOSITS]

			  ,MAX( MOB ) [MOB_DEPOSITS]
			  
			  ,SUM(CASE WHEN Quarters = 'Q1' then Month_end_balance END) [SUM_MONTH_END_BALANCE_DEPOSITS_Q1]
			  ,SUM(CASE WHEN Quarters = 'Q2' then Month_end_balance END) [SUM_MONTH_END_BALANCE_DEPOSITS_Q2]
			  ,SUM(CASE WHEN Quarters = 'Q3' then Month_end_balance END) [SUM_MONTH_END_BALANCE_DEPOSITS_Q3]
			  ,SUM(CASE WHEN Quarters = 'Q4' then Month_end_balance END) [SUM_MONTH_END_BALANCE_DEPOSITS_Q4]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_DEPOSITS_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_DEPOSITS_Q1_Q4 was taken 

			  ,AVG(CASE WHEN Quarters = 'Q1' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q1]
			  ,AVG(CASE WHEN Quarters = 'Q2' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q2]
			  ,AVG(CASE WHEN Quarters = 'Q3' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q3]
			  ,AVG(CASE WHEN Quarters = 'Q4' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q4]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_DEPOSITS_Q1 was taken 

              ,SUM(CASE WHEN Quarters = 'Q1' then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_DEPOSITS_Q1]
			  ,SUM(CASE WHEN Quarters = 'Q2' then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_DEPOSITS_Q2]
			  ,SUM(CASE WHEN Quarters = 'Q3' then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_DEPOSITS_Q3]
			  ,SUM(CASE WHEN Quarters = 'Q4' then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_DEPOSITS_Q4]

					       --- Previously only SUM_LASTDIVAMOUNT_DEPOSITS_Q1 was taken

              ,AVG(CASE WHEN  Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_DEPOSITS_SP]			
			FROM #deposits_account_data
			group by SSN
			) B
			ON A.SSN = B.SSN
		 
		) 

		---Refer 5199 line of Previous Data Creation

		--SELECT TOP 100 * FROM #membership_deposits

		--SELECT TOP 100 * FROM ARCUSYM000..SAVINGSTRANSACTION
		
		--SELECT TOP 100 * FROM #deposits_account_data


------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Transaction Data (ShareCategorywise) ***\\\-----------------------------------------------

     DROP TABLE IF EXISTS #static_unid_deposits
     
     SELECT UNID,PARENTACCOUNT,Deposit_Flag,Process_Date
     into #static_unid_deposits
     from #deposits_account_data

     DROP TABLE IF EXISTS #deposit_transaction_temp1
     SELECT B.Deposit_Flag
	  ,case when A.EFFECTIVEDATE_v1 in ((left(convert(varchar,dateadd(month,-10,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-11,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6))) then 'Q4'
		    when A.EFFECTIVEDATE_v1 in ((left(convert(varchar,dateadd(month,-7,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-8,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-9,@staticpooldate),112),6))) then 'Q3'
		    when A.EFFECTIVEDATE_v1 in ((left(convert(varchar,dateadd(month,-4,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-5,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-6,@staticpooldate),112),6))) then 'Q2'
		    when A.EFFECTIVEDATE_v1 in ((left(convert(varchar,dateadd(month,-3,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-2,@staticpooldate),112),6)),(left(convert(varchar,dateadd(month,-1,@staticpooldate),112),6))) then 'Q1'
		    when A.EFFECTIVEDATE_v1 in (left(convert(varchar,@staticpooldate,112),6)) then 'Staticpool' end Quarters
	 ,A.*
	    into #deposit_transaction_temp1
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      ,[COMMENTCODE]
      ,[TRANSFERCODE]
      ,[ADJUSTMENTCODE]
      ,[REGECODE]
      ,[REGDCHECKCODE]
      ,[REGDTRANSFERCODE]
      ,[VOIDCODE]
      ,[SUBACTIONCODE]
      ,[SEQUENCENUMBER]
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      ,[POSTDATE]
      ,[POSTTIME]
      ,[USERNUMBER]
      ,[USEROVERRIDE]
      ,[SECURITYLEVELS]
      ,[DESCRIPTION]
      ,[ACTIONCODE]
      ,[SOURCECODE]
      ,[BALANCECHANGE]
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	  ,[INTEREST]
      ,[NEWBALANCE]
      ,[FEEAMOUNT]
      ,[ESCROWAMOUNT]
      ,[LASTTRANDATE]
      ,[MATURITYLOANDUEDATE]
      ,[COMMENT]
      ,[BRANCH]
      ,[CONSOLENUMBER]
      ,[BATCHSEQUENCE]
      ,[SALESTAXAMOUNT]
      ,[ACTIVITYDATE]
      ,[BILLEDFEEAMOUNT]
      ,[PROCESSORUSER]
      ,[MEMBERBRANCH]
      ,[PREVAVAILBALANCE]
      ,[SUBSOURCE]
      ,[CONFIRMATIONSEQ]
      ,[MICRACCTNUM]
      ,[MICRRT]
      ,[RECURRINGTRAN]
      ,[FEEEXMTCRTSYAMT]
      ,[ESCROWUNPAIDBALCHG]
      ,[ESCROWAPPLIEDBALCHG]
      ,[UNAPPLIEDPARTIALPMTCHG]
      ,[FEECOUNTBY]
      ,[BALSEGCOUNT]
      ,[LATECHGWAIVEDAMT]
      ,[LATECHGUNPAIDCHGAMT]
      ,[PREVLATECHGDATE]
      ,[PREVLATECHGACCRUED]
      ,[LATECHGFIELDSVALID]
      ,[BALSEGID1]
      ,[BALSEGPMTCHANGEDATE1]
      ,[INTEFFECTDATE]
      ,[BALSEGPREVFIRSTPMTDATE1]
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
	 FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
	  WHERE  ACTIONCODE!='C') A
	 left join #static_unid_deposits B
	 ON A.UNID = B.UNID
	 --and A.EFFECTIVEDATE_v1 = B.Process_Date
	-- day wise data include all dates 
	where EFFECTIVEDATE_v1 between left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6) and left(convert(varchar,@staticpooldate,112),6)
  
  
   
--select PARENTACCOUNT,PARENTID,UNID
--			,count(*) Transaction_COUNT
--			,sum(BALANCECHANGE) Transaction_amount
--			,AVG(BALANCECHANGE) AVG_BALANCECHANGE
--			,sum(Deposited_amount) Deposited_amount
--			,count(Deposited_amount) Deposited_count
--			,sum(withdrawl_amount) withdrawal_amount
--			,count(withdrawl_amount) withdrawal_count
--			,sum(INTEREST) Sum_INTEREST
--			,EFFECTIVEDATE_v1
--		into ##Certificates_transaction

        DROP TABLE IF EXISTS #deposit_transaction_temp2
            
        SELECT B.SSN
                ,A.*
        INTO #deposit_transaction_temp2 
        From
		(
		 SELECT * FROM
          (SELECT  PARENTACCOUNT
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_SAVINGS_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_SAVINGS_Q4]
            
                ,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_SAVINGS_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_SAVINGS_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_SAVINGS_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_SAVINGS_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_SAVINGS_Q4]	
            		
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_COUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_COUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_COUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_COUNT_SAVINGS_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_SAVINGS_Q4]
            
                ,COUNT(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_SAVINGS_Q1]
            	,COUNT(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_SAVINGS_Q2]
            	,COUNT(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_SAVINGS_Q3]
            	,COUNT(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_SAVINGS_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_SAVINGS_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_CHECKING_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CHECKING_Q4]
            
                ,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_CHECKING_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_CHECKING_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_CHECKING_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_CHECKING_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CHECKING_Q4]	
            		
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_COUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_COUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_COUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_COUNT_CHECKING_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CHECKING_Q4]
            
                ,COUNT(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_CHECKING_Q1]
            	,COUNT(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_CHECKING_Q2]
            	,COUNT(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_CHECKING_Q3]
            	,COUNT(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_CHECKING_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_CHECKING_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_CERTIFICATES_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_Q4]
            
                ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_CERTIFICATES_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_CERTIFICATES_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_CERTIFICATES_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_CERTIFICATES_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CERTIFICATES_Q4]	
            		
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_COUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_COUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_COUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_COUNT_CERTIFICATES_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CERTIFICATES_Q4]
            
                ,COUNT(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_CERTIFICATES_Q1]
            	,COUNT(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_CERTIFICATES_Q2]
            	,COUNT(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_CERTIFICATES_Q3]
            	,COUNT(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_CERTIFICATES_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_CERTIFICATES_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_MONEYMARKET_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_MONEYMARKET_Q4]
            
                ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_MONEYMARKET_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_MONEYMARKET_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_MONEYMARKET_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_MONEYMARKET_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_MONEYMARKET_Q4]	
            		
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_COUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_COUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_COUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_COUNT_MONEYMARKET_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_MONEYMARKET_Q4]
            
                ,COUNT(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_MONEYMARKET_Q1]
            	,COUNT(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_MONEYMARKET_Q2]
            	,COUNT(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_MONEYMARKET_Q3]
            	,COUNT(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_MONEYMARKET_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_MONEYMARKET_Q4]
        from #deposit_transaction_temp1
        group by PARENTACCOUNT) P
		LEFT JOIN 
		(SELECT PARENTACCOUNT [P_D]
                ,SUM(CASE WHEN Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q4]
            
                ,SUM(CASE WHEN Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_DEPOSITS_Q4]
            
                ,AVG(CASE WHEN Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_DEPOSITS_Q1]
            	,AVG(CASE WHEN Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_DEPOSITS_Q2]
            	,AVG(CASE WHEN Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_DEPOSITS_Q3]
            	,AVG(CASE WHEN Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_BALANCECHANGE_DEPOSITS_Q4]
            
                ,SUM(CASE WHEN Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_DEPOSITS_Q4]	
            		
            	,SUM(CASE WHEN Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_COUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_COUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_COUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_COUNT_DEPOSITS_Q4]
            
                ,SUM(CASE WHEN Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q4]
            
                ,COUNT(CASE WHEN Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_DEPOSITS_Q1]
            	,COUNT(CASE WHEN Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_DEPOSITS_Q2]
            	,COUNT(CASE WHEN Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_DEPOSITS_Q3]
            	,COUNT(CASE WHEN Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_DEPOSITS_Q4]
            
                ,SUM(CASE WHEN Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_DEPOSITS_Q4]		
		FROM #deposit_transaction_temp1
		group by PARENTACCOUNT ) Q
		ON P.PARENTACCOUNT = Q.P_D
		) A
        left join #Static_SSN_account B
        on A.PARENTACCOUNT = B.AccountNumber

		DROP TABLE IF EXISTS #deposits_transaction

		SELECT SSN [SSN004]
		      , [TRANSACTION_COUNT_SAVINGS_Q1] 
			  , (ISNULL(TRANSACTION_COUNT_SAVINGS_Q1,0) - ISNULL(TRANSACTION_COUNT_SAVINGS_Q2,0)) DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2
			  , (ISNULL(TRANSACTION_COUNT_SAVINGS_Q1,0) - ISNULL(TRANSACTION_COUNT_SAVINGS_Q3,0)) DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q3
			  --, (ISNULL(TRANSACTION_COUNT_SAVINGS_Q1,0) - ISNULL(TRANSACTION_COUNT_SAVINGS_Q4,0)) DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q4
			  , [TRANSACTION_AMOUNT_SAVINGS_Q1]
			  , (ISNULL(TRANSACTION_AMOUNT_SAVINGS_Q1,0) - ISNULL(TRANSACTION_AMOUNT_SAVINGS_Q2,0)) DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2
			  , (ISNULL(TRANSACTION_AMOUNT_SAVINGS_Q1,0) - ISNULL(TRANSACTION_AMOUNT_SAVINGS_Q3,0)) DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q3
			  --, (ISNULL(TRANSACTION_AMOUNT_SAVINGS_Q1,0) - ISNULL(TRANSACTION_AMOUNT_SAVINGS_Q4,0)) DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q4
			  , [AVG_BALANCECHANGE_SAVINGS_Q1]
			  , (ISNULL(AVG_BALANCECHANGE_SAVINGS_Q1,0)  - ISNULL(AVG_BALANCECHANGE_SAVINGS_Q2,0)) DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q2
			  , (ISNULL(AVG_BALANCECHANGE_SAVINGS_Q1,0)  - ISNULL(AVG_BALANCECHANGE_SAVINGS_Q3,0)) DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q3
			  --, (ISNULL(AVG_BALANCECHANGE_SAVINGS_Q1,0)  - ISNULL(AVG_BALANCECHANGE_SAVINGS_Q4,0)) DFT_AVG_BALANCECHANGE_SAVINGS_Q1_Q4
			  , [DEPOSITED_AMOUNT_SAVINGS_Q1] 
			  , (ISNULL(DEPOSITED_AMOUNT_SAVINGS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_SAVINGS_Q2,0)) DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2
			  , (ISNULL(DEPOSITED_AMOUNT_SAVINGS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_SAVINGS_Q3,0)) DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q3
			  --, (ISNULL(DEPOSITED_AMOUNT_SAVINGS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_SAVINGS_Q4,0)) DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q4
			  , [DEPOSITED_COUNT_SAVINGS_Q1]
			  , (ISNULL(DEPOSITED_COUNT_SAVINGS_Q1,0) - ISNULL(DEPOSITED_COUNT_SAVINGS_Q2,0)) [DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2]
			  , (ISNULL(DEPOSITED_COUNT_SAVINGS_Q1,0) - ISNULL(DEPOSITED_COUNT_SAVINGS_Q3,0)) [DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q3]
			  --, (ISNULL(DEPOSITED_COUNT_SAVINGS_Q1,0) - ISNULL(DEPOSITED_COUNT_SAVINGS_Q4,0)) [DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q4]
			  , [WITHDRAWAL_AMOUNT_SAVINGS_Q1]
			  , (ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q2,0)) [DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2]
			  , (ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q3,0)) [DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3]
			  --, (ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q4,0)) [DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q4]
			  , [WITHDRAWAL_COUNT_SAVINGS_Q1]
			  , (ISNULL(WITHDRAWAL_COUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_COUNT_SAVINGS_Q2,0)) [DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2]
			  , (ISNULL(WITHDRAWAL_COUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_COUNT_SAVINGS_Q3,0)) [DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q3]
			  --, (ISNULL(WITHDRAWAL_COUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_COUNT_SAVINGS_Q4,0)) [DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q4]
			  , [SUM_INTEREST_SAVINGS_Q1]
			  , (ISNULL(SUM_INTEREST_SAVINGS_Q1,0) - ISNULL(SUM_INTEREST_SAVINGS_Q2,0)) [DFT_SUM_INTEREST_SAVINGS_Q1_Q2]
			  , (ISNULL(SUM_INTEREST_SAVINGS_Q1,0) - ISNULL(SUM_INTEREST_SAVINGS_Q3,0)) [DFT_SUM_INTEREST_SAVINGS_Q1_Q3]
			  --, (ISNULL(SUM_INTEREST_SAVINGS_Q1,0) - ISNULL(SUM_INTEREST_SAVINGS_Q4,0)) [DFT_SUM_INTEREST_SAVINGS_Q1_Q4]

			  , [TRANSACTION_COUNT_CHECKING_Q1] 
			  , (ISNULL(TRANSACTION_COUNT_CHECKING_Q1,0) - ISNULL(TRANSACTION_COUNT_CHECKING_Q2,0)) DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2
			  , (ISNULL(TRANSACTION_COUNT_CHECKING_Q1,0) - ISNULL(TRANSACTION_COUNT_CHECKING_Q3,0)) DFT_TRANSACTION_COUNT_CHECKING_Q1_Q3
			  --, (ISNULL(TRANSACTION_COUNT_CHECKING_Q1,0) - ISNULL(TRANSACTION_COUNT_CHECKING_Q4,0)) DFT_TRANSACTION_COUNT_CHECKING_Q1_Q4
			  , [TRANSACTION_AMOUNT_CHECKING_Q1]
			  , (ISNULL(TRANSACTION_AMOUNT_CHECKING_Q1,0) - ISNULL(TRANSACTION_AMOUNT_CHECKING_Q2,0)) DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2
			  , (ISNULL(TRANSACTION_AMOUNT_CHECKING_Q1,0) - ISNULL(TRANSACTION_AMOUNT_CHECKING_Q3,0)) DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3
			  --, (ISNULL(TRANSACTION_AMOUNT_CHECKING_Q1,0) - ISNULL(TRANSACTION_AMOUNT_CHECKING_Q4,0)) DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q4
			  , [AVG_BALANCECHANGE_CHECKING_Q1]
			  , (ISNULL(AVG_BALANCECHANGE_CHECKING_Q1,0)  - ISNULL(AVG_BALANCECHANGE_CHECKING_Q2,0)) DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q2
			  , (ISNULL(AVG_BALANCECHANGE_CHECKING_Q1,0)  - ISNULL(AVG_BALANCECHANGE_CHECKING_Q3,0)) DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q3
			  --, (ISNULL(AVG_BALANCECHANGE_CHECKING_Q1,0)  - ISNULL(AVG_BALANCECHANGE_CHECKING_Q4,0)) DFT_AVG_BALANCECHANGE_CHECKING_Q1_Q4
			  , [DEPOSITED_AMOUNT_CHECKING_Q1] 
			  , (ISNULL(DEPOSITED_AMOUNT_CHECKING_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_CHECKING_Q2,0)) DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2
			  , (ISNULL(DEPOSITED_AMOUNT_CHECKING_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_CHECKING_Q3,0)) DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3
			  --, (ISNULL(DEPOSITED_AMOUNT_CHECKING_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_CHECKING_Q4,0)) DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q4
			  , [DEPOSITED_COUNT_CHECKING_Q1]
			  , (ISNULL(DEPOSITED_COUNT_CHECKING_Q1,0) - ISNULL(DEPOSITED_COUNT_CHECKING_Q2,0)) [DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2]
			  , (ISNULL(DEPOSITED_COUNT_CHECKING_Q1,0) - ISNULL(DEPOSITED_COUNT_CHECKING_Q3,0)) [DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3]
			  --, (ISNULL(DEPOSITED_COUNT_CHECKING_Q1,0) - ISNULL(DEPOSITED_COUNT_CHECKING_Q4,0)) [DFT_DEPOSITED_COUNT_CHECKING_Q1_Q4]
			  , [WITHDRAWAL_AMOUNT_CHECKING_Q1]
			  , (ISNULL(WITHDRAWAL_AMOUNT_CHECKING_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_CHECKING_Q2,0)) [DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2]
			  , (ISNULL(WITHDRAWAL_AMOUNT_CHECKING_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_CHECKING_Q3,0)) [DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q3]
			  --, (ISNULL(WITHDRAWAL_AMOUNT_CHECKING_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_CHECKING_Q4,0)) [DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q4]
			  , [WITHDRAWAL_COUNT_CHECKING_Q1]
			  , (ISNULL(WITHDRAWAL_COUNT_CHECKING_Q1,0) - ISNULL(WITHDRAWAL_COUNT_CHECKING_Q2,0)) [DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2]
			  , (ISNULL(WITHDRAWAL_COUNT_CHECKING_Q1,0) - ISNULL(WITHDRAWAL_COUNT_CHECKING_Q3,0)) [DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q3]
			  --, (ISNULL(WITHDRAWAL_COUNT_CHECKING_Q1,0) - ISNULL(WITHDRAWAL_COUNT_CHECKING_Q4,0)) [DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q4]
			  , [SUM_INTEREST_CHECKING_Q1]
			  , (ISNULL(SUM_INTEREST_CHECKING_Q1,0) - ISNULL(SUM_INTEREST_CHECKING_Q2,0)) [DFT_SUM_INTEREST_CHECKING_Q1_Q2]
			  , (ISNULL(SUM_INTEREST_CHECKING_Q1,0) - ISNULL(SUM_INTEREST_CHECKING_Q3,0)) [DFT_SUM_INTEREST_CHECKING_Q1_Q3]
			  --, (ISNULL(SUM_INTEREST_CHECKING_Q1,0) - ISNULL(SUM_INTEREST_CHECKING_Q4,0)) [DFT_SUM_INTEREST_CHECKING_Q1_Q4]

			  , [TRANSACTION_COUNT_CERTIFICATES_Q1] 
			  , (ISNULL(TRANSACTION_COUNT_CERTIFICATES_Q1,0) - ISNULL(TRANSACTION_COUNT_CERTIFICATES_Q2,0)) DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q2
			  , (ISNULL(TRANSACTION_COUNT_CERTIFICATES_Q1,0) - ISNULL(TRANSACTION_COUNT_CERTIFICATES_Q3,0)) DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q3
			  --, (ISNULL(TRANSACTION_COUNT_CERTIFICATES_Q1,0) - ISNULL(TRANSACTION_COUNT_CERTIFICATES_Q4,0)) DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q4
			  , [TRANSACTION_AMOUNT_CERTIFICATES_Q1]
			  , (ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_Q1,0) - ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_Q2,0)) DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q2
			  , (ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_Q1,0) - ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_Q3,0)) DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q3
			  --, (ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_Q1,0) - ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_Q4,0)) DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q4
			  , [AVG_BALANCECHANGE_CERTIFICATES_Q1]
			  , (ISNULL(AVG_BALANCECHANGE_CERTIFICATES_Q1,0)  - ISNULL(AVG_BALANCECHANGE_CERTIFICATES_Q2,0)) DFT_AVG_BALANCECHANGE_CERTIFICATES_Q1_Q2
			  , (ISNULL(AVG_BALANCECHANGE_CERTIFICATES_Q1,0)  - ISNULL(AVG_BALANCECHANGE_CERTIFICATES_Q3,0)) DFT_AVG_BALANCECHANGE_CERTIFICATES_Q1_Q3
			  --, (ISNULL(AVG_BALANCECHANGE_CERTIFICATES_Q1,0)  - ISNULL(AVG_BALANCECHANGE_CERTIFICATES_Q4,0)) DFT_AVG_BALANCECHANGE_CERTIFICATES_Q1_Q4
			  , [DEPOSITED_AMOUNT_CERTIFICATES_Q1] 
			  , (ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_Q2,0)) DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q2
			  , (ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_Q3,0)) DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q3
			  --, (ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_Q4,0)) DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q4
			  , [DEPOSITED_COUNT_CERTIFICATES_Q1]
			  , (ISNULL(DEPOSITED_COUNT_CERTIFICATES_Q1,0) - ISNULL(DEPOSITED_COUNT_CERTIFICATES_Q2,0)) [DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q2]
			  , (ISNULL(DEPOSITED_COUNT_CERTIFICATES_Q1,0) - ISNULL(DEPOSITED_COUNT_CERTIFICATES_Q3,0)) [DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q3]
			  --, (ISNULL(DEPOSITED_COUNT_CERTIFICATES_Q1,0) - ISNULL(DEPOSITED_COUNT_CERTIFICATES_Q4,0)) [DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q4]
			  , [WITHDRAWAL_AMOUNT_CERTIFICATES_Q1]
			  , (ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_Q2,0)) [DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q2]
			  , (ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_Q3,0)) [DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q3]
			  , (ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_Q4,0)) [DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q4]
			  , [WITHDRAWAL_COUNT_CERTIFICATES_Q1]
			  , (ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_Q1,0) - ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_Q2,0)) [DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q2]
			  , (ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_Q1,0) - ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_Q3,0)) [DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q3]
			  --, (ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_Q1,0) - ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_Q4,0)) [DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q4]
			  , [SUM_INTEREST_CERTIFICATES_Q1]
			  , (ISNULL(SUM_INTEREST_CERTIFICATES_Q1,0) - ISNULL(SUM_INTEREST_CERTIFICATES_Q2,0)) [DFT_SUM_INTEREST_CERTIFICATES_Q1_Q2]
			  , (ISNULL(SUM_INTEREST_CERTIFICATES_Q1,0) - ISNULL(SUM_INTEREST_CERTIFICATES_Q3,0)) [DFT_SUM_INTEREST_CERTIFICATES_Q1_Q3]
			  --, (ISNULL(SUM_INTEREST_CERTIFICATES_Q1,0) - ISNULL(SUM_INTEREST_CERTIFICATES_Q4,0)) [DFT_SUM_INTEREST_CERTIFICATES_Q1_Q4]

			  , [TRANSACTION_COUNT_MONEYMARKET_Q1] 
			  , (ISNULL(TRANSACTION_COUNT_MONEYMARKET_Q1,0) - ISNULL(TRANSACTION_COUNT_MONEYMARKET_Q2,0)) DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q2
			  , (ISNULL(TRANSACTION_COUNT_MONEYMARKET_Q1,0) - ISNULL(TRANSACTION_COUNT_MONEYMARKET_Q3,0)) DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q3
			  --, (ISNULL(TRANSACTION_COUNT_MONEYMARKET_Q1,0) - ISNULL(TRANSACTION_COUNT_MONEYMARKET_Q4,0)) DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q4
			  , [TRANSACTION_AMOUNT_MONEYMARKET_Q1]
			  , (ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_Q1,0) - ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_Q2,0)) DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q2
			  , (ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_Q1,0) - ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_Q3,0)) DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q3
			  --, (ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_Q1,0) - ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_Q4,0)) DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q4
			  , [AVG_BALANCECHANGE_MONEYMARKET_Q1]
			  , (ISNULL(AVG_BALANCECHANGE_MONEYMARKET_Q1,0)  - ISNULL(AVG_BALANCECHANGE_MONEYMARKET_Q2,0)) DFT_AVG_BALANCECHANGE_MONEYMARKET_Q1_Q2
			  , (ISNULL(AVG_BALANCECHANGE_MONEYMARKET_Q1,0)  - ISNULL(AVG_BALANCECHANGE_MONEYMARKET_Q3,0)) DFT_AVG_BALANCECHANGE_MONEYMARKET_Q1_Q3
			  --, (ISNULL(AVG_BALANCECHANGE_MONEYMARKET_Q1,0)  - ISNULL(AVG_BALANCECHANGE_MONEYMARKET_Q4,0)) DFT_AVG_BALANCECHANGE_MONEYMARKET_Q1_Q4
			  , [DEPOSITED_AMOUNT_MONEYMARKET_Q1] 
			  , (ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_Q2,0)) DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q2
			  , (ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_Q3,0)) DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q3
			  --, (ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_Q4,0)) DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q4
			  , [DEPOSITED_COUNT_MONEYMARKET_Q1]
			  , (ISNULL(DEPOSITED_COUNT_MONEYMARKET_Q1,0) - ISNULL(DEPOSITED_COUNT_MONEYMARKET_Q2,0)) [DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q2]
			  , (ISNULL(DEPOSITED_COUNT_MONEYMARKET_Q1,0) - ISNULL(DEPOSITED_COUNT_MONEYMARKET_Q3,0)) [DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q3]
			  --, (ISNULL(DEPOSITED_COUNT_MONEYMARKET_Q1,0) - ISNULL(DEPOSITED_COUNT_MONEYMARKET_Q4,0)) [DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q4]
			  , [WITHDRAWAL_AMOUNT_MONEYMARKET_Q1]
			  , (ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_Q2,0)) [DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q2]
			  , (ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_Q3,0)) [DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q3]
			  --, (ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_Q4,0)) [DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q4]
			  , [WITHDRAWAL_COUNT_MONEYMARKET_Q1]
			  , (ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_Q1,0) - ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_Q2,0)) [DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q2]
			  , (ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_Q1,0) - ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_Q3,0)) [DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q3]
			  --, (ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_Q1,0) - ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_Q4,0)) [DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q4]
			  , [SUM_INTEREST_MONEYMARKET_Q1]
			  , (ISNULL(SUM_INTEREST_MONEYMARKET_Q1,0) - ISNULL(SUM_INTEREST_MONEYMARKET_Q2,0)) [DFT_SUM_INTEREST_MONEYMARKET_Q1_Q2]
			  , (ISNULL(SUM_INTEREST_MONEYMARKET_Q1,0) - ISNULL(SUM_INTEREST_MONEYMARKET_Q3,0)) [DFT_SUM_INTEREST_MONEYMARKET_Q1_Q3]
			  --, (ISNULL(SUM_INTEREST_MONEYMARKET_Q1,0) - ISNULL(SUM_INTEREST_MONEYMARKET_Q4,0)) [DFT_SUM_INTEREST_MONEYMARKET_Q1_Q4]

			   , [TRANSACTION_COUNT_DEPOSITS_Q1] 
			  , (ISNULL(TRANSACTION_COUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_COUNT_DEPOSITS_Q2,0)) DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q2
			  , (ISNULL(TRANSACTION_COUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_COUNT_DEPOSITS_Q3,0)) DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q3
			  --, (ISNULL(TRANSACTION_COUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_COUNT_DEPOSITS_Q4,0)) DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q4
			  , [TRANSACTION_AMOUNT_DEPOSITS_Q1]
			  , (ISNULL(TRANSACTION_AMOUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_AMOUNT_DEPOSITS_Q2,0)) DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2
			  , (ISNULL(TRANSACTION_AMOUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_AMOUNT_DEPOSITS_Q3,0)) DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q3
			  --, (ISNULL(TRANSACTION_AMOUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_AMOUNT_DEPOSITS_Q4,0)) DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q4
			  , [AVG_BALANCECHANGE_DEPOSITS_Q1]
			  , (ISNULL(AVG_BALANCECHANGE_DEPOSITS_Q1,0)  - ISNULL(AVG_BALANCECHANGE_DEPOSITS_Q2,0)) DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q2
			  , (ISNULL(AVG_BALANCECHANGE_DEPOSITS_Q1,0)  - ISNULL(AVG_BALANCECHANGE_DEPOSITS_Q3,0)) DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q3
			  --, (ISNULL(AVG_BALANCECHANGE_DEPOSITS_Q1,0)  - ISNULL(AVG_BALANCECHANGE_DEPOSITS_Q4,0)) DFT_AVG_BALANCECHANGE_DEPOSITS_Q1_Q4
			  , [DEPOSITED_AMOUNT_DEPOSITS_Q1] 
			  , (ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q2,0)) DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2
			  , (ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q3,0)) DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3
			  --, (ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q4,0)) DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q4
			  , [DEPOSITED_COUNT_DEPOSITS_Q1]
			  , (ISNULL(DEPOSITED_COUNT_DEPOSITS_Q1,0) - ISNULL(DEPOSITED_COUNT_DEPOSITS_Q2,0)) [DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2]
			  , (ISNULL(DEPOSITED_COUNT_DEPOSITS_Q1,0) - ISNULL(DEPOSITED_COUNT_DEPOSITS_Q3,0)) [DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q3]
			  --, (ISNULL(DEPOSITED_COUNT_DEPOSITS_Q1,0) - ISNULL(DEPOSITED_COUNT_DEPOSITS_Q4,0)) [DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q4]
			  , [WITHDRAWAL_AMOUNT_DEPOSITS_Q1]
			  , (ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q2,0)) [DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2]
			  , (ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q3,0)) [DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q3]
			  --, (ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q4,0)) [DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q4]
			  , [WITHDRAWAL_COUNT_DEPOSITS_Q1]
			  , (ISNULL(WITHDRAWAL_COUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_COUNT_DEPOSITS_Q2,0)) [DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2]
			  , (ISNULL(WITHDRAWAL_COUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_COUNT_DEPOSITS_Q3,0)) [DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q3]
			  --, (ISNULL(WITHDRAWAL_COUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_COUNT_DEPOSITS_Q4,0)) [DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q4]
			  , [SUM_INTEREST_DEPOSITS_Q1]
			  , (ISNULL(SUM_INTEREST_DEPOSITS_Q1,0) - ISNULL(SUM_INTEREST_DEPOSITS_Q2,0)) [DFT_SUM_INTEREST_DEPOSITS_Q1_Q2]
			  , (ISNULL(SUM_INTEREST_DEPOSITS_Q1,0) - ISNULL(SUM_INTEREST_DEPOSITS_Q3,0)) [DFT_SUM_INTEREST_DEPOSITS_Q1_Q3]
			  --, (ISNULL(SUM_INTEREST_DEPOSITS_Q1,0) - ISNULL(SUM_INTEREST_DEPOSITS_Q4,0)) [DFT_SUM_INTEREST_DEPOSITS_Q1_Q4]
		into #deposits_transaction
		from #deposit_transaction_temp2

		DROP TABLE IF EXISTS #deposits_summary
		SELECT * 
		into #deposits_summary 
		FROM #membership_deposits A
		left join #deposits_transaction B
		on A.SSN003  = B.SSN004

		
		--DROP TABLE IF EXISTS #updated_deposits_summary
		--SELECT CASE WHEN A.SSN003  = B.SSN004 THEN A.SSN003 
		--            WHEN A.SSN003 is NULL THEN B.SSN004
		--			WHEN B.SSN004 is NULL THEN A.SSN003 END [SSN_Dep]
		--			,A.*,B.*
		--into #updated_deposits_summary 
		--FROM #membership_deposits A
		--full outer join #deposits_transaction B
		--on A.SSN003  = B.SSN004

		-- Merging the Loan Product Summary and Deposits Summary

		DROP TABLE IF EXISTS #merged_loan_deposits_summary
		SELECT * 
		into #merged_loan_deposits_summary
		FROM #deposits_summary A
		left join 
		#loan_product_master B
		on A.SSN003 = B.SSN001

		--DROP TABLE IF EXISTS #updated_merged_loan_deposits_summary
		--SELECT CASE WHEN A.SSN_Dep = B.SSN_L THEN SSN_Dep
		--            WHEN A.SSN_Dep IS NULL THEN B.SSN_L
		--			WHEN B.SSN_L IS NULL THEN A.SSN_Dep END [FINAL_SSN]
		--into #updated_merged_loan_deposits_summary
		--FROM #updated_deposits_summary A
		--full outer join 
		--#updated_loan_product_master B
		--on A.SSN_Dep = B.SSN_L

		--DROP TABLE IF EXISTS Analytics.dbo.SN_depositsLOAN 
		--SELECT TOP 10 *
		--into Analytics.dbo.SN_depositsLOAN
		--FROM #merged_loan_deposits_summary

	/* Appending OnlineBanking data to Master data  */
	drop table if exists #loan_dep_onlinebanking
	select  A.*,DATEDIFF ( day, LastLogon, GETDATE()) AS "Days Since Last Login" 
	into #loan_dep_onlinebanking -- new copy of master data
	from #merged_loan_deposits_summary as A
	LEFT join Q2EVE.[dbo].[vwMemberOnlineBankingSummary] as B
	on A.SSN003 = B.SSN

	/** Appending Bureau Data to master data 091322 **/

drop table if exists Analytics.dbo.REVISED_MASTER_DATA_092022
	select  A.*
	  ,B.[FICO]
      ,B.[CCAPREstimate]
      ,B.[AggregatedSpendPast3Months]
      ,B.[TopOfWalletCCAnnualSpend]
      ,B.[TopOfWalletCCCurrentBalance]
      ,B.[OpenTradeCount]                   
      ,B.[OpenTradeBalance]                  
      ,B.[AutoOpenTradeCount]               
      ,B.[AutoLoanOrgBalanceP12Months]
      ,B.[AutoOpenTradeBalance]             
      ,B.[CCCount]
      ,B.[CCOpenCount]                      
      ,B.[CCTotalAvailableLOC]              
      ,B.[CCOpenBalance]                    
      ,B.[ChargeOffTradeCountP12Months]
      ,B.[ChargeOffTotalBalance]
      ,B.[ForeclosureCountP12Months]
      ,B.[ForeclosureTotalBalance]
      ,B.[BankruptcyCount]
      ,B.[NumberInquiriesP6Months]        
      ,B.[CCWorstRatingP12Months]
      ,B.[AutoWorstRatingP12Months]
      ,B.[MortgageWorstRatingP12Months]
      ,B.[HELOCWorstRatingP12Months]
      ,B.[HEWorstRatingP12Months]
      ,B.[HEOpenCount]                    
      ,B.[HETotalAvailableLOC]            
      ,B.[HEOpenBalance]                 
      ,B.[HELOCOpenCount]
      ,B.[HELOCTotalAvailableLOC]
      ,B.[HELOCOpenBalance]
      ,B.[MortgageOpenCount]             
      ,B.[MortgageOpenBalance]            
      ,B.[RevolvingAccountCount]
      ,B.[CCRevolvingBalance]
      ,B.[CCTripTypeP6Months]
      ,B.[StudentLoanOpenCount]          
      ,B.[StudentLoanOpenBalance]
	into Analytics.dbo.REVISED_MASTER_DATA_092022
	from #loan_dep_onlinebanking  as A
	LEFT join BureauData.[dbo].[TransUnionAttributeHistory] as B
	on a.SSN003 = b.SSN 

------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///***DROPPING MONEYMARKET VARIABLES***\\\-------------------------------------------------

--///** COPY OF Analytics.dbo.REVISED_MASTER_DATA_102022 **///

DROP TABLE IF EXISTS #MoneyMarket_NBP_092022
SELECT * into #MoneyMarket_NBP_092022 FROM Analytics.dbo.REVISED_MASTER_DATA_092022

ALTER TABLE #MoneyMarket_NBP_092022 DROP COLUMN 
DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q2
,DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q3
,DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q2
,DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q3
,DFT_AVG_BALANCECHANGE_MONEYMARKET_Q1_Q2
,DFT_AVG_BALANCECHANGE_MONEYMARKET_Q1_Q3
,DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q2
,DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q3
,[DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q2]
,[DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q3]
,[DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q2]
,[DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q3]
,[DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q2]
,[DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q3]
,[DFT_SUM_INTEREST_DEPOSITS_Q1_Q2]
,[DFT_SUM_INTEREST_DEPOSITS_Q1_Q3]
,PRODUCT_MONEYMARKET_SP
,PRODUCT_MONEYMARKET_Q1
,DFT_PRODUCT_MONEYMARKET_Q1_Q2
,DFT_PRODUCT_MONEYMARKET_Q1_Q3
,TYPE_MONEYMARKET_SP
,TYPE_MONEYMARKET_Q1
,MOB_MONEYMARKET
,AVG_MONTH_END_BALANCE_MONEYMARKET_Q1
,DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2
,DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q3
,SUM_LASTDIVAMOUNT_MONEYMARKET_Q1
,DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2
,DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q3
,AVG_CHARGEOFFAMOUNT_MONEYMARKET_SP

/***** Target Flag Creation *****/
		
--  All Savings TABLE  at StaticPool

DROP TABLE IF EXISTS #savings_SP

SELECT a.PARENTACCOUNT
      ,a.ID
	  ,a.OPENDATE
	  ,a.CLOSEDATE
	  ,a.CHARGEOFFDATE
	  ,a.ProcessDate
	  ,a.BALANCE
	  ,b.ShareTypeDescription
	  ,b.ShareCategory1
	  ,b.ShareCategory2
into #savings_SP
FROM [ARCUSYM000].dbo.SAVINGS A
LEFT JOIN #ShareCategory B
ON A.TYPE = B.ShareType
WHERE 1 = 1
and a.ProcessDate = 20210930
--and a.OPENDATE <> a.CLOSEDATE
and (a.OPENDATE is not null or a.openDATE < '2021-09-30')
and ( a.CLOSEDATE is null or a.CLOSEDATE > '2021-09-30')
and ( a.CHARGEOFFDATE > '2021-09-30' or 
a.CHARGEOFFDATE is NULL)  --  529251

--  MONEYMARKET AT STATICPOOL 

DROP TABLE IF EXISTS #moneymarket_SP

SELECT DISTINCT PARENTACCOUNT
into #moneymarket_SP
FROM #savings_SP
where ShareCategory2 = 'Money Market' -- 10611

--SELECT TOP 100 * FROM #savings_SP
--SELECT * FROM #ShareCategory

-- Mapping the parentaccount of the members having MoneyMarket on SP to SSN

DROP TABLE IF EXISTS #SSN_moneymarket_SP
SELECT DISTINCT SSN 
INTO #SSN_moneymarket_SP
FROM
(
SELECT A.SSN, CASE WHEN A.PARENTACCOUNT = B.PARENTACCOUNT THEN 1 ELSE 0 END [HaveMMonSP]
FROM ARCUSYM000..NAME A
LEFT JOIN #moneymarket_SP B
ON A.PARENTACCOUNT = B.PARENTACCOUNT
) R
WHERE [HaveMMonSP] = 1 --10543

-- Savings table AFTER StaticPool

DROP TABLE IF EXISTS #savings_after_SP

SELECT a.PARENTACCOUNT
      ,a.ID
	  ,a.OPENDATE
	  ,a.CLOSEDATE
	  ,a.CHARGEOFFDATE
	  ,a.ProcessDate
	  ,case when B.ShareCategory2 = 'CD' and A.BALANCE = 0 then 0 else 1 end [carryforwardflag]
	  ,b.ShareTypeDescription
	  ,b.ShareCategory1
	  ,b.ShareCategory2
into #savings_after_SP
FROM [ARCUSYM000].dbo.SAVINGS A
LEFT JOIN #ShareCategory B
ON A.TYPE = B.ShareType
WHERE 1 = 1
and a.ProcessDate BETWEEN 20211031 and 20220930
--and a.OPENDATE <> a.CLOSEDATE
and (a.OPENDATE is not null or a.OPENDATE < '2021-09-30')
and ( a.CLOSEDATE is null
or a.CLOSEDATE > '2021-09-30')
and ( a.CHARGEOFFDATE > '2021-09-30' or 
a.CHARGEOFFDATE is NULL)   -- 19083668 --35321225

--select top 10 * from #savings_after_SP where PARENTACCOUNT ='0014621084' and ID = '0001' order by ProcessDate

-- Savings table without members having Money Market on Static Pool

DROP TABLE IF EXISTS #savings_wo_MMSP
SELECT *
INTO #savings_wo_MMSP
FROM
(
SELECT a.*
     , CASE WHEN a.PARENTACCOUNT = b.PARENTACCOUNT THEN 0 ELSE 1 END [NoMMinSP]  
FROM #savings_after_SP a
LEFT JOIN #moneymarket_SP b
on a.PARENTACCOUNT = b.PARENTACCOUNT
) M
WHERE [NoMMinSP] = 1 
and carryforwardflag = 1-- 18030551 --32502522

--  ParentAccount who take MoneyMarket after SP (Does not have MoneyMarket before SP)

DROP TABLE IF EXISTS #Par_MM_after_SP
SELECT Distinct PARENTACCOUNT
into #Par_MM_after_SP
FROM #savings_wo_MMSP
WHERE ShareCategory2 = 'Money Market'  --4802 --5053

--  Mapping the ParentAccount to SSN

DROP TABLE IF EXISTS #SSN_Target_MM
SELECT DISTINCT SSN
INTO #SSN_Target_MM
FROM
(
SELECT A.SSN, CASE WHEN A.PARENTACCOUNT = B.PARENTACCOUNT THEN 1 ELSE 0 END [match]
FROM ARCUSYM000..NAME A
LEFT JOIN #Par_MM_after_SP B
ON A.PARENTACCOUNT = B.PARENTACCOUNT
) S
where [match] = 1 -- 4926


-- Final Table Creation :

/*excluding all those SSN having MoneyMarket in SP*/

DROP TABLE IF EXISTS #temp_MM_exclusion_SP 
SELECT F.*
INTO #temp_MM_exclusion_SP
FROM
(
SELECT A.*, CASE WHEN A.SSN003 = B.SSN THEN 0 ELSE 1 END [NoMMInSP]
FROM #MoneyMarket_NBP_092022 A
LEFT JOIN #SSN_moneymarket_SP B
ON A.SSN003 = B.SSN
) F
WHERE [NoMMInSP] = 1  --352203

--DROPPING [NoMMInSP] (we dont need it in final ds)
 
 ALTER TABLE #temp_MM_exclusion_SP DROP COLUMN [NoMMInSP]

 -- FINAL TABLE : Analytics.dbo.NBP_MoneyMarket_202208

DROP TABLE IF EXISTS #temp13

SELECT A.SSN003[SSN], A.*,CASE WHEN A.SSN003 = B.SSN THEN 1 ELSE 0 END [MM_TargetFlag]
INTO #temp13
FROM #temp_MM_exclusion_SP A
LEFT JOIN #SSN_Target_MM B
ON A.SSN003 = B.SSN 

/*********** Dropping Members who have MOB less than 6 months *******************/
--select distinct ssn from #temp13 --261000

drop table if exists Analytics.dbo.NBP_MoneyMarket_202209
select *
into Analytics.dbo.NBP_MoneyMarket_202209
from #temp13 
where SSN in (select distinct AccountPrimeNameSSN from ARCUSYM000.arcu.ARCUAccountDetailed where ProcessDate = 20210930 and datediff(MONTH,AccountOpenDate,'2021-09-30') >= 6 ) --287900

--SELECT [MM_TargetFlag], Count(*)  FROM Analytics.dbo.NBP_MoneyMarket_202209 group by [MM_TargetFlag] --2041


-----------------------------------------------
/****** Splitting of Train & Test Data *******/
----------------------------------------------

	DROP TABLE IF EXISTS Analytics.dbo.NBP_MoneyMarket_train_202209
	DROP TABLE IF EXISTS Analytics.dbo.NBP_MoneyMarket_test_202209

	SELECT * 
	into Analytics.dbo.NBP_MoneyMarket_train_202209
	FROM Analytics.dbo.NBP_MoneyMarket_202209
	where 1=0
	
	SELECT * 
	into Analytics.dbo.NBP_MoneyMarket_test_202209
	FROM Analytics.dbo.NBP_MoneyMarket_202209
	where 1=0
	
	INSERT INTO Analytics.dbo.NBP_MoneyMarket_train_202209
	     EXEC sp_execute_external_script
		             @language = N'R'
					 , @script = N'

					 library(caret)

					 Data1 <- data.frame(Demo1_New)
					 set.seed(129)
					 train_indi <- createDataPartition(Data1$MM_TargetFlag,p=0.7,list=F)
					 train_data <- data.frame(Data1[train_indi,]);
					 train_data
					 '
	     , @output_data_1_name = N'train_data'
		     ,@input_data_1 = N'SELECT * FROM Analytics.dbo.NBP_MoneyMarket_202209'
			 , @input_data_1_name = N'Demo1_New'

INSERT INTO Analytics.dbo.NBP_MoneyMarket_test_202209
SELECT * 
from Analytics.dbo.NBP_MoneyMarket_202209
WHERE SSN not in (SELECT SSN from Analytics.dbo.NBP_MoneyMarket_train_202209)







--SELECT DISTINCT SSN FROM #SSN_Target_MM where SSN not in (SELECT SSN003 from #addingBureauData )

--SELECT DISTINCT SSN FROM #SSN_Target_MM where SSN not in (SELECT SSN003 from #temp_MM_exclusion_SP )

--SELECT SSN003 from #temp_MM_exclusion_SP where SSN003 not in (SELECT SSN from #SSN_Target_MM)

--SELECT DISTINCT SSN FROM #SSN_Target_MM where SSN not in (SELECT SSN003 from #NBP_MoneyMarket_202208 where MM_TargetFlag = 1 )

-----------------------------------------------
/******* Validation of the discrepancy *******/
-----------------------------------------------

-- SSN not in the Revised Master data
--DROP TABLE IF EXISTS #SSN_notinmaster
--SELECT SSN
--into #SSN_notinmaster
--FROM(
--SELECT A.SSN003,B.SSN,CASE WHEN A.SSN003 = B.SSN THEN 1 ELSE 0 END [MM_TargetFlag]
----INTO #NBP_MoneyMarket_202208
--FROM #temp_MM_exclusion_SP A
--FULL OUTER JOIN #SSN_Target_MM B
--ON A.SSN003 = B.SSN ) W
--where SSN003 is NULL          --3100

--DROP TABLE IF EXISTS #SSN_notinStaticSSN
--SELECT DISTINCT AccountNumber,SSN
--into #SSN_notinStaticSSN
--FROM #Static_SSN_account where SSN in (SELECT SSN FROM #SSN_notinmaster)  -- 580 SSN only remain in #Static_SSN_account(the condition are not satisfied for other remaining)

--SELECT DISTINCT PARENTACCOUNT,SSN
--into  #par_notiname
--FROM ARCUSYM000..NAME where SSN in (SELECT SSN FROM #SSN_notinStaticSSN) -- (but they are all available in ARCUSYM000..NAME table)

----SELECT PARENTACCOUNT 
------into #loanloanssn 
----from ARCUSYM000..Loan where PARENTACCOUNT in (SELECT PARENTACCOUNT FROM #par_notiname) and ProcessDate = 20210930 and closedate is not null

--SELECT DISTINCT PARENTACCOUNT
----into #ruledout
--from ARCUSYM000..SAVINGS 
--where PARENTACCOUNT in (SELECT AccountNumber FROM #SSN_notinStaticSSN) 
--and ProcessDate = 20210930 and closedate is not null 
--and closedate < '2021-09-30' and opendate < '2021-09-30' 
--and datediff(MONTH,OPENDATE,'2021-09-30') >= 6 
--and balance = 0


--SELECT DISTINCT AccountNumber FROM #SSN_notinStaticSSN where AccountNumber not in (SELECT PARENTACCOUNT FROM #ruledout) 

--select * FROM #SSN_notinStaticSSN 

--Declaring the STATIC POOL

		DECLARE @staticpooldate date
		set @staticpooldate = '2022-08-31'

		--Taking Member Having General membership of Greenstate

		drop table if exists #Name
		select distinct a.PARENTACCOUNT,SSN 
		into #NAME
		from 
		(select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date from ARCUSYM000.dbo.NAME) a
		left join ARCUSYM000.dbo.SAVINGS b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		and a.ProcessDate=b.ProcessDate
		where a.TYPE=0
		and a.Process_date=@staticpooldate
		
		
		--
		 drop table if exists #Static_SSN_account_final
		select distinct  SSN 
		--,PARENTACCOUNT,Process_date
		into #Static_SSN_account_final
		from
		(    ---- SAving accounts detail
			select  b.SSN
					,a.PARENTACCOUNT
					,id
					,cast(OPENDATE as date) OPEN_DATE
					,cast(CLOSEDATE as date) CLOSE_DATE
					,cast(CHARGEOFFDATE as date) CHARGEOFFDATE
					,left(a.ProcessDate,6) ProcessDate_V
					,datefromparts(left(a.ProcessDate ,4),right(left(a.ProcessDate,6),2),right(a.ProcessDate,2)) Process_date
					,case when len(month(closedate))=1 then CONCAT(year(closedate),0,month(closedate)) 
						  else CONCAT(year(closedate),month(closedate)) end CLOSED_DATE_SAVINGS 
					,case when len(month(OpenDate))=1 then CONCAT(year(OpenDate),0,month(OpenDate)) 
					      else CONCAT(year(OpenDate),month(OpenDate))end  OPEN_DATE_INT_SAVINGS
					,case when len(month(CHARGEOFFDATE))=1 then CONCAT(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE)) 
					      else CONCAT(year(CHARGEOFFDATE),month(CHARGEOFFDATE))end  CHARGEOFF_DATE_SAVINGS
		
			from ARCUSYM000.dbo.SAVINGS a
			left join #NAME b 
			on a.PARENTACCOUNT=b.PARENTACCOUNT
		) aa
		where ssn is not null 
			and OPEN_DATE<@staticpooldate  
			and (CLOSE_DATE is null or CLOSE_DATE>@staticpooldate)
			and (CHARGEOFFDATE is null or CHARGEOFFDATE>@staticpooldate)  
			and Process_date=@staticpooldate 
		
		
		-- Remaning Parent to account name
		drop table if exists #Static_SSN_account
			select distinct 
				PARENTACCOUNT AccountNumber
				,SSN
			into #Static_SSN_account
			from #NAME

			----------------------------------
			-----///*** commercial ***\\\---
			 drop table if exists #commercial_loan
			
			--select distinct parentaccount from #commercial_loan
			select 
				*
				,case when  (LoanCategory1 like 'commercial %' or  LoanCategory1='commercial') and Quarters='Staticpool' then 1 else 0 end Staticpool_Commercial_loan_flag
			into #commercial_loan
			from
			(
					select [ProcessDate]
						   ,left(ProcessDate,6) ProcessDate_V
						   ,Process_Date
						   ,Open_date
						   ,Close_date
						   ,case when Process_Date in ((DATEADD(month,-12,@staticpooldate)),(DATEADD(month,-11,@staticpooldate)),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
		                         when Process_Date in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
 								 when Process_Date in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
								 when Process_Date in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
								 when Process_Date in (@staticpooldate) then 'Staticpool'
							end Quarters
							,d.SSN
							,[PARENTACCOUNT]
							,[ID]
							,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
							,case when len(month(a.closedate))=1 then CONCAT(year(a.closedate),0,month(a.closedate))
							      else CONCAT(year(a.closedate),month(a.closedate)) end  Closed_date_INT
							,case when len(month(a.opendate))=1 then CONCAT(year(a.opendate),0,month(a.opendate))
							      else CONCAT(year(a.opendate),month(a.opendate)) end  OPEN_date_INT
							,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
							,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
							,[TYPE]
							,[LASTFMDATE]
							,[LASTTRANDATE]
							,[ORIGINALDATE]
							,a.[OPENDATE]
							,a.[CLOSEDATE]
							,[LOANCODE]
							,[APPROVALCODE]
							,[APPROVALDATE]
							,[PAYMENTFREQUENCY]
							,[PARTIALPAYMENT]
							,[PAYMENT]
							,[PAYMENTCOUNT]
							,[DUEDAY1]
							,[INTERESTRATE]
							,[ORIGINALBALANCE]
							,[CREDITLIMIT]
							,[DESCRIPTION]
							,[NSFMONTHTODATE]
							,[MATURITYDATE]
							,[APR]
							,[CREDITSCORE]
							,[ADVANCEAMOUNT]
							,b.LoanCategory1
							,b.LoanCategory3
							,b.LoanCategory4
							,b.LoanTypeDescription
							,CRPMTCURRENT
					  from 
					 (
						 select * 
						 ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
						 ,cast(OPENDATE as date) Open_date
						 ,cast(CLOSEDATE as date) Close_date,cast(MATURITYDATE as date) as MATURITY_DATE 
						 from ARCUSYM000.dbo.LOAN 
				     ) a
			
					left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
					on b.loantype=a.TYPE
					left join  #Static_SSN_account d
					on a.PARENTACCOUNT=d.AccountNumber
					where  ORIGINALDATE is not null 
					and a.OpenDate is not null 
					and a.Open_date < @staticpooldate  
					and (a.CLOSEDATE is null or a.Close_date>@staticpooldate )   
					and process_date between (select dateadd(MM,-12,@staticpooldate)) and (select dateadd(MM,12,@staticpooldate)) 
					and  PARENTACCOUNT in (select distinct AccountNumber PARENTACCOUNT from #Static_SSN_account )
				-- -- To be test
		) AA
		where  ( LoanCategory1 like 'commercial %' or  LoanCategory1='commercial')  
		and LoanCategory3 <> 'Writeoff' -- added on 101822
		and LoanCategory4 <> 'Writeoff' -- added on 101822
		and OPEN_DATE<@staticpooldate
		 and (Close_date is null or Close_date>@staticpooldate) 
		 and ORIGINALDATE>= Open_date 
		 and Quarters is not null
		
		select distinct ssn from #commercial_loan
		--select cast(ORIGINALDATE as date) ORIGINALDATE,cast(OPENDATE as date) OPENDATE,* from loan
--===== AutoLoan Member at staticpool ====
--=================================== ====
DECLARE @staticpooldate DATE;

set @staticpooldate = '2024-08-31'

DROP TABLE IF EXISTS #processdate2;

SELECT 
    Process_date,
    MAX(ProcessDate) AS Max_ProcessDate
INTO #processdate2
FROM (
    SELECT 
        ProcessDate,
        LEFT(ProcessDate, 6) AS Process_date 
    FROM 
        arcusym000.dbo.SAVINGS
) AS A
WHERE 
    Process_date >= CONVERT(INT, FORMAT(@staticpooldate, 'yyyyMM')) and 
    Process_date <= CONVERT(INT, FORMAT(DATEADD(MONTH, 12, @staticpooldate), 'yyyyMM'))
GROUP BY 
    Process_date;

Select * from #processdate2 order by 1

DROP TABLE IF EXISTS #TEMP3
SELECT DISTINCT A.PARENTACCOUNT,A.ID, CONCAT(A.PARENTACCOUNT,A.ID) UNID,A.BALANCE,C.SSN,
A.OPENDATE

INTO #TEMP3
FROM ARCUSYM000.DBO.LOAN A
LEFT JOIN [ARCUSYM000].[ARCU].ARCULOANCATEGORY B	
ON B.LOANTYPE=A.TYPE
LEFT JOIN
ARCUSYM000..LOANNAME C
ON A.PARENTACCOUNT=C.PARENTACCOUNT
AND A.ID=C.PARENTID
WHERE 
B.LOANCATEGORY1 = 'CONSUMER' AND
B.LOANCATEGORY2='VEHICLE'
AND  LOANCATEGORY3 NOT IN ('INDIRECT','SMALL BUSINESS')
AND  LOANCATEGORY4 NOT IN ('WRITEOFF','WORKOUT/TDR','BUSINESS VEHICLE')
AND A.PROCESSDATE =  CONVERT(INT, FORMAT(@staticpooldate, 'yyyyMMdd'))
AND A.OPENDATE IS NOT NULL 
AND A.CLOSEDATE IS NULL 
AND A.CHARGEOFFDATE IS NULL

select distinct OPENDATE from #TEMP5 order by 1

drop table if exists #temp5
select distinct a.PARENTACCOUNT,a.ID, concat(a.PARENTACCOUNT,a.id) UNID,c.SSN,
a.OPENDATE
into #temp5
FROM ARCUSYM000.DBO.LOAN A
LEFT JOIN [ARCUSYM000].[ARCU].ARCULOANCATEGORY B	
ON B.LOANTYPE=A.TYPE
LEFT JOIN
ARCUSYM000..LOANNAME C
ON A.PARENTACCOUNT=C.PARENTACCOUNT
AND A.ID=C.PARENTID
WHERE 
B.LOANCATEGORY1 = 'CONSUMER' AND
B.LOANCATEGORY2='VEHICLE'
AND  LOANCATEGORY3 NOT IN ('INDIRECT','SMALL BUSINESS')
AND  LOANCATEGORY4 NOT IN ('WRITEOFF','WORKOUT/TDR','BUSINESS VEHICLE')
 and a.ProcessDate  in (select Max_ProcessDate from #processdate2)
 and a.PARENTACCOUNT not in (select PARENTACCOUNT from #temp3 )
 and c.ssn in ( (select distinct AccountPrimeNameSSN from ARCUSYM000.arcu.ARCUAccountDetailed 
where ProcessDate = CONVERT(INT, FORMAT(@staticpooldate, 'yyyyMMdd')) and 
datediff(MONTH,AccountOpenDate,@staticpooldate) >= 6 ))
and (OPENDATE  between   @staticpooldate
 and DATEADD(MONTH, 12, @staticpooldate))
 --and DATEADD(mm,ProcessDate,OPENDATE) mob
 and a.OPENDATE is not null 
 and a.CLOSEDATE is null 
 and a.CHARGEOFFDATE is null

 --Master data copy

 select top 8 * from #1

 Drop table if exists #1
SELECT  * 
into #1
 FROM
  Analytics.dbo.REVISED_MASTER_DATA_AUG2023
  --Analytics..REVISED_MASTER_DATA

  select COLUMN_NAME from INFORMATION_SCHEMA.COLUMNS
  where TABLE_NAME = 'Analytics.dbo.REVISED_MASTER_DATA_AUG2023'
  and COLUMN_NAME like '%auto%'
 
alter table #1 drop column
        [TRANSACTION_COUNT_CHECKING_Q1]
      ,[DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2]
      ,[DFT_TRANSACTION_COUNT_CHECKING_Q1_Q3]
      ,[TRANSACTION_AMOUNT_CHECKING_Q1]
      ,[DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2]
      ,[DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q3]
      ,[AVG_TRANSACTION_CHECKING_Q1]
      ,[DFT_AVG_TRANSACTION_CHECKING_Q1_Q2]
      ,[DFT_AVG_TRANSACTION_CHECKING_Q1_Q3]
      ,[DEPOSITED_AMOUNT_CHECKING_Q1]
      ,[DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2]
      ,[DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q3]
      ,[DEPOSITED_COUNT_CHECKING_Q1]
      ,[DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2]
      ,[DFT_DEPOSITED_COUNT_CHECKING_Q1_Q3]
      ,[WITHDRAWAL_AMOUNT_CHECKING_Q1]
      ,[DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2]
      ,[DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q3]
      ,[WITHDRAWAL_COUNT_CHECKING_Q1]
      ,[DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2]
      ,[DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q3]
      ,[SUM_INTEREST_CHECKING_Q1]
      ,[DFT_SUM_INTEREST_CHECKING_Q1_Q2]
      ,[DFT_SUM_INTEREST_CHECKING_Q1_Q3],[CHECKING_Q1Flag],[CHECKING_StaticpoolFlag],[PRODUCT_CHECKING_SP]
      ,[PRODUCT_CHECKING_Q1]
      ,[DFT_PRODUCT_CHECKING_Q1_Q2]
      ,[DFT_PRODUCT_CHECKING_Q1_Q3]
      ,[TYPE_CHECKING_SP]
      ,[TYPE_CHECKING_Q1]
      ,[DFT_TYPE_CHECKING_Q1_Q2]
      ,[DFT_TYPE_CHECKING_Q1_Q3]
      ,[MOB_CHECKING]
      ,[AVG_MONTH_END_BALANCE_CHECKING_Q1]
      ,[DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2]
      ,[DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q3]
      ,[SUM_LASTDIVAMOUNT_CHECKING_Q1]
      ,[DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2]
      ,[DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q3]
      ,[AVG_CHARGEOFFAMOUNT_CHECKING_SP]
      ,[AVG_CHARGEOFFAMOUNT_CHECKING_Q1]
      ,[DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q2]
      ,[DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q3]

--Select distinct ssn that not in #temp3
Drop table if exists #final
SELECT SSN003 
INTO #final 
FROM #1
EXCEPT 
SELECT SSN 
FROM #temp3




 /********** -- #1 loan table at Staticpool  -- **********/
		--  All Loan TABLE  at StaticPool

    DROP TABLE  IF EXISTS #AUTOLOAN_SP -- STATIC POOL
    SELECT A.PARENTACCOUNT,A.ID,A.OPENDATE,A.CLOSEDATE,A.CHARGEOFFDATE,A.PROCESSDATE,B.LOANCATEGORY2,B.LOANCATEGORY3,B.LOANCATEGORY4
    INTO #AUTOLOAN_SP
    FROM ARCUSYM000.DBO.LOAN A
    LEFT JOIN [ARCUSYM000].[ARCU].[ARCULOANCATEGORY] B
    ON B.LOANTYPE=A.TYPE
    WHERE 1 = 1
	AND A.PROCESSDATE = 20211231 
	AND (A.CLOSEDATE IS NULL OR  A.CLOSEDATE > '2021-12-31' )-- CAHNGE MADE OF OPEN < STATICPOOL
	AND (A.OPENDATE IS NOT NULL OR A.OPENDATE < '2021-12-31' )-- CAHNGE MADE OF OPEN < STATICPOOL
	AND (A.CHARGEOFFDATE > 2021-12-31 OR A.CHARGEOFFDATE IS NULL) --165953

	--select * FROM #Autoloan_SP

/********** -- #2 LOAN AT STATICPOOL (Vehicle) -- **********/
		
	drop table if exists #AL_SP -- distinct parent account from static pool
	SELECT Distinct PARENTACCOUNT
	into #AL_SP
	FROM #Autoloan_SP 
	WHERE LOANCATEGORY2 ='VEHICLE' 
	AND LOANCATEGORY3 NOT IN ('INDIRECT') 
	AND LOANCATEGORY4 NOT IN ('WRITEOFF','WORKOUT/TDR') --21208 

	--select * FROM #AL_SP

/********** -- #3 Loan table AFTER StaticPool -- **********/

    DROP TABLE IF EXISTS #loan_aftr_SP -- one year after static pool
    select a.PARENTACCOUNT,a.ID,a.OPENDATE,a.CLOSEDATE,a.ProcessDate,b.LoanCategory2,b.LoanCategory3,b.LoanCategory4
    into #loan_aftr_SP
    from ARCUSYM000.dbo.LOAN a
    left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
    on b.loantype=a.TYPE
    where a.ProcessDate BETWEEN 20220131 
	and 20221231 
	and a.CLOSEDATE is null and a.OPENDATE is not null
	and (a.CHARGEOFFDATE > 2021-12-31 or a.CHARGEOFFDATE is NULL) -- 14799393

 
/********** -- #4 Loan table without MEMBER Having Vehicle Loan AT StaticPool -- **********/

    DROP TABLE IF EXISTS #loan_without_SP
    SELECT *
    INTO #loan_without_SP
    FROM
    (
    SELECT A.*, CASE WHEN A.PARENTACCOUNT = B.PARENTACCOUNT THEN 0 ELSE 1 END [NOALINSP]
    FROM #loan_aftr_SP A
    LEFT JOIN #AL_SP B
    ON A.PARENTACCOUNT = B.PARENTACCOUNT
    ) P
    WHERE [NOALINSP] = 1  --5592976 

	--select * from #loan_without_SP 

/********** -- #5 PARENTACCOUNT WHO ARE HAVING Vehicle LOAN AFTER STATICPOOL -- **********/
	
	DROP TABLE IF EXISTS #AUTOLOAN_TARGET
	SELECT 
	DISTINCT PARENTACCOUNT
	INTO #AUTOLOAN_TARGET
	FROM #LOAN_WITHOUT_SP 
	WHERE LOANCATEGORY2 ='VEHICLE' 
	AND LOANCATEGORY3 NOT IN ('INDIRECT') 
	AND LOANCATEGORY4 NOT IN ('WRITEOFF','WORKOUT/TDR') --40026

/********** -- #6  MAPPING THIS PARENTACCOUNT WITH SSN -- **********/

    DROP TABLE IF EXISTS #AL_target_SSN
    SELECT distinct SSN
    into #AL_target_SSN
    from
    (
    SELECT  SSN,B.PARENTACCOUNT,CASE WHEN A.PARENTACCOUNT = B.PARENTACCOUNT then 1 else 0 end [match] 
    FROM ARCUSYM000.dbo.NAME A
    LEFT JOIN #Autoloan_target B
    ON A.PARENTACCOUNT = B.PARENTACCOUNT
    ) W
    where [match] = 1 --40770


/********** -- #7  MAPPING PARENTACCOUNT OF #AL_SP WITH SSN (SSN HAVING AUTO LOAN AT STATIC POOL) -- **********/

		DROP TABLE IF EXISTS #AL_SP_SSN
		SELECT DISTINCT E.SSN 
		INTO #AL_SP_SSN
		FROM
		(
		SELECT A.*,CASE WHEN A.PARENTACCOUNT = B.PARENTACCOUNT THEN 1 ELSE 0 END [ALInSP]
		FROM ARCUSYM000..NAME A
		LEFT JOIN #AL_SP B
		ON A.PARENTACCOUNT = B.PARENTACCOUNT
		) E
		WHERE [ALInSP] = 1  -- 105495

/********** -- #8  EXCLUDING ALL THOSE SSN HAVING AUTO LOAN IN SP -- **********/

DROP TABLE IF EXISTS #temp_AL_exclusion_SP 
SELECT F.*
INTO #temp_AL_exclusion_SP
FROM
(
SELECT A.*, CASE WHEN A.SSN003 = B.SSN THEN 0 ELSE 1 END [NoALInSP]
FROM #AutoLoan_NBP A
LEFT JOIN #AL_SP_SSN B
ON A.SSN003 = B.SSN
) F
WHERE [NoALInSP] = 1 -- 251835


/********** -- #9 DROPPING [NoALInSP] (we dont need it in final Dataset) -- **********/

 ALTER TABLE #temp_AL_exclusion_SP DROP COLUMN [NoALInSP]


/********** -- #10 Creating Target Flag -- **********/

DROP TABLE IF EXISTS #Auto_TargetFlag
SELECT A.*,CASE WHEN A.SSN003 = B.SSN THEN 1 ELSE 0 END [AL_TargetFlag]
INTO #Auto_TargetFlag
FROM #temp_AL_exclusion_SP A
LEFT JOIN #AL_target_SSN B
ON A.SSN003 = B.SSN         -- 251835













































--select count(SSN003) from #1

--Flag creation 

drop table if exists #Checking_NBP
SELECT  *
,CASE WHEN A.SSN003 = B.SSN THEN 1 ELSE 0 end  CHK_Target 
into #Checking_NBP
FROM #1 a 
LEFT JOIN #temp5 b
on A.SSN003 = B.SSN 
where 
A.SSN003 IN (SELECT * FROM #final)
and 
A.SSN003 in (select distinct AccountPrimeNameSSN from ARCUSYM000.arcu.ARCUAccountDetailed 
where ProcessDate = 20220331 and datediff(MONTH,AccountOpenDate,'2022-03-31') >= 6 )
--A.SSN003 not in (select distinct  SSN from #temp3)

Drop table if exists Analytics.dbo.NBPCheking_new
select *
into Analytics.dbo.NBPCheking_new
from #Checking_NBP

select count(*) from Analytics.dbo.NBPCheking_new
where CHK_Target=1


			/************ SPLITTING INTO TRAIN AND TEST **************/

			DROP TABLE IF EXISTS #SPLIT

			SELECT *,(CASE WHEN NTILE(10) OVER (ORDER BY RAND()) <= 7 THEN 'TRAIN' ELSE 'TEST' END) SPLIT
			INTO #SPLIT
			FROM Analytics.dbo.NBPCheking_new

			/************ TRAIN DATA ************/

			DROP TABLE IF EXISTS Analytics.dbo.NBPCheking_new_TRAIN

			SELECT * 
			INTO Analytics.dbo.NBPCheking_new_TRAIN
			FROM #SPLIT
			WHERE SPLIT = 'TRAIN'    --228389

			/************ TEST DATA ************/

			DROP TABLE IF EXISTS Analytics.dbo.NBPCheking_new_TEST

			SELECT * 
			INTO Analytics.dbo.NBPCheking_new_TEST
			FROM #SPLIT
			WHERE SPLIT = 'TEST'     --228389

			DROP TABLE IF EXISTS Analytics.dbo.NBPCheking_new_TRAINV1

			SELECT * 
			INTO Analytics.dbo.NBPCheking_new_TRAINV1
			FROM  Analytics.dbo.NBPCheking_new
			WHERE SSN003 IN (SELECT SSN003 FROM Analytics.dbo.NBPCheking_new_TRAIN)


			
			DROP TABLE IF EXISTS Analytics.dbo.NBPCheking_new_TESTV1

			SELECT * 
			INTO Analytics.dbo.NBPCheking_new_TESTV1
			FROM  Analytics.dbo.NBPCheking_new
			WHERE SSN003 IN (SELECT SSN003 FROM Analytics.dbo.NBPCheking_new_TEST)
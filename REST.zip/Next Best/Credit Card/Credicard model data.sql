

		--select sum(Money_market_ACCT_Flag) from master_table_data
		--	exec [dbo].[Dynamic_Master_data] @staticpooldate as date
		Select * from ##masterdata
		

go
		-- drop table if exists #CC_SSN_Staticpool
			select distinct  [Social Security Number] SSN
			,Durable_Key
			,[Account Number]
			,Extract_ACCOUNT_OPEN_DATE 
			INTO #CC_SSN_Staticpool
			from Analytics..cardholder
			where 
			--[External Status Code]='' and [Internal Status Code] in ('','N') and
			 extract_datepart<=201801

			go
		-- drop table if exists Credit_card_Model_data
		select *,case when CC_Target_flag is null then 0 else CC_Target_flag end Final_Creditcard_Flag
		into analytics..Credit_Card_Model_Data_new
		from 
		analytics..master_table_data
		where ssn not in (select ssn from #CC_SSN_Staticpool)
		and MOB_Savings is not null
		
		

		


		go

		-- drop table if exists Analytics..Creditcard_model_No_R2_V1
		-- drop table if exists Analytics..Creditcard_model_No_R2_Static
		-- table with NO r2 checkign in data
		select  * 
		into Analytics..Creditcard_model_No_R2_V1
		from
		(select *,case when CC_Target_flag is null then 0 else CC_Target_flag end Final_Creditcard_Flag
		from Analytics..Master_table_data_V1
		where ssn not in (select ssn from #CC_SSN_Staticpool) and MOB_Savings is not null ) a
		where  ssn not in (select ssn from analytics..R2_CC_Member)

		go

		-- drop table if exists #R2_before_static
		select distinct a.ssn 
		INTO #R2_before_static
		from Analytics..Master_table_data_V1 a
		 inner join  analytics..R2_CC_Member b
		 on a.SSN=b.SSN
		 where MOB_Savings is not null and (CC_Target_flag is null or CC_Target_flag=0)
		 and a.ssn not in (select ssn from #CC_SSN_Staticpool)

		 go


		 -- drop table if exists Analytics..Creditcard_model_No_R2_Static
		select *
		into Analytics..Creditcard_model_No_R2_Static
		from
		(select *,case when CC_Target_flag is null then 0 else CC_Target_flag end Final_Creditcard_Flag
		from Analytics..Master_table_data_V1
		where ssn not in (select ssn from #CC_SSN_Staticpool) and MOB_Savings is not null ) a
		where  ssn not in (select ssn from #R2_before_static)



		
		
		
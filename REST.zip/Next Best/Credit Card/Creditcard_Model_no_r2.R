rm(list=ls())
library(RODBC)
databaseConnection <- odbcDriverConnect("Driver={SQL Server};server=ACARCU01;database=Analytics;trusted_connection=TRUE")
Credit_Card_Data <- sqlQuery(databaseConnection, "select  *  from Creditcard_model_No_R2_V1")
CREDITCARDdataframe <- data.frame(Credit_Card_Data,stringsAsFactors=FALSE)


#library(pastecs)
#stats <- stat.desc(CREDITCARDdataframe)
#write.csv(stats, "Creditcard_STATS1.csv")
#Colnames.creditcarddataframe <- colnames(CREDITCARDdataframe)
#write.csv(Colnames.creditcarddataframe,"colnames.creditcarddataframe.csv")

CREDITCARDdataframe1 <- (CREDITCARDdataframe[,c(1,1014,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,139,140,141,143,144,145,146,147,148,149,150,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,205,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,291,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,342,343,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,377,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,443,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469,470,471,472,473,474,475,476,477,478,479,480,481,482,483,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,523,524,525,526,527,528,529,530,531,532,533,534,535,536,537,538,539,540,541,542,543,544,545,546,547,548,549,550,551,552,553,554,555,556,557,558,559,560,561,562,563,564,565,566,567,568,569,570,571,572,573,574,575,576,577,578,579,580,581,582,583,584,585,586,587,588,589,590,591,592,593,594,595,596,597,598,599,600,601,602,603,604,605,606,607,608,609,610,611,612,613,614,615,616,617,618,619,620,621,622,623,624,625,626,627,628,629,630,631,632,633,634,635,636,637,638,639,640,641,642,643,644,645,646,647,648,649,650,651,652,653,654,655,656,657,658,659,660,661,662,663,664,665,666,667,668,669,670,671,672,673,674,675,676,677,678,679,680,681,682,683,684,685,686,687,688,689,690,691,692,693,694,695,696,697,698,699,700,701,702,703,704,705,706,707,708,709,710,711,712,713,714,715,716,717,718,719,720,721,722,723,724,725,726,727,728,729,730,731,732,733,734,735,736,737,738,739,740,741,742,743,744,745,746,747,748,749,750,751,752,753,754,755,756,757,758,759,760,761,762,763,764,765,766,767,768,769,770,771,772,773,774,775,776,777,778,779,780,781,782,783,784,785,786,787,788,789,790,791,792,793,794,795,796,797,798,799,800,801,802,803,804,805,806,807,808,809,810,811,812,813,814,815,816,817,818,819,820,821,822,823,824,825,826,827,828,829,830,831,832,833,834,835,836,837,838,839,840,841,842,843,844,845,846,847,848,849,850,851,852,853,854,855,856,857,858,859,860,861,862,863,864,865,866,867,868,869,870,871,872,873,874,875,876,877,878,879,880,881,882,883,884,885,886,887,888,889,890,891,892,893,894,895,896,897,898,899,900,901,902,903,904,905,906,907,910,911,912,913,914,915,916,917,918,919,920,921,922,923,924,927,928,929,930,931,932,933,934,935,936,937,938,939,940,941,944,945,946,947,948,949,950,951,952,953,954,955,956,957,958,961,962,963,964,965,966,967,968,969,970,971,972,973,974,975,978,979,980,981,982,983,984,985,986,987,988,989,990,991,992,995,996,997,998,999,1000,1001,1002,1003,1004,1005,1006,1007,1008,1009,1010,1011,1012,1013)])
#Colnames.creditcarddataframe1 <- colnames(CREDITCARDdataframe1)
#write.csv(Colnames.creditcarddataframe1,"colnames.creditcarddataframe1.csv")
CREDITCARDdataframe1$Final_Creditcard_Flag[is.na(CREDITCARDdataframe1$Final_Creditcard_Flag)] <- 0
CREDITCARDdataframe1$Staticpool_Checking_flag[is.na(CREDITCARDdataframe1$Staticpool_Checking_flag)] <- 0
CREDITCARDdataframe1$Staticpool_Certificates_flag[is.na(CREDITCARDdataframe1$Staticpool_Certificates_flag)] <- 0
CREDITCARDdataframe1$StaticPool_Money_market_flag[is.na(CREDITCARDdataframe1$StaticPool_Money_market_flag)] <- 0
CREDITCARDdataframe1$StaticPool_Saving_flag[is.na(CREDITCARDdataframe1$StaticPool_Saving_flag)] <- 0
CREDITCARDdataframe1$Staticpool_Work_Out_loan_flag[is.na(CREDITCARDdataframe1$Staticpool_Work_Out_loan_flag)] <- 0
CREDITCARDdataframe1$Staticpool_Vehicles_loan_flag[is.na(CREDITCARDdataframe1$Staticpool_Vehicles_loan_flag)] <- 0
CREDITCARDdataframe1$Staticpool_Unsecured_loan_flag[is.na(CREDITCARDdataframe1$Staticpool_Unsecured_loan_flag)] <- 0
CREDITCARDdataframe1$Staticpool_Secured_loan_flag[is.na(CREDITCARDdataframe1$Staticpool_Secured_loan_flag)] <- 0
CREDITCARDdataframe1$Staticpool_Real_Estate_loan_flag[is.na(CREDITCARDdataframe1$Staticpool_Real_Estate_loan_flag)] <- 0
CREDITCARDdataframe1$Staticpool_Fresh_Start_loan_flag[is.na(CREDITCARDdataframe1$Staticpool_Fresh_Start_loan_flag)] <- 0
CREDITCARDdataframe1$Staticpool_Commercial_loan_flag[is.na(CREDITCARDdataframe1$Staticpool_Commercial_loan_flag)] <- 0

CREDITCARDdataframe1 <- replace(CREDITCARDdataframe1,is.na(CREDITCARDdataframe1),-99999999)

CREDITCARDdataframe1[,c(163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180)][CREDITCARDdataframe1[,c(163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180)]==-99999999] <- 0
CREDITCARDdataframe1[,c(407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467)][CREDITCARDdataframe1[,c(407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,467)]==-99999999] <- 0



CREDITCARDdataframe1$Final_Creditcard_Flag <- as.factor(CREDITCARDdataframe1$Final_Creditcard_Flag)

library(woeBinning)
binning <- woe.binning(CREDITCARDdataframe1,'Final_Creditcard_Flag',CREDITCARDdataframe1)
tabulate.binning <- woe.binning.table(binning)

WOEsumm <-data.matrix(tabulate.binning, rownames.force = NA)
write.csv(WOEsumm,"Summary_bining_allvariable_NoR2_new.csv") 

CREDITCARDdataframe_V1 <- (CREDITCARDdataframe1[,c(1,2,178,174,177,173,261,259,188,201,199,208,254,194,189,248,203,212,209,216,214,204,249,218,223,198,260,258,257,256,255,183,227,180,179,175,219,238,176,253,224,231,229,233,200,234,215,213,211,210,195,207,196,246,244,239,262,252,251,250,247,230,228,226,225,182,181,206,205,202,185,193,245,243,242,241,240,222,221,220,217,237,236,235,232,186,168,167,419,197,431,429,420,418,165,166,442,440,411,430,164,135,162,161,160,159,158,157,156,155,154,153,152,151,150,149,148,147,146,145,144,143,142,141,140,139,138,137,136,134,133,132,432,427,441,163,192,421,428,464,462,423,422,598,597,596,595,594,593,592,591,590,589,588,587,586,585,584,583,582,581,580,579,578,577,576,575,574,573,572,571,570,569,412,912,911,910,909,908,907,906,905,904,903,901,900,899,902,443,453,451,416,439,465,450,913,917,927,926,925,924,923,922,921,920,919,918,916,915,914,417,457,298,297,296,295,294,293,292,291,267,434,433,328,327,326,325,324,323,322,321,313,312,311,310,309,308,307,306,290,289,288,287,286,285,284,305,304,303,302,301,300,299,648,647,646,645,644,643,642,641,640,639,638,637,636,635,634,633,632,631,630,629,628,627,626,625,624,623,622,621,620,619,413,268)]) 


library(randomForest)
set.seed(2017)
RF <- randomForest(Final_Creditcard_Flag ~.,data = CREDITCARDdataframe_V1,ntree=100)
print(RF)
Important_vr <- importance(RF)
write.csv(Important_vr,"Imp_VR100_NoR2_V1.csv")
library(randomForestExplainer)
min_depth_frame <- min_depth_distribution(RF)
plot_min_depth_distribution(min_depth_frame)

importance_frame <- measure_importance(RF)
save(importance_frame, file = "importance_frame.rda")
load("importance_frame.rda")
importance_frame
write.csv(importance_frame,"Importance_frame_NoR2_V1.csv")

#colname.creditcarddatafrmae_v1 <- colnames(CREDITCARDdataframe_V1)
#write.csv(colname.creditcarddatafrmae_v1,"colname.creditcarddatafrmae_v1.csv")

CREDITCARDdataframe_V2<- (CREDITCARDdataframe_V1[,c(1,2,87,88,174,39,99,195,134,36,192,35,34,95,142,143,32,223,73,96,222,211,284,193,5,12,33,139,62,74,30,19,9,212,44,29,6,37,45,46,47,75,76,16,77,90,23,65,51,63,53,3,31,14,18,89,17,64,24,4,71,48,26,27,86,135,15,100,189,28,22,49,138,11,50,56,20,10,8,7,133,21,13,41,54,55,38,119,25,43,105,190,191,42,94,141,98,140,104,177)])
CREDITCARDdataframe_V2$Final_Creditcard_Flag <- as.numeric(as.character(CREDITCARDdataframe_V2$Final_Creditcard_Flag))
require(caTools)
library(caTools)
set.seed(123)   #  set seed to ensure you always have same random numbers generated
sample = sample.split(CREDITCARDdataframe_V2,SplitRatio = 0.60) # splits the data in the ratio mentioned in SplitRatio. After splitting marks these rows as logical TRUE and the the remaining are marked as logical FALSE
train1 =subset(CREDITCARDdataframe_V2,sample ==TRUE) # creates a training dataset named train1 with rows which are marked as TRUE
test1=subset(CREDITCARDdataframe_V2, sample==FALSE)

CREDITCARDdataframe_temp <- (train1[,c("Final_Creditcard_Flag"
                                                     ,"Avg_withdrawal_count_Checkings_Staticpool"
                                                     ,"MOB_Checkings"
                                                     ,"sum_Interest_amount_Total_loan_ACCT"
                                                     ,"INTERESTRATE_Vehicles"
                                                     ,"avg_Deposited_count_savings_Q1"
                                                     ,"avg_withdrawal_amount_savings_Q3")])

CREDITCARDdataframe_temp$Final_Creditcard_Flag <- as.factor(CREDITCARDdataframe_temp$Final_Creditcard_Flag)
library(woeBinning)
binning <- woe.binning(CREDITCARDdataframe_temp,'Final_Creditcard_Flag',CREDITCARDdataframe_temp)
tabulate.binning <- woe.binning.table(binning)




library(woeBinning)

Binning.train <- woe.binning(train1,'Final_Creditcard_Flag',train1)
Training_dataset_woe <- woe.binning.deploy(train1, Binning.train, add.woe.or.dum.var = "woe")
tabulate.binning.Train <- woe.binning.table(Binning.train)
#colnames.Training_dataset_woe <- colnames(Training_dataset_woe)
#write.csv(colnames.Training_dataset_woe,"Training_dataset_woe_colnames.csv")

Training_dataset_woe$Final_Creditcard_Flag<- as.numeric(as.character(Training_dataset_woe$Final_Creditcard_Flag))
library(My.stepwise)

my.variable.list <- c("AVG_Transaction_COUNT_Total_Deposit_ACCT","AVG_Deposited_count_Total_Deposit_ACCT","SUM_Transaction_COUNT_Total_Deposit_ACCT","SUM_Deposited_count_Total_Deposit_ACCT","avg_Deposited_count_Checkings_Q2","Avg_withdrawal_count_Checkings_Q2","Avg_withdrawal_count_Checkings_Q1","avg_Deposited_count_Checkings_Q1","Sum_transaction_count_checkings_Staticpool","AVG_balancechange_Checkings_Staticpool","Avg_withdrawal_count_Checkings_Staticpool","avg_Deposited_count_Checkings_Staticpool","sum_FEECOUNT1_checkings_Q2","Sum_transaction_count_checkings_Q1","Avg_Month_end_balance_Checkings_Q1","SUM_withdrawal_amount_Total_Deposit_ACCT","AVG_withdrawal_amount_Total_Deposit_ACCT","AVG_balancechange_Checkings_Q1","sum_FEECOUNT1_checkings_Q3","sum_Month_end_balance_Checkings_Q1","sum_FEECOUNT1_checkings_Q4","Avg_withdrawal_count_Checkings_Q3","avg_Deposited_count_Checkings_Q3","Sum_transaction_count_checkings_Q2","MOB_Checkings","SUM_Deposited_amount_Total_Deposit_ACCT","avg_Deposited_amount_Checkings_Staticpool","avg_withdrawal_amount_Checkings_Staticpool","Sum_transaction_amount_checkings_Staticpool","Avg_transaction_amount_checkings_Staticpool","Avg_Month_end_balance_Checkings_Staticpool","avg_withdrawal_amount_Checkings_Q2","Sum_transaction_count_checkings_Q3","avg_Deposited_amount_Checkings_Q1","Avg_transaction_amount_checkings_Q1","Sum_transaction_amount_checkings_Q1","avg_withdrawal_amount_Checkings_Q1","Avg_Month_end_balance_Checkings_Q2","AVG_balancechange_Checkings_Q2","sum_Month_end_balance_Checkings_Staticpool","sum_Month_end_balance_Checkings_Q2","AVG_balancechange_Checkings_Q3","Avg_Month_end_balance_Checkings_Q3","sum_Month_end_balance_Checkings_Q3","avg_Deposited_count_Checkings_Q4","Avg_withdrawal_count_Checkings_Q4","Sum_transaction_amount_checkings_Q2","Avg_transaction_amount_checkings_Q2","avg_Deposited_amount_Checkings_Q2","sum_Month_end_balance_Checkings_Q4","Avg_Month_end_balance_Checkings_Q4","AVG_Deposited_amount_Total_Deposit_ACCT","Avg_transaction_amount_checkings_Q3","avg_Deposited_amount_Checkings_Q3","Sum_transaction_amount_checkings_Q3","avg_withdrawal_amount_Checkings_Q3","Sum_transaction_count_checkings_Q4","Diff_Month_end_balance_Checkings_Q1_Q2","Sum_transaction_amount_checkings_Q4","Avg_transaction_amount_checkings_Q4","AVG_balancechange_Checkings_Q4","avg_Deposited_amount_Checkings_Q4","avg_withdrawal_amount_Checkings_Q4","Diff_Month_end_balance_Checkings_Q1_Q4","SUM_Month_end_balance_Total_Deposit_ACCT","AVG_Month_end_balance_Total_Deposit_ACCT","avg_Deposited_count_savings_Q1","avg_Deposited_count_savings_Q3","avg_withdrawal_amount_savings_Q3","AVG_balancechange_savings_Q2","Avg_LASTDIVAMOUNT_Total_Deposit_ACCT","SUM_LASTDIVAMOUNT_Total_Deposit_ACCT","sum_Interest_amount_Total_loan_ACCT","sum_Transaction_amount_Total_loan_ACCT","Sum_transaction_count_savings_Q2","Sum_transaction_count_savings_Q3","Sum_transaction_amount_savings_Q1","avg_withdrawal_amount_savings_Q2","avg_Deposited_amount_savings_Q1","Avg_withdrawal_count_savings_Staticpool","avg_Deposited_count_savings_Staticpool","Sum_transaction_count_savings_Q1","avg_Deposited_amount_savings_Q3","AVG_balancechange_savings_Q1","INTERESTRATE_Vehicles","Avg_transaction_amount_savings_Q2","avg_Deposited_amount_savings_Q2","Diff_Month_end_balance_savings_Q1_Q2","Sum_transaction_amount_savings_Q2","Avg_transaction_amount_savings_Q1","avg_Deposited_count_savings_Q4","Avg_withdrawal_count_savings_Q4","Diff_Month_end_balance_savings_Q1_Q4","avg_withdrawal_amount_savings_Q1","Sum_LASTDIVAMOUNT_savings_Staticpool","Sum_LASTDIVAMOUNT_savings_Q1","avg_Deposited_amount_savings_Q4")

my.variable.list <- c("woe.AVG_Transaction_COUNT_Total_Deposit_ACCT.binned","woe.AVG_Deposited_count_Total_Deposit_ACCT.binned","woe.SUM_Transaction_COUNT_Total_Deposit_ACCT.binned","woe.SUM_Deposited_count_Total_Deposit_ACCT.binned","woe.avg_Deposited_count_Checkings_Q2.binned","woe.Avg_withdrawal_count_Checkings_Q2.binned","woe.Avg_withdrawal_count_Checkings_Q1.binned","woe.avg_Deposited_count_Checkings_Q1.binned","woe.Sum_transaction_count_checkings_Staticpool.binned","woe.AVG_balancechange_Checkings_Staticpool.binned","woe.Avg_withdrawal_count_Checkings_Staticpool.binned","woe.avg_Deposited_count_Checkings_Staticpool.binned","woe.sum_FEECOUNT1_checkings_Q2.binned","woe.Sum_transaction_count_checkings_Q1.binned","woe.Avg_Month_end_balance_Checkings_Q1.binned","woe.SUM_withdrawal_amount_Total_Deposit_ACCT.binned","woe.AVG_withdrawal_amount_Total_Deposit_ACCT.binned","woe.AVG_balancechange_Checkings_Q1.binned","woe.sum_FEECOUNT1_checkings_Q3.binned"
                      ,"woe.sum_Month_end_balance_Checkings_Q1.binned","woe.sum_FEECOUNT1_checkings_Q4.binned","woe.Avg_withdrawal_count_Checkings_Q3.binned","woe.avg_Deposited_count_Checkings_Q3.binned","woe.Sum_transaction_count_checkings_Q2.binned","woe.MOB_Checkings.binned","woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned","woe.avg_Deposited_amount_Checkings_Staticpool.binned","woe.avg_withdrawal_amount_Checkings_Staticpool.binned","woe.Sum_transaction_amount_checkings_Staticpool.binned","woe.Avg_transaction_amount_checkings_Staticpool.binned","woe.Avg_Month_end_balance_Checkings_Staticpool.binned","woe.avg_withdrawal_amount_Checkings_Q2.binned","woe.Sum_transaction_count_checkings_Q3.binned","woe.avg_Deposited_amount_Checkings_Q1.binned","woe.Avg_transaction_amount_checkings_Q1.binned","woe.Sum_transaction_amount_checkings_Q1.binned","woe.avg_withdrawal_amount_Checkings_Q1.binned","woe.Avg_Month_end_balance_Checkings_Q2.binned","woe.AVG_balancechange_Checkings_Q2.binned","woe.sum_Month_end_balance_Checkings_Staticpool.binned","woe.sum_Month_end_balance_Checkings_Q2.binned","woe.AVG_balancechange_Checkings_Q3.binned","woe.Avg_Month_end_balance_Checkings_Q3.binned","woe.sum_Month_end_balance_Checkings_Q3.binned","woe.avg_Deposited_count_Checkings_Q4.binned","woe.Avg_withdrawal_count_Checkings_Q4.binned","woe.Sum_transaction_amount_checkings_Q2.binned","woe.Avg_transaction_amount_checkings_Q2.binned","woe.avg_Deposited_amount_Checkings_Q2.binned","woe.sum_Month_end_balance_Checkings_Q4.binned","woe.Avg_Month_end_balance_Checkings_Q4.binned","woe.AVG_Deposited_amount_Total_Deposit_ACCT.binned","woe.Avg_transaction_amount_checkings_Q3.binned","woe.avg_Deposited_amount_Checkings_Q3.binned","woe.Sum_transaction_amount_checkings_Q3.binned","woe.avg_withdrawal_amount_Checkings_Q3.binned","woe.Sum_transaction_count_checkings_Q4.binned","woe.Diff_Month_end_balance_Checkings_Q1_Q2.binned","woe.Sum_transaction_amount_checkings_Q4.binned","woe.Avg_transaction_amount_checkings_Q4.binned","woe.AVG_balancechange_Checkings_Q4.binned","woe.avg_Deposited_amount_Checkings_Q4.binned","woe.avg_withdrawal_amount_Checkings_Q4.binned","woe.Diff_Month_end_balance_Checkings_Q1_Q4.binned","woe.SUM_Month_end_balance_Total_Deposit_ACCT.binned","woe.AVG_Month_end_balance_Total_Deposit_ACCT.binned","woe.avg_Deposited_count_savings_Q1.binned","woe.avg_Deposited_count_savings_Q3.binned","woe.avg_withdrawal_amount_savings_Q3.binned","woe.AVG_balancechange_savings_Q2.binned","woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned","woe.SUM_LASTDIVAMOUNT_Total_Deposit_ACCT.binned","woe.sum_Interest_amount_Total_loan_ACCT.binned","woe.sum_Transaction_amount_Total_loan_ACCT.binned","woe.Sum_transaction_count_savings_Q2.binned","woe.Sum_transaction_count_savings_Q3.binned","woe.Sum_transaction_amount_savings_Q1.binned","woe.avg_withdrawal_amount_savings_Q2.binned","woe.avg_Deposited_amount_savings_Q1.binned","woe.Avg_withdrawal_count_savings_Staticpool.binned","woe.avg_Deposited_count_savings_Staticpool.binned","woe.Sum_transaction_count_savings_Q1.binned","woe.avg_Deposited_amount_savings_Q3.binned","woe.AVG_balancechange_savings_Q1.binned","woe.INTERESTRATE_Vehicles.binned","woe.Avg_transaction_amount_savings_Q2.binned","woe.avg_Deposited_amount_savings_Q2.binned","woe.Diff_Month_end_balance_savings_Q1_Q2.binned","woe.Sum_transaction_amount_savings_Q2.binned","woe.Avg_transaction_amount_savings_Q1.binned","woe.avg_Deposited_count_savings_Q4.binned","woe.Avg_withdrawal_count_savings_Q4.binned","woe.Diff_Month_end_balance_savings_Q1_Q4.binned","woe.avg_withdrawal_amount_savings_Q1.binned","woe.Sum_LASTDIVAMOUNT_savings_Staticpool.binned","woe.Sum_LASTDIVAMOUNT_savings_Q1.binned","woe.avg_Deposited_amount_savings_Q4.binned")

my.variable.list <-  c("woe.Avg_withdrawal_count_Checkings_Staticpool.binned"
                       ,"woe.MOB_Checkings.binned"
                       ,"woe.sum_Interest_amount_Total_loan_ACCT.binned"
                       ,"woe.INTERESTRATE_Vehicles.binned"
                       ,"woe.avg_withdrawal_amount_savings_Q3.binned"
                       ,"woe.avg_Deposited_count_savings_Q1.binned")

My.stepwise.glm.results <- My.stepwise.glm(Y ="Final_Creditcard_Flag", my.variable.list, data = Training_dataset_woe, sle = 0.10 , sls = 0.10, myfamily="binomial",myoffset = "NULL") 

print(Mystepwiseglm_6)
#GLM_Model <- glm(Final_Creditcard_Flag~ woe.SUM_LASTDIVAMOUNT_Total_Deposit_ACCT.binned + woe.Diff_Month_end_balance_Certificates_Q1_Q4.binned + woe.Sum_transaction_amount_Certificates_Q3.binned + woe.avg_withdrawal_amount_Certificates_Q4.binned + woe.Sum_LASTDIVAMOUNT_Certificates_Q2.binned + woe.sum_FEECOUNT1_Certificates_Q4.binned + woe.sum_FEECOUNT1_Certificates_Q3.binned + woe.Count_Total_Deposit_ACCT.binned + woe.Sum_transaction_amount_Certificates_Q2.binned + woe.Avg_Month_end_balance_Certificates_Staticpool.binned + woe.sum_FEECOUNT1_Certificates_Q2.binned + woe.SUM_Month_end_balance_Total_Deposit_ACCT.binned + woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned + woe.MOB_Certificates.binned + woe.avg_withdrawal_amount_Certificates_Q1.binned + woe.avg_Deposited_amount_Certificates_Q2.binned + woe.avg_Deposited_amount_Certificates_Q3.binned + woe.Avg_Month_end_balance_Certificates_Q4.binned + woe.Sum_transaction_count_Certificates_Q4.binned ,data = Training_dataset_woe)

#GLM_Model <- glm(Final_Creditcard_Flag~ woe.avg_withdrawal_amount_Certificates_Q1.binned + woe.SUM_Deposited_amount_Total_Deposit_ACCT.binned + woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned + woe.Diff_Month_end_balance_Certificates_Q1_Q2.binned + woe.Avg_LASTDIVAMOUNT_Total_Deposit_ACCT.binned,data = Training_dataset_woe)

GLM_Model <- glm(Final_Creditcard_Flag~ woe.Avg_withdrawal_count_Checkings_Staticpool.binned + woe.MOB_Checkings.binned + woe.sum_Interest_amount_Total_loan_ACCT.binned + woe.INTERESTRATE_Vehicles.binned + woe.avg_withdrawal_amount_savings_Q3.binned + woe.avg_Deposited_count_savings_Q1.binned ,data = Training_dataset_woe)

summary(GLM_Model)

library(car)
Anova(GLM_Model, type="II", test="Wald")
vif(GLM_Model)
alias.result <- alias(GLM_Model)



#write.csv(Training_dataset_woe,"Training_dataset_woe.csv")
fitted.results <- predict(GLM_Model,Training_dataset_woe,type='response')
score_train <- data.frame(Training_dataset_woe,fitted.results)
write.csv(score_train,"score_train_CC_new_6.csv")

library(gplots)
library(ROCR)
library(pROC)
pdata3 <- as.numeric(format(round(predict(GLM_Model,data = Training_dataset_woe,type='response',na.action = na.pass))))

fitpreds = predict(GLM_Model,Training_dataset_woe,type="response")
fitpred = prediction(fitpreds,Training_dataset_woe$Final_Creditcard_Flag)
fitperf = performance(fitpred,"tpr","fpr")
plot(fitperf,col="green",lwd=2,main="ROC Curve for Logistic:  Adult")
abline(a=0,b=1,lwd=2,lty=2,col="gray")
library(AUC)
auc(fitpreds,(Training_dataset_woe$Final_Creditcard_Flag))

predictions <- as.numeric(predict(GLM_Model, Training_dataset_woe, type = 'response'))
multiclass.roc(Training_dataset_woe$Final_Creditcard_Flag, predictions)



#Test

library(woeBinning)
Binning.test <- woe.binning(test1,'Final_Creditcard_Flag',test1)
Test_dataset_woe <- woe.binning.deploy(test1, Binning.test, add.woe.or.dum.var = "woe")

fitted.test.results <- predict(GLM_Model,Test_dataset_woe,type='response')
score_test <- data.frame(Test_dataset_woe[,c("Final_Creditcard_Flag"
                                             ,"woe.Avg_withdrawal_count_Checkings_Staticpool.binned"
                                             ,"woe.MOB_Checkings.binned"
                                             ,"woe.sum_Interest_amount_Total_loan_ACCT.binned"
                                             ,"woe.INTERESTRATE_Vehicles.binned"
                                             ,"woe.avg_Deposited_count_savings_Q1.binned"
                                             ,"woe.avg_withdrawal_amount_savings_Q3.binned")],fitted.test.results)
write.csv(score_test,"score_test_CC_6.csv")

library(gplots)
library(ROCR)
library(pROC)
pdata3 <- as.numeric(format(round(predict(GLM_Model,data = Test_dataset_woe,type='response',na.action = na.pass))))

fitpreds = predict(GLM_Model,Test_dataset_woe,type="response")
fitpred = prediction(fitpreds,Test_dataset_woe$Final_Creditcard_Flag)
fitperf = performance(fitpred,"tpr","fpr")
plot(fitperf,col="green",lwd=2,main="ROC Curve for Logistic:  Adult")
abline(a=0,b=1,lwd=2,lty=2,col="gray")
library(AUC)
auc(fitpreds,(Test_dataset_woe$Final_Creditcard_Flag))

predictions <- as.numeric(predict(GLM_Model, Test_dataset_woe, type = 'response'))
multiclass.roc(Test_dataset_woe$Final_Creditcard_Flag, predictions)








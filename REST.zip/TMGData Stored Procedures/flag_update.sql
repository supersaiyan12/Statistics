USE [TMGData]
GO

/****** Object:  StoredProcedure [dbo].[flag_update]    Script Date: 12/28/2021 8:36:49 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE Procedure [dbo].[flag_update]
As

SELECT
 Durable_Key 
,[fullExtractdate] 
, isnull([spend],0.00)  as spend
,isnull([RevolvingBalance],0.00) as revolvingBalance   
,xx.*
into ##Temp_Tripflag1
FROM  Cardholder a
                cross apply
            (SELECT sum(isnull([spend],0.00)) as sumspend  ,sum(isnull([RevolvingBalance],0.00)) as sum_revolving_balance 
             from [dbo].Cardholder
         where Durable_Key=a.Durable_Key and Active_Flag=1
           and [fullExtractdate] BETWEEN  dateadd(mm,-5, a.[fullExtractdate])  and a.[fullExtractdate]) xx 
/*Change to current month*/
where 
Active_Flag=1 

 

update Cardholder set Sixmonthspend =bb.sumspend, SIXmonthRevolvingBalance =isnull(bb.sum_revolving_balance,0)
from 
   Cardholder aa
     join
   ##Temp_Tripflag1 bb
        on aa.Durable_Key = bb.Durable_Key
                   and aa.[fullExtractdate] = bb.[fullExtractdate]
/*change to current month*/
where  Active_Flag=1 


 
update Cardholder set TRIPFLAG = CASE 
	WHEN Sixmonthspend <= 0 AND SIXmonthRevolvingBalance <= 0 THEN 'I'
                    WHEN Sixmonthspend <= 0 AND SIXmonthRevolvingBalance > 0 THEN 'P'
                    WHEN Sixmonthspend > 0 AND SIXmonthRevolvingBalance <= 0 THEN 'T'
                    WHEN Sixmonthspend > 0 AND SIXmonthRevolvingBalance >0 THEN 'R'
                    end
from   Cardholder aa  
where  aa.Active_Flag=1 



drop table ##Temp_Tripflag1 


----Closed Flag--


update Cardholder
set Closed_account_flag = null;



update Cardholder
set Closed_account_flag = bb.closed_flag
from Cardholder aa
join
(select *, 
case 
	when (Extract_DatePart<b.min_date or b.min_date is null) then '0' 
	when Extract_DatePart=b.min_date then '1' else 'NA' 
	end closed_flag 
from Cardholder  A 
join 
	(select Durable_Key as DK, min(case when flag=1 then Extract_DatePart else null end) min_date 
	from 
		(
		select Durable_Key,[Master Account Key],[External Status Code],Extract_DatePart,
		case when [External Status Code]='C' then 1 else 0 end flag
		from Cardholder with (nolock) where Active_Flag='1') aa  
	group  by Durable_Key) B
on
A.Durable_Key=B.DK where Active_Flag='1') bb
on
aa.Durable_Key=bb.Durable_Key and aa.Extract_DatePart=bb.Extract_DatePart
where aa.Active_Flag='1' 

GO



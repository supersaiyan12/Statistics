USE [TMGData]
GO

/****** Object:  StoredProcedure [dbo].[Statements_Update]    Script Date: 12/28/2021 8:37:42 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[Statements_Update]
AS

UPDATE Statements_Staging

SET [MSR FLAP INT DELAY DATE]=

(case when [MSR FLAP INT DELAY DATE] = '0' then '1900-01-01'
	  when right([MSR FLAP INT DELAY DATE],2) = '99' then convert(date,replace([MSR FLAP INT DELAY DATE],right([MSR FLAP INT DELAY DATE],2),'01'))
	  else convert(date,[MSR FLAP INT DELAY DATE]) end  )



UPDATE Statements_Staging
SET
[Active Flag]=(case when [Active Flag] = 'TRUE' then 1 else 0 end)



UPDATE Statements_Staging
SET [MSR FLAP PRMT DUE DT]=
(case when [MSR FLAP PRMT DUE DT] = '0' then '1900-01-01'
else convert(date,[MSR FLAP PRMT DUE DT]) end)

GO



USE [TMGData]
GO

/****** Object:  StoredProcedure [dbo].[Cardholder_Update]    Script Date: 12/28/2021 8:35:40 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[Cardholder_Update]
AS

update cardholder_staging
		set 
		[External Status Code Last Change Date]=case when len([External Status Code Last Change Date])=8 
		then datefromparts(left([External Status Code Last Change Date],4),right(left([External Status Code Last Change Date],6),2),right([External Status Code Last Change Date],2)) 
		else '1900-01-01' end
		,[Account System Entry Date]=case when len([Account System Entry Date])=8 
		then datefromparts(left([Account System Entry Date],4),right(left([Account System Entry Date],6),2),right([Account System Entry Date],2)) 
		else '1900-01-01' end
 ,[Card Account Charge-Off Date]=case when len([Card Account Charge-Off Date])=8 
		then datefromparts(left([Card Account Charge-Off Date],4),right(left([Card Account Charge-Off Date],6),2),right([Card Account Charge-Off Date],2)) 
		else '1900-01-01' end
  
  ,[Date Last Monetary Tran]= case when len([Date Last Monetary Tran])=6 then datefromparts(concat(20,left([Date Last Monetary Tran],2)),right(left([Date Last Monetary Tran],4),2),right([Date Last Monetary Tran],2))
		when len([Date Last Monetary Tran])=5 then datefromparts(concat(200,left([Date Last Monetary Tran],1)),left(right([Date Last Monetary Tran],4),2),right([Date Last Monetary Tran],2))
		when len([Date Last Monetary Tran])=4 then datefromparts(2000,left([Date Last Monetary Tran],2),right([Date Last Monetary Tran],2))
		when len([Date Last Monetary Tran])=3 then datefromparts(2000,left([Date Last Monetary Tran],1),right([Date Last Monetary Tran],2))
		else '1900-01-01' end
 ,[Last Statement Date]= case when len([Last Statement Date])=6 then datefromparts(concat(20,left([Last Statement Date],2)),right(left([Last Statement Date],4),2),right([Last Statement Date],2))
		when len([Last Statement Date])=5 then datefromparts(concat(200,left([Last Statement Date],1)),left(right([Last Statement Date],4),2),right([Last Statement Date],2))
		when len([Last Statement Date])=4 then datefromparts(2000,left([Last Statement Date],2),right([Last Statement Date],2))
		when len([Last Statement Date])=3 then datefromparts(2000,left([Last Statement Date],1),right([Last Statement Date],2))
		else '1900-01-01' end



UPDATE cardholder_staging
SET
[Active_flag]=(case when [Active_Flag] = 'TRUE' then 1 else 0 end)



UPDATE cardholder_staging
SET [External Status Code Last Change Date]=
(case when [External Status Code Last Change Date] = '0' then '1900-01-01'
else convert(date,[External Status Code Last Change Date]) end)



UPDATE cardholder_staging
SET [Card Account Charge-Off Date]=
(case when [Card Account Charge-Off Date] = '0' then '1900-01-01'
else convert(date,[Card Account Charge-Off Date]) end)



UPDATE cardholder_staging
SET [Account System Entry Date]=
convert(date,[Account System Entry Date])


UPDATE cardholder_staging
SET [Date First Active New]=
(case when len([date first active]) = 1 then '1900-01-01'
		 when len([date first active]) = 3 then convert(date,CONCAT('20000',[date first active]))
		 when len([date first active]) = 4 then convert(date,CONCAT('2000',[date first active]))
		 when len([date first active]) = 5 then convert(date,CONCAT('200',[date first active]))
		 else convert(date,[date first active]) end)


update cardholder_staging
set ChargeOff_Extract_DatePart = b.Extract_Datepart
from cardholder_staging a
left join (select *
		,case when extract_datepart=[Card Account Charge-Off Date] then 1 else 0 end Flag
		from	
				(select Durable_Key,[Master Account Key],Active_Flag
				,extract_datepart
				,case when len(month([Card Account Charge-Off Date]))=1 then concat(year([Card Account Charge-Off Date]),0,month([Card Account Charge-Off Date]))
				else concat(year([Card Account Charge-Off Date]),month([Card Account Charge-Off Date])) end [Card Account Charge-Off Date],cast([Charge-Off Amount] as money) [Charge-Off Amount]
				 from ChargeOff) a
				 ) b 
on a.Durable_Key = b.Durable_Key and a.[Master Account Key]=b.[Master Account Key]
and a.Active_Flag=b.Active_Flag
and a.extract_datepart=b.Extract_Datepart
where Flag=1



			
update cardholder_staging  set [ChargeoffAmount_final]=  b.[Charge-Off Amount]
from cardholder_staging a
left join (select *
		,case when extract_datepart=[Card Account Charge-Off Date] then 1 else 0 end Flag
		from
				(select Durable_Key,[Master Account Key],Active_Flag
				,extract_datepart
				,case when len(month([Card Account Charge-Off Date]))=1 then concat(year([Card Account Charge-Off Date]),0,month([Card Account Charge-Off Date]))
				else concat(year([Card Account Charge-Off Date]),month([Card Account Charge-Off Date])) end [Card Account Charge-Off Date],cast([Charge-Off Amount] as money) [Charge-Off Amount]
				 from ChargeOff) A
		) b 
on a.Durable_Key = b.Durable_Key and a.[Master Account Key]=b.[Master Account Key]
and a.Active_Flag=b.Active_Flag
and a.extract_datepart=b.Extract_Datepart
where Flag=1



update cardholder_staging
set [ChargeoffAmount_final] = ISNULL([ChargeoffAmount_final],0)




update cardholder_staging
set Extract_ACCOUNT_OPEN_DATE = 
left([Account System Entry Date],4)+right(left([Account System Entry Date],7),2)




update cardholder_staging 
set [NewAccountFLag] = case when  Extract_ACCOUNT_OPEN_DATE = [Extract_DatePart] then 1 else 0 end




update cardholder_staging 
set [Status Reason Code] =  B.[Charge Off Reason],
	[Status Reason Code Description] = case when  [Charge Off Reason] = '89' then 'Charged off Due to bankruptcy'
	 when  [Charge Off Reason] = '68' then 'Charged off;Paid Less than Full Balance'
	 when  [Charge Off Reason] = '88' then 'Charged off Due to Fraud'
	 else null end
	from cardholder_staging A
	join
	(
	select *
		,case when extract_datepart=[Card Account Charge-Off Date] then 1 else 0 end Flag
		from	
				(select Durable_Key,[Master Account Key],Active_Flag
				,extract_datepart,[Charge Off Reason]
				,case when len(month([Card Account Charge-Off Date]))=1 then concat(year([Card Account Charge-Off Date]),0,month([Card Account Charge-Off Date]))
				else concat(year([Card Account Charge-Off Date]),month([Card Account Charge-Off Date])) end [Card Account Charge-Off Date],cast([Charge-Off Amount] as money) [Charge-Off Amount]
				 from ChargeOff) a
				 ) B 
on
A.Durable_Key=B.Durable_Key and a.extract_datepart = b.extract_datepart
where Flag=1




update cardholder_staging
set [spend] = isnull(convert(float,[Last Statement Sale Amount]),0)-isnull(convert(float,[Last Statement Return Amount]),0)
			--where Active_Flag=1





select [Active Flag],[Durable Key],[Extract_DatePart],
sum(case when [MSR FLAP blnc type CD] = 'B' then convert(float,[MSR FLAP NORM ADB AM]) else 0 END) as [Protected_Balance],
sum(case when [MSR FLAP blnc type CD] = 'I' then convert(float,[MSR FLAP NORM ADB AM]) else 0 END) as [Promo_Balance] ,
sum(case when [MSR FLAP blnc type CD] = 'B' then convert(float,[MSR FLAP CURR INTEREST]) else 0 END) as [Protected_Current_Interest] ,
sum(case when [MSR FLAP blnc type CD] = 'I' then convert(float,[MSR FLAP CURR INTEREST]) else 0 END) as [Promo_Current_Interest]
into #temp1
from Statements 
--where [Active Flag]=1
group by [Active Flag],[Durable Key], Extract_DatePart  



update cardholder_staging
set [Protected_Balance] = isnull(t.[Protected_Balance],0),
[Promo_Balance] = isnull(t.[Promo_Balance],0),
[Protected_Current_Interest] = isnull(t.[Protected_Current_Interest],0),
[Promo_Current_Interest]= isnull(t.[Promo_Current_Interest],0) 
from cardholder_staging c
join #temp1 t 
on c.Durable_Key = t.[Durable Key] 
and c.[Extract_DatePart] = t.[Extract_DatePart] and c.Active_Flag=t.[Active Flag]
--where c.Active_Flag='1' 



update cardholder_staging  set RevolvingBalance = isnull([Protected_Balance],0) + isnull([Promo_Balance],0) +
										isnull([Last Statement Cash Average Daily Balance Amount],0) +
										isnull([Last Statement Merchandise Average Daily Balance Amount],0)
										--where Active_Flag='1'




update cardholder_staging set fullExtractdate =
right([Extract Date],4)+'-'+ right('00'+left([Extract Date],1),2)+'-'+ '01' 



update cardholder_staging
set fullExtractdate = 
right([Extract Date],4)+'-'+ right('00'+left([Extract Date],2),2)+'-'+ '01' 
where [Extract Date] like '10%' or [Extract Date] like '11%' or [Extract Date] like '12%'


-------Trip Flag space



SELECT
 Durable_Key 
,[fullExtractdate] 
, isnull([spend],0.00)  as spend
,isnull([RevolvingBalance],0.00) as revolvingBalance   
,xx.*
into ##Temp_Tripflag1
FROM  cardholder_staging a
                cross apply
            (SELECT sum(isnull([spend],0.00)) as sumspend  ,sum(isnull([RevolvingBalance],0.00)) as sum_revolving_balance 
             from [dbo].cardholder_staging
         where Durable_Key=a.Durable_Key and Active_Flag=1
           and [fullExtractdate] BETWEEN  dateadd(mm,-5, a.[fullExtractdate])  and a.[fullExtractdate]) xx 
/*Change to current month*/
where 
Active_Flag=1 

 

update cardholder_staging set Sixmonthspend =bb.sumspend, SIXmonthRevolvingBalance =isnull(bb.sum_revolving_balance,0)
from 
   cardholder_staging aa
     join
   ##Temp_Tripflag1 bb
        on aa.Durable_Key = bb.Durable_Key
                   and aa.[fullExtractdate] = bb.[fullExtractdate]
/*change to current month*/
where  Active_Flag=1 


 
update cardholder_staging set TRIPFLAG = CASE 
	WHEN Sixmonthspend <= 0 AND SIXmonthRevolvingBalance <= 0 THEN 'I'
                    WHEN Sixmonthspend <= 0 AND SIXmonthRevolvingBalance > 0 THEN 'P'
                    WHEN Sixmonthspend > 0 AND SIXmonthRevolvingBalance <= 0 THEN 'T'
                    WHEN Sixmonthspend > 0 AND SIXmonthRevolvingBalance >0 THEN 'R'
                    end
from   cardholder_staging aa  
where  aa.Active_Flag=1 



drop table ##Temp_Tripflag1 






----------



update cardholder_staging
set Closed_account_flag = null;



update cardholder_staging
set Closed_account_flag = bb.closed_flag
from cardholder_staging aa
join
(select *, 
case 
	when (Extract_DatePart<b.min_date or b.min_date is null) then '0' 
	when Extract_DatePart=b.min_date then '1' else 'NA' 
	end closed_flag 
from cardholder_staging  A 
join 
	(select Durable_Key as DK, min(case when flag=1 then Extract_DatePart else null end) min_date 
	from 
		(
		select Durable_Key,[Master Account Key],[External Status Code],Extract_DatePart,
		case when [External Status Code]='C' then 1 else 0 end flag
		from cardholder_staging with (nolock) where Active_Flag='1') aa  
	group  by Durable_Key) B
on
A.Durable_Key=B.DK where Active_Flag='1') bb
on
aa.Durable_Key=bb.Durable_Key and aa.Extract_DatePart=bb.Extract_DatePart
where aa.Active_Flag='1' 





update cardholder_staging
set Mob = datediff(mm,convert(date,[Account System Entry Date]),convert(date,fullExtractdate))



update cardholder_staging 
set ChargeoffAmount_final= ISNULL(ChargeoffAmount_final,0),
[spend]=ISNULL([spend],0),
[Protected_Balance]=isnull([Protected_Balance],0),
[Promo_Balance]=isnull([Promo_Balance],0),
[Protected_Current_Interest]=isnull([Protected_Current_Interest],0),
[Promo_Current_Interest]=isnull([Promo_Current_Interest],0),
RevolvingBalance=ISNULL(RevolvingBalance,0),
[Last Statement Cash Average Daily Balance Amount]= ISNULL([Last Statement Cash Average Daily Balance Amount],0),
[Last Statement Merchandise Average Daily Balance Amount]= isnull([Last Statement Merchandise Average Daily Balance Amount],0)




update cardholder_staging
set [CHARGEOFF_FLAG]  = case when [ChargeoffAmount_final]>0 then 1 else 0 end 
GO



m_data = read.csv('Mortgage_testData.csv',header=TRUE)
test = read.csv('test.csv',header=TRUE)
head(m_data)
dim(m_data)
m_data
install.packages("spline")
install.packages("lubridate")
install.packages('tseries')
library(tseries)
library(lubridate)

m_data$FullDate <- lubridate::mdy(m_data$FullDate)
m_data <- m_data[order(m_data$FullDate),]  
str(m_data)

test$FullDate <- lubridate::mdy(test$FullDate)
test <- test[order(test$FullDate),]  
ts_data = ts(m_data$TrueBalance,start =c(2019,01) ,frequency = 12)
# ts_test = ts(test$TrueBalance,start =c(2019,01) ,frequency = 12)
str(test)


m_data$TrueBalance=as.integer(m_data$TrueBalance)
plot(m_data$FullDate,m_data$TrueBalance)
?plot

# SPLINES MODEL :

library(splines)
head(m_data)
str(m_data)

a2 = smooth.spline(m_data$FullDate,m_data$TrueBalance,df=2)
plot(m_data$FullDate,m_data$TrueBalance)
# lines(a2,col = 2)
lines(a5,col = 'blue')
lines(a6,col = 'green')
a7 = smooth.spline(m_data$FullDate,m_data$TrueBalance,df=7)
lines(a7,col = 'black')
lines(a8,col = 'red')

predict(a7,newdata= as.data.frame(test[,1]))
# plot(test$FullDate,test$TrueBalance)
# lines(y,col='green')
a5 = smooth.spline(m_data$FullDate,m_data$TrueBalance,df=5)
plot(m_data$FullDate,m_data$TrueBalance)
lines(a5,col = 5)
title(main = "Model with DF 5")

a6 = smooth.spline(m_data$FullDate,m_data$TrueBalance,df=6)
plot(m_data$FullDate,m_data$TrueBalance)
lines(a6,col = 6)
title(main = "Model with DF 6")

a7 = smooth.spline(m_data$FullDate,m_data$TrueBalance,df=7)
plot(m_data$FullDate,m_data$TrueBalance)
lines(a7,col = 'black')
title(main = "Model with DF 7")

# Perfectly Fitted
a8 = smooth.spline(m_data$FullDate,m_data$TrueBalance,df=8)
plot(m_data$FullDate,m_data$TrueBalance)
lines(a8,col = 8)
title(main = "Model with DF 8")
par(mfrow=c(2,2))

w= as.numeric(test[,1])
w
y7 = predict(a7,w)

unlist(y7)
test[,2]

plot(test$FullDate,test$TrueBalance)
lines( predict(a7,w), col = "red")

# Piecewise Linear Regression 
attach(m_data)
dummy = rep(0,length(m_data$FullDate))
plot(m_data$FullDate,m_data$TrueBalance)
dummy[m_data$FullDate >'2021-07-31'] = 1
m_data$DN = dummy
m_data
m_data$DateDif = as.numeric(m_data$FullDate)-as.numeric(m_data[31,1])
?
  p_lin = lm(TrueBalance)

# Holt Winter Exponential Smoothing

ts_data
install.packages("forecast")
library(forecast)

hw_m = HoltWinters(ts_data,seasonal = "multiplicative")
hw_m
plot(hw_m)

y_pred = predict(hw_m,n.ahead = 6,prediction.interval = T,level = 0.95)
plot(hw_m,y_pred)

ts_test = ts(test$TrueBalance,start =c(2022,04) ,frequency = 12)
y_pred

accuracy(y_pred,ts_test)
install.packages('caret')
library(caret)

## Another method

ts_data_2 = window(ts_data,start = c(2021,01))
hw_mt = HoltWinters(ts_data_2,seasonal = "multiplicative",gamma = FALSE)
hw_mt
plot(hw_mt)

y_pred_t = predict(hw_mt,n.ahead = 6,level = 0.95)
plot(hw_mt,y_pred_t)

accuracy(y_pred_t,ts_test)

# Applying Seasonal ADjustment 

decompose = decompose(ts_data)
plot(decompose)
deseason = seasadj(decompose)
plot(deseason)

hw_ds = HoltWinters(deseason,seasonal = "multiplicative")
hw_ds
plot(hw_ds)

y_pred = predict(hw_ds,n.ahead = 6,prediction.interval = T,level = 0.95)
plot(hw_ds,y_pred)

ts_test = ts(test$TrueBalance,start =c(2022,04) ,frequency = 12)
y_pred

accuracy(y_pred,ts_test)

auto.arima(deseason,ic='aic',trace = TRUE)
model1 = Arima(deseason,order = c(0,2,0),method ='ML')
arima_pred = forecast(model1,level = c(95),h=1*12)
ts_test
arima_pred
accuracy(arima_pred,ts_test)

m_data = read.csv('Mortgage_testData.csv',header=TRUE)
test = read.csv('test.csv',header=TRUE)
head(m_data)
dim(m_data)
m_data
install.packages("spline")
install.packages("lubridate")

library(lubridate)
m_data$FullDate <- lubridate::mdy(m_data$FullDate)
m_data <- m_data[order(m_data$FullDate),]  
str(m_data)

test$FullDate <- lubridate::mdy(test$FullDate)
test <- test[order(test$FullDate),]  
ts_data = ts(m_data$TrueBalance,start =c(2019,01) ,frequency = 12)
# ts_test = ts(test$TrueBalance,start =c(2019,01) ,frequency = 12)
str(test)


m_data$TrueBalance=as.integer(m_data$TrueBalance)
plot(m_data$FullDate,m_data$TrueBalance)
?plot

library(splines)
head(m_data)
str(m_data)

a2 = smooth.spline(m_data$FullDate,m_data$TrueBalance,df=2)
plot(m_data$FullDate,m_data$TrueBalance)
# lines(a2,col = 2)
lines(a5,col = 'blue')
lines(a6,col = 'green')
a7 = smooth.spline(m_data$FullDate,m_data$TrueBalance,df=7)
lines(a7,col = 'black')
lines(a8,col = 'red')

# predict(a7,x= ts_data)
# plot(test$FullDate,test$TrueBalance)
# lines(y,col='green')
a5 = smooth.spline(m_data$FullDate,m_data$TrueBalance,df=5)
plot(m_data$FullDate,m_data$TrueBalance)
lines(a5,col = 5)
title(main = "Model with DF 5")

a6 = smooth.spline(m_data$FullDate,m_data$TrueBalance,df=6)
plot(m_data$FullDate,m_data$TrueBalance)
lines(a6,col = 6)
title(main = "Model with DF 6")

a7 = smooth.spline(m_data$FullDate,m_data$TrueBalance,df=7)
plot(m_data$FullDate,m_data$TrueBalance)
lines(a7,col = 'black')

# Perfectly Fitted
a8 = smooth.spline(m_data$FullDate,m_data$TrueBalance,df=8)
plot(m_data$FullDate,m_data$TrueBalance)
lines(a8,col = 8)



# Setting up Directory and Loading Libraries
getwd()
library(RODBC)
#install.packages('clock')
library(clock)
library(timeDate)
library(lubridate)
#install.packages('forecast')
library(forecast)
library(tseries)
library(zoo)
# install.packages('dplyr')
library(dplyr)


# Connecting to Dev DB
databaseConnection <- RODBC::odbcDriverConnect('driver={SQL Server};server=ACARCU01;database=Analytics;trusted_connection=true')


# importing data query
Indirect_data <- RODBC::sqlQuery(databaseConnection, "select  *  from Analytics.dbo.Timeseriesindirect")
head(Indirect_data)
str(Indirect_data)


#Date formatting & Sorting
Indirect_data$FullDate <- lubridate::ymd(Indirect_data$FullDate)
Indirect_data <- Indirect_data[order(Indirect_data$FullDate),]  
str(Indirect_data)


#Date starting point
startdate <- Indirect_data$FullDate[1]
startdate

# starting year & month defined
yearstart <- as.numeric(substr(startdate,1,4))
monthstart <- as.numeric(substr(startdate,6,7))

myts <- lag(Indirect_data$TrueBalance,k=1)

Indirect_data
myts


#Converting dataset to Time series dataset
myts <- ts(Indirect_data$TrueBalance,start =c(yearstart,monthstart) ,frequency = 12)
plot(myts)


# checking ACF & PACF graph to decide AR & MA position
acf(myts)
pacf(myts)

#check whether data is stationary or not
adf.test(myts)


#applying Auto Arima model
myts_model = auto.arima(myts,ic = "aic",trace = TRUE)

# Applying Manual Input to arima model
myts_model = arima(myts,order = c(1,2,0))


#Forecasting for next 12 month
Indirect_forecast = forecast(myts_model,level = c(95),h = 1*12)

AAA <- Indirect_forecast$lower

#forecasted value
IndirectDF <- data.frame(FORECAST = Indirect_forecast$mean)

#Generating dates for output
library(timeDate)
a <- max(Indirect_data$FullDate)
aa = timeLastDayInMonth(a)


#Loop to incorporating required end date till 12 Month
test = NULL
for (i in 1:12){
  aaa<- ymd(as.Date(aa)) %m+% months(i)
  test = rbind(test,aaa)
  
}


#convert to date format
dates <- as.Date(test)

#print dates format
print(dates)

#Combined Result & Date tables
Indirectdates <- as.character(dates)

#concatenating columns
Indirectfinal <- cbind(Indirectdates,IndirectDF,'Indirect')

print(Indirectfinal)

colnames(Indirectfinal) <- c('Date','Forecasted_Value','Category')


#Final Data set to export to SQL back (Timestamp with result)
sqlQuery(databaseConnection, 'drop table if exists  ARIMA_OUTPUTS1')
sqlSave(databaseConnection,Indirectfinal,tablename = "ARIMA_OUTPUTS1")


















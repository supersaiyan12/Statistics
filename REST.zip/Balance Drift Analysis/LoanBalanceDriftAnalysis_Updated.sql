--declare @date as date = (select EOMONTH(DATEADD(MM,-1,(MAX(DATEFROMPARTS(LEFT(processdate,4),LEFT(RIGHT(processdate,4),2),RIGHT(processdate,2)))))) from ARCUSYM000..NAME)
DECLARE @date as date = '2024-01-31'
---********** FETCHING ACTIVE ACCOUNTS AS OF MONTH END DATES **********-----



--DROP TABLE IF EXISTS #DATES
--SELECT DISTINCT EOMONTH(DATEFROMPARTS(LEFT(processdate,4),LEFT(RIGHT(processdate,4),2),RIGHT(processdate,2))) AS EXTRACT_DATE
--INTO #DATES
--FROM ARCUSYM000..NAME
--	WHERE EOMONTH(DATEFROMPARTS(LEFT(ProcessDate,4),LEFT(RIGHT(ProcessDate,4),2),RIGHT(ProcessDate,2)))
							--BETWEEN EOMONTH(DATEADD(MM,-37,GETDATE())) AND GETDATE()

--REMOVE SAVINGS 
DROP TABLE IF EXISTS #ACTIVE_ACCOUNTS
SELECT SSN
	,n.PARENTACCOUNT
	,a.ACCOUNTNUMBER
	,a.OPENDATE
	,ROW_NUMBER() over (partition by SSN order by a.opendate) as opendate_rownum
	,DATEDIFF(MM, A.OPENDATE, @date) AS MOB
	, DATEFROMPARTS(LEFT(N.ProcessDate,4),LEFT(RIGHT(N.ProcessDate,4),2),RIGHT(N.ProcessDate,2)) processdate
	,A.ESTMTENABLE AS ESTMTENABLE
	,S.PARENTACCOUNT AS SHARE_ACCOUNT_NUMBER
	,S.ID AS SHARE_ID
	,S.DESCRIPTION AS SHARE_DESCRIPTION
	,S.BALANCE AS SHARE_BALANCE
	,L.PARENTACCOUNT AS LOAN_ACCOUNT_NUMBER
	,L.ID  AS LOAN_ID
	,L.DESCRIPTION AS LOAN_DESCRIPTION
	,L.BALANCE AS LOAN_BALANCE
INTO #ACTIVE_ACCOUNTS
FROM ARCUSYM000..NAME N
LEFT JOIN ARCUSYM000..ACCOUNT A
	ON N.PARENTACCOUNT = A.ACCOUNTNUMBER
	AND N.ProcessDate = A.ProcessDate
LEFT JOIN ARCUSYM000..LOAN L
	ON N.PARENTACCOUNT = L.PARENTACCOUNT
	AND N.ProcessDate = L.ProcessDate
LEFT JOIN ARCUSYM000..SAVINGS S
	ON N.PARENTACCOUNT = S.PARENTACCOUNT
	AND N.ProcessDate = S.ProcessDate
WHERE DATEFROMPARTS(LEFT(N.ProcessDate,4),LEFT(RIGHT(N.ProcessDate,4),2),RIGHT(N.ProcessDate,2)) = @date
	AND N.TYPE = 0 --FOR PRIME MEMBERS FROM NAME TABLE
	AND A.CLOSEDATE IS NULL
	AND S.CLOSEDATE IS NULL
	AND L.CLOSEDATE IS NULL
	AND A.TYPE = 0 --FOR GENERAL MEMBERSHIP FROM ACCOUNT TABLE
	AND N.SSNType = 0 --FOR INDIVIDUAL SSNTYPE
	AND A.COMMERCIALCODE = 0 --FOR CONSUMER ACCOUNTTYPE
	AND N.DEATHDATE IS NULL
	AND EXPIRATIONDATE IS NULL
	AND L.CHARGEOFFDATE IS NULL --LOAN CHARGE-OFF
	AND S.CHARGEOFFDATE IS NULL --SHARE CHARGE-OFF



	--ANALYSING DFT IN  BALANCES ACCORDING TO  DELINQUENCY  BANDS 
	--ADD FICO AND CREATE BANDS \
	--BALANCE BANDS 


	--DECLARE @date as date = '2024-01-31'

DROP TABLE IF EXISTS #TEMP1
SELECT L.AccountNumber
	,l.LoanID
	,l.LoanOpenDate
	,LoanDelqDays
	,datefromparts(left(l.ProcessDate,4),left(right(l.ProcessDate,4),2),right(l.ProcessDate,2)) [Process Date]
	,case when LoanDelqDays between 1 and    29  and l.loanchargeoffdate is null then'Cycle 1' 
	 when LoanDelqDays between 30 and  59  and l.loanchargeoffdate is null then 'Cycle 2'
	 when LoanDelqDays between 60 and  89  and l.loanchargeoffdate is null then 'Cycle 3'
	 when LoanDelqDays between 90 and  119 and l.loanchargeoffdate is null then 'Cycle 4' 
	 when LoanDelqDays between 120 and 149 and l.loanchargeoffdate is null then 'Cycle 5' 
	 when LoanDelqDays between 150 and 179 and l.loanchargeoffdate is null then 'Cycle 6' 
	 when LoanDelqDays between 180 and 359 and l.loanchargeoffdate is null then 'Cycle 7' 
	 when LoanDelqDays >= 360 and l.loanchargeoffdate is null then 'Cycle8' end as Delcycle 
	,case when l.LoanChargeoffDate is not null then 1 else 0 end loanchargeoff
	,LoanCategory3,
	LoanCategory2
	,A.LOAN_BALANCE
	,l.LoanType
	,alc.LoanTypeDescription
	INto #TEMP1 
FROM #ACTIVE_ACCOUNTS A
LEFT JOIN ARCUSYM000.ARCU.ARCULoanDetailed L
	ON A.ACCOUNTNUMBER = L.AccountNumber
	AND A.LOAN_ID = L.LoanID
LEFT JOIN ARCUSYM000.ARCU.ARCULoanCategory ALC
	ON L.LoanType = ALC.LoanType
WHERE 1=1
	AND CONVERT (DATE,CAST(L.ProcessDate AS varchar),102) = @date



	---Fico Adding 


	
	--DECLARE @date as date = '2024-01-31'

	Drop table if exists #TEMP2
	 Select  distinct aa.*,bb.SSN
	 ,cc.fico,
	 case when cc.fico <660 then '<660'
	  when cc.fico between 660 and 700 then '661-700'
	  when cc.fico between 700 and 760 then '701-760'
	  when cc.fico between 760 and 800 then '761-800' 
	  when cc.fico >800 then '>800' else 'N/A'
	  end as Fico_Bands 
	 into #temp2 
	 from #TEMP1 aa
	 left join 
	 ARCUSYM000.dbo.name bb
	 on aa.AccountNumber=bb.PARENTACCOUNT
	 and CONVERT (DATE,CAST(bb.ProcessDate AS varchar),102) = @date
	and  bb.type=0
	left join (SELECT * FROM OPENQUERY([GSDWSQL01],'SELECT * FROM [BureauData].[dbo].[TransUnionAttributeHistory] where date =''202401''')) cc
	on bb.SSN=cc.ssn 


	 Select count(*) from #temp1
	 Select count(*) from #temp2 where fico is null

	 select [Process Date],LoanCategory2,LoanCategory3,Count(distinct SSN) #Members, Count(distinct concat(AccountNumber,Loanid)) #accounts,Sum(LOAN_BALANCE) Total_LOAN_BALANCE,Fico_Bands,
	 avg(LOAN_BALANCE) avg_LOAN_BALANCE
	  from #temp2
	  group by [Process Date],LoanCategory2,LoanCategory3,Fico_Bands
	  order by 2,3



DECLARE @date1 as date = '2024-01-31'
--declare @date as date = (select EOMONTH(DATEADD(MM,-1,(MAX(DATEFROMPARTS(LEFT(processdate,4),LEFT(RIGHT(processdate,4),2),RIGHT(processdate,2)))))) from ..NAME)
SELECT @date1 AS EXTRACT_DATE
	,LoanCategory3 AS LOAN_CATEGORY
	,AVG(BALANCE) AS LOAN_BALANCE
FROM ARCUSYM000..NAME N 
	LEFT JOIN ARCUSYM000..LOAN L
		ON N.PARENTACCOUNT = L.PARENTACCOUNT
		AND N.ProcessDate = L.ProcessDate
	LEFT JOIN ARCUSYM000.ARCU.ARCULoanCategory C
		ON L.TYPE = C.LoanType
WHERE 1=1
	AND DATEFROMPARTS(LEFT(L.ProcessDate,4),LEFT(RIGHT(L.ProcessDate,4),2),RIGHT(L.ProcessDate,2)) = @date1
	AND L.CLOSEDATE IS NULL
	AND L.CHARGEOFFDATE IS NULL
	AND N.TYPE = 0
	AND N.SSNTYPE = 0
	AND N.DEATHDATE IS NULL
GROUP BY LoanCategory3


	-----cREDIT CARD DELINQUENCY 
--	---Delinquency2 ----

--bALANCES BANDS 
--cL BANDS --


--declare @creditcarddate date
--set @creditcarddate =  (Select max(fullExtractdate) from TMGData.dbo.cardholder) 

-- Drop table if exists #creditcarddelinquency2
--Select  eomonth(cast(fullExtractdate as date)) Date,durable_key,[Social Security Number],
-- case when [Card Account Delinquent Day Account new] between 1 and 29     and CHARGEOFF_FLAG<>1  then 1 else 0  end  cycle1 
-- ,case when [Card Account Delinquent Day Account new] between 30 and 59   and chargeoff_flag<>1  then 1 else 0  end  cycle2
-- ,case when [Card Account Delinquent Day Account new] between 60 and 89   and chargeoff_flag<>1  then 1 else 0  end  cycle3
-- ,case when [Card Account Delinquent Day Account new] between 90 and 119  and chargeoff_flag<>1  then 1 else 0  end  cycle4
-- ,case when [Card Account Delinquent Day Account new] between 120 and 149 and chargeoff_flag<>1  then 1 else 0 end  cycle5
-- ,case when [Card Account Delinquent Day Account new] between 150 and 179 and chargeoff_flag<>1  then 1 else 0 end  cycle6
-- ,case when [Card Account Delinquent Day Account new] between 180 and 359 and chargeoff_flag<>1  then 1 else 0 end  cycle7
-- ,case when [Card Account Delinquent Day Account new] >359 and chargeoff_flag<>1   then 1 else 0 end  cycle8
-- ,case when chargeoff_flag = 1   then 1 else 0 end chargeoff,[Card Description], case when chargeoff_flag=1 then [Charge-off Amount] else [Last Statement Balance Amount] end Balance
-- into #creditcarddelinquency2
--  from
--		  (select * 
--		,case when pre_del>0 then pre_del-lead(date,1) over(partition by Durable_Key order by extract_datepart) else [Card Account Delinquent Day Account] end [Card Account Delinquent Day Account new]
--		,lead(date,1) over(partition by Durable_Key order by extract_datepart) pre_days
--		from 
--		(select *,day(eomonth(cast(fullExtractdate as date))) date
--		,lead([Card Account Delinquent Day Account],1) over(partition by Durable_Key order by extract_datepart) pre_del
--		from TMGData.dbo.cardholder where Active_Flag=1 and [External Status Code] not in ('C')
--		) AB  ) A
--where fullExtractdate between dateadd(month,-35,@creditcarddate) and @creditcarddate
----extract_datepart between case when len(month(@creditcarddate))=1 then concat(year(@creditcarddate),0,month(@creditcarddate))  
----else concat(year(@creditcarddate),0,month(@creditcarddate))  end 
--and active_flag = 1
-- AND [Card Description] not IN ('Mastercard Business')

DROP TABLE IF EXISTS #DATES
SELECT DISTINCT EOMONTH(DATEFROMPARTS(LEFT(processdate,4),LEFT(RIGHT(processdate,4),2),RIGHT(processdate,2))) AS EXTRACT_DATE
INTO #DATES
FROM ARCUSYM000..NAME
	WHERE EOMONTH(DATEFROMPARTS(LEFT(ProcessDate,4),LEFT(RIGHT(ProcessDate,4),2),RIGHT(ProcessDate,2)))
							BETWEEN EOMONTH(DATEADD(MM,-37,GETDATE())) AND GETDATE()

--declare @date as date = (select EOMONTH(DATEADD(MM,-1,(MAX(DATEFROMPARTS(LEFT(processdate,4),LEFT(RIGHT(processdate,4),2),RIGHT(processdate,2)))))) from ..NAME)
DECLARE @date1 DATE
DECLARE curP CURSOR FOR
	SELECT EXTRACT_DATE
	FROM #DATES
	--WHERE EXTRACT_DATE BETWEEN EOMONTH(DATEADD(MM,-37,@date)) AND @date
	ORDER BY 1

OPEN curP
FETCH NEXT FROM curP INTO @date1

WHILE @@FETCH_STATUS = 0
BEGIN

--SELECT '2024-01-31' AS EXTRACT_DATE
--	,'AUTOLOAN' AS LOAN_CATEGORY
--	,123456 AS LOAN_BALANCE
--INTO #AVG_BAL_CUR

--DELETE FROM #AVG_BAL_CUR
--WHERE EXTRACT_DATE = '2024-01-31'

--SELECT * INTO ANALYTICS.dbo.LoanBalanceDrift FROM #AVG_BAL_CUR

INSERT INTO ANALYTICS.dbo.LoanBalanceDrift

	DECLARE @date1 as date = '2024-01-31'
--declare @date as date = (select EOMONTH(DATEADD(MM,-1,(MAX(DATEFROMPARTS(LEFT(processdate,4),LEFT(RIGHT(processdate,4),2),RIGHT(processdate,2)))))) from ..NAME)
SELECT @date1 AS EXTRACT_DATE
	,LoanCategory3 AS LOAN_CATEGORY
	,AVG(BALANCE) AS LOAN_BALANCE
FROM ARCUSYM000..NAME N 
	LEFT JOIN ARCUSYM000..LOAN L
		ON N.PARENTACCOUNT = L.PARENTACCOUNT
		AND N.ProcessDate = L.ProcessDate
	LEFT JOIN ARCUSYM000.ARCU.ARCULoanCategory C
		ON L.TYPE = C.LoanType
WHERE 1=1
	AND DATEFROMPARTS(LEFT(L.ProcessDate,4),LEFT(RIGHT(L.ProcessDate,4),2),RIGHT(L.ProcessDate,2)) = @date1
	AND L.CLOSEDATE IS NULL
	AND L.CHARGEOFFDATE IS NULL
	AND N.TYPE = 0
	AND N.SSNTYPE = 0
	AND N.DEATHDATE IS NULL
GROUP BY LoanCategory3




	



FETCH NEXT FROM curP INTO @date1
END
CLOSE curP
DEALLOCATE curP


select * from ANALYTICS.dbo.LoanBalanceDrift

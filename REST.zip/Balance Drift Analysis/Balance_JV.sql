/*** High Level Balances YoY ***/
declare @date as int
set @date = '20240131'
print @date-10000

drop table if exists #data
--select b.LoanCategory2,convert(date,cast(ProcessDate as varchar),102) ProcessDate,sum(BALANCE) BALANCE
select PARENTACCOUNT,id,bb.LoanCategory2,convert(date,cast(aa.ProcessDate as varchar),102) ProcessDate,sum(BALANCE) BALANCE
into #data
	from ARCUSYM000..loan aa
	left join ARCUSYM000.arcu.ARCULoanCategory bb
	on aa.TYPE = bb.LoanType
	where bb.LoanCategory2 in ( 'Vehicle','Personal','Real Estate')
	and CLOSEDATE is null
	and CHARGEOFFDATE is null
	and aa.ProcessDate in( @date,@date-10000,@date-20000)
	group by PARENTACCOUNT,id,bb.LoanCategory2,aa.ProcessDate


Drop table if exists #TEMP2
	 Select  distinct aa.*,bb.SSN
	 ,cc.fico,
	 case when cc.fico <660 then '<660'
	  when cc.fico between 660 and 700 then '661-700'
	  when cc.fico between 700 and 760 then '701-760'
	  when cc.fico between 760 and 800 then '761-800' 
	  when cc.fico >800 then '>800' else 'N/A'
	  end as Fico_Bands 
	 into #temp2 
	 from #data aa
	 left join 
	 ARCUSYM000.dbo.name bb
	 on aa.PARENTACCOUNT=bb.PARENTACCOUNT
	 and CONVERT (DATE,CAST(bb.ProcessDate AS varchar),102) = '2024-01-31'
	and  bb.type=0
	left join (SELECT * FROM OPENQUERY([GSDWSQL01],'SELECT * FROM [BureauData].[dbo].[TransUnionAttributeHistory] where date =''202401''')) cc
	on bb.SSN=cc.ssn 

	select  LoanCategory2,ProcessDate,sum(BALANCE) 
	from #data
	group by LoanCategory2,ProcessDate
	order by 1,2 desc

	select  Fico_Bands,LoanCategory2,ProcessDate,	sum(BALANCE)  BALANCE
	from #temp2
	group by Fico_Bands,LoanCategory2,ProcessDate
	order by 2,3,1 desc




	--select distinct  bb.LoanCategory2 from  ARCUSYM000.arcu.ARCULoanCategory bb
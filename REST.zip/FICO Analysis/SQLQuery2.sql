select 
	case when [Calc Norm Mrch Annual Rate]=0 then '0'
	when [Calc Norm Mrch Annual Rate]<=10.9 then '<=10.9'
	when [Calc Norm Mrch Annual Rate]=11.9 then '11.9'
	when [Calc Norm Mrch Annual Rate]<=12.75 then '<=12.75'
	when [Calc Norm Mrch Annual Rate]=12.9 then '12.9'
	when [Calc Norm Mrch Annual Rate]<=13.75 then '<=13.75'
	when [Calc Norm Mrch Annual Rate]=13.9 then '13.9'
	when [Calc Norm Mrch Annual Rate]<=14.25 then '<=14.25'
	when [Calc Norm Mrch Annual Rate]=14.9 then '14.9'
	when [Calc Norm Mrch Annual Rate]<=15.25 then '<=15.25'
	when [Calc Norm Mrch Annual Rate]=15.9 then '15.9'
	when [Calc Norm Mrch Annual Rate]<=16.99 then '<=16.99'
	when [Calc Norm Mrch Annual Rate]=17.9 then '17.9'
	when [Calc Norm Mrch Annual Rate]<=18.25 then '<=18.25'
	when [Calc Norm Mrch Annual Rate]=18.9 then '18.9'
	when [Calc Norm Mrch Annual Rate]<=19.99 then '<=19.99'
	when [Calc Norm Mrch Annual Rate]=20.9 then '20.9'
	when [Calc Norm Mrch Annual Rate]>20.9 then '>20.9'
	else 'Others' end as rate_band
,
case 
	when b.FICO = 0 then 'a.= 0'
	when b.FICO <660 then 'b.< 660'
	when b.FICO <680 then 'c.< 680'
	when b.FICO <700 then 'd.< 700'
	when b.FICO <740 then 'e.< 740'
	when b.FICO <780 then 'f.< 780'
	when b.FICO between 780 and 950 then 'g. 780+'
	else 'h.NA' end as FICO_Band,
	count(*) as N_cards,
	sum([Last Statement Balance Amount]) as Balance,
	sum(RevolvingBalance) as Rev_Bal,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as spend,
	sum([Protected_Current_Interest]+[Promo_Current_Interest]
	+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income,

	sum([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]
	+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] 
	  +[Dynamic Interest Fees Charges Statement Year To Date]) as fees,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income,    
	sum([Last Statement Balance Amount])*0.02/12 as COF,
	sum(ChargeoffAmount_final) as chgoff_amt,
	sum(case when [Card Description] in ('MasterCard Platinum Rewards','MasterCard World Credit','MasterCard Merchant Platinum') 
	then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end) as rewards_expense,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense,
	sum(case when TRIPFLAG = 'I' then 0.9 else 2.75 end) as processing_cost
	from [TMGData].[dbo].[cardholder] a
	left join openquery ( [GSDWsql01],'select SSN,FICO from [BureauData].[dbo].[TransUnionAttributeHistory] where date = 202312 ' ) b
	on a.[Social Security Number] = b.SSN
	where Active_Flag = 1 and extract_datepart = 202312
	and [External Status Code] not in('C')
	group by 
	case when [Calc Norm Mrch Annual Rate]=0 then '0'
	when [Calc Norm Mrch Annual Rate]<=10.9 then '<=10.9'
	when [Calc Norm Mrch Annual Rate]=11.9 then '11.9'
	when [Calc Norm Mrch Annual Rate]<=12.75 then '<=12.75'
	when [Calc Norm Mrch Annual Rate]=12.9 then '12.9'
	when [Calc Norm Mrch Annual Rate]<=13.75 then '<=13.75'
	when [Calc Norm Mrch Annual Rate]=13.9 then '13.9'
	when [Calc Norm Mrch Annual Rate]<=14.25 then '<=14.25'
	when [Calc Norm Mrch Annual Rate]=14.9 then '14.9'
	when [Calc Norm Mrch Annual Rate]<=15.25 then '<=15.25'
	when [Calc Norm Mrch Annual Rate]=15.9 then '15.9'
	when [Calc Norm Mrch Annual Rate]<=16.99 then '<=16.99'
	when [Calc Norm Mrch Annual Rate]=17.9 then '17.9'
	when [Calc Norm Mrch Annual Rate]<=18.25 then '<=18.25'
	when [Calc Norm Mrch Annual Rate]=18.9 then '18.9'
	when [Calc Norm Mrch Annual Rate]<=19.99 then '<=19.99'
	when [Calc Norm Mrch Annual Rate]=20.9 then '20.9'
	when [Calc Norm Mrch Annual Rate]>20.9 then '>20.9'
	else 'Others' end,
	case 
	when b.FICO = 0 then 'a.= 0'
	when b.FICO <660 then 'b.< 660'
	when b.FICO <680 then 'c.< 680'
	when b.FICO <700 then 'd.< 700'
	when b.FICO <740 then 'e.< 740'
	when b.FICO <780 then 'f.< 780'
	when b.FICO between 780 and 950 then 'g. 780+'
	else 'h.NA' end
	order by 
	case 
	when b.FICO = 0 then 'a.= 0'
	when b.FICO <660 then 'b.< 660'
	when b.FICO <680 then 'c.< 680'
	when b.FICO <700 then 'd.< 700'
	when b.FICO <740 then 'e.< 740'
	when b.FICO <780 then 'f.< 780'
	when b.FICO between 780 and 950 then 'g. 780+'
	else 'h.NA' end,
	case when [Calc Norm Mrch Annual Rate]=0 then '0'
	when [Calc Norm Mrch Annual Rate]<=10.9 then '<=10.9'
	when [Calc Norm Mrch Annual Rate]=11.9 then '11.9'
	when [Calc Norm Mrch Annual Rate]<=12.75 then '<=12.75'
	when [Calc Norm Mrch Annual Rate]=12.9 then '12.9'
	when [Calc Norm Mrch Annual Rate]<=13.75 then '<=13.75'
	when [Calc Norm Mrch Annual Rate]=13.9 then '13.9'
	when [Calc Norm Mrch Annual Rate]<=14.25 then '<=14.25'
	when [Calc Norm Mrch Annual Rate]=14.9 then '14.9'
	when [Calc Norm Mrch Annual Rate]<=15.25 then '<=15.25'
	when [Calc Norm Mrch Annual Rate]=15.9 then '15.9'
	when [Calc Norm Mrch Annual Rate]<=16.99 then '<=16.99'
	when [Calc Norm Mrch Annual Rate]=17.9 then '17.9'
	when [Calc Norm Mrch Annual Rate]<=18.25 then '<=18.25'
	when [Calc Norm Mrch Annual Rate]=18.9 then '18.9'
	when [Calc Norm Mrch Annual Rate]<=19.99 then '<=19.99'
	when [Calc Norm Mrch Annual Rate]=20.9 then '20.9'
	when [Calc Norm Mrch Annual Rate]>20.9 then '>20.9'
	else 'Others' end

	go

	select 
	[Calc Norm Mrch Annual Rate],
	count(*) as N_cards
	from [TMGData].[dbo].[cardholder]
	where Active_Flag = 1 and extract_datepart = 202312
	and [External Status Code] not in('C')
	group by [Calc Norm Mrch Annual Rate]
	order by [Calc Norm Mrch Annual Rate]


	go

	select 
	case 
	when [Calc Norm Mrch Annual Rate]=0 then '0'
	when [Calc Norm Mrch Annual Rate]<=12.9 then '<=12.9'
	when [Calc Norm Mrch Annual Rate]<=13.9 then '<=13.9'
	when [Calc Norm Mrch Annual Rate]<=14.9 then '<=14.9'
	when [Calc Norm Mrch Annual Rate]<=15.9 then '<=15.9'
	when [Calc Norm Mrch Annual Rate]<=17.9 then '<=17.9'
	when [Calc Norm Mrch Annual Rate]<=18.9 then '<=18.9'
	when [Calc Norm Mrch Annual Rate]<=20.9 then '<=20.9'
	when [Calc Norm Mrch Annual Rate]>20.9 then '>20.9'
	else 'Others' end as rate_band
,
case 
	when b.FICO = 0 then 'a.= 0'
	when b.FICO <660 then 'b.< 660'
	when b.FICO <680 then 'c.< 680'
	when b.FICO <700 then 'd.< 700'
	when b.FICO <740 then 'e.< 740'
	when b.FICO <780 then 'f.< 780'
	when b.FICO between 780 and 950 then 'g. 780+'
	else 'h.NA' end as FICO_Band,
	count(*) as N_cards,
	sum([Last Statement Balance Amount]) as Balance,
	sum(RevolvingBalance) as Rev_Bal,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount]) as spend,
	sum([Protected_Current_Interest]+[Promo_Current_Interest]
	+[Last Statement Cash Interest Amount]+[Accumulated Merchandise Interest Amount]) as Interest_Income,

	sum([Last Statement Credit Life Change Amount]+[Last Statement Charge Cash Amount]
	+[Last Statement Charge Late Amount]+[Last Statement Charge Overlimit Amount]
      +[Last Statement Charge Sale Amount]+[Last Statement External Fee Amount]
	  +[Dynamic Fees Fee Charges Statement Year To Date] +[Miscellaneous Fee Charges Since Last Statement] 
	  +[Dynamic Interest Fees Charges Statement Year To Date]) as fees,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount])*0.018 as interchange_income,    
	sum([Last Statement Balance Amount])*0.02/12 as COF,
	sum(ChargeoffAmount_final) as chgoff_amt,
	sum(case when [Card Description] in ('MasterCard Platinum Rewards','MasterCard World Credit','MasterCard Merchant Platinum') 
	then ([Last Statement Sale Amount]-[Last Statement Return Amount])*0.004 else 0 end) as rewards_expense,
	sum([Last Statement Sale Amount]-[Last Statement Return Amount])*0.00324 as visa_expense,
	sum(case when TRIPFLAG = 'I' then 0.9 else 2.75 end) as processing_cost
	from [TMGData].[dbo].[cardholder] a
	left join openquery ( [GSDWsql01],'select SSN,FICO from [BureauData].[dbo].[TransUnionAttributeHistory] where date = 202312 ' ) b
	on a.[Social Security Number] = b.SSN
	where Active_Flag = 1 and extract_datepart = 202312
	and [External Status Code] not in('C')
	group by 
	case 
	when [Calc Norm Mrch Annual Rate]=0 then '0'
	when [Calc Norm Mrch Annual Rate]<=12.9 then '<=12.9'
	when [Calc Norm Mrch Annual Rate]<=13.9 then '<=13.9'
	when [Calc Norm Mrch Annual Rate]<=14.9 then '<=14.9'
	when [Calc Norm Mrch Annual Rate]<=15.9 then '<=15.9'
	when [Calc Norm Mrch Annual Rate]<=17.9 then '<=17.9'
	when [Calc Norm Mrch Annual Rate]<=18.9 then '<=18.9'
	when [Calc Norm Mrch Annual Rate]<=20.9 then '<=20.9'
	when [Calc Norm Mrch Annual Rate]>20.9 then '>20.9'
	else 'Others' end,
	case 
	when b.FICO = 0 then 'a.= 0'
	when b.FICO <660 then 'b.< 660'
	when b.FICO <680 then 'c.< 680'
	when b.FICO <700 then 'd.< 700'
	when b.FICO <740 then 'e.< 740'
	when b.FICO <780 then 'f.< 780'
	when b.FICO between 780 and 950 then 'g. 780+'
	else 'h.NA' end
	order by 
	case 
	when b.FICO = 0 then 'a.= 0'
	when b.FICO <660 then 'b.< 660'
	when b.FICO <680 then 'c.< 680'
	when b.FICO <700 then 'd.< 700'
	when b.FICO <740 then 'e.< 740'
	when b.FICO <780 then 'f.< 780'
	when b.FICO between 780 and 950 then 'g. 780+'
	else 'h.NA' end,
	case 
	when [Calc Norm Mrch Annual Rate]=0 then '0'
	when [Calc Norm Mrch Annual Rate]<=12.9 then '<=12.9'
	when [Calc Norm Mrch Annual Rate]<=13.9 then '<=13.9'
	when [Calc Norm Mrch Annual Rate]<=14.9 then '<=14.9'
	when [Calc Norm Mrch Annual Rate]<=15.9 then '<=15.9'
	when [Calc Norm Mrch Annual Rate]<=17.9 then '<=17.9'
	when [Calc Norm Mrch Annual Rate]<=18.9 then '<=18.9'
	when [Calc Norm Mrch Annual Rate]<=20.9 then '<=20.9'
	when [Calc Norm Mrch Annual Rate]>20.9 then '>20.9'
	else 'Others' end

	go

	select 
	Durable_Key,[Calc Norm Mrch Annual Rate],[Account System Entry Date],b.FICO,[Card Description]
	from [TMGData].[dbo].[cardholder] a
	left join openquery ( [GSDWsql01],'select SSN,FICO from [BureauData].[dbo].[TransUnionAttributeHistory] where date = 202312 ' ) b
	on a.[Social Security Number] = b.SSN
	where Active_Flag = 1 and extract_datepart = 202312
	and [External Status Code] not in('C')
	and FICO between 1 and 659
	

	go

	select extract_datepart,
	[Calc Norm Mrch Annual Rate]
,
case 
	when b.FICO = 0 then 'a.= 0'
	when b.FICO <660 then 'b.< 660'
	when b.FICO <680 then 'c.< 680'
	when b.FICO <700 then 'd.< 700'
	when b.FICO <740 then 'e.< 740'
	when b.FICO <780 then 'f.< 780'
	when b.FICO between 780 and 950 then 'g. 780+'
	else 'h.NA' end as FICO_Band,
	count(*) as N_cards,
	sum([Last Statement Balance Amount]) as Balance,
	sum(RevolvingBalance) as Rev_Bal,
	balance

	from [TMGData].[dbo].[cardholder] a
	left join openquery ( [GSDWsql01],'select SSN,FICO from [BureauData].[dbo].[TransUnionAttributeHistory] where date = 202312 ' ) b
	on a.[Social Security Number] = b.SSN
	where Active_Flag = 1 and extract_datepart >= 202302
	and [External Status Code] not in('C')
	group by extract_datepart,
	[Calc Norm Mrch Annual Rate],
	case 
	when b.FICO = 0 then 'a.= 0'
	when b.FICO <660 then 'b.< 660'
	when b.FICO <680 then 'c.< 680'
	when b.FICO <700 then 'd.< 700'
	when b.FICO <740 then 'e.< 740'
	when b.FICO <780 then 'f.< 780'
	when b.FICO between 780 and 950 then 'g. 780+'
	else 'h.NA' end
	order by 
	case 
	when b.FICO = 0 then 'a.= 0'
	when b.FICO <660 then 'b.< 660'
	when b.FICO <680 then 'c.< 680'
	when b.FICO <700 then 'd.< 700'
	when b.FICO <740 then 'e.< 740'
	when b.FICO <780 then 'f.< 780'
	when b.FICO between 780 and 950 then 'g. 780+'
	else 'h.NA' end,
	[Calc Norm Mrch Annual Rate]
						       --validate all columns                                         			
						--,0 BookingCosts --application fee
										
declare @staticpooldate date
		declare @staticpooldate2 date
		declare @staticpooldate3 date
		set  @staticpooldate= (select datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Processdate from
	(select max(ProcessDate) processdate from ARCUSYM000..LOAN) A)
set  @staticpooldate2 = (Select case when @staticpooldate = EOMONTH(@staticpooldate) then @staticpooldate else EOmonth(DATEADD(Month,-1,@staticpooldate)) end)
set  @staticpooldate3 = (select dateadd(month,-35,@staticpooldate2))

drop table if exists #processdate
select process_date,max(ProcessDate) max_ProcessDate,max([process date]) [process date]
into #processdate
		from (select ProcessDate,left(ProcessDate,6) process_date ,datefromparts(left(processdate,4),right(left(processdate,6),2),RIGHT(processdate,2)) [process date]
				from ARCUSYM000..loan) A
where [process date]>=@staticpooldate3 and [process date]<=@staticpooldate2
group by process_date

--Loan Static of one month back -- 
	drop table if exists #LoanStatic
	select *
	into #LoanStatic
	from
	(
	select 
		a.[ProcessDate],[Process date],[Process_date],[PARENTACCOUNT],concat(PARENTACCOUNT,ID) UNID,ID
		,LoanCategory4 Loan_Categories
		,case when LoanCategory3='Indirect' then 'Indirect' else 'Direct' END Direct_indirect
		,LoanCategory2 LoanCategory1,LoanCategory3 LoanCategory2,LoanCategory4 LoanCategory3,b.LoanTypeDescription, BALANCE,MOB, Month_to_Maturity, Loan_Term,ORIGINALBALANCE, 
		INTERESTRATE,INTERESTRATE/1000 monthlyinterestrate,Open_date,OPENDATE,
		Close_date, CLOSEDATE,Charge_off_date,CHARGEOFFAMOUNT,CHARGEOFFDATE,BRANCH,
		--nikita made  
		CASE WHEN MONTH(OpenDate) = MONTH([process date]) AND YEAR(OpenDate) = YEAR([process date]) THEN Balance ELSE 0 END NewLoanBalance,
		Open_flag_NewLoan,Close_flag_closedLoan,
	[Process_date]	ExtractDatepart,[Process date] fullextractdate,  FORMAT([Process date] ,'MMM-yyyy') MonthYear,case when LoanCategory3='Indirect' then 'Indirect' else 'Direct' end  membertype,
		CASE WHEN DATEDIFF(MONTH, cast(OpenDate as date), case when cast(CloseDate as date)<cast([Process date] as date) THEN CloseDate else [Process date] end ) BETWEEN 0 AND 12   THEN    '0-12 Months'
					 WHEN DATEDIFF(MONTH, cast(OpenDate as date), case when cast(CloseDate as date)<cast([Process date] as date) THEN CloseDate else  [Process date] end ) BETWEEN 13 AND 24  THEN    '13-24 Months'
					 WHEN DATEDIFF(MONTH, cast(OpenDate as date), case when cast(CloseDate as date)<cast([Process date] as date) THEN CloseDate else [Process date] end ) BETWEEN 25 AND 36  THEN    '25-36 Months'
					 WHEN DATEDIFF(MONTH, cast(OpenDate as date), case when cast(CloseDate as date)<cast([Process date] as date) THEN CloseDate else [Process date] end ) BETWEEN 37 AND 48  THEN    '37-48 Months'
					 WHEN DATEDIFF(MONTH, cast(OpenDate as date), case when cast(CloseDate as date)<cast([Process date] as date) THEN CloseDate else [Process date] end ) BETWEEN 49 AND 60  THEN    '49-60 Months'
					 WHEN DATEDIFF(MONTH, cast(OpenDate as date), case when cast(CloseDate as date)<cast([Process date] as date) THEN CloseDate else [Process date] end ) BETWEEN 61 AND 120 THEN    '61-120 Months'
					 WHEN DATEDIFF(MONTH, cast(OpenDate as date), case when cast(CloseDate as date)<cast([Process date] as date) THEN CloseDate else [Process date] end )  >120              THEN    '>120 Months'
					 ELSE  	'NA'END   AS Tenure,

					 CASE WHEN DATEDIFF(MONTH, cast(OpenDate as date), case when cast(CloseDate as date)<cast([Process date] as date) THEN CloseDate else [Process date] end ) BETWEEN 0 AND 12   THEN    1
					 WHEN DATEDIFF(MONTH, cast(OpenDate as date), case when cast(CloseDate as date)<cast([Process date] as date) THEN CloseDate else  [Process date] end ) BETWEEN 13 AND 24  THEN        2
					 WHEN DATEDIFF(MONTH, cast(OpenDate as date), case when cast(CloseDate as date)<cast([Process date] as date) THEN CloseDate else [Process date] end ) BETWEEN 25 AND 36  THEN         3
					 WHEN DATEDIFF(MONTH, cast(OpenDate as date), case when cast(CloseDate as date)<cast([Process date] as date) THEN CloseDate else [Process date] end ) BETWEEN 37 AND 48  THEN         4
					 WHEN DATEDIFF(MONTH, cast(OpenDate as date), case when cast(CloseDate as date)<cast([Process date] as date) THEN CloseDate else [Process date] end ) BETWEEN 49 AND 60  THEN         5
					 WHEN DATEDIFF(MONTH, cast(OpenDate as date), case when cast(CloseDate as date)<cast([Process date] as date) THEN CloseDate else [Process date] end ) BETWEEN 61 AND 120 THEN         6
					 WHEN DATEDIFF(MONTH, cast(OpenDate as date), case when cast(CloseDate as date)<cast([Process date] as date) THEN CloseDate else [Process date] end )  >120              THEN         7
					 ELSE  	'NA'END   AS TenureSort,

					LoanCategory4  ProductSubtype					 	
		 ---FEECOUNT1, FEECOUNT2, FEECOUNT3,FEECOUNT4,FEENEWBALANCE,LATECHARGEACCRUED,ORIGINALDATE
		from
			(
			select *,CONCAT(PARENTACCOUNT,ID) UNID
			,case when opendate=closedate then 0 else 1 end Flag,
			CASE WHEN MONTH(OpenDate) = MONTH([process date]) AND YEAR(OpenDate) = YEAR([process date]) THEN 1 ELSE 0 END Open_flag_NewLoan,
			CASE WHEN MONTH(CloseDate)= MONTH([process date]) AND  YEAR(CloseDate)=YEAR([process date]) THEN 1 ELSE 0 END Close_flag_closedLoan
			,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date 
			then 1 else 0 end Open_Flag
			,DATEDIFF(month,OPENDATE,[Process date]) MOB	-- add the @Staticpooldate ---replaced staticpool with processdate
			,case when CLOSEDATE is null then DATEDIFF(month,OPENDATE,MATURITYDATE) else 0 end Loan_Term
			,case when CLOSEDATE is null then DATEDIFF(month,@staticpooldate2,MATURITYDATE) else 0 end Month_to_Maturity
				from 
					(select *
					,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
					else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
					,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
					else concat(year(opendate),month(opendate)) end Open_date
					,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
					else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
					,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
					,left(ProcessDate,6) Process_date
					from ARCUSYM000..LOAN
					where ProcessDate in (select max_ProcessDate from #processdate)
					) H
				where  ORIGINALDATE is not null
				 and OpenDate is not null 
				--and CLOSEDATE is null
				-- and CHARGEOFFDATE is null
				and [Process date] between @staticpooldate3 and @staticpooldate2    -- DATEADD(month,-1,@staticpooldate2)		-- Later give the @staticpooldate date here 
				and MATURITYDATE> @staticpooldate2      -- DATEADD(month,-1,@staticpooldate2)	-- add 3 month in currrent date
			) A
				left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
				on b.loantype=a.TYPE
								where Flag=1 and Open_Flag=1 
							         --AND b.loancategory4 not in ('writeoff','Workout/TDR') 
									  and b.LoanCategory1 in ('Consumer') and LoanCategory2='Vehicle'

				) D
				order by PARENTACCOUNT,ProcessDate

drop table if exists #FICO_Add
select
CASE WHEN  ISNUMERIC(convert(varchar(12),N.USERCHAR3))=1 and ISNUMERIC(convert(varchar(12),N.USERCHAR3))>1000 then  'Not available'
					 WHEN ISNUMERIC(convert(varchar(12),N.USERCHAR3))=0 thEN  'Not available'
					  WHEN ISNUMERIC(convert(varchar(12),N.USERCHAR3))=1 THEN convert(varchar(12),N.USERCHAR3) else 'Not available'
				END AS Fico, a.PARENTACCOUNT, [Process date],a.ProcessDate,Process_date
				into #FICO_Add
from #LoanStatic A
left join  arcusym000..name N
 on a.PARENTACCOUNT=N.PARENTACCOUNT
 and a.ProcessDate=n.ProcessDate
 where ISNUMERIC(N.USERCHAR3)=1 and ISNUMERIC(N.UserChar3)<>0 and N.UserChar3<>'NO SCORE'

--Generation and FICO add
--select top 1 BIRTHDATE from arcusym000..name
drop table if exists #Gen_FICO_Add
select
 a.*
,N.birthdate
,CASE WHEN TRY_CONVERT(DATE, N.BirthDate) IS NOT NULL		
						THEN CASE   WHEN YEAR(N.BirthDate) < 1946 THEN 'Silent (till 1945)'
									WHEN YEAR(N.BirthDate) BETWEEN 1946 AND 1964 THEN 'Baby Boomers (1946-1964)'
									WHEN YEAR(N.BirthDate) BETWEEN 1965 AND 1980 THEN 'Gen X (1965-1980)'
									WHEN YEAR(N.BirthDate) BETWEEN 1981 AND 1996 THEN 'Gen Y (1981-1996)'
									WHEN YEAR(N.BirthDate) > 1996 THEN 'Gen Z (1997 and above)'
								ELSE 'NA'
							END
						ELSE 'NA'
				END AS Generation,

				CASE WHEN TRY_CONVERT(DATE, N.BirthDate) IS NOT NULL		
						THEN CASE   WHEN YEAR(N.BirthDate) < 1946 THEN 1
									WHEN YEAR(N.BirthDate) BETWEEN 1946 AND 1964 THEN 2
									WHEN YEAR(N.BirthDate) BETWEEN 1965 AND 1980 THEN 3
									WHEN YEAR(N.BirthDate) BETWEEN 1981 AND 1996 THEN 4
									WHEN YEAR(N.BirthDate) > 1996 THEN 5
								ELSE 6
							END
						ELSE 6
				END AS GenerationSort,
			 Case WHEN Fico <560 THEN '<560'
					 WHEN Fico BETWEEN 560 AND 619 THEN '560-619'
					 WHEN Fico BETWEEN 620 AND 659 THEN '620-659'
					  WHEN Fico BETWEEN 660 AND 699 THEN '660-699'
					  	  WHEN Fico BETWEEN 700 AND 759 THEN '700-759'
					 WHEN Fico  >=760 THEN '>=760'
					 ELSE 'NA' end  FicoRange ,
					 Case WHEN Fico <560 THEN 1
					 WHEN Fico BETWEEN 560 AND 619 THEN 2 
					  WHEN Fico BETWEEN 620 AND 659 THEN 3
					  WHEN Fico BETWEEN 660 AND 699 THEN 4
					  	  WHEN Fico BETWEEN 700 AND 759 THEN 5
					 WHEN Fico  >=760 THEN 6
					 ELSE 7 end  FicoSort
				into #Gen_FICO_Add
from #LoanStatic A
left join  arcusym000..name N
 on a.PARENTACCOUNT=N.PARENTACCOUNT
  and a.ProcessDate=n.ProcessDate
left join  #FICO_add F
on a.PARENTACCOUNT=F.PARENTACCOUNT
 and a.ProcessDate=F.ProcessDate

 -----underwriting bands
---adding fees table 

Drop table if exists #Loan_Transaction
		select Effective_date,PARENTACCOUNT,PARENTID,UNID--,DESCRIPTION
		,sum(Fee) Fee,sum(Payment) Payment,sum(Insurance) Insurance,sum(isnull(Deferment_Fee,0) ) Deferment_Fee,sum(Paybreak) Paybreak
		,SUM(case when DESCRIPTION='SKIP A PAYMENT' then Fee else 0 end) SKIP_PAY_Fee
		,SUM(case when DESCRIPTION='Return Item Fee' then Fee else 0 end) Return_Item_Fee
		,SUM(case when DESCRIPTION='Wire In Fee' then Fee else 0 end) WIREIN_Fee
		, case when sum(payment)>0 then 1 else 0 end TotalPaymentAccounts
		into #Loan_Transaction
		from
				(Select * , case when fee>0 and DESCRIPTION is null and Lead_Comment like '%Deferment%' then Fee when DESCRIPTION in ('DEFERMENT FEE','DEFERMENT FEES') then Fee
				else 0 end Deferment_Fee
				from
						(select concat(PARENTACCOUNT,PARENTID) UNID,cast(EFFECTIVEDATE as date) [EFFECTIVE DATE],PARENTACCOUNT,PARENTID,ACTIONCODE,SOURCECODE,BALANCECHANGE,COMMENT,DESCRIPTION
						,cast(convert(varchar(20),eomonth(EFFECTIVEDATE),112) as int) EFFECTIVEDATE,left(cast(convert(varchar(20),eomonth(EFFECTIVEDATE),112) as int),6) EFFECTIVE_DATE
						,isnull(case when ACTIONCODE='A' and SOURCECODE='F' then BALANCECHANGE else 0 end,0) Fee
						,isnull(case when ACTIONCODE='A' and SOURCECODE='I' then BALANCECHANGE else 0 end,0) Insurance
						,isnull(case when ACTIONCODE='A' and SOURCECODE='I' and description not like '%coll%' then BALANCECHANGE else 0 end,0 ) Paybreak
						,isnull(case when ACTIONCODE='P' then BALANCECHANGE else 0 end,0)*-1 Payment,SEQUENCENUMBER
						,lead(COMMENT,1) over(partition by parentaccount,parentid order by SEQUENCENUMBER) Lead_Comment
						from ARCUSYM000..LOANTRANSACTION --group by ACTIONCODE,SOURCECODE 0.00
						where   concat(PARENTACCOUNT,PARENTID) in (select distinct UNID from #LoanStatic) 
						 ) AA 
				 ) A
		where Effective_date in (select process_date from #processdate)
		group by Effective_date,PARENTACCOUNT,PARENTID,UNID--,DESCRIPTION
		order by Effective_date,PARENTACCOUNT,PARENTID
		go
		--select * from #Loan_Transaction

		---Add on income
Drop table if exists #GAP_MBP_DPW
		select TYPE,Parentaccount,ID,CoverageType,EffectiveDate,case when Cancled_days between 1 and 60 and [ADD on income]=357 
		then 0 when Cancled_days between 1 and 30 and [ADD on income]=500 then 0 when Cancled_days between 1 and 30 and [ADD on income]=313 then 0
		else [ADD on income] end [ADD on income] 
		into #GAP_MBP_DPW
		from(
		select * ,case when CoverageType='GAP' then 357 when CoverageType='MBP' then 500 when CoverageType='DPW' then 313 else 0 end [ADD on income]
		,case when CancellationDate is null then 0 else datediff(day,EffectiveDate,CancellationDate) end Cancled_days
		from
			(select T.type,T.PARENTACCOUNT,T.ID
				,case when t.type = 72 then 'MBP' else T.UserChar1 END "CoverageType"
				,T.CreationDate,T.UserDate1 "EffectiveDate",T.UserDate2 "CancellationDate",T.ExpireDate
			from ARCUSYM000.dbo.LOANTRACKING T
			join ARCUSYM000.dbo.LOAN L ON L.PARENTACCOUNT = T.PARENTACCOUNT AND L.ID =T.ID AND L.ProcessDate = T.ProcessDate
			left join ARCUSYM000.dbo.COMMENT C ON C.PARENTACCOUNT = T.PARENTACCOUNT
				AND LEFT(C.COMMENT,18) = CONCAT('Loan ',RIGHT('000'+ t.ID,4),' MOVED TO')
				AND comment like '%loan%moved to%' AND C.ProcessDate = T.ProcessDate
			where t.ProcessDate = (SELECT MAX(ProcessDate) FROM ARCUSYM000.dbo.IRS)
				and RIGHT(C.COMMENT,15) is null and (T.UserDate2 is null or T.UserDate2 > DATEADD(D,30,T.UserDate1))
				and (T.expiredate is null or T.ExpireDate > DATEADD(D,30,T.UserDate1)) and T.TYPE in (71,72)
			union all 
				 select T.type,T.PARENTACCOUNT,T.ID,'MBP' "CoverageType",T.CreationDate,T.UserDate1 "EffectiveDate"
				,T.UserDate2 "CancellationDate",T.ExpireDate
				from ARCUSYM000.dbo.TRACKING T
				join ARCUSYM000.dbo.LOAN L ON L.PARENTACCOUNT = T.PARENTACCOUNT AND L.ID = T.ID AND L.ProcessDate = T.ProcessDate
				left join ARCUSYM000.dbo.COMMENT C ON C.PARENTACCOUNT = T.PARENTACCOUNT
				AND LEFT(C.COMMENT,18) = CONCAT('Loan ',RIGHT('000'+ t.ID,4),' MOVED TO')
				AND comment like '%loan%moved to%' AND C.ProcessDate = T.ProcessDate
				where t.ProcessDate = (SELECT MAX(ProcessDate) FROM ARCUSYM000.dbo.IRS)
				and RIGHT(C.COMMENT,15) is null and (T.UserDate2 is null or T.UserDate2 > DATEADD(D,30,T.UserDate1))
				and (T.expiredate is null or T.ExpireDate > DATEADD(D,30,T.UserDate1))
				) A
		) AA
		order by PARENTACCOUNT,id
		go	
		select PARENTACCOUNT,id,CoverageType,count(*) from #GAP_MBP_DPW where [ADD on income]>0 group by PARENTACCOUNT,id,CoverageType
		having count(*)>1
		select * from #GAP_MBP_DPW where PARENTACCOUNT=0000662402 and ID=0003
		go
		
		
		Drop table if exists #GAPMBPDPW
		select concat(PARENTACCOUNT,ID) UNID,PARENTACCOUNT,ID,max(EffectiveDate) EffectiveDate,sum([ADD on income]) [ADD on income],max(left(cast(convert(varchar(20),eomonth(EFFECTIVEDATE),112) as int),6)) EFFECTIVE_DATE  
		into #GAPMBPDPW
		from
		(
		select distinct PARENTACCOUNT,ID,CoverageType,max(EffectiveDate) EffectiveDate,max([ADD on income]) [ADD on income]
		from #GAP_MBP_DPW Group by PARENTACCOUNT,ID,CoverageType 
		) A group by PARENTACCOUNT,ID
		order by PARENTACCOUNT,ID
		go


		---repossession cost----
			Drop table if exists #repossession1
		select PARENTACCOUNT,ID,concat(PARENTACCOUNT,ID) UNID,left(convert(varchar(20),creationdate,112),6) Creat_date 
				into #repossession1
				from ARCUSYM000.tracking.tvwARCULOANTRACKINGRepossession  where concat(PARENTACCOUNT,ID) in (Select UNID from #Loanstatic)
				group by PARENTACCOUNT,id,CreationDate
				go
		Drop table if exists #repossession
		Select distinct a.*,b.STATE ,case when STATE='IA' or STATE is null then 725 else 1200 end Repossesion_cost
		into #repossession 
		from #repossession1  A
				Left join (Select a.PARENTACCOUNT,STATE,ZIPCODE,ProcessDate ,left(ProcessDate,6) Process_Date
							from ARCUSYM000..name A left join #repossession1 B on a.PARENTACCOUNT=b.PARENTACCOUNT
							and left(a.ProcessDate,6)=b.Creat_date where b.PARENTACCOUNT is not null --and a.PARENTACCOUNT='0014408690'
							group by a.PARENTACCOUNT,STATE,ZIPCODE,ProcessDate) B on a.PARENTACCOUNT=b.PARENTACCOUNT
		
		--join the transaction fees into the final table before aggregation
		
		drop table if exists #TranAdd
		select distinct a.*, b.Effective_date
		,Fee, Payment,Insurance, Deferment_Fee,Paybreak
		,SKIP_PAY_Fee
		, Return_Item_Fee
		, WIREIN_Fee
		,TotalPaymentAccounts
		,[ADD on income]
		,Repossesion_cost
		into #TranAdd
		from #Gen_FICO_Add a
		left join  #Loan_Transaction b
		on a.UNID=b.unid
		and a.Process_date=b.EFFECTIVE_DATE
		left join #GAPMBPDPW c
		on a.unid=c.unid
		and a.process_date=c.EFFECTIVE_DATE
		left join #repossession d
		on a.unid=d.unid
		and a.Process_date=d.Creat_date
		order by unid
		---select top 100 * from #TranAdd where Payment>880


		-----Aggregated table
drop table if exists #Aggregated
select distinct ExtractDatepart,FullExtractDate,case when Open_flag_NewLoan=1 then 'Yes' else 'No' end NewLoanFlag
,MonthYear,Branch BranchCode
, Generation, GenerationSort
, FICORange,FICOSort,MemberType
,ProductSubtype,Tenure,TenureSort,
 count(distinct unid)  [Total Loans] ,
				--SUM(CASE WHEN MONTH(OpenDate) = MONTH([process date]) AND YEAR(OpenDate) = YEAR([process date]) THEN 1 ELSE 0 END) AS  NewLoans,
				--SUM(CASE WHEN MONTH(CloseDate)= MONTH([process date]) AND  YEAR(CloseDate)=YEAR([process date]) THEN 1 ELSE 0 END) AS  ClosedLoans,
					SUM(Open_flag_NewLoan) AS  NewLoans,
					SUM(Close_flag_closedLoan) AS  ClosedLoans,
				SUM(CASE WHEN NULLIF(ChargeOffDate, '') IS NOT NULL OR CloseDate <> '' THEN 0 ELSE Balance END) AS TotalBalance,sum(case when Open_flag_NewLoan=1 then NewLoanBalance else 0 end)NewLoanBalance,
				SUM(CASE WHEN CloseDate ='' THEN DATEDIFF(MONTH,cast(OpenDate as date),cast([process date]as date))
				 else DATEDIFF(MONTH,cast(OpenDate as date),cast(closedate as date))  end ) AS SumOfLoanTenure
				,SUM(CASE WHEN MONTH(ChargeOffDate) = MONTH([process date]) AND YEAR(ChargeOffDate)=YEAR([process date]) THEN 1 ELSE 0 END) AS   ChargeOffs,
				sum(CASE WHEN MONTH(ChargeOffDate) = MONTH([process date]) AND YEAR(ChargeOffDate)=YEAR([process date]) THEN Balance ELSE 0 END) AS ChargeOffAmount,
				ROUND(SUM(InterestRate/1000),2) AS  InterestRate,
				(SUM(CASE WHEN NULLIF(ChargeOffDate, '') IS NOT NULL OR CloseDate <> '' THEN 0 ELSE Balance * (InterestRate/1000)/1200 END )) AS InterestIncome
				,sum(isnull(Fee,0) ) Fee,sum(isnull(Payment,0)) Payment,sum(isnull(Insurance,0)) Insurance,sum(isnull(Deferment_Fee,0) ) Deferment_Fee,sum(isnull(Paybreak,0) ) Paybreak
		,sum(isnull(SKIP_PAY_Fee,0) ) SKIP_PAY_Fee
		,sum(isnull(Return_Item_Fee,0) )  Return_Item_Fee
		,sum(isnull(WIREIN_Fee,0) ) WIREIN_Fee
		,sum(isnull(TotalPaymentAccounts,0)) TotalPaymentAccounts
				, sum(isnull([ADD on income],0))  [ADD on income]
				, sum(isnull(Repossesion_cost,0)) [Repossesion_cost]
				into #Aggregated
 from #TranAdd
 group by  ExtractDatepart,fullextractdate,MonthYear,branch, generation,GenerationSort, FICORange,FICOSORT,   membertype,ProductSubtype, Tenure,TenureSort,case when Open_flag_NewLoan=1 then 'Yes' else 'No' end,NewLoanBalance

 ---joined Branch
 ---calculated cost of funds
 drop table if exists #BranchAdd
 select a. *,case when coalesce(b.City,b.Extraaddress) is null then convert(varchar,a.BRANCHCode) else coalesce(b.City,b.Extraaddress)  end Branch,
 a.totalbalance*cof/1200 [Cost of Funds], (ChargeOffAmount* 0.02/12) CollectionCosts --change this assumption of 0.2% annually
 , a.NewLoans*15 BookingCosts  ---application fee
 into #BranchAdd
 from #aggregated a
left join  ARCUSYM000..InstitutionBranchAddress b
on a.BranchCode=b.INSTITUTIONID
left join uiccu..vwCostOfFunds c
on a.fullextractdate=c.Date

--select distinct ExtractDatepart from #BranchAdd order by 1

 --Final table
 drop table if exists analytics.dbo.BT_Autoloan
 select *			
	,datepart(month, Fullextractdate) MonthNo#_FullRxtractDate,
format(FullExtractDate,'MMMMMMMMM') MonthName_FullExtractDate,
Year(FullextractDate) [Year_FullExtractDate]
 into	[analytics].dbo.[BT_AutoLoan]
    from #BranchAdd

	--select distinct ExtractDatepart from analytics.dbo.BT_Autoloan
	
		--List of members from Temenos
		
		--drop table if exists analytics..Nikita_AutoloanAnalyzer_temenos_connect	
		--	select CASE WHEN ID.Account IS NULL THEN 'Not funded' ELSE ID.Account END "Account"
		--		,ID.LoanID,Ch.DisplayName "Channel" 
		--		into analytics..Nikita_AutoloanAnalyzer_temenos_connect
		--		from [ACAKCELSQL01].[Temenos].[Lending].[Application] A with (nolock)
		--		 LEFT JOIN UICCU.dbo.vwLoanApplicationID ID
		--		ON A.applicationID = ID.ApplicationID
		--		 JOIN [ACAKCELSQL01].[Temenos].[Lending].[Channel] Ch with (nolock)
		--		ON Ch.ChannelID = A.ChannelID
		--		where id.loanid is not null
		--		order by account
--select distinct ExtractDatepart from analytics.dbo.BT_Autoloan order by 1
--select * from #LoanStatic where PARENTACCOUNT=0013531364

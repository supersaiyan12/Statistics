SELECT
       PARENTACCOUNT,
	   EMPLOYERNAME
FROM
    dbo.NAME
WHERE
    ProcessDate = (SELECT MAX(ProcessDate)FROM dbo.IRS)
    AND (EMPLOYERNAME LIKE 'SSI%' OR EMPLOYERNAME LIKE '%Social Secu%')
    AND
        (
            EMPLOYERNAME NOT LIKE 'Social Security Adm%'
            AND EMPLOYERNAME NOT LIKE '%Social Security Agency'
            AND EMPLOYERNAME NOT LIKE '%SOCIAL SECUIRTY ADMI%'
            AND EMPLOYERNAME NOT LIKE '%SSI TECHNOLOGIES%'
        );


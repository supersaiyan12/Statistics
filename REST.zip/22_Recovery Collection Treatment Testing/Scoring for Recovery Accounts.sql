
--Work on the Decision Tree logic by using the decision tree shared by Amee and debra -- 
Case when [Loan Balance]>= $900 And Share Balance >= $300 AND
AND Age < 65 AND State = ('IA','IL','WI','NE', 'MI', 'MO', 'SD')
AND loantypedescription <> 'LIVE CHECK LOAN' and FlagonRealEstate=1 or SSN is null
and current/prior placement in NCLS /Blitts then NCLS or Blitts


Case when [Loan Balance]<= $900 And Share Balance <= $300 AND
AND Age > 65 AND State != ('IA','IL','WI','NE', 'MI', 'MO', 'SD')
AND loantypedescription = 'LIVE CHECK LOAN' and FlagonRealEstate=0 then Triverity


Drop table if exists #SSI
SELECT
       PARENTACCOUNT,
	   EMPLOYERNAME
	   into #SSI
FROM
   ARCUSYM000.dbo.NAME
WHERE
    ProcessDate = (SELECT MAX(ProcessDate)FROM  ARCUSYM000.dbo.IRS)
    AND (EMPLOYERNAME LIKE 'SSI%' OR EMPLOYERNAME LIKE '%Social Secu%')
    AND
        (
            EMPLOYERNAME NOT LIKE 'Social Security Adm%'
            AND EMPLOYERNAME NOT LIKE '%Social Security Agency'
            AND EMPLOYERNAME NOT LIKE '%SOCIAL SECUIRTY ADMI%'
            AND EMPLOYERNAME NOT LIKE '%SSI TECHNOLOGIES%'
        );




--GreenState code
use ARCUSYM000


drop table if exists #test
select 
	t.POSTDATE, -t.BALANCECHANGE as Recovery, l.CHARGEOFFDATE, l.PARENTACCOUNT, l.ID, l.TYPE, l.CREDITSCORE
	into #test
from arcusym000.dbo.loan l
join arcusym000.dbo.loantransaction t on l.parentaccount=t.parentaccount and l.id=t.parentid
left join
(
	select fh.SEQUENCENUMBER, fh.PARENTACCOUNT, fh.ID, fh.NEWDATE, ROW_NUMBER() over (partition by fh.parentaccount, fh.id order by postdate, sequencenumber, ordinal desc) as rn from ARCUSYM000.dbo.FMHISTORY as fh where fh.FIELDNUMBER = 9 and fh.RECORDTYPE = 10
) as co on co.rn = 1 and co.PARENTACCOUNT = l.PARENTACCOUNT and co.ID = l.ID
where 
  exists (select * from GLHISTORY as gh where gh.POSTDATE = t.POSTDATE and gh.SEQUENCENUMBER = t.SEQUENCENUMBER and gh.AMOUNT = t.BALANCECHANGE and gh.PARENTGLACCOUNT = 70900000000000) and
  not exists (select * from GLHISTORY as gh2 where gh2.POSTDATE = t.POSTDATE and gh2.SEQUENCENUMBER = t.SEQUENCENUMBER and gh2.AMOUNT = -t.BALANCECHANGE and gh2.PARENTGLACCOUNT in (43000000000000, 76000000000000)) and
  l.processdate=CONVERT(VARCHAR(8),EOMONTH(GETDATE()-1,-1),112) and
  l.chargeoffdate is not null and
  (t.postdate > l.chargeoffdate or (co.SEQUENCENUMBER is not null and l.CHARGEOFFDATE = t.POSTDATE and t.SEQUENCENUMBER > co.SEQUENCENUMBER))
  and
  t.POSTDATE >= '20180101' and
  t.actioncode='p' and
  t.voidcode=0
  and BALANCECHANGE <> 0
  order by l.type, POSTDATE, l.PARENTACCOUNT

  --select * from #test where PARENTACCOUNT=0014199773

  --select * from ARCUSYM000..loan where PARENTACCOUNT=0014199773 and id=0002 and CHARGEOFFDATE is not null order by ProcessDate
  

  -----Trellance code
 --recovery accounts connected to loan account
  
  drop table if exists #test2
  select l.*,alc.CHARGEOFFDATE CHARGEOFFDATELoantable,alc.BALANCE,CHARGEOFFAMOUNT, alc.ProcessDate, c.*
  into #test2
   from #test l
    left join ARCUSYM000.dbo.Loan alc
  on l.PARENTACCOUNT= alc.PARENTACCOUNT
  and   l.id= alc.id
   left join  arcusym000.arcu.ARCULoanCategory c
  on l.type= c.LoanType
   where alc.ProcessDate in (Select max(ProcessDate) ProcessDate from ARCUSYM000..Loan) and alc.CHARGEOFFDATE>'2018-01-01 00:00:00'
  --select * from #test2



  ---Whole table of chargeoff
    drop table if exists #test3
  select alc.CHARGEOFFDATE CHARGEOFFDATELoantable,alc.BALANCE,CHARGEOFFAMOUNT, alc.PARENTACCOUNT loanparentaccount, alc.id loanid,alc.ProcessDate, c.*
  into #test3
   from  ARCUSYM000.dbo.Loan alc
     left join  arcusym000.arcu.ARCULoanCategory c
  on alc.type= c.LoanType
   where alc.ProcessDate in (Select max(ProcessDate) ProcessDate from ARCUSYM000..Loan) and alc.CHARGEOFFDATE>'2018-01-01 00:00:00'

   select * from #test3 
  


   --2019 chargeoff table
   --Final Recovery Table

  drop table if exists #RecoveryTable
  select a.*,left(cast(convert(varchar(20),chargeoffdate,112) as int),6) [Charge-offdate] ,
  left(cast(convert(varchar(20),postdate,112) as int),6) Recoverydate , LoanCategory2,LoanCategory3,LoanCategory4
  into #RecoveryTable 
  from #test a 
  left join   arcusym000.arcu.ARCULoanCategory b
  on a.type=b.LoanType and a.POSTDATE>'2019-01-01 00:00:00' and a.postdate<'2019-12-31 00:00:00'
 
 select * from arcusym000.arcu.ARCULoanCategory where LoanCategory4='Writeoff'


 ---





  drop table if exists #finalrecovery
  select *, DATEDIFF(month,CHARGEOFFDATE,postdate) monthdiff 
  into #finalrecovery 
  from #RecoveryTable
   where [Charge-offdate] >=201901 and [Charge-offdate]<=201912  and LoanCategory2<>'Commercial Loans' order by [Charge-offdate], Recoverydate
   select * from #finalrecovery

   --final total chargooff table

   drop table if exists #chargeofftable
   select *,left(cast(convert(varchar(20),chargeoffdateloantable,112) as int),6) [Charge-offdate] 
   into #chargeofftable from #test3 where LoanCategory2<>'Commercial Loans'

   select * from #chargeofftable where LoanCategory2='credit card'


   drop table if exists #finalchargeoff
   select  *
   into #finalchargeoff
    from #chargeofftable
   where [Charge-offdate] >=201901 and [Charge-offdate]<=201912 order by [Charge-offdate]


   
---Bureau
select top 1 * from uiccu.dbo.TransUnionAttribute_20220430


drop table if exists #Bureau_Mortgage
select SSN, FICO, MortgageOpenBalance, Date into #Bureau_Mortgage
from bureaudata.[dbo].[TransUnionAttributeHistory]
where MortgageOpenCount=1


---add harland mortgages
select top 1 * from arcusym000.arcu.arculoandetailed
select LoanPrimeNameSSN,AccountNumber, loanid, a.loantype,a.loantypedescription, 
LoanBalance, loancategory2,loancategory3,loancategory4
from arcusym000.arcu.arculoandetailed a

left join arcusym000.arcu.arculoancategory b
on a.loantype=b.loantype
where accountstatus='Open' and loanstatus='open' and
loancategory2='Real Estate' and 
--loancategory3<>'2nd Mortgage' and 

processdate in (select max(processdate) from  arcusym000.arcu.arculoandetailed )
--select * from #Bureau_Mortgage


   /*
 -----credit card connected from arcu to cardholder for validation


 ---- drop table if exists #finalrecoverysum
 ---- select sum(recovery) totalrecovery, parentaccount, id
 ---- into #finalrecoverysum
 ----  from #finalrecovery
 ---- group by parentaccount, id 


 ---- select distinct a.chargeoffamount,totalrecovery, a.CHARGEOFFDATEloantable, a.loanPARENTACCOUNT, a.loanid, a.loantype,a.LoanTypeDescription,b.loancategory2,
 ----[Card Account Charge-Off Date],Durable_Key ,concat(loanPARENTACCOUNT,loanid) unid
 ---- from #chargeofftable a
 ---- left join   arcusym000.arcu.ARCULoanCategory b
 ---- on a.loantype=b.LoanType 
 ---- left join arcusym000..name c
 ---- on a.loanparentaccount=c.parentaccount
 ----  left join ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard d
 ----  on c.SSN=d.SSN_UserChar3
 ----  left join tmgdata..cardholder e
 ----  on d.TMGDurableKey_UserChar10=e.Durable_Key
 ----  left join #finalrecoverysum f
 ----  on a.loanparentaccount=f.parentaccount
 ----  where b.LoanCategory2='Credit Card' and c.processdate='20210830'  and d.processdate='20210830' and c.processdate='20210830' and e.extract_datepart=202107
 ----  and  Durable_Key=5875344 
   --select top 1 * from arcusym000..name where PARENTACCOUNT=0013480367 and id=0003



 ---- --select top 1 * from ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard
 ----select balance, ORIGINALBALANCE,concat(PARENTACCOUNT,id) unid, * from ARCUSYM000..loan where type=400 and ProcessDate=20210830
 */
 ---Data validation
 -----
   --recovery by monthdiff

   drop table if exists #monthdiff
   select * into #monthdiff from #finalrecovery where monthdiff<13

   select distinct concat(parentaccount,id)  from  #monthdiff where LoanCategory2='credit card' and  monthdiff<13
   --select * from #monthdiff where parentaccount=0014199773 order by [Charge-offdate], POSTDATE
  
  select * from #monthdiff
  
   --aggregated recovery
   drop table if exists #recoveryaggregated
   select  case when monthdiff=0  then sum(recovery)  else 0 end [0],
  case when monthdiff>=0 and monthdiff<=2 then sum(recovery)  else 0 end [0-2],
   case when  monthdiff>=0 and monthdiff<=5  then sum(recovery) else 0 end [0-5],
   case when  monthdiff>=0 and monthdiff<=8  then sum(recovery) else 0 end [0-8],
   case when monthdiff>=0 and monthdiff<=11  then sum(recovery) else 0 end [0-11], 
    case when monthdiff=0 then  count(distinct concat(parentaccount,id))  else 0 end [0count],
   case when  monthdiff>=0 and monthdiff<=2  then  count(distinct concat(parentaccount,id)) else 0 end [0-2count],
   case when  monthdiff>=0 and monthdiff<=5  then  count(distinct concat(parentaccount,id)) else 0 end [0-5count],
   case when monthdiff>=0 and monthdiff<=8  then  count(distinct concat(parentaccount,id)) else 0 end [0-8count],
    case when  monthdiff>=0 and monthdiff<=11  then  count(distinct concat(parentaccount,id)) else 0 end [0-11count],
     LoanCategory2,LoanCategory3,LoanCategory4
	into #recoveryaggregated
	 from #monthdiff
	where monthdiff<13
   group by monthdiff,LoanCategory2,LoanCategory3,LoanCategory4
    order by  LoanCategory2,LoanCategory3,LoanCategory4 
   
   select * from #recoveryaggregated

   drop table if exists #finalrecoveryaggregated
   select sum([0])[0], sum ([0-2])[0-2], sum([0-5])[0-5], sum([0-8])[0-8], sum([0-11])[0-11],
    sum([0count])[0count], sum ([0-2count])[0-2count], sum([0-5count])[0-5count], sum([0-8count])[0-8count],
	 sum([0-11count])[0-11count],
	LoanCategory2,LoanCategory3,LoanCategory4
   into #finalrecoveryaggregated 
   from #recoveryaggregated
   group by LoanCategory2,LoanCategory3,LoanCategory4



   --select * from #finalrecoveryaggregated order by LoanCategory2,LoanCategory3,LoanCategory4

   /*
   drop table if exists #final
   select a.chargeoffamount,a.chargeoffcount,b.*
   into #final from #chargeoffaggregated a
   left join  #finalrecoveryaggregated b
   on a.LoanCategory2=b.LoanCategory2
   and a.LoanCategory3=b.LoanCategory3
   and   a.LoanCategory4=b.LoanCategory4 where [0] is not null

   --FINAL TABLE
   select
    [0]*100/chargeoffamount [$ 0ratio], [0-2]*100/chargeoffamount [$ 0-2ratio], [0-5]*100/chargeoffamount [$ 0-5ratio],
	[0-8]*100/chargeoffamount [$ 0-8ratio],[0-11]*100/chargeoffamount [$ 0-11ratio],chargeoffamount,
	  [0count]*100/chargeoffcount [# 0ratio], [0-2count]*100/chargeoffcount [# 0-2ratio], [0-5count]*100/chargeoffcount [# 0-5ratio],
   [0-8count]*100/chargeoffcount [# 0-8ratio],[0-11count]*100/chargeoffcount [# 0-11ratio],chargeoffcount ,
   [0],[0-2],[0-5],[0-8],[0-11],
    [0count],[0-2count],  [0-5count],[0-8count],[0-11count],  
 
   LoanCategory2,LoanCategory3,LoanCategory4  from #final 
  loancategories for all  */ 



   ----loancategory2 only
   
   --chargeoff by month
   drop table if exists #chargeoffaggregated
   select  sum(CHARGEOFFAMOUNT) chargeoffamount, count(concat(loanparentaccount,loanid)) chargeoffcount, LoanCategory2
   into #chargeoffaggregated from #finalchargeoff 
   group by LoanCategory2 order by  LoanCategory2

   select * from #chargeoffaggregated

    --aggregated recovery
   drop table if exists #recoveryaggregated
   select  case when monthdiff=0  then sum(recovery)  else 0 end [0],
  case when monthdiff>=0 and monthdiff<=2 then sum(recovery)  else 0 end [0-2],
   case when  monthdiff>=0 and monthdiff<=5  then sum(recovery) else 0 end [0-5],
   case when  monthdiff>=0 and monthdiff<=8  then sum(recovery) else 0 end [0-8],
   case when monthdiff>=0 and monthdiff<=11  then sum(recovery) else 0 end [0-11], 
    case when monthdiff=0 then  count(distinct concat(parentaccount,id))  else 0 end [0count],
   case when  monthdiff>=0 and monthdiff<=2  then  count(distinct concat(parentaccount,id)) else 0 end [0-2count],
   case when  monthdiff>=0 and monthdiff<=5  then  count(distinct concat(parentaccount,id)) else 0 end [0-5count],
   case when monthdiff>=0 and monthdiff<=8  then  count(distinct concat(parentaccount,id)) else 0 end [0-8count],
    case when  monthdiff>=0 and monthdiff<=11  then  count(distinct concat(parentaccount,id)) else 0 end [0-11count],
     LoanCategory2
	into #recoveryaggregated
	 from #monthdiff
	where monthdiff<13
   group by monthdiff,LoanCategory2
    order by  LoanCategory2
   
   select * from #recoveryaggregated

   drop table if exists #finalrecoveryaggregated
   select sum([0])[0], sum ([0-2])[0-2], sum([0-5])[0-5], sum([0-8])[0-8], sum([0-11])[0-11],
    sum([0count])[0count], sum ([0-2count])[0-2count], sum([0-5count])[0-5count], sum([0-8count])[0-8count],
	 sum([0-11count])[0-11count],
	LoanCategory2
   into #finalrecoveryaggregated 
   from #recoveryaggregated
   group by LoanCategory2


   drop table if exists #final
   select a.chargeoffamount,a.chargeoffcount,b.*
   into #final from #chargeoffaggregated a
   left join  #finalrecoveryaggregated b
   on a.LoanCategory2=b.LoanCategory2
  where [0] is not null

   --FINAL TABLE
   select
    [0]*100/chargeoffamount [$ 0ratio], [0-2]*100/chargeoffamount [$ 0-2ratio], [0-5]*100/chargeoffamount [$ 0-5ratio],
	[0-8]*100/chargeoffamount [$ 0-8ratio],[0-11]*100/chargeoffamount [$ 0-11ratio],chargeoffamount,
	  [0count]*100/chargeoffcount [# 0ratio], [0-2count]*100/chargeoffcount [# 0-2ratio], [0-5count]*100/chargeoffcount [# 0-5ratio],
   [0-8count]*100/chargeoffcount [# 0-8ratio],[0-11count]*100/chargeoffcount [# 0-11ratio],chargeoffcount ,
   [0],[0-2],[0-5],[0-8],[0-11],
    [0count],[0-2count],  [0-5count],[0-8count],[0-11count],  
 
   LoanCategory2  from #final 




   ----OLD QUERy

   
 --  --aggregated recovery
 --  drop table if exists #recoveryaggregated
 --  select  case when monthdiff>=0 and monthdiff<=3 then sum(recovery)  else 0 end [0-3],
 --  case when  monthdiff>=4 and monthdiff<=6  then sum(recovery) else 0 end [4-6],
 --  case when  monthdiff>=7 and monthdiff<=9  then sum(recovery) else 0 end [7-9],
 --  case when monthdiff>=10 and monthdiff<=12  then sum(recovery) else 0 end [10-12], 
 --   case when monthdiff>=0 and monthdiff<=3 then  count(distinct concat(parentaccount,id))  else 0 end [0-3count],
 --  case when  monthdiff>=4 and monthdiff<=6  then  count(distinct concat(parentaccount,id)) else 0 end [4-6count],
 --  case when  monthdiff>=7 and monthdiff<=9  then  count(distinct concat(parentaccount,id)) else 0 end [7-9count],
 --  case when monthdiff>=10 and monthdiff<=12  then  count(distinct concat(parentaccount,id)) else 0 end [10-12count],
 --   case when  monthdiff>=1 and monthdiff<=6  then  count(distinct concat(parentaccount,id)) else 0 end [1-6count],
 --  case when  monthdiff>=1 and monthdiff<=9  then  count(distinct concat(parentaccount,id)) else 0 end [1-9count],
 --  case when monthdiff>=1 and monthdiff<=12  then  count(distinct concat(parentaccount,id)) else 0 end [1-12count],
 --     case when  monthdiff>=1 and monthdiff<=6  then   sum(recovery) else 0 end [1-6sum],
 --  case when  monthdiff>=1 and monthdiff<=9  then   sum(recovery) else 0 end [1-9sum],
 --  case when monthdiff>=1 and monthdiff<=12  then  sum(recovery) else 0 end [1-12sum],
 --   LoanCategory2,LoanCategory3,LoanCategory4
	--into #recoveryaggregated
	-- from #monthdiff
	--where monthdiff<13
 --  group by monthdiff,LoanCategory2,LoanCategory3,LoanCategory4
 --   order by  LoanCategory2,LoanCategory3,LoanCategory4 
   
 --  select * from #recoveryaggregated

 --  drop table if exists #finalrecoveryaggregated
 --  select sum([0-3])[0-3], sum ([4-6])[4-6], sum([7-9])[7-9], sum([10-12])[10-12],
 --   sum([0-3count])[0-3count], sum ([4-6count])[4-6count], sum([7-9count])[7-9count], sum([10-12count])[10-12count],
	-- sum([1-6sum])[1-6sum], sum ([1-9sum])[1-9sum], sum([1-12sum])[1-12sum],sum([1-6count])[1-6count], sum ([1-9count])[1-9count], sum([1-12count])[1-12count],
	--LoanCategory2,LoanCategory3,LoanCategory4
 --  into #finalrecoveryaggregated 
 --  from #recoveryaggregated
 --  group by LoanCategory2,LoanCategory3,LoanCategory4



 --  select * from #finalrecoveryaggregated order by LoanCategory2,LoanCategory3,LoanCategory4


 --  drop table if exists #final
 --  select a.chargeoffamount,a.chargeoffcount,b.*
 --  into #final from #chargeoffaggregated a
 --  left join  #finalrecoveryaggregated b
 --  on a.LoanCategory2=b.LoanCategory2
 --  and a.LoanCategory3=b.LoanCategory3
 --  and   a.LoanCategory4=b.LoanCategory4 where [0-3] is not null


 --  select [0-3]*100/chargeoffamount [0-3ratio], [4-6]*100/chargeoffamount [4-6ratio], [7-9]*100/chargeoffamount [7-9ratio],[10-12]*100/chargeoffamount [10-12ratio],
 --  [0-3],  [4-6],[7-9],[10-12],chargeoffamount,
 --  [0-3count],  [4-6count],[7-9count],[10-12count],  chargeoffcount ,[1-6sum], [1-9sum],[1-12sum],[1-6count],[1-9count],[1-12count],
 --  --[0-3count]*100/chargeoffcount [0-3count],   [4-6count]*100/chargeoffcount [4-6count],  [7-9count]*100/chargeoffcount [7-9count], [10-12count]*100/chargeoffcount [10-12count], 
 --  LoanCategory2,LoanCategory3,LoanCategory4  from #final 
 ++


 --data validation between loan table and cardholder
--cardholder
drop table if exists #temp
  select distinct Durable_Key, ChargeoffAmount_final ChargeoffAmount_final_cardholder ,extract_datepart
  into #temp
    from tmgdata..cardholder
   where CHARGEOFF_FLAG=1 order by extract_datepart

   select * from #temp 
   
   --loan table 400

   --chargeofff type 
   drop table if exists #400
    select balance, ORIGINALBALANCE, CHARGEOFFAMOUNT CHARGEOFFAMOUNT_loan,concat(PARENTACCOUNT,id) unid,PARENTACCOUNT,id, CHARGEOFFDATE, PARTIALPAYMENT, payment, DESCRIPTION
	into #400
	 from ARCUSYM000..loan where type=400 and ProcessDate=20210831 and CHARGEOFFDATE is not null
	 select * from #400

	 drop table if exists #temp2
	 select a.*, e.Durable_Key
	  into #temp2
	   from #400 a
	 left join arcusym000..name c
  on a.parentaccount=c.parentaccount
     left join ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard d
   on c.SSN=d.SSN_UserChar3
   left join tmgdata..cardholder e
   on d.TMGDurableKey_UserChar10=e.Durable_Key
   where c.processdate='20210830'  and d.processdate='20210830' and c.processdate='20210830' and e.extract_datepart=202107

   select * from #temp where Durable_Key in ( select Durable_Key from #temp2)


   select distinct a.*, b.* from #temp a
   left join #temp2 b
   on a.Durable_Key=b.Durable_Key where ChargeoffAmount_final_cardholder<>CHARGEOFFAMOUNT_loan
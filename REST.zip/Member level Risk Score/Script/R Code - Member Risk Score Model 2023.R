###################################### Member Risk Model (3/23/2023) ###############################
## STATIC POOL : 06/30/2023

# Loading the Train Data :

rm(list=ls())
getwd()
install.packages('RODBC')
library(RODBC)
databaseConnection <- odbcDriverConnect("Driver={SQL Server};server=ACARCU01;trusted_connection=true")
RISK_train <- sqlQuery(databaseConnection, "select * from  [Analytics].[dbo].[MemberRiskScore_TRAIN]")
RISK_train <- data.frame(RISK_train,stringsAsFactors=FALSE)

RISK_train$DelinquencyProduct_Cycle1_SP = (RISK_train$ProductLoan_Cycle1_SP + RISK_train$ProductCC_Cycle1_SP + RISK_train$Cycle1_HarlandProduct_SP)
RISK_train$DelinquencyProduct_Cycle2_SP = (RISK_train$ProductLoan_Cycle2_SP + RISK_train$ProductCC_Cycle2_SP + RISK_train$Cycle2_HarlandProduct_SP)
RISK_train$DelinquencyProduct_Cycle2plus_SP = (RISK_train$ProductLoan_Cycle2plus_SP + RISK_train$ProductCC_Cycle2plus_SP + RISK_train$Cycle2plus_HarlandProduct_SP)

RISK_train$DelinquencyProduct_Cycle1_3MonthBack = (RISK_train$ProductLoan_Cycle1_3MonthBack + RISK_train$ProductCC_Cycle1_3MBack + RISK_train$Cycle1_HarlandProduct_3MonthBack)
RISK_train$DelinquencyProduct_Cycle2_3MonthBack = (RISK_train$ProductLoan_Cycle2_3MonthBack + RISK_train$ProductCC_Cycle2_3MBack + RISK_train$Cycle2_HarlandProduct_3MonthBack)
RISK_train$DelinquencyProduct_Cycle2plus_3MonthBack = (RISK_train$ProductLoan_Cycle2plus_3MonthBack + RISK_train$ProductCC_Cycle2plus_3MBack + RISK_train$Cycle2plus_HarlandProduct_3MonthBack)

RISK_train$DelinquencyProduct_Cycle1_6MonthBack = (RISK_train$ProductLoan_Cycle1_6MonthBack + RISK_train$ProductCC_Cycle1_6MBack + RISK_train$Cycle1_HarlandProduct_6MonthBack)
RISK_train$DelinquencyProduct_Cycle2_6MonthBack = (RISK_train$ProductLoan_Cycle2_6MonthBack + RISK_train$ProductCC_Cycle2_6MBack + RISK_train$Cycle2_HarlandProduct_6MonthBack)
RISK_train$DelinquencyProduct_Cycle2plus_6MonthBack = (RISK_train$ProductLoan_Cycle2plus_6MonthBack + RISK_train$ProductCC_Cycle2plus_6MBack + RISK_train$Cycle2plus_HarlandProduct_6MonthBack)

RISK_train$DelinquencyProduct_Cycle1_9MonthBack = (RISK_train$ProductLoan_Cycle1_9MonthBack + RISK_train$ProductCC_Cycle1_9MBack + RISK_train$Cycle1_HarlandProduct_9MonthBack)
RISK_train$DelinquencyProduct_Cycle2_9MonthBack = (RISK_train$ProductLoan_Cycle2_9MonthBack + RISK_train$ProductCC_Cycle2_9MBack + RISK_train$Cycle2_HarlandProduct_9MonthBack)
RISK_train$DelinquencyProduct_Cycle2plus_9MonthBack = (RISK_train$ProductLoan_Cycle2plus_9MonthBack + RISK_train$ProductCC_Cycle2plus_9MBack + RISK_train$Cycle2plus_HarlandProduct_9MonthBack)

RISK_train$DelinquencyProduct_Cycle1_12MonthBack = (RISK_train$ProductLoan_Cycle1_12MonthBack + RISK_train$ProductCC_Cycle1_12MBack + RISK_train$Cycle1_HarlandProduct_12MonthBack)
RISK_train$DelinquencyProduct_Cycle2_12MonthBack = (RISK_train$ProductLoan_Cycle2_12MonthBack + RISK_train$ProductCC_Cycle2_12MBack + RISK_train$Cycle2_HarlandProduct_12MonthBack)
RISK_train$DelinquencyProduct_Cycle2plus_12MonthBack = (RISK_train$ProductLoan_Cycle2plus_12MonthBack + RISK_train$ProductCC_Cycle2plus_12MBack + RISK_train$Cycle2plus_HarlandProduct_12MonthBack)

RISK_train$DelinquencyFlag_Cycle1_SP = ifelse((RISK_train$DelinquencyProduct_Cycle1_SP > 0),1,0)
RISK_train$DelinquencyFlag_Cycle2_SP = ifelse((RISK_train$DelinquencyProduct_Cycle2_SP > 0),1,0)
RISK_train$DelinquencyFlag_Cycle2plus_SP = ifelse((RISK_train$DelinquencyProduct_Cycle2plus_SP > 0),1,0)

RISK_train$DelinquencyFlag_Cycle1_3MonthBack = ifelse((RISK_train$DelinquencyProduct_Cycle1_3MonthBack > 0),1,0)
RISK_train$DelinquencyFlag_Cycle2_3MonthBack = ifelse((RISK_train$DelinquencyProduct_Cycle2_3MonthBack > 0),1,0)
RISK_train$DelinquencyFlag_Cycle2plus_3MonthBack = ifelse((RISK_train$DelinquencyProduct_Cycle2plus_3MonthBack > 0),1,0)

RISK_train$DelinquencyFlag_Cycle1_6MonthBack = ifelse((RISK_train$DelinquencyProduct_Cycle1_6MonthBack > 0),1,0)
RISK_train$DelinquencyFlag_Cycle2_6MonthBack = ifelse((RISK_train$DelinquencyProduct_Cycle2_6MonthBack > 0),1,0)
RISK_train$DelinquencyFlag_Cycle2plus_6MonthBack = ifelse((RISK_train$DelinquencyProduct_Cycle2plus_6MonthBack > 0),1,0)

RISK_train$DelinquencyFlag_Cycle1_9MonthBack = ifelse((RISK_train$DelinquencyProduct_Cycle1_9MonthBack > 0),1,0)
RISK_train$DelinquencyFlag_Cycle2_9MonthBack = ifelse((RISK_train$DelinquencyProduct_Cycle2_9MonthBack > 0),1,0)
RISK_train$DelinquencyFlag_Cycle2plus_9MonthBack = ifelse((RISK_train$DelinquencyProduct_Cycle2plus_9MonthBack > 0),1,0)

RISK_train$DelinquencyFlag_Cycle1_12MonthBack = ifelse((RISK_train$DelinquencyProduct_Cycle1_12MonthBack > 0),1,0)
RISK_train$DelinquencyFlag_Cycle2_12MonthBack = ifelse((RISK_train$DelinquencyProduct_Cycle2_12MonthBack > 0),1,0)
RISK_train$DelinquencyFlag_Cycle2plus_12MonthBack = ifelse((RISK_train$DelinquencyProduct_Cycle2plus_12MonthBack > 0),1,0)

RISK_train$MortgageProduct_Cycle1_SP = (RISK_train$ProductRealEstate_Cycle1_SP + RISK_train$Cycle1_HarlandProduct_SP)
RISK_train$MortgageProduct_Cycle2_SP = (RISK_train$ProductRealEstate_Cycle2_SP + RISK_train$Cycle2_HarlandProduct_SP)
RISK_train$MortgageProduct_Cycle2plus_SP = (RISK_train$ProductRealEstate_Cycle2plus_SP + RISK_train$Cycle2plus_HarlandProduct_SP)

RISK_train$MortgageProduct_Cycle1_3MonthBack = (RISK_train$ProductRealEstate_Cycle1_3MonthBack + RISK_train$Cycle1_HarlandProduct_3MonthBack)
RISK_train$MortgageProduct_Cycle2_3MonthBack = (RISK_train$ProductRealEstate_Cycle2_3MonthBack + RISK_train$Cycle2_HarlandProduct_3MonthBack)
RISK_train$MortgageProduct_Cycle2plus_3MonthBack = (RISK_train$ProductRealEstate_Cycle2plus_3MonthBack + RISK_train$Cycle2plus_HarlandProduct_3MonthBack)

RISK_train$MortgageProduct_Cycle1_6MonthBack = (RISK_train$ProductRealEstate_Cycle1_6MonthBack + RISK_train$Cycle1_HarlandProduct_6MonthBack)
RISK_train$MortgageProduct_Cycle2_6MonthBack = (RISK_train$ProductRealEstate_Cycle2_6MonthBack + RISK_train$Cycle2_HarlandProduct_6MonthBack)
RISK_train$MortgageProduct_Cycle2plus_6MonthBack = (RISK_train$ProductRealEstate_Cycle2plus_6MonthBack + RISK_train$Cycle2plus_HarlandProduct_6MonthBack)

RISK_train$MortgageProduct_Cycle1_9MonthBack = (RISK_train$ProductRealEstate_Cycle1_9MonthBack + RISK_train$Cycle1_HarlandProduct_9MonthBack)
RISK_train$MortgageProduct_Cycle2_9MonthBack = (RISK_train$ProductRealEstate_Cycle2_9MonthBack + RISK_train$Cycle2_HarlandProduct_9MonthBack)
RISK_train$MortgageProduct_Cycle2plus_9MonthBack = (RISK_train$ProductRealEstate_Cycle2plus_9MonthBack + RISK_train$Cycle2plus_HarlandProduct_9MonthBack)

RISK_train$MortgageProduct_Cycle1_12MonthBack = (RISK_train$ProductRealEstate_Cycle1_12MonthBack + RISK_train$Cycle1_HarlandProduct_12MonthBack)
RISK_train$MortgageProduct_Cycle2_12MonthBack = (RISK_train$ProductRealEstate_Cycle2_12MonthBack + RISK_train$Cycle2_HarlandProduct_12MonthBack)
RISK_train$MortgageProduct_Cycle2plus_12MonthBack = (RISK_train$ProductRealEstate_Cycle2plus_12MonthBack + RISK_train$Cycle2plus_HarlandProduct_12MonthBack)

RISK_train$MortgageFlag_Cycle1_SP = ifelse((RISK_train$MortgageProduct_Cycle1_SP > 0),1,0)
RISK_train$MortgageFlag_Cycle2_SP = ifelse((RISK_train$MortgageProduct_Cycle2_SP > 0),1,0)
RISK_train$MortgageFlag_Cycle2plus_SP = ifelse((RISK_train$MortgageProduct_Cycle2plus_SP > 0),1,0)

RISK_train$MortgageFlag_Cycle1_3MonthBack = ifelse((RISK_train$MortgageProduct_Cycle1_3MonthBack > 0),1,0)
RISK_train$MortgageFlag_Cycle2_3MonthBack = ifelse((RISK_train$MortgageProduct_Cycle2_3MonthBack > 0),1,0)
RISK_train$MortgageFlag_Cycle2plus_3MonthBack = ifelse((RISK_train$MortgageProduct_Cycle2plus_3MonthBack > 0),1,0)

RISK_train$MortgageFlag_Cycle1_6MonthBack = ifelse((RISK_train$MortgageProduct_Cycle1_6MonthBack > 0),1,0)
RISK_train$MortgageFlag_Cycle2_6MonthBack = ifelse((RISK_train$MortgageProduct_Cycle2_6MonthBack > 0),1,0)
RISK_train$MortgageFlag_Cycle2plus_6MonthBack = ifelse((RISK_train$MortgageProduct_Cycle2plus_6MonthBack > 0),1,0)

RISK_train$MortgageFlag_Cycle1_9MonthBack = ifelse((RISK_train$MortgageProduct_Cycle1_9MonthBack > 0),1,0)
RISK_train$MortgageFlag_Cycle2_9MonthBack = ifelse((RISK_train$MortgageProduct_Cycle2_9MonthBack > 0),1,0)
RISK_train$MortgageFlag_Cycle2plus_9MonthBack = ifelse((RISK_train$MortgageProduct_Cycle2plus_9MonthBack > 0),1,0)

RISK_train$MortgageFlag_Cycle1_12MonthBack = ifelse((RISK_train$MortgageProduct_Cycle1_12MonthBack > 0),1,0)
RISK_train$MortgageFlag_Cycle2_12MonthBack = ifelse((RISK_train$MortgageProduct_Cycle2_12MonthBack > 0),1,0)
RISK_train$MortgageFlag_Cycle2plus_12MonthBack = ifelse((RISK_train$MortgageProduct_Cycle2plus_12MonthBack > 0),1,0)


dim(RISK_train) # (130451 , 1006)

# Loading the Test data

RISK_test <- sqlQuery(databaseConnection, "select * from  [Analytics].[dbo].[MemberRiskScore_TEST]")
RISK_test <- data.frame(RISK_test,stringsAsFactors=FALSE)

RISK_test$DelinquencyProduct_Cycle1_SP = (RISK_test$ProductLoan_Cycle1_SP + RISK_test$ProductCC_Cycle1_SP + RISK_test$Cycle1_HarlandProduct_SP)
RISK_test$DelinquencyProduct_Cycle2_SP = (RISK_test$ProductLoan_Cycle2_SP + RISK_test$ProductCC_Cycle2_SP + RISK_test$Cycle2_HarlandProduct_SP)
RISK_test$DelinquencyProduct_Cycle2plus_SP = (RISK_test$ProductLoan_Cycle2plus_SP + RISK_test$ProductCC_Cycle2plus_SP + RISK_test$Cycle2plus_HarlandProduct_SP)

RISK_test$DelinquencyProduct_Cycle1_3MonthBack = (RISK_test$ProductLoan_Cycle1_3MonthBack + RISK_test$ProductCC_Cycle1_3MBack + RISK_test$Cycle1_HarlandProduct_3MonthBack)
RISK_test$DelinquencyProduct_Cycle2_3MonthBack = (RISK_test$ProductLoan_Cycle2_3MonthBack + RISK_test$ProductCC_Cycle2_3MBack + RISK_test$Cycle2_HarlandProduct_3MonthBack)
RISK_test$DelinquencyProduct_Cycle2plus_3MonthBack = (RISK_test$ProductLoan_Cycle2plus_3MonthBack + RISK_test$ProductCC_Cycle2plus_3MBack + RISK_test$Cycle2plus_HarlandProduct_3MonthBack)

RISK_test$DelinquencyProduct_Cycle1_6MonthBack = (RISK_test$ProductLoan_Cycle1_6MonthBack + RISK_test$ProductCC_Cycle1_6MBack + RISK_test$Cycle1_HarlandProduct_6MonthBack)
RISK_test$DelinquencyProduct_Cycle2_6MonthBack = (RISK_test$ProductLoan_Cycle2_6MonthBack + RISK_test$ProductCC_Cycle2_6MBack + RISK_test$Cycle2_HarlandProduct_6MonthBack)
RISK_test$DelinquencyProduct_Cycle2plus_6MonthBack = (RISK_test$ProductLoan_Cycle2plus_6MonthBack + RISK_test$ProductCC_Cycle2plus_6MBack + RISK_test$Cycle2plus_HarlandProduct_6MonthBack)

RISK_test$DelinquencyProduct_Cycle1_9MonthBack = (RISK_test$ProductLoan_Cycle1_9MonthBack + RISK_test$ProductCC_Cycle1_9MBack + RISK_test$Cycle1_HarlandProduct_9MonthBack)
RISK_test$DelinquencyProduct_Cycle2_9MonthBack = (RISK_test$ProductLoan_Cycle2_9MonthBack + RISK_test$ProductCC_Cycle2_9MBack + RISK_test$Cycle2_HarlandProduct_9MonthBack)
RISK_test$DelinquencyProduct_Cycle2plus_9MonthBack = (RISK_test$ProductLoan_Cycle2plus_9MonthBack + RISK_test$ProductCC_Cycle2plus_9MBack + RISK_test$Cycle2plus_HarlandProduct_9MonthBack)

RISK_test$DelinquencyProduct_Cycle1_12MonthBack = (RISK_test$ProductLoan_Cycle1_12MonthBack + RISK_test$ProductCC_Cycle1_12MBack + RISK_test$Cycle1_HarlandProduct_12MonthBack)
RISK_test$DelinquencyProduct_Cycle2_12MonthBack = (RISK_test$ProductLoan_Cycle2_12MonthBack + RISK_test$ProductCC_Cycle2_12MBack + RISK_test$Cycle2_HarlandProduct_12MonthBack)
RISK_test$DelinquencyProduct_Cycle2plus_12MonthBack = (RISK_test$ProductLoan_Cycle2plus_12MonthBack + RISK_test$ProductCC_Cycle2plus_12MBack + RISK_test$Cycle2plus_HarlandProduct_12MonthBack)

RISK_test$DelinquencyFlag_Cycle1_SP = ifelse((RISK_test$DelinquencyProduct_Cycle1_SP > 0),1,0)
RISK_test$DelinquencyFlag_Cycle2_SP = ifelse((RISK_test$DelinquencyProduct_Cycle2_SP > 0),1,0)
RISK_test$DelinquencyFlag_Cycle2plus_SP = ifelse((RISK_test$DelinquencyProduct_Cycle2plus_SP > 0),1,0)

RISK_test$DelinquencyFlag_Cycle1_3MonthBack = ifelse((RISK_test$DelinquencyProduct_Cycle1_3MonthBack > 0),1,0)
RISK_test$DelinquencyFlag_Cycle2_3MonthBack = ifelse((RISK_test$DelinquencyProduct_Cycle2_3MonthBack > 0),1,0)
RISK_test$DelinquencyFlag_Cycle2plus_3MonthBack = ifelse((RISK_test$DelinquencyProduct_Cycle2plus_3MonthBack > 0),1,0)

RISK_test$DelinquencyFlag_Cycle1_6MonthBack = ifelse((RISK_test$DelinquencyProduct_Cycle1_6MonthBack > 0),1,0)
RISK_test$DelinquencyFlag_Cycle2_6MonthBack = ifelse((RISK_test$DelinquencyProduct_Cycle2_6MonthBack > 0),1,0)
RISK_test$DelinquencyFlag_Cycle2plus_6MonthBack = ifelse((RISK_test$DelinquencyProduct_Cycle2plus_6MonthBack > 0),1,0)

RISK_test$DelinquencyFlag_Cycle1_9MonthBack = ifelse((RISK_test$DelinquencyProduct_Cycle1_9MonthBack > 0),1,0)
RISK_test$DelinquencyFlag_Cycle2_9MonthBack = ifelse((RISK_test$DelinquencyProduct_Cycle2_9MonthBack > 0),1,0)
RISK_test$DelinquencyFlag_Cycle2plus_9MonthBack = ifelse((RISK_test$DelinquencyProduct_Cycle2plus_9MonthBack > 0),1,0)

RISK_test$DelinquencyFlag_Cycle1_12MonthBack = ifelse((RISK_test$DelinquencyProduct_Cycle1_12MonthBack > 0),1,0)
RISK_test$DelinquencyFlag_Cycle2_12MonthBack = ifelse((RISK_test$DelinquencyProduct_Cycle2_12MonthBack > 0),1,0)
RISK_test$DelinquencyFlag_Cycle2plus_12MonthBack = ifelse((RISK_test$DelinquencyProduct_Cycle2plus_12MonthBack > 0),1,0)

RISK_test$MortgageProduct_Cycle1_SP = (RISK_test$ProductRealEstate_Cycle1_SP + RISK_test$Cycle1_HarlandProduct_SP)
RISK_test$MortgageProduct_Cycle2_SP = (RISK_test$ProductRealEstate_Cycle2_SP + RISK_test$Cycle2_HarlandProduct_SP)
RISK_test$MortgageProduct_Cycle2plus_SP = (RISK_test$ProductRealEstate_Cycle2plus_SP + RISK_test$Cycle2plus_HarlandProduct_SP)

RISK_test$MortgageProduct_Cycle1_3MonthBack = (RISK_test$ProductRealEstate_Cycle1_3MonthBack + RISK_test$Cycle1_HarlandProduct_3MonthBack)
RISK_test$MortgageProduct_Cycle2_3MonthBack = (RISK_test$ProductRealEstate_Cycle2_3MonthBack + RISK_test$Cycle2_HarlandProduct_3MonthBack)
RISK_test$MortgageProduct_Cycle2plus_3MonthBack = (RISK_test$ProductRealEstate_Cycle2plus_3MonthBack + RISK_test$Cycle2plus_HarlandProduct_3MonthBack)

RISK_test$MortgageProduct_Cycle1_6MonthBack = (RISK_test$ProductRealEstate_Cycle1_6MonthBack + RISK_test$Cycle1_HarlandProduct_6MonthBack)
RISK_test$MortgageProduct_Cycle2_6MonthBack = (RISK_test$ProductRealEstate_Cycle2_6MonthBack + RISK_test$Cycle2_HarlandProduct_6MonthBack)
RISK_test$MortgageProduct_Cycle2plus_6MonthBack = (RISK_test$ProductRealEstate_Cycle2plus_6MonthBack + RISK_test$Cycle2plus_HarlandProduct_6MonthBack)

RISK_test$MortgageProduct_Cycle1_9MonthBack = (RISK_test$ProductRealEstate_Cycle1_9MonthBack + RISK_test$Cycle1_HarlandProduct_9MonthBack)
RISK_test$MortgageProduct_Cycle2_9MonthBack = (RISK_test$ProductRealEstate_Cycle2_9MonthBack + RISK_test$Cycle2_HarlandProduct_9MonthBack)
RISK_test$MortgageProduct_Cycle2plus_9MonthBack = (RISK_test$ProductRealEstate_Cycle2plus_9MonthBack + RISK_test$Cycle2plus_HarlandProduct_9MonthBack)

RISK_test$MortgageProduct_Cycle1_12MonthBack = (RISK_test$ProductRealEstate_Cycle1_12MonthBack + RISK_test$Cycle1_HarlandProduct_12MonthBack)
RISK_test$MortgageProduct_Cycle2_12MonthBack = (RISK_test$ProductRealEstate_Cycle2_12MonthBack + RISK_test$Cycle2_HarlandProduct_12MonthBack)
RISK_test$MortgageProduct_Cycle2plus_12MonthBack = (RISK_test$ProductRealEstate_Cycle2plus_12MonthBack + RISK_test$Cycle2plus_HarlandProduct_12MonthBack)

RISK_test$MortgageFlag_Cycle1_SP = ifelse((RISK_test$MortgageProduct_Cycle1_SP > 0),1,0)
RISK_test$MortgageFlag_Cycle2_SP = ifelse((RISK_test$MortgageProduct_Cycle2_SP > 0),1,0)
RISK_test$MortgageFlag_Cycle2plus_SP = ifelse((RISK_test$MortgageProduct_Cycle2plus_SP > 0),1,0)

RISK_test$MortgageFlag_Cycle1_3MonthBack = ifelse((RISK_test$MortgageProduct_Cycle1_3MonthBack > 0),1,0)
RISK_test$MortgageFlag_Cycle2_3MonthBack = ifelse((RISK_test$MortgageProduct_Cycle2_3MonthBack > 0),1,0)
RISK_test$MortgageFlag_Cycle2plus_3MonthBack = ifelse((RISK_test$MortgageProduct_Cycle2plus_3MonthBack > 0),1,0)

RISK_test$MortgageFlag_Cycle1_6MonthBack = ifelse((RISK_test$MortgageProduct_Cycle1_6MonthBack > 0),1,0)
RISK_test$MortgageFlag_Cycle2_6MonthBack = ifelse((RISK_test$MortgageProduct_Cycle2_6MonthBack > 0),1,0)
RISK_test$MortgageFlag_Cycle2plus_6MonthBack = ifelse((RISK_test$MortgageProduct_Cycle2plus_6MonthBack > 0),1,0)

RISK_test$MortgageFlag_Cycle1_9MonthBack = ifelse((RISK_test$MortgageProduct_Cycle1_9MonthBack > 0),1,0)
RISK_test$MortgageFlag_Cycle2_9MonthBack = ifelse((RISK_test$MortgageProduct_Cycle2_9MonthBack > 0),1,0)
RISK_test$MortgageFlag_Cycle2plus_9MonthBack = ifelse((RISK_test$MortgageProduct_Cycle2plus_9MonthBack > 0),1,0)

RISK_test$MortgageFlag_Cycle1_12MonthBack = ifelse((RISK_test$MortgageProduct_Cycle1_12MonthBack > 0),1,0)
RISK_test$MortgageFlag_Cycle2_12MonthBack = ifelse((RISK_test$MortgageProduct_Cycle2_12MonthBack > 0),1,0)
RISK_test$MortgageFlag_Cycle2plus_12MonthBack = ifelse((RISK_test$MortgageProduct_Cycle2plus_12MonthBack > 0),1,0)

dim(RISK_test) # (55830 , 1006)

##1. Extracting out the date and char variable.

type = sapply(RISK_train,class)
write.csv(type,"CLASS OF Member Risk Model.csv")

df1 = RISK_train[,!sapply(RISK_train,is.character)]   ## Excluding character variable
dim(df1) #998 vars

install.packages("lubridate")
library(lubridate)
df2 =  df1[,!sapply(df1,is.POSIXct)]   ## Excluding date variable
dim(df2) # 998 vars

df3 =  df2[,!sapply(df2,is.factor)]   ## Here factor variables also contains the date variables. So removing it
dim(df3) # 998 vars

df4 =  df3[,!sapply(df3,is.logical)]   ## Here logical variables also contains NULL variables. So removing it
dim(df4) # 998 vars

### 2. Removing the i.i.d. variables (Uniqueidentifier variables)

df5 = subset(df4,select =-c(SSN_CC,SSN001,SSN002,SSN003,SSN004,SSN_DLQ))
dim(df5) # 992 vars

### 3. Creating the summary function

Summary_Function <- function(data)
{
  a <- data.frame()
  e <- data.frame()
  f <- data.frame()
  G <- data.frame()
  H <- data.frame()
  I <- data.frame()
  J <- data.frame()
  K <- data.frame()
  L <- data.frame()
  M <- data.frame()
  N <- data.frame()
  Col_bined <- data.frame()
  
  
  for (i in 1:ncol(data))
  {
    if(class(data[,c(i)])!="factor") {
      Total_count <- NROW(data)-(sum(is.na(data[,c(i)]))+sum(data[,c(i)]==0,na.rm = TRUE))
      Count_NA <- data.frame(sum(is.na(data[,c(i)])))
      Count_zero <- data.frame(sum(data[,c(i)]==0,na.rm = TRUE))
      Mean_1 <- data.frame(mean(data[,c(i)],na.rm = TRUE))
      Median_1 <- data.frame(median(data[,c(i)],na.rm = TRUE))
      std <- data.frame(sd(data[,c(i)],na.rm = TRUE))
      Max_1 <- data.frame(max(data[,c(i)],na.rm = TRUE))
      Min_1 <- data.frame(min(data[,c(i)],na.rm = TRUE))
      b <-data.frame(colnames(data)[i],quantile(data[,c(i)],.25,na.rm = TRUE))
      c <-data.frame(quantile(data[,c(i)],.75,na.rm = TRUE))
      d <-data.frame(quantile(data[,c(i)],.99,na.rm = TRUE))
      row.names(Count_NA) <- NULL
      row.names(Count_zero) <- NULL
      row.names(Mean_1) <- NULL
      row.names(Median_1) <- NULL
      row.names(std) <- NULL
      row.names(Max_1) <- NULL
      row.names(Min_1) <- NULL
      row.names(Total_count) <- NULL
      row.names(b) <- NULL
      row.names(c) <- NULL
      row.names(d) <- NULL
      
      a <- rbind(b,a)
      e <- rbind(c,e)
      f <- rbind(d,f)
      
      G <- rbind(Count_NA,G)
      H <- rbind(Count_zero,H)
      I <- rbind(Mean_1,I)
      J <- rbind(Median_1,J)
      K <- rbind(Max_1,K)
      L <- rbind(Min_1,L)
      M <- rbind(std,M)
      N <- rbind(Total_count,N)
      Col_bined <- data.frame(cbind(a,e,f,N,G,H,I,J,M,K,L))
      colnames(Col_bined) <- c("Variables","Percentile 25%","Percentile 75%","Percentile 99%"
                               ,"Total_No_obs","Count_NA","Count_zero","Mean","Median","Standard_Deviation","Max","Min")
      
    }
    
  }
  
  Col_bined1<- data.frame(apply(Col_bined,2,rev))
  
  write.csv(Col_bined1,"Summary of Member Risk Score Model.csv")
}


Summary_Function(df5)

# Summary Function Removal :

df6 = subset(df5,select = - c(PENALTYYTD_SAVINGS_Q1,
                              DFT_PENALTYYTD_SAVINGS_Q1_Q2,
                              PENALTYYTD_CHECKING_Q1,
                              DFT_PENALTYYTD_CHECKING_Q1_Q2,
                              AVG_CHARGEOFFAMOUNT_CERTIFICATES_SP,
                              AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1,
                              DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q2,
                              AVG_CHARGEOFFAMOUNT_MONEYMARKET_SP,
                              AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1,
                              DFT_AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1_Q2,
                              OVERDRAFTFEEYTD_MONEYMARKET_Q1,
                              DFT_OVERDRAFTFEEYTD_MONEYMARKET_Q1_Q2,
                              PENALTYYTD_MONEYMARKET_Q1,
                              DFT_PENALTYYTD_MONEYMARKET_Q1_Q2,
                              AVG_CHARGEOFFAMOUNT_IRA_Q1,
                              DFT_AVG_CHARGEOFFAMOUNT_IRA_Q1_Q2,
                              DFT_PENALTYYTD_SAVINGS_H1_H2,
                              DFT_PENALTYYTD_CHECKING_H1_H2,
                              DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_H1_H2,
                              DFT_AVG_CHARGEOFFAMOUNT_MONEYMARKET_H1_H2,
                              DFT_OVERDRAFTFEEYTD_MONEYMARKET_H1_H2,
                              DFT_PENALTYYTD_MONEYMARKET_H1_H2,
                              DFT_AVG_CHARGEOFFAMOUNT_IRA_H1_H2,
                              SUM_INTEREST_SAVINGS_Q1,
                              DFT_SUM_INTEREST_SAVINGS_Q1_Q2,
                              SUM_INTEREST_CHECKING_Q1,
                              DFT_SUM_INTEREST_CHECKING_Q1_Q2,
                              SUM_INTEREST_MONEYMARKET_Q1,
                              DFT_SUM_INTEREST_MONEYMARKET_Q1_Q2,
                              DFT_SUM_INTEREST_SAVINGS_H1_H2,
                              DFT_SUM_INTEREST_CHECKING_H1_H2,
                              DFT_SUM_INTEREST_MONEYMARKET_H1_H2,
                              PRODUCT_CommercialLoan_Q1,
                              DFT_PRODUCT_CommercialLoan_Q1_Q2,
                              CommercialLoan_MOB,
                              PAYMENTCOUNT_CommercialLoan_Q1,
                              DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q2,
                              MAX_INTERESTRATE_CommercialLoan_Q1,
                              DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q2,
                              DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q2,
                              AVG_PAYMENTSKIPS_Commercial_loan_Q1,
                              DFT_AVG_PAYMENTSKIPS_Commercial_loan_Q1_Q2,
                              DFT_AVG_PAYMENTSKIPS_Commercial_loan_Q1_Q3,
                              AVG_PAYMENTSKIPS_Real_Estate_loan_Q1,
                              DFT_AVG_PAYMENTSKIPS_Real_Estate_loan_Q1_Q2,
                              AVG_PAYMENTSKIPS_UnsecuredLoan_Q1,
                              DFT_AVG_PAYMENTSKIPS_UnsecuredLoan_Q1_Q2,
                              AVG_PAYMENTSKIPS_SecuredLoan_Q1,
                              DFT_AVG_PAYMENTSKIPS_SecuredLoan_Q1_Q2,
                              AVG_PAYMENTSKIPS_Vehicleloan_Q1,
                              DFT_AVG_PAYMENTSKIPS_Vehicleloan_Q1_Q2,
                              AVG_PAYMENTSKIPS_Loan_Q1,
                              DFT_AVG_PAYMENTSKIPS_Loan_Q1_Q2,
                              COUNT_DUEDAY1_CommercialLoan_Q1,
                              COUNT_DUEDAY1_CommercialLoan_Q2,
                              COUNT_DUEDAY2_CommercialLoan_Q1,
                              COUNT_DUEDAY2_CommercialLoan_Q2,
                              COUNT_DUEDAY2_RealEstate_Q1,
                              COUNT_DUEDAY2_RealEstate_Q2,
                              COUNT_DUEDAY2_SecuredLoan_Q1,
                              COUNT_DUEDAY2_SecuredLoan_Q2,
                              COUNT_DUEDAY2_Others_Q1,
                              COUNT_DUEDAY2_Others_Q2,
                              DFT_PRODUCT_CommercialLoan_H1_H2,
                              DFT_PAYMENTCOUNT_CommercialLoan_H1_H2,
                              DFT_MAX_INTERESTRATE_CommercialLoan_H1_H2,
                              DFT_AVG_PAYMENTSKIPS_Commercial_loan_H1_H2,
                              DFT_AVG_PAYMENTSKIPS_Real_Estate_loan_H1_H2,
                              DFT_AVG_PAYMENTSKIPS_UnsecuredLoan_H1_H2,
                              DFT_AVG_PAYMENTSKIPS_SecuredLoan_H1_H2,
                              DFT_AVG_PAYMENTSKIPS_Vehicleloan_H1_H2,
                              DFT_AVG_PAYMENTSKIPS_Loan_H1_H2,
                              COUNT_DUEDAY1_CommercialLoan_H2,
                              COUNT_DUEDAY2_CommercialLoan_H1,
                              COUNT_DUEDAY2_CommercialLoan_H2,
                              COUNT_DUEDAY2_RealEstate_H1,
                              COUNT_DUEDAY2_RealEstate_H2,
                              COUNT_DUEDAY2_SecuredLoan_H1,
                              COUNT_DUEDAY2_SecuredLoan_H2,
                              COUNT_DUEDAY2_Others_H1,
                              COUNT_DUEDAY2_Others_H2,
                              CommercialLoan_Month_to_Maturity,
                              CommercialLoan_StaticPoolFlag,
                              COUNT_PAYROLL_STATICPOOL,
                              COUNT_PAYROLL_Q1,
                              DFT_COUNT_PAYROLL_Q1_Q2,
                              COUNT_AUDIO_RESPONSE_TELEPHONE_STATICPOOL,
                              COUNT_AUDIO_RESPONSE_TELEPHONE_Q1,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q2,
                              COUNT_PAYROLL_RealEstate_Q1,
                              DFT_COUNT_PAYROLL_RealEstate_Q1_Q2,
                              COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q2,
                              COUNT_PAYROLL_SecuredLoan_Q1,
                              DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q2,
                              COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q2,
                              COUNT_PAYROLL_UnsecuredLoan_Q1,
                              DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q2,
                              COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q2,
                              COUNT_PAYROLL_VehicleLoan_Q1,
                              DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q2,
                              COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q2,
                              DFT_COUNT_PAYROLL_H1_H2,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_H1_H2,
                              DFT_COUNT_PAYROLL_RealEstate_H1_H2,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_H1_H2,
                              DFT_COUNT_PAYROLL_SecuredLoan_H1_H2,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_H1_H2,
                              DFT_COUNT_PAYROLL_UnsecuredLoan_H1_H2,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_H1_H2,
                              DFT_COUNT_PAYROLL_VehicleLoan_H1_H2,
                              DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_H1_H2,
                              COUNT_DELQ_CommercialLoan_SP,
                              COUNT_DELQ_CommercialLoan_Q1,
                              COUNT_DELQ_CommercialLoan_Q2,
                              COUNT_DELQ_CommercialLoan_H1,
                              COUNT_DELQ_CommercialLoan_H2,
                              COUNT_DELQ_Others_SP,
                              COUNT_DELQ_Others_Q1,
                              COUNT_DELQ_Others_Q2,
                              COUNT_DELQ_Others_H1,
                              Max_DelinquencyDays_CommercialLoan_Q1,
                              Max_DelinquencyDays_CommercialLoan_Q2,
                              Max_DelinquencyDays_CommercialLoan_H1,
                              Max_DelinquencyDays_CommercialLoan_H2,
                              Max_DelinquencyDays_Others_Q3,
                              Max_DelinquencyDays_Others_H1,
                              Last.Statement.External.Fee.Amount_CC_Q1,
                              DFT_Last.Statement.External.Fee.Amount_CC_Q1_Q2,
                              Last.Statement.Credit.Life.Change.Amount_CC_Q1,
                              DFT_Last.Statement.Credit.Life.Change.Amount_CC_Q1_Q2,
                              Last.Statement.Charge.Overlimit.Amount_CC_Q1,
                              DFT_Last.Statement.Charge.Overlimit.Amount_CC_Q1_Q2,
                              DFT_Last.Statement.External.Fee.Amount_CC_H1_H2,
                              DFT_Last.Statement.Credit.Life.Change.Amount_CC_H1_H2,
                              DFT_Last.Statement.Charge.Overlimit.Amount_CC_H1_H2,
                              DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q2,
                              DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q2,
                              COUNT_DUEDAY2_VehicleLoan_Q1,
                              COUNT_DUEDAY2_VehicleLoan_Q2,
                              DFT_MAX_CREDITLIMIT_SecuredLoan_H1_H2,
                              COUNT_DUEDAY2_VehicleLoan_H1,
                              COUNT_DUEDAY2_VehicleLoan_H2,
                              COUNT_DELQ_Others_H2,
                              Max_DelinquencyDays_Others_Q4,
                              Max_DelinquencyDays_Others_H2,
                              COUNT_DUEDAY2_UnsecuredLoan_Q1,
                              COUNT_DUEDAY2_UnsecuredLoan_Q2,
                              DFT_MAX_CREDITLIMIT_VehicleLoan_H1_H2,
                              COUNT_DUEDAY2_UnsecuredLoan_H1,
                              COUNT_DUEDAY2_UnsecuredLoan_H2,
                              finalLoanchargeoffFlag,
                              ForeclosureTotalBalance,
                              AVG_CHARGEOFFAMOUNT_SAVINGS_Q1,
                              MAX_CREDITLIMIT_SecuredLoan_Q1,
                              COUNT_DUEDAY1_Others_H2,
                              AVG_CHARGEOFFAMOUNT_SAVINGS_SP,
                              DFT_PENALTYYTD_CERTIFICATES_Q1_Q2,
                              MAX_CREDITLIMIT_VehicleLoan_Q1,
                              OVERDRAFTFEEYTD_SAVINGS_Q1,
                              DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q2,
                              DFT_OVERDRAFTFEEYTD_SAVINGS_Q1_Q2,
                              DFT_AVG_CHARGEOFFAMOUNT_SecuredLoan_Q1_Q2,
                              ForeclosureCountP12Months,
                              PENALTYYTD_CERTIFICATES_Q1,
                              CreditCard_Q1Flag))
dim(df6) # 822

df6 = df5
# a. WOE Binning on train data

df6$CreditCard_StaticpoolFlag = replace(df6$CreditCard_StaticpoolFlag,is.na(df6$CreditCard_StaticpoolFlag),0)

df6$RealEstate_StaticPoolFlag = replace(df6$RealEstate_StaticPoolFlag,is.na(df6$RealEstate_StaticPoolFlag),0)

df6$SecuredLoan_StaticPoolFlag = replace(df6$SecuredLoan_StaticPoolFlag,is.na(df6$SecuredLoan_StaticPoolFlag),0)

df6$UnsecuredLoan_StaticPoolFlag = replace(df6$UnsecuredLoan_StaticPoolFlag,is.na(df6$UnsecuredLoan_StaticPoolFlag),0)

df6$VehicleLoan_StaticPoolFlag = replace(df6$VehicleLoan_StaticPoolFlag,is.na(df6$VehicleLoan_StaticPoolFlag),0)

df6$CERTIFICATES_StaticpoolFlag = replace(df6$CERTIFICATES_StaticpoolFlag,is.na(df6$CERTIFICATES_StaticpoolFlag),0)

df6$CHECKING_StaticpoolFlag = replace(df6$CHECKING_StaticpoolFlag,is.na(df6$CHECKING_StaticpoolFlag),0)

df6$SAVINGS_StaticpoolFlag = replace(df6$SAVINGS_StaticpoolFlag,is.na(df6$SAVINGS_StaticpoolFlag),0)

df6$IRA_StaticpoolFlag = replace(df6$IRA_StaticpoolFlag,is.na(df6$IRA_StaticpoolFlag),0)

df6$MONEYMARKET_StaticpoolFlag= replace(df6$MONEYMARKET_StaticpoolFlag,is.na(df6$MONEYMARKET_StaticpoolFlag),0)



NAReplace_train <- replace(df6,is.na(df6),-9999999)
sum(is.na(NAReplace_train)) 

install.packages("woeBinning")
library(woeBinning)

RISK_binning_model <- woe.binning(NAReplace_train,'RISK_TARGET',NAReplace_train)
df_woe <- woe.binning.deploy(NAReplace_train,RISK_binning_model,add.woe.or.dum.var = "woe")
index_number4 <- colnames(df_woe)
write.csv(index_number4,"Combined Risk Model WOE variables.csv") 

df_woe = subset(df_woe,select=c(woe.FICO.binned,
                                woe.FICO_Staticpool.binned,
                                woe.CCWorstRatingP12Months.binned,
                                woe.CREDIT_SCORE_SP.binned,
                                woe.MAX_INTERESTRATE_Loan_Q1.binned,
                                woe.finalcycle1.binned,
                                woe.CCTotalAvailableLOC.binned,
                                woe.MAX_INTERESTRATE_VehicleLoan_Q1.binned,
                                woe.originationltv.binned,
                                woe.X.loanproducts.binned,
                                woe.Lien_flag.binned,
                                woe.finalLoanchargeoffFlag.binned,
                                woe.finalcycle2.binned,
                                woe.cpiflag.binned,
                                woe.ChargeOffTradeCountP12Months.binned,
                                woe.ChargeOffTotalBalance.binned,
                                woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned,
                                woe.AVG_MONTH_END_BALANCE_CHECKING_Q1.binned,
                                woe.AVG_MONTH_END_BALANCE_DEPOSITS_Q1.binned,
                                woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_H1_H2.binned,
                                woe.COUNT_LOAN_ADDON_Q1.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Loan_H1.binned,
                                woe.DFT_CREDIT_SCORE_SP_Q4.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Loan_Q1.binned,
                                woe.TopOfWalletCCAnnualSpend.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Loan_SP.binned,
                                woe.OVERDRAFTFEEYTD_CHECKING_Q1.binned,
                                woe.AggregatedSpendPast3Months.binned,
                                woe.COUNT_LOAN_ADDON_VehicleLoan_Q1.binned,
                                woe.DFT_COUNT_INSURANCE_H1_H2.binned,
                                woe.MAX_DAYSINCEDUEDATE_Loan_SP.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Loan_Q2.binned,
                                woe.SUM_LASTDIVAMOUNT_DEPOSITS_Q1.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H1.binned,
                                woe.COUNT_INSURANCE_Q1.binned,
                                woe.PRODUCT_UnsecuredLoan_Q1.binned,
                                woe.MAX_DAYSINCEDUEDATE_Loan_Q1.binned,
                                woe.AVG_CHARGEOFFAMOUNT_Loan_Q1.binned,
                                woe.MAX_CREDITLIMIT_Loan_Q1.binned,
                                woe.SUM_PAYMENT_Loan_Q1.binned,
                                woe.SUM_OriginalBalance_Loan_Q1.binned,
                                woe.PAYMENTCOUNT_Loan_Q1.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_Q1.binned,
                                woe.DFT_SUM_OriginalBalance_Loan_Q1_Q2.binned,
                                woe.COUNT_LOAN_ADDON_STATICPOOL.binned,
                                woe.DFT_PAYMENTCOUNT_Loan_Q1_Q2.binned,
                                woe.CCAPREstimate.binned,
                                woe.Diff_Due_Payment_Vehicle_Staticpool.binned,
                                woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_SP.binned,
                                woe.MortgageOpenCount.binned,
                                woe.RevolvingAccountCount.binned,
                                woe.MAX_DAYSINCEDUEDATE_UnsecuredLoan_SP.binned,
                                woe.UnsecuredLoan_StaticPoolFlag.binned,
                                woe.OpenTradeBalance.binned,
                                woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                woe.MOB_DEPOSITS.binned,
                                woe.DFT_COUNT_KIOSK_H1_H2.binned,
                                woe.DFT_COUNT_CHECKS_H1_H2.binned,
                                woe.DFT_COUNT_HOMEBANKING_H1_H2.binned,
                                woe.DFT_COUNT_FEE_H1_H2.binned,
                                woe.DFT_COUNT_ACH_H1_H2.binned,
                                woe.DFT_COUNT_DRAFT_H1_H2.binned,
                                woe.DFT_COUNT_CASH_H1_H2.binned,
                                woe.DFT_COUNT_LOAN_PAYMENT_H1_H2.binned,
                                woe.DFT_COUNT_NEW_LOAN_H1_H2.binned,
                                woe.MAX_DAYSINCEDUEDATE_Loan_H1.binned,
                                woe.DFT_AVG_CHARGEOFFAMOUNT_Loan_Q1_Q2.binned,
                                woe.DFT_MAX_CREDITLIMIT_Loan_Q1_Q2.binned,
                                woe.DFT_MAX_INTERESTRATE_Loan_Q1_Q2.binned,
                                woe.DFT_SUM_PAYMENT_Loan_Q1_Q2.binned,
                                woe.MortgageOpenBalance.binned,
                                woe.MAX_DAYSINCEDUEDATE_UnsecuredLoan_Q1.binned,
                                woe.AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q1.binned,
                                woe.MAX_CREDITLIMIT_UnsecuredLoan_Q1.binned,
                                woe.MAX_INTERESTRATE_UnsecuredLoan_Q1.binned,
                                woe.SUM_PAYMENT_UnsecuredLoan_Q1.binned,
                                woe.SUM_OriginalBalance_UnsecuredLoan_Q1.binned,
                                woe.PAYMENTCOUNT_UnsecuredLoan_Q1.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_SP.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_Q2.binned,
                                woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Loan_H2.binned,
                                woe.DFT_COUNT_KIOSK_Q1_Q2.binned,
                                woe.DFT_COUNT_CHECKS_Q1_Q2.binned,
                                woe.DFT_COUNT_INSURANCE_Q1_Q2.binned,
                                woe.DFT_COUNT_HOMEBANKING_Q1_Q2.binned,
                                woe.DFT_COUNT_FEE_Q1_Q2.binned,
                                woe.DFT_COUNT_ACH_Q1_Q2.binned,
                                woe.DFT_COUNT_DRAFT_Q1_Q2.binned,
                                woe.DFT_COUNT_CASH_Q1_Q2.binned,
                                woe.DFT_COUNT_LOAN_PAYMENT_Q1_Q2.binned,
                                woe.DFT_COUNT_NEW_LOAN_Q1_Q2.binned,
                                woe.DFT_COUNT_LOAN_ADDON_Q1_Q2.binned,
                                woe.MOB_SAVINGS.binned,
                                woe.AVG_UTILIZATION_RATE_CC_Q1.binned,
                                woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_H1_H2.binned,
                                woe.COUNT_ACH_Q1.binned,
                                woe.PRODUCT_RealEstate_Q1.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_Q1.binned,
                                woe.CCCount.binned,
                                woe.DFT_INTEREST_AMOUNT_VehicleLoan_H1_H2.binned,
                                woe.MAX_DAYSINCEDUEDATE_UnsecuredLoan_H1.binned,
                                woe.DFT_AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q2.binned,
                                woe.MAX_DAYSINCEDUEDATE_Loan_Q2.binned,
                                woe.OpenTradeCount.binned,
                                woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned,
                                woe.MortgageWorstRatingP12Months.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H2.binned,
                                woe.MAX_DAYSINCEDUEDATE_UnsecuredLoan_Q2.binned,
                                woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_H1_H2.binned,
                                woe.DFT_AVG_FEEAMOUNT_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_AVG_NEWBALANCE_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_FEEAMOUNT_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_INTEREST_AMOUNT_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_KIOSK_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_CHECKS_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_INSURANCE_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_HOMEBANKING_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_FEE_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_ACH_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_DRAFT_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_CASH_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_H1_H2.binned,
                                woe.COUNT_NEW_LOAN_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_LOAN_ADDON_UnsecuredLoan_H1_H2.binned,
                                woe.CCOpenCount.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_H1.binned,
                                woe.TRANSACTION_AMOUNT_DEPOSITS_Q1.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_Q2.binned,
                                woe.DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2.binned,
                                woe.DFT_PAYMENTCOUNT_Loan_H1_H2.binned,
                                woe.DFT_SUM_OriginalBalance_Loan_H1_H2.binned,
                                woe.DFT_SUM_PAYMENT_Loan_H1_H2.binned,
                                woe.DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_FEE_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_ACH_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_CASH_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q2.binned,
                                woe.COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q2.binned,
                                woe.UnsecuredLoan_Month_to_Maturity.binned,
                                woe.COUNT_DRAFT_Q1.binned,
                                woe.DFT_AVG_NEWBALANCE_VehicleLoan_H1_H2.binned,
                                woe.CCRevolvingBalance.binned,
                                woe.Max_Loan_Month_to_Maturity.binned,
                                woe.AVG_FEEAMOUNT_UnsecuredLoan_Q1.binned,
                                woe.AVG_NEWBALANCE_UnsecuredLoan_Q1.binned,
                                woe.AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1.binned,
                                woe.FEEAMOUNT_UnsecuredLoan_Q1.binned,
                                woe.INTEREST_AMOUNT_UnsecuredLoan_Q1.binned,
                                woe.LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1.binned,
                                woe.COUNT_KIOSK_UnsecuredLoan_Q1.binned,
                                woe.COUNT_CHECKS_UnsecuredLoan_Q1.binned,
                                woe.COUNT_INSURANCE_UnsecuredLoan_Q1.binned,
                                woe.COUNT_HOMEBANKING_UnsecuredLoan_Q1.binned,
                                woe.COUNT_FEE_UnsecuredLoan_Q1.binned,
                                woe.COUNT_ACH_UnsecuredLoan_Q1.binned,
                                woe.COUNT_DRAFT_UnsecuredLoan_Q1.binned,
                                woe.COUNT_CASH_UnsecuredLoan_Q1.binned,
                                woe.COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1.binned,
                                woe.COUNT_NEW_LOAN_UnsecuredLoan_Q1.binned,
                                woe.COUNT_LOAN_ADDON_UnsecuredLoan_Q1.binned,
                                woe.TRANSACTION_AMOUNT_CHECKING_Q1.binned,
                                woe.PRODUCT_VehicleLoan_Q1.binned,
                                woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_H1_H2.binned,
                                woe.MAX_Loan_MOB.binned,
                                woe.UnsecuredLoan_MOB.binned,
                                woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned,
                                woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned,
                                woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned,
                                woe.DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                woe.DFT_AVG_CHARGEOFFAMOUNT_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_MAX_CREDITLIMIT_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_MAX_INTERESTRATE_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_SUM_PAYMENT_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_SUM_OriginalBalance_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_PAYMENTCOUNT_UnsecuredLoan_H1_H2.binned,
                                woe.COUNT_INSURANCE_STATICPOOL.binned,
                                woe.HELOCOpenCount.binned,
                                woe.Last.Statement.Average.Daily.Balance.Amount_CC_Q1.binned,
                                woe.RevolvingBalance_CC_Q1.binned,
                                woe.AVG_TRANSACTION_CHECKING_Q1.binned,
                                woe.LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1.binned,
                                woe.Days.Since.Last.Login.binned,
                                woe.DFT_COUNT_KIOSK_VehicleLoan_H1_H2.binned,
                                woe.DFT_COUNT_LOAN_PAYMENT_VehicleLoan_H1_H2.binned,
                                woe.COUNT_NEW_LOAN_VehicleLoan_H1_H2.binned,
                                woe.COUNT_KIOSK_Q1.binned,
                                woe.COUNT_CHECKS_Q1.binned,
                                woe.COUNT_HOMEBANKING_Q1.binned,
                                woe.COUNT_FEE_Q1.binned,
                                woe.COUNT_CASH_Q1.binned,
                                woe.COUNT_LOAN_PAYMENT_Q1.binned,
                                woe.COUNT_NEW_LOAN_Q1.binned,
                                woe.DFT_COUNT_KIOSK_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q2.binned,
                                woe.COUNT_NEW_LOAN_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_CHECKS_VehicleLoan_H1_H2.binned,
                                woe.DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2.binned,
                                woe.AVG_TRANSACTION_DEPOSITS_Q1.binned,
                                woe.DFT_PRODUCT_Loan_H1_H2.binned,
                                woe.MOB_CHECKING.binned,
                                woe.DFT_PRODUCT_Loan_Q1_Q2.binned,
                                woe.SUM_OriginalBalance_VehicleLoan_Q1.binned,
                                woe.DEPOSITED_COUNT_DEPOSITS_Q1.binned,
                                woe.DEPOSITED_AMOUNT_DEPOSITS_Q1.binned,
                                woe.MAX_DAYSINCEDUEDATE_Vehicleloan_SP.binned,
                                woe.VehicleLoan_StaticPoolFlag.binned,
                                woe.DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2.binned,
                                woe.MAX_DAYSINCEDUEDATE_UnsecuredLoan_H2.binned,
                                woe.COUNT_ACH_VehicleLoan_Q1.binned,
                                woe.DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_H1_H2.binned,
                                woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned,
                                woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2.binned,
                                woe.DFT_TRANSACTION_AMOUNT_CHECKING_H1_H2.binned,
                                woe.DFT_AVG_FEEAMOUNT_VehicleLoan_H1_H2.binned,
                                woe.DFT_FEEAMOUNT_VehicleLoan_H1_H2.binned,
                                woe.DFT_COUNT_INSURANCE_VehicleLoan_H1_H2.binned,
                                woe.DFT_COUNT_HOMEBANKING_VehicleLoan_H1_H2.binned,
                                woe.DFT_COUNT_FEE_VehicleLoan_H1_H2.binned,
                                woe.DFT_COUNT_ACH_VehicleLoan_H1_H2.binned,
                                woe.DFT_COUNT_DRAFT_VehicleLoan_H1_H2.binned,
                                woe.DFT_COUNT_CASH_VehicleLoan_H1_H2.binned,
                                woe.Loan_Cycle2plusFlag_12MonthBack.binned,
                                woe.Loan_Cycle2Flag_12MonthBack.binned,
                                woe.Loan_Cycle1Flag_12MonthBack.binned,
                                woe.VehicleLoan_Cycle2plusFlag_12MonthBack.binned,
                                woe.VehicleLoan_Cycle2Flag_12MonthBack.binned,
                                woe.VehicleLoan_Cycle1Flag_12MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2plusFlag_12MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2Flag_12MonthBack.binned,
                                woe.UnsecuredLoan_Cycle1Flag_12MonthBack.binned,
                                woe.SecuredLoan_Cycle2plusFlag_12MonthBack.binned,
                                woe.SecuredLoan_Cycle2Flag_12MonthBack.binned,
                                woe.SecuredLoan_Cycle1Flag_12MonthBack.binned,
                                woe.RealEstate_Cycle2plusFlag_12MonthBack.binned,
                                woe.RealEstate_Cycle2Flag_12MonthBack.binned,
                                woe.RealEstate_Cycle1Flag_12MonthBack.binned,
                                woe.Loan_Cycle2plusFlag_9MonthBack.binned,
                                woe.Loan_Cycle2Flag_9MonthBack.binned,
                                woe.Loan_Cycle1Flag_9MonthBack.binned,
                                woe.VehicleLoan_Cycle2plusFlag_9MonthBack.binned,
                                woe.VehicleLoan_Cycle2Flag_9MonthBack.binned,
                                woe.VehicleLoan_Cycle1Flag_9MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2plusFlag_9MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2Flag_9MonthBack.binned,
                                woe.UnsecuredLoan_Cycle1Flag_9MonthBack.binned,
                                woe.SecuredLoan_Cycle2plusFlag_9MonthBack.binned,
                                woe.SecuredLoan_Cycle2Flag_9MonthBack.binned,
                                woe.SecuredLoan_Cycle1Flag_9MonthBack.binned,
                                woe.RealEstate_Cycle2plusFlag_9MonthBack.binned,
                                woe.RealEstate_Cycle2Flag_9MonthBack.binned,
                                woe.RealEstate_Cycle1Flag_9MonthBack.binned,
                                woe.Loan_Cycle2plusFlag_6MonthBack.binned,
                                woe.Loan_Cycle2Flag_6MonthBack.binned,
                                woe.Loan_Cycle1Flag_6MonthBack.binned,
                                woe.VehicleLoan_Cycle2plusFlag_6MonthBack.binned,
                                woe.VehicleLoan_Cycle2Flag_6MonthBack.binned,
                                woe.VehicleLoan_Cycle1Flag_6MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2plusFlag_6MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2Flag_6MonthBack.binned,
                                woe.UnsecuredLoan_Cycle1Flag_6MonthBack.binned,
                                woe.SecuredLoan_Cycle2plusFlag_6MonthBack.binned,
                                woe.SecuredLoan_Cycle2Flag_6MonthBack.binned,
                                woe.SecuredLoan_Cycle1Flag_6MonthBack.binned,
                                woe.RealEstate_Cycle2plusFlag_6MonthBack.binned,
                                woe.RealEstate_Cycle2Flag_6MonthBack.binned,
                                woe.RealEstate_Cycle1Flag_6MonthBack.binned,
                                woe.Loan_Cycle2plusFlag_3MonthBack.binned,
                                woe.Loan_Cycle2Flag_3MonthBack.binned,
                                woe.Loan_Cycle1Flag_3MonthBack.binned,
                                woe.VehicleLoan_Cycle2plusFlag_3MonthBack.binned,
                                woe.VehicleLoan_Cycle2Flag_3MonthBack.binned,
                                woe.VehicleLoan_Cycle1Flag_3MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2plusFlag_3MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2Flag_3MonthBack.binned,
                                woe.UnsecuredLoan_Cycle1Flag_3MonthBack.binned,
                                woe.SecuredLoan_Cycle2plusFlag_3MonthBack.binned,
                                woe.SecuredLoan_Cycle2Flag_3MonthBack.binned,
                                woe.SecuredLoan_Cycle1Flag_3MonthBack.binned,
                                woe.RealEstate_Cycle2plusFlag_3MonthBack.binned,
                                woe.RealEstate_Cycle2Flag_3MonthBack.binned,
                                woe.RealEstate_Cycle1Flag_3MonthBack.binned,
                                woe.Loan_Cycle2plusFlag_SP.binned,
                                woe.Loan_Cycle2Flag_SP.binned,
                                woe.Loan_Cycle1Flag_SP.binned,
                                woe.VehicleLoan_Cycle2plusFlag_SP.binned,
                                woe.VehicleLoan_Cycle2Flag_SP.binned,
                                woe.VehicleLoan_Cycle1Flag_SP.binned,
                                woe.UnsecuredLoan_Cycle2plusFlag_SP.binned,
                                woe.UnsecuredLoan_Cycle2Flag_SP.binned,
                                woe.UnsecuredLoan_Cycle1Flag_SP.binned,
                                woe.SecuredLoan_Cycle2plusFlag_SP.binned,
                                woe.SecuredLoan_Cycle2Flag_SP.binned,
                                woe.SecuredLoan_Cycle1Flag_SP.binned,
                                woe.RealEstate_Cycle2plusFlag_SP.binned,
                                woe.RealEstate_Cycle2Flag_SP.binned,
                                woe.RealEstate_Cycle1Flag_SP.binned,
                                woe.ProductLoan_Cycle2plus_12MonthBack.binned,
                                woe.ProductLoan_Cycle2_12MonthBack.binned,
                                woe.ProductLoan_Cycle1_12MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2plus_12MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2_12MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle1_12MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2plus_12MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2_12MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle1_12MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2plus_12MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2_12MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle1_12MonthBack.binned,
                                woe.ProductRealEstate_Cycle2plus_12MonthBack.binned,
                                woe.ProductRealEstate_Cycle2_12MonthBack.binned,
                                woe.ProductRealEstate_Cycle1_12MonthBack.binned,
                                woe.ProductLoan_Cycle2plus_9MonthBack.binned,
                                woe.ProductLoan_Cycle2_9MonthBack.binned,
                                woe.ProductLoan_Cycle1_9MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2plus_9MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2_9MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle1_9MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2plus_9MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2_9MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle1_9MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2plus_9MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2_9MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle1_9MonthBack.binned,
                                woe.ProductRealEstate_Cycle2plus_9MonthBack.binned,
                                woe.ProductRealEstate_Cycle2_9MonthBack.binned,
                                woe.ProductRealEstate_Cycle1_9MonthBack.binned,
                                woe.ProductLoan_Cycle2plus_6MonthBack.binned,
                                woe.ProductLoan_Cycle2_6MonthBack.binned,
                                woe.ProductLoan_Cycle1_6MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2plus_6MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2_6MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle1_6MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2plus_6MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2_6MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle1_6MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2plus_6MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2_6MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle1_6MonthBack.binned,
                                woe.ProductRealEstate_Cycle2plus_6MonthBack.binned,
                                woe.ProductRealEstate_Cycle2_6MonthBack.binned,
                                woe.ProductRealEstate_Cycle1_6MonthBack.binned,
                                woe.ProductLoan_Cycle2plus_3MonthBack.binned,
                                woe.ProductLoan_Cycle2_3MonthBack.binned,
                                woe.ProductLoan_Cycle1_3MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2plus_3MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2_3MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle1_3MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2plus_3MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2_3MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle1_3MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2plus_3MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2_3MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle1_3MonthBack.binned,
                                woe.ProductRealEstate_Cycle2plus_3MonthBack.binned,
                                woe.ProductRealEstate_Cycle2_3MonthBack.binned,
                                woe.ProductRealEstate_Cycle1_3MonthBack.binned,
                                woe.ProductLoan_Cycle2plus_SP.binned,
                                woe.ProductLoan_Cycle2_SP.binned,
                                woe.ProductLoan_Cycle1_SP.binned,
                                woe.ProductVehicleLoan_Cycle2plus_SP.binned,
                                woe.ProductVehicleLoan_Cycle2_SP.binned,
                                woe.ProductVehicleLoan_Cycle1_SP.binned,
                                woe.ProductUnsecuredLoan_Cycle2plus_SP.binned,
                                woe.ProductUnsecuredLoan_Cycle2_SP.binned,
                                woe.ProductUnsecuredLoan_Cycle1_SP.binned,
                                woe.ProductSecuredLoan_Cycle2plus_SP.binned,
                                woe.ProductSecuredLoan_Cycle2_SP.binned,
                                woe.ProductSecuredLoan_Cycle1_SP.binned,
                                woe.ProductRealEstate_Cycle2plus_SP.binned,
                                woe.ProductRealEstate_Cycle2_SP.binned,
                                woe.ProductRealEstate_Cycle1_SP.binned,
                                woe.DFT_PRODUCT_VehicleLoan_H1_H2.binned,
                                woe.DFT_PRODUCT_UnsecuredLoan_H1_H2.binned,
                                woe.DFT_PRODUCT_SecuredLoan_H1_H2.binned,
                                woe.DFT_PRODUCT_RealEstate_H1_H2.binned,
                                woe.DFT_PRODUCT_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_PRODUCT_UnsecuredLoan_Q1_Q2.binned,
                                woe.DFT_PRODUCT_SecuredLoan_Q1_Q2.binned,
                                woe.PRODUCT_SecuredLoan_Q1.binned,
                                woe.DFT_PRODUCT_RealEstate_Q1_Q2.binned,
                                woe.AutoLoanOrgBalanceP12Months.binned,
                                woe.DFT_AVG_CHARGEOFFAMOUNT_Loan_H1_H2.binned,
                                woe.DFT_MAX_CREDITLIMIT_Loan_H1_H2.binned,
                                woe.DFT_MAX_INTERESTRATE_Loan_H1_H2.binned,
                                woe.DFT_AVG_TRANSACTION_CHECKING_H1_H2.binned,
                                woe.AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1.binned,
                                woe.MAX_DAYSINCEDUEDATE_Vehicleloan_Q1.binned,
                                woe.AVG_CHARGEOFFAMOUNT_Vehicleloan_Q1.binned,
                                woe.SUM_PAYMENT_VehicleLoan_Q1.binned,
                                woe.PAYMENTCOUNT_VehicleLoan_Q1.binned,
                                woe.WITHDRAWAL_AMOUNT_CHECKING_Q1.binned,
                                woe.DEPOSITED_COUNT_CHECKING_Q1.binned,
                                woe.DEPOSITED_AMOUNT_CHECKING_Q1.binned,
                                woe.DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_FEEAMOUNT_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_CHECKS_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_FEE_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_ACH_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_DRAFT_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_CASH_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q2.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_H2.binned,
                                woe.DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q2.binned,
                                woe.MAX_DAYSINCEDUEDATE_Vehicleloan_Q2.binned,
                                woe.NumberInquiriesP6Months.binned,
                                woe.max_credit_Limit.binned,
                                woe.CL_CC_StaticPool.binned,
                                woe.SUM_LASTDIVAMOUNT_SAVINGS_Q1.binned,
                                woe.DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q2.binned,
                                woe.COUNT_KIOSK_VehicleLoan_Q1.binned,
                                woe.COUNT_LOAN_PAYMENT_VehicleLoan_Q1.binned,
                                woe.COUNT_NEW_LOAN_VehicleLoan_Q1.binned,
                                woe.HEOpenCount.binned,
                                woe.AutoWorstRatingP12Months.binned,
                                woe.COUNT_DRAFT_VehicleLoan_Q1.binned,
                                woe.DFT_SUM_LASTDIVAMOUNT_DEPOSITS_H1_H2.binned,
                                woe.MAX_DAYSINCEDUEDATE_Vehicleloan_H1.binned,
                                woe.DFT_AVG_CHARGEOFFAMOUNT_Vehicleloan_Q1_Q2.binned,
                                woe.DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2.binned,
                                woe.AutoOpenTradeBalance.binned,
                                woe.AutoOpenTradeCount.binned,
                                woe.Vehicleloan_MOB.binned,
                                woe.HELOCWorstRatingP12Months.binned,
                                woe.TopOfWalletCCCurrentBalance.binned,
                                woe.Last.Statement.Payment.Amount_CC_Q1.binned,
                                woe.DFT_SUM_PAYMENT_VehicleLoan_H1_H2.binned,
                                woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned,
                                woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2.binned,
                                woe.DFT_AVG_TRANSACTION_SAVINGS_H1_H2.binned,
                                woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_H1_H2.binned,
                                woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_H1_H2.binned,
                                woe.DFT_AVG_TRANSACTION_CHECKING_Q1_Q2.binned,
                                woe.DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2.binned,
                                woe.Vehicleloan_Month_to_Maturity.binned,
                                woe.MONEYMARKET_StaticpoolFlag.binned,
                                woe.AVG_FEEAMOUNT_VehicleLoan_Q1.binned,
                                woe.AVG_NEWBALANCE_VehicleLoan_Q1.binned,
                                woe.FEEAMOUNT_VehicleLoan_Q1.binned,
                                woe.COUNT_CHECKS_VehicleLoan_Q1.binned,
                                woe.COUNT_INSURANCE_VehicleLoan_Q1.binned,
                                woe.COUNT_HOMEBANKING_VehicleLoan_Q1.binned,
                                woe.COUNT_FEE_VehicleLoan_Q1.binned,
                                woe.COUNT_CASH_VehicleLoan_Q1.binned,
                                woe.WITHDRAWAL_COUNT_MONEYMARKET_Q1.binned,
                                woe.DEPOSITED_COUNT_MONEYMARKET_Q1.binned,
                                woe.DEPOSITED_AMOUNT_MONEYMARKET_Q1.binned,
                                woe.AVG_TRANSACTION_MONEYMARKET_Q1.binned,
                                woe.TRANSACTION_COUNT_MONEYMARKET_Q1.binned,
                                woe.TRANSACTION_AMOUNT_MONEYMARKET_Q1.binned,
                                woe.WITHDRAWAL_AMOUNT_MONEYMARKET_Q1.binned,
                                woe.TRANSACTION_AMOUNT_SAVINGS_Q1.binned,
                                woe.MOB_MONEYMARKET.binned,
                                woe.DFT_WITHDRAWAL_COUNT_CHECKING_H1_H2.binned,
                                woe.DFT_TRANSACTION_COUNT_CHECKING_H1_H2.binned,
                                woe.RealEstate_Month_to_Maturity.binned,
                                woe.AVG_TRANSACTION_SAVINGS_Q1.binned,
                                woe.DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_H1_H2.binned,
                                woe.DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_H1_H2.binned,
                                woe.RealEstate_MOB.binned,
                                woe.DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2.binned,
                                woe.DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2.binned,
                                woe.PRODUCT_DEPOSITS_SP.binned,
                                woe.DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q2.binned,
                                woe.DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q2.binned,
                                woe.DFT_AVG_TRANSACTION_MONEYMARKET_Q1_Q2.binned,
                                woe.DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q2.binned,
                                woe.DFT_WITHDRAWAL_COUNT_MONEYMARKET_H1_H2.binned,
                                woe.DFT_DEPOSITED_COUNT_MONEYMARKET_H1_H2.binned,
                                woe.DFT_AVG_TRANSACTION_MONEYMARKET_H1_H2.binned,
                                woe.DFT_TRANSACTION_COUNT_MONEYMARKET_H1_H2.binned,
                                woe.DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q2.binned,
                                woe.DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q2.binned,
                                woe.SUM_LASTDIVAMOUNT_MONEYMARKET_Q1.binned,
                                woe.AVG_MONTH_END_BALANCE_MONEYMARKET_Q1.binned,
                                woe.PRODUCT_MONEYMARKET_Q1.binned,
                                woe.DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q2.binned,
                                woe.DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_H1_H2.binned,
                                woe.DFT_DEPOSITED_AMOUNT_MONEYMARKET_H1_H2.binned,
                                woe.DFT_TRANSACTION_AMOUNT_MONEYMARKET_H1_H2.binned,
                                woe.HELOCOpenBalance.binned,
                                woe.DFT_AVG_CHARGEOFFAMOUNT_Vehicleloan_H1_H2.binned,
                                woe.DFT_MAX_INTERESTRATE_VehicleLoan_H1_H2.binned,
                                woe.DFT_SUM_OriginalBalance_VehicleLoan_H1_H2.binned,
                                woe.DFT_PAYMENTCOUNT_VehicleLoan_H1_H2.binned,
                                woe.HELOCTotalAvailableLOC.binned,
                                woe.DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q2.binned,
                                woe.COUNT_ACH_STATICPOOL.binned,
                                woe.AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1.binned,
                                woe.CCOpenBalance.binned,
                                woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned,
                                woe.DFT_AVG_CHARGEOFFAMOUNT_Real_Estate_loan_H1_H2.binned,
                                woe.DFT_MAX_CREDITLIMIT_RealEstate_H1_H2.binned,
                                woe.DFT_MAX_INTERESTRATE_RealEstate_H1_H2.binned,
                                woe.DFT_SUM_PAYMENT_RealEstate_H1_H2.binned,
                                woe.DFT_SUM_OriginalBalance_RealEstate_H1_H2.binned,
                                woe.DFT_PAYMENTCOUNT_RealEstate_H1_H2.binned,
                                woe.MAX_DAYSINCEDUEDATE_Vehicleloan_H2.binned,
                                woe.DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2.binned,
                                woe.DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2.binned,
                                woe.MOB_CERTIFICATES.binned,
                                woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                woe.COUNT_DRAFT_STATICPOOL.binned,
                                woe.SUM_LASTDIVAMOUNT_CHECKING_Q1.binned,
                                woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                woe.DFT_PENALTYYTD_CERTIFICATES_H1_H2.binned,
                                woe.DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_H1_H2.binned,
                                woe.DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_H1_H2.binned,
                                woe.DFT_SUM_INTEREST_CERTIFICATES_H1_H2.binned,
                                woe.DFT_WITHDRAWAL_COUNT_CERTIFICATES_H1_H2.binned,
                                woe.DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_H1_H2.binned,
                                woe.DFT_DEPOSITED_COUNT_CERTIFICATES_H1_H2.binned,
                                woe.DFT_DEPOSITED_AMOUNT_CERTIFICATES_H1_H2.binned,
                                woe.DFT_AVG_TRANSACTION_CERTIFICATES_H1_H2.binned,
                                woe.DFT_TRANSACTION_AMOUNT_CERTIFICATES_H1_H2.binned,
                                woe.DFT_TRANSACTION_COUNT_CERTIFICATES_H1_H2.binned,
                                woe.DFT_DEPOSITED_COUNT_DEPOSITS_H1_H2.binned,
                                woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_H1_H2.binned,
                                woe.max_age_member_CC.binned,
                                woe.MAX_DAYSINCEDUEDATE_Real_Estate_loan_SP.binned,
                                woe.RealEstate_StaticPoolFlag.binned,
                                woe.DFT_RevolvingBalance_CC_Q1_Q2.binned,
                                woe.MAX_DAYSINCEDUEDATE_Real_Estate_loan_H2.binned,
                                woe.Max_MOB_CC.binned,
                                woe.MAX_DAYSINCEDUEDATE_Real_Estate_loan_H1.binned,
                                woe.DFT_AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q1_Q2.binned,
                                woe.DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q2.binned,
                                woe.DFT_MAX_INTERESTRATE_RealEstate_Q1_Q2.binned,
                                woe.DFT_SUM_PAYMENT_RealEstate_Q1_Q2.binned,
                                woe.DFT_SUM_OriginalBalance_RealEstate_Q1_Q2.binned,
                                woe.DFT_PAYMENTCOUNT_RealEstate_Q1_Q2.binned,
                                woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_H1_H2.binned,
                                woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                woe.DFT_SUM_INTEREST_CERTIFICATES_Q1_Q2.binned,
                                woe.DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q2.binned,
                                woe.DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q2.binned,
                                woe.DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q2.binned,
                                woe.DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q2.binned,
                                woe.DFT_AVG_TRANSACTION_CERTIFICATES_Q1_Q2.binned,
                                woe.DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q2.binned,
                                woe.DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q2.binned,
                                woe.MAX_DAYSINCEDUEDATE_Real_Estate_loan_Q1.binned,
                                woe.AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q1.binned,
                                woe.MAX_CREDITLIMIT_RealEstate_Q1.binned,
                                woe.MAX_INTERESTRATE_RealEstate_Q1.binned,
                                woe.SUM_PAYMENT_RealEstate_Q1.binned,
                                woe.SUM_OriginalBalance_RealEstate_Q1.binned,
                                woe.PAYMENTCOUNT_RealEstate_Q1.binned,
                                woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned,
                                woe.CERTIFICATES_StaticpoolFlag.binned,
                                woe.PRODUCT_CERTIFICATES_SP.binned,
                                woe.Max_Extract_ACCOUNT_OPEN_DATE_CC.binned,
                                woe.DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2.binned,
                                woe.DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2.binned,
                                woe.DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2.binned,
                                woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2.binned,
                                woe.CHECKING_StaticpoolFlag.binned,
                                woe.AVG_CHARGEOFFAMOUNT_CHECKING_SP.binned,
                                woe.PRODUCT_CHECKING_SP.binned,
                                woe.DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q2.binned,
                                woe.DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2.binned,
                                woe.PRODUCT_DEPOSITS_Q1.binned,
                                woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_H1.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_SP.binned,
                                woe.WITHDRAWAL_COUNT_DEPOSITS_Q1.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_Q1.binned,
                                woe.SUM_INTEREST_CERTIFICATES_Q1.binned,
                                woe.WITHDRAWAL_COUNT_CERTIFICATES_Q1.binned,
                                woe.WITHDRAWAL_AMOUNT_CERTIFICATES_Q1.binned,
                                woe.DEPOSITED_COUNT_CERTIFICATES_Q1.binned,
                                woe.DEPOSITED_AMOUNT_CERTIFICATES_Q1.binned,
                                woe.AVG_TRANSACTION_CERTIFICATES_Q1.binned,
                                woe.TRANSACTION_AMOUNT_CERTIFICATES_Q1.binned,
                                woe.TRANSACTION_COUNT_CERTIFICATES_Q1.binned,
                                woe.Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1.binned,
                                woe.SUM_LASTDIVAMOUNT_CERTIFICATES_Q1.binned,
                                woe.AVG_MONTH_END_BALANCE_CERTIFICATES_Q1.binned,
                                woe.PRODUCT_CERTIFICATES_Q1.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_H2.binned,
                                woe.DFT_SUM_LASTDIVAMOUNT_SAVINGS_H1_H2.binned,
                                woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_H1_H2.binned,
                                woe.MAX_DAYSINCEDUEDATE_Real_Estate_loan_Q2.binned,
                                woe.DFT_AVG_TRANSACTION_SAVINGS_Q1_Q2.binned,
                                woe.DFT_AVG_FEEAMOUNT_RealEstate_H1_H2.binned,
                                woe.DFT_AVG_NEWBALANCE_RealEstate_H1_H2.binned,
                                woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_H1_H2.binned,
                                woe.DFT_FEEAMOUNT_RealEstate_H1_H2.binned,
                                woe.DFT_INTEREST_AMOUNT_RealEstate_H1_H2.binned,
                                woe.DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_H1_H2.binned,
                                woe.DFT_COUNT_KIOSK_RealEstate_H1_H2.binned,
                                woe.DFT_COUNT_CHECKS_RealEstate_H1_H2.binned,
                                woe.DFT_COUNT_INSURANCE_RealEstate_H1_H2.binned,
                                woe.DFT_COUNT_HOMEBANKING_RealEstate_H1_H2.binned,
                                woe.DFT_COUNT_FEE_RealEstate_H1_H2.binned,
                                woe.DFT_COUNT_ACH_RealEstate_H1_H2.binned,
                                woe.DFT_COUNT_DRAFT_RealEstate_H1_H2.binned,
                                woe.DFT_COUNT_CASH_RealEstate_H1_H2.binned,
                                woe.DFT_COUNT_LOAN_PAYMENT_RealEstate_H1_H2.binned,
                                woe.COUNT_NEW_LOAN_RealEstate_H1_H2.binned,
                                woe.DFT_COUNT_LOAN_ADDON_RealEstate_H1_H2.binned,
                                woe.HEWorstRatingP12Months.binned,
                                woe.DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_Q2.binned,
                                woe.DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Sale.Count_CC_H1_H2.binned,
                                woe.WITHDRAWAL_COUNT_CHECKING_Q1.binned,
                                woe.TRANSACTION_COUNT_CHECKING_Q1.binned,
                                woe.DFT_RevolvingBalance_CC_H1_H2.binned,
                                woe.DFT_DEPOSITED_COUNT_CHECKING_H1_H2.binned,
                                woe.DFT_DEPOSITED_AMOUNT_CHECKING_H1_H2.binned,
                                woe.Last.Statement.Payment.Count_CC_Q1.binned,
                                woe.HEOpenBalance.binned,
                                woe.HETotalAvailableLOC.binned,
                                woe.DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q3.binned,
                                woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_H1_H2.binned,
                                woe.DEPOSITED_AMOUNT_SAVINGS_Q1.binned,
                                woe.AVG_FEEAMOUNT_RealEstate_Q1.binned,
                                woe.AVG_NEWBALANCE_RealEstate_Q1.binned,
                                woe.AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1.binned,
                                woe.FEEAMOUNT_RealEstate_Q1.binned,
                                woe.INTEREST_AMOUNT_RealEstate_Q1.binned,
                                woe.LOAN_TRANSACTION_AMOUNT_RealEstate_Q1.binned,
                                woe.COUNT_KIOSK_RealEstate_Q1.binned,
                                woe.COUNT_CHECKS_RealEstate_Q1.binned,
                                woe.COUNT_INSURANCE_RealEstate_Q1.binned,
                                woe.COUNT_HOMEBANKING_RealEstate_Q1.binned,
                                woe.COUNT_FEE_RealEstate_Q1.binned,
                                woe.COUNT_ACH_RealEstate_Q1.binned,
                                woe.COUNT_DRAFT_RealEstate_Q1.binned,
                                woe.COUNT_CASH_RealEstate_Q1.binned,
                                woe.COUNT_LOAN_PAYMENT_RealEstate_Q1.binned,
                                woe.COUNT_NEW_LOAN_RealEstate_Q1.binned,
                                woe.COUNT_LOAN_ADDON_RealEstate_Q1.binned,
                                woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2.binned,
                                woe.MortgageFlag_Cycle2plus_12MonthBack.binned,
                                woe.MortgageFlag_Cycle2_12MonthBack.binned,
                                woe.MortgageFlag_Cycle1_12MonthBack.binned,
                                woe.MortgageFlag_Cycle2plus_9MonthBack.binned,
                                woe.MortgageFlag_Cycle2_9MonthBack.binned,
                                woe.MortgageFlag_Cycle1_9MonthBack.binned,
                                woe.MortgageFlag_Cycle2plus_6MonthBack.binned,
                                woe.MortgageFlag_Cycle2_6MonthBack.binned,
                                woe.MortgageFlag_Cycle1_6MonthBack.binned,
                                woe.MortgageFlag_Cycle2plus_3MonthBack.binned,
                                woe.MortgageFlag_Cycle2_3MonthBack.binned,
                                woe.MortgageFlag_Cycle1_3MonthBack.binned,
                                woe.MortgageFlag_Cycle2plus_SP.binned,
                                woe.MortgageFlag_Cycle2_SP.binned,
                                woe.MortgageFlag_Cycle1_SP.binned,
                                woe.MortgageProduct_Cycle2plus_12MonthBack.binned,
                                woe.MortgageProduct_Cycle2_12MonthBack.binned,
                                woe.MortgageProduct_Cycle1_12MonthBack.binned,
                                woe.MortgageProduct_Cycle2plus_9MonthBack.binned,
                                woe.MortgageProduct_Cycle2_9MonthBack.binned,
                                woe.MortgageProduct_Cycle1_9MonthBack.binned,
                                woe.MortgageProduct_Cycle2plus_6MonthBack.binned,
                                woe.MortgageProduct_Cycle2_6MonthBack.binned,
                                woe.MortgageProduct_Cycle1_6MonthBack.binned,
                                woe.MortgageProduct_Cycle2plus_3MonthBack.binned,
                                woe.MortgageProduct_Cycle2_3MonthBack.binned,
                                woe.MortgageProduct_Cycle1_3MonthBack.binned,
                                woe.MortgageProduct_Cycle2plus_SP.binned,
                                woe.MortgageProduct_Cycle2_SP.binned,
                                woe.MortgageProduct_Cycle1_SP.binned,
                                woe.chargeoffflag_HarlandProduct_3MonthBack.binned,
                                woe.Cycle2plus_HarlandProduct_3MonthBack.binned,
                                woe.Cycle2_HarlandProduct_3MonthBack.binned,
                                woe.Cycle1_HarlandProduct_3MonthBack.binned,
                                woe.chargeoffflag_HarlandProduct_6MonthBack.binned,
                                woe.Cycle2plus_HarlandProduct_6MonthBack.binned,
                                woe.Cycle2_HarlandProduct_6MonthBack.binned,
                                woe.Cycle1_HarlandProduct_6MonthBack.binned,
                                woe.chargeoffflag_HarlandProduct_9MonthBack.binned,
                                woe.Cycle2plus_HarlandProduct_9MonthBack.binned,
                                woe.Cycle2_HarlandProduct_9MonthBack.binned,
                                woe.Cycle1_HarlandProduct_9MonthBack.binned,
                                woe.chargeoffflag_HarlandProduct_12MonthBack.binned,
                                woe.Cycle2plus_HarlandProduct_12MonthBack.binned,
                                woe.Cycle2_HarlandProduct_12MonthBack.binned,
                                woe.Cycle1_HarlandProduct_12MonthBack.binned,
                                woe.chargeoffflag_HarlandProduct_SP.binned,
                                woe.Cycle2plus_HarlandProduct_SP.binned,
                                woe.Cycle2_HarlandProduct_SP.binned,
                                woe.Cycle1_HarlandProduct_SP.binned,
                                woe.DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q2.binned,
                                woe.DFT_AVG_NEWBALANCE_RealEstate_Q1_Q2.binned,
                                woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2.binned,
                                woe.DFT_FEEAMOUNT_RealEstate_Q1_Q2.binned,
                                woe.DFT_INTEREST_AMOUNT_RealEstate_Q1_Q2.binned,
                                woe.DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2.binned,
                                woe.DFT_COUNT_KIOSK_RealEstate_Q1_Q2.binned,
                                woe.DFT_COUNT_CHECKS_RealEstate_Q1_Q2.binned,
                                woe.DFT_COUNT_INSURANCE_RealEstate_Q1_Q2.binned,
                                woe.DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q2.binned,
                                woe.DFT_COUNT_FEE_RealEstate_Q1_Q2.binned,
                                woe.DFT_COUNT_ACH_RealEstate_Q1_Q2.binned,
                                woe.DFT_COUNT_DRAFT_RealEstate_Q1_Q2.binned,
                                woe.DFT_COUNT_CASH_RealEstate_Q1_Q2.binned,
                                woe.DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q2.binned,
                                woe.COUNT_NEW_LOAN_RealEstate_Q1_Q2.binned,
                                woe.DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q2.binned,
                                woe.DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2.binned,
                                woe.DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2.binned,
                                woe.DFT_spend_CC_Q1_Q2.binned,
                                woe.DFT_DEPOSITED_AMOUNT_SAVINGS_H1_H2.binned,
                                woe.DFT_Last.Statement.Sale.Amount_CC_Q1_Q2.binned,
                                woe.DFT_WITHDRAWAL_COUNT_DEPOSITS_H1_H2.binned,
                                woe.DFT_WITHDRAWAL_COUNT_SAVINGS_H1_H2.binned,
                                woe.DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q2.binned,
                                woe.COUNT_HOMEBANKING_STATICPOOL.binned,
                                woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned,
                                woe.DFT_WITHDRAWAL_AMOUNT_CHECKING_H1_H2.binned,
                                woe.WITHDRAWAL_AMOUNT_SAVINGS_Q1.binned,
                                woe.TRANSACTION_COUNT_DEPOSITS_Q1.binned,
                                woe.StudentLoanOpenCount.binned,
                                woe.WITHDRAWAL_COUNT_SAVINGS_Q1.binned,
                                woe.DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2.binned,
                                woe.DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2.binned,
                                woe.TRIP_FLAG_staticpool.binned,
                                woe.AVG_CHARGEOFFAMOUNT_CHECKING_Q1.binned,
                                woe.PRODUCT_CHECKING_Q1.binned,
                                woe.DFT_DEPOSITED_COUNT_SAVINGS_H1_H2.binned,
                                woe.DFT_TRANSACTION_COUNT_SAVINGS_H1_H2.binned,
                                woe.DFT_Last.Statement.Payment.Amount_CC_Q1_Q2.binned,
                                woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2.binned,
                                woe.DFT_Promo_Current_Interest_CC_H1_H2.binned,
                                woe.DFT_Protected_Current_Interest_CC_H1_H2.binned,
                                woe.DFT_Promo_Balance_CC_H1_H2.binned,
                                woe.DFT_Protected_Balance_CC_H1_H2.binned,
                                woe.DFT_spend_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Cash.Average.Daily.Balance.Amount_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Charge.Sale.Amount_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Charge.Overlimit.Amount_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Charge.Cash.Amount_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Charge.Late.Amount_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Credit.Life.Change.Amount_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.External.Fee.Amount_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Return.Count_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Cash.Advance.Count_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Return.Amount_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Cash.Amount_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Payment.Amount_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Payment.Count_CC_H1_H2.binned,
                                woe.CL_DIFF_past_oneyear.binned,
                                woe.Promo_Current_Interest_CC_Q1.binned,
                                woe.Protected_Current_Interest_CC_Q1.binned,
                                woe.Promo_Balance_CC_Q1.binned,
                                woe.Protected_Balance_CC_Q1.binned,
                                woe.spend_CC_Q1.binned,
                                woe.Last.Statement.Charge.Sale.Amount_CC_Q1.binned,
                                woe.Last.Statement.Charge.Overlimit.Amount_CC_Q1.binned,
                                woe.Last.Statement.Charge.Cash.Amount_CC_Q1.binned,
                                woe.Last.Statement.Charge.Late.Amount_CC_Q1.binned,
                                woe.Last.Statement.Credit.Life.Change.Amount_CC_Q1.binned,
                                woe.Last.Statement.External.Fee.Amount_CC_Q1.binned,
                                woe.Last.Statement.Return.Count_CC_Q1.binned,
                                woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned,
                                woe.Last.Statement.Sale.Count_CC_Q1.binned,
                                woe.Last.Statement.Return.Amount_CC_Q1.binned,
                                woe.Last.Statement.Cash.Amount_CC_Q1.binned,
                                woe.Last.Statement.Sale.Amount_CC_Q1.binned,
                                woe.DFT_Promo_Current_Interest_CC_Q1_Q2.binned,
                                woe.DFT_Protected_Current_Interest_CC_Q1_Q2.binned,
                                woe.DFT_Promo_Balance_CC_Q1_Q2.binned,
                                woe.DFT_Protected_Balance_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Charge.Sale.Amount_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Charge.Overlimit.Amount_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Charge.Cash.Amount_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Charge.Late.Amount_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Credit.Life.Change.Amount_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.External.Fee.Amount_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Return.Count_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Cash.Advance.Count_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Sale.Count_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Return.Amount_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Cash.Amount_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Payment.Count_CC_Q1_Q2.binned,
                                woe.DFT_TRANSACTION_COUNT_DEPOSITS_H1_H2.binned,
                                woe.DEPOSITED_COUNT_SAVINGS_Q1.binned,
                                woe.TRANSACTION_COUNT_SAVINGS_Q1.binned,
                                woe.MEMBER.binned,
                                woe.COUNT_KIOSK_STATICPOOL.binned,
                                woe.COUNT_CHECKS_STATICPOOL.binned,
                                woe.COUNT_FEE_STATICPOOL.binned,
                                woe.COUNT_CASH_STATICPOOL.binned,
                                woe.COUNT_LOAN_PAYMENT_STATICPOOL.binned,
                                woe.COUNT_NEW_LOAN_STATICPOOL.binned,
                                woe.CC_Cycle2plusFlag_12MBack.binned,
                                woe.CC_Cycle2Flag_12MBack.binned,
                                woe.CC_Cycle1Flag_12MBack.binned,
                                woe.ProductCC_Cycle2plus_12MBack.binned,
                                woe.ProductCC_Cycle2_12MBack.binned,
                                woe.ProductCC_Cycle1_12MBack.binned,
                                woe.CC_Cycle2plusFlag_9MBack.binned,
                                woe.CC_Cycle2Flag_9MBack.binned,
                                woe.CC_Cycle1Flag_9MBack.binned,
                                woe.ProductCC_Cycle2plus_9MBack.binned,
                                woe.ProductCC_Cycle2_9MBack.binned,
                                woe.ProductCC_Cycle1_9MBack.binned,
                                woe.CC_Cycle2plusFlag_6MBack.binned,
                                woe.CC_Cycle2Flag_6MBack.binned,
                                woe.CC_Cycle1Flag_6MBack.binned,
                                woe.ProductCC_Cycle2plus_6MBack.binned,
                                woe.ProductCC_Cycle2_6MBack.binned,
                                woe.ProductCC_Cycle1_6MBack.binned,
                                woe.CC_Cycle2plusFlag_3MBack.binned,
                                woe.CC_Cycle2Flag_3MBack.binned,
                                woe.CC_Cycle1Flag_3MBack.binned,
                                woe.ProductCC_Cycle2plus_3MBack.binned,
                                woe.ProductCC_Cycle2_3MBack.binned,
                                woe.ProductCC_Cycle1_3MBack.binned,
                                woe.CC_Cycle2plusFlag_SP.binned,
                                woe.CC_Cycle2Flag_SP.binned,
                                woe.CC_Cycle1Flag_SP.binned,
                                woe.ProductCC_Cycle2plus_SP.binned,
                                woe.ProductCC_Cycle2_SP.binned,
                                woe.ProductCC_Cycle1_SP.binned,
                                woe.MOB_CC_staticPool.binned,
                                woe.ChargeoffAmount_final_CC.binned,
                                woe.Count_Durable_CC.binned,
                                woe.DFT_PRODUCT_CC_H1_H2.binned,
                                woe.DFT_PRODUCT_CC_Q1_Q2.binned,
                                woe.PRODUCT_CC_Q1.binned,
                                woe.CreditCard_Q1Flag.binned,
                                woe.CreditCard_StaticpoolFlag.binned,
                                woe.Max_chargoff_date_CC.binned,
                                woe.SUM_INTEREST_DEPOSITS_Q1.binned,
                                woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3.binned,
                                woe.DFT_PRODUCT_CERTIFICATES_Q1_Q2.binned,
                                woe.AVG_CHARGEOFFAMOUNT_DEPOSITS_SP.binned,
                                woe.DFT_PRODUCT_CERTIFICATES_H1_H2.binned,
                                woe.DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2.binned,
                                woe.Max_Closed_account_flag_CC.binned,
                                woe.DFT_OVERDRAFTFEEYTD_CHECKING_Q1_Q2.binned,
                                woe.DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q2.binned,
                                woe.DelinquencyFlag_Cycle2plus_12MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2_12MonthBack.binned,
                                woe.DelinquencyFlag_Cycle1_12MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2plus_9MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2_9MonthBack.binned,
                                woe.DelinquencyFlag_Cycle1_9MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2plus_6MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2_6MonthBack.binned,
                                woe.DelinquencyFlag_Cycle1_6MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2plus_3MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2_3MonthBack.binned,
                                woe.DelinquencyFlag_Cycle1_3MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2plus_SP.binned,
                                woe.DelinquencyFlag_Cycle2_SP.binned,
                                woe.DelinquencyFlag_Cycle1_SP.binned,
                                woe.DelinquencyProduct_Cycle2plus_12MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2_12MonthBack.binned,
                                woe.DelinquencyProduct_Cycle1_12MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2plus_9MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2_9MonthBack.binned,
                                woe.DelinquencyProduct_Cycle1_9MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2plus_6MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2_6MonthBack.binned,
                                woe.DelinquencyProduct_Cycle1_6MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2plus_3MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2_3MonthBack.binned,
                                woe.DelinquencyProduct_Cycle1_3MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2plus_SP.binned,
                                woe.DelinquencyProduct_Cycle2_SP.binned,
                                woe.DelinquencyProduct_Cycle1_SP.binned,
                                woe.DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_H1_H2.binned,
                                woe.BankruptcyCount.binned,
                                woe.DFT_PRODUCT_MONEYMARKET_H1_H2.binned,
                                woe.StudentLoanOpenBalance.binned,
                                woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned,
                                woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned,
                                woe.DFT_AVG_CHARGEOFFAMOUNT_CHECKING_H1_H2.binned,
                                woe.DFT_PRODUCT_MONEYMARKET_Q1_Q2.binned,
                                woe.DFT_SUM_INTEREST_DEPOSITS_Q1_Q2.binned,
                                woe.PRODUCT_SAVINGS_SP.binned,
                                woe.DFT_PRODUCT_DEPOSITS_Q1_Q2.binned,
                                woe.PRODUCT_SAVINGS_Q1.binned,
                                woe.DFT_PRODUCT_SAVINGS_Q1_Q2.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_Q2.binned,
                                woe.DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_FEEAMOUNT_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_KIOSK_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_CHECKS_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_FEE_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_ACH_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_DRAFT_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_CASH_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q2.binned,
                                woe.COUNT_NEW_LOAN_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q2.binned,
                                woe.MAX_DAYSINCEDUEDATE_SecuredLoan_Q2.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_Q1.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_H1.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_H2.binned,
                                woe.MAX_DAYSINCEDUEDATE_SecuredLoan_H2.binned,
                                woe.AVG_FEEAMOUNT_SecuredLoan_Q1.binned,
                                woe.AVG_NEWBALANCE_SecuredLoan_Q1.binned,
                                woe.AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1.binned,
                                woe.FEEAMOUNT_SecuredLoan_Q1.binned,
                                woe.INTEREST_AMOUNT_SecuredLoan_Q1.binned,
                                woe.LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1.binned,
                                woe.COUNT_KIOSK_SecuredLoan_Q1.binned,
                                woe.COUNT_CHECKS_SecuredLoan_Q1.binned,
                                woe.COUNT_INSURANCE_SecuredLoan_Q1.binned,
                                woe.COUNT_HOMEBANKING_SecuredLoan_Q1.binned,
                                woe.COUNT_FEE_SecuredLoan_Q1.binned,
                                woe.COUNT_ACH_SecuredLoan_Q1.binned,
                                woe.COUNT_DRAFT_SecuredLoan_Q1.binned,
                                woe.COUNT_CASH_SecuredLoan_Q1.binned,
                                woe.COUNT_LOAN_PAYMENT_SecuredLoan_Q1.binned,
                                woe.COUNT_NEW_LOAN_SecuredLoan_Q1.binned,
                                woe.COUNT_LOAN_ADDON_SecuredLoan_Q1.binned,
                                woe.MAX_DAYSINCEDUEDATE_SecuredLoan_Q1.binned,
                                woe.AVG_CHARGEOFFAMOUNT_SecuredLoan_Q1.binned,
                                woe.MAX_INTERESTRATE_SecuredLoan_Q1.binned,
                                woe.SUM_PAYMENT_SecuredLoan_Q1.binned,
                                woe.SUM_OriginalBalance_SecuredLoan_Q1.binned,
                                woe.PAYMENTCOUNT_SecuredLoan_Q1.binned,
                                woe.MAX_DAYSINCEDUEDATE_SecuredLoan_H1.binned,
                                woe.DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_SUM_PAYMENT_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q2.binned,
                                woe.DFT_SUM_INTEREST_DEPOSITS_H1_H2.binned,
                                woe.MAX_DAYSINCEDUEDATE_SecuredLoan_SP.binned,
                                woe.SecuredLoan_StaticPoolFlag.binned,
                                woe.MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_SP.binned,
                                woe.DFT_AVG_FEEAMOUNT_SecuredLoan_H1_H2.binned,
                                woe.DFT_AVG_NEWBALANCE_SecuredLoan_H1_H2.binned,
                                woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1_H2.binned,
                                woe.DFT_FEEAMOUNT_SecuredLoan_H1_H2.binned,
                                woe.DFT_INTEREST_AMOUNT_SecuredLoan_H1_H2.binned,
                                woe.DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_KIOSK_SecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_CHECKS_SecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_INSURANCE_SecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_HOMEBANKING_SecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_FEE_SecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_ACH_SecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_DRAFT_SecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_CASH_SecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_LOAN_PAYMENT_SecuredLoan_H1_H2.binned,
                                woe.COUNT_NEW_LOAN_SecuredLoan_H1_H2.binned,
                                woe.DFT_COUNT_LOAN_ADDON_SecuredLoan_H1_H2.binned,
                                woe.DFT_PRODUCT_CHECKING_Q1_Q2.binned,
                                woe.DFT_AVG_CHARGEOFFAMOUNT_SecuredLoan_H1_H2.binned,
                                woe.DFT_MAX_INTERESTRATE_SecuredLoan_H1_H2.binned,
                                woe.DFT_SUM_PAYMENT_SecuredLoan_H1_H2.binned,
                                woe.DFT_SUM_OriginalBalance_SecuredLoan_H1_H2.binned,
                                woe.DFT_PAYMENTCOUNT_SecuredLoan_H1_H2.binned,
                                woe.SecuredLoan_Month_to_Maturity.binned,
                                woe.SecuredLoan_MOB.binned,
                                woe.DFT_PRODUCT_CHECKING_H1_H2.binned,
                                woe.DFT_OVERDRAFTFEEYTD_SAVINGS_H1_H2.binned,
                                woe.DFT_PRODUCT_DEPOSITS_H1_H2.binned,
                                woe.DFT_PRODUCT_SAVINGS_H1_H2.binned,
                                woe.SAVINGS_StaticpoolFlag.binned,
                                RISK_TARGET))
dim(df_woe) # 992

# 6. Random Forest Feature Selection

install.packages("randomForest")
install.packages('e1071')
install.packages('caret')
install.packages('ROCR')

library(randomForest)
library(e1071)
library(caret)
library(ROCR)
set.seed(2023)

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

RF_RISK <- randomForest(RISK_TARGET ~.,data = df_woe,ntree=50)
Important_vr <- importance(RF_RISK)
write.csv(Important_vr,"Important Variables for Member Risk Model.csv")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

# # Information Value of the variables
# 
# sleep_func <- function() { Sys.sleep(5) } 
# startTime <- Sys.time()
# 
# # install.packages("Information")
# library(Information)
# IV = create_infotables(data = NAReplace_train,y="RISK_TARGET",parallel = FALSE)
# IV = data.frame(IV$Summary)
# write.csv(IV,"INFORMATION VALUE OF ORG VAR.csv")
# 
# sleep_func()
# endTime <- Sys.time()
# 
# # prints recorded time
# print(endTime - startTime)


# FEATURE SELECTION BY RANDOM FOREST :

df_RF = subset(df_woe,select = c(woe.FICO.binned,
                                 woe.COUNT_DELQ_Loan_SP.binned,
                                 woe.COUNT_DELQ_Vehicleloan_SP.binned,
                                 woe.CCWorstRatingP12Months.binned,
                                 woe.Max_DelinquencyDays_Loan_Q1.binned,
                                 woe.CCAPREstimate.binned,
                                 woe.COUNT_DELQ_Loan_Q1.binned,
                                 woe.RevolvingAccountCount.binned,
                                 woe.OpenTradeCount.binned,
                                 woe.Days.Since.Last.Login.binned,
                                 woe.NumberInquiriesP6Months.binned,
                                 woe.TopOfWalletCCCurrentBalance.binned,
                                 woe.Max_DelinquencyDays_Loan_H1.binned,
                                 woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned,
                                 woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned,
                                 woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned,
                                 woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned,
                                 woe.MAX_DFT_DUEPAYMENTDAYS_Loan_SP.binned,
                                 woe.OpenTradeBalance.binned,
                                 woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                 woe.StudentLoanOpenBalance.binned,
                                 woe.StudentLoanOpenCount.binned,
                                 woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                 woe.MAX_INTERESTRATE_VehicleLoan_Q1.binned,
                                 woe.CCCount.binned,
                                 woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned,
                                 woe.AutoLoanOrgBalanceP12Months.binned,
                                 woe.MAX_Loan_MOB.binned,
                                 woe.CCRevolvingBalance.binned,
                                 woe.CCOpenCount.binned,
                                 woe.COUNT_DELQ_Loan_H1.binned,
                                 woe.MAX_INTERESTRATE_Loan_Q1.binned,
                                 woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H1.binned,
                                 woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_SP.binned,
                                 woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned,
                                 woe.COUNT_ACH_STATICPOOL.binned,
                                 woe.DFT_INTEREST_AMOUNT_VehicleLoan_H1_H2.binned,
                                 woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_H1_H2.binned,
                                 woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2.binned,
                                 woe.DFT_COUNT_CHECKS_VehicleLoan_H1_H2.binned,
                                 woe.CREDIT_SCORE_SP.binned,
                                 woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                 woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned,
                                 woe.DFT_DEPOSITED_AMOUNT_SAVINGS_H1_H2.binned,
                                 woe.ChargeOffTradeCountP12Months.binned,
                                 woe.DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2.binned,
                                 woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                 woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_H1_H2.binned,
                                 woe.AggregatedSpendPast3Months.binned,
                                 woe.Vehicleloan_MOB.binned,
                                 woe.MAX_DFT_DUEPAYMENTDAYS_Loan_H2.binned,
                                 woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned,
                                 woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H2.binned,
                                 woe.MAX_DFT_DUEPAYMENTDAYS_Loan_Q1.binned,
                                 woe.COUNT_LOAN_ADDON_STATICPOOL.binned,
                                 woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned,
                                 woe.DFT_SUM_PAYMENT_Loan_H1_H2.binned,
                                 woe.Vehicleloan_Month_to_Maturity.binned,
                                 woe.TRANSACTION_AMOUNT_DEPOSITS_Q1.binned,
                                 woe.COUNT_DELQ_Vehicleloan_Q1.binned,
                                 woe.COUNT_DRAFT_STATICPOOL.binned,
                                 woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned,
                                 woe.ChargeOffTotalBalance.binned,
                                 woe.COUNT_LOAN_ADDON_Q1.binned,
                                 woe.MortgageOpenBalance.binned,
                                 woe.DFT_AVG_TRANSACTION_SAVINGS_Q1_Q2.binned,
                                 woe.SUM_OriginalBalance_VehicleLoan_Q1.binned,
                                 woe.MortgageOpenCount.binned,
                                 woe.TopOfWalletCCAnnualSpend.binned,
                                 woe.finalcycle1.binned,
                                 woe.COUNT_LOAN_ADDON_VehicleLoan_Q1.binned,
                                 woe.CCOpenBalance.binned,
                                 woe.Lien_flag.binned,
                                 woe.CCTotalAvailableLOC.binned,
                                 woe.DFT_AVG_NEWBALANCE_VehicleLoan_H1_H2.binned,
                                 woe.finalcycle2.binned,
                                 woe.COUNT_DRAFT_VehicleLoan_Q1.binned,
                                 woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned,
                                 woe.BankruptcyCount.binned,
                                 woe.X.loanproducts.binned,
                                 woe.originationltv.binned,
                                 woe.CL_CC_StaticPool.binned,
                                 woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned,
                                 woe.DFT_Last.Statement.Charge.Cash.Amount_CC_H1_H2.binned,
                                 woe.Last.Statement.Cash.Amount_CC_Q1.binned,
                                 woe.cpiflag.binned,
                                 
                                 woe.DFT_SUM_PAYMENT_VehicleLoan_H1_H2.binned,
                                 woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned,
                                 woe.Last.Statement.Payment.Amount_CC_Q1.binned,
                                 woe.Last.Statement.Sale.Count_CC_Q1.binned,
                                 woe.AVG_UTILIZATION_RATE_CC_Q1.binned,
                                 woe.Max_DelinquencyDays_Vehicleloan_Q1.binned,
                                 woe.COUNT_ACH_VehicleLoan_Q1.binned,
                                 woe.COUNT_DELQ_Vehicleloan_H2.binned,
                                 woe.Max_DelinquencyDays_Vehicleloan_H2.binned,
                                 woe.Diff_Due_Payment_Vehicle_Staticpool.binned,
                                 woe.Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1.binned,
                                 woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned,
                                 woe.RevolvingBalance_CC_Q1.binned,
                                 woe.DFT_FEEAMOUNT_VehicleLoan_H1_H2.binned,
                                 woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned,
                                 woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned,
                                 woe.DFT_Last.Statement.Sale.Count_CC_H1_H2.binned,
                                 woe.DFT_spend_CC_H1_H2.binned,
                                 woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_H1_H2.binned,
                                 woe.DFT_RevolvingBalance_CC_H1_H2.binned,
                                 woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_H1_H2.binned,
                                 woe.DFT_COUNT_CASH_VehicleLoan_H1_H2.binned,
                                 woe.DFT_RevolvingBalance_CC_Q1_Q2.binned,
                                 woe.DFT_Last.Statement.Cash.Advance.Count_CC_H1_H2.binned,
                                 woe.DFT_Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                 woe.DFT_Last.Statement.Charge.Sale.Amount_CC_Q1_Q2.binned,
                                 woe.DFT_Last.Statement.Cash.Amount_CC_H1_H2.binned,
                                 woe.DFT_Last.Statement.Charge.Late.Amount_CC_H1_H2.binned,
                                 RISK_TARGET))
dim(df_RF) # 115

# SPLITTING THE DATA FOR COMPUTATION SPEED

split = sample(c(TRUE,FALSE),nrow(df_RF),replace = TRUE,prob = c(0.5,0.5))
sample1 = df_RF[split,]
dim(sample1) # (64963,86)


# Stepwise Regession

# install.packages("My.stepwise")
# install.packages("carData")
# install.packages("car")
# install.packages("blorr")
library(My.stepwise)
library(carData)
library(car)
library(blorr)

# Iteration 1 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list1 = colnames(subset(sample1,select = - RISK_TARGET))
stepwise_1 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list1, data = sample1, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg1 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Loan_SP.binned + 
                 woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                 woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                 woe.COUNT_DELQ_Loan_H1.binned + woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned + 
                 woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.Days.Since.Last.Login.binned + 
                 woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                 woe.DFT_SUM_PAYMENT_Loan_H1_H2.binned + woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + 
                 woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.ChargeOffTradeCountP12Months.binned + 
                 woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + woe.COUNT_DELQ_Vehicleloan_Q1.binned + 
                 woe.SUM_OriginalBalance_VehicleLoan_Q1.binned + woe.DFT_COUNT_CHECKS_VehicleLoan_H1_H2.binned + 
                 woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + woe.MortgageOpenBalance.binned + 
                 woe.Lien_flag.binned + woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                 woe.COUNT_LOAN_ADDON_STATICPOOL.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                 woe.DFT_INTEREST_AMOUNT_VehicleLoan_H1_H2.binned + woe.COUNT_DRAFT_VehicleLoan_Q1.binned + 
                 woe.CCOpenBalance.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                 woe.MAX_Loan_MOB.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                 woe.CCCount.binned + woe.CCTotalAvailableLOC.binned, family = binomial(logit), 
               data = sample1)
a1 = Anova(log_reg1,type="II",test="Wald")
v1 = vif(log_reg1)
write.csv(a1,"ANOVA.csv")
write.csv(v1,"VIF.csv")
summary(log_reg1)

# woe.COUNT_DRAFT_VehicleLoan_Q1.binned has high p value and negative estimate.

sample2 = subset(sample1,select = -woe.COUNT_DRAFT_VehicleLoan_Q1.binned)
dim(sample2) # 85
df7 = subset(df_RF,select = -woe.COUNT_DRAFT_VehicleLoan_Q1.binned)
dim(df7) # 85


# Iteration 2 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list2 = colnames(subset(sample2,select = - RISK_TARGET))
stepwise_2 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list2, data = sample2, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg2 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                 woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                 woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                 woe.Days.Since.Last.Login.binned + woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned + 
                 woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                 woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.Lien_flag.binned + 
                 woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.CCOpenBalance.binned + 
                 woe.ChargeOffTradeCountP12Months.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                 woe.COUNT_DELQ_Vehicleloan_SP.binned + woe.SUM_OriginalBalance_VehicleLoan_Q1.binned + 
                 woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.COUNT_DELQ_Loan_Q1.binned + 
                 woe.TopOfWalletCCAnnualSpend.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                 woe.BankruptcyCount.binned + woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned + 
                 woe.Vehicleloan_MOB.binned + woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + 
                 woe.MAX_DFT_DUEPAYMENTDAYS_Loan_SP.binned, family = binomial(logit), 
               data = sample2)
a2 = Anova(log_reg2,type="II",test="Wald")
v2 = vif(log_reg2)
write.csv(a2,"ANOVA.csv")
write.csv(v2,"VIF.csv")
summary(log_reg2)

# woe.BankruptcyCount.binned has high p value and negative estimate.

sample3 = subset(sample2,select = -woe.BankruptcyCount.binned)
dim(sample3)
df8 = subset(df7,select = -woe.BankruptcyCount.binned)
dim(df8) #85

# Iteration 3 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list3 = colnames(subset(sample3,select = - RISK_TARGET))
stepwise_3 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list3, data = sample3, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg3 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                 woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                 woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                 woe.Days.Since.Last.Login.binned + woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned + 
                 woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                 woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.Lien_flag.binned + 
                 woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.CCOpenBalance.binned + 
                 woe.ChargeOffTradeCountP12Months.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                 woe.COUNT_DELQ_Vehicleloan_SP.binned + woe.SUM_OriginalBalance_VehicleLoan_Q1.binned + 
                 woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.COUNT_DELQ_Loan_Q1.binned + 
                 woe.TopOfWalletCCAnnualSpend.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                 woe.MAX_DFT_DUEPAYMENTDAYS_Loan_SP.binned + woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + 
                 woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned + 
                 woe.Vehicleloan_MOB.binned, family = binomial(logit), data = sample3)

a3 = Anova(log_reg3,type = "II",test = "Wald")
v3 = vif(log_reg3)
write.csv(a3,"ANOVA.csv")
write.csv(v3,"VIF.csv")
summary(log_reg3)

# woe.MAX_DFT_DUEPAYMENTDAYS_Loan_SP.binned has high p value and negative estimate.

sample4 = subset(sample3,select = -woe.MAX_DFT_DUEPAYMENTDAYS_Loan_SP.binned)
dim(sample4) #84
df9 = subset(df8,select = -woe.MAX_DFT_DUEPAYMENTDAYS_Loan_SP.binned)
dim(df9) #84

# Iteration 4 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list4 = colnames(subset(sample4,select = - RISK_TARGET))
stepwise_4 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list4, data = sample4, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg4 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                 woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                 woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                 woe.Days.Since.Last.Login.binned + woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned + 
                 woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                 woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.Lien_flag.binned + 
                 woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.CCOpenBalance.binned + 
                 woe.ChargeOffTradeCountP12Months.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                 woe.COUNT_DELQ_Vehicleloan_SP.binned + woe.SUM_OriginalBalance_VehicleLoan_Q1.binned + 
                 woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.COUNT_DELQ_Loan_Q1.binned + 
                 woe.TopOfWalletCCAnnualSpend.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                 woe.CREDIT_SCORE_SP.binned + woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned + 
                 woe.Vehicleloan_MOB.binned + woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned, 
               family = binomial(logit), data = sample4)
a4 = Anova(log_reg4,type="II",test="Wald")
v4 = vif(log_reg4)
write.csv(a4,"ANOVA.csv")
write.csv(v4,"VIF.csv")
summary(log_reg4)

# woe.CREDIT_SCORE_SP.binned has high p value and negative estimate.

sample5 = subset(sample4,select = -woe.CREDIT_SCORE_SP.binned)
dim(sample5) # 83
df10 = subset(df9,select = -woe.CREDIT_SCORE_SP.binned)
dim(df10) #83

# Iteration 5 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list5 = colnames(subset(sample5,select = - RISK_TARGET))
stepwise_5 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list5, data = sample5, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg5 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                 woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                 woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                 woe.Days.Since.Last.Login.binned + woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned + 
                 woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                 woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.Lien_flag.binned + 
                 woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.CCOpenBalance.binned + 
                 woe.ChargeOffTradeCountP12Months.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                 woe.COUNT_DELQ_Vehicleloan_SP.binned + woe.SUM_OriginalBalance_VehicleLoan_Q1.binned + 
                 woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.COUNT_DELQ_Loan_Q1.binned + 
                 woe.TopOfWalletCCAnnualSpend.binned + woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned + 
                 woe.Vehicleloan_MOB.binned + woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned, 
               family = binomial(logit), data = sample5)
a5 = Anova(log_reg5,type="II",test = "Wald")
v5 = vif(log_reg5)
write.csv(a5,"ANOVA.csv")
write.csv(v5,"VIF.csv")
summary(log_reg5)

# woe.Vehicleloan_MOB.binned has high p value and negative estimate

sample6 = subset(sample5,select = -woe.Vehicleloan_MOB.binned)
dim(sample6) #82
df11 = subset(df10,select = -woe.Vehicleloan_MOB.binned)
dim(df11) #82

# Iteration 6 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list6 = colnames(subset(sample6,select = - RISK_TARGET))
stepwise_6 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list6, data = sample6, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg6 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                 woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                 woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                 woe.Days.Since.Last.Login.binned + woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned + 
                 woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                 woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.Lien_flag.binned + 
                 woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.CCOpenBalance.binned + 
                 woe.ChargeOffTradeCountP12Months.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                 woe.COUNT_DELQ_Vehicleloan_SP.binned + woe.SUM_OriginalBalance_VehicleLoan_Q1.binned + 
                 woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.COUNT_DELQ_Loan_Q1.binned + 
                 woe.TopOfWalletCCAnnualSpend.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                 woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned + 
                 woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned, family = binomial(logit), 
               data = sample6)

a6 = Anova(log_reg6,type="II",test="Wald")
v6 = vif(log_reg6)
write.csv(a6,"ANOVA.csv")
write.csv(v6,"VIF.csv")
summary(log_reg6)

# woe.ChargeOffTradeCountP12Months.binned has high p value and negative estimate.

sample7 = subset(sample6,select=-woe.ChargeOffTradeCountP12Months.binned)
dim(sample7) #81
df12 = subset(df11,select = -woe.ChargeOffTradeCountP12Months.binned)
dim(df12) # 81

# Iteration 7 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list7 = colnames(subset(sample7,select = - RISK_TARGET))
stepwise_7 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list7, data = sample7, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg7 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                 woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                 woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                 woe.Days.Since.Last.Login.binned + woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned + 
                 woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                 woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.Lien_flag.binned + 
                 woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.CCOpenBalance.binned + 
                 woe.ChargeOffTotalBalance.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                 woe.COUNT_DELQ_Vehicleloan_SP.binned + woe.SUM_OriginalBalance_VehicleLoan_Q1.binned + 
                 woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.COUNT_DELQ_Loan_Q1.binned + 
                 woe.TopOfWalletCCAnnualSpend.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                 woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned + 
                 woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned, family = binomial(logit), 
               data = sample7)
a7 = Anova(log_reg7,type="II",test="Wald")
v7 = vif(log_reg7)
write.csv(a7,"ANOVA.csv")
write.csv(v7,"VIF.csv")
summary(log_reg7)

# woe.ChargeOffTotalBalance.binned has high p value and negative estimate.

sample8 = subset(sample7,select = -woe.ChargeOffTotalBalance.binned)
dim(sample8) #80

df13 = subset(df12,select = -woe.ChargeOffTotalBalance.binned)
dim(df13) # 80

# Iteration 8 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list8 = colnames(subset(sample8,select = - RISK_TARGET))
stepwise_8 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list8, data = sample8, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg8 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                 woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                 woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                 woe.Days.Since.Last.Login.binned + woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned + 
                 woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                 woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.Lien_flag.binned + 
                 woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_SUM_PAYMENT_Loan_H1_H2.binned + 
                 woe.CCOpenBalance.binned + woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + 
                 woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.COUNT_DELQ_Loan_Q1.binned + 
                 woe.COUNT_ACH_STATICPOOL.binned + woe.CCRevolvingBalance.binned + 
                 woe.TopOfWalletCCAnnualSpend.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                 woe.SUM_OriginalBalance_VehicleLoan_Q1.binned + woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned, 
               family = binomial(logit), data = sample8)
a8 = Anova(log_reg8,type="II",test="Wald")
v8 = vif(log_reg8)
write.csv(a8,"ANOVA.csv")
write.csv(v8,"VIF.csv")
summary(log_reg8)

# woe.CCOpenBalance.binned has high p value and negative estimate

sample9 = subset(sample8,select = -woe.DFT_SUM_PAYMENT_Loan_H1_H2.binned)
dim(sample9) #79
df14 =  subset(df13,select = -woe.DFT_SUM_PAYMENT_Loan_H1_H2.binned)
dim(df14) #79

# Iteration 9 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list9 = colnames(subset(sample9,select = - RISK_TARGET))
stepwise_9 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list9, data = sample9, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg9 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                 woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                 woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                 woe.Days.Since.Last.Login.binned + woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned + 
                 woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                 woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.Lien_flag.binned + 
                 woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.CCOpenBalance.binned + 
                 woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                 woe.SUM_OriginalBalance_VehicleLoan_Q1.binned + woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned + 
                 woe.TopOfWalletCCAnnualSpend.binned + woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                 woe.COUNT_DELQ_Loan_Q1.binned + woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_H1_H2.binned + 
                 woe.COUNT_ACH_STATICPOOL.binned + woe.CCRevolvingBalance.binned, 
               family = binomial(logit), data = sample9)
a9 = Anova(log_reg9,type="II",test="Wald")
v9 = vif(log_reg9)
write.csv(a9,"ANOVA.csv")
write.csv(v9,"VIF.csv")
summary(log_reg9)

# woe.CCOpenBalance.binned has high p value and negative estimate.

sample10 = subset(sample9,select = -woe.CCOpenBalance.binned)
dim(sample10) # 78
df15 = subset(df14,select = -woe.CCOpenBalance.binned)
dim(df15) #78

# Iteration 10 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list10 = colnames(subset(sample10,select = - RISK_TARGET))
stepwise_10 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list10, data = sample10, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg10 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                  woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                  woe.Days.Since.Last.Login.binned + woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.Lien_flag.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + 
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + woe.SUM_OriginalBalance_VehicleLoan_Q1.binned + 
                  woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned + 
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_H1_H2.binned + 
                  woe.COUNT_DELQ_Loan_Q1.binned + woe.COUNT_ACH_STATICPOOL.binned, 
                family = binomial(logit), data = sample10)
a10 = Anova(log_reg10,type="II",test="Wald")
v10 = vif(log_reg10)
write.csv(a10,"ANOVA.csv")
write.csv(v10,"VIF.csv")
summary(log_reg10)

# woe.SUM_OriginalBalance_VehicleLoan_Q1.binned has high p value and negative estimate

sample11 = subset(sample10,select = -woe.SUM_OriginalBalance_VehicleLoan_Q1.binned)
dim(sample11) #77
df16 = subset(df15,select = -woe.SUM_OriginalBalance_VehicleLoan_Q1.binned)
dim(df16) #77

# Iteration 11 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list11 = colnames(subset(sample11,select = - RISK_TARGET))
stepwise_11 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list11, data = sample11, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg11 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                  woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                  woe.Days.Since.Last.Login.binned + woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.Lien_flag.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + 
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_SP.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_H1_H2.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.COUNT_DELQ_Loan_Q1.binned + woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned, 
                family = binomial(logit), data = sample11)
a11 = Anova(log_reg11,type="II",test="Wald")
v11 = vif(log_reg11)
summary(log_reg11)
write.csv(a11,"ANOVA.csv")
write.csv(v11,"VIF.csv")

# woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_SP.binned has high p value and negative estimate.

sample12 = subset(sample11,select = -woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_SP.binned)
dim(sample12) #76
df17 = subset(df16,select = -woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_SP.binned)
dim(df17) #76

# Iteration 12 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list12 = colnames(subset(sample12,select = - RISK_TARGET))
stepwise_12 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list12, data = sample12, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg12 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                  woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                  woe.Days.Since.Last.Login.binned + woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.Lien_flag.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + 
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_H1_H2.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + woe.COUNT_DELQ_Loan_Q1.binned, 
                family = binomial(logit), data = sample12)
a12 = Anova(log_reg12,type="II",test="Wald")
v12 = vif(log_reg12)
write.csv(a12,"ANOVA.csv")
write.csv(v12,"VIF.csv")
summary(log_reg12)

# woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned has high p value and negative estimate.

sample13 = subset(sample12,select = -woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned)
dim(sample13) # 75
df18 = subset(df17, select=-woe.MAX_DAYSINCEDUEDATE_Loan_H2.binned)
dim(df18) #75

# Iteration 13 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list13 = colnames(subset(sample13,select = - RISK_TARGET))
stepwise_13 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list13, data = sample13, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg13 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                  woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                  woe.Days.Since.Last.Login.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.Lien_flag.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.MAX_Loan_MOB.binned + woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.COUNT_DELQ_Loan_Q1.binned + 
                  woe.CCRevolvingBalance.binned, family = binomial(logit), 
                data = sample13)

a13 = Anova(log_reg13,type="II",test="Wald")  
v13 = vif(log_reg13)
write.csv(a13,"ANOVA.csv")
write.csv(v13,"VIF.csv")
summary(log_reg13)
# woe.MAX_Loan_MOB.binned has high p value and negative estimate.

sample14 = subset(sample13,select = -woe.MAX_Loan_MOB.binned)
dim(sample14) #74
df19 = subset(df18,select = -woe.MAX_Loan_MOB.binned)
dim(df19) # 74

# Iteration 14 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list14 = colnames(subset(sample14,select = - RISK_TARGET))
stepwise_14 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list14, data = sample14, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg14 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                  woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                  woe.Days.Since.Last.Login.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.Lien_flag.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.MAX_DFT_DUEPAYMENTDAYS_Loan_H2.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + woe.NumberInquiriesP6Months.binned + 
                  woe.AutoLoanOrgBalanceP12Months.binned + woe.COUNT_DELQ_Loan_Q1.binned + 
                  woe.CCRevolvingBalance.binned, family = binomial(logit), 
                data = sample14)

a14 = Anova(log_reg14,type="II",test="Wald")
v14 = vif(log_reg14)
summary(log_reg14)
write.csv(a14,"ANOVA.csv")
write.csv(v14,"VIF.csv")

#  woe.AutoLoanOrgBalanceP12Months.binned has high p value and negative estimate.

sample15 = subset(sample14,select = -woe.AutoLoanOrgBalanceP12Months.binned)
dim(sample15) #73
df20 = subset(df19,select = -woe.AutoLoanOrgBalanceP12Months.binned)
dim(df20) # 73

# Iteration 15 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list15 = colnames(subset(sample15,select = - RISK_TARGET))
stepwise_15 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list15, data = sample15, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg15 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                  woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                  woe.Days.Since.Last.Login.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.Lien_flag.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.MAX_DFT_DUEPAYMENTDAYS_Loan_H2.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + woe.NumberInquiriesP6Months.binned + 
                  woe.COUNT_DELQ_Loan_Q1.binned + woe.CCRevolvingBalance.binned, 
                family = binomial(logit), data = sample15)
a15 = Anova(log_reg15,type="II",test ="Wald")
v15 = vif(log_reg15)
write.csv(a15,"ANOVA.csv")
write.csv(v15,"VIF.csv")
summary(log_reg15)

# woe.MAX_DFT_DUEPAYMENTDAYS_Loan_H2.binned has high p value and negative estimate.

sample16 = subset(sample15,select = -woe.MAX_DFT_DUEPAYMENTDAYS_Loan_H2.binned)
dim(sample16) # 72
df21 = subset(df20,select = -woe.MAX_DFT_DUEPAYMENTDAYS_Loan_H2.binned)
dim(df21) # 72

# Iteration 16 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list16 = colnames(subset(sample16,select = - RISK_TARGET))
stepwise_16 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list16, data = sample16, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg16 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                  woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                  woe.Days.Since.Last.Login.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.Lien_flag.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H2.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + woe.NumberInquiriesP6Months.binned + 
                  woe.COUNT_DELQ_Loan_Q1.binned + woe.CCRevolvingBalance.binned, 
                family = binomial(logit), data = sample16)


a16 = Anova(log_reg16,type = "II",test="Wald")
v16 = vif(log_reg16)
write.csv(a16,"ANOVA.csv")
write.csv(v16,"VIF.csv")
summary(log_reg16)

# woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H2.binned has high p value and negative estimate.
sample17 = subset(sample16,select = -woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H2.binned)
dim(sample17) 71
df22 = subset(df21,select = -woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H2.binned)
dim(df22) # 71

# Iteration 17

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list17 = colnames(subset(sample17,select = - RISK_TARGET))
stepwise_17 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list17, data = sample17, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg17 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned + woe.FICO.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                  woe.RevolvingAccountCount.binned + woe.CCAPREstimate.binned + 
                  woe.Days.Since.Last.Login.binned + woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.Lien_flag.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + woe.MAX_DFT_DUEPAYMENTDAYS_Loan_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.COUNT_DELQ_Loan_Q1.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + woe.CCRevolvingBalance.binned, 
                family = binomial(logit), data = sample17)
a17 = Anova(log_reg17,type="II",test="Wald")
v17 = vif(log_reg17)
write.csv(a17,"ANOVA.csv")
write.csv(v17,"VIF.csv")
summary(log_reg17)

# woe.MAX_DFT_DUEPAYMENTDAYS_Loan_Q1.binned has high p value and nwegative estimate.

sample18 = subset(sample17, select = -woe.MAX_DFT_DUEPAYMENTDAYS_Loan_Q1.binned)
dim(sample18) # 70
df23 = subset(df22,select = -woe.MAX_DFT_DUEPAYMENTDAYS_Loan_Q1.binned)
dim(df23) # 70

# Iteration 18

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list18 = colnames(subset(sample18,select = - RISK_TARGET))
stepwise_18 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list18, data = sample18, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

# MODEL CREATION ON THE WHOLE POPULATION :

# Model 1

model1 = glm(RISK_TARGET ~ woe.COUNT_DELQ_Loan_SP.binned +
               woe.FICO.binned + 
               woe.COUNT_LOAN_ADDON_Q1.binned +
               woe.CCWorstRatingP12Months.binned + 
               woe.RevolvingAccountCount.binned +
               woe.CCAPREstimate.binned + 
               woe.Days.Since.Last.Login.binned +
               woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
               woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned +
               woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
               woe.Lien_flag.binned + 
               woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
               woe.COUNT_ACH_STATICPOOL.binned + 
               woe.MAX_INTERESTRATE_Loan_Q1.binned + 
               woe.COUNT_DELQ_Vehicleloan_SP.binned + 
               woe.NumberInquiriesP6Months.binned + 
               woe.COUNT_DELQ_Loan_Q1.binned +
               woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + 
               woe.CCRevolvingBalance.binned
             , family = binomial(logit),data = df23)

am1 = Anova(model1,type="II",test="Wald")
vm1 = vif(model1)
write.csv(am1,"ANOVA.csv")
write.csv(vm1,"VIF.csv")
summary(model1)

org1 = glm(RISK_TARGET ~ COUNT_DELQ_Loan_SP + 
             FICO + 
             COUNT_LOAN_ADDON_Q1 +
             CCWorstRatingP12Months + 
             RevolvingAccountCount +
             CCAPREstimate + 
             Days.Since.Last.Login +
             DFT_AVG_TRANSACTION_DEPOSITS_H1_H2 + 
             DFT_COUNT_LOAN_ADDON_H1_H2 +
             DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
             Lien_flag + 
             Last.Statement.Cash.Advance.Count_CC_Q1 + 
             COUNT_ACH_STATICPOOL + 
             MAX_INTERESTRATE_Loan_Q1 + 
             COUNT_DELQ_Vehicleloan_SP + 
             NumberInquiriesP6Months + 
             COUNT_DELQ_Loan_Q1 +
             DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 + 
             CCRevolvingBalance
           , family = binomial(logit),data = NAReplace_train)
summary(org1)
o1 = vif(org1)
write.csv(o1,"VIF.csv")

# Model 2

model2 = glm(RISK_TARGET ~ #woe.COUNT_DELQ_Loan_SP.binned +#1
               woe.FICO.binned + 
               woe.COUNT_LOAN_ADDON_Q1.binned +
               woe.CCWorstRatingP12Months.binned + 
               woe.RevolvingAccountCount.binned +
               woe.CCAPREstimate.binned + 
               woe.Days.Since.Last.Login.binned +
               woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
               woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned +
               woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
               woe.Lien_flag.binned + 
               woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
               woe.COUNT_ACH_STATICPOOL.binned + 
               woe.MAX_INTERESTRATE_Loan_Q1.binned + 
               woe.COUNT_DELQ_Vehicleloan_SP.binned + 
               woe.NumberInquiriesP6Months.binned + 
               woe.COUNT_DELQ_Loan_Q1.binned +
               woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + 
               woe.CCRevolvingBalance.binned
             , family = binomial(logit),data = df23)

am2 = Anova(model2,type="II",test="Wald")
vm2 = vif(model2)
write.csv(am2,"ANOVA.csv")
write.csv(vm2,"VIF.csv")
summary(model2)

org2 = glm(RISK_TARGET ~ #COUNT_DELQ_Loan_SP + #1
             FICO + 
             COUNT_LOAN_ADDON_Q1 +
             CCWorstRatingP12Months + 
             RevolvingAccountCount +
             CCAPREstimate + 
             Days.Since.Last.Login +
             DFT_AVG_TRANSACTION_DEPOSITS_H1_H2 + 
             DFT_COUNT_LOAN_ADDON_H1_H2 +
             DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
             Lien_flag + 
             Last.Statement.Cash.Advance.Count_CC_Q1 + 
             COUNT_ACH_STATICPOOL + 
             MAX_INTERESTRATE_Loan_Q1 + 
             COUNT_DELQ_Vehicleloan_SP + 
             NumberInquiriesP6Months + 
             COUNT_DELQ_Loan_Q1 +
             DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 + 
             CCRevolvingBalance
           , family = binomial(logit),data = NAReplace_train)
summary(org2)
o2 = vif(org2)
write.csv(o2,"VIF.csv")


# Model 3

model3 = glm(RISK_TARGET ~ #woe.COUNT_DELQ_Loan_SP.binned +#1
               woe.FICO.binned + 
               woe.COUNT_LOAN_ADDON_Q1.binned +
               woe.CCWorstRatingP12Months.binned + 
               woe.RevolvingAccountCount.binned +
               woe.CCAPREstimate.binned + 
               woe.Days.Since.Last.Login.binned +
               woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + 
               woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned +
               woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
               woe.Lien_flag.binned + 
               woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
               woe.COUNT_ACH_STATICPOOL.binned + 
               woe.MAX_INTERESTRATE_Loan_Q1.binned + 
               woe.COUNT_DELQ_Vehicleloan_SP.binned + 
               woe.NumberInquiriesP6Months.binned + 
               # woe.COUNT_DELQ_Loan_Q1.binned + #2
               woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + 
               woe.CCRevolvingBalance.binned
             , family = binomial(logit),data = df23)

am3 = Anova(model3,type="II",test="Wald")
vm3 = vif(model3)
write.csv(am3,"ANOVA.csv")
write.csv(vm3,"VIF.csv")
summary(model3)

org3 = glm(RISK_TARGET ~ #COUNT_DELQ_Loan_SP + #1
             FICO + 
             COUNT_LOAN_ADDON_Q1 +
             CCWorstRatingP12Months + 
             RevolvingAccountCount +
             CCAPREstimate + 
             Days.Since.Last.Login +
             DFT_AVG_TRANSACTION_DEPOSITS_H1_H2 + 
             DFT_COUNT_LOAN_ADDON_H1_H2 +
             DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
             Lien_flag + 
             Last.Statement.Cash.Advance.Count_CC_Q1 + 
             COUNT_ACH_STATICPOOL + 
             MAX_INTERESTRATE_Loan_Q1 + 
             COUNT_DELQ_Vehicleloan_SP +
             NumberInquiriesP6Months + 
             # COUNT_DELQ_Loan_Q1 + #2
             DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 + 
             CCRevolvingBalance
           , family = binomial(logit),data = NAReplace_train)
summary(org3)
o3 = vif(org3)
write.csv(o3,"VIF.csv")


# Model 4

model4 = glm(RISK_TARGET ~ #woe.COUNT_DELQ_Loan_SP.binned +#1
               woe.FICO.binned + 
               woe.COUNT_LOAN_ADDON_Q1.binned +
               woe.CCWorstRatingP12Months.binned + 
               woe.RevolvingAccountCount.binned + 
               woe.CCAPREstimate.binned + 
               woe.Days.Since.Last.Login.binned +
               # woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned + #3
               woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned +
               woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
               woe.Lien_flag.binned + 
               woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
               woe.COUNT_ACH_STATICPOOL.binned + 
               woe.MAX_INTERESTRATE_Loan_Q1.binned + 
               woe.COUNT_DELQ_Vehicleloan_SP.binned + 
               woe.NumberInquiriesP6Months.binned + 
               # woe.COUNT_DELQ_Loan_Q1.binned + #2
               woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + 
               woe.CCRevolvingBalance.binned
             , family = binomial(logit),data = df23)

am4 = Anova(model4,type="II",test="Wald")
vm4 = vif(model4)
write.csv(am4,"ANOVA.csv")
write.csv(vm4,"VIF.csv")
summary(model4)

org4 = glm(RISK_TARGET ~ #COUNT_DELQ_Loan_SP + #1
             FICO +
             COUNT_LOAN_ADDON_Q1 +
             CCWorstRatingP12Months + 
             RevolvingAccountCount + 
             CCAPREstimate + 
             Days.Since.Last.Login +
             # DFT_AVG_TRANSACTION_DEPOSITS_H1_H2 + #3
             DFT_COUNT_LOAN_ADDON_H1_H2 +
             DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
             Lien_flag + 
             Last.Statement.Cash.Advance.Count_CC_Q1 + 
             COUNT_ACH_STATICPOOL + 
             MAX_INTERESTRATE_Loan_Q1 + 
             COUNT_DELQ_Vehicleloan_SP +
             NumberInquiriesP6Months + 
             # COUNT_DELQ_Loan_Q1 + #2
             DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 + 
             CCRevolvingBalance
           , family = binomial(logit),data = NAReplace_train)
summary(org4)
o4 = vif(org4)
write.csv(o4,"VIF.csv")

# Model 5

sample19 = subset(sample18,select = -c(woe.RevolvingAccountCount.binned
                                       ,woe.COUNT_DELQ_Loan_SP.binned
                                       ,woe.COUNT_DELQ_Loan_Q1.binned
                                       ,woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned))
dim(sample19) # 66
df24 = subset(df23,select = -c(woe.RevolvingAccountCount.binned
                               ,woe.COUNT_DELQ_Loan_SP.binned
                               ,woe.COUNT_DELQ_Loan_Q1.binned
                               ,woe.DFT_AVG_TRANSACTION_DEPOSITS_H1_H2.binned))
dim(df24) #66

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list19 = colnames(subset(sample19,select = - RISK_TARGET))
stepwise_19 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list19, data = sample19, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg19 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.COUNT_DELQ_Vehicleloan_Q1.binned + 
                  woe.Days.Since.Last.Login.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.Lien_flag.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + woe.NumberInquiriesP6Months.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + woe.CCRevolvingBalance.binned + 
                  woe.MortgageOpenCount.binned, family = binomial(logit), data = sample19)
a19 = Anova(log_reg19,type="II",test="Wald")
v19 = vif(log_reg19)
write.csv(a19,"ANOVA.csv")
write.csv(v19,"VIF.csv")
summary(log_reg19)

# woe.COUNT_DELQ_Vehicleloan_Q1.binned has high p value and negative estiamte.

sample20 = subset(sample19,select = -woe.COUNT_DELQ_Vehicleloan_Q1.binned)
dim(sample20) # 65
df25 = subset(df24,select = -woe.COUNT_DELQ_Vehicleloan_Q1.binned)
dim(df25) # 65

# Iteration 20

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list20 = colnames(subset(sample20,select = - RISK_TARGET))
stepwise_20 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list20, data = sample20, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg20 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.Lien_flag.binned + woe.Days.Since.Last.Login.binned + 
                  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.MAX_INTERESTRATE_VehicleLoan_Q1.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H1.binned + woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.CCRevolvingBalance.binned + 
                  woe.OpenTradeBalance.binned, family = binomial(logit), data = sample20)
a20 = Anova(log_reg20,type="II",test="Wald")
v20 = vif(log_reg20)
write.csv(a20,"ANOVA.csv")
write.csv(v20,"VIF.csv")
summary(log_reg20)

# woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H1.binned has high p value and negative estimate.

sample21 = subset(sample20,select = -woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H1.binned)
dim(sample21) # 64
df26 = subset(df25,select = -woe.MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H1.binned)
dim(df26) # 64

# Iteration 21

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list21 = colnames(subset(sample21,select = - RISK_TARGET))
stepwise_21 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list21, data = sample21, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg21 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.Lien_flag.binned + woe.Days.Since.Last.Login.binned + 
                  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.MAX_INTERESTRATE_VehicleLoan_Q1.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.CCRevolvingBalance.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + woe.MortgageOpenCount.binned + 
                  woe.Vehicleloan_Month_to_Maturity.binned + woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned, 
                family = binomial(logit), data = sample21)
a21 = Anova(log_reg21,type="II",test="Wald")
v21 = vif(log_reg21)
write.csv(a21,"ANOVA.csv")
write.csv(v21,"VIF.csv")
summary(log_reg21)

# woe.Vehicleloan_Month_to_Maturity.binned has high p value and negative estimate.

sample22 = subset(sample21,select = -woe.Vehicleloan_Month_to_Maturity.binned )
dim(sample22) #71

df27 = subset(df26,select = -woe.Vehicleloan_Month_to_Maturity.binned )
dim(df27) #63

# Iteration 22

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list22 = colnames(subset(sample22,select = - RISK_TARGET))
stepwise_22 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list22, data = sample22, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg22 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + woe.CCWorstRatingP12Months.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.Lien_flag.binned + woe.Days.Since.Last.Login.binned + 
                  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.MAX_INTERESTRATE_VehicleLoan_Q1.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.CCRevolvingBalance.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + woe.MortgageOpenCount.binned, 
                family = binomial(logit), data = sample22)
a22 = Anova(log_reg22,type="II",test="Wald")
v22 = vif(log_reg22)
write.csv(a22,"ANOVA.csv")
write.csv(v22,"VIF.csv")
summary(log_reg22)

# woe.MAX_INTERESTRATE_VehicleLoan_Q1.binned has high p value and negative estimate.

sample23 = subset(sample22,select = -woe.MAX_INTERESTRATE_VehicleLoan_Q1.binned)
dim(sample23) # 62
df28 = subset(df27,select = -woe.MAX_INTERESTRATE_VehicleLoan_Q1.binned)
dim(df28) # 62

# Iteration 23

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list23 = colnames(subset(sample23,select = - RISK_TARGET))
stepwise_23 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list23, data = sample23, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg23 = glm(RISK_TARGET ~ woe.FICO.binned + 
                  woe.COUNT_DELQ_Vehicleloan_SP.binned +
                  woe.COUNT_LOAN_ADDON_Q1.binned +
                  woe.CCWorstRatingP12Months.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned +
                  woe.CCAPREstimate.binned +
                  woe.CCCount.binned +
                  woe.Lien_flag.binned + 
                  woe.Days.Since.Last.Login.binned +
                  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned +
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned +
                  woe.NumberInquiriesP6Months.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned +
                  woe.CCRevolvingBalance.binned +
                  woe.OpenTradeBalance.binned
                , family = binomial(logit), data = df28)
a23 = Anova(log_reg23,type="II",test = "Wald")
v23 = vif(log_reg23)
write.csv(a23,"ANOVA.csv")
write.csv(v23,"VIF.csv")
summary(log_reg23)


org_reg23 = glm(RISK_TARGET ~ FICO + 
                  COUNT_DELQ_Vehicleloan_SP +
                  COUNT_LOAN_ADDON_Q1 +
                  CCWorstRatingP12Months +
                  Max_DelinquencyDays_Loan_Q1 +
                  CCAPREstimate +
                  CCCount +
                  Lien_flag + 
                  Days.Since.Last.Login +
                  Last.Statement.Cash.Advance.Count_CC_Q1 + 
                  MAX_INTERESTRATE_Loan_Q1 + 
                  DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 +
                  DFT_COUNT_LOAN_ADDON_H1_H2 + 
                  COUNT_ACH_STATICPOOL + 
                  NumberInquiriesP6Months# + 
                DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 +
                  CCRevolvingBalance +
                  OpenTradeBalance
                , family = binomial(logit), data = NAReplace_train)
summary(org_reg23)
vif(org_reg23)

blr_gains_table(log_reg23,data = df28)

sample24 = subset(sample23,select = - woe.Days.Since.Last.Login.binned)
dim(sample24) # 61
df29 = subset(df28,select = -woe.Days.Since.Last.Login.binned)
dim(df29) # 61

# Iteration 24 : Stepwise on Whole Data

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list24 = colnames(subset(df29,select = - RISK_TARGET))
stepwise_24 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list24, data = df29, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg24 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.OpenTradeBalance.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_H1_H2.binned + woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.COUNT_LOAN_ADDON_STATICPOOL.binned + woe.CCRevolvingBalance.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.DFT_INTEREST_AMOUNT_VehicleLoan_H1_H2.binned + 
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.COUNT_DRAFT_STATICPOOL.binned + woe.COUNT_DELQ_Loan_H1.binned + 
                  woe.CCTotalAvailableLOC.binned + woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + 
                  woe.StudentLoanOpenBalance.binned, family = binomial(logit), 
                data = df29)
a24 = Anova(log_reg24,type="II",test="Wald")
v24 = vif(log_reg24)
write.csv(a24,"ANOVA.csv")
write.csv(v24,"VIF.csv")
summary(log_reg24)


# woe.StudentLoanOpenBalance.binned has high p value and negative estimate.
df30 = subset(df29,select = -woe.StudentLoanOpenBalance.binned)
dim(df30)  #60

# Iteration 25 

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list25 = colnames(subset(df30,select = - RISK_TARGET))
stepwise_25 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list25, data = df30, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg25 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.OpenTradeBalance.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_H1_H2.binned + woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.COUNT_LOAN_ADDON_STATICPOOL.binned + woe.CCRevolvingBalance.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.DFT_INTEREST_AMOUNT_VehicleLoan_H1_H2.binned + 
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.COUNT_DRAFT_STATICPOOL.binned + woe.COUNT_DELQ_Loan_H1.binned + 
                  woe.CCTotalAvailableLOC.binned + woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + 
                  woe.MortgageOpenCount.binned, family = binomial(logit), data = df30)
a25 = Anova(log_reg25,type="II",test="Wald")
v25 = vif(log_reg25)
write.csv(a25,"ANOVA.csv")
write.csv(v25,"VIF.csv")
summary(log_reg25)

# woe.CCTotalAvailableLOC.binned has negative estimate
df31 = subset(df30,select = -woe.CCTotalAvailableLOC.binned)
dim(df31) # 59

# Iteration 26 

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list26 = colnames(subset(df31,select = - RISK_TARGET))
stepwise_26 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list26, data = df31, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg26 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.OpenTradeBalance.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_H1_H2.binned + woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.COUNT_LOAN_ADDON_STATICPOOL.binned + woe.CCRevolvingBalance.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.DFT_INTEREST_AMOUNT_VehicleLoan_H1_H2.binned + 
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.COUNT_DRAFT_STATICPOOL.binned + woe.COUNT_DELQ_Loan_H1.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned, family = binomial(logit), 
                data = df31)
a26 = Anova(log_reg26,type="II",test="Wald")
v26 = vif(log_reg26)
write.csv(a26,"ANOVA.csv")
write.csv(v26,"VIF.csv")
summary(log_reg26)

# woe.COUNT_DRAFT_STATICPOOL.binned has high p value and negative estimate.

df32 = subset(df31,select = -woe.COUNT_DRAFT_STATICPOOL.binned)
dim(df32) # 58

# Iteration 27 

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list27 = colnames(subset(df32,select = - RISK_TARGET))
stepwise_27 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list27, data = df32, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg27 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.OpenTradeBalance.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_H1_H2.binned + woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.COUNT_LOAN_ADDON_STATICPOOL.binned + woe.CCRevolvingBalance.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.DFT_INTEREST_AMOUNT_VehicleLoan_H1_H2.binned + 
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.COUNT_DELQ_Loan_H1.binned + woe.DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2.binned, 
                family = binomial(logit), data = df32)
a27 = Anova(log_reg27,type="II",test= "Wald")
v27 = vif(log_reg27)
write.csv(a27,"ANOVA.csv")
write.csv(v27,"VIF.csv")
summary(log_reg27)

#  woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_H1_H2.binned has high p value and negative estimate.

df33 = subset(df32,select = -woe.DFT_COUNT_LOAN_ADDON_VehicleLoan_H1_H2.binned)
dim(df33) #57

# Iteration 28

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list28 = colnames(subset(df33,select = - RISK_TARGET))
stepwise_28 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list28, data = df33, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg28 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.OpenTradeBalance.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.COUNT_LOAN_ADDON_STATICPOOL.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.CCRevolvingBalance.binned + 
                  woe.COUNT_DELQ_Loan_H1.binned + woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_H1_H2.binned + woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + woe.DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2.binned, 
                family = binomial(logit), data = df33)

a28 = Anova(log_reg28,type="II",test="Wald")
v28 = vif(log_reg28)
write.csv(a28,"ANOVA.csv")
write.csv(v28,"VIF.csv")
summary(log_reg28)

# woe.DFT_INTEREST_AMOUNT_VehicleLoan_H1_H2.binned has high p value and negative estimate.

df34 = subset(df33,select = -woe.DFT_INTEREST_AMOUNT_VehicleLoan_H1_H2.binned)
dim(df34) # 56

# Iteration 29

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list29 = colnames(subset(df34,select = - RISK_TARGET))
stepwise_29 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list29, data = df34, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg29 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.OpenTradeBalance.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.COUNT_LOAN_ADDON_STATICPOOL.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.CCRevolvingBalance.binned + 
                  woe.COUNT_DELQ_Loan_H1.binned + woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2.binned + woe.finalcycle1.binned, 
                family = binomial(logit), data = df34)
a29 = Anova(log_reg29,type="II",test="Wald")
v29 = vif(log_reg29)
write.csv(a29,"ANOVA.csv")
write.csv(v29,"VIF.csv")
summary(log_reg29)

# woe.finalcycle1.binned has high p value and negative estimate.
df35 = subset(df34,select = -woe.finalcycle1.binned)
dim(df35) # 55

# Iteration 30

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list30 = colnames(subset(df35,select = - RISK_TARGET))
stepwise_30 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list30, data = df35, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg30 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.OpenTradeBalance.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.COUNT_LOAN_ADDON_STATICPOOL.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.CCRevolvingBalance.binned + 
                  woe.COUNT_DELQ_Loan_H1.binned + woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2.binned, family = binomial(logit), 
                data = df35)
a30 = Anova(log_reg30,type="II",test="Wald")  
v30 = vif(log_reg30)
write.csv(a30,"ANOVA.csv")
write.csv(v30,"VIF.csv")
summary(log_reg30)

# woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned has high p value and negative estimate.

df36 = subset(df35,select = -woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned)
dim(df36) # 54

# Iteration 31

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list31 = colnames(subset(df36,select = - RISK_TARGET))
stepwise_31 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list31, data = df36, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg31 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.OpenTradeBalance.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.COUNT_LOAN_ADDON_STATICPOOL.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.CCRevolvingBalance.binned + 
                  woe.COUNT_DELQ_Loan_H1.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.DFT_COUNT_CHECKS_VehicleLoan_H1_H2.binned + 
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + woe.DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2.binned, 
                family = binomial(logit), data = df36)
a31 = Anova(log_reg31,type="II",test = "Wald")
v31 = vif(log_reg31)
summary(log_reg31)
write.csv(a31,"ANOVA.csv")
write.csv(v31,"VIF.csv")

# woe.DFT_COUNT_CHECKS_VehicleLoan_H1_H2.binned has high p value and negative estimates.
df37 = subset(df36,select = -woe.DFT_COUNT_CHECKS_VehicleLoan_H1_H2.binned)
dim(df37) # 53

# Iteration 32

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list32 = colnames(subset(df37,select = - RISK_TARGET))
stepwise_32 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list32, data = df37, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg32 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.OpenTradeBalance.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.COUNT_LOAN_ADDON_STATICPOOL.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.CCRevolvingBalance.binned + 
                  woe.COUNT_DELQ_Loan_H1.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned + 
                  woe.DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2.binned, family = binomial(logit), 
                data = df37)
a32 = Anova(log_reg32,type="II",test="Wald")
v32 = vif(log_reg32)
write.csv(a32,"ANOVA.csv")
write.csv(v32,"VIF.csv")
summary(log_reg32)

# woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned has high p value and negative estimate.
df38 = subset(df37,select = -woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2.binned)
dim(df38) # 52

# Iteration 33

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list33 = colnames(subset(df38,select = - RISK_TARGET))
stepwise_33 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list33, data = df38, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg33 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.OpenTradeBalance.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.COUNT_LOAN_ADDON_STATICPOOL.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.CCRevolvingBalance.binned + 
                  woe.COUNT_DELQ_Loan_H1.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.DFT_AVG_NEWBALANCE_VehicleLoan_H1_H2.binned + 
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned, family = binomial(logit), 
                data = df38)
a33 = Anova(log_reg33,type="II",test="Wald")
v33 = vif(log_reg33)
write.csv(a33,"ANOVA.csv")
write.csv(v33,"VIF.csv")
summary(log_reg33)

# woe.DFT_AVG_NEWBALANCE_VehicleLoan_H1_H2.binned has high p value and negative estimate.
df39 = subset(df38,select= -woe.DFT_AVG_NEWBALANCE_VehicleLoan_H1_H2.binned)

# Iteration 34

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list34 = colnames(subset(df39,select = - RISK_TARGET))
stepwise_34 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list34, data = df39, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg34 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned + woe.CCAPREstimate.binned + 
                  woe.CCCount.binned + woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.OpenTradeBalance.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.COUNT_LOAN_ADDON_STATICPOOL.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.CCRevolvingBalance.binned + 
                  woe.COUNT_DELQ_Loan_H1.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2.binned, 
                family = binomial(logit), data = df39)
a34 = Anova(log_reg34,type="II",test="Wald")
v34 = vif(log_reg34)
write.csv(a34,"ANOVA.csv")
write.csv(v34,"VIF.csv")
summary(log_reg34)

# woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2.binned has negative estimate
df40 = subset(df39,select=-woe.DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2.binned)
dim(df40) # 50

# Iteration 34

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list35 = colnames(subset(df40,select = - RISK_TARGET))
stepwise_35 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list35, data = df40, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg34 = glm(formula = RISK_TARGET ~ woe.FICO.binned +
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned +
                  woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned +
                  woe.CCAPREstimate.binned + 
                  woe.CCCount.binned +
                  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.OpenTradeBalance.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.COUNT_LOAN_ADDON_STATICPOOL.binned +
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  woe.CCRevolvingBalance.binned + 
                  woe.COUNT_DELQ_Loan_H1.binned +
                  woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned
                , family = binomial(logit),data = df40)
a34 = Anova(log_reg34,type="II",test="Wald")
v34 = vif(log_reg34)
write.csv(a34,"ANOVA.csv")
write.csv(v34,"VIF.csv")
summary(log_reg34)

org34 = glm(formula = RISK_TARGET ~ FICO +
              COUNT_DELQ_Vehicleloan_SP + 
              Max_DelinquencyDays_Loan_Q1 +
              COUNT_LOAN_ADDON_Q1 + 
              CCWorstRatingP12Months +
              CCAPREstimate + 
              CCCount +
              Last.Statement.Cash.Advance.Count_CC_Q1 + 
              Lien_flag + 
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
              OpenTradeBalance + 
              MAX_INTERESTRATE_Loan_Q1 + 
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
              COUNT_LOAN_ADDON_STATICPOOL +
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1 + 
              NumberInquiriesP6Months +
              CCRevolvingBalance + 
              COUNT_DELQ_Loan_H1 +
              COUNT_ACH_STATICPOOL + 
              DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2
            , family = binomial(logit),data = NAReplace_train)
summary(org34)
o34 = vif(org34)
write.csv(o34,"VIF.csv")

# woe.COUNT_LOAN_ADDON_STATICPOOL.binned has high vif.

# Iteration 35

log_reg35 = glm(formula = RISK_TARGET ~ woe.FICO.binned +
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned +
                  woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned +
                  woe.CCAPREstimate.binned + 
                  woe.CCCount.binned +
                  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.OpenTradeBalance.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  # woe.COUNT_LOAN_ADDON_STATICPOOL.binned +
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  woe.CCRevolvingBalance.binned + 
                  woe.COUNT_DELQ_Loan_H1.binned +
                  woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned
                , family = binomial(logit),data = df40)
a35 = Anova(log_reg35,type="II",test="Wald")
v35 = vif(log_reg35)
write.csv(a35,"ANOVA.csv")
write.csv(v35,"VIF.csv")
summary(log_reg35)

org35 = glm(formula = RISK_TARGET ~ FICO +
              COUNT_DELQ_Vehicleloan_SP + 
              Max_DelinquencyDays_Loan_Q1 +
              COUNT_LOAN_ADDON_Q1 + 
              CCWorstRatingP12Months +
              CCAPREstimate + 
              CCCount +
              Last.Statement.Cash.Advance.Count_CC_Q1 + 
              Lien_flag + 
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
              OpenTradeBalance + 
              MAX_INTERESTRATE_Loan_Q1 + 
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
              # COUNT_LOAN_ADDON_STATICPOOL +
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1 + 
              NumberInquiriesP6Months +
              CCRevolvingBalance + 
              COUNT_DELQ_Loan_H1 +
              COUNT_ACH_STATICPOOL + 
              DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2
            , family = binomial(logit),data = NAReplace_train)
summary(org35)
o35 = vif(org35)
write.csv(o35,"VIF.csv")

# woe.COUNT_DELQ_Loan_H1.binned has high vif of org vars.


# Iteration 36

log_reg36 = glm(formula = RISK_TARGET ~ woe.FICO.binned +
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned +
                  woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned +
                  woe.CCAPREstimate.binned + 
                  woe.CCCount.binned +
                  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.OpenTradeBalance.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  # woe.COUNT_LOAN_ADDON_STATICPOOL.binned +
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  woe.CCRevolvingBalance.binned + 
                  # woe.COUNT_DELQ_Loan_H1.binned +
                  woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned
                , family = binomial(logit),data = df40)
a36 = Anova(log_reg36,type="II",test="Wald")
v36 = vif(log_reg36)
write.csv(a36,"ANOVA.csv")
write.csv(v36,"VIF.csv")
summary(log_reg36)

org36 = glm(formula = RISK_TARGET ~ FICO +
              COUNT_DELQ_Vehicleloan_SP + 
              Max_DelinquencyDays_Loan_Q1 +
              COUNT_LOAN_ADDON_Q1 + 
              CCWorstRatingP12Months +
              CCAPREstimate + 
              CCCount +
              Last.Statement.Cash.Advance.Count_CC_Q1 + 
              Lien_flag + 
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
              OpenTradeBalance + 
              MAX_INTERESTRATE_Loan_Q1 + 
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
              # COUNT_LOAN_ADDON_STATICPOOL +
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1 + 
              NumberInquiriesP6Months +
              CCRevolvingBalance + 
              # COUNT_DELQ_Loan_H1 +
              COUNT_ACH_STATICPOOL + 
              DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2
            , family = binomial(logit),data = NAReplace_train)
summary(org36)
o36 = vif(org36)
write.csv(o36,"VIF.csv")

# woe.CCCount.binned has high vif.

# Iteration 37

log_reg37 = glm(formula = RISK_TARGET ~ woe.FICO.binned +
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_Q1.binned +
                  woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned +
                  woe.CCAPREstimate.binned + 
                  woe.CCCount.binned +
                  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  # woe.OpenTradeBalance.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  # woe.COUNT_LOAN_ADDON_STATICPOOL.binned +
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  woe.CCRevolvingBalance.binned + 
                  # woe.COUNT_DELQ_Loan_H1.binned +
                  woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned
                , family = binomial(logit),data = df40)
a37 = Anova(log_reg37,type="II",test="Wald")
v37 = vif(log_reg37)
write.csv(a37,"ANOVA.csv")
write.csv(v37,"VIF.csv")
summary(log_reg37)

org37 = glm(formula = RISK_TARGET ~ FICO +
              COUNT_DELQ_Vehicleloan_SP + 
              Max_DelinquencyDays_Loan_Q1 +
              COUNT_LOAN_ADDON_Q1 + 
              CCWorstRatingP12Months +
              CCAPREstimate + 
              CCCount +
              Last.Statement.Cash.Advance.Count_CC_Q1 + 
              Lien_flag + 
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
              # OpenTradeBalance + 
              MAX_INTERESTRATE_Loan_Q1 + 
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
              # COUNT_LOAN_ADDON_STATICPOOL +
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1 + 
              NumberInquiriesP6Months +
              CCRevolvingBalance + 
              # COUNT_DELQ_Loan_H1 +
              COUNT_ACH_STATICPOOL + 
              DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2
            , family = binomial(logit),data = NAReplace_train)
summary(org37)
o37 = vif(org37)
write.csv(o37,"VIF.csv")

# woe.Max_DelinquencyDays_Loan_Q1.binned has high vif.


# Iteration 38

log_reg38 = glm(formula = RISK_TARGET ~ woe.FICO.binned +
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  # woe.Max_DelinquencyDays_Loan_Q1.binned +
                  woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned +
                  woe.CCAPREstimate.binned + 
                  woe.CCCount.binned +
                  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  # woe.OpenTradeBalance.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  # woe.COUNT_LOAN_ADDON_STATICPOOL.binned +
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  woe.CCRevolvingBalance.binned + 
                  # woe.COUNT_DELQ_Loan_H1.binned +
                  woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned
                , family = binomial(logit),data = df40)
a38 = Anova(log_reg38,type="II",test="Wald")
v38 = vif(log_reg38)
write.csv(a38,"ANOVA.csv")
write.csv(v38,"VIF.csv")
summary(log_reg38)

org38 = glm(formula = RISK_TARGET ~ FICO +
              COUNT_DELQ_Vehicleloan_SP + 
              # Max_DelinquencyDays_Loan_Q1 +
              COUNT_LOAN_ADDON_Q1 + 
              CCWorstRatingP12Months +
              CCAPREstimate + 
              CCCount +
              Last.Statement.Cash.Advance.Count_CC_Q1 + 
              Lien_flag + 
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
              # OpenTradeBalance + 
              MAX_INTERESTRATE_Loan_Q1 + 
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
              # COUNT_LOAN_ADDON_STATICPOOL +
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1 + 
              NumberInquiriesP6Months +
              CCRevolvingBalance + 
              # COUNT_DELQ_Loan_H1 +
              COUNT_ACH_STATICPOOL + 
              DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2
            , family = binomial(logit),data = NAReplace_train)
summary(org38)
o38 = vif(org38)
write.csv(o38,"VIF.csv")

df41 = subset(df40,select=-c(woe.Max_DelinquencyDays_Loan_Q1.binned,
                             woe.COUNT_DELQ_Loan_H1.binned,
                             woe.COUNT_LOAN_ADDON_STATICPOOL.binned,
                             woe.OpenTradeBalance.binned))
dim(df41) # 45

# Iteration 39

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list39 = colnames(subset(df41,select = - RISK_TARGET))
stepwise_39 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list39, data = df41, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg39 = glm(formula = RISK_TARGET ~ woe.FICO.binned +
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_H1.binned +
                  woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned + 
                  woe.CCAPREstimate.binned + 
                  woe.OpenTradeCount.binned +
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.Lien_flag.binned +
                  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.CCRevolvingBalance.binned +
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned +
                  woe.MortgageOpenCount.binned, 
                family = binomial(logit), data = df41)

a39 = Anova(log_reg39,type="II",test="Wald")
v39 = vif(log_reg39)
write.csv(a39,"ANOVA.csv")
write.csv(v39,"VIF.csv")
summary(log_reg39)

org39 = glm(formula = RISK_TARGET ~ FICO +
              COUNT_DELQ_Vehicleloan_SP + 
              Max_DelinquencyDays_Loan_H1 +
              COUNT_LOAN_ADDON_Q1 + 
              CCWorstRatingP12Months + 
              CCAPREstimate + 
              OpenTradeCount +
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              Lien_flag +
              Last.Statement.Cash.Advance.Count_CC_Q1 + 
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
              MAX_INTERESTRATE_Loan_Q1 + 
              NumberInquiriesP6Months +
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1 + 
              CCRevolvingBalance +
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
              COUNT_ACH_STATICPOOL +
              MortgageOpenCount, 
            family = binomial(logit), data = NAReplace_train)
summary(org39)
o39 = vif(org39)
write.csv(o39,"VIF.csv")


# Iteration 40

log_reg40 = glm(formula = RISK_TARGET ~ woe.FICO.binned +
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  # woe.Max_DelinquencyDays_Loan_Q1.binned +
                  woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.CCWorstRatingP12Months.binned +
                  woe.CCAPREstimate.binned + 
                  woe.CCCount.binned +
                  woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + 
                  woe.Lien_flag.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  # woe.OpenTradeBalance.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  # woe.COUNT_LOAN_ADDON_STATICPOOL.binned +
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  woe.CCRevolvingBalance.binned + 
                  # woe.COUNT_DELQ_Loan_H1.binned +
                  woe.COUNT_ACH_STATICPOOL.binned #+ 
                # woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned
                , family = binomial(logit),data = df_woe)
a40 = Anova(log_reg40,type="II",test="Wald")
v40 = vif(log_reg40)
write.csv(a40,"ANOVA.csv")
write.csv(v40,"VIF.csv")
summary(log_reg40)

org40 = glm(formula = RISK_TARGET ~ FICO +
              COUNT_DELQ_Vehicleloan_SP + 
              # Max_DelinquencyDays_Loan_Q1 +
              COUNT_LOAN_ADDON_Q1 + 
              CCWorstRatingP12Months +
              CCAPREstimate + 
              CCCount +
              Last.Statement.Cash.Advance.Count_CC_Q1 + 
              Lien_flag + 
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
              # OpenTradeBalance + 
              MAX_INTERESTRATE_Loan_Q1 + 
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
              # COUNT_LOAN_ADDON_STATICPOOL +
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1 + 
              NumberInquiriesP6Months +
              CCRevolvingBalance + 
              # COUNT_DELQ_Loan_H1 +
              COUNT_ACH_STATICPOOL# + 
            # DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2
            , family = binomial(logit),data = NAReplace_train)
summary(org40)
o40 = vif(org40)
write.csv(o40,"VIF.csv")
blr_gains_table(log_reg40,data=df_woe)

df_test = subset(RISK_test,select = c(  RISK_TARGET,
                                        FICO ,
                                        COUNT_DELQ_Vehicleloan_SP , 
                                        COUNT_LOAN_ADDON_Q1 , 
                                        CCWorstRatingP12Months ,
                                        CCAPREstimate , 
                                        CCCount ,
                                        Last.Statement.Cash.Advance.Count_CC_Q1 , 
                                        Lien_flag , 
                                        DFT_COUNT_LOAN_ADDON_H1_H2 , 
                                        DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 , 
                                        MAX_INTERESTRATE_Loan_Q1 , 
                                        DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 ,
                                        WITHDRAWAL_AMOUNT_DEPOSITS_Q1 , 
                                        NumberInquiriesP6Months ,
                                        CCRevolvingBalance ,
                                        COUNT_ACH_STATICPOOL))



NAReplace_test <- replace(df_test,is.na(df_test),-9999999)
sum(is.na(NAReplace_test)) 

RISK_test_model <- woe.binning(NAReplace_test,'RISK_TARGET',NAReplace_test)
test_woe <- woe.binning.deploy(NAReplace_test,RISK_test_model,add.woe.or.dum.var = "woe")

blr_gains_table(log_reg40,test_woe)


# Iteration 41

log_reg41 = glm(RISK_TARGET ~ woe.FICO.binned +
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  # woe.Max_DelinquencyDays_Loan_Q1.binned +
                  # woe.COUNT_LOAN_ADDON_Q1.binned + #7
                  woe.CCWorstRatingP12Months.binned +
                  woe.CCAPREstimate.binned + 
                  # woe.CCCount.binned + #1
                  # woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned + #6
                  # woe.Lien_flag.binned + #8
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  # woe.OpenTradeBalance.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  # woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + #4
                  # woe.COUNT_LOAN_ADDON_STATICPOOL.binned +
                  # woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + #5
                  woe.NumberInquiriesP6Months.binned# +
                # woe.CCRevolvingBalance.binned + #2
                # woe.COUNT_DELQ_Loan_H1.binned +
                # woe.COUNT_ACH_STATICPOOL.binned #+ #3
                # woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned
                , family = binomial(logit),data = df_woe)
a41 = Anova(log_reg41,type="II",test="Wald")
v41 = vif(log_reg41)
write.csv(a41,"ANOVA.csv")
write.csv(v41,"VIF.csv")
summary(log_reg41)

org41 = glm(formula = RISK_TARGET ~ FICO +
              COUNT_DELQ_Vehicleloan_SP + 
              # Max_DelinquencyDays_Loan_Q1 +
              # COUNT_LOAN_ADDON_Q1 + #7
              CCWorstRatingP12Months +
              CCAPREstimate + 
              # CCCount + #1
              # Last.Statement.Cash.Advance.Count_CC_Q1 +  #6
              # Lien_flag + 
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
              # OpenTradeBalance + 
              MAX_INTERESTRATE_Loan_Q1 + 
              # DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + #4
              # COUNT_LOAN_ADDON_STATICPOOL +
              # WITHDRAWAL_AMOUNT_DEPOSITS_Q1 #+ #5
              NumberInquiriesP6Months #+ 
            # CCRevolvingBalance + #2
            # COUNT_DELQ_Loan_H1 +
            # COUNT_ACH_STATICPOOL# + #3
            # DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2
            , family = binomial(logit),data = NAReplace_train)
summary(org41)
o41 = vif(org41)
write.csv(o41,"VIF.csv")
blr_gains_table(log_reg41,data=df_woe)
blr_gains_table(log_reg41,data=test_woe)

df42 = subset(df41,select =-c( woe.CCWorstRatingP12Months.binned ,
                               woe.CCAPREstimate.binned ,
                               woe.CCCount.binned ))
dim(df42)


df42 = subset(df_woe,select = c(woe.FICO.binned,
                                woe.COUNT_DELQ_Vehicleloan_SP.binned,
                                woe.OpenTradeCount.binned,
                                woe.NumberInquiriesP6Months.binned,
                                woe.TopOfWalletCCCurrentBalance.binned,
                                woe.Max_DelinquencyDays_Loan_H1.binned,
                                woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned,
                                woe.DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                woe.StudentLoanOpenCount.binned,
                                woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned,
                                woe.CCRevolvingBalance.binned,
                                woe.CCOpenCount.binned,
                                woe.MAX_INTERESTRATE_Loan_Q1.binned,
                                woe.COUNT_ACH_STATICPOOL.binned,
                                woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2.binned,
                                woe.DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3.binned,
                                woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned,
                                woe.DFT_DEPOSITED_AMOUNT_SAVINGS_H1_H2.binned,
                                woe.DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2.binned,
                                woe.DFT_WITHDRAWAL_AMOUNT_DEPOSITS_H1_H2.binned,
                                woe.AggregatedSpendPast3Months.binned,
                                woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned,
                                woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned,
                                woe.TRANSACTION_AMOUNT_DEPOSITS_Q1.binned,
                                woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned,
                                woe.COUNT_LOAN_ADDON_Q1.binned,
                                woe.MortgageOpenBalance.binned,
                                woe.DFT_AVG_TRANSACTION_SAVINGS_Q1_Q2.binned,
                                woe.MortgageOpenCount.binned,
                                woe.TopOfWalletCCAnnualSpend.binned,
                                woe.COUNT_LOAN_ADDON_VehicleLoan_Q1.binned,
                                woe.Lien_flag.binned,
                                woe.finalcycle2.binned,
                                woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned,
                                woe.X.loanproducts.binned,
                                woe.originationltv.binned,
                                woe.CL_CC_StaticPool.binned,
                                woe.Last.Statement.Cash.Advance.Count_CC_Q1.binned,
                                woe.DFT_Last.Statement.Charge.Cash.Amount_CC_H1_H2.binned,
                                woe.Last.Statement.Cash.Amount_CC_Q1.binned,
                                woe.cpiflag.binned,
                                woe.DFT_SUM_PAYMENT_VehicleLoan_H1_H2.binned,
                                woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned,
                                woe.Last.Statement.Payment.Amount_CC_Q1.binned,
                                woe.Last.Statement.Sale.Count_CC_Q1.binned,
                                woe.AVG_UTILIZATION_RATE_CC_Q1.binned,
                                woe.Max_DelinquencyDays_Vehicleloan_Q1.binned,
                                woe.COUNT_ACH_VehicleLoan_Q1.binned,
                                woe.COUNT_DELQ_Vehicleloan_H2.binned,
                                woe.Max_DelinquencyDays_Vehicleloan_H2.binned,
                                woe.Diff_Due_Payment_Vehicle_Staticpool.binned,
                                woe.Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1.binned,
                                woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned,
                                woe.RevolvingBalance_CC_Q1.binned,
                                woe.DFT_FEEAMOUNT_VehicleLoan_H1_H2.binned,
                                woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Sale.Count_CC_H1_H2.binned,
                                woe.DFT_spend_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_H1_H2.binned,
                                woe.DFT_RevolvingBalance_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_H1_H2.binned,
                                woe.DFT_COUNT_CASH_VehicleLoan_H1_H2.binned,
                                woe.DFT_RevolvingBalance_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Cash.Advance.Count_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Cash.Average.Daily.Balance.Amount_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Charge.Sale.Amount_CC_Q1_Q2.binned,
                                woe.DFT_Last.Statement.Cash.Amount_CC_H1_H2.binned,
                                woe.DFT_Last.Statement.Charge.Late.Amount_CC_H1_H2.binned,
                                RISK_TARGET))

dim(df42) # 71

# Iteration 42

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list42 = colnames(subset(df42,select = - RISK_TARGET))
stepwise_42 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list42, data = df42, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg42 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_H1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned + 
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + woe.OpenTradeCount.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.COUNT_DELQ_Vehicleloan_H2.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_H1_H2.binned + 
                  woe.Lien_flag.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.Last.Statement.Payment.Amount_CC_Q1.binned + woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.Max_DelinquencyDays_Vehicleloan_Q1.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned + 
                  woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_H1_H2.binned + 
                  woe.DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2.binned + woe.MortgageOpenCount.binned + 
                  woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + woe.RevolvingBalance_CC_Q1.binned, 
                family = binomial(logit), data = df42)
a42 = Anova(log_reg42,type="II",test="Wald")
v42 = vif(log_reg42)
write.csv(a42,"ANOVA.csv")
write.csv(v42,"VIF.csv")
summary(log_reg42)

# woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_H1_H2.binned has high p value and negative estimate.
df43 = subset(df42,select=-woe.DFT_Last.Statement.Average.Daily.Balance.Amount_CC_H1_H2.binned)
dim(df43) # 70

# Iteration 43

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list43 = colnames(subset(df43,select = - RISK_TARGET))
stepwise_43 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list43, data = df43, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg43 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_H1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned + 
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + woe.OpenTradeCount.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.COUNT_DELQ_Vehicleloan_H2.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_H1_H2.binned + 
                  woe.Lien_flag.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.Last.Statement.Payment.Amount_CC_Q1.binned + woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.Max_DelinquencyDays_Vehicleloan_Q1.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned + 
                  woe.DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2.binned + woe.MortgageOpenCount.binned + 
                  woe.DFT_RevolvingBalance_CC_H1_H2.binned + woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2.binned + 
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.RevolvingBalance_CC_Q1.binned, family = binomial(logit), 
                data = df43)
a43 = Anova(log_reg43,type="II",test = "Wald")
v43 = vif(log_reg43)
write.csv(a43,"ANOVA.csv")
write.csv(v43,"VIF.csv")
summary(log_reg43)

# woe.DFT_RevolvingBalance_CC_H1_H2.binned has high p value and negative estimate.

df44 = subset(df43,select = -woe.DFT_RevolvingBalance_CC_H1_H2.binned)
dim(df44) #69

# Iteration 44

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list44 = colnames(subset(df44,select = - RISK_TARGET))
stepwise_44 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list44, data = df44, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg44 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_H1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned + 
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + woe.OpenTradeCount.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.COUNT_DELQ_Vehicleloan_H2.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_H1_H2.binned + 
                  woe.Lien_flag.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.Last.Statement.Payment.Amount_CC_Q1.binned + woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.Max_DelinquencyDays_Vehicleloan_Q1.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned + 
                  woe.DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2.binned + woe.MortgageOpenCount.binned + 
                  woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned, family = binomial(logit), 
                data = df44)
a44 = Anova(log_reg44,type="II",test="Wald")
v44 = vif(log_reg44)
write.csv(a44,"ANOVA.csv")
write.csv(v44,"VIF.csv")
summary(log_reg44)

# woe.COUNT_DELQ_Vehicleloan_H2.binned has high p value and negative estimate.

df45 = subset(df44,select = -woe.COUNT_DELQ_Vehicleloan_H2.binned)
dim(df45) #68

# Iteration 45

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list45 = colnames(subset(df45,select = - RISK_TARGET))
stepwise_45 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list45, data = df45, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg45 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_H1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned + 
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + woe.OpenTradeCount.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.Max_DelinquencyDays_Vehicleloan_H2.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + woe.DFT_SUM_PAYMENT_VehicleLoan_H1_H2.binned + 
                  woe.Lien_flag.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.Last.Statement.Payment.Amount_CC_Q1.binned + woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.Max_DelinquencyDays_Vehicleloan_Q1.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned + 
                  woe.DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2.binned + woe.MortgageOpenCount.binned + 
                  woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2.binned + woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned, family = binomial(logit), 
                data = df45)
a45 = Anova(log_reg45,type = "II",test="Wald")
v45 = vif(log_reg45)
write.csv(a45,"ANOVA.csv")
write.csv(v45,"VIF.csv")
summary(log_reg45)

# woe.Max_DelinquencyDays_Vehicleloan_H2.binned has high p value and negative estimate.

df46 = subset(df45,select = -woe.Max_DelinquencyDays_Vehicleloan_H2.binned)
dim(df46) # 67

# Iteration 46

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list46 = colnames(subset(df46,select = - RISK_TARGET))
stepwise_46 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list46, data = df46, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg46 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_H1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned + 
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + woe.OpenTradeCount.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                  woe.DFT_SUM_PAYMENT_VehicleLoan_H1_H2.binned + woe.Lien_flag.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.Last.Statement.Payment.Amount_CC_Q1.binned + woe.NumberInquiriesP6Months.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned + 
                  woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2.binned + woe.DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned + 
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + woe.MortgageOpenCount.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned, family = binomial(logit), 
                data = df46)
a46 = Anova(log_reg46,type="II",test="Wald")
v46 = vif(log_reg46)
write.csv(a46,"ANOVA.csv")
write.csv(v46,"VIF.csv")
summary(log_reg46)

# woe.DFT_SUM_PAYMENT_VehicleLoan_H1_H2.binned has high p value and negative estimate.

df47 = subset(df46,select = -woe.DFT_SUM_PAYMENT_VehicleLoan_H1_H2.binned)
dim(df47) # 66

# Iteration 47

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list47 = colnames(subset(df47,select = - RISK_TARGET))
stepwise_47 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list47, data = df47, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg47 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_H1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned + 
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + woe.OpenTradeCount.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.Last.Statement.Payment.Amount_CC_Q1.binned + woe.Lien_flag.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.DFT_FEEAMOUNT_VehicleLoan_H1_H2.binned + 
                  woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2.binned + woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_H1_H2.binned, 
                family = binomial(logit), data = df47)
a47 = Anova(log_reg47,type="II",test="Wald")
v47 = vif(log_reg47)
write.csv(a47,"ANOVA.csv")
write.csv(v47,"VIF.csv")
summary(log_reg47)

# woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_H1_H2.binned has high p value and negative estimate.

df48 = subset(df47,select = -woe.DFT_Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_H1_H2.binned)
dim(df48) # 65

# Iteration 48

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list48 = colnames(subset(df48,select = - RISK_TARGET))
stepwise_48 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list48, data = df48, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg48 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_H1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned + 
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + woe.OpenTradeCount.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.Last.Statement.Payment.Amount_CC_Q1.binned + woe.Lien_flag.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.DFT_FEEAMOUNT_VehicleLoan_H1_H2.binned + 
                  woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2.binned, family = binomial(logit), 
                data = df48)
a48 = Anova(log_reg48,type="II",test = "Wald")
v48 = vif(log_reg48)
write.csv(a48,"ANOVA.csv")
write.csv(v48,"VIF.csv")
summary(log_reg48)

# woe.DFT_FEEAMOUNT_VehicleLoan_H1_H2.binned has high p value and negative estimate.

df49 = subset(df48,select = -woe.DFT_FEEAMOUNT_VehicleLoan_H1_H2.binned)
dim(df49) # 64

# Iteration 49

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list49 = colnames(subset(df49,select = - RISK_TARGET))
stepwise_49 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list49, data = df49, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg49 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_H1.binned + woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned + 
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + woe.OpenTradeCount.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.Last.Statement.Payment.Amount_CC_Q1.binned + woe.Lien_flag.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned + woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned + 
                  woe.AggregatedSpendPast3Months.binned + woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + woe.DFT_COUNT_CASH_VehicleLoan_H1_H2.binned + 
                  woe.DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2.binned, family = binomial(logit), 
                data = df49)
a49 = Anova(log_reg49,type="II",test="Wald")
v49 = vif(log_reg49)
write.csv(a49,"ANOVA.csv")
write.csv(v49,"VIF.csv")
summary(log_reg49)

# woe.DFT_COUNT_CASH_VehicleLoan_H1_H2.binned has high p value and negative estimate.

df50 = subset(df49,select = -woe.DFT_COUNT_CASH_VehicleLoan_H1_H2.binned)
dim(df50) # 63

# Iteration 50

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list50 = colnames(subset(df50,select = - RISK_TARGET))
stepwise_50 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list50, data = df50, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg50 = glm(formula = RISK_TARGET ~ woe.FICO.binned +
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_H1.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned + 
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned +
                  woe.OpenTradeCount.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned +
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.Last.Statement.Payment.Amount_CC_Q1.binned +
                  woe.Lien_flag.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned + 
                  woe.AggregatedSpendPast3Months.binned + 
                  woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned
                , family = binomial(logit),data = df50)

a50 = Anova(log_reg50,type="II",test= "Wald")
v50 = vif(log_reg50)
write.csv(a50,"ANOVA.csv")
write.csv(v50,"VIF.csv")
summary(log_reg50)

org_50 = glm(formula = RISK_TARGET ~ FICO +
                  COUNT_DELQ_Vehicleloan_SP + 
                  Max_DelinquencyDays_Loan_H1 + 
                  COUNT_LOAN_ADDON_Q1 + 
                  Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1 + 
                  Diff_Due_Payment_Vehicle_Staticpool +
                  OpenTradeCount + 
                  DFT_COUNT_LOAN_ADDON_H1_H2 +
                  INTEREST_AMOUNT_VehicleLoan_Q1 + 
                  MAX_INTERESTRATE_Loan_Q1 + 
                  DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
                  Last.Statement.Payment.Amount_CC_Q1 +
                  Lien_flag + 
                  DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
                  WITHDRAWAL_AMOUNT_DEPOSITS_Q1 + 
                  NumberInquiriesP6Months +
                  DFT_AVG_UTILIZATION_RATE_CC_H1_H2 + 
                  AggregatedSpendPast3Months + 
                  DFT_Last.Statement.Sale.Amount_CC_H1_H2 + 
                  COUNT_ACH_STATICPOOL + 
                  AVG_MONTH_END_BALANCE_SAVINGS_Q1 + 
                  DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2
                , family = binomial(logit),data = NAReplace_train)
summary(org_50)

o50 = vif(org_50)
write.csv(o50,"VIF.csv")

# Iteration 51

log_reg51 = glm(formula = RISK_TARGET ~ woe.FICO.binned +
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.Max_DelinquencyDays_Loan_H1.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned + 
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned +
                  woe.OpenTradeCount.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned +
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  # woe.Last.Statement.Payment.Amount_CC_Q1.binned +
                  woe.Lien_flag.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned + 
                  woe.AggregatedSpendPast3Months.binned + 
                  woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned
                , family = binomial(logit),data = df50)

a51 = Anova(log_reg51,type="II",test= "Wald")
v51 = vif(log_reg51)
write.csv(a51,"ANOVA.csv")
write.csv(v51,"VIF.csv")
summary(log_reg51)

org_51 = glm(formula = RISK_TARGET ~ FICO +
               COUNT_DELQ_Vehicleloan_SP + 
               Max_DelinquencyDays_Loan_H1 + 
               COUNT_LOAN_ADDON_Q1 + 
               Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1 + 
               Diff_Due_Payment_Vehicle_Staticpool +
               OpenTradeCount + 
               DFT_COUNT_LOAN_ADDON_H1_H2 +
               INTEREST_AMOUNT_VehicleLoan_Q1 + 
               MAX_INTERESTRATE_Loan_Q1 + 
               DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
               # Last.Statement.Payment.Amount_CC_Q1 +
               Lien_flag + 
               DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
               WITHDRAWAL_AMOUNT_DEPOSITS_Q1 + 
               NumberInquiriesP6Months +
               DFT_AVG_UTILIZATION_RATE_CC_H1_H2 + 
               AggregatedSpendPast3Months + 
               DFT_Last.Statement.Sale.Amount_CC_H1_H2 + 
               COUNT_ACH_STATICPOOL + 
               AVG_MONTH_END_BALANCE_SAVINGS_Q1 + 
               DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2
             , family = binomial(logit),data = NAReplace_train)
summary(org_51)

o51 = vif(org_51)
write.csv(o51,"VIF.csv")


# Iteration 52

log_reg52 = glm(formula = RISK_TARGET ~ woe.FICO.binned +
                  woe.COUNT_DELQ_Vehicleloan_SP.binned +
                  woe.Max_DelinquencyDays_Loan_H1.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + 
                  woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned + 
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned +
                  woe.OpenTradeCount.binned +
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned +
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  # woe.Last.Statement.Payment.Amount_CC_Q1.binned + #1
                  woe.Lien_flag.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  # woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned + #2
                  woe.AggregatedSpendPast3Months.binned + 
                  woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned +
                  woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned
                , family = binomial(logit),data = df50)

a52 = Anova(log_reg52,type="II",test= "Wald")
v52 = vif(log_reg52)
write.csv(a52,"ANOVA.csv")
write.csv(v52,"VIF.csv")
summary(log_reg52)

org_52 = glm(formula = RISK_TARGET ~ FICO +
               COUNT_DELQ_Vehicleloan_SP +
               Max_DelinquencyDays_Loan_H1 + 
               COUNT_LOAN_ADDON_Q1 + 
               Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1 + 
               Diff_Due_Payment_Vehicle_Staticpool +
               OpenTradeCount +
               DFT_COUNT_LOAN_ADDON_H1_H2 +
               INTEREST_AMOUNT_VehicleLoan_Q1 + 
               MAX_INTERESTRATE_Loan_Q1 + 
               DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
               # Last.Statement.Payment.Amount_CC_Q1 + #1
               Lien_flag + 
               DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
               WITHDRAWAL_AMOUNT_DEPOSITS_Q1 + 
               NumberInquiriesP6Months +
               # DFT_AVG_UTILIZATION_RATE_CC_H1_H2 + #2
               AggregatedSpendPast3Months + 
               DFT_Last.Statement.Sale.Amount_CC_H1_H2 +
               COUNT_ACH_STATICPOOL + 
               AVG_MONTH_END_BALANCE_SAVINGS_Q1 + 
               DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2
             , family = binomial(logit),data = NAReplace_train)
summary(org_52)

o52 = vif(org_52)
write.csv(o52,"VIF.csv")

# Iteration 53

log_reg53 = glm(formula = RISK_TARGET ~ woe.FICO.binned +
                  woe.COUNT_DELQ_Vehicleloan_SP.binned +
                  woe.Max_DelinquencyDays_Loan_H1.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned + 
                  # woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned + #3
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned +
                  woe.OpenTradeCount.binned +
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned +
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  # woe.Last.Statement.Payment.Amount_CC_Q1.binned + #1
                  woe.Lien_flag.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  # woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned + #2
                  woe.AggregatedSpendPast3Months.binned + 
                  woe.DFT_Last.Statement.Sale.Amount_CC_H1_H2.binned +
                  woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned
                , family = binomial(logit),data = df50)

a53 = Anova(log_reg53,type="II",test= "Wald")
v53 = vif(log_reg53)
write.csv(a53,"ANOVA.csv")
write.csv(v53,"VIF.csv")
summary(log_reg53)

org_53 = glm(formula = RISK_TARGET ~ FICO +
               COUNT_DELQ_Vehicleloan_SP +
               Max_DelinquencyDays_Loan_H1 + 
               COUNT_LOAN_ADDON_Q1 + 
               # Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1 +  #3
               Diff_Due_Payment_Vehicle_Staticpool +
               OpenTradeCount +
               DFT_COUNT_LOAN_ADDON_H1_H2 +
               INTEREST_AMOUNT_VehicleLoan_Q1 + 
               MAX_INTERESTRATE_Loan_Q1 + 
               DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
               # Last.Statement.Payment.Amount_CC_Q1 + #1
               Lien_flag + 
               DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
               WITHDRAWAL_AMOUNT_DEPOSITS_Q1 + 
               NumberInquiriesP6Months +
               # DFT_AVG_UTILIZATION_RATE_CC_H1_H2 + #2
               AggregatedSpendPast3Months + 
               DFT_Last.Statement.Sale.Amount_CC_H1_H2 +
               COUNT_ACH_STATICPOOL + 
               AVG_MONTH_END_BALANCE_SAVINGS_Q1 + 
               DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2
             , family = binomial(logit),data = NAReplace_train)
summary(org_53)

o53 = vif(org_53)
write.csv(o53,"VIF.csv")


# Iteration 54

df51 = subset(df50,select=-c(woe.Last.Statement.Merchandise.Average.Daily.Balance.Amount_CC_Q1.binned
                            ,woe.DFT_AVG_UTILIZATION_RATE_CC_H1_H2.binned 
                            ,woe.Last.Statement.Payment.Amount_CC_Q1.binned
                            ,woe.FICO.binned))

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list54 = colnames(subset(df51,select = - RISK_TARGET))
stepwise_54 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list54, data = df51, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg54 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.Max_DelinquencyDays_Loan_H1.binned + 
                  woe.OpenTradeCount.binned +
                  woe.AVG_UTILIZATION_RATE_CC_Q1.binned + 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned +
                  woe.Lien_flag.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  woe.TopOfWalletCCAnnualSpend.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned +
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                  woe.CCRevolvingBalance.binned +
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned +
                  woe.RevolvingBalance_CC_Q1.binned + 
                  woe.MortgageOpenCount.binned +
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned +
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.CCOpenCount.binned + 
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned +
                  woe.AggregatedSpendPast3Months.binned + 
                  woe.TopOfWalletCCCurrentBalance.binned +
                  woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned + 
                  woe.StudentLoanOpenCount.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.CL_CC_StaticPool.binned
                , family = binomial(logit), data = df51)
a54 = Anova(log_reg54,type="II",test="Wald")
v54 = vif(log_reg54)
write.csv(a54,"ANOVA.csv")
write.csv(v54,"VIF.csv")
summary(log_reg54)

org54 = glm(formula = RISK_TARGET ~ COUNT_DELQ_Vehicleloan_SP + 
                  DFT_COUNT_LOAN_ADDON_H1_H2 + 
                  Max_DelinquencyDays_Loan_H1 + 
                  OpenTradeCount +
                  AVG_UTILIZATION_RATE_CC_Q1 + 
                  MAX_INTERESTRATE_Loan_Q1 +
                  Lien_flag + 
                  NumberInquiriesP6Months +
                  TopOfWalletCCAnnualSpend + 
                  COUNT_LOAN_ADDON_Q1 +
                  Diff_Due_Payment_Vehicle_Staticpool + 
                  CCRevolvingBalance +
                  DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
                  WITHDRAWAL_AMOUNT_DEPOSITS_Q1 +
                  RevolvingBalance_CC_Q1 + 
                  MortgageOpenCount +
                  DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
                  DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2 +
                  AVG_MONTH_END_BALANCE_SAVINGS_Q1 + 
                  CCOpenCount + 
                  INTEREST_AMOUNT_VehicleLoan_Q1 + 
                  DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 +
                  AggregatedSpendPast3Months + 
                  TopOfWalletCCCurrentBalance +
                  DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2 + 
                  StudentLoanOpenCount + 
                  COUNT_ACH_STATICPOOL + 
                  CL_CC_StaticPool
                , family = binomial(logit), data = NAReplace_train)
summary(org54)
o54 = vif(org54)
write.csv(o54,"VIF.csv")

# Iteration 55

log_reg55 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  woe.Max_DelinquencyDays_Loan_H1.binned + 
                  woe.OpenTradeCount.binned +
                  # woe.AVG_UTILIZATION_RATE_CC_Q1.binned + #1 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned +
                  woe.Lien_flag.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  woe.TopOfWalletCCAnnualSpend.binned + 
                  woe.COUNT_LOAN_ADDON_Q1.binned +
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                  woe.CCRevolvingBalance.binned +
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned +
                  woe.RevolvingBalance_CC_Q1.binned + 
                  woe.MortgageOpenCount.binned +
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned +
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.CCOpenCount.binned + 
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned +
                  woe.AggregatedSpendPast3Months.binned + 
                  woe.TopOfWalletCCCurrentBalance.binned +
                  woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned + 
                  woe.StudentLoanOpenCount.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned + 
                  woe.CL_CC_StaticPool.binned
                , family = binomial(logit), data = df51)
a55 = Anova(log_reg55,type="II",test="Wald")
v55 = vif(log_reg55)
write.csv(a55,"ANOVA.csv")
write.csv(v55,"VIF.csv")
summary(log_reg55)

org55 = glm(formula = RISK_TARGET ~ COUNT_DELQ_Vehicleloan_SP + 
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              Max_DelinquencyDays_Loan_H1 + 
              OpenTradeCount +
              # AVG_UTILIZATION_RATE_CC_Q1 + #1
              MAX_INTERESTRATE_Loan_Q1 +
              Lien_flag + 
              NumberInquiriesP6Months +
              TopOfWalletCCAnnualSpend + 
              COUNT_LOAN_ADDON_Q1 +
              Diff_Due_Payment_Vehicle_Staticpool + 
              CCRevolvingBalance +
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1 +
              RevolvingBalance_CC_Q1 + 
              MortgageOpenCount +
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
              DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2 +
              AVG_MONTH_END_BALANCE_SAVINGS_Q1 + 
              CCOpenCount + 
              INTEREST_AMOUNT_VehicleLoan_Q1 + 
              DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 +
              AggregatedSpendPast3Months + 
              TopOfWalletCCCurrentBalance +
              DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2 + 
              StudentLoanOpenCount + 
              COUNT_ACH_STATICPOOL + 
              CL_CC_StaticPool
            , family = binomial(logit), data = NAReplace_train)
summary(org55)
o55 = vif(org55)
write.csv(o55,"VIF.csv")


# Iteration 56

log_reg56 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  # woe.Max_DelinquencyDays_Loan_H1.binned + #5
                  woe.OpenTradeCount.binned +
                  # woe.AVG_UTILIZATION_RATE_CC_Q1.binned + #1 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned +
                  woe.Lien_flag.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  # woe.TopOfWalletCCAnnualSpend.binned +  #3
                  woe.COUNT_LOAN_ADDON_Q1.binned +
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                  woe.CCRevolvingBalance.binned +
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned +
                  woe.RevolvingBalance_CC_Q1.binned + 
                  woe.MortgageOpenCount.binned +
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned +
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  woe.CCOpenCount.binned + 
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned +
                  woe.AggregatedSpendPast3Months.binned + 
                  woe.TopOfWalletCCCurrentBalance.binned +
                  # woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned + #2
                  woe.StudentLoanOpenCount.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned# + 
                  # woe.CL_CC_StaticPool.binned #4
                , family = binomial(logit), data = df51)
a56 = Anova(log_reg56,type="II",test="Wald")
v56 = vif(log_reg56)
write.csv(a56,"ANOVA.csv")
write.csv(v56,"VIF.csv")
summary(log_reg56)

org56 = glm(formula = RISK_TARGET ~ COUNT_DELQ_Vehicleloan_SP + 
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              # Max_DelinquencyDays_Loan_H1 +  #5
              OpenTradeCount +
              # AVG_UTILIZATION_RATE_CC_Q1 + #1
              MAX_INTERESTRATE_Loan_Q1 +
              Lien_flag + 
              NumberInquiriesP6Months +
              # TopOfWalletCCAnnualSpend + #3
              COUNT_LOAN_ADDON_Q1 +
              Diff_Due_Payment_Vehicle_Staticpool + 
              CCRevolvingBalance +
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1 +
              RevolvingBalance_CC_Q1 + 
              MortgageOpenCount +
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
              DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2 +
              AVG_MONTH_END_BALANCE_SAVINGS_Q1 + 
              CCOpenCount + 
              INTEREST_AMOUNT_VehicleLoan_Q1 + 
              DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 +
              AggregatedSpendPast3Months + 
              TopOfWalletCCCurrentBalance +
              # DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2 +  #2
              StudentLoanOpenCount + 
              COUNT_ACH_STATICPOOL #+ 
              # CL_CC_StaticPool #4
            , family = binomial(logit), data = NAReplace_train)
summary(org56)
o56 = vif(org56)
write.csv(o56,"VIF.csv")

blr_gains_table(log_reg56,df51)


# Iteration 57

log_reg57 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  # woe.Max_DelinquencyDays_Loan_H1.binned + #5
                  woe.OpenTradeCount.binned +
                  # woe.AVG_UTILIZATION_RATE_CC_Q1.binned + #1 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned +
                  woe.Lien_flag.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  # woe.TopOfWalletCCAnnualSpend.binned +  #3
                  woe.COUNT_LOAN_ADDON_Q1.binned +
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                  woe.CCRevolvingBalance.binned +
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned +
                  woe.RevolvingBalance_CC_Q1.binned + 
                  woe.MortgageOpenCount.binned +
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned +
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  # woe.CCOpenCount.binned + #6
                  woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + 
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned +
                  # woe.AggregatedSpendPast3Months.binned + #7
                  woe.TopOfWalletCCCurrentBalance.binned +
                  # woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned + #2
                  woe.StudentLoanOpenCount.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned# + 
                # woe.CL_CC_StaticPool.binned #4
                , family = binomial(logit), data = df51)
a57 = Anova(log_reg57,type="II",test="Wald")
v57 = vif(log_reg57)
write.csv(a57,"ANOVA.csv")
write.csv(v57,"VIF.csv")
summary(log_reg57)

org57 = glm(formula = RISK_TARGET ~ COUNT_DELQ_Vehicleloan_SP + 
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              # Max_DelinquencyDays_Loan_H1 +  #5
              OpenTradeCount +
              # AVG_UTILIZATION_RATE_CC_Q1 + #1
              MAX_INTERESTRATE_Loan_Q1 +
              Lien_flag + 
              NumberInquiriesP6Months +
              # TopOfWalletCCAnnualSpend + #3
              COUNT_LOAN_ADDON_Q1 +
              Diff_Due_Payment_Vehicle_Staticpool + 
              CCRevolvingBalance +
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1 +
              RevolvingBalance_CC_Q1 + 
              MortgageOpenCount +
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
              DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2 +
              AVG_MONTH_END_BALANCE_SAVINGS_Q1 + 
              # CCOpenCount +  #6
              INTEREST_AMOUNT_VehicleLoan_Q1 + 
              DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 +
              # AggregatedSpendPast3Months + # 7
              TopOfWalletCCCurrentBalance +
              # DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2 +  #2
              StudentLoanOpenCount + 
              COUNT_ACH_STATICPOOL #+ 
            # CL_CC_StaticPool #4
            , family = binomial(logit), data = NAReplace_train)
summary(org57)
o57 = vif(org57)
write.csv(o57,"VIF.csv")

blr_gains_table(log_reg57,df51)


# WOE on Test data ;

df_test = subset(RISK_test,select=c(RISK_TARGET ,
                                    FICO,
                                    COUNT_DELQ_Vehicleloan_SP , 
                                      DFT_COUNT_LOAN_ADDON_H1_H2 , 
                                      # Max_DelinquencyDays_Loan_H1 ,  #5
                                      OpenTradeCount ,
                                      # AVG_UTILIZATION_RATE_CC_Q1 , #1
                                      MAX_INTERESTRATE_Loan_Q1 ,
                                      Lien_flag , 
                                      NumberInquiriesP6Months ,
                                      # TopOfWalletCCAnnualSpend , #3
                                      COUNT_LOAN_ADDON_Q1 ,
                                      Diff_Due_Payment_Vehicle_Staticpool , 
                                      CCRevolvingBalance ,
                                      DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 , 
                                      WITHDRAWAL_AMOUNT_DEPOSITS_Q1 ,
                                      RevolvingBalance_CC_Q1 , 
                                      MortgageOpenCount ,
                                      DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 , 
                                      DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2 ,
                                      AVG_MONTH_END_BALANCE_SAVINGS_Q1 , 
                                      CCOpenCount ,  #6
                                      # INTEREST_AMOUNT_VehicleLoan_Q1 , #8
                                      DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 ,
                                      # AggregatedSpendPast3Months , # 7
                                      TopOfWalletCCCurrentBalance ,
                                      # DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2 ,  #2
                                      # StudentLoanOpenCount , #9
                                      COUNT_ACH_STATICPOOL 
                                    ))


NAReplace_test <- replace(df_test,is.na(df_test),-9999999)
sum(is.na(NAReplace_test)) 

install.packages("woeBinning")
library(woeBinning)

RISK_test_model <- woe.binning(NAReplace_test,'RISK_TARGET',NAReplace_test)
test_woe <- woe.binning.deploy(NAReplace_test,RISK_test_model,add.woe.or.dum.var = "woe")


# Iteration 58

log_reg58 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  # woe.Max_DelinquencyDays_Loan_H1.binned + #5
                  woe.OpenTradeCount.binned +
                  # woe.AVG_UTILIZATION_RATE_CC_Q1.binned + #1 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned +
                  woe.Lien_flag.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  # woe.TopOfWalletCCAnnualSpend.binned +  #3
                  woe.COUNT_LOAN_ADDON_Q1.binned +
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                  woe.CCRevolvingBalance.binned +
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned +
                  woe.RevolvingBalance_CC_Q1.binned + 
                  woe.MortgageOpenCount.binned +
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned +
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  # woe.CCOpenCount.binned + #6
                  # woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + #8
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned +
                  # woe.AggregatedSpendPast3Months.binned + #7
                  woe.TopOfWalletCCCurrentBalance.binned +
                  # woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned + #2
                  woe.StudentLoanOpenCount.binned + 
                  woe.COUNT_ACH_STATICPOOL.binned# + 
                # woe.CL_CC_StaticPool.binned #4
                , family = binomial(logit), data = df51)
a58 = Anova(log_reg58,type="II",test="Wald")
v58 = vif(log_reg58)
write.csv(a58,"ANOVA.csv")
write.csv(v58,"VIF.csv")
summary(log_reg58)

org58 = glm(formula = RISK_TARGET ~ COUNT_DELQ_Vehicleloan_SP + 
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              # Max_DelinquencyDays_Loan_H1 +  #5
              OpenTradeCount +
              # AVG_UTILIZATION_RATE_CC_Q1 + #1
              MAX_INTERESTRATE_Loan_Q1 +
              Lien_flag + 
              NumberInquiriesP6Months +
              # TopOfWalletCCAnnualSpend + #3
              COUNT_LOAN_ADDON_Q1 +
              Diff_Due_Payment_Vehicle_Staticpool + 
              CCRevolvingBalance +
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1 +
              RevolvingBalance_CC_Q1 + 
              MortgageOpenCount +
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
              DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2 +
              AVG_MONTH_END_BALANCE_SAVINGS_Q1 + 
              # CCOpenCount +  #6
              # INTEREST_AMOUNT_VehicleLoan_Q1 + #8
              DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 +
              # AggregatedSpendPast3Months + # 7
              TopOfWalletCCCurrentBalance +
              # DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2 +  #2
              StudentLoanOpenCount + 
              COUNT_ACH_STATICPOOL #+ 
            # CL_CC_StaticPool #4
            , family = binomial(logit), data = NAReplace_train)
summary(org58)
o58 = vif(org58)
write.csv(o58,"VIF.csv")

blr_gains_table(log_reg58,df51)

# Iteration 59

log_reg59 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  # woe.Max_DelinquencyDays_Loan_H1.binned + #5
                  woe.OpenTradeCount.binned +
                  # woe.AVG_UTILIZATION_RATE_CC_Q1.binned + #1 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned +
                  woe.Lien_flag.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  # woe.TopOfWalletCCAnnualSpend.binned +  #3
                  woe.COUNT_LOAN_ADDON_Q1.binned +
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                  woe.CCRevolvingBalance.binned +
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned +
                  woe.RevolvingBalance_CC_Q1.binned + 
                  woe.MortgageOpenCount.binned +
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned +
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  # woe.CCOpenCount.binned + #6
                  # woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + #8
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned +
                  # woe.AggregatedSpendPast3Months.binned + #7
                  woe.TopOfWalletCCCurrentBalance.binned +
                  # woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned + #2
                  # woe.StudentLoanOpenCount.binned + #9
                  woe.COUNT_ACH_STATICPOOL.binned# + 
                # woe.CL_CC_StaticPool.binned #4
                , family = binomial(logit), data = df51)
a59 = Anova(log_reg59,type="II",test="Wald")
v59 = vif(log_reg59)
write.csv(a59,"ANOVA.csv")
write.csv(v59,"VIF.csv")
summary(log_reg59)

org59 = glm(formula = RISK_TARGET ~ COUNT_DELQ_Vehicleloan_SP + 
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              # Max_DelinquencyDays_Loan_H1 +  #5
              OpenTradeCount +
              # AVG_UTILIZATION_RATE_CC_Q1 + #1
              MAX_INTERESTRATE_Loan_Q1 +
              Lien_flag + 
              NumberInquiriesP6Months +
              # TopOfWalletCCAnnualSpend + #3
              COUNT_LOAN_ADDON_Q1 +
              Diff_Due_Payment_Vehicle_Staticpool + 
              CCRevolvingBalance +
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1 +
              RevolvingBalance_CC_Q1 + 
              MortgageOpenCount +
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
              DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2 +
              AVG_MONTH_END_BALANCE_SAVINGS_Q1 + 
              # CCOpenCount +  #6
              # INTEREST_AMOUNT_VehicleLoan_Q1 + #8
              DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 +
              # AggregatedSpendPast3Months + # 7
              TopOfWalletCCCurrentBalance +
              # DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2 +  #2
              # StudentLoanOpenCount + #9
              COUNT_ACH_STATICPOOL #+ 
            # CL_CC_StaticPool #4
            , family = binomial(logit), data = NAReplace_train)
summary(org59)
o59 = vif(org59)
write.csv(o59,"VIF.csv")

blr_gains_table(log_reg59,df51)
blr_gains_table(log_reg59,test_woe)


# Iteration 60

log_reg60 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  # woe.Max_DelinquencyDays_Loan_H1.binned + #5
                  woe.OpenTradeCount.binned +
                  # woe.AVG_UTILIZATION_RATE_CC_Q1.binned + #1 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned +
                  woe.Lien_flag.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  # woe.TopOfWalletCCAnnualSpend.binned +  #3
                  woe.COUNT_LOAN_ADDON_Q1.binned +
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                  woe.CCRevolvingBalance.binned +
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned +
                  woe.RevolvingBalance_CC_Q1.binned + 
                  woe.MortgageOpenCount.binned +
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned +
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  # woe.CCOpenCount.binned + #6
                  # woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + #8
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned +
                  # woe.AggregatedSpendPast3Months.binned + #7
                  # woe.TopOfWalletCCCurrentBalance.binned + #10
                  # woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned + #2
                  # woe.StudentLoanOpenCount.binned + #9
                  woe.COUNT_ACH_STATICPOOL.binned# + 
                # woe.CL_CC_StaticPool.binned #4
                , family = binomial(logit), data = df51)
a60 = Anova(log_reg60,type="II",test="Wald")
v60 = vif(log_reg60)
write.csv(a60,"ANOVA.csv")
write.csv(v60,"VIF.csv")
summary(log_reg60)

org60 = glm(formula = RISK_TARGET ~ COUNT_DELQ_Vehicleloan_SP + 
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              # Max_DelinquencyDays_Loan_H1 +  #5
              OpenTradeCount +
              # AVG_UTILIZATION_RATE_CC_Q1 + #1
              MAX_INTERESTRATE_Loan_Q1 +
              Lien_flag + 
              NumberInquiriesP6Months +
              # TopOfWalletCCAnnualSpend + #3
              COUNT_LOAN_ADDON_Q1 +
              Diff_Due_Payment_Vehicle_Staticpool + 
              CCRevolvingBalance +
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1 +
              RevolvingBalance_CC_Q1 + 
              MortgageOpenCount +
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
              DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2 +
              AVG_MONTH_END_BALANCE_SAVINGS_Q1 + 
              # CCOpenCount +  #6
              # INTEREST_AMOUNT_VehicleLoan_Q1 + #8
              DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 +
              # AggregatedSpendPast3Months + # 7
              # TopOfWalletCCCurrentBalance + #10
              # DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2 +  #2
              # StudentLoanOpenCount + #9
              COUNT_ACH_STATICPOOL #+ 
            # CL_CC_StaticPool #4
            , family = binomial(logit), data = NAReplace_train)
summary(org60)
o60 = vif(org60)
write.csv(o60,"VIF.csv")

blr_gains_table(log_reg60,df51)
blr_gains_table(log_reg60,test_woe)



# Iteration 61

log_reg61 = glm(formula = RISK_TARGET ~ woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  # woe.Max_DelinquencyDays_Loan_H1.binned + #5
                  woe.OpenTradeCount.binned +
                  # woe.AVG_UTILIZATION_RATE_CC_Q1.binned + #1 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned +
                  woe.Lien_flag.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  # woe.TopOfWalletCCAnnualSpend.binned +  #3
                  woe.COUNT_LOAN_ADDON_Q1.binned +
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                  woe.CCRevolvingBalance.binned +
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned +
                  woe.RevolvingBalance_CC_Q1.binned + 
                  woe.MortgageOpenCount.binned +
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned +
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  # woe.CCOpenCount.binned + #6
                  # woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + #8
                  # woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + #11
                  # woe.AggregatedSpendPast3Months.binned + #7
                  # woe.TopOfWalletCCCurrentBalance.binned + #10
                  # woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned + #2
                  # woe.StudentLoanOpenCount.binned + #9
                  woe.COUNT_ACH_STATICPOOL.binned# + 
                # woe.CL_CC_StaticPool.binned #4
                , family = binomial(logit), data = df51)
a61 = Anova(log_reg61,type="II",test="Wald")
v61 = vif(log_reg61)
write.csv(a61,"ANOVA.csv")
write.csv(v61,"VIF.csv")
summary(log_reg61)

org61 = glm(formula = RISK_TARGET ~ COUNT_DELQ_Vehicleloan_SP + 
              DFT_COUNT_LOAN_ADDON_H1_H2 + 
              # Max_DelinquencyDays_Loan_H1 +  #5
              OpenTradeCount +
              # AVG_UTILIZATION_RATE_CC_Q1 + #1
              MAX_INTERESTRATE_Loan_Q1 +
              Lien_flag + 
              NumberInquiriesP6Months +
              # TopOfWalletCCAnnualSpend + #3
              COUNT_LOAN_ADDON_Q1 +
              Diff_Due_Payment_Vehicle_Staticpool + 
              CCRevolvingBalance +
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1 +
              RevolvingBalance_CC_Q1 + 
              MortgageOpenCount +
              DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 +
              DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2 +
              AVG_MONTH_END_BALANCE_SAVINGS_Q1 + 
              # CCOpenCount +  #6
              # INTEREST_AMOUNT_VehicleLoan_Q1 + #8
              # DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 + #11
              # AggregatedSpendPast3Months + # 7
              # TopOfWalletCCCurrentBalance + #10
              # DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2 +  #2
              # StudentLoanOpenCount + #9
              COUNT_ACH_STATICPOOL #+ 
            # CL_CC_StaticPool #4
            , family = binomial(logit), data = NAReplace_train)
summary(org61)
o61 = vif(org61)
write.csv(o61,"VIF.csv")

blr_gains_table(log_reg61,df51)
blr_gains_table(log_reg61,test_woe)





# Iteration 62

log_reg62 = glm(formula = RISK_TARGET ~ 
                  woe.FICO.binned+
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                  # woe.Max_DelinquencyDays_Loan_H1.binned + #5
                  woe.OpenTradeCount.binned +
                  # woe.AVG_UTILIZATION_RATE_CC_Q1.binned + #1 
                  woe.MAX_INTERESTRATE_Loan_Q1.binned +
                  # woe.Lien_flag.binned + ######
                  # woe.NumberInquiriesP6Months.binned + ######
                  # woe.TopOfWalletCCAnnualSpend.binned +  #3
                  # woe.COUNT_LOAN_ADDON_Q1.binned +
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                  # woe.CCRevolvingBalance.binned + ###
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned +
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.RevolvingBalance_CC_Q1.binned #+ 
                  # woe.MortgageOpenCount.binned + ###
                  # woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned ###+ #####
                  # woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + #12
                  # woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned +  ######
                  # woe.CCOpenCount.binned + #6 #######
                  # woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + #8
                  # woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned + #11 #####
                  # woe.AggregatedSpendPast3Months.binned + #7
                  # woe.TopOfWalletCCCurrentBalance.binned + #10
                  # woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned + #2
                  # woe.StudentLoanOpenCount.binned + #9
                  # woe.COUNT_ACH_STATICPOOL.binned# + #11 #######
                # woe.CL_CC_StaticPool.binned #4
                , family = binomial(logit), data = df50)
a62 = Anova(log_reg62,type="II",test="Wald")
v62 = vif(log_reg62)
write.csv(a62,"ANOVA.csv")
write.csv(v62,"VIF.csv")
summary(log_reg62)

org62 = glm( RISK_TARGET ~
              FICO+
              COUNT_DELQ_Vehicleloan_SP+
              DFT_COUNT_LOAN_ADDON_H1_H2+
              OpenTradeCount+
              MAX_INTERESTRATE_Loan_Q1+
              COUNT_LOAN_ADDON_Q1+
              Diff_Due_Payment_Vehicle_Staticpool+
              DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2+
              WITHDRAWAL_AMOUNT_DEPOSITS_Q1+
              RevolvingBalance_CC_Q1, family = binomial(logit), data = NAReplace_train
)


summary(org62)
o62 = vif(org62)
write.csv(o62,"VIF.csv")

blr_gains_table(log_reg62,df50)
blr_gains_table(log_reg62,test_woe)
test_woe$RISK_TARGET = as.factor(test_woe$RISK_TARGET ) 


df_test1 = subset(RISK_test,select= c(RISK_TARGET , 
                                        COUNT_DELQ_Vehicleloan_SP , 
                                        DFT_COUNT_LOAN_ADDON_H1_H2 ,
                                        Max_DelinquencyDays_Loan_H1 , #5
                                        OpenTradeCount ,
                                        AVG_UTILIZATION_RATE_CC_Q1 , #1
                                        MAX_INTERESTRATE_Loan_Q1 ,
                                        finalcycle2 , 
                                        NumberInquiriesP6Months ,
                                        TopOfWalletCCAnnualSpend , #3
                                        COUNT_LOAN_ADDON_Q1 ,
                                        Diff_Due_Payment_Vehicle_Staticpool , 
                                        CCRevolvingBalance , 
                                        DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 , 
                                        WITHDRAWAL_AMOUNT_DEPOSITS_Q1 , 
                                        RevolvingBalance_CC_Q1 ,
                                        MortgageOpenCount , 
                                        DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 , 
                                        DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2 , 
                                        AVG_MONTH_END_BALANCE_SAVINGS_Q1 , 
                                        CCOpenCount , #6
                                        INTEREST_AMOUNT_VehicleLoan_Q1 , #7
                                        DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 ,#11
                                        AggregatedSpendPast3Months , #8
                                        TopOfWalletCCCurrentBalance , #10
                                        DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2 , #2
                                        StudentLoanOpenCount , #9
                                        COUNT_ACH_STATICPOOL , 
                                      CL_CC_StaticPool #4
                                      ,FICO_Staticpool
                                      ))

NAReplace_test <- replace(df_test1,is.na(df_test1),-9999999)
sum(is.na(NAReplace_test)) 

RISK_test_model <- woe.binning(NAReplace_test,'RISK_TARGET',NAReplace_test)
test_woe <- woe.binning.deploy(NAReplace_test,RISK_test_model,add.woe.or.dum.var = "woe")



# Iteration 63

df52 = subset(df51,select = -woe.Lien_flag.binned)
dim(df52) # 58


sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list55 = colnames(subset(df52,select = - RISK_TARGET))
stepwise_55 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list55, data = df52, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg63 = glm(formula = RISK_TARGET ~ 
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned +
                  # woe.Max_DelinquencyDays_Loan_H1.binned + #5
                  woe.OpenTradeCount.binned +
                  # woe.AVG_UTILIZATION_RATE_CC_Q1.binned + #1
                  woe.MAX_INTERESTRATE_Loan_Q1.binned +
                  woe.finalcycle2.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  # woe.TopOfWalletCCAnnualSpend.binned + #3
                  woe.COUNT_LOAN_ADDON_Q1.binned +
                  woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                  woe.CCRevolvingBalance.binned + 
                  woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.RevolvingBalance_CC_Q1.binned +
                  woe.MortgageOpenCount.binned + 
                  woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned + 
                  woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned + 
                  # woe.CCOpenCount.binned + #6
                  # woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + #7
                  woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned +#11
                  # woe.AggregatedSpendPast3Months.binned + #8
                  woe.TopOfWalletCCCurrentBalance.binned + #10
                  # woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned + #2
                  # woe.StudentLoanOpenCount.binned + #9
                  woe.COUNT_ACH_STATICPOOL.binned #+ 
                  # woe.CL_CC_StaticPool.binned #4
                , family = binomial(logit), data = df52)

a63 = Anova(log_reg63,type="II",test= "Wald")
v63 = vif(log_reg63)  
a63
v63

org63 = glm(formula = RISK_TARGET ~ COUNT_DELQ_Vehicleloan_SP + 
                  DFT_COUNT_LOAN_ADDON_H1_H2 +
                  # Max_DelinquencyDays_Loan_H1 + #5
                  OpenTradeCount +
                  # AVG_UTILIZATION_RATE_CC_Q1 + #1
                  MAX_INTERESTRATE_Loan_Q1 +
                  finalcycle2 + 
                  NumberInquiriesP6Months +
                  # TopOfWalletCCAnnualSpend + #3
                  COUNT_LOAN_ADDON_Q1 +
                  Diff_Due_Payment_Vehicle_Staticpool + 
                  CCRevolvingBalance + 
                  DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 + 
                  WITHDRAWAL_AMOUNT_DEPOSITS_Q1 + 
                  RevolvingBalance_CC_Q1 + 
                  MortgageOpenCount + 
                  DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 + 
                  DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2 + 
                  AVG_MONTH_END_BALANCE_SAVINGS_Q1 + 
                  # CCOpenCount + #6
                  # INTEREST_AMOUNT_VehicleLoan_Q1 + #7 
                  DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 + #11
                  # AggregatedSpendPast3Months + #8
                  TopOfWalletCCCurrentBalance + #10
                  # DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2 + #2
                  # StudentLoanOpenCount + #9
                  COUNT_ACH_STATICPOOL #+ 
                  # CL_CC_StaticPool #4
                , family = binomial(logit), data = NAReplace_train)
summary(org63)
o63 = vif(org63)
write.csv(o63,"VIF.csv")

blr_gains_table(log_reg63,df52)
blr_gains_table(log_reg63,test_woe)


# Iteration Testing

log_reg63 = glm(formula = RISK_TARGET ~ 
                  woe.FICO_Staticpool.binned+
                  woe.COUNT_DELQ_Vehicleloan_SP.binned + 
                  woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned +
                  # woe.Max_DelinquencyDays_Loan_H1.binned + #5
                  woe.OpenTradeCount.binned +
                  # woe.AVG_UTILIZATION_RATE_CC_Q1.binned + #1
                  woe.MAX_INTERESTRATE_Loan_Q1.binned +
                  # woe.finalcycle2.binned + 
                  woe.NumberInquiriesP6Months.binned +
                  # woe.TopOfWalletCCAnnualSpend.binned + #3
                  # woe.COUNT_LOAN_ADDON_Q1.binned +
                  # woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                  # woe.CCRevolvingBalance.binned + 
                  # woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                  # woe.WITHDRAWAL_AMOUNT_DEPOSITS_Q1.binned + 
                  woe.RevolvingBalance_CC_Q1.binned #+
                  # woe.MortgageOpenCount.binned #+ 
                  # woe.DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2.binned + 
                  # woe.DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2.binned #+ 
                  # woe.AVG_MONTH_END_BALANCE_SAVINGS_Q1.binned# + 
                  # woe.CCOpenCount.binned + #6
                  # woe.INTEREST_AMOUNT_VehicleLoan_Q1.binned + #7
                  # woe.DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2.binned +#11
                  # woe.AggregatedSpendPast3Months.binned + #8
                  # woe.TopOfWalletCCCurrentBalance.binned + #10
                  # woe.DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2.binned + #2
                  # woe.StudentLoanOpenCount.binned + #9
                  # woe.COUNT_ACH_STATICPOOL.binned #+ # 12
                # woe.CL_CC_StaticPool.binned #4
                , family = binomial(logit), data = df_woe)

a63 = Anova(log_reg63,type="II",test= "Wald")
v63 = vif(log_reg63)  
write.csv(a63,"ANOVA.csv")
write.csv(v63,"VIF.csv")
summary(log_reg63)

org63 = glm(formula = RISK_TARGET ~ 
              FICO+
              COUNT_DELQ_Vehicleloan_SP +
              DFT_COUNT_LOAN_ADDON_H1_H2 +
              # Max_DelinquencyDays_Loan_H1 + #5
              OpenTradeCount +
              # AVG_UTILIZATION_RATE_CC_Q1 + #1
              MAX_INTERESTRATE_Loan_Q1 +
              # finalcycle2 +
              NumberInquiriesP6Months +
              # TopOfWalletCCAnnualSpend + #3
              # COUNT_LOAN_ADDON_Q1 +
              # Diff_Due_Payment_Vehicle_Staticpool +
              # CCRevolvingBalance +
              # DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2 +
              # WITHDRAWAL_AMOUNT_DEPOSITS_Q1 +
              RevolvingBalance_CC_Q1# +
              # MortgageOpenCount# +
              # DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2 +
              # DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2# +
              # AVG_MONTH_END_BALANCE_SAVINGS_Q1# +
              # CCOpenCount + #6
              # INTEREST_AMOUNT_VehicleLoan_Q1 + #7
              # DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2 + #11
              # AggregatedSpendPast3Months + #8
              # TopOfWalletCCCurrentBalance + #10
              # DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2 + #2
              # StudentLoanOpenCount + #9
              # COUNT_ACH_STATICPOOL #+ #12
            # CL_CC_StaticPool #4
            , family = binomial(logit), data = NAReplace_train)
summary(org63)
o63 = vif(org63)
write.csv(o63,"VIF.csv")

blr_gains_table(log_reg63,df_woe)
blr_gains_table(log_reg63,test_woe)


# New Iteration  :

df101 = subset(df_woe,select = c(woe.FICO.binned,
                                woe.FICO_Staticpool.binned,
                                woe.OpenTradeCount.binned,
                                woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned,
                                woe.NumberInquiriesP6Months.binned,
                                woe.MAX_INTERESTRATE_Loan_Q1.binned,
                                woe.RevolvingBalance_CC_Q1.binned,
                                woe.Diff_Due_Payment_Vehicle_Staticpool.binned,
                                woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned,
                                woe.VehicleLoan_Cycle2plusFlag_12MonthBack.binned,
                                woe.VehicleLoan_Cycle2Flag_12MonthBack.binned,
                                woe.VehicleLoan_Cycle1Flag_12MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2plusFlag_12MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2Flag_12MonthBack.binned,
                                woe.UnsecuredLoan_Cycle1Flag_12MonthBack.binned,
                                woe.SecuredLoan_Cycle2plusFlag_12MonthBack.binned,
                                woe.SecuredLoan_Cycle2Flag_12MonthBack.binned,
                                woe.SecuredLoan_Cycle1Flag_12MonthBack.binned,
                                woe.VehicleLoan_Cycle2plusFlag_9MonthBack.binned,
                                woe.VehicleLoan_Cycle2Flag_9MonthBack.binned,
                                woe.VehicleLoan_Cycle1Flag_9MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2plusFlag_9MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2Flag_9MonthBack.binned,
                                woe.UnsecuredLoan_Cycle1Flag_9MonthBack.binned,
                                woe.SecuredLoan_Cycle2plusFlag_9MonthBack.binned,
                                woe.SecuredLoan_Cycle2Flag_9MonthBack.binned,
                                woe.SecuredLoan_Cycle1Flag_9MonthBack.binned,
                                woe.VehicleLoan_Cycle2plusFlag_6MonthBack.binned,
                                woe.VehicleLoan_Cycle2Flag_6MonthBack.binned,
                                woe.VehicleLoan_Cycle1Flag_6MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2plusFlag_6MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2Flag_6MonthBack.binned,
                                woe.UnsecuredLoan_Cycle1Flag_6MonthBack.binned,
                                woe.SecuredLoan_Cycle2plusFlag_6MonthBack.binned,
                                woe.SecuredLoan_Cycle2Flag_6MonthBack.binned,
                                woe.SecuredLoan_Cycle1Flag_6MonthBack.binned,
                                woe.VehicleLoan_Cycle2plusFlag_3MonthBack.binned,
                                woe.VehicleLoan_Cycle2Flag_3MonthBack.binned,
                                woe.VehicleLoan_Cycle1Flag_3MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2plusFlag_3MonthBack.binned,
                                woe.UnsecuredLoan_Cycle2Flag_3MonthBack.binned,
                                woe.UnsecuredLoan_Cycle1Flag_3MonthBack.binned,
                                woe.SecuredLoan_Cycle2plusFlag_3MonthBack.binned,
                                woe.SecuredLoan_Cycle2Flag_3MonthBack.binned,
                                woe.SecuredLoan_Cycle1Flag_3MonthBack.binned,
                                woe.VehicleLoan_Cycle2plusFlag_SP.binned,
                                woe.VehicleLoan_Cycle2Flag_SP.binned,
                                woe.VehicleLoan_Cycle1Flag_SP.binned,
                                woe.UnsecuredLoan_Cycle2plusFlag_SP.binned,
                                woe.UnsecuredLoan_Cycle2Flag_SP.binned,
                                woe.UnsecuredLoan_Cycle1Flag_SP.binned,
                                woe.SecuredLoan_Cycle2plusFlag_SP.binned,
                                woe.SecuredLoan_Cycle2Flag_SP.binned,
                                woe.SecuredLoan_Cycle1Flag_SP.binned,
                                woe.ProductVehicleLoan_Cycle2plus_12MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2_12MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle1_12MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2plus_12MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2_12MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle1_12MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2plus_12MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2_12MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle1_12MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2plus_9MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2_9MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle1_9MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2plus_9MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2_9MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle1_9MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2plus_9MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2_9MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle1_9MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2plus_6MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2_6MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle1_6MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2plus_6MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2_6MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle1_6MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2plus_6MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2_6MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle1_6MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2plus_3MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2_3MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle1_3MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2plus_3MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle2_3MonthBack.binned,
                                woe.ProductUnsecuredLoan_Cycle1_3MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2plus_3MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle2_3MonthBack.binned,
                                woe.ProductSecuredLoan_Cycle1_3MonthBack.binned,
                                woe.ProductVehicleLoan_Cycle2plus_SP.binned,
                                woe.ProductVehicleLoan_Cycle2_SP.binned,
                                woe.ProductVehicleLoan_Cycle1_SP.binned,
                                woe.ProductUnsecuredLoan_Cycle2plus_SP.binned,
                                woe.ProductUnsecuredLoan_Cycle2_SP.binned,
                                woe.ProductUnsecuredLoan_Cycle1_SP.binned,
                                woe.ProductSecuredLoan_Cycle2plus_SP.binned,
                                woe.ProductSecuredLoan_Cycle2_SP.binned,
                                woe.ProductSecuredLoan_Cycle1_SP.binned,
                                woe.MortgageFlag_Cycle2plus_12MonthBack.binned,
                                woe.MortgageFlag_Cycle2_12MonthBack.binned,
                                woe.MortgageFlag_Cycle1_12MonthBack.binned,
                                woe.MortgageFlag_Cycle2plus_9MonthBack.binned,
                                woe.MortgageFlag_Cycle2_9MonthBack.binned,
                                woe.MortgageFlag_Cycle1_9MonthBack.binned,
                                woe.MortgageFlag_Cycle2plus_6MonthBack.binned,
                                woe.MortgageFlag_Cycle2_6MonthBack.binned,
                                woe.MortgageFlag_Cycle1_6MonthBack.binned,
                                woe.MortgageFlag_Cycle2plus_3MonthBack.binned,
                                woe.MortgageFlag_Cycle2_3MonthBack.binned,
                                woe.MortgageFlag_Cycle1_3MonthBack.binned,
                                woe.MortgageFlag_Cycle2plus_SP.binned,
                                woe.MortgageFlag_Cycle2_SP.binned,
                                woe.MortgageFlag_Cycle1_SP.binned,
                                woe.MortgageProduct_Cycle2plus_12MonthBack.binned,
                                woe.MortgageProduct_Cycle2_12MonthBack.binned,
                                woe.MortgageProduct_Cycle1_12MonthBack.binned,
                                woe.MortgageProduct_Cycle2plus_9MonthBack.binned,
                                woe.MortgageProduct_Cycle2_9MonthBack.binned,
                                woe.MortgageProduct_Cycle1_9MonthBack.binned,
                                woe.MortgageProduct_Cycle2plus_6MonthBack.binned,
                                woe.MortgageProduct_Cycle2_6MonthBack.binned,
                                woe.MortgageProduct_Cycle1_6MonthBack.binned,
                                woe.MortgageProduct_Cycle2plus_3MonthBack.binned,
                                woe.MortgageProduct_Cycle2_3MonthBack.binned,
                                woe.MortgageProduct_Cycle1_3MonthBack.binned,
                                woe.MortgageProduct_Cycle2plus_SP.binned,
                                woe.MortgageProduct_Cycle2_SP.binned,
                                woe.MortgageProduct_Cycle1_SP.binned,
                                woe.Cycle2plus_HarlandProduct_3MonthBack.binned,
                                woe.Cycle2_HarlandProduct_3MonthBack.binned,
                                woe.Cycle1_HarlandProduct_3MonthBack.binned,
                                woe.Cycle2plus_HarlandProduct_6MonthBack.binned,
                                woe.Cycle2_HarlandProduct_6MonthBack.binned,
                                woe.Cycle1_HarlandProduct_6MonthBack.binned,
                                woe.Cycle2plus_HarlandProduct_9MonthBack.binned,
                                woe.Cycle2_HarlandProduct_9MonthBack.binned,
                                woe.Cycle1_HarlandProduct_9MonthBack.binned,
                                woe.Cycle2plus_HarlandProduct_12MonthBack.binned,
                                woe.Cycle2_HarlandProduct_12MonthBack.binned,
                                woe.Cycle1_HarlandProduct_12MonthBack.binned,
                                woe.Cycle2plus_HarlandProduct_SP.binned,
                                woe.Cycle2_HarlandProduct_SP.binned,
                                woe.Cycle1_HarlandProduct_SP.binned,
                                woe.CC_Cycle2plusFlag_12MBack.binned,
                                woe.CC_Cycle2Flag_12MBack.binned,
                                woe.CC_Cycle1Flag_12MBack.binned,
                                woe.ProductCC_Cycle2plus_12MBack.binned,
                                woe.ProductCC_Cycle2_12MBack.binned,
                                woe.ProductCC_Cycle1_12MBack.binned,
                                woe.CC_Cycle2plusFlag_9MBack.binned,
                                woe.CC_Cycle2Flag_9MBack.binned,
                                woe.CC_Cycle1Flag_9MBack.binned,
                                woe.ProductCC_Cycle2plus_9MBack.binned,
                                woe.ProductCC_Cycle2_9MBack.binned,
                                woe.ProductCC_Cycle1_9MBack.binned,
                                woe.CC_Cycle2plusFlag_6MBack.binned,
                                woe.CC_Cycle2Flag_6MBack.binned,
                                woe.CC_Cycle1Flag_6MBack.binned,
                                woe.ProductCC_Cycle2plus_6MBack.binned,
                                woe.ProductCC_Cycle2_6MBack.binned,
                                woe.ProductCC_Cycle1_6MBack.binned,
                                woe.CC_Cycle2plusFlag_3MBack.binned,
                                woe.CC_Cycle2Flag_3MBack.binned,
                                woe.CC_Cycle1Flag_3MBack.binned,
                                woe.ProductCC_Cycle2plus_3MBack.binned,
                                woe.ProductCC_Cycle2_3MBack.binned,
                                woe.ProductCC_Cycle1_3MBack.binned,
                                woe.CC_Cycle2plusFlag_SP.binned,
                                woe.CC_Cycle2Flag_SP.binned,
                                woe.CC_Cycle1Flag_SP.binned,
                                woe.ProductCC_Cycle2plus_SP.binned,
                                woe.ProductCC_Cycle2_SP.binned,
                                woe.ProductCC_Cycle1_SP.binned,
                                woe.DelinquencyFlag_Cycle2plus_12MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2_12MonthBack.binned,
                                woe.DelinquencyFlag_Cycle1_12MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2plus_9MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2_9MonthBack.binned,
                                woe.DelinquencyFlag_Cycle1_9MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2plus_6MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2_6MonthBack.binned,
                                woe.DelinquencyFlag_Cycle1_6MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2plus_3MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2_3MonthBack.binned,
                                woe.DelinquencyFlag_Cycle1_3MonthBack.binned,
                                woe.DelinquencyFlag_Cycle2plus_SP.binned,
                                woe.DelinquencyFlag_Cycle2_SP.binned,
                                woe.DelinquencyFlag_Cycle1_SP.binned,
                                woe.DelinquencyProduct_Cycle2plus_12MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2_12MonthBack.binned,
                                woe.DelinquencyProduct_Cycle1_12MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2plus_9MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2_9MonthBack.binned,
                                woe.DelinquencyProduct_Cycle1_9MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2plus_6MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2_6MonthBack.binned,
                                woe.DelinquencyProduct_Cycle1_6MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2plus_3MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2_3MonthBack.binned,
                                woe.DelinquencyProduct_Cycle1_3MonthBack.binned,
                                woe.DelinquencyProduct_Cycle2plus_SP.binned,
                                woe.DelinquencyProduct_Cycle2_SP.binned,
                                woe.DelinquencyProduct_Cycle1_SP.binned,
                                RISK_TARGET))
dim(df101) # 205

# Random Forest


library(randomForest)
library(e1071)
library(caret)
library(ROCR)
set.seed(2023)

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

RF_RISKupdated <- randomForest(RISK_TARGET ~.,data = df101,ntree=50)
Important_vr_updated <- importance(RF_RISKupdated)
write.csv(Important_vr_updated,"New Updated Important Variables for Member Risk Model.csv")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

# Stepwise Regression

library(My.stepwise)
library(carData)
library(car)
library(blorr)

# Iteration 101 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list101 = colnames(subset(df101,select = - RISK_TARGET))
stepwise_101 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list101, data = df101, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg101 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                   woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                   woe.RevolvingBalance_CC_Q1.binned + woe.OpenTradeCount.binned + 
                   woe.FICO_Staticpool.binned + woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + 
                   woe.VehicleLoan_Cycle2plusFlag_12MonthBack.binned + woe.CC_Cycle2plusFlag_12MBack.binned + 
                   woe.MortgageFlag_Cycle2plus_12MonthBack.binned, family = binomial(logit), 
                 data = df101)
a101 = Anova(log_reg101,type = "II",test="Wald")
v101 = vif(log_reg101)
write.csv(a101,"ANOVA.csv")
write.csv(v101,"VIF.csv")
summary(log_reg101)

# woe.VehicleLoan_Cycle2plusFlag_12MonthBack.binned has negative estimate.

df102 = subset(df101,select=-c(woe.VehicleLoan_Cycle2plusFlag_12MonthBack.binned,woe.FICO_Staticpool.binned))
dim(df102) # 203


# Iteration 102 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list102 = colnames(subset(df102,select = - RISK_TARGET))
stepwise_102 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list102, data = df102, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg102 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                   woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                   woe.RevolvingBalance_CC_Q1.binned + woe.OpenTradeCount.binned + 
                   woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + woe.VehicleLoan_Cycle2Flag_12MonthBack.binned + 
                   woe.CC_Cycle2plusFlag_12MBack.binned + woe.MortgageFlag_Cycle2plus_12MonthBack.binned, 
                 family = binomial(logit), data = df102)
a102 = Anova(log_reg102,type="II",test="Wald")
v102 = vif(log_reg102)
write.csv(a102,"ANOVA.csv")
write.csv(v102,"VIF.csv")
summary(log_reg102)

# woe.VehicleLoan_Cycle2Flag_12MonthBack.binned has negative estimate.

df103 = subset(df102,select=-woe.VehicleLoan_Cycle2Flag_12MonthBack.binned)
dim(df103) # 202

# Iteration 103 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list103 = colnames(subset(df103,select = - RISK_TARGET))
stepwise_103 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list103, data = df103, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

log_reg103 = glm(formula = RISK_TARGET ~ woe.FICO.binned + woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                   woe.MAX_INTERESTRATE_Loan_Q1.binned + woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                   woe.RevolvingBalance_CC_Q1.binned + woe.OpenTradeCount.binned + 
                   woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned + woe.VehicleLoan_Cycle1Flag_12MonthBack.binned + 
                   woe.CC_Cycle2plusFlag_12MBack.binned + woe.MortgageFlag_Cycle2plus_12MonthBack.binned, 
                 family = binomial(logit), data = df103)
summary(log_reg103)

# woe.VehicleLoan_Cycle1Flag_12MonthBack.binned has negative estimate

df104 = subset(df103,select = -c(woe.VehicleLoan_Cycle1Flag_12MonthBack.binned,
                                 woe.VehicleLoan_Cycle2plusFlag_9MonthBack.binned,
                                 woe.VehicleLoan_Cycle2Flag_9MonthBack.binned,
                                 woe.VehicleLoan_Cycle1Flag_9MonthBack.binned,
                                 woe.VehicleLoan_Cycle2plusFlag_6MonthBack.binned,
                                 woe.VehicleLoan_Cycle2Flag_6MonthBack.binned,
                                 woe.VehicleLoan_Cycle1Flag_6MonthBack.binned,
                                 woe.VehicleLoan_Cycle2plusFlag_3MonthBack.binned,
                                 woe.VehicleLoan_Cycle2Flag_3MonthBack.binned,
                                 woe.VehicleLoan_Cycle1Flag_3MonthBack.binned,
                                 woe.VehicleLoan_Cycle2plusFlag_SP.binned,
                                 woe.VehicleLoan_Cycle2Flag_SP.binned,
                                 woe.VehicleLoan_Cycle1Flag_SP.binned,
                                 woe.UnsecuredLoan_Cycle2plusFlag_12MonthBack.binned,
                                 woe.UnsecuredLoan_Cycle2Flag_12MonthBack.binned,
                                 woe.UnsecuredLoan_Cycle1Flag_12MonthBack.binned,
                                 woe.UnsecuredLoan_Cycle2plusFlag_9MonthBack.binned,
                                 woe.UnsecuredLoan_Cycle2Flag_9MonthBack.binned,
                                 woe.UnsecuredLoan_Cycle1Flag_9MonthBack.binned,
                                 woe.UnsecuredLoan_Cycle2plusFlag_6MonthBack.binned,
                                 woe.UnsecuredLoan_Cycle2Flag_6MonthBack.binned,
                                 woe.UnsecuredLoan_Cycle1Flag_6MonthBack.binned,
                                 woe.UnsecuredLoan_Cycle2plusFlag_3MonthBack.binned,
                                 woe.UnsecuredLoan_Cycle2Flag_3MonthBack.binned,
                                 woe.UnsecuredLoan_Cycle1Flag_3MonthBack.binned,
                                 woe.UnsecuredLoan_Cycle2plusFlag_SP.binned,
                                 woe.UnsecuredLoan_Cycle2Flag_SP.binned,
                                 woe.UnsecuredLoan_Cycle1Flag_SP.binned,
                                 woe.SecuredLoan_Cycle2plusFlag_12MonthBack.binned,
                                 woe.SecuredLoan_Cycle2Flag_12MonthBack.binned,
                                 woe.SecuredLoan_Cycle1Flag_12MonthBack.binned,
                                 woe.SecuredLoan_Cycle2plusFlag_9MonthBack.binned,
                                 woe.SecuredLoan_Cycle2Flag_9MonthBack.binned,
                                 woe.SecuredLoan_Cycle1Flag_9MonthBack.binned,
                                 woe.SecuredLoan_Cycle2plusFlag_6MonthBack.binned,
                                 woe.SecuredLoan_Cycle2Flag_6MonthBack.binned,
                                 woe.SecuredLoan_Cycle1Flag_6MonthBack.binned,
                                 woe.SecuredLoan_Cycle2plusFlag_3MonthBack.binned,
                                 woe.SecuredLoan_Cycle2Flag_3MonthBack.binned,
                                 woe.SecuredLoan_Cycle1Flag_3MonthBack.binned,
                                 woe.SecuredLoan_Cycle2plusFlag_SP.binned,
                                 woe.SecuredLoan_Cycle2Flag_SP.binned,
                                 woe.SecuredLoan_Cycle1Flag_SP.binned,
                                 woe.ProductVehicleLoan_Cycle2plus_12MonthBack.binned,
                                 woe.ProductVehicleLoan_Cycle2_12MonthBack.binned,
                                 woe.ProductVehicleLoan_Cycle1_12MonthBack.binned,
                                 woe.ProductVehicleLoan_Cycle2plus_9MonthBack.binned,
                                 woe.ProductVehicleLoan_Cycle2_9MonthBack.binned,
                                 woe.ProductVehicleLoan_Cycle1_9MonthBack.binned,
                                 woe.ProductVehicleLoan_Cycle2plus_6MonthBack.binned,
                                 woe.ProductVehicleLoan_Cycle2_6MonthBack.binned,
                                 woe.ProductVehicleLoan_Cycle1_6MonthBack.binned,
                                 woe.ProductVehicleLoan_Cycle2plus_3MonthBack.binned,
                                 woe.ProductVehicleLoan_Cycle2_3MonthBack.binned,
                                 woe.ProductVehicleLoan_Cycle1_3MonthBack.binned,
                                 woe.ProductVehicleLoan_Cycle2plus_SP.binned,
                                 woe.ProductVehicleLoan_Cycle2_SP.binned,
                                 woe.ProductVehicleLoan_Cycle1_SP.binned,
                                 woe.ProductUnsecuredLoan_Cycle2plus_12MonthBack.binned,
                                 woe.ProductUnsecuredLoan_Cycle2_12MonthBack.binned,
                                 woe.ProductUnsecuredLoan_Cycle1_12MonthBack.binned,
                                 woe.ProductSecuredLoan_Cycle2plus_12MonthBack.binned,
                                 woe.ProductSecuredLoan_Cycle2_12MonthBack.binned,
                                 woe.ProductSecuredLoan_Cycle1_12MonthBack.binned,
                                 woe.ProductUnsecuredLoan_Cycle2plus_9MonthBack.binned,
                                 woe.ProductUnsecuredLoan_Cycle2_9MonthBack.binned,
                                 woe.ProductUnsecuredLoan_Cycle1_9MonthBack.binned,
                                 woe.ProductSecuredLoan_Cycle2plus_9MonthBack.binned,
                                 woe.ProductSecuredLoan_Cycle2_9MonthBack.binned,
                                 woe.ProductSecuredLoan_Cycle1_9MonthBack.binned,
                                 woe.ProductUnsecuredLoan_Cycle2plus_6MonthBack.binned,
                                 woe.ProductUnsecuredLoan_Cycle2_6MonthBack.binned,
                                 woe.ProductUnsecuredLoan_Cycle1_6MonthBack.binned,
                                 woe.ProductSecuredLoan_Cycle2plus_6MonthBack.binned,
                                 woe.ProductSecuredLoan_Cycle2_6MonthBack.binned,
                                 woe.ProductSecuredLoan_Cycle1_6MonthBack.binned,
                                 woe.ProductUnsecuredLoan_Cycle2plus_3MonthBack.binned,
                                 woe.ProductUnsecuredLoan_Cycle2_3MonthBack.binned,
                                 woe.ProductUnsecuredLoan_Cycle1_3MonthBack.binned,
                                 woe.ProductSecuredLoan_Cycle2plus_3MonthBack.binned,
                                 woe.ProductSecuredLoan_Cycle2_3MonthBack.binned,
                                 woe.ProductSecuredLoan_Cycle1_3MonthBack.binned,
                                 woe.ProductUnsecuredLoan_Cycle2plus_SP.binned,
                                 woe.ProductUnsecuredLoan_Cycle2_SP.binned,
                                 woe.ProductUnsecuredLoan_Cycle1_SP.binned,
                                 woe.ProductSecuredLoan_Cycle2plus_SP.binned,
                                 woe.ProductSecuredLoan_Cycle2_SP.binned,
                                 woe.ProductSecuredLoan_Cycle1_SP.binned,
                                 woe.Cycle2plus_HarlandProduct_3MonthBack.binned,
                                 woe.Cycle2_HarlandProduct_3MonthBack.binned,
                                 woe.Cycle1_HarlandProduct_3MonthBack.binned,
                                 woe.Cycle2plus_HarlandProduct_6MonthBack.binned,
                                 woe.Cycle2_HarlandProduct_6MonthBack.binned,
                                 woe.Cycle1_HarlandProduct_6MonthBack.binned,
                                 woe.Cycle2plus_HarlandProduct_9MonthBack.binned,
                                 woe.Cycle2_HarlandProduct_9MonthBack.binned,
                                 woe.Cycle1_HarlandProduct_9MonthBack.binned,
                                 woe.Cycle2plus_HarlandProduct_12MonthBack.binned,
                                 woe.Cycle2_HarlandProduct_12MonthBack.binned,
                                 woe.Cycle1_HarlandProduct_12MonthBack.binned,
                                 woe.Cycle2plus_HarlandProduct_SP.binned,
                                 woe.Cycle2_HarlandProduct_SP.binned,
                                 woe.Cycle1_HarlandProduct_SP.binned))
dim(df104) # 99

# Iteration 104 :

sleep_func <- function() { Sys.sleep(5) } 
startTime <- Sys.time()

variable_list104 = colnames(subset(df104,select = - RISK_TARGET))
stepwise_104 <- My.stepwise.glm(Y = "RISK_TARGET", variable_list104, data = df104, sle = 0.05,sls = 0.05, myfamily="binomial")

sleep_func()
endTime <- Sys.time()

# prints recorded time
print(endTime - startTime)

write.csv(colnames(df104),"DELQ.csv")

log_reg104 = glm(formula = RISK_TARGET ~ woe.FICO_Staticpool.binned +
                   # woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                   woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                   woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                   woe.RevolvingBalance_CC_Q1.binned +
                   woe.OpenTradeCount.binned + 
                   woe.ProductCC_Cycle2plus_3MBack.binned+
                   # woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned+
                   # woe.DelinquencyFlag_Cycle2plus_SP.binned +
                   # woe.CC_Cycle2Flag_SP.binned+
                   woe.MortgageFlag_Cycle2_SP.binned
                 , family = binomial(logit), 
                 data = df_woe)

a104 = Anova(log_reg104,type="II",test="Wald")
v104 = vif(log_reg104)
write.csv(a104,"ANOVA.csv")
write.csv(v104,"VIF.csv")
summary(log_reg104)
blr_gains_table(log_reg104,df_woe)

org104 = glm(formula = RISK_TARGET ~ FICO_Staticpool+
                   # Diff_Due_Payment_Vehicle_Staticpool + 
                     ProductCC_Cycle2plus_3MBack+
                   MAX_INTERESTRATE_Loan_Q1 + 
                   DFT_COUNT_LOAN_ADDON_H1_H2 + 
                   RevolvingBalance_CC_Q1 +
                   OpenTradeCount + 
                   # DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2+
                   # CC_Cycle2Flag_SP+
                   # DelinquencyFlag_Cycle2plus_SP+
                   MortgageFlag_Cycle2_SP
                 , family = binomial(logit), 
                 data = NAReplace_train)
summary(org104)
o104 = vif(org104)
write.csv(o104,"VIF.csv")
df_test = subset(RISK_test,select=c(RISK_TARGET,
                                     FICO_Staticpool,
                   ProductCC_Cycle2plus_3MBack,
                   MAX_INTERESTRATE_Loan_Q1 ,
                   DFT_COUNT_LOAN_ADDON_H1_H2 ,
                   RevolvingBalance_CC_Q1 ,
                   OpenTradeCount , 
                   MortgageFlag_Cycle2_SP))
write.csv(test_woe,"test.csv")
NAReplace_test <- replace(df_test,is.na(df_test),-9999999)
sum(is.na(NAReplace_test)) 

install.packages("woeBinning")
library(woeBinning)

RISK_binning_test <- woe.binning(NAReplace_test,'RISK_TARGET',NAReplace_test)
test_woe <- woe.binning.deploy(NAReplace_test,RISK_binning_test,add.woe.or.dum.var = "woe")
library(blorr)
blr_gains_table(log_reg104,test_woe)
test_woe$RISK_TARGET = as.factor(test_woe$RISK_TARGET)

a = predict(log_reg104,newdata = test_woe)

# Iteration 105

log_reg105 = glm(formula = RISK_TARGET ~ woe.FICO_Staticpool.binned +
                   # woe.Diff_Due_Payment_Vehicle_Staticpool.binned + 
                   woe.MAX_INTERESTRATE_Loan_Q1.binned + 
                   woe.DFT_COUNT_LOAN_ADDON_H1_H2.binned + 
                   woe.RevolvingBalance_CC_Q1.binned +
                   woe.OpenTradeCount.binned + 
                   # woe.ProductCC_Cycle2plus_3MBack.binned+
                   # woe.DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2.binned+
                   # woe.DelinquencyFlag_Cycle2plus_SP.binned +
                   # woe.CC_Cycle2Flag_SP.binned+
                   woe.MortgageFlag_Cycle2_SP.binned
                 , family = binomial(logit), 
                 data = df_woe)

a105 = Anova(log_reg105,type="II",test="Wald")
v105 = vif(log_reg105)
write.csv(a105,"ANOVA.csv")
write.csv(v105,"VIF.csv")
summary(log_reg105)
blr_gains_table(log_reg105,df_woe)

org105 = glm(formula = RISK_TARGET ~ FICO_Staticpool+
               # Diff_Due_Payment_Vehicle_Staticpool + 
               # ProductCC_Cycle2plus_3MBack+
               MAX_INTERESTRATE_Loan_Q1 + 
               DFT_COUNT_LOAN_ADDON_H1_H2 + 
               RevolvingBalance_CC_Q1 +
               OpenTradeCount + 
               MortgageFlag_Cycle2_SP
             , family = binomial(logit), 
             data = NAReplace_train)
summary(org105)
o105 = vif(org105)
write.csv(o105,"VIF.csv")
df_test = subset(RISK_test,select=c(RISK_TARGET,
                                    FICO_Staticpool,
                                    ProductCC_Cycle2plus_3MBack,
                                    MAX_INTERESTRATE_Loan_Q1 ,
                                    DFT_COUNT_LOAN_ADDON_H1_H2 ,
                                    RevolvingBalance_CC_Q1 ,
                                    OpenTradeCount , 
                                    MortgageFlag_Cycle2_SP))
write.csv(test_woe,"test.csv")
NAReplace_test <- replace(df_test,is.na(df_test),-9999999)
sum(is.na(NAReplace_test)) 

install.packages("woeBinning")
library(woeBinning)

RISK_binning_test <- woe.binning(NAReplace_test,'RISK_TARGET',NAReplace_test)
test_woe <- woe.binning.deploy(NAReplace_test,RISK_binning_test,add.woe.or.dum.var = "woe")
library(blorr)
blr_gains_table(log_reg105,test_woe)
test_woe$RISK_TARGET = as.factor(test_woe$RISK_TARGET)

a = predict(log_reg105,newdata = test_woe)
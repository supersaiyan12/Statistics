
                                                              ------------------------------------
													      	   /****** Member Risk Model ******/
														    ---------------------------------------

--/****************************************************************************************************/
--/*       NOTES BEFORE USING THIS CODE                                                               */
--/*                                                                                                  */
--/*       EXCLUSION *                                                                                */
--/*      Workout & Writeoff (add it back in case you're using for Attrition)                         */
--/*                                                                                                  */
--/*                                                                                                  */
--/*      Included all IRA types (IRA Money Market , IRA Checking) execept "IRA SAVING"				  */
--/*      Included HSA                                                                                */                                                                                                 */
--/*                                                                                                  */
--/*                                                                                                  */
--/*      6 Months half before SP : H1                                                                */                                                                                                  */
--/*      12 Months half before SP : H2                                                               */
--/*                                                                                                  */
--/*      Line NO : 674 DFT_DUEPAYMENTDAYS                                                            */
--/*                                                                                                  */
--/*                                                                                                  */                                                                                                  */
--/*                                                                                                  */
--/*                                                                                                  */
--/*                                                                                                  */
--/****************************************************************************************************/

       --Declaring the STATIC POOL

		DECLARE @staticpooldate date
		set @staticpooldate = '2022-06-30'

		declare @staticcreditdate date
		set  @staticcreditdate = '2022-06-01' -- fullextractdate in format '2022-06-01'
		--SELECT @staticcreditdate

		--Taking Member Having General membership of Greenstate

		drop table if exists #Name
		select distinct a.PARENTACCOUNT,SSN 
		into #NAME
		from 
		(select *,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date from ARCUSYM000.dbo.NAME) a
		left join ARCUSYM000.dbo.SAVINGS b
		on a.PARENTACCOUNT=b.PARENTACCOUNT
		and a.ProcessDate=b.ProcessDate
		where a.TYPE=0
		and a.Process_date=@staticpooldate
		
		
		---- SAVING ACCOUNTS DETAIL
		 drop table if exists #Static_SSN_account_final
		select distinct  SSN 
		--,PARENTACCOUNT,Process_date
		into #Static_SSN_account_final
		from
		(    
			select  b.SSN
					,a.PARENTACCOUNT
					,id
					,cast(OPENDATE as date) OPEN_DATE
					,cast(CLOSEDATE as date) CLOSE_DATE
					,cast(CHARGEOFFDATE as date) CHARGEOFFDATE
					,left(a.ProcessDate,6) ProcessDate_V
					,datefromparts(left(a.ProcessDate ,4),right(left(a.ProcessDate,6),2),right(a.ProcessDate,2)) Process_date
					,case when len(month(closedate))=1 then CONCAT(year(closedate),0,month(closedate)) 
						  else CONCAT(year(closedate),month(closedate)) end CLOSED_DATE_SAVINGS 
					,case when len(month(OpenDate))=1 then CONCAT(year(OpenDate),0,month(OpenDate)) 
					      else CONCAT(year(OpenDate),month(OpenDate))end  OPEN_DATE_INT_SAVINGS
					,case when len(month(CHARGEOFFDATE))=1 then CONCAT(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE)) 
					      else CONCAT(year(CHARGEOFFDATE),month(CHARGEOFFDATE))end  CHARGEOFF_DATE_SAVINGS
		
			from ARCUSYM000.dbo.SAVINGS a
			left join #NAME b 
			on a.PARENTACCOUNT=b.PARENTACCOUNT
		) aa
		where ssn is not null 
			and OPEN_DATE<@staticpooldate  
			and (CLOSE_DATE is null or CLOSE_DATE>@staticpooldate)
			and (CHARGEOFFDATE is null or CHARGEOFFDATE>@staticpooldate)  
			and Process_date=@staticpooldate 
		
		
		-- Re-Naming ParentAccount to account name
		drop table if exists #Static_SSN_account
			select distinct 
				PARENTACCOUNT AccountNumber
				,SSN
			into #Static_SSN_account
			from #NAME

        ------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Loan Membership Master Data ***\\\-------------------------------------------------------------------
			 drop table if exists #membership_loan

		--DECLARE @staticpooldate date
		--set @staticpooldate = '2022-06-30'
			
			--select distinct parentaccount from #commercial_loan
              select *
				,case when  (LoanCategory1 like 'commercial%')
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then  'Commercial_loan'
                 --when LoanCategory3 = '1st Mortgage'
				 --and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 --and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 --then 'Real_Estate_loan1'
				 --when LoanCategory3 = '2nd Mortgage'
				 --and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 --and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 --then 'Real_Estate_loan2'
				 when LoanCategory3 in ('1st Mortgage','2nd Mortgage')
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then 'Real_Estate_loan'
                when LoanCategory3 = 'Secured'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then 'SecuredLoan' 
                when LoanCategory3 = 'Unsecured'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				  then 'UnsecuredLoan' 
				when LoanCategory2 ='Vehicle'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				  then 'Vehicleloan' else 'Others' end as Product_Flag
           into #membership_loan
			from
			(
					select [ProcessDate]
						   ,left(ProcessDate,6) ProcessDate_V
						   ,Process_Date
						   ,Open_date
						   ,Close_date
						   ,case when Process_Date in ((EOMONTH(DATEADD(month,-12,@staticpooldate))),(EOMONTH(DATEADD(month,-11,@staticpooldate))),(EOMONTH(DATEADD(month,-10,@staticpooldate )))) then 'Q4'
		                         when Process_Date in ((EOMONTH(DATEADD(month,-9,@staticpooldate ))),(EOMONTH(DATEADD(month,-8,@staticpooldate))),(EOMONTH(DATEADD(month,-7,@staticpooldate)))) then 'Q3'
 								 when Process_Date in ((EOMONTH(DATEADD(month,-6,@staticpooldate ))),(EOMONTH(DATEADD(month,-5,@staticpooldate))),(EOMONTH(DATEADD(month,-4,@staticpooldate)))) then 'Q2'
								 when Process_Date in ((EOMONTH(DATEADD(month,-3,@staticpooldate))),(EOMONTH(DATEADD(month,-2,@staticpooldate ))),(EOMONTH(DATEADD(month,-1,@staticpooldate )))) then 'Q1'
								 when Process_Date in (@staticpooldate) then 'Staticpool'
							end Quarters
							,case when Process_Date in (EOMONTH(DATEADD(month,-12,@staticpooldate)),(EOMONTH(DATEADD(month,-11,@staticpooldate))),(EOMONTH(DATEADD(month,-10,@staticpooldate))) 
							                           ,(EOMONTH(DATEADD(month,-9,@staticpooldate ))),(EOMONTH(DATEADD(month,-8,@staticpooldate))),(EOMONTH(DATEADD(month,-7,@staticpooldate)))) then 'H2'
 								  when Process_Date in (EOMONTH(DATEADD(month,-6,@staticpooldate )),(EOMONTH(DATEADD(month,-5,@staticpooldate))),(EOMONTH(DATEADD(month,-4,@staticpooldate)))
								                      ,(EOMONTH(DATEADD(month,-3,@staticpooldate))),(EOMONTH(DATEADD(month,-2,@staticpooldate ))),(EOMONTH(DATEADD(month,-1,@staticpooldate )))) then 'H1'
							end HalfYearly
							,d.SSN
							,[PARENTACCOUNT]
							,[ID]
							,rtrim(Ltrim(CONCAT(PARENTACCOUNT,ID))) UNID
							,case when len(month(a.closedate))=1 then CONCAT(year(a.closedate),0,month(a.closedate))
							      else CONCAT(year(a.closedate),month(a.closedate)) end  Closed_date_INT
							,case when len(month(a.opendate))=1 then CONCAT(year(a.opendate),0,month(a.opendate))
							      else CONCAT(year(a.opendate),month(a.opendate)) end  OPEN_date_INT
							,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
							,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
							,[TYPE]
							,[LASTFMDATE]
							,[LASTTRANDATE]
							,[ORIGINALDATE]
							,a.[OPENDATE]
							,a.[CLOSEDATE]
							,[LOANCODE]
							,[APPROVALCODE]
							,[APPROVALDATE]
							,[PAYMENTFREQUENCY]
							,[PARTIALPAYMENT]
							,[PAYMENT]
							,[PAYMENTCOUNT]
							,[DUEDAY1]
							,[DUEDAY2]
							,[INTERESTRATE]
							,[ORIGINALBALANCE]
							,BALANCE
							,[CREDITLIMIT]
							,[DESCRIPTION]
							,[NSFMONTHTODATE]
							,[MATURITYDATE]
							,[APR]
							,[CREDITSCORE]
							,LASTPAYMENTDATE
							,DUEDATE
							,abs(day(DUEDATE)-day(LASTPAYMENTDATE)) DFT_DUEPAYMENTDAYS
							,abs(day(DUEDATE)-day(@staticpooldate)) DAYSINCEDUEDATE
							--,(BALANCE/CREDITLIMIT) [UTILIZATION_RATE]
							,[ADVANCEAMOUNT]
							,b.LoanCategory1
							,b.LoanCategory2
							,b.LoanCategory3
							,b.LoanCategory4
							,b.LoanCategory5
							,b.LoanTypeDescription
							,CRPMTCURRENT
							,CHARGEOFFAMOUNT
							,PAYMENTSKIPS
					  from 
					 (
						 select * 
						 ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
						 ,cast(OPENDATE as date) Open_date
						 ,cast(CLOSEDATE as date) Close_date,cast(MATURITYDATE as date) as MATURITY_DATE 
						 from ARCUSYM000.dbo.LOAN 
				     ) a
			
					left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
					on b.loantype=a.TYPE
					left join  #Static_SSN_account d
					on a.PARENTACCOUNT=d.AccountNumber
					where  ORIGINALDATE is not null 
					and a.OpenDate is not null and a.Open_date < @staticpooldate  
					and (a.CLOSEDATE is null or a.Close_date>@staticpooldate )   
					and process_date between (select EOMONTH(dateadd(MM,-12,@staticpooldate))) and (select EOMONTH(dateadd(MM,12,@staticpooldate))) 
					and  PARENTACCOUNT in (select distinct AccountNumber PARENTACCOUNT from #Static_SSN_account )
		) AA
		where		LoanCategory3 not in ('Writeoff','Workout/TDR')
				    and LoanCategory4 not in ('Writeoff','Workout/TDR')
					and OPEN_DATE<@staticpooldate
					and (Close_date is null or Close_date>@staticpooldate) 
					and ORIGINALDATE <= Open_date 
					and Quarters is not null
					 

			 --SELECT SSN, QUARTERS ,Product_Flag 
			 --          ,CASE WHEN MAX(CRPMTCURRENT) = 0 THEN 'GOOD STANDING'
			 --             WHEN MAX(CRPMTCURRENT) = 1 THEN 'CYCLE 1'
			 --             WHEN MAX(CRPMTCURRENT) = 2 THEN 'CYCLE 2'
			 --             WHEN MAX(CRPMTCURRENT) > 2 THEN 'CYCLE 2PLUS'
			 --             ELSE 'OTHERS' END DELINQUENCY_STATUS		
				--		  FROM
				--		  (SELECT * FROM #membership_loan) A
				--		  GROUP BY SSN, QUARTERS ,Product_Flag
		--SELECT count( ssn) FROM #membership_loan  -- 152347 out of 1944047 (On an Average Each member holds 12 product)

		-- SSN having loan accounts except  Credit Cards

		DROP TABLE IF EXISTS #loan_woCC

		SELECT DISTINCT SSN
		INTO #loan_woCC
		FROM #membership_loan -- 152345

-- Derived variables for product holdings for loan variables without Credit Card

		DROP TABLE IF EXISTS #loan_product_holdings
		--SELECT DISTINCT QUARTERS FROM #membership_loan
		--SELECT DISTINCT Product_Flag FROM #membership_loan
		SELECT SSN [SSN001]
			   --,#Products_CommercialLoan_Q1 [PRODUCT_CommercialLoan_Q1]
			   --,CASE WHEN (#Products_CommercialLoan_Q1 IS NULL AND #Products_CommercialLoan_Q2 IS  NULL) THEN #Products_CommercialLoan_Q1 else (ISNULL(#Products_CommercialLoan_Q1,0) - ISNULL(#Products_CommercialLoan_Q2,0)) end [DFT_PRODUCT_CommercialLoan_Q1_Q2]

			   ,#Products_RealEstate_Q1 [PRODUCT_RealEstate_Q1]
			   ,CASE WHEN (#Products_RealEstate_Q1 IS NULL AND #Products_RealEstate_Q2 IS  NULL) THEN #Products_RealEstate_Q1 else (ISNULL(#Products_RealEstate_Q1,0) - ISNULL(#Products_RealEstate_Q2,0)) end [DFT_PRODUCT_RealEstate_Q1_Q2]

			   ,#Products_SecuredLoan_Q1 [PRODUCT_SecuredLoan_Q1]
			   ,CASE WHEN (#Products_SecuredLoan_Q1 IS NULL AND #Products_SecuredLoan_Q2 IS  NULL) THEN #Products_SecuredLoan_Q1 else (ISNULL(#Products_SecuredLoan_Q1,0) - ISNULL(#Products_SecuredLoan_Q2,0)) end [DFT_PRODUCT_SecuredLoan_Q1_Q2]
			   
			   ,#Products_UnsecuredLoan_Q1 [PRODUCT_UnsecuredLoan_Q1]
			   ,CASE WHEN (#Products_UnsecuredLoan_Q1 IS NULL AND #Products_UnsecuredLoan_Q2 IS  NULL) THEN #Products_UnsecuredLoan_Q1 else (ISNULL(#Products_UnsecuredLoan_Q1,0) - ISNULL(#Products_UnsecuredLoan_Q2,0)) end [DFT_PRODUCT_UnsecuredLoan_Q1_Q2]
			   
			   ,#Products_VehicleLoan_Q1 [PRODUCT_VehicleLoan_Q1]
			   ,CASE WHEN (#Products_VehicleLoan_Q1 IS NULL AND #Products_VehicleLoan_Q2 IS  NULL) THEN #Products_VehicleLoan_Q1 else (ISNULL(#Products_VehicleLoan_Q1,0) - ISNULL(#Products_VehicleLoan_Q2,0)) end [DFT_PRODUCT_VehicleLoan_Q1_Q2]

			   ,CASE WHEN (#Products_Loan_Q1 IS NULL AND #Products_Loan_Q2 IS  NULL) THEN #Products_Loan_Q1 else (ISNULL(#Products_Loan_Q1,0) - ISNULL(#Products_Loan_Q2,0)) end [DFT_PRODUCT_Loan_Q1_Q2]

				--,[CommercialLoan_MOB]
				,[RealEstate_MOB]
				,[SecuredLoan_MOB]
				,[UnsecuredLoan_MOB]
				,[Vehicleloan_MOB]
				--,[Others_MOB]
				,MAX_Loan_MOB

			   --,PAYMENTCOUNT_CommercialLoan_Q1 [PAYMENTCOUNT_CommercialLoan_Q1]
			   --,CASE WHEN (PAYMENTCOUNT_CommercialLoan_Q1 IS NULL AND PAYMENTCOUNT_CommercialLoan_Q2 IS  NULL) THEN PAYMENTCOUNT_CommercialLoan_Q1 else (ISNULL(PAYMENTCOUNT_CommercialLoan_Q1,0) - ISNULL(PAYMENTCOUNT_CommercialLoan_Q2,0)) end [DFT_PAYMENTCOUNT_CommercialLoan_Q1_Q2]
               
			   ,PAYMENTCOUNT_RealEstate_Q1 [PAYMENTCOUNT_RealEstate_Q1]
			   ,CASE WHEN (PAYMENTCOUNT_RealEstate_Q1 IS NULL AND PAYMENTCOUNT_RealEstate_Q2 IS  NULL) THEN PAYMENTCOUNT_RealEstate_Q1 else (ISNULL(PAYMENTCOUNT_RealEstate_Q1,0) - ISNULL(PAYMENTCOUNT_RealEstate_Q2,0)) end [DFT_PAYMENTCOUNT_RealEstate_Q1_Q2]

			   ,PAYMENTCOUNT_SecuredLoan_Q1 [PAYMENTCOUNT_SecuredLoan_Q1]
			   ,CASE WHEN (PAYMENTCOUNT_SecuredLoan_Q1 IS NULL AND PAYMENTCOUNT_SecuredLoan_Q2 IS  NULL) THEN PAYMENTCOUNT_SecuredLoan_Q1 else (ISNULL(PAYMENTCOUNT_SecuredLoan_Q1,0) - ISNULL(PAYMENTCOUNT_SecuredLoan_Q2,0)) end [DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q2]

               ,PAYMENTCOUNT_UnsecuredLoan_Q1 [PAYMENTCOUNT_UnsecuredLoan_Q1]
			   ,CASE WHEN (PAYMENTCOUNT_UnsecuredLoan_Q1 IS NULL AND PAYMENTCOUNT_UnsecuredLoan_Q2 IS  NULL) THEN PAYMENTCOUNT_UnsecuredLoan_Q1 else (ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q1,0) - ISNULL(PAYMENTCOUNT_UnsecuredLoan_Q2,0)) end [DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q2]

			   ,PAYMENTCOUNT_VehicleLoan_Q1 [PAYMENTCOUNT_VehicleLoan_Q1]
			   ,CASE WHEN (PAYMENTCOUNT_VehicleLoan_Q1 IS NULL AND PAYMENTCOUNT_VehicleLoan_Q2 IS  NULL) THEN PAYMENTCOUNT_VehicleLoan_Q1 else (ISNULL(PAYMENTCOUNT_VehicleLoan_Q1,0) - ISNULL(PAYMENTCOUNT_VehicleLoan_Q2,0)) end [DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q2]

			   ,PAYMENTCOUNT_Loan_Q1 [PAYMENTCOUNT_Loan_Q1]
			   ,CASE WHEN (PAYMENTCOUNT_Loan_Q1 IS NULL AND PAYMENTCOUNT_Loan_Q2 IS  NULL) THEN PAYMENTCOUNT_Loan_Q1 else (ISNULL(PAYMENTCOUNT_Loan_Q1,0) - ISNULL(PAYMENTCOUNT_Loan_Q2,0)) end [DFT_PAYMENTCOUNT_Loan_Q1_Q2]

			   --,SUM_OriginalBalance_CommercialLoan_Q1 [SUM_OriginalBalance_CommercialLoan_Q1]
			   --,CASE WHEN (SUM_OriginalBalance_CommercialLoan_Q1 IS NULL AND SUM_OriginalBalance_CommercialLoan_Q2 IS  NULL) THEN SUM_OriginalBalance_CommercialLoan_Q1 else (ISNULL(SUM_OriginalBalance_CommercialLoan_Q1,0) - ISNULL(SUM_OriginalBalance_CommercialLoan_Q2,0)) end [DFT_SUM_OriginalBalance_CommercialLoan_Q1_Q2]

			   ,SUM_OriginalBalance_RealEstate_Q1 [SUM_OriginalBalance_RealEstate_Q1]
			   ,CASE WHEN (SUM_OriginalBalance_RealEstate_Q1 IS NULL AND SUM_OriginalBalance_RealEstate_Q2 IS  NULL) THEN SUM_OriginalBalance_RealEstate_Q1 else (ISNULL(SUM_OriginalBalance_RealEstate_Q1,0) - ISNULL(SUM_OriginalBalance_RealEstate_Q2,0)) end [DFT_SUM_OriginalBalance_RealEstate_Q1_Q2]

			   ,SUM_OriginalBalance_SecuredLoan_Q1 [SUM_OriginalBalance_SecuredLoan_Q1]
			   ,CASE WHEN (SUM_OriginalBalance_SecuredLoan_Q1 IS NULL AND SUM_OriginalBalance_SecuredLoan_Q2 IS  NULL) THEN SUM_OriginalBalance_SecuredLoan_Q1 else (ISNULL(SUM_OriginalBalance_SecuredLoan_Q1,0) - ISNULL(SUM_OriginalBalance_SecuredLoan_Q2,0)) end [DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q2]

			   ,SUM_OriginalBalance_UnsecuredLoan_Q1 [SUM_OriginalBalance_UnsecuredLoan_Q1]
			   ,CASE WHEN (SUM_OriginalBalance_UnsecuredLoan_Q1 IS NULL AND SUM_OriginalBalance_UnsecuredLoan_Q2 IS  NULL) THEN SUM_OriginalBalance_UnsecuredLoan_Q1 else (ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q1,0) - ISNULL(SUM_OriginalBalance_UnsecuredLoan_Q2,0)) end [DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q2]

			   ,SUM_OriginalBalance_VehicleLoan_Q1 [SUM_OriginalBalance_VehicleLoan_Q1]
			   ,CASE WHEN (SUM_OriginalBalance_VehicleLoan_Q1 IS NULL AND SUM_OriginalBalance_VehicleLoan_Q2 IS  NULL) THEN SUM_OriginalBalance_VehicleLoan_Q1 else (ISNULL(SUM_OriginalBalance_VehicleLoan_Q1,0) - ISNULL(SUM_OriginalBalance_VehicleLoan_Q2,0)) end [DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q2]

			   ,SUM_OriginalBalance_Loan_Q1 [SUM_OriginalBalance_Loan_Q1]
			   ,CASE WHEN (SUM_OriginalBalance_Loan_Q1 IS NULL AND SUM_OriginalBalance_Loan_Q2 IS  NULL) THEN SUM_OriginalBalance_Loan_Q1 else (ISNULL(SUM_OriginalBalance_Loan_Q1,0) - ISNULL(SUM_OriginalBalance_Loan_Q2,0)) end [DFT_SUM_OriginalBalance_Loan_Q1_Q2]

			   --,SUM_PAYMENT_CommercialLoan_Q1 [SUM_PAYMENT_CommercialLoan_Q1]
			   --,CASE WHEN (SUM_PAYMENT_CommercialLoan_Q1 IS NULL AND SUM_PAYMENT_CommercialLoan_Q2 IS  NULL) THEN SUM_PAYMENT_CommercialLoan_Q1 else (ISNULL(SUM_PAYMENT_CommercialLoan_Q1,0) - ISNULL(SUM_PAYMENT_CommercialLoan_Q2,0)) end [DFT_SUM_PAYMENT_CommercialLoan_Q1_Q2]

			   ,SUM_PAYMENT_RealEstate_Q1 [SUM_PAYMENT_RealEstate_Q1]
			   ,CASE WHEN (SUM_PAYMENT_RealEstate_Q1 IS NULL AND SUM_PAYMENT_RealEstate_Q2 IS  NULL) THEN SUM_PAYMENT_RealEstate_Q1 else (ISNULL(SUM_PAYMENT_RealEstate_Q1,0) - ISNULL(SUM_PAYMENT_RealEstate_Q2,0)) end [DFT_SUM_PAYMENT_RealEstate_Q1_Q2]

			   ,SUM_PAYMENT_SecuredLoan_Q1 [SUM_PAYMENT_SecuredLoan_Q1]
			   ,CASE WHEN (SUM_PAYMENT_SecuredLoan_Q1 IS NULL AND SUM_PAYMENT_SecuredLoan_Q2 IS  NULL) THEN SUM_PAYMENT_SecuredLoan_Q1 else (ISNULL(SUM_PAYMENT_SecuredLoan_Q1,0) - ISNULL(SUM_PAYMENT_SecuredLoan_Q2,0)) end [DFT_SUM_PAYMENT_SecuredLoan_Q1_Q2]

			   ,SUM_PAYMENT_UnsecuredLoan_Q1 [SUM_PAYMENT_UnsecuredLoan_Q1]
			   ,CASE WHEN (SUM_PAYMENT_UnsecuredLoan_Q1 IS NULL AND SUM_PAYMENT_UnsecuredLoan_Q2 IS  NULL) THEN SUM_PAYMENT_UnsecuredLoan_Q1 else (ISNULL(SUM_PAYMENT_UnsecuredLoan_Q1,0) - ISNULL(SUM_PAYMENT_UnsecuredLoan_Q2,0)) end [DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q2]

			   ,SUM_PAYMENT_VehicleLoan_Q1 [SUM_PAYMENT_VehicleLoan_Q1]
			   ,CASE WHEN (SUM_PAYMENT_VehicleLoan_Q1 IS NULL AND SUM_PAYMENT_VehicleLoan_Q2 IS  NULL) THEN SUM_PAYMENT_VehicleLoan_Q1 else (ISNULL(SUM_PAYMENT_VehicleLoan_Q1,0) - ISNULL(SUM_PAYMENT_VehicleLoan_Q2,0)) end [DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2]

    		   ,SUM_PAYMENT_Loan_Q1 [SUM_PAYMENT_Loan_Q1]
			   ,CASE WHEN (SUM_PAYMENT_Loan_Q1 IS NULL AND SUM_PAYMENT_Loan_Q2 IS  NULL) THEN SUM_PAYMENT_Loan_Q1 else (ISNULL(SUM_PAYMENT_Loan_Q1,0) - ISNULL(SUM_PAYMENT_Loan_Q2,0)) end [DFT_SUM_PAYMENT_Loan_Q1_Q2]

			   --,MAX_INTERESTRATE_CommercialLoan_Q1 [MAX_INTERESTRATE_CommercialLoan_Q1]
			   --,CASE WHEN (MAX_INTERESTRATE_CommercialLoan_Q1 IS NULL AND MAX_INTERESTRATE_CommercialLoan_Q2 IS  NULL) THEN MAX_INTERESTRATE_CommercialLoan_Q1 else (ISNULL(MAX_INTERESTRATE_CommercialLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_CommercialLoan_Q2,0)) end [DFT_MAX_INTERESTRATE_CommercialLoan_Q1_Q2]

			   ,MAX_INTERESTRATE_RealEstate_Q1 [MAX_INTERESTRATE_RealEstate_Q1]
			   ,CASE WHEN (MAX_INTERESTRATE_RealEstate_Q1 IS NULL AND MAX_INTERESTRATE_RealEstate_Q2 IS  NULL) THEN MAX_INTERESTRATE_RealEstate_Q1 else (ISNULL(MAX_INTERESTRATE_RealEstate_Q1,0) - ISNULL(MAX_INTERESTRATE_RealEstate_Q2,0)) end [DFT_MAX_INTERESTRATE_RealEstate_Q1_Q2]

			   ,MAX_INTERESTRATE_SecuredLoan_Q1 [MAX_INTERESTRATE_SecuredLoan_Q1]
			   ,CASE WHEN (MAX_INTERESTRATE_SecuredLoan_Q1 IS NULL AND MAX_INTERESTRATE_SecuredLoan_Q2 IS  NULL) THEN MAX_INTERESTRATE_SecuredLoan_Q1 else (ISNULL(MAX_INTERESTRATE_SecuredLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_SecuredLoan_Q2,0)) end [DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q2]

			   ,MAX_INTERESTRATE_UnsecuredLoan_Q1 [MAX_INTERESTRATE_UnsecuredLoan_Q1]
			   ,CASE WHEN (MAX_INTERESTRATE_UnsecuredLoan_Q1 IS NULL AND MAX_INTERESTRATE_UnsecuredLoan_Q2 IS  NULL) THEN MAX_INTERESTRATE_UnsecuredLoan_Q1 else (ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_UnsecuredLoan_Q2,0)) end [DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q2]

			   ,MAX_INTERESTRATE_VehicleLoan_Q1 [MAX_INTERESTRATE_VehicleLoan_Q1]
			   ,CASE WHEN (MAX_INTERESTRATE_VehicleLoan_Q1 IS NULL AND MAX_INTERESTRATE_VehicleLoan_Q2 IS  NULL) THEN MAX_INTERESTRATE_VehicleLoan_Q1 else (ISNULL(MAX_INTERESTRATE_VehicleLoan_Q1,0) - ISNULL(MAX_INTERESTRATE_VehicleLoan_Q2,0)) end [DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q2]

			   ,MAX_INTERESTRATE_Loan_Q1 [MAX_INTERESTRATE_Loan_Q1]
			   ,CASE WHEN (MAX_INTERESTRATE_Loan_Q1 IS NULL AND MAX_INTERESTRATE_Loan_Q2 IS  NULL) THEN MAX_INTERESTRATE_Loan_Q1 else (ISNULL(MAX_INTERESTRATE_Loan_Q1,0) - ISNULL(MAX_INTERESTRATE_Loan_Q2,0)) end [DFT_MAX_INTERESTRATE_Loan_Q1_Q2]


			   --,MAX_CREDITLIMIT_CommercialLoan_Q1 [MAX_CREDITLIMIT_CommercialLoan_Q1]
			   --,CASE WHEN (MAX_CREDITLIMIT_CommercialLoan_Q1 IS NULL AND MAX_CREDITLIMIT_CommercialLoan_Q2 IS  NULL) THEN MAX_CREDITLIMIT_CommercialLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_CommercialLoan_Q2,0)) end [DFT_MAX_CREDITLIMIT_CommercialLoan_Q1_Q2]

			   ,MAX_CREDITLIMIT_RealEstate_Q1 [MAX_CREDITLIMIT_RealEstate_Q1]
			   ,CASE WHEN (MAX_CREDITLIMIT_RealEstate_Q1 IS NULL AND MAX_CREDITLIMIT_RealEstate_Q2 IS  NULL) THEN MAX_CREDITLIMIT_RealEstate_Q1 else (ISNULL(MAX_CREDITLIMIT_RealEstate_Q1,0) - ISNULL(MAX_CREDITLIMIT_RealEstate_Q2,0)) end [DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q2]

			   --,MAX_CREDITLIMIT_SecuredLoan_Q1 [MAX_CREDITLIMIT_SecuredLoan_Q1]
			   --,CASE WHEN (MAX_CREDITLIMIT_SecuredLoan_Q1 IS NULL AND MAX_CREDITLIMIT_SecuredLoan_Q2 IS  NULL) THEN MAX_CREDITLIMIT_SecuredLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_SecuredLoan_Q2,0)) end [DFT_MAX_CREDITLIMIT_SecuredLoan_Q1_Q2]

			   ,MAX_CREDITLIMIT_UnsecuredLoan_Q1 [MAX_CREDITLIMIT_UnsecuredLoan_Q1]
			   --,CASE WHEN (MAX_CREDITLIMIT_UnsecuredLoan_Q1 IS NULL AND MAX_CREDITLIMIT_UnsecuredLoan_Q2 IS  NULL) THEN MAX_CREDITLIMIT_UnsecuredLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_Q2,0)) end [DFT_MAX_CREDITLIMIT_UnsecuredLoan_Q1_Q2]

			   --,MAX_CREDITLIMIT_VehicleLoan_Q1 [MAX_CREDITLIMIT_VehicleLoan_Q1]
			   --,CASE WHEN (MAX_CREDITLIMIT_VehicleLoan_Q1 IS NULL AND MAX_CREDITLIMIT_VehicleLoan_Q2 IS  NULL) THEN MAX_CREDITLIMIT_VehicleLoan_Q1 else (ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q1,0) - ISNULL(MAX_CREDITLIMIT_VehicleLoan_Q2,0)) end [DFT_MAX_CREDITLIMIT_VehicleLoan_Q1_Q2]

			   ,MAX_CREDITLIMIT_Loan_Q1 [MAX_CREDITLIMIT_Loan_Q1]
			   ,CASE WHEN (MAX_CREDITLIMIT_Loan_Q1 IS NULL AND MAX_CREDITLIMIT_Loan_Q2 IS  NULL) THEN MAX_CREDITLIMIT_Loan_Q1 else (ISNULL(MAX_CREDITLIMIT_Loan_Q1,0) - ISNULL(MAX_CREDITLIMIT_Loan_Q2,0)) end [DFT_MAX_CREDITLIMIT_Loan_Q1_Q2]
		
			  -- ,AVG_CHARGEOFFAMOUNT_Commercial_loan_Q1
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_Commercial_loan_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_Commercial_loan_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_Commercial_loan_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_Commercial_loan_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_Commercial_loan_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_Commercial_loan_Q1_Q2]

			   ,AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q1_Q2]

			  ,AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q1_Q2]

			  ,AVG_CHARGEOFFAMOUNT_SecuredLoan_Q1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_SecuredLoan_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_SecuredLoan_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_SecuredLoan_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_SecuredLoan_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_SecuredLoan_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_SecuredLoan_Q1_Q2]

			  ,AVG_CHARGEOFFAMOUNT_Vehicleloan_Q1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_Vehicleloan_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_Vehicleloan_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_Vehicleloan_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_Vehicleloan_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_Vehicleloan_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_Vehicleloan_Q1_Q2]

			  ,AVG_CHARGEOFFAMOUNT_Loan_Q1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_Loan_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_Loan_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_Loan_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_Loan_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_Loan_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_Loan_Q1_Q2]

			  --,AVG_PAYMENTSKIPS_Commercial_loan_Q1
			  --,CASE WHEN (AVG_PAYMENTSKIPS_Commercial_loan_Q1 IS NULL AND AVG_PAYMENTSKIPS_Commercial_loan_Q2 IS NULL) THEN AVG_PAYMENTSKIPS_Commercial_loan_Q1 else (ISNULL(AVG_PAYMENTSKIPS_Commercial_loan_Q1,0)-ISNULL(AVG_PAYMENTSKIPS_Commercial_loan_Q2,0)) end [DFT_AVG_PAYMENTSKIPS_Commercial_loan_Q1_Q2]
			  --,CASE WHEN (AVG_PAYMENTSKIPS_Commercial_loan_Q1 IS NULL AND AVG_PAYMENTSKIPS_Commercial_loan_Q3 IS NULL) THEN AVG_PAYMENTSKIPS_Commercial_loan_Q1 else (ISNULL(AVG_PAYMENTSKIPS_Commercial_loan_Q1,0)-ISNULL(AVG_PAYMENTSKIPS_Commercial_loan_Q3,0)) end [DFT_AVG_PAYMENTSKIPS_Commercial_loan_Q1_Q3]

			  --,AVG_PAYMENTSKIPS_Real_Estate_loan_Q1
			  --,CASE WHEN (AVG_PAYMENTSKIPS_Real_Estate_loan_Q1 IS NULL AND AVG_PAYMENTSKIPS_Real_Estate_loan_Q2 IS NULL) THEN AVG_PAYMENTSKIPS_Real_Estate_loan_Q1 else (ISNULL(AVG_PAYMENTSKIPS_Real_Estate_loan_Q1,0)-ISNULL(AVG_PAYMENTSKIPS_Real_Estate_loan_Q2,0)) end [DFT_AVG_PAYMENTSKIPS_Real_Estate_loan_Q1_Q2]

			  --,AVG_PAYMENTSKIPS_UnsecuredLoan_Q1
			  --,CASE WHEN (AVG_PAYMENTSKIPS_UnsecuredLoan_Q1 IS NULL AND AVG_PAYMENTSKIPS_UnsecuredLoan_Q2 IS NULL) THEN AVG_PAYMENTSKIPS_UnsecuredLoan_Q1 else (ISNULL(AVG_PAYMENTSKIPS_UnsecuredLoan_Q1,0)-ISNULL(AVG_PAYMENTSKIPS_UnsecuredLoan_Q2,0)) end [DFT_AVG_PAYMENTSKIPS_UnsecuredLoan_Q1_Q2]

			  --,AVG_PAYMENTSKIPS_SecuredLoan_Q1
			  --,CASE WHEN (AVG_PAYMENTSKIPS_SecuredLoan_Q1 IS NULL AND AVG_PAYMENTSKIPS_SecuredLoan_Q2 IS NULL) THEN AVG_PAYMENTSKIPS_SecuredLoan_Q1 else (ISNULL(AVG_PAYMENTSKIPS_SecuredLoan_Q1,0)-ISNULL(AVG_PAYMENTSKIPS_SecuredLoan_Q2,0)) end [DFT_AVG_PAYMENTSKIPS_SecuredLoan_Q1_Q2]

			  --,AVG_PAYMENTSKIPS_Vehicleloan_Q1
			  --,CASE WHEN (AVG_PAYMENTSKIPS_Vehicleloan_Q1 IS NULL AND AVG_PAYMENTSKIPS_Vehicleloan_Q2 IS NULL) THEN AVG_PAYMENTSKIPS_Vehicleloan_Q1 else (ISNULL(AVG_PAYMENTSKIPS_Vehicleloan_Q1,0)-ISNULL(AVG_PAYMENTSKIPS_Vehicleloan_Q2,0)) end [DFT_AVG_PAYMENTSKIPS_Vehicleloan_Q1_Q2]

			  --,AVG_PAYMENTSKIPS_Loan_Q1
			  --,CASE WHEN (AVG_PAYMENTSKIPS_Loan_Q1 IS NULL AND AVG_PAYMENTSKIPS_Loan_Q2 IS NULL) THEN AVG_PAYMENTSKIPS_Loan_Q1 else (ISNULL(AVG_PAYMENTSKIPS_Loan_Q1,0)-ISNULL(AVG_PAYMENTSKIPS_Loan_Q2,0)) end [DFT_AVG_PAYMENTSKIPS_Loan_Q1_Q2]

			   --,ISNULL(COUNT_DUEDAY1_CommercialLoan_Q1,0) [COUNT_DUEDAY1_CommercialLoan_Q1]
			   --,ISNULL(COUNT_DUEDAY1_CommercialLoan_Q2,0) [COUNT_DUEDAY1_CommercialLoan_Q2]


			   --,ISNULL(COUNT_DUEDAY1_RealEstate_Q1,0) [COUNT_DUEDAY1_RealEstate_Q1]
			   --,ISNULL(COUNT_DUEDAY1_RealEstate_Q2,0) [COUNT_DUEDAY1_RealEstate_Q2]


			   --,ISNULL(COUNT_DUEDAY1_SecuredLoan_Q1,0) [COUNT_DUEDAY1_SecuredLoan_Q1]
			   --,ISNULL(COUNT_DUEDAY1_SecuredLoan_Q2,0) [COUNT_DUEDAY1_SecuredLoan_Q2]


			   --,ISNULL(COUNT_DUEDAY1_UnsecuredLoan_Q1,0) [COUNT_DUEDAY1_UnsecuredLoan_Q1]
			   --,ISNULL(COUNT_DUEDAY1_UnsecuredLoan_Q2,0) [COUNT_DUEDAY1_UnsecuredLoan_Q2]


			   --,ISNULL(COUNT_DUEDAY1_VehicleLoan_Q1,0) [COUNT_DUEDAY1_VehicleLoan_Q1]
			   --,ISNULL(COUNT_DUEDAY1_VehicleLoan_Q2,0) [COUNT_DUEDAY1_VehicleLoan_Q2]


			   --,ISNULL(COUNT_DUEDAY1_Others_Q1,0) [COUNT_DUEDAY1_Others_Q1]
			   --,ISNULL(COUNT_DUEDAY1_Others_Q2,0) [COUNT_DUEDAY1_Others_Q2]



			   --,ISNULL(COUNT_DUEDAY2_CommercialLoan_Q1,0) [COUNT_DUEDAY2_CommercialLoan_Q1]
			   --,ISNULL(COUNT_DUEDAY2_CommercialLoan_Q2,0) [COUNT_DUEDAY2_CommercialLoan_Q2]


			   --,ISNULL(COUNT_DUEDAY2_RealEstate_Q1,0) [COUNT_DUEDAY2_RealEstate_Q1]
			   --,ISNULL(COUNT_DUEDAY2_RealEstate_Q2,0) [COUNT_DUEDAY2_RealEstate_Q2]


			   --,ISNULL(COUNT_DUEDAY2_SecuredLoan_Q1,0) [COUNT_DUEDAY2_SecuredLoan_Q1]
			   --,ISNULL(COUNT_DUEDAY2_SecuredLoan_Q2,0) [COUNT_DUEDAY2_SecuredLoan_Q2]


			   --,ISNULL(COUNT_DUEDAY2_UnsecuredLoan_Q1,0) [COUNT_DUEDAY2_UnsecuredLoan_Q1]
			   --,ISNULL(COUNT_DUEDAY2_UnsecuredLoan_Q2,0) [COUNT_DUEDAY2_UnsecuredLoan_Q2]


			   --,ISNULL(COUNT_DUEDAY2_VehicleLoan_Q1,0) [COUNT_DUEDAY2_VehicleLoan_Q1]
			   --,ISNULL(COUNT_DUEDAY2_VehicleLoan_Q2,0) [COUNT_DUEDAY2_VehicleLoan_Q2]


			   --,ISNULL(COUNT_DUEDAY2_Others_Q1,0) [COUNT_DUEDAY2_Others_Q1]
			   --,ISNULL(COUNT_DUEDAY2_Others_Q2,0) [COUNT_DUEDAY2_Others_Q2]


			   ----,#Products_CommercialLoan_H1 [PRODUCT_CommercialLoan_H1]
			   --,CASE WHEN (#Products_CommercialLoan_H1 IS NULL AND #Products_CommercialLoan_H2 IS  NULL) THEN #Products_CommercialLoan_H1 else (ISNULL(#Products_CommercialLoan_H1,0) - ISNULL(#Products_CommercialLoan_H2,0)) end [DFT_PRODUCT_CommercialLoan_H1_H2]

			   --,#Products_RealEstate_H1 [PRODUCT_RealEstate_H1]
			   ,CASE WHEN (#Products_RealEstate_H1 IS NULL AND #Products_RealEstate_H2 IS  NULL) THEN #Products_RealEstate_H1 else (ISNULL(#Products_RealEstate_H1,0) - ISNULL(#Products_RealEstate_H2,0)) end [DFT_PRODUCT_RealEstate_H1_H2]

			   --,#Products_SecuredLoan_H1 [PRODUCT_SecuredLoan_H1]
			   ,CASE WHEN (#Products_SecuredLoan_H1 IS NULL AND #Products_SecuredLoan_H2 IS  NULL) THEN #Products_SecuredLoan_H1 else (ISNULL(#Products_SecuredLoan_H1,0) - ISNULL(#Products_SecuredLoan_H2,0)) end [DFT_PRODUCT_SecuredLoan_H1_H2]
			   
			   --,#Products_UnsecuredLoan_H1 [PRODUCT_UnsecuredLoan_H1]
			   ,CASE WHEN (#Products_UnsecuredLoan_H1 IS NULL AND #Products_UnsecuredLoan_H2 IS  NULL) THEN #Products_UnsecuredLoan_H1 else (ISNULL(#Products_UnsecuredLoan_H1,0) - ISNULL(#Products_UnsecuredLoan_H2,0)) end [DFT_PRODUCT_UnsecuredLoan_H1_H2]
			   
			   --,#Products_VehicleLoan_H1 [PRODUCT_VehicleLoan_H1]
			   ,CASE WHEN (#Products_VehicleLoan_H1 IS NULL AND #Products_VehicleLoan_H2 IS  NULL) THEN #Products_VehicleLoan_H1 else (ISNULL(#Products_VehicleLoan_H1,0) - ISNULL(#Products_VehicleLoan_H2,0)) end [DFT_PRODUCT_VehicleLoan_H1_H2]

			   ,CASE WHEN (#Products_Loan_H1 IS NULL AND #Products_Loan_H2 IS  NULL) THEN #Products_Loan_H1 else (ISNULL(#Products_Loan_H1,0) - ISNULL(#Products_Loan_H2,0)) end [DFT_PRODUCT_Loan_H1_H2]

			   --,PAYMENTCOUNT_CommercialLoan_H1 [PAYMENTCOUNT_CommercialLoan_H1]
			   --,CASE WHEN (PAYMENTCOUNT_CommercialLoan_H1 IS NULL AND PAYMENTCOUNT_CommercialLoan_H2 IS  NULL) THEN PAYMENTCOUNT_CommercialLoan_H1 else (ISNULL(PAYMENTCOUNT_CommercialLoan_H1,0) - ISNULL(PAYMENTCOUNT_CommercialLoan_H2,0)) end [DFT_PAYMENTCOUNT_CommercialLoan_H1_H2]
               
			   --,PAYMENTCOUNT_RealEstate_H1 [PAYMENTCOUNT_RealEstate_H1]
			   ,CASE WHEN (PAYMENTCOUNT_RealEstate_H1 IS NULL AND PAYMENTCOUNT_RealEstate_H2 IS  NULL) THEN PAYMENTCOUNT_RealEstate_H1 else (ISNULL(PAYMENTCOUNT_RealEstate_H1,0) - ISNULL(PAYMENTCOUNT_RealEstate_H2,0)) end [DFT_PAYMENTCOUNT_RealEstate_H1_H2]

			   --,PAYMENTCOUNT_SecuredLoan_H1 [PAYMENTCOUNT_SecuredLoan_H1]
			   ,CASE WHEN (PAYMENTCOUNT_SecuredLoan_H1 IS NULL AND PAYMENTCOUNT_SecuredLoan_H2 IS  NULL) THEN PAYMENTCOUNT_SecuredLoan_H1 else (ISNULL(PAYMENTCOUNT_SecuredLoan_H1,0) - ISNULL(PAYMENTCOUNT_SecuredLoan_H2,0)) end [DFT_PAYMENTCOUNT_SecuredLoan_H1_H2]

               --,PAYMENTCOUNT_UnsecuredLoan_H1 [PAYMENTCOUNT_UnsecuredLoan_H1]
			   ,CASE WHEN (PAYMENTCOUNT_UnsecuredLoan_H1 IS NULL AND PAYMENTCOUNT_UnsecuredLoan_H2 IS  NULL) THEN PAYMENTCOUNT_UnsecuredLoan_H1 else (ISNULL(PAYMENTCOUNT_UnsecuredLoan_H1,0) - ISNULL(PAYMENTCOUNT_UnsecuredLoan_H2,0)) end [DFT_PAYMENTCOUNT_UnsecuredLoan_H1_H2]

			   --,PAYMENTCOUNT_VehicleLoan_H1 [PAYMENTCOUNT_VehicleLoan_H1]
			   ,CASE WHEN (PAYMENTCOUNT_VehicleLoan_H1 IS NULL AND PAYMENTCOUNT_VehicleLoan_H2 IS  NULL) THEN PAYMENTCOUNT_VehicleLoan_H1 else (ISNULL(PAYMENTCOUNT_VehicleLoan_H1,0) - ISNULL(PAYMENTCOUNT_VehicleLoan_H2,0)) end [DFT_PAYMENTCOUNT_VehicleLoan_H1_H2]

			   --,PAYMENTCOUNT_Loan_H1 [PAYMENTCOUNT_Loan_H1]
			   ,CASE WHEN (PAYMENTCOUNT_Loan_H1 IS NULL AND PAYMENTCOUNT_Loan_H2 IS  NULL) THEN PAYMENTCOUNT_Loan_H1 else (ISNULL(PAYMENTCOUNT_Loan_H1,0) - ISNULL(PAYMENTCOUNT_Loan_H2,0)) end [DFT_PAYMENTCOUNT_Loan_H1_H2]

			   --,SUM_OriginalBalance_CommercialLoan_H1 [SUM_OriginalBalance_CommercialLoan_H1]
			   --,CASE WHEN (SUM_OriginalBalance_CommercialLoan_H1 IS NULL AND SUM_OriginalBalance_CommercialLoan_H2 IS  NULL) THEN SUM_OriginalBalance_CommercialLoan_H1 else (ISNULL(SUM_OriginalBalance_CommercialLoan_H1,0) - ISNULL(SUM_OriginalBalance_CommercialLoan_H2,0)) end [DFT_SUM_OriginalBalance_CommercialLoan_H1_H2]

			   --,SUM_OriginalBalance_RealEstate_H1 [SUM_OriginalBalance_RealEstate_H1]
			   ,CASE WHEN (SUM_OriginalBalance_RealEstate_H1 IS NULL AND SUM_OriginalBalance_RealEstate_H2 IS  NULL) THEN SUM_OriginalBalance_RealEstate_H1 else (ISNULL(SUM_OriginalBalance_RealEstate_H1,0) - ISNULL(SUM_OriginalBalance_RealEstate_H2,0)) end [DFT_SUM_OriginalBalance_RealEstate_H1_H2]

			   --,SUM_OriginalBalance_SecuredLoan_H1 [SUM_OriginalBalance_SecuredLoan_H1]
			   ,CASE WHEN (SUM_OriginalBalance_SecuredLoan_H1 IS NULL AND SUM_OriginalBalance_SecuredLoan_H2 IS  NULL) THEN SUM_OriginalBalance_SecuredLoan_H1 else (ISNULL(SUM_OriginalBalance_SecuredLoan_H1,0) - ISNULL(SUM_OriginalBalance_SecuredLoan_H2,0)) end [DFT_SUM_OriginalBalance_SecuredLoan_H1_H2]

			   --,SUM_OriginalBalance_UnsecuredLoan_H1 [SUM_OriginalBalance_UnsecuredLoan_H1]
			   ,CASE WHEN (SUM_OriginalBalance_UnsecuredLoan_H1 IS NULL AND SUM_OriginalBalance_UnsecuredLoan_H2 IS  NULL) THEN SUM_OriginalBalance_UnsecuredLoan_H1 else (ISNULL(SUM_OriginalBalance_UnsecuredLoan_H1,0) - ISNULL(SUM_OriginalBalance_UnsecuredLoan_H2,0)) end [DFT_SUM_OriginalBalance_UnsecuredLoan_H1_H2]

			   --,SUM_OriginalBalance_VehicleLoan_H1 [SUM_OriginalBalance_VehicleLoan_H1]
			   ,CASE WHEN (SUM_OriginalBalance_VehicleLoan_H1 IS NULL AND SUM_OriginalBalance_VehicleLoan_H2 IS  NULL) THEN SUM_OriginalBalance_VehicleLoan_H1 else (ISNULL(SUM_OriginalBalance_VehicleLoan_H1,0) - ISNULL(SUM_OriginalBalance_VehicleLoan_H2,0)) end [DFT_SUM_OriginalBalance_VehicleLoan_H1_H2]

			   --,SUM_OriginalBalance_Loan_H1 [SUM_OriginalBalance_Loan_H1]
			   ,CASE WHEN (SUM_OriginalBalance_Loan_H1 IS NULL AND SUM_OriginalBalance_Loan_H2 IS  NULL) THEN SUM_OriginalBalance_Loan_H1 else (ISNULL(SUM_OriginalBalance_Loan_H1,0) - ISNULL(SUM_OriginalBalance_Loan_H2,0)) end [DFT_SUM_OriginalBalance_Loan_H1_H2]

			   --,SUM_PAYMENT_CommercialLoan_H1 [SUM_PAYMENT_CommercialLoan_H1]
			   --,CASE WHEN (SUM_PAYMENT_CommercialLoan_H1 IS NULL AND SUM_PAYMENT_CommercialLoan_H2 IS  NULL) THEN SUM_PAYMENT_CommercialLoan_H1 else (ISNULL(SUM_PAYMENT_CommercialLoan_H1,0) - ISNULL(SUM_PAYMENT_CommercialLoan_H2,0)) end [DFT_SUM_PAYMENT_CommercialLoan_H1_H2]

			   --,SUM_PAYMENT_RealEstate_H1 [SUM_PAYMENT_RealEstate_H1]
			   ,CASE WHEN (SUM_PAYMENT_RealEstate_H1 IS NULL AND SUM_PAYMENT_RealEstate_H2 IS  NULL) THEN SUM_PAYMENT_RealEstate_H1 else (ISNULL(SUM_PAYMENT_RealEstate_H1,0) - ISNULL(SUM_PAYMENT_RealEstate_H2,0)) end [DFT_SUM_PAYMENT_RealEstate_H1_H2]

			   --,SUM_PAYMENT_SecuredLoan_H1 [SUM_PAYMENT_SecuredLoan_H1]
			   ,CASE WHEN (SUM_PAYMENT_SecuredLoan_H1 IS NULL AND SUM_PAYMENT_SecuredLoan_H2 IS  NULL) THEN SUM_PAYMENT_SecuredLoan_H1 else (ISNULL(SUM_PAYMENT_SecuredLoan_H1,0) - ISNULL(SUM_PAYMENT_SecuredLoan_H2,0)) end [DFT_SUM_PAYMENT_SecuredLoan_H1_H2]

			   --,SUM_PAYMENT_UnsecuredLoan_H1 [SUM_PAYMENT_UnsecuredLoan_H1]
			   ,CASE WHEN (SUM_PAYMENT_UnsecuredLoan_H1 IS NULL AND SUM_PAYMENT_UnsecuredLoan_H2 IS  NULL) THEN SUM_PAYMENT_UnsecuredLoan_H1 else (ISNULL(SUM_PAYMENT_UnsecuredLoan_H1,0) - ISNULL(SUM_PAYMENT_UnsecuredLoan_H2,0)) end [DFT_SUM_PAYMENT_UnsecuredLoan_H1_H2]

			   --,SUM_PAYMENT_VehicleLoan_H1 [SUM_PAYMENT_VehicleLoan_H1]
			   ,CASE WHEN (SUM_PAYMENT_VehicleLoan_H1 IS NULL AND SUM_PAYMENT_VehicleLoan_H2 IS  NULL) THEN SUM_PAYMENT_VehicleLoan_H1 else (ISNULL(SUM_PAYMENT_VehicleLoan_H1,0) - ISNULL(SUM_PAYMENT_VehicleLoan_H2,0)) end [DFT_SUM_PAYMENT_VehicleLoan_H1_H2]

    		   --,SUM_PAYMENT_Loan_H1 [SUM_PAYMENT_Loan_H1]
			   ,CASE WHEN (SUM_PAYMENT_Loan_H1 IS NULL AND SUM_PAYMENT_Loan_H2 IS  NULL) THEN SUM_PAYMENT_Loan_H1 else (ISNULL(SUM_PAYMENT_Loan_H1,0) - ISNULL(SUM_PAYMENT_Loan_H2,0)) end [DFT_SUM_PAYMENT_Loan_H1_H2]

			   --,MAX_INTERESTRATE_CommercialLoan_H1 [MAX_INTERESTRATE_CommercialLoan_H1]
			   --,CASE WHEN (MAX_INTERESTRATE_CommercialLoan_H1 IS NULL AND MAX_INTERESTRATE_CommercialLoan_H2 IS  NULL) THEN MAX_INTERESTRATE_CommercialLoan_H1 else (ISNULL(MAX_INTERESTRATE_CommercialLoan_H1,0) - ISNULL(MAX_INTERESTRATE_CommercialLoan_H2,0)) end [DFT_MAX_INTERESTRATE_CommercialLoan_H1_H2]

			   --,MAX_INTERESTRATE_RealEstate_H1 [MAX_INTERESTRATE_RealEstate_H1]
			   ,CASE WHEN (MAX_INTERESTRATE_RealEstate_H1 IS NULL AND MAX_INTERESTRATE_RealEstate_H2 IS  NULL) THEN MAX_INTERESTRATE_RealEstate_H1 else (ISNULL(MAX_INTERESTRATE_RealEstate_H1,0) - ISNULL(MAX_INTERESTRATE_RealEstate_H2,0)) end [DFT_MAX_INTERESTRATE_RealEstate_H1_H2]

			   --,MAX_INTERESTRATE_SecuredLoan_H1 [MAX_INTERESTRATE_SecuredLoan_H1]
			   ,CASE WHEN (MAX_INTERESTRATE_SecuredLoan_H1 IS NULL AND MAX_INTERESTRATE_SecuredLoan_H2 IS  NULL) THEN MAX_INTERESTRATE_SecuredLoan_H1 else (ISNULL(MAX_INTERESTRATE_SecuredLoan_H1,0) - ISNULL(MAX_INTERESTRATE_SecuredLoan_H2,0)) end [DFT_MAX_INTERESTRATE_SecuredLoan_H1_H2]

			   --,MAX_INTERESTRATE_UnsecuredLoan_H1 [MAX_INTERESTRATE_UnsecuredLoan_H1]
			   ,CASE WHEN (MAX_INTERESTRATE_UnsecuredLoan_H1 IS NULL AND MAX_INTERESTRATE_UnsecuredLoan_H2 IS  NULL) THEN MAX_INTERESTRATE_UnsecuredLoan_H1 else (ISNULL(MAX_INTERESTRATE_UnsecuredLoan_H1,0) - ISNULL(MAX_INTERESTRATE_UnsecuredLoan_H2,0)) end [DFT_MAX_INTERESTRATE_UnsecuredLoan_H1_H2]

			   --,MAX_INTERESTRATE_VehicleLoan_H1 [MAX_INTERESTRATE_VehicleLoan_H1]
			   ,CASE WHEN (MAX_INTERESTRATE_VehicleLoan_H1 IS NULL AND MAX_INTERESTRATE_VehicleLoan_H2 IS  NULL) THEN MAX_INTERESTRATE_VehicleLoan_H1 else (ISNULL(MAX_INTERESTRATE_VehicleLoan_H1,0) - ISNULL(MAX_INTERESTRATE_VehicleLoan_H2,0)) end [DFT_MAX_INTERESTRATE_VehicleLoan_H1_H2]

			   --,MAX_INTERESTRATE_Loan_H1 [MAX_INTERESTRATE_Loan_H1]
			   ,CASE WHEN (MAX_INTERESTRATE_Loan_H1 IS NULL AND MAX_INTERESTRATE_Loan_H2 IS  NULL) THEN MAX_INTERESTRATE_Loan_H1 else (ISNULL(MAX_INTERESTRATE_Loan_H1,0) - ISNULL(MAX_INTERESTRATE_Loan_H2,0)) end [DFT_MAX_INTERESTRATE_Loan_H1_H2]


			   --,MAX_CREDITLIMIT_CommercialLoan_H1 [MAX_CREDITLIMIT_CommercialLoan_H1]
			   --,CASE WHEN (MAX_CREDITLIMIT_CommercialLoan_H1 IS NULL AND MAX_CREDITLIMIT_CommercialLoan_H2 IS  NULL) THEN MAX_CREDITLIMIT_CommercialLoan_H1 else (ISNULL(MAX_CREDITLIMIT_CommercialLoan_H1,0) - ISNULL(MAX_CREDITLIMIT_CommercialLoan_H2,0)) end [DFT_MAX_CREDITLIMIT_CommercialLoan_H1_H2]

			   --,MAX_CREDITLIMIT_RealEstate_H1 [MAX_CREDITLIMIT_RealEstate_H1]
			   ,CASE WHEN (MAX_CREDITLIMIT_RealEstate_H1 IS NULL AND MAX_CREDITLIMIT_RealEstate_H2 IS  NULL) THEN MAX_CREDITLIMIT_RealEstate_H1 else (ISNULL(MAX_CREDITLIMIT_RealEstate_H1,0) - ISNULL(MAX_CREDITLIMIT_RealEstate_H2,0)) end [DFT_MAX_CREDITLIMIT_RealEstate_H1_H2]

			   --,MAX_CREDITLIMIT_SecuredLoan_H1 [MAX_CREDITLIMIT_SecuredLoan_H1]
			   ,CASE WHEN (MAX_CREDITLIMIT_SecuredLoan_H1 IS NULL AND MAX_CREDITLIMIT_SecuredLoan_H2 IS  NULL) THEN MAX_CREDITLIMIT_SecuredLoan_H1 else (ISNULL(MAX_CREDITLIMIT_SecuredLoan_H1,0) - ISNULL(MAX_CREDITLIMIT_SecuredLoan_H2,0)) end [DFT_MAX_CREDITLIMIT_SecuredLoan_H1_H2]

			   --,MAX_CREDITLIMIT_UnsecuredLoan_H1 [MAX_CREDITLIMIT_UnsecuredLoan_H1]
			   ,CASE WHEN (MAX_CREDITLIMIT_UnsecuredLoan_H1 IS NULL AND MAX_CREDITLIMIT_UnsecuredLoan_H2 IS  NULL) THEN MAX_CREDITLIMIT_UnsecuredLoan_H1 else (ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_H1,0) - ISNULL(MAX_CREDITLIMIT_UnsecuredLoan_H2,0)) end [DFT_MAX_CREDITLIMIT_UnsecuredLoan_H1_H2]

			   --,MAX_CREDITLIMIT_VehicleLoan_H1 [MAX_CREDITLIMIT_VehicleLoan_H1]
			   ,CASE WHEN (MAX_CREDITLIMIT_VehicleLoan_H1 IS NULL AND MAX_CREDITLIMIT_VehicleLoan_H2 IS  NULL) THEN MAX_CREDITLIMIT_VehicleLoan_H1 else (ISNULL(MAX_CREDITLIMIT_VehicleLoan_H1,0) - ISNULL(MAX_CREDITLIMIT_VehicleLoan_H2,0)) end [DFT_MAX_CREDITLIMIT_VehicleLoan_H1_H2]

			   --,MAX_CREDITLIMIT_Loan_H1 [MAX_CREDITLIMIT_Loan_H1]
			   ,CASE WHEN (MAX_CREDITLIMIT_Loan_H1 IS NULL AND MAX_CREDITLIMIT_Loan_H2 IS  NULL) THEN MAX_CREDITLIMIT_Loan_H1 else (ISNULL(MAX_CREDITLIMIT_Loan_H1,0) - ISNULL(MAX_CREDITLIMIT_Loan_H2,0)) end [DFT_MAX_CREDITLIMIT_Loan_H1_H2]
		
			   --,AVG_CHARGEOFFAMOUNT_Commercial_loan_H1
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_Commercial_loan_H1 IS NULL AND AVG_CHARGEOFFAMOUNT_Commercial_loan_H2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_Commercial_loan_H1 else (ISNULL(AVG_CHARGEOFFAMOUNT_Commercial_loan_H1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_Commercial_loan_H2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_Commercial_loan_H1_H2]

			   --,AVG_CHARGEOFFAMOUNT_Real_Estate_loan_H1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_Real_Estate_loan_H1 IS NULL AND AVG_CHARGEOFFAMOUNT_Real_Estate_loan_H2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_Real_Estate_loan_H1 else (ISNULL(AVG_CHARGEOFFAMOUNT_Real_Estate_loan_H1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_Real_Estate_loan_H2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_Real_Estate_loan_H1_H2]

			  --,AVG_CHARGEOFFAMOUNT_UnsecuredLoan_H1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_UnsecuredLoan_H1 IS NULL AND AVG_CHARGEOFFAMOUNT_UnsecuredLoan_H2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_UnsecuredLoan_H1 else (ISNULL(AVG_CHARGEOFFAMOUNT_UnsecuredLoan_H1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_UnsecuredLoan_H2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_UnsecuredLoan_H1_H2]

			  --,AVG_CHARGEOFFAMOUNT_SecuredLoan_H1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_SecuredLoan_H1 IS NULL AND AVG_CHARGEOFFAMOUNT_SecuredLoan_H2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_SecuredLoan_H1 else (ISNULL(AVG_CHARGEOFFAMOUNT_SecuredLoan_H1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_SecuredLoan_H2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_SecuredLoan_H1_H2]

			  --,AVG_CHARGEOFFAMOUNT_Vehicleloan_H1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_Vehicleloan_H1 IS NULL AND AVG_CHARGEOFFAMOUNT_Vehicleloan_H2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_Vehicleloan_H1 else (ISNULL(AVG_CHARGEOFFAMOUNT_Vehicleloan_H1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_Vehicleloan_H2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_Vehicleloan_H1_H2]

			  --,AVG_CHARGEOFFAMOUNT_Loan_H1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_Loan_H1 IS NULL AND AVG_CHARGEOFFAMOUNT_Loan_H2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_Loan_H1 else (ISNULL(AVG_CHARGEOFFAMOUNT_Loan_H1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_Loan_H2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_Loan_H1_H2]

			  --,AVG_PAYMENTSKIPS_Commercial_loan_H1
			  ----,CASE WHEN (AVG_PAYMENTSKIPS_Commercial_loan_H1 IS NULL AND AVG_PAYMENTSKIPS_Commercial_loan_H2 IS NULL) THEN AVG_PAYMENTSKIPS_Commercial_loan_H1 else (ISNULL(AVG_PAYMENTSKIPS_Commercial_loan_H1,0)-ISNULL(AVG_PAYMENTSKIPS_Commercial_loan_H2,0)) end [DFT_AVG_PAYMENTSKIPS_Commercial_loan_H1_H2]

			  ----,AVG_PAYMENTSKIPS_Real_Estate_loan_H1
			  --,CASE WHEN (AVG_PAYMENTSKIPS_Real_Estate_loan_H1 IS NULL AND AVG_PAYMENTSKIPS_Real_Estate_loan_H2 IS NULL) THEN AVG_PAYMENTSKIPS_Real_Estate_loan_H1 else (ISNULL(AVG_PAYMENTSKIPS_Real_Estate_loan_H1,0)-ISNULL(AVG_PAYMENTSKIPS_Real_Estate_loan_H2,0)) end [DFT_AVG_PAYMENTSKIPS_Real_Estate_loan_H1_H2]

			  ----,AVG_PAYMENTSKIPS_UnsecuredLoan_H1
			  --,CASE WHEN (AVG_PAYMENTSKIPS_UnsecuredLoan_H1 IS NULL AND AVG_PAYMENTSKIPS_UnsecuredLoan_H2 IS NULL) THEN AVG_PAYMENTSKIPS_UnsecuredLoan_H1 else (ISNULL(AVG_PAYMENTSKIPS_UnsecuredLoan_H1,0)-ISNULL(AVG_PAYMENTSKIPS_UnsecuredLoan_H2,0)) end [DFT_AVG_PAYMENTSKIPS_UnsecuredLoan_H1_H2]

			  ----,AVG_PAYMENTSKIPS_SecuredLoan_H1
			  --,CASE WHEN (AVG_PAYMENTSKIPS_SecuredLoan_H1 IS NULL AND AVG_PAYMENTSKIPS_SecuredLoan_H2 IS NULL) THEN AVG_PAYMENTSKIPS_SecuredLoan_H1 else (ISNULL(AVG_PAYMENTSKIPS_SecuredLoan_H1,0)-ISNULL(AVG_PAYMENTSKIPS_SecuredLoan_H2,0)) end [DFT_AVG_PAYMENTSKIPS_SecuredLoan_H1_H2]

			  ----,AVG_PAYMENTSKIPS_Vehicleloan_H1
			  --,CASE WHEN (AVG_PAYMENTSKIPS_Vehicleloan_H1 IS NULL AND AVG_PAYMENTSKIPS_Vehicleloan_H2 IS NULL) THEN AVG_PAYMENTSKIPS_Vehicleloan_H1 else (ISNULL(AVG_PAYMENTSKIPS_Vehicleloan_H1,0)-ISNULL(AVG_PAYMENTSKIPS_Vehicleloan_H2,0)) end [DFT_AVG_PAYMENTSKIPS_Vehicleloan_H1_H2]

			  ----,AVG_PAYMENTSKIPS_Loan_H1
			  --,CASE WHEN (AVG_PAYMENTSKIPS_Loan_H1 IS NULL AND AVG_PAYMENTSKIPS_Loan_H2 IS NULL) THEN AVG_PAYMENTSKIPS_Loan_H1 else (ISNULL(AVG_PAYMENTSKIPS_Loan_H1,0)-ISNULL(AVG_PAYMENTSKIPS_Loan_H2,0)) end [DFT_AVG_PAYMENTSKIPS_Loan_H1_H2]

			   --,ISNULL(COUNT_DUEDAY1_CommercialLoan_H1,0) [COUNT_DUEDAY1_CommercialLoan_H1]
			   --,ISNULL(COUNT_DUEDAY1_CommercialLoan_H2,0) [COUNT_DUEDAY1_CommercialLoan_H2]


			   --,ISNULL(COUNT_DUEDAY1_RealEstate_H1,0) [COUNT_DUEDAY1_RealEstate_H1]
			   --,ISNULL(COUNT_DUEDAY1_RealEstate_H2,0) [COUNT_DUEDAY1_RealEstate_H2]


			   --,ISNULL(COUNT_DUEDAY1_SecuredLoan_H1,0) [COUNT_DUEDAY1_SecuredLoan_H1]
			   --,ISNULL(COUNT_DUEDAY1_SecuredLoan_H2,0) [COUNT_DUEDAY1_SecuredLoan_H2]


			   --,ISNULL(COUNT_DUEDAY1_UnsecuredLoan_H1,0) [COUNT_DUEDAY1_UnsecuredLoan_H1]
			   --,ISNULL(COUNT_DUEDAY1_UnsecuredLoan_H2,0) [COUNT_DUEDAY1_UnsecuredLoan_H2]


			   --,ISNULL(COUNT_DUEDAY1_VehicleLoan_H1,0) [COUNT_DUEDAY1_VehicleLoan_H1]
			   --,ISNULL(COUNT_DUEDAY1_VehicleLoan_H2,0) [COUNT_DUEDAY1_VehicleLoan_H2]


			   --,ISNULL(COUNT_DUEDAY1_Others_H1,0) [COUNT_DUEDAY1_Others_H1]
			   --,ISNULL(COUNT_DUEDAY1_Others_H2,0) [COUNT_DUEDAY1_Others_H2]



			   ----,ISNULL(COUNT_DUEDAY2_CommercialLoan_H1,0) [COUNT_DUEDAY2_CommercialLoan_H1]
			   ----,ISNULL(COUNT_DUEDAY2_CommercialLoan_H2,0) [COUNT_DUEDAY2_CommercialLoan_H2]


			   --,ISNULL(COUNT_DUEDAY2_RealEstate_H1,0) [COUNT_DUEDAY2_RealEstate_H1]
			   --,ISNULL(COUNT_DUEDAY2_RealEstate_H2,0) [COUNT_DUEDAY2_RealEstate_H2]


			   --,ISNULL(COUNT_DUEDAY2_SecuredLoan_H1,0) [COUNT_DUEDAY2_SecuredLoan_H1]
			   --,ISNULL(COUNT_DUEDAY2_SecuredLoan_H2,0) [COUNT_DUEDAY2_SecuredLoan_H2]


			   --,ISNULL(COUNT_DUEDAY2_UnsecuredLoan_H1,0) [COUNT_DUEDAY2_UnsecuredLoan_H1]
			   --,ISNULL(COUNT_DUEDAY2_UnsecuredLoan_H2,0) [COUNT_DUEDAY2_UnsecuredLoan_H2]


			   --,ISNULL(COUNT_DUEDAY2_VehicleLoan_H1,0) [COUNT_DUEDAY2_VehicleLoan_H1]
			   --,ISNULL(COUNT_DUEDAY2_VehicleLoan_H2,0) [COUNT_DUEDAY2_VehicleLoan_H2]


			   --,ISNULL(COUNT_DUEDAY2_Others_H1,0) [COUNT_DUEDAY2_Others_H1]
			   --,ISNULL(COUNT_DUEDAY2_Others_H2,0) [COUNT_DUEDAY2_Others_H2]

			   --,[CommercialLoan_Month_to_Maturity]
			   ,[RealEstate_Month_to_Maturity]
			   ,[SecuredLoan_Month_to_Maturity]
			   ,[UnsecuredLoan_Month_to_Maturity]
			   ,[Vehicleloan_Month_to_Maturity]
			   ,[Others_Month_to_Maturity] 	
			   ,Max_Loan_Month_to_Maturity
			   --,[Delinquency_CommercialLoan_SP]
			   ,[Delinquency_RealEstate_SP]
			   ,[Delinquency_SecuredLoan_SP]
			   ,[Delinquency_UnsecuredLoan_SP]
			   ,[Delinquency_Vehicleloan_SP]
			   ,[Delinquency_Others_SP]
			   ,Delinquency_Loan_SP
			   --,CommercialLoan_OPENDATE
			   --,CommercialLoan_CLOSEDATE
			   --,RealEstate_OPENDATE
			   --,RealEstate_CLOSEDATE
			   --,SecuredLoan_OPENDATE
			   --,SecuredLoan_CLOSEDATE
			   --,UnsecuredLoan_OPENDATE
			   --,UnsecuredLoan_CLOSEDATE
			   --,Vehicleloan_OPENDATE
			   --,Vehicleloan_CLOSEDATE
			   --,Others_OPENDATE
			   --,Others_CLOSEDATE
			   --,Min_Loan_OPENDATE
			   --,Max_Loan_CLOSEDATE
			   --,[CommercialLoan_StaticPoolFlag]
			   ,[RealEstate_StaticPoolFlag]
			   ,[SecuredLoan_StaticPoolFlag]
			   ,[UnsecuredLoan_StaticPoolFlag]
			   ,[VehicleLoan_StaticPoolFlag]

			   ,MAX_DAYSINCEDUEDATE_Real_Estate_loan_SP
			   ,MAX_DAYSINCEDUEDATE_Real_Estate_loan_Q1
			   ,MAX_DAYSINCEDUEDATE_Real_Estate_loan_Q2
			   ,MAX_DAYSINCEDUEDATE_Real_Estate_loan_H1
			   ,MAX_DAYSINCEDUEDATE_Real_Estate_loan_H2

			   ,MAX_DAYSINCEDUEDATE_SecuredLoan_SP
			   ,MAX_DAYSINCEDUEDATE_SecuredLoan_Q1
			   ,MAX_DAYSINCEDUEDATE_SecuredLoan_Q2
			   ,MAX_DAYSINCEDUEDATE_SecuredLoan_H1
			   ,MAX_DAYSINCEDUEDATE_SecuredLoan_H2

			   ,MAX_DAYSINCEDUEDATE_UnsecuredLoan_SP
			   ,MAX_DAYSINCEDUEDATE_UnsecuredLoan_Q1
			   ,MAX_DAYSINCEDUEDATE_UnsecuredLoan_Q2
			   ,MAX_DAYSINCEDUEDATE_UnsecuredLoan_H1
			   ,MAX_DAYSINCEDUEDATE_UnsecuredLoan_H2

			   ,MAX_DAYSINCEDUEDATE_Vehicleloan_SP
			   ,MAX_DAYSINCEDUEDATE_Vehicleloan_Q1
			   ,MAX_DAYSINCEDUEDATE_Vehicleloan_Q2
			   ,MAX_DAYSINCEDUEDATE_Vehicleloan_H1
			   ,MAX_DAYSINCEDUEDATE_Vehicleloan_H2

			   ,MAX_DAYSINCEDUEDATE_Loan_SP
			   ,MAX_DAYSINCEDUEDATE_Loan_Q1
			   ,MAX_DAYSINCEDUEDATE_Loan_Q2
			   ,MAX_DAYSINCEDUEDATE_Loan_H1
			   ,MAX_DAYSINCEDUEDATE_Loan_H2
			   
			   ,MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_SP
			   ,MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_Q1
			   ,MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_Q2
			   ,MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_H1
			   ,MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_H2

			   ,MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_SP
			   ,MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_Q1
			   ,MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_Q2
			   ,MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_H1
			   ,MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_H2

			   ,MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_SP
			   ,MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_Q1
			   ,MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_Q2
			   ,MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_H1
			   ,MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_H2

			   ,MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_SP
			   ,MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_Q1
			   ,MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_Q2
			   ,MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H1
			   ,MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H2

			   ,MAX_DFT_DUEPAYMENTDAYS_Loan_SP
			   ,MAX_DFT_DUEPAYMENTDAYS_Loan_Q1
			   ,MAX_DFT_DUEPAYMENTDAYS_Loan_Q2
			   ,MAX_DFT_DUEPAYMENTDAYS_Loan_H1
			   ,MAX_DFT_DUEPAYMENTDAYS_Loan_H2

			   ,ISNULL([CREDIT_SCORE_SP],0) [CREDIT_SCORE_SP]
			   ,CASE WHEN (CREDIT_SCORE_SP IS NULL AND CREDIT_SCORE_Q4 IS  NULL) THEN CREDIT_SCORE_SP else (ISNULL(CREDIT_SCORE_SP,0) - ISNULL(CREDIT_SCORE_Q4,0)) end [DFT_CREDIT_SCORE_SP_Q4]
 

		into #loan_product_holdings
		FROM
		(
		SELECT *
		,CASE WHEN #Products_CommercialLoan_SP > 0 then 1 ELSE 0 end  [CommercialLoan_StaticPoolFlag]
		,CASE WHEN #Products_RealEstate_SP > 0 then 1 ELSE 0 end  [RealEstate_StaticPoolFlag]
		,CASE WHEN #Products_SecuredLoan_SP > 0 then 1 ELSE 0 end  [SecuredLoan_StaticPoolFlag]
		,CASE WHEN #Products_UnsecuredLoan_SP > 0 then 1 ELSE 0 end  [UnsecuredLoan_StaticPoolFlag]
		,CASE WHEN #Products_VehicleLoan_SP > 0 then 1 ELSE 0 end  [VehicleLoan_StaticPoolFlag]

		,CASE WHEN #Products_CommercialLoan_Q1 > 0 then 1 ELSE 0 end  [CommercialLoan_Q1Flag]
		,CASE WHEN #Products_RealEstate_Q1 > 0 then 1 ELSE 0 end  [RealEstate_Q1Flag]
		,CASE WHEN #Products_SecuredLoan_Q1 > 0 then 1 ELSE 0 end  [SecuredLoan_Q1Flag]
		,CASE WHEN #Products_UnsecuredLoan_Q1 > 0 then 1 ELSE 0 end  [UnsecuredLoan_Q1Flag]
		,CASE WHEN #Products_VehicleLoan_Q1 > 0 then 1 ELSE 0 end  [VehicleLoan_Q1Flag]
		FROM
		 (SELECT  SSN [SSN]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_CommercialLoan_SP] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q1' THEN UNID END) as [#Products_CommercialLoan_Q1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q2' THEN UNID END) as [#Products_CommercialLoan_Q2]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q3' THEN UNID END) as [#Products_CommercialLoan_Q3]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q4' THEN UNID END) as [#Products_CommercialLoan_Q4] 	
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND HalfYearly = 'H1' THEN UNID END) as [#Products_CommercialLoan_H1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND HalfYearly = 'H2' THEN UNID END) as [#Products_CommercialLoan_H2]					 		 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_RealEstate_SP] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q1' THEN UNID END) as  [#Products_RealEstate_Q1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q2' THEN UNID END) as  [#Products_RealEstate_Q2]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q3' THEN UNID END) as [#Products_RealEstate_Q3]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q4' THEN UNID END) as [#Products_RealEstate_Q4]		
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND HalfYearly = 'H1' THEN UNID END) as  [#Products_RealEstate_H1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND HalfYearly = 'H2' THEN UNID END) as  [#Products_RealEstate_H2]		
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_SecuredLoan_SP]
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q1' THEN UNID END) as [#Products_SecuredLoan_Q1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q2' THEN UNID END) as [#Products_SecuredLoan_Q2]
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q3' THEN UNID END) as [#Products_SecuredLoan_Q3]
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q4' THEN UNID END) as [#Products_SecuredLoan_Q4] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND HalfYearly = 'H1' THEN UNID END) as [#Products_SecuredLoan_H1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND HalfYearly = 'H2' THEN UNID END) as [#Products_SecuredLoan_H2]
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_UnsecuredLoan_SP]
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q1' THEN UNID END) as [#Products_UnsecuredLoan_Q1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q2' THEN UNID END) as [#Products_UnsecuredLoan_Q2]
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q3' THEN UNID END) as [#Products_UnsecuredLoan_Q3]
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q4' THEN UNID END) as [#Products_UnsecuredLoan_Q4]
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND HalfYearly = 'H1' THEN UNID END) as [#Products_UnsecuredLoan_H1] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND HalfYearly = 'H2' THEN UNID END) as [#Products_UnsecuredLoan_H2]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_VehicleLoan_SP]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q1' THEN UNID END) as [#Products_VehicleLoan_Q1]      
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q2' THEN UNID END) as [#Products_VehicleLoan_Q2]      
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q3' THEN UNID END) as [#Products_VehicleLoan_Q3]      
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q4' THEN UNID END) as [#Products_VehicleLoan_Q4] 
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND HalfYearly = 'H1' THEN UNID END) as [#Products_VehicleLoan_H1]      
				,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND HalfYearly = 'H2' THEN UNID END) as [#Products_VehicleLoan_H2]  				     
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Staticpool' THEN UNID END) as [#Products_Others_SP]
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q1' THEN UNID END) as [#Products_Others_Q1]       
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q2' THEN UNID END) as [#Products_Others_Q2]       
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q3' THEN UNID END) as [#Products_Others_Q3]       
				,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q4' THEN UNID END) as [#Products_Others_Q4]     
		
				,COUNT(Distinct CASE WHEN Quarters = 'Staticpool' THEN UNID END) as [#Products_Loan_SP]
				,COUNT(Distinct CASE WHEN Quarters = 'Q1' THEN UNID END) as [#Products_Loan_Q1]       
				,COUNT(Distinct CASE WHEN Quarters = 'Q2' THEN UNID END) as [#Products_Loan_Q2]       
				,COUNT(Distinct CASE WHEN Quarters = 'Q3' THEN UNID END) as [#Products_Loan_Q3]       
				,COUNT(Distinct CASE WHEN Quarters = 'Q4' THEN UNID END) as [#Products_Loan_Q4]
				,COUNT(Distinct CASE WHEN HalfYearly = 'H1' THEN UNID END) as [#Products_Loan_H1]       
				,COUNT(Distinct CASE WHEN HalfYearly = 'H2' THEN UNID END) as [#Products_Loan_H2] 


				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' THEN MOB END) [CommercialLoan_MOB]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' THEN MOB END) [RealEstate_MOB]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' THEN MOB END) [SecuredLoan_MOB]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' THEN MOB END) [UnsecuredLoan_MOB]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' THEN MOB END) [Vehicleloan_MOB]
				,MAX(CASE WHEN Product_Flag = 'Others' THEN MOB END) [Others_MOB] 
				,MAX(MOB) [MAX_Loan_MOB]

				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_CommercialLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_CommercialLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_CommercialLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_CommercialLoan_Q4]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_CommercialLoan_H1]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_CommercialLoan_H2]

				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate_Q1]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate_Q2]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate_Q3]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate_Q4]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate_H1]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_RealEstate_H2]

				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_SecuredLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_SecuredLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_SecuredLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_SecuredLoan_Q4]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_SecuredLoan_H1]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_SecuredLoan_H2]

				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_UnsecuredLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_UnsecuredLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_UnsecuredLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_UnsecuredLoan_Q4]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_UnsecuredLoan_H1]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_UnsecuredLoan_H2]

				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Vehicleloan_Q1]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Vehicleloan_Q2]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Vehicleloan_Q3]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Vehicleloan_Q4]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Vehicleloan_H1]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Vehicleloan_H2]				
					
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Others_Q1]
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Others_Q2]
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Others_Q3]
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Others_Q4]
				,SUM(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Others_H1]
				,SUM(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Others_H2]


				,SUM(CASE WHEN Quarters = 'Q1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Loan_Q1]
				,SUM(CASE WHEN Quarters = 'Q2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Loan_Q2]
				,SUM(CASE WHEN Quarters = 'Q3' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Loan_Q3]
				,SUM(CASE WHEN Quarters = 'Q4' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Loan_Q4]
				,SUM(CASE WHEN HalfYearly = 'H1' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Loan_H1]
				,SUM(CASE WHEN HalfYearly = 'H2' THEN PAYMENTCOUNT END) [PAYMENTCOUNT_Loan_H2]

				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_CommercialLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_CommercialLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_CommercialLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_CommercialLoan_Q4]
			    ,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_CommercialLoan_H1]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_CommercialLoan_H2]

				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate_Q1]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate_Q2]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate_Q3]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate_Q4]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate_H1]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_RealEstate_H2]

				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_SecuredLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_SecuredLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_SecuredLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_SecuredLoan_Q4]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_SecuredLoan_H1]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_SecuredLoan_H2]

				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_UnsecuredLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_UnsecuredLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_UnsecuredLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_UnsecuredLoan_Q4]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_UnsecuredLoan_H1]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_UnsecuredLoan_H2]

				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Vehicleloan_Q1]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Vehicleloan_Q2]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Vehicleloan_Q3]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Vehicleloan_Q4]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Vehicleloan_H1]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Vehicleloan_H2]

				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Others_Q1]	
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Others_Q2]	
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Others_Q3]	
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Others_Q4]
				,SUM(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Others_H1]	
				,SUM(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Others_H2]

				,SUM(CASE WHEN Quarters = 'Q1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Loan_Q1]	
				,SUM(CASE WHEN Quarters = 'Q2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Loan_Q2]	
				,SUM(CASE WHEN Quarters = 'Q3' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Loan_Q3]	
				,SUM(CASE WHEN Quarters = 'Q4' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Loan_Q4]
				,SUM(CASE WHEN HalfYearly = 'H1' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Loan_H1]	
				,SUM(CASE WHEN HalfYearly = 'H2' THEN ORIGINALBALANCE END) [SUM_OriginalBalance_Loan_H2]			

				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_CommercialLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_CommercialLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_CommercialLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_CommercialLoan_Q4]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H1' THEN PAYMENT END) [SUM_PAYMENT_CommercialLoan_H1]
				,SUM(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H2' THEN PAYMENT END) [SUM_PAYMENT_CommercialLoan_H2]

				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_RealEstate_Q1]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_RealEstate_Q2]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_RealEstate_Q3]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_RealEstate_Q4]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H1' THEN PAYMENT END) [SUM_PAYMENT_RealEstate_H1]
				,SUM(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H2' THEN PAYMENT END) [SUM_PAYMENT_RealEstate_H2]

				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_SecuredLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_SecuredLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_SecuredLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_SecuredLoan_Q4]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H1' THEN PAYMENT END) [SUM_PAYMENT_SecuredLoan_H1]
				,SUM(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H2' THEN PAYMENT END) [SUM_PAYMENT_SecuredLoan_H2]

				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_UnsecuredLoan_Q1]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_UnsecuredLoan_Q2]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_UnsecuredLoan_Q3]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_UnsecuredLoan_Q4]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H1' THEN PAYMENT END) [SUM_PAYMENT_UnsecuredLoan_H1]
				,SUM(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H2' THEN PAYMENT END) [SUM_PAYMENT_UnsecuredLoan_H2]

				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_Vehicleloan_Q1]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_Vehicleloan_Q2]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_Vehicleloan_Q3]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_Vehicleloan_Q4]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H1' THEN PAYMENT END) [SUM_PAYMENT_Vehicleloan_H1]
				,SUM(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H2' THEN PAYMENT END) [SUM_PAYMENT_Vehicleloan_H2]

				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_Others_Q1]	
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_Others_Q2]	
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_Others_Q3]	
				,SUM(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_Others_Q4]
				,SUM(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H1' THEN PAYMENT END) [SUM_PAYMENT_Others_H1]	
				,SUM(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H2' THEN PAYMENT END) [SUM_PAYMENT_Others_H2]


				,SUM(CASE WHEN Quarters = 'Q1' THEN PAYMENT END) [SUM_PAYMENT_Loan_Q1]	
				,SUM(CASE WHEN Quarters = 'Q2' THEN PAYMENT END) [SUM_PAYMENT_Loan_Q2]	
				,SUM(CASE WHEN Quarters = 'Q3' THEN PAYMENT END) [SUM_PAYMENT_Loan_Q3]	
				,SUM(CASE WHEN Quarters = 'Q4' THEN PAYMENT END) [SUM_PAYMENT_Loan_Q4]
				,SUM(CASE WHEN HalfYearly = 'H1' THEN PAYMENT END) [SUM_PAYMENT_Loan_H1]	
				,SUM(CASE WHEN HalfYearly = 'H2' THEN PAYMENT END) [SUM_PAYMENT_Loan_H2]


				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_CommercialLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_CommercialLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_CommercialLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_CommercialLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H1' THEN INTERESTRATE END) [MAX_INTERESTRATE_CommercialLoan_H1]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H2' THEN INTERESTRATE END) [MAX_INTERESTRATE_CommercialLoan_H2]

				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate_Q1]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate_Q2]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate_Q3]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate_Q4]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H1' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate_H1]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H2' THEN INTERESTRATE END) [MAX_INTERESTRATE_RealEstate_H2]

				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_SecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_SecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_SecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_SecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H1' THEN INTERESTRATE END) [MAX_INTERESTRATE_SecuredLoan_H1]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H2' THEN INTERESTRATE END) [MAX_INTERESTRATE_SecuredLoan_H2]

				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_UnsecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_UnsecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_UnsecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_UnsecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H1' THEN INTERESTRATE END) [MAX_INTERESTRATE_UnsecuredLoan_H1]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H2' THEN INTERESTRATE END) [MAX_INTERESTRATE_UnsecuredLoan_H2]

				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_Vehicleloan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_Vehicleloan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_Vehicleloan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_Vehicleloan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H1' THEN INTERESTRATE END) [MAX_INTERESTRATE_Vehicleloan_H1]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H2' THEN INTERESTRATE END) [MAX_INTERESTRATE_Vehicleloan_H2]

				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_Others_Q1]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_Others_Q2]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_Others_Q3]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_Others_Q4]
				,MAX(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H1' THEN INTERESTRATE END) [MAX_INTERESTRATE_Others_H1]	
				,MAX(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H2' THEN INTERESTRATE END) [MAX_INTERESTRATE_Others_H2]	

				,MAX(CASE WHEN Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_Q1]	
				,MAX(CASE WHEN Quarters = 'Q2' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_Q2]	
				,MAX(CASE WHEN Quarters = 'Q3' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_Q3]	
				,MAX(CASE WHEN Quarters = 'Q4' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_Q4]
				,MAX(CASE WHEN HalfYearly = 'H1' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_H1]	
				,MAX(CASE WHEN HalfYearly = 'H2' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_H2]

				--,CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q1' THEN (SELECT min(OPENDATE) FROM #membership_loan) ELSE NULL END [Total_CommercialLoan_Q4] 		 		 
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_CommercialLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_CommercialLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_CommercialLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_CommercialLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_CommercialLoan_H1]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_CommercialLoan_H2]

				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate_Q1]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate_Q2]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate_Q3]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate_Q4]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate_H1]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_RealEstate_H2]

				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_SecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_SecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_SecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_SecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_SecuredLoan_H1]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_SecuredLoan_H2]

				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_UnsecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_UnsecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_UnsecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_UnsecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_UnsecuredLoan_H1]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_UnsecuredLoan_H2]

				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Vehicleloan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Vehicleloan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Vehicleloan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Vehicleloan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Vehicleloan_H1]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Vehicleloan_H2]

				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Others_Q1]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Others_Q2]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Others_Q3]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Others_Q4]
				,MAX(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Others_H1]	
				,MAX(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Others_H2]					
		
				,MAX(CASE WHEN Quarters = 'Q1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Loan_Q1]	
				,MAX(CASE WHEN Quarters = 'Q2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Loan_Q2]	
				,MAX(CASE WHEN Quarters = 'Q3' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Loan_Q3]	
				,MAX(CASE WHEN Quarters = 'Q4' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Loan_Q4]	
				,MAX(CASE WHEN HalfYearly = 'H1' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Loan_H1]	
				,MAX(CASE WHEN HalfYearly = 'H2' THEN CREDITLIMIT END) [MAX_CREDITLIMIT_Loan_H2]	

				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_CommercialLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_CommercialLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_CommercialLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_CommercialLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H1' THEN DUEDAY1 END) [COUNT_DUEDAY1_CommercialLoan_H1]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H2' THEN DUEDAY1 END) [COUNT_DUEDAY1_CommercialLoan_H2]

				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate_Q1]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate_Q2]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate_Q3]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate_Q4]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H1' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate_H1]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H2' THEN DUEDAY1 END) [COUNT_DUEDAY1_RealEstate_H2]

				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_SecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_SecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_SecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_SecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H1' THEN DUEDAY1 END) [COUNT_DUEDAY1_SecuredLoan_H1]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H2' THEN DUEDAY1 END) [COUNT_DUEDAY1_SecuredLoan_H2]

				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_UnsecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_UnsecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_UnsecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_UnsecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H1' THEN DUEDAY1 END) [COUNT_DUEDAY1_UnsecuredLoan_H1]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H2' THEN DUEDAY1 END) [COUNT_DUEDAY1_UnsecuredLoan_H2]

				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_Vehicleloan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_Vehicleloan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_Vehicleloan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_Vehicleloan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H1' THEN DUEDAY1 END) [COUNT_DUEDAY1_Vehicleloan_H1]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H2' THEN DUEDAY1 END) [COUNT_DUEDAY1_Vehicleloan_H2]

				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_Others_Q1]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_Others_Q2]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_Others_Q3]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_Others_Q4]
				,MAX(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H1' THEN DUEDAY1 END) [COUNT_DUEDAY1_Others_H1]	
				,MAX(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H2' THEN DUEDAY1 END) [COUNT_DUEDAY1_Others_H2]

		
				,MAX(CASE WHEN Quarters = 'Q1' THEN DUEDAY1 END) [COUNT_DUEDAY1_Loan_Q1]	
				,MAX(CASE WHEN Quarters = 'Q2' THEN DUEDAY1 END) [COUNT_DUEDAY1_Loan_Q2]	
				,MAX(CASE WHEN Quarters = 'Q3' THEN DUEDAY1 END) [COUNT_DUEDAY1_Loan_Q3]	
				,MAX(CASE WHEN Quarters = 'Q4' THEN DUEDAY1 END) [COUNT_DUEDAY1_Loan_Q4]
				,MAX(CASE WHEN HalfYearly = 'H1' THEN DUEDAY1 END) [COUNT_DUEDAY1_Loan_H1]	
				,MAX(CASE WHEN HalfYearly = 'H2' THEN DUEDAY1 END) [COUNT_DUEDAY1_Loan_H2]	
		
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_CommercialLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_CommercialLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_CommercialLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_CommercialLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H1' THEN DUEDAY2 END) [COUNT_DUEDAY2_CommercialLoan_H1]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H2' THEN DUEDAY2 END) [COUNT_DUEDAY2_CommercialLoan_H2]

				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate_Q1]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate_Q2]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate_Q3]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate_Q4]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H1' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate_H1]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H2' THEN DUEDAY2 END) [COUNT_DUEDAY2_RealEstate_H2]

				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_SecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_SecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_SecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_SecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H1' THEN DUEDAY2 END) [COUNT_DUEDAY2_SecuredLoan_H1]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H2' THEN DUEDAY2 END) [COUNT_DUEDAY2_SecuredLoan_H2]

				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_UnsecuredLoan_Q1]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_UnsecuredLoan_Q2]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_UnsecuredLoan_Q3]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_UnsecuredLoan_Q4]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H1' THEN DUEDAY2 END) [COUNT_DUEDAY2_UnsecuredLoan_H1]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H2' THEN DUEDAY2 END) [COUNT_DUEDAY2_UnsecuredLoan_H2]

				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_Vehicleloan_Q1]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_Vehicleloan_Q2]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_Vehicleloan_Q3]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_Vehicleloan_Q4]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H1' THEN DUEDAY2 END) [COUNT_DUEDAY2_Vehicleloan_H1]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H2' THEN DUEDAY2 END) [COUNT_DUEDAY2_Vehicleloan_H2]

				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_Others_Q1]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_Others_Q2]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_Others_Q3]	
				,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_Others_Q4]
				,MAX(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H1' THEN DUEDAY2 END) [COUNT_DUEDAY2_Others_H1]	
				,MAX(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H2' THEN DUEDAY2 END) [COUNT_DUEDAY2_Others_H2]	
		
				,MAX(CASE WHEN Quarters = 'Q1' THEN DUEDAY2 END) [COUNT_DUEDAY2_Loan_Q1]	
				,MAX(CASE WHEN Quarters = 'Q2' THEN DUEDAY2 END) [COUNT_DUEDAY2_Loan_Q2]	
				,MAX(CASE WHEN Quarters = 'Q3' THEN DUEDAY2 END) [COUNT_DUEDAY2_Loan_Q3]	
				,MAX(CASE WHEN Quarters = 'Q4' THEN DUEDAY2 END) [COUNT_DUEDAY2_Loan_Q4]
				,MAX(CASE WHEN HalfYearly = 'H1' THEN DUEDAY2 END) [COUNT_DUEDAY2_Loan_H1]	
				,MAX(CASE WHEN HalfYearly = 'H2' THEN DUEDAY2 END) [COUNT_DUEDAY2_Loan_H2]

				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' THEN Month_to_Maturity END) [CommercialLoan_Month_to_Maturity]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' THEN Month_to_Maturity END) [RealEstate_Month_to_Maturity]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' THEN Month_to_Maturity END) [SecuredLoan_Month_to_Maturity]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' THEN Month_to_Maturity END) [UnsecuredLoan_Month_to_Maturity]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' THEN Month_to_Maturity END) [Vehicleloan_Month_to_Maturity]
				,MAX(CASE WHEN Product_Flag = 'Others' THEN Month_to_Maturity END) [Others_Month_to_Maturity] 	
				,MAX(Month_to_Maturity) [Max_Loan_Month_to_Maturity]

				,MIN(CASE WHEN Product_Flag = 'Commercial_loan' THEN OPENDATE END) [CommercialLoan_OPENDATE]
				,MIN(CASE WHEN Product_Flag = 'Real_Estate_loan' THEN OPENDATE END) [RealEstate_OPENDATE]
				,MIN(CASE WHEN Product_Flag = 'SecuredLoan' THEN OPENDATE END) [SecuredLoan_OPENDATE]
				,MIN(CASE WHEN Product_Flag = 'UnsecuredLoan' THEN OPENDATE END) [UnsecuredLoan_OPENDATE]
				,MIN(CASE WHEN Product_Flag = 'Vehicleloan' THEN OPENDATE END) [Vehicleloan_OPENDATE]
				,MIN(CASE WHEN Product_Flag = 'Others' THEN OPENDATE END) [Others_OPENDATE] 
				,MIN(OPENDATE) [Min_Loan_OPENDATE] 

				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' THEN CLOSEDATE END) [CommercialLoan_CLOSEDATE]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' THEN CLOSEDATE END) [RealEstate_CLOSEDATE]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' THEN CLOSEDATE END) [SecuredLoan_CLOSEDATE]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' THEN CLOSEDATE END) [UnsecuredLoan_CLOSEDATE]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' THEN CLOSEDATE END) [Vehicleloan_CLOSEDATE]
				,MAX(CASE WHEN Product_Flag = 'Others' THEN CLOSEDATE END) [Others_CLOSEDATE]
				,MAX(CLOSEDATE) [Max_Loan_CLOSEDATE]
				,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_CommercialLoan_SP]
				,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_RealEstate_SP]
				,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_SecuredLoan_SP]
				,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_UnsecuredLoan_SP]
				,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_Vehicleloan_SP]
				,MAX(CASE WHEN Product_Flag = 'Others'and Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_Others_SP]
				,MAX(CASE WHEN Quarters = 'Staticpool' THEN CRPMTCURRENT END) [Delinquency_Loan_SP]	
			
				,MAX( CASE WHEN Quarters = 'Staticpool' THEN CREDITSCORE END) [CREDIT_SCORE_SP]
				,MAX( CASE WHEN Quarters = 'Q4' THEN CREDITSCORE END) [CREDIT_SCORE_Q4]

			  ,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Commercial_loan_SP]
			  ,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Commercial_loan_Q1]
			  ,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Commercial_loan_Q2]
			  ,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Commercial_loan_Q3]
			  ,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Commercial_loan_Q4]
			  ,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Commercial_loan_H1]
			  ,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Commercial_loan_H2]
						
			  ,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Real_Estate_loan_SP]
			  ,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q1]
			  ,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q2]
			  ,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q3]
			  ,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q4]
			  ,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Real_Estate_loan_H1]
			  ,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Real_Estate_loan_H2]

			  ,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SecuredLoan_SP]
			  ,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SecuredLoan_Q1]
			  ,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SecuredLoan_Q2]
			  ,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SecuredLoan_Q3]
			  ,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SecuredLoan_Q4]
			  ,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SecuredLoan_H1]
			  ,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SecuredLoan_H2]
               
			  ,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_UnsecuredLoan_SP]
			  ,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q1]
			  ,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q2]
			  ,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q3]
			  ,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q4]
			  ,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_UnsecuredLoan_H1]
			  ,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_UnsecuredLoan_H2]

			  ,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Vehicleloan_SP]
			  ,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Vehicleloan_Q1]
			  ,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Vehicleloan_Q2]
			  ,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Vehicleloan_Q3]
			  ,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Vehicleloan_Q4]
			  ,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Vehicleloan_H1]
			  ,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Vehicleloan_H2]

			  ,AVG(CASE WHEN Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Loan_SP]
			  ,AVG(CASE WHEN Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Loan_Q1]
			  ,AVG(CASE WHEN Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Loan_Q2]
			  ,AVG(CASE WHEN Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Loan_Q3]
			  ,AVG(CASE WHEN Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Loan_Q4]
			  ,AVG(CASE WHEN HalfYearly = 'H1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Loan_H1]
			  ,AVG(CASE WHEN HalfYearly = 'H2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_Loan_H2]

			  ,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Staticpool'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Commercial_loan_SP]
			  ,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Commercial_loan_Q1]
			  ,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Commercial_loan_Q2]
			  ,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q3'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Commercial_loan_Q3]
			  ,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q4'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Commercial_loan_Q4]
			  ,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H1'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Commercial_loan_H1]
			  ,AVG(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H2'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Commercial_loan_H2]
						
			  ,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Staticpool'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Real_Estate_loan_SP]
			  ,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Real_Estate_loan_Q1]
			  ,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Real_Estate_loan_Q2]
			  ,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q3'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Real_Estate_loan_Q3]
			  ,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q4'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Real_Estate_loan_Q4]
			  ,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H1'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Real_Estate_loan_H1]
			  ,AVG(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H2'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Real_Estate_loan_H2]

			  ,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Staticpool'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Real_Estate_loan_SP]
			  ,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Real_Estate_loan_Q1]
			  ,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Real_Estate_loan_Q2]
			  ,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H1'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Real_Estate_loan_H1]
			  ,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H2'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Real_Estate_loan_H2]

			  ,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Staticpool'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_SP]
			  ,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_Q1]
			  ,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_Q2]
			  ,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H1'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_H1]
			  ,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H2'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_H2]


			  ,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Staticpool'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_SecuredLoan_SP]
			  ,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_SecuredLoan_Q1]
			  ,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_SecuredLoan_Q2]
			  ,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q3'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_SecuredLoan_Q3]
			  ,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q4'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_SecuredLoan_Q4]
			  ,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H1'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_SecuredLoan_H1]
			  ,AVG(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H2'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_SecuredLoan_H2]
               
			  ,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Staticpool'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_SecuredLoan_SP]
			  ,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_SecuredLoan_Q1]
			  ,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_SecuredLoan_Q2]
			  ,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H1'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_SecuredLoan_H1]
			  ,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H2'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_SecuredLoan_H2]
      
	  		  ,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Staticpool'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_SP]
			  ,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_Q1]
			  ,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_Q2]
			  ,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H1'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_H1]
			  ,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H2'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_H2]

			  ,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Staticpool'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_UnsecuredLoan_SP]
			  ,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_UnsecuredLoan_Q1]
			  ,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_UnsecuredLoan_Q2]
			  ,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q3'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_UnsecuredLoan_Q3]
			  ,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q4'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_UnsecuredLoan_Q4]
			  ,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H1'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_UnsecuredLoan_H1]
			  ,AVG(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H2'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_UnsecuredLoan_H2]

			  ,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Staticpool'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_UnsecuredLoan_SP]
			  ,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_UnsecuredLoan_Q1]
			  ,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_UnsecuredLoan_Q2]
			  ,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H1'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_UnsecuredLoan_H1]
			  ,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H2'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_UnsecuredLoan_H2]

			  
			  ,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Staticpool'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_SP]
			  ,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_Q1]
			  ,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_Q2]
			  ,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H1'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_H1]
			  ,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H2'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_H2]


			  ,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Staticpool'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Vehicleloan_SP]
			  ,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Vehicleloan_Q1]
			  ,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Vehicleloan_Q2]
			  ,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q3'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Vehicleloan_Q3]
			  ,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q4'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Vehicleloan_Q4]	
			  ,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H1'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Vehicleloan_H1]
			  ,AVG(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H2'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Vehicleloan_H2]

			  ,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Staticpool'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Vehicleloan_SP]
			  ,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Vehicleloan_Q1]
			  ,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Vehicleloan_Q2]
			  ,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H1'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Vehicleloan_H1]
			  ,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H2'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Vehicleloan_H2]

			  ,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Staticpool'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_SP]
			  ,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_Q1]
			  ,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_Q2]
			  ,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H1'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H1]
			  ,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H2'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H2]
	
	
			  ,AVG(CASE WHEN Quarters = 'Staticpool'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Loan_SP]
			  ,AVG(CASE WHEN Quarters = 'Q1'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Loan_Q1]
			  ,AVG(CASE WHEN Quarters = 'Q2'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Loan_Q2]
			  ,AVG(CASE WHEN Quarters = 'Q3'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Loan_Q3]
			  ,AVG(CASE WHEN Quarters = 'Q4'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Loan_Q4]
			  ,AVG(CASE WHEN HalfYearly = 'H1'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Loan_H1]
			  ,AVG(CASE WHEN HalfYearly = 'H2'  then PAYMENTSKIPS END) [AVG_PAYMENTSKIPS_Loan_H2]

			  ,MAX(CASE WHEN Quarters = 'Staticpool'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Loan_SP]
			  ,MAX(CASE WHEN Quarters = 'Q1'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Loan_Q1]
			  ,MAX(CASE WHEN Quarters = 'Q2'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Loan_Q2]
			  ,MAX(CASE WHEN HalfYearly = 'H1'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Loan_H1]
			  ,MAX(CASE WHEN HalfYearly = 'H2'  then DAYSINCEDUEDATE END) [MAX_DAYSINCEDUEDATE_Loan_H2]

			  ,MAX(CASE WHEN Quarters = 'Staticpool'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Loan_SP]
			  ,MAX(CASE WHEN Quarters = 'Q1'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Loan_Q1]
			  ,MAX(CASE WHEN Quarters = 'Q2'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Loan_Q2]
			  ,MAX(CASE WHEN HalfYearly = 'H1'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Loan_H1]
			  ,MAX(CASE WHEN HalfYearly = 'H2'  then DFT_DUEPAYMENTDAYS END) [MAX_DFT_DUEPAYMENTDAYS_Loan_H2]

					from #membership_loan
					group by SSN ) B) D

					--ON A.SSN = B.SSN

					--group by SSN,Quarters,Product_Flag ) B
					--SELECT TOP 1000 * FROM #loan_product_holdings

					--SELECT TOP 1000 CRPMTCURRENT FROM ARCUSYM000..LOAN

		--SELECT COUNT(DISTINCT SSN001) FROM #loan_product_holdings

		-- DISTINCT UNID FROM #membership_loan			

			 DROP TABLE IF EXISTS #static_unid
			 SELECT DISTINCT UNID,PARENTACCOUNT,Product_Flag into #static_unid FROM #membership_loan

------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Loan Transaction Master Data ***\\\-------------------------------------------------------------------



			 DROP TABLE IF EXISTS #temp_loan_transaction
			 SELECT X.SSN,bb.*,Product_Flag 
			 into #temp_loan_transaction
			from 
			(

			select unid,PARENTACCOUNT
			,case when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(dateadd(month,-10,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-11,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-12,@staticpooldate)),112),6))) then 'Q4'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(dateadd(month,-7,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-8,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-9,@staticpooldate)),112),6))) then 'Q3'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(dateadd(month,-4,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-5,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-6,@staticpooldate)),112),6))) then 'Q2'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(dateadd(month,-3,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-2,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-1,@staticpooldate)),112),6))) then 'Q1'
		    when EFFECTIVEDATE_v1 in (left(convert(varchar,@staticpooldate,112),6)) then 'Staticpool' end Quarters
		    ,case when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(DATEADD(month,-12,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-11,@staticpooldate)),112),6)),(left(convert(varchar,DATEADD(month,-10,@staticpooldate),112),6))
			                              ,(left(convert(varchar,EOMONTH(DATEADD(month,-9,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-8,@staticpooldate)),112),6)),(left(convert(varchar,DATEADD(month,-7,@staticpooldate),112),6))) then 'H2'
 		    	  when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(DATEADD(month,-6,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-5,@staticpooldate)),112),6)),(left(convert(varchar,DATEADD(month,-4,@staticpooldate),112),6))
				                          ,(left(convert(varchar,EOMONTH(DATEADD(month,-3,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH((DATEADD(month,-2,@staticpooldate))),112),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-1,@staticpooldate)),112),6))) then 'H1'
		     end HalfYearly			
			,EFFECTIVEDATE_v1
			,ACTIONCODE,SOURCECODE
			,case when ACTIONCODE='A' then 1 else 0 end Loan_addon
			,case when ACTIONCODE='N' then 1 else 0 end New_loan
			,case when ACTIONCODE='N' then 1 else 0 end loan_payment
			,case when SOURCECODE='C' then 1 else 0 end CASH
			,case when SOURCECODE='D' then 1 else 0 end DRAFT
			,case when SOURCECODE='E' then 1 else 0 end ACH
			,case when SOURCECODE='F' then 1 else 0 end FEE
			,case when SOURCECODE='H' then 1 else 0 end HOMEBANKING
			,case when SOURCECODE='I' then 1 else 0 end INSURANCE
			,case when SOURCECODE='K' then 1 else 0 end CHECKS
			,case when SOURCECODE='P' then 1 else 0 end PAYROLL
			,case when SOURCECODE='S' then 1 else 0 end KIOSK
			,case when SOURCECODE='T' then 1 else 0 end  AUDIO_RESPONSE_TELEPHONE
			,CASE WHEN ACTIONCODE='A' AND SOURCECODE='C' THEN 'LOANADDON_CASH'
			WHEN ACTIONCODE='A' AND SOURCECODE='F' THEN 'LOANADDON_FEE'
			WHEN ACTIONCODE='A' AND SOURCECODE='H' THEN 'LOANADDON_HOMEBANKING'
			WHEN ACTIONCODE='A' AND SOURCECODE='I' THEN 'LOANADDON_INSURANCE'
			WHEN ACTIONCODE='A' AND SOURCECODE='K' THEN 'LOANADDON_CHECK'
			WHEN ACTIONCODE='A' AND SOURCECODE='T' THEN 'LOANADDON_RESPONSE_TELEPHONE'
			WHEN ACTIONCODE='A' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'LOANADDON'
			WHEN ACTIONCODE='N' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'NEWLOAN'
			WHEN ACTIONCODE='N' AND SOURCECODE='K' THEN 'NEWLOAN_CHECKS'
			WHEN ACTIONCODE='N' AND SOURCECODE='S' THEN 'NEWLOAN_KIOSK'
			WHEN ACTIONCODE='P' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'LOANPAYMENT'
			
			WHEN ACTIONCODE='P' AND SOURCECODE='C' THEN 'LOANPAYMENT_CASH'
			WHEN ACTIONCODE='P' AND SOURCECODE='D' THEN 'LOANPAYMENT_DRAFT'
			WHEN ACTIONCODE='P' AND SOURCECODE='E' THEN 'LOANPAYMENT_ACH'
			WHEN ACTIONCODE='P' AND SOURCECODE='H' THEN 'LOANPAYMENT_HOMEBANKING'
			WHEN ACTIONCODE='P' AND SOURCECODE='K' THEN 'LOANPAYMENT_CHECKS'
			WHEN ACTIONCODE='P' AND SOURCECODE='P' THEN 'LOANPAYMENT_PAYROLL'
			WHEN ACTIONCODE='P' AND SOURCECODE='S' THEN 'LOANPAYMENT_KIOSK'
			WHEN ACTIONCODE='P' AND SOURCECODE='T' THEN  'LOANPAYMENT_RESPONSE_TELEPHONE' end action_source_code
			,BALANCECHANGE Transaction_amount,NEWBALANCE
			,INTEREST Interest_amount, FEEAMOUNT
			from	(

					select CONCAT(PARENTACCOUNT,PARENTID) UNID
					,PARENTACCOUNT,PARENTID
					,TRANSFERCODE
					,case when len(month(effectivedate))=1 then CONCAT(year(effectivedate),0,month(effectivedate))
					else CONCAT(year(effectivedate),month(effectivedate)) end EFFECTIVEDATE_v1
					,cast(EFFECTIVEDATE as date) EFFECTIVEDATE ,POSTDATE
					,ACTIONCODE,SOURCECODE,BALANCECHANGE,NEWBALANCE,INTEREST,FEEAMOUNT
					from [ARCUSYM000].dbo.LOANTRANSACTION
					where
					ACTIONCODE in ('A','N','P') AND SOURCECODE in ('C','D','E','F','H','I','K','P','S','T')
					 and ACTIONCODE !='C' 
					  ) AA --where parentaccount=0014465465
			 )bb
			   left join #static_unid W
					  on bb.UNID = W.UNID
					  left join #Static_SSN_account X
					  on bb.PARENTACCOUNT = X.AccountNumber
			 where bb.Quarters is not null 
			 and bb.EFFECTIVEDATE_v1 between (Cast((left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6)) as int)) 
			 and cast((left(convert(varchar,@staticpooldate,112),6)) as int)
			
			 --group by PARENTACCOUNT
			 --,UNID
			 --,Quarters,action_source_code

          drop table if exists #transaction_loan

			 SELECT  *
			 INTO #transaction_loan
			 from
			 ((
			 SELECT
			 SSN
			--PARENTACCOUNT
			--,UNID
			--,Quarters
			--,action_source_code
			,sum(CASE WHEN Quarters = 'Staticpool' then Loan_addon END) COUNT_LOAN_ADDON_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then Loan_addon END) COUNT_LOAN_ADDON_Q1
			,sum(CASE WHEN Quarters = 'Q2' then Loan_addon END) COUNT_LOAN_ADDON_Q2
			,sum(CASE WHEN Quarters = 'Q3' then Loan_addon END) COUNT_LOAN_ADDON_Q3
			,sum(CASE WHEN Quarters = 'Q4' then Loan_addon END) COUNT_LOAN_ADDON_Q4
			,sum(CASE WHEN HalfYearly = 'H1' then Loan_addon END) COUNT_LOAN_ADDON_H1
			,sum(CASE WHEN HalfYearly = 'H2' then Loan_addon END) COUNT_LOAN_ADDON_H2

			,sum(CASE WHEN Quarters = 'Staticpool' then New_loan END) COUNT_NEW_LOAN_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then New_loan END) COUNT_NEW_LOAN_Q1
			,sum(CASE WHEN Quarters = 'Q2' then New_loan END) COUNT_NEW_LOAN_Q2
			,sum(CASE WHEN Quarters = 'Q3' then New_loan END) COUNT_NEW_LOAN_Q3
			,sum(CASE WHEN Quarters = 'Q4' then New_loan END) COUNT_NEW_LOAN_Q4	
			,sum(CASE WHEN HalfYearly = 'H1' then New_loan END) COUNT_NEW_LOAN_H1
			,sum(CASE WHEN HalfYearly = 'H2' then New_loan END) COUNT_NEW_LOAN_H2

			,sum(CASE WHEN Quarters = 'Staticpool' then loan_payment END) COUNT_LOAN_PAYMENT_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then loan_payment END) COUNT_LOAN_PAYMENT_Q1
			,sum(CASE WHEN Quarters = 'Q2' then loan_payment END) COUNT_LOAN_PAYMENT_Q2
			,sum(CASE WHEN Quarters = 'Q3' then loan_payment END) COUNT_LOAN_PAYMENT_Q3
			,sum(CASE WHEN Quarters = 'Q4' then loan_payment END) COUNT_LOAN_PAYMENT_Q4
			,sum(CASE WHEN HalfYearly = 'H1' then loan_payment END) COUNT_LOAN_PAYMENT_H1
			,sum(CASE WHEN HalfYearly = 'H2' then loan_payment END) COUNT_LOAN_PAYMENT_H2

			,sum(CASE WHEN Quarters = 'Staticpool' then CASH END) COUNT_CASH_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then CASH END) COUNT_CASH_Q1
			,sum(CASE WHEN Quarters = 'Q2' then CASH END) COUNT_CASH_Q2
			,sum(CASE WHEN Quarters = 'Q3' then CASH END) COUNT_CASH_Q3
			,sum(CASE WHEN Quarters = 'Q4' then CASH END) COUNT_CASH_Q4
			,sum(CASE WHEN HalfYearly = 'H1' then CASH END) COUNT_CASH_H1
			,sum(CASE WHEN HalfYearly = 'H2' then CASH END) COUNT_CASH_H2

			,sum(CASE WHEN Quarters = 'Staticpool' then DRAFT END) COUNT_DRAFT_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then DRAFT END) COUNT_DRAFT_Q1
			,sum(CASE WHEN Quarters = 'Q2' then DRAFT END) COUNT_DRAFT_Q2
			,sum(CASE WHEN Quarters = 'Q3' then DRAFT END) COUNT_DRAFT_Q3
			,sum(CASE WHEN Quarters = 'Q4' then DRAFT END) COUNT_DRAFT_Q4
			,sum(CASE WHEN HalfYearly = 'H1' then DRAFT END) COUNT_DRAFT_H1
			,sum(CASE WHEN HalfYearly = 'H2' then DRAFT END) COUNT_DRAFT_H2

			,sum(CASE WHEN Quarters = 'Staticpool' then ACH END) COUNT_ACH_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then ACH END) COUNT_ACH_Q1
			,sum(CASE WHEN Quarters = 'Q2' then ACH END) COUNT_ACH_Q2
			,sum(CASE WHEN Quarters = 'Q3' then ACH END) COUNT_ACH_Q3
			,sum(CASE WHEN Quarters = 'Q4' then ACH END) COUNT_ACH_Q4
			,sum(CASE WHEN HalfYearly = 'H1' then ACH END) COUNT_ACH_H1
			,sum(CASE WHEN HalfYearly = 'H2' then ACH END) COUNT_ACH_H2

			,sum(CASE WHEN Quarters = 'Staticpool' then FEE END) COUNT_FEE_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then FEE END) COUNT_FEE_Q1
			,sum(CASE WHEN Quarters = 'Q2' then FEE END) COUNT_FEE_Q2
			,sum(CASE WHEN Quarters = 'Q3' then FEE END) COUNT_FEE_Q3
			,sum(CASE WHEN Quarters = 'Q4' then FEE END) COUNT_FEE_Q4
			,sum(CASE WHEN HalfYearly = 'H1' then FEE END) COUNT_FEE_H1
			,sum(CASE WHEN HalfYearly = 'H2' then FEE END) COUNT_FEE_H2

			,sum(CASE WHEN Quarters = 'Staticpool' then HOMEBANKING END) COUNT_HOMEBANKING_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then HOMEBANKING END) COUNT_HOMEBANKING_Q1
			,sum(CASE WHEN Quarters = 'Q2' then HOMEBANKING END) COUNT_HOMEBANKING_Q2
			,sum(CASE WHEN Quarters = 'Q3' then HOMEBANKING END) COUNT_HOMEBANKING_Q3
			,sum(CASE WHEN Quarters = 'Q4' then HOMEBANKING END) COUNT_HOMEBANKING_Q4
			,sum(CASE WHEN HalfYearly = 'H1' then HOMEBANKING END) COUNT_HOMEBANKING_H1
			,sum(CASE WHEN HalfYearly = 'H2' then HOMEBANKING END) COUNT_HOMEBANKING_H2

			,sum(CASE WHEN Quarters = 'Staticpool' then INSURANCE END) COUNT_INSURANCE_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then INSURANCE END) COUNT_INSURANCE_Q1
			,sum(CASE WHEN Quarters = 'Q2' then INSURANCE END) COUNT_INSURANCE_Q2
			,sum(CASE WHEN Quarters = 'Q3' then INSURANCE END) COUNT_INSURANCE_Q3
			,sum(CASE WHEN Quarters = 'Q4' then INSURANCE END) COUNT_INSURANCE_Q4
			,sum(CASE WHEN HalfYearly = 'H1' then INSURANCE END) COUNT_INSURANCE_H1
			,sum(CASE WHEN HalfYearly = 'H2' then INSURANCE END) COUNT_INSURANCE_H2

			,sum(CASE WHEN Quarters = 'Staticpool' then CHECKS END) COUNT_CHECKS_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then CHECKS END) COUNT_CHECKS_Q1
			,sum(CASE WHEN Quarters = 'Q2' then CHECKS END) COUNT_CHECKS_Q2
			,sum(CASE WHEN Quarters = 'Q3' then CHECKS END) COUNT_CHECKS_Q3
			,sum(CASE WHEN Quarters = 'Q4' then CHECKS END) COUNT_CHECKS_Q4
			,sum(CASE WHEN HalfYearly = 'H1' then CHECKS END) COUNT_CHECKS_H1
			,sum(CASE WHEN HalfYearly = 'H2' then CHECKS END) COUNT_CHECKS_H2

			,sum(CASE WHEN Quarters = 'Staticpool' then PAYROLL END) COUNT_PAYROLL_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then PAYROLL END) COUNT_PAYROLL_Q1
			,sum(CASE WHEN Quarters = 'Q2' then PAYROLL END) COUNT_PAYROLL_Q2
			,sum(CASE WHEN Quarters = 'Q3' then PAYROLL END) COUNT_PAYROLL_Q3
			,sum(CASE WHEN Quarters = 'Q4' then PAYROLL END) COUNT_PAYROLL_Q4
			,sum(CASE WHEN HalfYearly = 'H1' then PAYROLL END) COUNT_PAYROLL_H1
			,sum(CASE WHEN HalfYearly = 'H2' then PAYROLL END) COUNT_PAYROLL_H2

			,sum(CASE WHEN Quarters = 'Staticpool' then KIOSK END) COUNT_KIOSK_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then KIOSK END) COUNT_KIOSK_Q1
			,sum(CASE WHEN Quarters = 'Q2' then KIOSK END) COUNT_KIOSK_Q2
			,sum(CASE WHEN Quarters = 'Q3' then KIOSK END) COUNT_KIOSK_Q3
			,sum(CASE WHEN Quarters = 'Q4' then KIOSK END) COUNT_KIOSK_Q4
			,sum(CASE WHEN HalfYearly = 'H1' then KIOSK END) COUNT_KIOSK_H1
			,sum(CASE WHEN HalfYearly = 'H2' then KIOSK END) COUNT_KIOSK_H2

			,sum(CASE WHEN Quarters = 'Staticpool' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_STATICPOOL
			,sum(CASE WHEN Quarters = 'Q1' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Q1
			,sum(CASE WHEN Quarters = 'Q2' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Q2
			,sum(CASE WHEN Quarters = 'Q3' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Q3
			,sum(CASE WHEN Quarters = 'Q4' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Q4
			,sum(CASE WHEN HalfYearly = 'H1' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_H1
			,sum(CASE WHEN HalfYearly = 'H2' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_H2

			 from #temp_loan_transaction
			 --group by PARENTACCOUNT
		     group by SSN
			 ) A
			 left join 
			 ( SELECT SSN [SSN_Tran]
			  --PARENTACCOUNT [PARENTACCOUNT00]
            ,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then Loan_addon END) COUNT_LOAN_ADDON_CommercialLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_Q4	
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then New_loan END) COUNT_NEW_LOAN_CommercialLoan_H2


			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then loan_payment END) COUNT_LOAN_PAYMENT_CommercialLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then CASH END) COUNT_CASH_CommercialLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then DRAFT END) COUNT_DRAFT_CommercialLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then ACH END) COUNT_ACH_CommercialLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then FEE END) COUNT_FEE_CommercialLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then HOMEBANKING END) COUNT_HOMEBANKING_CommercialLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then INSURANCE END) COUNT_INSURANCE_CommercialLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then CHECKS END) COUNT_CHECKS_CommercialLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then PAYROLL END) COUNT_PAYROLL_CommercialLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then KIOSK END) COUNT_KIOSK_CommercialLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_CommercialLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then Interest_amount END) INTEREST_AMOUNT_CommercialLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) FEEAMOUNT_CommercialLoan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCECommercialLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCE_CommercialLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCE_CommercialLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCE_CommercialLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCE_CommercialLoan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCE_CommercialLoan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then NEWBALANCE END) AVG_NEWBALANCE_CommercialLoan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_CommercialLoan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Commercial_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_CommercialLoan_H2


            ,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then Loan_addon END) COUNT_LOAN_ADDON_RealEstate_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_Q4	
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then New_loan END) COUNT_NEW_LOAN_RealEstate_H2


			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then loan_payment END) COUNT_LOAN_PAYMENT_RealEstate_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then CASH END) COUNT_CASH_RealEstate_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then DRAFT END) COUNT_DRAFT_RealEstate_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then ACH END) COUNT_ACH_RealEstate_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then FEE END) COUNT_FEE_RealEstate_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then HOMEBANKING END) COUNT_HOMEBANKING_RealEstate_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then INSURANCE END) COUNT_INSURANCE_RealEstate_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then CHECKS END) COUNT_CHECKS_RealEstate_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then PAYROLL END) COUNT_PAYROLL_RealEstate_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then KIOSK END) COUNT_KIOSK_RealEstate_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_RealEstate_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) INTEREST_AMOUNT_RealEstate_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) FEEAMOUNT_RealEstate_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCERealEstate_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then NEWBALANCE END) AVG_NEWBALANCE_RealEstate_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then Interest_amount END) AVG_INTEREST_AMOUNT_RealEstate_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Real_Estate_loan' then FEEAMOUNT END) AVG_FEEAMOUNT_RealEstate_H2

            ,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_SecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_Q4	
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then New_loan END) COUNT_NEW_LOAN_SecuredLoan_H2


			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_SecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then CASH END) COUNT_CASH_SecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then DRAFT END) COUNT_DRAFT_SecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then ACH END) COUNT_ACH_SecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then FEE END) COUNT_FEE_SecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_SecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then INSURANCE END) COUNT_INSURANCE_SecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then CHECKS END) COUNT_CHECKS_SecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then PAYROLL END) COUNT_PAYROLL_SecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then KIOSK END) COUNT_KIOSK_SecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_SecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then Interest_amount END) INTEREST_AMOUNT_SecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) FEEAMOUNT_SecuredLoan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCESecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_SecuredLoan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_SecuredLoan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'SecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_SecuredLoan_H2

            ,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then Loan_addon END) COUNT_LOAN_ADDON_UnsecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_Q4	
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then New_loan END) COUNT_NEW_LOAN_UnsecuredLoan_H2


			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then loan_payment END) COUNT_LOAN_PAYMENT_UnsecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then CASH END) COUNT_CASH_UnsecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then DRAFT END) COUNT_DRAFT_UnsecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then ACH END) COUNT_ACH_UnsecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then FEE END) COUNT_FEE_UnsecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then HOMEBANKING END) COUNT_HOMEBANKING_UnsecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then INSURANCE END) COUNT_INSURANCE_UnsecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then CHECKS END) COUNT_CHECKS_UnsecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then PAYROLL END) COUNT_PAYROLL_UnsecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then KIOSK END) COUNT_KIOSK_UnsecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) INTEREST_AMOUNT_UnsecuredLoan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) FEEAMOUNT_UnsecuredLoan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCEUnsecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then NEWBALANCE END) AVG_NEWBALANCE_UnsecuredLoan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then Interest_amount END) AVG_INTEREST_AMOUNT_UnsecuredLoan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'UnsecuredLoan' then FEEAMOUNT END) AVG_FEEAMOUNT_UnsecuredLoan_H2

            ,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then Loan_addon END) COUNT_LOAN_ADDON_Vehicleloan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_Vehicleloan_Q4	
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then New_loan END) COUNT_NEW_LOAN_Vehicleloan_H2


			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then loan_payment END) COUNT_LOAN_PAYMENT_Vehicleloan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then CASH END) COUNT_CASH_Vehicleloan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then DRAFT END) COUNT_DRAFT_Vehicleloan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then ACH END) COUNT_ACH_Vehicleloan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then FEE END) COUNT_FEE_Vehicleloan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then HOMEBANKING END) COUNT_HOMEBANKING_Vehicleloan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then INSURANCE END) COUNT_INSURANCE_Vehicleloan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then CHECKS END) COUNT_CHECKS_Vehicleloan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then PAYROLL END) COUNT_PAYROLL_Vehicleloan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then KIOSK END) COUNT_KIOSK_Vehicleloan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Vehicleloan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Vehicleloan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then Interest_amount END) INTEREST_AMOUNT_Vehicleloan_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_Vehicleloan_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_Vehicleloan_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_Vehicleloan_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_Vehicleloan_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_Vehicleloan_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_Vehicleloan_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) FEEAMOUNT_Vehicleloan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Vehicleloan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Vehicleloan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Vehicleloan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Vehicleloan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Vehicleloan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Vehicleloan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Vehicleloan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCEVehicleloan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_Vehicleloan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_Vehicleloan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_Vehicleloan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_Vehicleloan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_Vehicleloan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then NEWBALANCE END) AVG_NEWBALANCE_Vehicleloan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_Vehicleloan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_Vehicleloan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_Vehicleloan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_Vehicleloan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_Vehicleloan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_Vehicleloan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then Interest_amount END) AVG_INTEREST_AMOUNT_Vehicleloan_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_Vehicleloan_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_Vehicleloan_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_Vehicleloan_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_Vehicleloan_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_Vehicleloan_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_Vehicleloan_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Vehicleloan' then FEEAMOUNT END) AVG_FEEAMOUNT_Vehicleloan_H2

            ,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then Loan_addon END) COUNT_LOAN_ADDON_Others_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_Q4	
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then New_loan END) COUNT_NEW_LOAN_Others_H2


			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then loan_payment END) COUNT_LOAN_PAYMENT_Others_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then CASH END) COUNT_CASH_Others_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then DRAFT END) COUNT_DRAFT_Others_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then ACH END) COUNT_ACH_Others_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then FEE END) COUNT_FEE_Others_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then HOMEBANKING END) COUNT_HOMEBANKING_Others_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then INSURANCE END) COUNT_INSURANCE_Others_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then CHECKS END) COUNT_CHECKS_Others_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then PAYROLL END) COUNT_PAYROLL_Others_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then KIOSK END) COUNT_KIOSK_Others_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then AUDIO_RESPONSE_TELEPHONE END) COUNT_AUDIO_RESPONSE_TELEPHONE_Others_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then Transaction_amount END) LOAN_TRANSACTION_AMOUNT_Others_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then Interest_amount END) INTEREST_AMOUNT_Others_H2

			,sum(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_SP
			,sum(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_Q1
			,sum(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_Q2
			,sum(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_Q3
			,sum(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_Q4
			,sum(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_H1
			,sum(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then FEEAMOUNT END) FEEAMOUNT_Others_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then Transaction_amount END) AVG_LOAN_TRANSACTION_AMOUNT_Others_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCEOthers_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then NEWBALANCE END) AVG_NEWBALANCE_Others_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then Interest_amount END) AVG_INTEREST_AMOUNT_Others_H2

			,AVG(CASE WHEN Quarters = 'Staticpool' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_SP
			,AVG(CASE WHEN Quarters = 'Q1' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_Q1
			,AVG(CASE WHEN Quarters = 'Q2' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_Q2
			,AVG(CASE WHEN Quarters = 'Q3' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_Q3
			,AVG(CASE WHEN Quarters = 'Q4' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_Q4
			,AVG(CASE WHEN HalfYearly = 'H1' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_H1
			,AVG(CASE WHEN HalfYearly = 'H2' and Product_Flag = 'Others' then FEEAMOUNT END) AVG_FEEAMOUNT_Others_H2
			 FROM #temp_loan_transaction
			 --group by PARENTACCOUNT
			 group by SSN
			 ) B
			 on A.SSN = B.SSN_Tran )


--- Drift of the Loan Transaction data

			 DROP TABLE IF EXISTS #LOAN_TRANSACTION_derived_vars
			 SELECT SSN [SSN002]
			 --PARENTACCOUNT
			        --,UNID
			        ,COUNT_LOAN_ADDON_STATICPOOL
			        ,COUNT_LOAN_ADDON_Q1
					,CASE WHEN ( COUNT_LOAN_ADDON_Q1 IS NULL AND COUNT_LOAN_ADDON_Q2 IS  NULL ) THEN COUNT_LOAN_ADDON_Q1 else (ISNULL(COUNT_LOAN_ADDON_Q1,0)-ISNULL(COUNT_LOAN_ADDON_Q2,0)) end DFT_COUNT_LOAN_ADDON_Q1_Q2

					,COUNT_NEW_LOAN_STATICPOOL
					,COUNT_NEW_LOAN_Q1
					,CASE WHEN ( COUNT_NEW_LOAN_Q1 IS NULL AND COUNT_NEW_LOAN_Q2 IS  NULL ) THEN COUNT_NEW_LOAN_Q1 else (ISNULL(COUNT_NEW_LOAN_Q1,0)-ISNULL(COUNT_NEW_LOAN_Q2,0)) end DFT_COUNT_NEW_LOAN_Q1_Q2

					,COUNT_LOAN_PAYMENT_STATICPOOL
					,COUNT_LOAN_PAYMENT_Q1
					,CASE WHEN ( COUNT_LOAN_PAYMENT_Q1 IS NULL AND COUNT_LOAN_PAYMENT_Q2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_Q1,0) - (ISNULL(COUNT_LOAN_PAYMENT_Q2,0))) end DFT_COUNT_LOAN_PAYMENT_Q1_Q2

					,COUNT_CASH_STATICPOOL
					,COUNT_CASH_Q1
					,CASE WHEN ( COUNT_CASH_Q1 IS NULL AND COUNT_CASH_Q2 IS  NULL ) THEN COUNT_CASH_Q1 else (ISNULL(COUNT_CASH_Q1,0) - ISNULL(COUNT_CASH_Q2,0)) end DFT_COUNT_CASH_Q1_Q2

					,COUNT_DRAFT_STATICPOOL
					,COUNT_DRAFT_Q1
					,CASE WHEN ( COUNT_DRAFT_Q1 IS NULL AND COUNT_DRAFT_Q2 IS  NULL ) THEN COUNT_DRAFT_Q1 else (ISNULL(COUNT_DRAFT_Q1,0)-ISNULL(COUNT_DRAFT_Q2,0)) end DFT_COUNT_DRAFT_Q1_Q2

					,COUNT_ACH_STATICPOOL
					,COUNT_ACH_Q1
					,CASE WHEN ( COUNT_ACH_Q1 IS NULL AND COUNT_ACH_Q2 IS  NULL ) THEN COUNT_ACH_Q1 else (ISNULL(COUNT_ACH_Q1,0)-ISNULL(COUNT_ACH_Q2,0)) end DFT_COUNT_ACH_Q1_Q2

					,COUNT_FEE_STATICPOOL
					,COUNT_FEE_Q1
					,CASE WHEN (COUNT_FEE_Q1 IS NULL AND COUNT_FEE_Q2 IS  NULL ) THEN COUNT_FEE_Q1 else (ISNULL(COUNT_FEE_Q1,0)-ISNULL(COUNT_FEE_Q2,0)) end DFT_COUNT_FEE_Q1_Q2

					,COUNT_HOMEBANKING_STATICPOOL
					,COUNT_HOMEBANKING_Q1
					,CASE WHEN (COUNT_HOMEBANKING_Q1 IS NULL AND COUNT_HOMEBANKING_Q2 IS  NULL ) THEN COUNT_HOMEBANKING_Q1 else (ISNULL(COUNT_HOMEBANKING_Q1,0)-ISNULL(COUNT_HOMEBANKING_Q2,0)) end DFT_COUNT_HOMEBANKING_Q1_Q2

					,COUNT_INSURANCE_STATICPOOL
					,COUNT_INSURANCE_Q1
					,CASE WHEN ( COUNT_INSURANCE_Q1 IS NULL AND COUNT_INSURANCE_Q2 IS  NULL ) THEN COUNT_INSURANCE_Q1 else (ISNULL(COUNT_INSURANCE_Q1,0)-ISNULL(COUNT_INSURANCE_Q2,0)) end DFT_COUNT_INSURANCE_Q1_Q2

					,COUNT_CHECKS_STATICPOOL
					,COUNT_CHECKS_Q1
					,CASE WHEN (COUNT_CHECKS_Q1 IS NULL AND COUNT_CHECKS_Q2 IS  NULL ) THEN COUNT_CHECKS_Q1 else (ISNULL(COUNT_CHECKS_Q1,0)-ISNULL(COUNT_CHECKS_Q2,0)) end DFT_COUNT_CHECKS_Q1_Q2
	
					,COUNT_PAYROLL_STATICPOOL
					,COUNT_PAYROLL_Q1
					,CASE WHEN (COUNT_CHECKS_Q1 IS NULL AND COUNT_CHECKS_Q2 IS  NULL ) THEN COUNT_CHECKS_Q1 else (ISNULL(COUNT_PAYROLL_Q1,0)-ISNULL(COUNT_PAYROLL_Q2,0)) end DFT_COUNT_PAYROLL_Q1_Q2

					,COUNT_KIOSK_STATICPOOL
					,COUNT_KIOSK_Q1
					,CASE WHEN ( COUNT_KIOSK_Q1 IS NULL AND COUNT_KIOSK_Q2 IS  NULL ) THEN COUNT_KIOSK_Q1 else (ISNULL(COUNT_KIOSK_Q1,0)-ISNULL(COUNT_KIOSK_Q2,0)) end DFT_COUNT_KIOSK_Q1_Q2

					,COUNT_AUDIO_RESPONSE_TELEPHONE_STATICPOOL
					,COUNT_AUDIO_RESPONSE_TELEPHONE_Q1
					,CASE WHEN (COUNT_AUDIO_RESPONSE_TELEPHONE_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_Q2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Q1,0)-ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_Q2,0)) end DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_Q1_Q2

	   --      ,COUNT_LOAN_ADDON_CommercialLoan_Q1
			 --,CASE WHEN ( COUNT_LOAN_ADDON_CommercialLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_CommercialLoan_Q2 IS  NULL ) THEN COUNT_LOAN_ADDON_CommercialLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q2,0)) end [DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q2]
			 --,CASE WHEN ( COUNT_LOAN_ADDON_CommercialLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_CommercialLoan_Q3 IS  NULL ) THEN COUNT_LOAN_ADDON_CommercialLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q3,0)) end [DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN ( COUNT_LOAN_ADDON_CommercialLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_CommercialLoan_Q4 IS  NULL ) THEN COUNT_LOAN_ADDON_CommercialLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_CommercialLoan_Q4,0)) end [DFT_COUNT_LOAN_ADDON_CommercialLoan_Q1_Q4]
			 ----,COUNT_NEW_LOAN_CommercialLoan_SP
			 --,COUNT_NEW_LOAN_CommercialLoan_Q1
			 --,CASE WHEN ( COUNT_NEW_LOAN_CommercialLoan_Q1 IS NULL AND COUNT_NEW_LOAN_CommercialLoan_Q2 IS  NULL ) THEN COUNT_NEW_LOAN_CommercialLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q2,0)) end [COUNT_NEW_LOAN_CommercialLoan_Q1_Q2]
			 --,CASE WHEN ( COUNT_NEW_LOAN_CommercialLoan_Q1 IS NULL AND COUNT_NEW_LOAN_CommercialLoan_Q3 IS  NULL ) THEN COUNT_NEW_LOAN_CommercialLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q3,0)) end [COUNT_NEW_LOAN_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN ( COUNT_NEW_LOAN_CommercialLoan_Q1 IS NULL AND COUNT_NEW_LOAN_CommercialLoan_Q4 IS  NULL ) THEN COUNT_NEW_LOAN_CommercialLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_CommercialLoan_Q4,0)) end [COUNT_NEW_LOAN_CommercialLoan_Q1_Q4]
			 ----,COUNT_LOAN_PAYMENT_CommercialLoan_SP
			 --,COUNT_LOAN_PAYMENT_CommercialLoan_Q1
			 --,CASE WHEN ( COUNT_LOAN_PAYMENT_CommercialLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_CommercialLoan_Q2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_CommercialLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q2,0)) end [DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q2]
			 --,CASE WHEN ( COUNT_LOAN_PAYMENT_CommercialLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_CommercialLoan_Q3 IS  NULL ) THEN COUNT_LOAN_PAYMENT_CommercialLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q3,0)) end [DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN ( COUNT_LOAN_PAYMENT_CommercialLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_CommercialLoan_Q4 IS  NULL ) THEN COUNT_LOAN_PAYMENT_CommercialLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_Q4,0)) end [DFT_COUNT_LOAN_PAYMENT_CommercialLoan_Q1_Q4]
			 ----,COUNT_CASH_CommercialLoan_SP
			 --,COUNT_CASH_CommercialLoan_Q1
			 --,CASE WHEN ( COUNT_CASH_CommercialLoan_Q1 IS NULL AND COUNT_CASH_CommercialLoan_Q2 IS  NULL ) THEN COUNT_CASH_CommercialLoan_Q1 else (ISNULL(COUNT_CASH_CommercialLoan_Q1,0) - ISNULL(COUNT_CASH_CommercialLoan_Q2,0)) end [DFT_COUNT_CASH_CommercialLoan_Q1_Q2]
			 --,CASE WHEN ( COUNT_CASH_CommercialLoan_Q1 IS NULL AND COUNT_CASH_CommercialLoan_Q3 IS  NULL ) THEN COUNT_CASH_CommercialLoan_Q1 else (ISNULL(COUNT_CASH_CommercialLoan_Q1,0) - ISNULL(COUNT_CASH_CommercialLoan_Q3,0)) end [DFT_COUNT_CASH_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN ( COUNT_CASH_CommercialLoan_Q1 IS NULL AND COUNT_CASH_CommercialLoan_Q4 IS  NULL ) THEN COUNT_CASH_CommercialLoan_Q1 else (ISNULL(COUNT_CASH_CommercialLoan_Q1,0) - ISNULL(COUNT_CASH_CommercialLoan_Q4,0)) end [DFT_COUNT_CASH_CommercialLoan_Q1_Q4]
			 ----,COUNT_DRAFT_CommercialLoan_SP
			 --,COUNT_DRAFT_CommercialLoan_Q1
			 --,CASE WHEN ( COUNT_DRAFT_CommercialLoan_Q1 IS NULL AND COUNT_DRAFT_CommercialLoan_Q2 IS  NULL ) THEN COUNT_DRAFT_CommercialLoan_Q1 else (ISNULL(COUNT_DRAFT_CommercialLoan_Q1,0) - ISNULL(COUNT_DRAFT_CommercialLoan_Q2,0)) end [DFT_COUNT_DRAFT_CommercialLoan_Q1_Q2]
			 --,CASE WHEN ( COUNT_DRAFT_CommercialLoan_Q1 IS NULL AND COUNT_DRAFT_CommercialLoan_Q3 IS  NULL ) THEN COUNT_DRAFT_CommercialLoan_Q1 else (ISNULL(COUNT_DRAFT_CommercialLoan_Q1,0) - ISNULL(COUNT_DRAFT_CommercialLoan_Q3,0)) end [DFT_COUNT_DRAFT_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN ( COUNT_DRAFT_CommercialLoan_Q1 IS NULL AND COUNT_DRAFT_CommercialLoan_Q4 IS  NULL ) THEN COUNT_DRAFT_CommercialLoan_Q1 else (ISNULL(COUNT_DRAFT_CommercialLoan_Q1,0) - ISNULL(COUNT_DRAFT_CommercialLoan_Q4,0)) end [DFT_COUNT_DRAFT_CommercialLoan_Q1_Q4]
			 ----,COUNT_ACH_CommercialLoan_SP
			 --,COUNT_ACH_CommercialLoan_Q1
			 --,CASE WHEN ( COUNT_ACH_CommercialLoan_Q1 IS NULL AND COUNT_ACH_CommercialLoan_Q2 IS  NULL ) THEN COUNT_ACH_CommercialLoan_Q1 else (ISNULL(COUNT_ACH_CommercialLoan_Q1,0) - ISNULL(COUNT_ACH_CommercialLoan_Q2,0)) end [DFT_COUNT_ACH_CommercialLoan_Q1_Q2]
			 --,CASE WHEN ( COUNT_ACH_CommercialLoan_Q1 IS NULL AND COUNT_ACH_CommercialLoan_Q3 IS  NULL ) THEN COUNT_ACH_CommercialLoan_Q1 else (ISNULL(COUNT_ACH_CommercialLoan_Q1,0) - ISNULL(COUNT_ACH_CommercialLoan_Q3,0)) end [DFT_COUNT_ACH_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN ( COUNT_ACH_CommercialLoan_Q1 IS NULL AND COUNT_ACH_CommercialLoan_Q4 IS  NULL ) THEN COUNT_ACH_CommercialLoan_Q1 else (ISNULL(COUNT_ACH_CommercialLoan_Q1,0) - ISNULL(COUNT_ACH_CommercialLoan_Q4,0)) end [DFT_COUNT_ACH_CommercialLoan_Q1_Q4]
			 ----,COUNT_FEE_CommercialLoan_SP
			 --,COUNT_FEE_CommercialLoan_Q1
			 --,CASE WHEN ( COUNT_FEE_CommercialLoan_Q1 IS NULL AND COUNT_FEE_CommercialLoan_Q2 IS  NULL ) THEN COUNT_FEE_CommercialLoan_Q1 else (ISNULL(COUNT_FEE_CommercialLoan_Q1,0) - ISNULL(COUNT_FEE_CommercialLoan_Q2,0)) end [DFT_COUNT_FEE_CommercialLoan_Q1_Q2]
			 --,CASE WHEN ( COUNT_FEE_CommercialLoan_Q1 IS NULL AND COUNT_FEE_CommercialLoan_Q3 IS  NULL ) THEN COUNT_FEE_CommercialLoan_Q1 else (ISNULL(COUNT_FEE_CommercialLoan_Q1,0) - ISNULL(COUNT_FEE_CommercialLoan_Q3,0)) end [DFT_COUNT_FEE_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN ( COUNT_FEE_CommercialLoan_Q1 IS NULL AND COUNT_FEE_CommercialLoan_Q4 IS  NULL ) THEN COUNT_FEE_CommercialLoan_Q1 else (ISNULL(COUNT_FEE_CommercialLoan_Q1,0) - ISNULL(COUNT_FEE_CommercialLoan_Q4,0)) end [DFT_COUNT_FEE_CommercialLoan_Q1_Q4]
			 ----,COUNT_HOMEBANKING_CommercialLoan_SP
			 --,COUNT_HOMEBANKING_CommercialLoan_Q1
			 --,CASE WHEN (COUNT_HOMEBANKING_CommercialLoan_Q1 IS NULL AND COUNT_HOMEBANKING_CommercialLoan_Q2 IS  NULL ) THEN COUNT_HOMEBANKING_CommercialLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q2,0)) end [DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q2]
			 --,CASE WHEN (COUNT_HOMEBANKING_CommercialLoan_Q1 IS NULL AND COUNT_HOMEBANKING_CommercialLoan_Q3 IS  NULL ) THEN COUNT_HOMEBANKING_CommercialLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q3,0)) end [DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN (COUNT_HOMEBANKING_CommercialLoan_Q1 IS NULL AND COUNT_HOMEBANKING_CommercialLoan_Q4 IS  NULL ) THEN COUNT_HOMEBANKING_CommercialLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_CommercialLoan_Q4,0)) end [DFT_COUNT_HOMEBANKING_CommercialLoan_Q1_Q4]
			 ----,COUNT_INSURANCE_CommercialLoan_SP
			 --,COUNT_INSURANCE_CommercialLoan_Q1
			 --,CASE WHEN (COUNT_INSURANCE_CommercialLoan_Q1 IS NULL AND COUNT_INSURANCE_CommercialLoan_Q2 IS  NULL ) THEN COUNT_INSURANCE_CommercialLoan_Q1 else (ISNULL(COUNT_INSURANCE_CommercialLoan_Q1,0) - ISNULL(COUNT_INSURANCE_CommercialLoan_Q2,0)) end [DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q2]
			 --,CASE WHEN (COUNT_INSURANCE_CommercialLoan_Q1 IS NULL AND COUNT_INSURANCE_CommercialLoan_Q3 IS  NULL ) THEN COUNT_INSURANCE_CommercialLoan_Q1 else (ISNULL(COUNT_INSURANCE_CommercialLoan_Q1,0) - ISNULL(COUNT_INSURANCE_CommercialLoan_Q3,0)) end [DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN (COUNT_INSURANCE_CommercialLoan_Q1 IS NULL AND COUNT_INSURANCE_CommercialLoan_Q4 IS  NULL ) THEN COUNT_INSURANCE_CommercialLoan_Q1 else (ISNULL(COUNT_INSURANCE_CommercialLoan_Q1,0) - ISNULL(COUNT_INSURANCE_CommercialLoan_Q4,0)) end [DFT_COUNT_INSURANCE_CommercialLoan_Q1_Q4]
			 ----,COUNT_CHECKS_CommercialLoan_SP
			 --,COUNT_CHECKS_CommercialLoan_Q1
			 --,CASE WHEN (COUNT_CHECKS_CommercialLoan_Q1 IS NULL AND COUNT_CHECKS_CommercialLoan_Q2 IS  NULL ) THEN COUNT_CHECKS_CommercialLoan_Q1 else (ISNULL(COUNT_CHECKS_CommercialLoan_Q1,0) - ISNULL(COUNT_CHECKS_CommercialLoan_Q2,0)) end [DFT_COUNT_CHECKS_CommercialLoan_Q1_Q2] 
			 --,CASE WHEN (COUNT_CHECKS_CommercialLoan_Q1 IS NULL AND COUNT_CHECKS_CommercialLoan_Q3 IS  NULL ) THEN COUNT_CHECKS_CommercialLoan_Q1 else (ISNULL(COUNT_CHECKS_CommercialLoan_Q1,0) - ISNULL(COUNT_CHECKS_CommercialLoan_Q3,0)) end [DFT_COUNT_CHECKS_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN (COUNT_CHECKS_CommercialLoan_Q1 IS NULL AND COUNT_CHECKS_CommercialLoan_Q4 IS  NULL ) THEN COUNT_CHECKS_CommercialLoan_Q1 else (ISNULL(COUNT_CHECKS_CommercialLoan_Q1,0) - ISNULL(COUNT_CHECKS_CommercialLoan_Q4,0)) end [DFT_COUNT_CHECKS_CommercialLoan_Q1_Q4]
			 ----,COUNT_PAYROLL_CommercialLoan_SP
			 --,COUNT_PAYROLL_CommercialLoan_Q1
			 --,CASE WHEN (COUNT_PAYROLL_CommercialLoan_Q1 IS NULL AND COUNT_PAYROLL_CommercialLoan_Q2 IS  NULL ) THEN COUNT_PAYROLL_CommercialLoan_Q1 else (ISNULL(COUNT_PAYROLL_CommercialLoan_Q1,0) - ISNULL(COUNT_PAYROLL_CommercialLoan_Q2,0)) end [DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q2]
			 --,CASE WHEN (COUNT_PAYROLL_CommercialLoan_Q1 IS NULL AND COUNT_PAYROLL_CommercialLoan_Q3 IS  NULL ) THEN COUNT_PAYROLL_CommercialLoan_Q1 else (ISNULL(COUNT_PAYROLL_CommercialLoan_Q1,0) - ISNULL(COUNT_PAYROLL_CommercialLoan_Q3,0)) end [DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN (COUNT_PAYROLL_CommercialLoan_Q1 IS NULL AND COUNT_PAYROLL_CommercialLoan_Q4 IS  NULL ) THEN COUNT_PAYROLL_CommercialLoan_Q1 else (ISNULL(COUNT_PAYROLL_CommercialLoan_Q1,0) - ISNULL(COUNT_PAYROLL_CommercialLoan_Q4,0)) end [DFT_COUNT_PAYROLL_CommercialLoan_Q1_Q4]
			 ----,COUNT_KIOSK_CommercialLoan_SP
			 --,COUNT_KIOSK_CommercialLoan_Q1
			 --,CASE WHEN (COUNT_KIOSK_CommercialLoan_Q1 IS NULL AND COUNT_KIOSK_CommercialLoan_Q2 IS  NULL ) THEN COUNT_KIOSK_CommercialLoan_Q1 else (ISNULL(COUNT_KIOSK_CommercialLoan_Q1,0) - ISNULL(COUNT_KIOSK_CommercialLoan_Q2,0)) end [DFT_COUNT_KIOSK_CommercialLoan_Q1_Q2]
			 --,CASE WHEN (COUNT_KIOSK_CommercialLoan_Q1 IS NULL AND COUNT_KIOSK_CommercialLoan_Q3 IS  NULL ) THEN COUNT_KIOSK_CommercialLoan_Q1 else (ISNULL(COUNT_KIOSK_CommercialLoan_Q1,0) - ISNULL(COUNT_KIOSK_CommercialLoan_Q3,0)) end [DFT_COUNT_KIOSK_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN (COUNT_KIOSK_CommercialLoan_Q1 IS NULL AND COUNT_KIOSK_CommercialLoan_Q4 IS  NULL ) THEN COUNT_KIOSK_CommercialLoan_Q1 else (ISNULL(COUNT_KIOSK_CommercialLoan_Q1,0) - ISNULL(COUNT_KIOSK_CommercialLoan_Q4,0)) end [DFT_COUNT_KIOSK_CommercialLoan_Q1_Q4]
			 ----,COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_SP
			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1
			 --,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q2]
			 --,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q3 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q3,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q4 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q4,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_Q1_Q4]

			 --,LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1
			 --,CASE WHEN (LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q2]
			 --,CASE WHEN (LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN (LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q4]
			 ----,INTEREST_AMOUNT_CommercialLoan_SP
			 --,INTEREST_AMOUNT_CommercialLoan_Q1
			 --,CASE WHEN (INTEREST_AMOUNT_CommercialLoan_Q1 IS NULL AND INTEREST_AMOUNT_CommercialLoan_Q2 IS  NULL ) THEN INTEREST_AMOUNT_CommercialLoan_Q1 else (ISNULL(INTEREST_AMOUNT_CommercialLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_CommercialLoan_Q2,0)) end [DFT_INTEREST_AMOUNT_CommercialLoan_Q1_Q2]
			 --,CASE WHEN (INTEREST_AMOUNT_CommercialLoan_Q1 IS NULL AND INTEREST_AMOUNT_CommercialLoan_Q3 IS  NULL ) THEN INTEREST_AMOUNT_CommercialLoan_Q1 else (ISNULL(INTEREST_AMOUNT_CommercialLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_CommercialLoan_Q3,0)) end [DFT_INTEREST_AMOUNT_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN (INTEREST_AMOUNT_CommercialLoan_Q1 IS NULL AND INTEREST_AMOUNT_CommercialLoan_Q4 IS  NULL ) THEN INTEREST_AMOUNT_CommercialLoan_Q1 else (ISNULL(INTEREST_AMOUNT_CommercialLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_CommercialLoan_Q4,0)) end [DFT_INTEREST_AMOUNT_CommercialLoan_Q1_Q4]
			 ----,FEEAMOUNT_CommercialLoan_SP
			 --,FEEAMOUNT_CommercialLoan_Q1
			 --,CASE WHEN (FEEAMOUNT_CommercialLoan_Q1 IS NULL AND FEEAMOUNT_CommercialLoan_Q2 IS  NULL ) THEN FEEAMOUNT_CommercialLoan_Q1 else (ISNULL(FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(FEEAMOUNT_CommercialLoan_Q2,0)) end [DFT_FEEAMOUNT_CommercialLoan_Q1_Q2]
			 --,CASE WHEN (FEEAMOUNT_CommercialLoan_Q1 IS NULL AND FEEAMOUNT_CommercialLoan_Q3 IS  NULL ) THEN FEEAMOUNT_CommercialLoan_Q1 else (ISNULL(FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(FEEAMOUNT_CommercialLoan_Q3,0)) end [DFT_FEEAMOUNT_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN (FEEAMOUNT_CommercialLoan_Q1 IS NULL AND FEEAMOUNT_CommercialLoan_Q4 IS  NULL ) THEN FEEAMOUNT_CommercialLoan_Q1 else (ISNULL(FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(FEEAMOUNT_CommercialLoan_Q4,0)) end [DFT_FEEAMOUNT_CommercialLoan_Q1_Q4]
			 ----,AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_SP
			 --,AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1
			 --,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q2]
			 --,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q3,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q4,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_Q1_Q4]
			 --,AVG_NEWBALANCE_CommercialLoan_Q1
			 --,CASE WHEN (AVG_NEWBALANCE_CommercialLoan_Q1 IS NULL AND AVG_NEWBALANCE_CommercialLoan_Q2 IS  NULL ) THEN AVG_NEWBALANCE_CommercialLoan_Q1 else (ISNULL(AVG_NEWBALANCE_CommercialLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_CommercialLoan_Q2,0)) end [DFT_AVG_NEWBALANCE_CommercialLoan_Q1_Q2]
			 --,CASE WHEN (AVG_NEWBALANCE_CommercialLoan_Q1 IS NULL AND AVG_NEWBALANCE_CommercialLoan_Q3 IS  NULL ) THEN AVG_NEWBALANCE_CommercialLoan_Q1 else (ISNULL(AVG_NEWBALANCE_CommercialLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_CommercialLoan_Q3,0)) end [DFT_AVG_NEWBALANCE_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN (AVG_NEWBALANCE_CommercialLoan_Q1 IS NULL AND AVG_NEWBALANCE_CommercialLoan_Q4 IS  NULL ) THEN AVG_NEWBALANCE_CommercialLoan_Q1 else (ISNULL(AVG_NEWBALANCE_CommercialLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_CommercialLoan_Q4,0)) end [DFT_AVG_NEWBALANCE_CommercialLoan_Q1_Q4]
			 ----,AVG_FEEAMOUNT_CommercialLoan_SP
			 --,AVG_FEEAMOUNT_CommercialLoan_Q1
			 --,CASE WHEN (AVG_FEEAMOUNT_CommercialLoan_Q1 IS NULL AND AVG_FEEAMOUNT_CommercialLoan_Q2 IS  NULL ) THEN AVG_FEEAMOUNT_CommercialLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q2,0)) end [DFT_AVG_FEEAMOUNT_CommercialLoan_Q1_Q2]
			 --,CASE WHEN (AVG_FEEAMOUNT_CommercialLoan_Q1 IS NULL AND AVG_FEEAMOUNT_CommercialLoan_Q3 IS  NULL ) THEN AVG_FEEAMOUNT_CommercialLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q3,0)) end [DFT_AVG_FEEAMOUNT_CommercialLoan_Q1_Q3]
			 ----,CASE WHEN (AVG_FEEAMOUNT_CommercialLoan_Q1 IS NULL AND AVG_FEEAMOUNT_CommercialLoan_Q4 IS  NULL ) THEN AVG_FEEAMOUNT_CommercialLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_CommercialLoan_Q4,0)) end [DFT_AVG_FEEAMOUNT_CommercialLoan_Q1_Q4]

	         ,COUNT_LOAN_ADDON_RealEstate_Q1
			 ,CASE WHEN ( COUNT_LOAN_ADDON_RealEstate_Q1 IS NULL AND COUNT_LOAN_ADDON_RealEstate_Q2 IS  NULL ) THEN COUNT_LOAN_ADDON_RealEstate_Q1 else (ISNULL(COUNT_LOAN_ADDON_RealEstate_Q1,0) - ISNULL(COUNT_LOAN_ADDON_RealEstate_Q2,0)) end [DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q2]

			 ,COUNT_NEW_LOAN_RealEstate_Q1
			 ,CASE WHEN ( COUNT_NEW_LOAN_RealEstate_Q1 IS NULL AND COUNT_NEW_LOAN_RealEstate_Q2 IS  NULL ) THEN COUNT_NEW_LOAN_RealEstate_Q1 else (ISNULL(COUNT_NEW_LOAN_RealEstate_Q1,0) - ISNULL(COUNT_NEW_LOAN_RealEstate_Q2,0)) end [COUNT_NEW_LOAN_RealEstate_Q1_Q2]

			 ,COUNT_LOAN_PAYMENT_RealEstate_Q1
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_RealEstate_Q1 IS NULL AND COUNT_LOAN_PAYMENT_RealEstate_Q2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_RealEstate_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_RealEstate_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_RealEstate_Q2,0)) end [DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q2]
	
			 ,COUNT_CASH_RealEstate_Q1
			 ,CASE WHEN ( COUNT_CASH_RealEstate_Q1 IS NULL AND COUNT_CASH_RealEstate_Q2 IS  NULL ) THEN COUNT_CASH_RealEstate_Q1 else (ISNULL(COUNT_CASH_RealEstate_Q1,0) - ISNULL(COUNT_CASH_RealEstate_Q2,0)) end [DFT_COUNT_CASH_RealEstate_Q1_Q2]

			 ,COUNT_DRAFT_RealEstate_Q1
			 ,CASE WHEN ( COUNT_DRAFT_RealEstate_Q1 IS NULL AND COUNT_DRAFT_RealEstate_Q2 IS  NULL ) THEN COUNT_DRAFT_RealEstate_Q1 else (ISNULL(COUNT_DRAFT_RealEstate_Q1,0) - ISNULL(COUNT_DRAFT_RealEstate_Q2,0)) end [DFT_COUNT_DRAFT_RealEstate_Q1_Q2]

			 ,COUNT_ACH_RealEstate_Q1
			 ,CASE WHEN ( COUNT_ACH_RealEstate_Q1 IS NULL AND COUNT_ACH_RealEstate_Q2 IS  NULL ) THEN COUNT_ACH_RealEstate_Q1 else (ISNULL(COUNT_ACH_RealEstate_Q1,0) - ISNULL(COUNT_ACH_RealEstate_Q2,0)) end [DFT_COUNT_ACH_RealEstate_Q1_Q2]

			 ,COUNT_FEE_RealEstate_Q1
			 ,CASE WHEN ( COUNT_FEE_RealEstate_Q1 IS NULL AND COUNT_FEE_RealEstate_Q2 IS  NULL ) THEN COUNT_FEE_RealEstate_Q1 else (ISNULL(COUNT_FEE_RealEstate_Q1,0) - ISNULL(COUNT_FEE_RealEstate_Q2,0)) end [DFT_COUNT_FEE_RealEstate_Q1_Q2]

			 ,COUNT_HOMEBANKING_RealEstate_Q1
			 ,CASE WHEN (COUNT_HOMEBANKING_RealEstate_Q1 IS NULL AND COUNT_HOMEBANKING_RealEstate_Q2 IS  NULL ) THEN COUNT_HOMEBANKING_RealEstate_Q1 else (ISNULL(COUNT_HOMEBANKING_RealEstate_Q1,0) - ISNULL(COUNT_HOMEBANKING_RealEstate_Q2,0)) end [DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q2]

			 ,COUNT_INSURANCE_RealEstate_Q1
			 ,CASE WHEN (COUNT_INSURANCE_RealEstate_Q1 IS NULL AND COUNT_INSURANCE_RealEstate_Q2 IS  NULL ) THEN COUNT_INSURANCE_RealEstate_Q1 else (ISNULL(COUNT_INSURANCE_RealEstate_Q1,0) - ISNULL(COUNT_INSURANCE_RealEstate_Q2,0)) end [DFT_COUNT_INSURANCE_RealEstate_Q1_Q2]

			 ,COUNT_CHECKS_RealEstate_Q1
			 ,CASE WHEN (COUNT_CHECKS_RealEstate_Q1 IS NULL AND COUNT_CHECKS_RealEstate_Q2 IS  NULL ) THEN COUNT_CHECKS_RealEstate_Q1 else (ISNULL(COUNT_CHECKS_RealEstate_Q1,0) - ISNULL(COUNT_CHECKS_RealEstate_Q2,0)) end [DFT_COUNT_CHECKS_RealEstate_Q1_Q2] 

			 ,COUNT_PAYROLL_RealEstate_Q1
			 ,CASE WHEN (COUNT_PAYROLL_RealEstate_Q1 IS NULL AND COUNT_PAYROLL_RealEstate_Q2 IS  NULL ) THEN COUNT_PAYROLL_RealEstate_Q1 else (ISNULL(COUNT_PAYROLL_RealEstate_Q1,0) - ISNULL(COUNT_PAYROLL_RealEstate_Q2,0)) end [DFT_COUNT_PAYROLL_RealEstate_Q1_Q2]

			 ,COUNT_KIOSK_RealEstate_Q1
			 ,CASE WHEN (COUNT_KIOSK_RealEstate_Q1 IS NULL AND COUNT_KIOSK_RealEstate_Q2 IS  NULL ) THEN COUNT_KIOSK_RealEstate_Q1 else (ISNULL(COUNT_KIOSK_RealEstate_Q1,0) - ISNULL(COUNT_KIOSK_RealEstate_Q2,0)) end [DFT_COUNT_KIOSK_RealEstate_Q1_Q2]

			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_Q1_Q2]

			 ,LOAN_TRANSACTION_AMOUNT_RealEstate_Q1
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_RealEstate_Q2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_Q2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2]

			 ,INTEREST_AMOUNT_RealEstate_Q1
			 ,CASE WHEN (INTEREST_AMOUNT_RealEstate_Q1 IS NULL AND INTEREST_AMOUNT_RealEstate_Q2 IS  NULL ) THEN INTEREST_AMOUNT_RealEstate_Q1 else (ISNULL(INTEREST_AMOUNT_RealEstate_Q1,0) - ISNULL(INTEREST_AMOUNT_RealEstate_Q2,0)) end [DFT_INTEREST_AMOUNT_RealEstate_Q1_Q2]

			 ,FEEAMOUNT_RealEstate_Q1
			 ,CASE WHEN (FEEAMOUNT_RealEstate_Q1 IS NULL AND FEEAMOUNT_RealEstate_Q2 IS  NULL ) THEN FEEAMOUNT_RealEstate_Q1 else (ISNULL(FEEAMOUNT_RealEstate_Q1,0) - ISNULL(FEEAMOUNT_RealEstate_Q2,0)) end [DFT_FEEAMOUNT_RealEstate_Q1_Q2]

			 ,AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2]

			 ,AVG_NEWBALANCE_RealEstate_Q1
			 ,CASE WHEN (AVG_NEWBALANCE_RealEstate_Q1 IS NULL AND AVG_NEWBALANCE_RealEstate_Q2 IS  NULL ) THEN AVG_NEWBALANCE_RealEstate_Q1 else (ISNULL(AVG_NEWBALANCE_RealEstate_Q1,0) - ISNULL(AVG_NEWBALANCE_RealEstate_Q2,0)) end [DFT_AVG_NEWBALANCE_RealEstate_Q1_Q2]

			 ,AVG_FEEAMOUNT_RealEstate_Q1
			 ,CASE WHEN (AVG_FEEAMOUNT_RealEstate_Q1 IS NULL AND AVG_FEEAMOUNT_RealEstate_Q2 IS  NULL ) THEN AVG_FEEAMOUNT_RealEstate_Q1 else (ISNULL(AVG_FEEAMOUNT_RealEstate_Q1,0) - ISNULL(AVG_FEEAMOUNT_RealEstate_Q2,0)) end [DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q2]
			 ,CASE WHEN (AVG_FEEAMOUNT_RealEstate_Q1 IS NULL AND AVG_FEEAMOUNT_RealEstate_Q3 IS  NULL ) THEN AVG_FEEAMOUNT_RealEstate_Q1 else (ISNULL(AVG_FEEAMOUNT_RealEstate_Q1,0) - ISNULL(AVG_FEEAMOUNT_RealEstate_Q3,0)) end [DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q3]
			 --,CASE WHEN (AVG_FEEAMOUNT_RealEstate_Q1 IS NULL AND AVG_FEEAMOUNT_RealEstate_Q4 IS  NULL ) THEN AVG_FEEAMOUNT_RealEstate_Q1 else (ISNULL(AVG_FEEAMOUNT_RealEstate_Q1,0) - ISNULL(AVG_FEEAMOUNT_RealEstate_Q4,0)) end [DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q4]

	         ,COUNT_LOAN_ADDON_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_LOAN_ADDON_SecuredLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_SecuredLoan_Q2 IS  NULL ) THEN COUNT_LOAN_ADDON_SecuredLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_SecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_SecuredLoan_Q2,0)) end [DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q2]

			 ,COUNT_NEW_LOAN_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_NEW_LOAN_SecuredLoan_Q1 IS NULL AND COUNT_NEW_LOAN_SecuredLoan_Q2 IS  NULL ) THEN COUNT_NEW_LOAN_SecuredLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_SecuredLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_SecuredLoan_Q2,0)) end [COUNT_NEW_LOAN_SecuredLoan_Q1_Q2]

			 ,COUNT_LOAN_PAYMENT_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_SecuredLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_SecuredLoan_Q2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_SecuredLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_Q2,0)) end [DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q2]

			 ,COUNT_CASH_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_CASH_SecuredLoan_Q1 IS NULL AND COUNT_CASH_SecuredLoan_Q2 IS  NULL ) THEN COUNT_CASH_SecuredLoan_Q1 else (ISNULL(COUNT_CASH_SecuredLoan_Q1,0) - ISNULL(COUNT_CASH_SecuredLoan_Q2,0)) end [DFT_COUNT_CASH_SecuredLoan_Q1_Q2]

			 ,COUNT_DRAFT_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_DRAFT_SecuredLoan_Q1 IS NULL AND COUNT_DRAFT_SecuredLoan_Q2 IS  NULL ) THEN COUNT_DRAFT_SecuredLoan_Q1 else (ISNULL(COUNT_DRAFT_SecuredLoan_Q1,0) - ISNULL(COUNT_DRAFT_SecuredLoan_Q2,0)) end [DFT_COUNT_DRAFT_SecuredLoan_Q1_Q2]

			 ,COUNT_ACH_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_ACH_SecuredLoan_Q1 IS NULL AND COUNT_ACH_SecuredLoan_Q2 IS  NULL ) THEN COUNT_ACH_SecuredLoan_Q1 else (ISNULL(COUNT_ACH_SecuredLoan_Q1,0) - ISNULL(COUNT_ACH_SecuredLoan_Q2,0)) end [DFT_COUNT_ACH_SecuredLoan_Q1_Q2]

			 ,COUNT_FEE_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_FEE_SecuredLoan_Q1 IS NULL AND COUNT_FEE_SecuredLoan_Q2 IS  NULL ) THEN COUNT_FEE_SecuredLoan_Q1 else (ISNULL(COUNT_FEE_SecuredLoan_Q1,0) - ISNULL(COUNT_FEE_SecuredLoan_Q2,0)) end [DFT_COUNT_FEE_SecuredLoan_Q1_Q2]

			 ,COUNT_HOMEBANKING_SecuredLoan_Q1
			 ,CASE WHEN (COUNT_HOMEBANKING_SecuredLoan_Q1 IS NULL AND COUNT_HOMEBANKING_SecuredLoan_Q2 IS  NULL ) THEN COUNT_HOMEBANKING_SecuredLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_SecuredLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_SecuredLoan_Q2,0)) end [DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q2]

			 ,COUNT_INSURANCE_SecuredLoan_Q1
			 ,CASE WHEN (COUNT_INSURANCE_SecuredLoan_Q1 IS NULL AND COUNT_INSURANCE_SecuredLoan_Q2 IS  NULL ) THEN COUNT_INSURANCE_SecuredLoan_Q1 else (ISNULL(COUNT_INSURANCE_SecuredLoan_Q1,0) - ISNULL(COUNT_INSURANCE_SecuredLoan_Q2,0)) end [DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q2]

			 ,COUNT_CHECKS_SecuredLoan_Q1
			 ,CASE WHEN (COUNT_CHECKS_SecuredLoan_Q1 IS NULL AND COUNT_CHECKS_SecuredLoan_Q2 IS  NULL ) THEN COUNT_CHECKS_SecuredLoan_Q1 else (ISNULL(COUNT_CHECKS_SecuredLoan_Q1,0) - ISNULL(COUNT_CHECKS_SecuredLoan_Q2,0)) end [DFT_COUNT_CHECKS_SecuredLoan_Q1_Q2] 

			 ,COUNT_PAYROLL_SecuredLoan_Q1
			 ,CASE WHEN (COUNT_PAYROLL_SecuredLoan_Q1 IS NULL AND COUNT_PAYROLL_SecuredLoan_Q2 IS  NULL ) THEN COUNT_PAYROLL_SecuredLoan_Q1 else (ISNULL(COUNT_PAYROLL_SecuredLoan_Q1,0) - ISNULL(COUNT_PAYROLL_SecuredLoan_Q2,0)) end [DFT_COUNT_PAYROLL_SecuredLoan_Q1_Q2]

			 ,COUNT_KIOSK_SecuredLoan_Q1
			 ,CASE WHEN (COUNT_KIOSK_SecuredLoan_Q1 IS NULL AND COUNT_KIOSK_SecuredLoan_Q2 IS  NULL ) THEN COUNT_KIOSK_SecuredLoan_Q1 else (ISNULL(COUNT_KIOSK_SecuredLoan_Q1,0) - ISNULL(COUNT_KIOSK_SecuredLoan_Q2,0)) end [DFT_COUNT_KIOSK_SecuredLoan_Q1_Q2]

			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_Q1_Q2]


			 ,LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2]

			 ,INTEREST_AMOUNT_SecuredLoan_Q1
			 ,CASE WHEN (INTEREST_AMOUNT_SecuredLoan_Q1 IS NULL AND INTEREST_AMOUNT_SecuredLoan_Q2 IS  NULL ) THEN INTEREST_AMOUNT_SecuredLoan_Q1 else (ISNULL(INTEREST_AMOUNT_SecuredLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_SecuredLoan_Q2,0)) end [DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q2]

			 ,FEEAMOUNT_SecuredLoan_Q1
			 ,CASE WHEN (FEEAMOUNT_SecuredLoan_Q1 IS NULL AND FEEAMOUNT_SecuredLoan_Q2 IS  NULL ) THEN FEEAMOUNT_SecuredLoan_Q1 else (ISNULL(FEEAMOUNT_SecuredLoan_Q1,0) - ISNULL(FEEAMOUNT_SecuredLoan_Q2,0)) end [DFT_FEEAMOUNT_SecuredLoan_Q1_Q2]

			 ,AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2]

			 ,AVG_NEWBALANCE_SecuredLoan_Q1
			 ,CASE WHEN (AVG_NEWBALANCE_SecuredLoan_Q1 IS NULL AND AVG_NEWBALANCE_SecuredLoan_Q2 IS  NULL ) THEN AVG_NEWBALANCE_SecuredLoan_Q1 else (ISNULL(AVG_NEWBALANCE_SecuredLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_SecuredLoan_Q2,0)) end [DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q2]

			 ,AVG_FEEAMOUNT_SecuredLoan_Q1
			 ,CASE WHEN (AVG_FEEAMOUNT_SecuredLoan_Q1 IS NULL AND AVG_FEEAMOUNT_SecuredLoan_Q2 IS  NULL ) THEN AVG_FEEAMOUNT_SecuredLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_SecuredLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_SecuredLoan_Q2,0)) end [DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q2]



	         ,COUNT_LOAN_ADDON_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_LOAN_ADDON_UnsecuredLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_LOAN_ADDON_UnsecuredLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_Q2,0)) end [DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q2]

			 ,COUNT_NEW_LOAN_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_NEW_LOAN_UnsecuredLoan_Q1 IS NULL AND COUNT_NEW_LOAN_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_NEW_LOAN_UnsecuredLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_Q2,0)) end [COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q2]

			 ,COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_Q2,0)) end [DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q2]

			 ,COUNT_CASH_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_CASH_UnsecuredLoan_Q1 IS NULL AND COUNT_CASH_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_CASH_UnsecuredLoan_Q1 else (ISNULL(COUNT_CASH_UnsecuredLoan_Q1,0) - ISNULL(COUNT_CASH_UnsecuredLoan_Q2,0)) end [DFT_COUNT_CASH_UnsecuredLoan_Q1_Q2]

			 ,COUNT_DRAFT_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_DRAFT_UnsecuredLoan_Q1 IS NULL AND COUNT_DRAFT_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_DRAFT_UnsecuredLoan_Q1 else (ISNULL(COUNT_DRAFT_UnsecuredLoan_Q1,0) - ISNULL(COUNT_DRAFT_UnsecuredLoan_Q2,0)) end [DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q2]

			 ,COUNT_ACH_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_ACH_UnsecuredLoan_Q1 IS NULL AND COUNT_ACH_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_ACH_UnsecuredLoan_Q1 else (ISNULL(COUNT_ACH_UnsecuredLoan_Q1,0) - ISNULL(COUNT_ACH_UnsecuredLoan_Q2,0)) end [DFT_COUNT_ACH_UnsecuredLoan_Q1_Q2]

			 ,COUNT_FEE_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_FEE_UnsecuredLoan_Q1 IS NULL AND COUNT_FEE_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_FEE_UnsecuredLoan_Q1 else (ISNULL(COUNT_FEE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_FEE_UnsecuredLoan_Q2,0)) end [DFT_COUNT_FEE_UnsecuredLoan_Q1_Q2]

			 ,COUNT_HOMEBANKING_UnsecuredLoan_Q1
			 ,CASE WHEN (COUNT_HOMEBANKING_UnsecuredLoan_Q1 IS NULL AND COUNT_HOMEBANKING_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_HOMEBANKING_UnsecuredLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_Q2,0)) end [DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q2]

			 ,COUNT_INSURANCE_UnsecuredLoan_Q1
			 ,CASE WHEN (COUNT_INSURANCE_UnsecuredLoan_Q1 IS NULL AND COUNT_INSURANCE_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_INSURANCE_UnsecuredLoan_Q1 else (ISNULL(COUNT_INSURANCE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_INSURANCE_UnsecuredLoan_Q2,0)) end [DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q2]

			 ,COUNT_CHECKS_UnsecuredLoan_Q1
			 ,CASE WHEN (COUNT_CHECKS_UnsecuredLoan_Q1 IS NULL AND COUNT_CHECKS_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_CHECKS_UnsecuredLoan_Q1 else (ISNULL(COUNT_CHECKS_UnsecuredLoan_Q1,0) - ISNULL(COUNT_CHECKS_UnsecuredLoan_Q2,0)) end [DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q2] 

			 ,COUNT_PAYROLL_UnsecuredLoan_Q1
			 ,CASE WHEN (COUNT_PAYROLL_UnsecuredLoan_Q1 IS NULL AND COUNT_PAYROLL_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_PAYROLL_UnsecuredLoan_Q1 else (ISNULL(COUNT_PAYROLL_UnsecuredLoan_Q1,0) - ISNULL(COUNT_PAYROLL_UnsecuredLoan_Q2,0)) end [DFT_COUNT_PAYROLL_UnsecuredLoan_Q1_Q2]

			 ,COUNT_KIOSK_UnsecuredLoan_Q1
			 ,CASE WHEN (COUNT_KIOSK_UnsecuredLoan_Q1 IS NULL AND COUNT_KIOSK_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_KIOSK_UnsecuredLoan_Q1 else (ISNULL(COUNT_KIOSK_UnsecuredLoan_Q1,0) - ISNULL(COUNT_KIOSK_UnsecuredLoan_Q2,0)) end [DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q2]

			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_Q1_Q2]


			 ,LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2]

			 ,INTEREST_AMOUNT_UnsecuredLoan_Q1
			 ,CASE WHEN (INTEREST_AMOUNT_UnsecuredLoan_Q1 IS NULL AND INTEREST_AMOUNT_UnsecuredLoan_Q2 IS  NULL ) THEN INTEREST_AMOUNT_UnsecuredLoan_Q1 else (ISNULL(INTEREST_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_UnsecuredLoan_Q2,0)) end [DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q2]

			 ,FEEAMOUNT_UnsecuredLoan_Q1
			 ,CASE WHEN (FEEAMOUNT_UnsecuredLoan_Q1 IS NULL AND FEEAMOUNT_UnsecuredLoan_Q2 IS  NULL ) THEN FEEAMOUNT_UnsecuredLoan_Q1 else (ISNULL(FEEAMOUNT_UnsecuredLoan_Q1,0) - ISNULL(FEEAMOUNT_UnsecuredLoan_Q2,0)) end [DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q2]

			 ,AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2]

			 ,AVG_NEWBALANCE_UnsecuredLoan_Q1
			 ,CASE WHEN (AVG_NEWBALANCE_UnsecuredLoan_Q1 IS NULL AND AVG_NEWBALANCE_UnsecuredLoan_Q2 IS  NULL ) THEN AVG_NEWBALANCE_UnsecuredLoan_Q1 else (ISNULL(AVG_NEWBALANCE_UnsecuredLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_UnsecuredLoan_Q2,0)) end [DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q2]

			 ,AVG_FEEAMOUNT_UnsecuredLoan_Q1
			 ,CASE WHEN (AVG_FEEAMOUNT_UnsecuredLoan_Q1 IS NULL AND AVG_FEEAMOUNT_UnsecuredLoan_Q2 IS  NULL ) THEN AVG_FEEAMOUNT_UnsecuredLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_Q2,0)) end [DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q2]



	         ,COUNT_LOAN_ADDON_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_LOAN_ADDON_VehicleLoan_Q1 IS NULL AND COUNT_LOAN_ADDON_VehicleLoan_Q2 IS  NULL ) THEN COUNT_LOAN_ADDON_VehicleLoan_Q1 else (ISNULL(COUNT_LOAN_ADDON_VehicleLoan_Q1,0) - ISNULL(COUNT_LOAN_ADDON_VehicleLoan_Q2,0)) end [DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q2]

			 ,COUNT_NEW_LOAN_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_NEW_LOAN_VehicleLoan_Q1 IS NULL AND COUNT_NEW_LOAN_VehicleLoan_Q2 IS  NULL ) THEN COUNT_NEW_LOAN_VehicleLoan_Q1 else (ISNULL(COUNT_NEW_LOAN_VehicleLoan_Q1,0) - ISNULL(COUNT_NEW_LOAN_VehicleLoan_Q2,0)) end [COUNT_NEW_LOAN_VehicleLoan_Q1_Q2]

			 ,COUNT_LOAN_PAYMENT_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_VehicleLoan_Q1 IS NULL AND COUNT_LOAN_PAYMENT_VehicleLoan_Q2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_VehicleLoan_Q1 else (ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_Q1,0) - ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_Q2,0)) end [DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q2]

			 ,COUNT_CASH_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_CASH_VehicleLoan_Q1 IS NULL AND COUNT_CASH_VehicleLoan_Q2 IS  NULL ) THEN COUNT_CASH_VehicleLoan_Q1 else (ISNULL(COUNT_CASH_VehicleLoan_Q1,0) - ISNULL(COUNT_CASH_VehicleLoan_Q2,0)) end [DFT_COUNT_CASH_VehicleLoan_Q1_Q2]

			 ,COUNT_DRAFT_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_DRAFT_VehicleLoan_Q1 IS NULL AND COUNT_DRAFT_VehicleLoan_Q2 IS  NULL ) THEN COUNT_DRAFT_VehicleLoan_Q1 else (ISNULL(COUNT_DRAFT_VehicleLoan_Q1,0) - ISNULL(COUNT_DRAFT_VehicleLoan_Q2,0)) end [DFT_COUNT_DRAFT_VehicleLoan_Q1_Q2]

			 ,COUNT_ACH_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_ACH_VehicleLoan_Q1 IS NULL AND COUNT_ACH_VehicleLoan_Q2 IS  NULL ) THEN COUNT_ACH_VehicleLoan_Q1 else (ISNULL(COUNT_ACH_VehicleLoan_Q1,0) - ISNULL(COUNT_ACH_VehicleLoan_Q2,0)) end [DFT_COUNT_ACH_VehicleLoan_Q1_Q2]

			 ,COUNT_FEE_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_FEE_VehicleLoan_Q1 IS NULL AND COUNT_FEE_VehicleLoan_Q2 IS  NULL ) THEN COUNT_FEE_VehicleLoan_Q1 else (ISNULL(COUNT_FEE_VehicleLoan_Q1,0) - ISNULL(COUNT_FEE_VehicleLoan_Q2,0)) end [DFT_COUNT_FEE_VehicleLoan_Q1_Q2]

			 ,COUNT_HOMEBANKING_VehicleLoan_Q1
			 ,CASE WHEN (COUNT_HOMEBANKING_VehicleLoan_Q1 IS NULL AND COUNT_HOMEBANKING_VehicleLoan_Q2 IS  NULL ) THEN COUNT_HOMEBANKING_VehicleLoan_Q1 else (ISNULL(COUNT_HOMEBANKING_VehicleLoan_Q1,0) - ISNULL(COUNT_HOMEBANKING_VehicleLoan_Q2,0)) end [DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q2]

			 ,COUNT_INSURANCE_VehicleLoan_Q1
			 ,CASE WHEN (COUNT_INSURANCE_VehicleLoan_Q1 IS NULL AND COUNT_INSURANCE_VehicleLoan_Q2 IS  NULL ) THEN COUNT_INSURANCE_VehicleLoan_Q1 else (ISNULL(COUNT_INSURANCE_VehicleLoan_Q1,0) - ISNULL(COUNT_INSURANCE_VehicleLoan_Q2,0)) end [DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q2]

			 ,COUNT_CHECKS_VehicleLoan_Q1
			 ,CASE WHEN (COUNT_CHECKS_VehicleLoan_Q1 IS NULL AND COUNT_CHECKS_VehicleLoan_Q2 IS  NULL ) THEN COUNT_CHECKS_VehicleLoan_Q1 else (ISNULL(COUNT_CHECKS_VehicleLoan_Q1,0) - ISNULL(COUNT_CHECKS_VehicleLoan_Q2,0)) end [DFT_COUNT_CHECKS_VehicleLoan_Q1_Q2] 

			 ,COUNT_PAYROLL_VehicleLoan_Q1
			 ,CASE WHEN (COUNT_PAYROLL_VehicleLoan_Q1 IS NULL AND COUNT_PAYROLL_VehicleLoan_Q2 IS  NULL ) THEN COUNT_PAYROLL_VehicleLoan_Q1 else (ISNULL(COUNT_PAYROLL_VehicleLoan_Q1,0) - ISNULL(COUNT_PAYROLL_VehicleLoan_Q2,0)) end [DFT_COUNT_PAYROLL_VehicleLoan_Q1_Q2]

			 ,COUNT_KIOSK_VehicleLoan_Q1
			 ,CASE WHEN (COUNT_KIOSK_VehicleLoan_Q1 IS NULL AND COUNT_KIOSK_VehicleLoan_Q2 IS  NULL ) THEN COUNT_KIOSK_VehicleLoan_Q1 else (ISNULL(COUNT_KIOSK_VehicleLoan_Q1,0) - ISNULL(COUNT_KIOSK_VehicleLoan_Q2,0)) end [DFT_COUNT_KIOSK_VehicleLoan_Q1_Q2]

			 ,COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_Q1_Q2]


			 ,LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 IS NULL AND LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2]

			 ,INTEREST_AMOUNT_VehicleLoan_Q1
			 ,CASE WHEN (INTEREST_AMOUNT_VehicleLoan_Q1 IS NULL AND INTEREST_AMOUNT_VehicleLoan_Q2 IS  NULL ) THEN INTEREST_AMOUNT_VehicleLoan_Q1 else (ISNULL(INTEREST_AMOUNT_VehicleLoan_Q1,0) - ISNULL(INTEREST_AMOUNT_VehicleLoan_Q2,0)) end [DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2]

			 ,FEEAMOUNT_VehicleLoan_Q1
			 ,CASE WHEN (FEEAMOUNT_VehicleLoan_Q1 IS NULL AND FEEAMOUNT_VehicleLoan_Q2 IS  NULL ) THEN FEEAMOUNT_VehicleLoan_Q1 else (ISNULL(FEEAMOUNT_VehicleLoan_Q1,0) - ISNULL(FEEAMOUNT_VehicleLoan_Q2,0)) end [DFT_FEEAMOUNT_VehicleLoan_Q1_Q2]

			 ,AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2]
	
			 ,AVG_NEWBALANCE_VehicleLoan_Q1
			 ,CASE WHEN (AVG_NEWBALANCE_VehicleLoan_Q1 IS NULL AND AVG_NEWBALANCE_VehicleLoan_Q2 IS  NULL ) THEN AVG_NEWBALANCE_VehicleLoan_Q1 else (ISNULL(AVG_NEWBALANCE_VehicleLoan_Q1,0) - ISNULL(AVG_NEWBALANCE_VehicleLoan_Q2,0)) end [DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2]

			 ,AVG_FEEAMOUNT_VehicleLoan_Q1
			 ,CASE WHEN (AVG_FEEAMOUNT_VehicleLoan_Q1 IS NULL AND AVG_FEEAMOUNT_VehicleLoan_Q2 IS  NULL ) THEN AVG_FEEAMOUNT_VehicleLoan_Q1 else (ISNULL(AVG_FEEAMOUNT_VehicleLoan_Q1,0) - ISNULL(AVG_FEEAMOUNT_VehicleLoan_Q2,0)) end [DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q2]

			        --,COUNT_LOAN_ADDON_H1
					,CASE WHEN ( COUNT_LOAN_ADDON_H1 IS NULL AND COUNT_LOAN_ADDON_H2 IS  NULL ) THEN COUNT_LOAN_ADDON_H1 else (ISNULL(COUNT_LOAN_ADDON_H1,0)-ISNULL(COUNT_LOAN_ADDON_H2,0)) end DFT_COUNT_LOAN_ADDON_H1_H2

					--,COUNT_NEW_LOAN_H1
					,CASE WHEN ( COUNT_NEW_LOAN_H1 IS NULL AND COUNT_NEW_LOAN_H2 IS  NULL ) THEN COUNT_NEW_LOAN_H1 else (ISNULL(COUNT_NEW_LOAN_H1,0)-ISNULL(COUNT_NEW_LOAN_H2,0)) end DFT_COUNT_NEW_LOAN_H1_H2

					--,COUNT_LOAN_PAYMENT_H1
					,CASE WHEN ( COUNT_LOAN_PAYMENT_H1 IS NULL AND COUNT_LOAN_PAYMENT_H2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_H1 else (ISNULL(COUNT_LOAN_PAYMENT_H1,0) - (ISNULL(COUNT_LOAN_PAYMENT_H2,0))) end DFT_COUNT_LOAN_PAYMENT_H1_H2

					--,COUNT_CASH_H1
					,CASE WHEN ( COUNT_CASH_H1 IS NULL AND COUNT_CASH_H2 IS  NULL ) THEN COUNT_CASH_H1 else (ISNULL(COUNT_CASH_H1,0) - ISNULL(COUNT_CASH_H2,0)) end DFT_COUNT_CASH_H1_H2

					--,COUNT_DRAFT_H1
					,CASE WHEN ( COUNT_DRAFT_H1 IS NULL AND COUNT_DRAFT_H2 IS  NULL ) THEN COUNT_DRAFT_H1 else (ISNULL(COUNT_DRAFT_H1,0)-ISNULL(COUNT_DRAFT_H2,0)) end DFT_COUNT_DRAFT_H1_H2

					--,COUNT_ACH_H1
					,CASE WHEN ( COUNT_ACH_H1 IS NULL AND COUNT_ACH_H2 IS  NULL ) THEN COUNT_ACH_H1 else (ISNULL(COUNT_ACH_H1,0)-ISNULL(COUNT_ACH_H2,0)) end DFT_COUNT_ACH_H1_H2

					--,COUNT_FEE_H1
					,CASE WHEN (COUNT_FEE_H1 IS NULL AND COUNT_FEE_H2 IS  NULL ) THEN COUNT_FEE_H1 else (ISNULL(COUNT_FEE_H1,0)-ISNULL(COUNT_FEE_H2,0)) end DFT_COUNT_FEE_H1_H2

					--,COUNT_HOMEBANKING_H1
					,CASE WHEN (COUNT_HOMEBANKING_H1 IS NULL AND COUNT_HOMEBANKING_H2 IS  NULL ) THEN COUNT_HOMEBANKING_H1 else (ISNULL(COUNT_HOMEBANKING_H1,0)-ISNULL(COUNT_HOMEBANKING_H2,0)) end DFT_COUNT_HOMEBANKING_H1_H2

					--,COUNT_INSURANCE_H1
					,CASE WHEN ( COUNT_INSURANCE_H1 IS NULL AND COUNT_INSURANCE_H2 IS  NULL ) THEN COUNT_INSURANCE_H1 else (ISNULL(COUNT_INSURANCE_H1,0)-ISNULL(COUNT_INSURANCE_H2,0)) end DFT_COUNT_INSURANCE_H1_H2

					--,COUNT_CHECKS_H1
					,CASE WHEN (COUNT_CHECKS_H1 IS NULL AND COUNT_CHECKS_H2 IS  NULL ) THEN COUNT_CHECKS_H1 else (ISNULL(COUNT_CHECKS_H1,0)-ISNULL(COUNT_CHECKS_H2,0)) end DFT_COUNT_CHECKS_H1_H2

					--,COUNT_PAYROLL_H1
					,CASE WHEN (COUNT_CHECKS_H1 IS NULL AND COUNT_CHECKS_H2 IS  NULL ) THEN COUNT_CHECKS_H1 else (ISNULL(COUNT_PAYROLL_H1,0)-ISNULL(COUNT_PAYROLL_H2,0)) end DFT_COUNT_PAYROLL_H1_H2

					--,COUNT_KIOSK_H1
					,CASE WHEN ( COUNT_KIOSK_H1 IS NULL AND COUNT_KIOSK_H2 IS  NULL ) THEN COUNT_KIOSK_H1 else (ISNULL(COUNT_KIOSK_H1,0)-ISNULL(COUNT_KIOSK_H2,0)) end DFT_COUNT_KIOSK_H1_H2

					--,COUNT_AUDIO_RESPONSE_TELEPHONE_H1
					,CASE WHEN (COUNT_AUDIO_RESPONSE_TELEPHONE_H1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_H2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_H1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_H1,0)-ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_H2,0)) end DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_H1_H2

	   --      ,COUNT_LOAN_ADDON_CommercialLoan_H1
			 --,CASE WHEN ( COUNT_LOAN_ADDON_CommercialLoan_H1 IS NULL AND COUNT_LOAN_ADDON_CommercialLoan_H2 IS  NULL ) THEN COUNT_LOAN_ADDON_CommercialLoan_H1 else (ISNULL(COUNT_LOAN_ADDON_CommercialLoan_H1,0) - ISNULL(COUNT_LOAN_ADDON_CommercialLoan_H2,0)) end [DFT_COUNT_LOAN_ADDON_CommercialLoan_H1_H2]
			 --,CASE WHEN ( COUNT_LOAN_ADDON_CommercialLoan_H1 IS NULL AND COUNT_LOAN_ADDON_CommercialLoan_H3 IS  NULL ) THEN COUNT_LOAN_ADDON_CommercialLoan_H1 else (ISNULL(COUNT_LOAN_ADDON_CommercialLoan_H1,0) - ISNULL(COUNT_LOAN_ADDON_CommercialLoan_H3,0)) end [DFT_COUNT_LOAN_ADDON_CommercialLoan_H1_H3]
			 ----,CASE WHEN ( COUNT_LOAN_ADDON_CommercialLoan_H1 IS NULL AND COUNT_LOAN_ADDON_CommercialLoan_H4 IS  NULL ) THEN COUNT_LOAN_ADDON_CommercialLoan_H1 else (ISNULL(COUNT_LOAN_ADDON_CommercialLoan_H1,0) - ISNULL(COUNT_LOAN_ADDON_CommercialLoan_H4,0)) end [DFT_COUNT_LOAN_ADDON_CommercialLoan_H1_H4]
			 ----,COUNT_NEW_LOAN_CommercialLoan_SP
			 --,COUNT_NEW_LOAN_CommercialLoan_H1
			 --,CASE WHEN ( COUNT_NEW_LOAN_CommercialLoan_H1 IS NULL AND COUNT_NEW_LOAN_CommercialLoan_H2 IS  NULL ) THEN COUNT_NEW_LOAN_CommercialLoan_H1 else (ISNULL(COUNT_NEW_LOAN_CommercialLoan_H1,0) - ISNULL(COUNT_NEW_LOAN_CommercialLoan_H2,0)) end [COUNT_NEW_LOAN_CommercialLoan_H1_H2]
			 --,CASE WHEN ( COUNT_NEW_LOAN_CommercialLoan_H1 IS NULL AND COUNT_NEW_LOAN_CommercialLoan_H3 IS  NULL ) THEN COUNT_NEW_LOAN_CommercialLoan_H1 else (ISNULL(COUNT_NEW_LOAN_CommercialLoan_H1,0) - ISNULL(COUNT_NEW_LOAN_CommercialLoan_H3,0)) end [COUNT_NEW_LOAN_CommercialLoan_H1_H3]
			 ----,CASE WHEN ( COUNT_NEW_LOAN_CommercialLoan_H1 IS NULL AND COUNT_NEW_LOAN_CommercialLoan_H4 IS  NULL ) THEN COUNT_NEW_LOAN_CommercialLoan_H1 else (ISNULL(COUNT_NEW_LOAN_CommercialLoan_H1,0) - ISNULL(COUNT_NEW_LOAN_CommercialLoan_H4,0)) end [COUNT_NEW_LOAN_CommercialLoan_H1_H4]
			 ----,COUNT_LOAN_PAYMENT_CommercialLoan_SP
			 --,COUNT_LOAN_PAYMENT_CommercialLoan_H1
			 --,CASE WHEN ( COUNT_LOAN_PAYMENT_CommercialLoan_H1 IS NULL AND COUNT_LOAN_PAYMENT_CommercialLoan_H2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_CommercialLoan_H1 else (ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_H1,0) - ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_H2,0)) end [DFT_COUNT_LOAN_PAYMENT_CommercialLoan_H1_H2]
			 --,CASE WHEN ( COUNT_LOAN_PAYMENT_CommercialLoan_H1 IS NULL AND COUNT_LOAN_PAYMENT_CommercialLoan_H3 IS  NULL ) THEN COUNT_LOAN_PAYMENT_CommercialLoan_H1 else (ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_H1,0) - ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_H3,0)) end [DFT_COUNT_LOAN_PAYMENT_CommercialLoan_H1_H3]
			 ----,CASE WHEN ( COUNT_LOAN_PAYMENT_CommercialLoan_H1 IS NULL AND COUNT_LOAN_PAYMENT_CommercialLoan_H4 IS  NULL ) THEN COUNT_LOAN_PAYMENT_CommercialLoan_H1 else (ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_H1,0) - ISNULL(COUNT_LOAN_PAYMENT_CommercialLoan_H4,0)) end [DFT_COUNT_LOAN_PAYMENT_CommercialLoan_H1_H4]
			 ----,COUNT_CASH_CommercialLoan_SP
			 --,COUNT_CASH_CommercialLoan_H1
			 --,CASE WHEN ( COUNT_CASH_CommercialLoan_H1 IS NULL AND COUNT_CASH_CommercialLoan_H2 IS  NULL ) THEN COUNT_CASH_CommercialLoan_H1 else (ISNULL(COUNT_CASH_CommercialLoan_H1,0) - ISNULL(COUNT_CASH_CommercialLoan_H2,0)) end [DFT_COUNT_CASH_CommercialLoan_H1_H2]
			 --,CASE WHEN ( COUNT_CASH_CommercialLoan_H1 IS NULL AND COUNT_CASH_CommercialLoan_H3 IS  NULL ) THEN COUNT_CASH_CommercialLoan_H1 else (ISNULL(COUNT_CASH_CommercialLoan_H1,0) - ISNULL(COUNT_CASH_CommercialLoan_H3,0)) end [DFT_COUNT_CASH_CommercialLoan_H1_H3]
			 ----,CASE WHEN ( COUNT_CASH_CommercialLoan_H1 IS NULL AND COUNT_CASH_CommercialLoan_H4 IS  NULL ) THEN COUNT_CASH_CommercialLoan_H1 else (ISNULL(COUNT_CASH_CommercialLoan_H1,0) - ISNULL(COUNT_CASH_CommercialLoan_H4,0)) end [DFT_COUNT_CASH_CommercialLoan_H1_H4]
			 ----,COUNT_DRAFT_CommercialLoan_SP
			 --,COUNT_DRAFT_CommercialLoan_H1
			 --,CASE WHEN ( COUNT_DRAFT_CommercialLoan_H1 IS NULL AND COUNT_DRAFT_CommercialLoan_H2 IS  NULL ) THEN COUNT_DRAFT_CommercialLoan_H1 else (ISNULL(COUNT_DRAFT_CommercialLoan_H1,0) - ISNULL(COUNT_DRAFT_CommercialLoan_H2,0)) end [DFT_COUNT_DRAFT_CommercialLoan_H1_H2]
			 --,CASE WHEN ( COUNT_DRAFT_CommercialLoan_H1 IS NULL AND COUNT_DRAFT_CommercialLoan_H3 IS  NULL ) THEN COUNT_DRAFT_CommercialLoan_H1 else (ISNULL(COUNT_DRAFT_CommercialLoan_H1,0) - ISNULL(COUNT_DRAFT_CommercialLoan_H3,0)) end [DFT_COUNT_DRAFT_CommercialLoan_H1_H3]
			 ----,CASE WHEN ( COUNT_DRAFT_CommercialLoan_H1 IS NULL AND COUNT_DRAFT_CommercialLoan_H4 IS  NULL ) THEN COUNT_DRAFT_CommercialLoan_H1 else (ISNULL(COUNT_DRAFT_CommercialLoan_H1,0) - ISNULL(COUNT_DRAFT_CommercialLoan_H4,0)) end [DFT_COUNT_DRAFT_CommercialLoan_H1_H4]
			 ----,COUNT_ACH_CommercialLoan_SP
			 --,COUNT_ACH_CommercialLoan_H1
			 --,CASE WHEN ( COUNT_ACH_CommercialLoan_H1 IS NULL AND COUNT_ACH_CommercialLoan_H2 IS  NULL ) THEN COUNT_ACH_CommercialLoan_H1 else (ISNULL(COUNT_ACH_CommercialLoan_H1,0) - ISNULL(COUNT_ACH_CommercialLoan_H2,0)) end [DFT_COUNT_ACH_CommercialLoan_H1_H2]
			 --,CASE WHEN ( COUNT_ACH_CommercialLoan_H1 IS NULL AND COUNT_ACH_CommercialLoan_H3 IS  NULL ) THEN COUNT_ACH_CommercialLoan_H1 else (ISNULL(COUNT_ACH_CommercialLoan_H1,0) - ISNULL(COUNT_ACH_CommercialLoan_H3,0)) end [DFT_COUNT_ACH_CommercialLoan_H1_H3]
			 ----,CASE WHEN ( COUNT_ACH_CommercialLoan_H1 IS NULL AND COUNT_ACH_CommercialLoan_H4 IS  NULL ) THEN COUNT_ACH_CommercialLoan_H1 else (ISNULL(COUNT_ACH_CommercialLoan_H1,0) - ISNULL(COUNT_ACH_CommercialLoan_H4,0)) end [DFT_COUNT_ACH_CommercialLoan_H1_H4]
			 ----,COUNT_FEE_CommercialLoan_SP
			 --,COUNT_FEE_CommercialLoan_H1
			 --,CASE WHEN ( COUNT_FEE_CommercialLoan_H1 IS NULL AND COUNT_FEE_CommercialLoan_H2 IS  NULL ) THEN COUNT_FEE_CommercialLoan_H1 else (ISNULL(COUNT_FEE_CommercialLoan_H1,0) - ISNULL(COUNT_FEE_CommercialLoan_H2,0)) end [DFT_COUNT_FEE_CommercialLoan_H1_H2]
			 --,CASE WHEN ( COUNT_FEE_CommercialLoan_H1 IS NULL AND COUNT_FEE_CommercialLoan_H3 IS  NULL ) THEN COUNT_FEE_CommercialLoan_H1 else (ISNULL(COUNT_FEE_CommercialLoan_H1,0) - ISNULL(COUNT_FEE_CommercialLoan_H3,0)) end [DFT_COUNT_FEE_CommercialLoan_H1_H3]
			 ----,CASE WHEN ( COUNT_FEE_CommercialLoan_H1 IS NULL AND COUNT_FEE_CommercialLoan_H4 IS  NULL ) THEN COUNT_FEE_CommercialLoan_H1 else (ISNULL(COUNT_FEE_CommercialLoan_H1,0) - ISNULL(COUNT_FEE_CommercialLoan_H4,0)) end [DFT_COUNT_FEE_CommercialLoan_H1_H4]
			 ----,COUNT_HOMEBANKING_CommercialLoan_SP
			 --,COUNT_HOMEBANKING_CommercialLoan_H1
			 --,CASE WHEN (COUNT_HOMEBANKING_CommercialLoan_H1 IS NULL AND COUNT_HOMEBANKING_CommercialLoan_H2 IS  NULL ) THEN COUNT_HOMEBANKING_CommercialLoan_H1 else (ISNULL(COUNT_HOMEBANKING_CommercialLoan_H1,0) - ISNULL(COUNT_HOMEBANKING_CommercialLoan_H2,0)) end [DFT_COUNT_HOMEBANKING_CommercialLoan_H1_H2]
			 --,CASE WHEN (COUNT_HOMEBANKING_CommercialLoan_H1 IS NULL AND COUNT_HOMEBANKING_CommercialLoan_H3 IS  NULL ) THEN COUNT_HOMEBANKING_CommercialLoan_H1 else (ISNULL(COUNT_HOMEBANKING_CommercialLoan_H1,0) - ISNULL(COUNT_HOMEBANKING_CommercialLoan_H3,0)) end [DFT_COUNT_HOMEBANKING_CommercialLoan_H1_H3]
			 ----,CASE WHEN (COUNT_HOMEBANKING_CommercialLoan_H1 IS NULL AND COUNT_HOMEBANKING_CommercialLoan_H4 IS  NULL ) THEN COUNT_HOMEBANKING_CommercialLoan_H1 else (ISNULL(COUNT_HOMEBANKING_CommercialLoan_H1,0) - ISNULL(COUNT_HOMEBANKING_CommercialLoan_H4,0)) end [DFT_COUNT_HOMEBANKING_CommercialLoan_H1_H4]
			 ----,COUNT_INSURANCE_CommercialLoan_SP
			 --,COUNT_INSURANCE_CommercialLoan_H1
			 --,CASE WHEN (COUNT_INSURANCE_CommercialLoan_H1 IS NULL AND COUNT_INSURANCE_CommercialLoan_H2 IS  NULL ) THEN COUNT_INSURANCE_CommercialLoan_H1 else (ISNULL(COUNT_INSURANCE_CommercialLoan_H1,0) - ISNULL(COUNT_INSURANCE_CommercialLoan_H2,0)) end [DFT_COUNT_INSURANCE_CommercialLoan_H1_H2]
			 --,CASE WHEN (COUNT_INSURANCE_CommercialLoan_H1 IS NULL AND COUNT_INSURANCE_CommercialLoan_H3 IS  NULL ) THEN COUNT_INSURANCE_CommercialLoan_H1 else (ISNULL(COUNT_INSURANCE_CommercialLoan_H1,0) - ISNULL(COUNT_INSURANCE_CommercialLoan_H3,0)) end [DFT_COUNT_INSURANCE_CommercialLoan_H1_H3]
			 ----,CASE WHEN (COUNT_INSURANCE_CommercialLoan_H1 IS NULL AND COUNT_INSURANCE_CommercialLoan_H4 IS  NULL ) THEN COUNT_INSURANCE_CommercialLoan_H1 else (ISNULL(COUNT_INSURANCE_CommercialLoan_H1,0) - ISNULL(COUNT_INSURANCE_CommercialLoan_H4,0)) end [DFT_COUNT_INSURANCE_CommercialLoan_H1_H4]
			 ----,COUNT_CHECKS_CommercialLoan_SP
			 --,COUNT_CHECKS_CommercialLoan_H1
			 --,CASE WHEN (COUNT_CHECKS_CommercialLoan_H1 IS NULL AND COUNT_CHECKS_CommercialLoan_H2 IS  NULL ) THEN COUNT_CHECKS_CommercialLoan_H1 else (ISNULL(COUNT_CHECKS_CommercialLoan_H1,0) - ISNULL(COUNT_CHECKS_CommercialLoan_H2,0)) end [DFT_COUNT_CHECKS_CommercialLoan_H1_H2] 
			 --,CASE WHEN (COUNT_CHECKS_CommercialLoan_H1 IS NULL AND COUNT_CHECKS_CommercialLoan_H3 IS  NULL ) THEN COUNT_CHECKS_CommercialLoan_H1 else (ISNULL(COUNT_CHECKS_CommercialLoan_H1,0) - ISNULL(COUNT_CHECKS_CommercialLoan_H3,0)) end [DFT_COUNT_CHECKS_CommercialLoan_H1_H3]
			 ----,CASE WHEN (COUNT_CHECKS_CommercialLoan_H1 IS NULL AND COUNT_CHECKS_CommercialLoan_H4 IS  NULL ) THEN COUNT_CHECKS_CommercialLoan_H1 else (ISNULL(COUNT_CHECKS_CommercialLoan_H1,0) - ISNULL(COUNT_CHECKS_CommercialLoan_H4,0)) end [DFT_COUNT_CHECKS_CommercialLoan_H1_H4]
			 ----,COUNT_PAYROLL_CommercialLoan_SP
			 --,COUNT_PAYROLL_CommercialLoan_H1
			 --,CASE WHEN (COUNT_PAYROLL_CommercialLoan_H1 IS NULL AND COUNT_PAYROLL_CommercialLoan_H2 IS  NULL ) THEN COUNT_PAYROLL_CommercialLoan_H1 else (ISNULL(COUNT_PAYROLL_CommercialLoan_H1,0) - ISNULL(COUNT_PAYROLL_CommercialLoan_H2,0)) end [DFT_COUNT_PAYROLL_CommercialLoan_H1_H2]
			 --,CASE WHEN (COUNT_PAYROLL_CommercialLoan_H1 IS NULL AND COUNT_PAYROLL_CommercialLoan_H3 IS  NULL ) THEN COUNT_PAYROLL_CommercialLoan_H1 else (ISNULL(COUNT_PAYROLL_CommercialLoan_H1,0) - ISNULL(COUNT_PAYROLL_CommercialLoan_H3,0)) end [DFT_COUNT_PAYROLL_CommercialLoan_H1_H3]
			 ----,CASE WHEN (COUNT_PAYROLL_CommercialLoan_H1 IS NULL AND COUNT_PAYROLL_CommercialLoan_H4 IS  NULL ) THEN COUNT_PAYROLL_CommercialLoan_H1 else (ISNULL(COUNT_PAYROLL_CommercialLoan_H1,0) - ISNULL(COUNT_PAYROLL_CommercialLoan_H4,0)) end [DFT_COUNT_PAYROLL_CommercialLoan_H1_H4]
			 ----,COUNT_KIOSK_CommercialLoan_SP
			 --,COUNT_KIOSK_CommercialLoan_H1
			 --,CASE WHEN (COUNT_KIOSK_CommercialLoan_H1 IS NULL AND COUNT_KIOSK_CommercialLoan_H2 IS  NULL ) THEN COUNT_KIOSK_CommercialLoan_H1 else (ISNULL(COUNT_KIOSK_CommercialLoan_H1,0) - ISNULL(COUNT_KIOSK_CommercialLoan_H2,0)) end [DFT_COUNT_KIOSK_CommercialLoan_H1_H2]
			 --,CASE WHEN (COUNT_KIOSK_CommercialLoan_H1 IS NULL AND COUNT_KIOSK_CommercialLoan_H3 IS  NULL ) THEN COUNT_KIOSK_CommercialLoan_H1 else (ISNULL(COUNT_KIOSK_CommercialLoan_H1,0) - ISNULL(COUNT_KIOSK_CommercialLoan_H3,0)) end [DFT_COUNT_KIOSK_CommercialLoan_H1_H3]
			 ----,CASE WHEN (COUNT_KIOSK_CommercialLoan_H1 IS NULL AND COUNT_KIOSK_CommercialLoan_H4 IS  NULL ) THEN COUNT_KIOSK_CommercialLoan_H1 else (ISNULL(COUNT_KIOSK_CommercialLoan_H1,0) - ISNULL(COUNT_KIOSK_CommercialLoan_H4,0)) end [DFT_COUNT_KIOSK_CommercialLoan_H1_H4]
			 ----,COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_SP
			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H1
			 --,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H1_H2]
			 --,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H3 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H3,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H1_H3]
			 ----,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H4 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H4,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_CommercialLoan_H1_H4]

			 --,LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1
			 --,CASE WHEN (LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1 IS NULL AND LOAN_TRANSACTION_AMOUNT_CommercialLoan_H2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_H2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1_H2]
			 --,CASE WHEN (LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1 IS NULL AND LOAN_TRANSACTION_AMOUNT_CommercialLoan_H3 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_H3,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1_H3]
			 ----,CASE WHEN (LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1 IS NULL AND LOAN_TRANSACTION_AMOUNT_CommercialLoan_H4 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_CommercialLoan_H4,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1_H4]
			 ----,INTEREST_AMOUNT_CommercialLoan_SP
			 --,INTEREST_AMOUNT_CommercialLoan_H1
			 --,CASE WHEN (INTEREST_AMOUNT_CommercialLoan_H1 IS NULL AND INTEREST_AMOUNT_CommercialLoan_H2 IS  NULL ) THEN INTEREST_AMOUNT_CommercialLoan_H1 else (ISNULL(INTEREST_AMOUNT_CommercialLoan_H1,0) - ISNULL(INTEREST_AMOUNT_CommercialLoan_H2,0)) end [DFT_INTEREST_AMOUNT_CommercialLoan_H1_H2]
			 --,CASE WHEN (INTEREST_AMOUNT_CommercialLoan_H1 IS NULL AND INTEREST_AMOUNT_CommercialLoan_H3 IS  NULL ) THEN INTEREST_AMOUNT_CommercialLoan_H1 else (ISNULL(INTEREST_AMOUNT_CommercialLoan_H1,0) - ISNULL(INTEREST_AMOUNT_CommercialLoan_H3,0)) end [DFT_INTEREST_AMOUNT_CommercialLoan_H1_H3]
			 ----,CASE WHEN (INTEREST_AMOUNT_CommercialLoan_H1 IS NULL AND INTEREST_AMOUNT_CommercialLoan_H4 IS  NULL ) THEN INTEREST_AMOUNT_CommercialLoan_H1 else (ISNULL(INTEREST_AMOUNT_CommercialLoan_H1,0) - ISNULL(INTEREST_AMOUNT_CommercialLoan_H4,0)) end [DFT_INTEREST_AMOUNT_CommercialLoan_H1_H4]
			 ----,FEEAMOUNT_CommercialLoan_SP
			 --,FEEAMOUNT_CommercialLoan_H1
			 --,CASE WHEN (FEEAMOUNT_CommercialLoan_H1 IS NULL AND FEEAMOUNT_CommercialLoan_H2 IS  NULL ) THEN FEEAMOUNT_CommercialLoan_H1 else (ISNULL(FEEAMOUNT_CommercialLoan_H1,0) - ISNULL(FEEAMOUNT_CommercialLoan_H2,0)) end [DFT_FEEAMOUNT_CommercialLoan_H1_H2]
			 --,CASE WHEN (FEEAMOUNT_CommercialLoan_H1 IS NULL AND FEEAMOUNT_CommercialLoan_H3 IS  NULL ) THEN FEEAMOUNT_CommercialLoan_H1 else (ISNULL(FEEAMOUNT_CommercialLoan_H1,0) - ISNULL(FEEAMOUNT_CommercialLoan_H3,0)) end [DFT_FEEAMOUNT_CommercialLoan_H1_H3]
			 ----,CASE WHEN (FEEAMOUNT_CommercialLoan_H1 IS NULL AND FEEAMOUNT_CommercialLoan_H4 IS  NULL ) THEN FEEAMOUNT_CommercialLoan_H1 else (ISNULL(FEEAMOUNT_CommercialLoan_H1,0) - ISNULL(FEEAMOUNT_CommercialLoan_H4,0)) end [DFT_FEEAMOUNT_CommercialLoan_H1_H4]
			 ----,AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_SP
			 --,AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1
			 --,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1_H2]
			 --,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H3 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H3,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1_H3]
			 ----,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H4 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H4,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_CommercialLoan_H1_H4]
			 --,AVG_NEWBALANCE_CommercialLoan_H1
			 --,CASE WHEN (AVG_NEWBALANCE_CommercialLoan_H1 IS NULL AND AVG_NEWBALANCE_CommercialLoan_H2 IS  NULL ) THEN AVG_NEWBALANCE_CommercialLoan_H1 else (ISNULL(AVG_NEWBALANCE_CommercialLoan_H1,0) - ISNULL(AVG_NEWBALANCE_CommercialLoan_H2,0)) end [DFT_AVG_NEWBALANCE_CommercialLoan_H1_H2]
			 --,CASE WHEN (AVG_NEWBALANCE_CommercialLoan_H1 IS NULL AND AVG_NEWBALANCE_CommercialLoan_H3 IS  NULL ) THEN AVG_NEWBALANCE_CommercialLoan_H1 else (ISNULL(AVG_NEWBALANCE_CommercialLoan_H1,0) - ISNULL(AVG_NEWBALANCE_CommercialLoan_H3,0)) end [DFT_AVG_NEWBALANCE_CommercialLoan_H1_H3]
			 ----,CASE WHEN (AVG_NEWBALANCE_CommercialLoan_H1 IS NULL AND AVG_NEWBALANCE_CommercialLoan_H4 IS  NULL ) THEN AVG_NEWBALANCE_CommercialLoan_H1 else (ISNULL(AVG_NEWBALANCE_CommercialLoan_H1,0) - ISNULL(AVG_NEWBALANCE_CommercialLoan_H4,0)) end [DFT_AVG_NEWBALANCE_CommercialLoan_H1_H4]
			 ----,AVG_FEEAMOUNT_CommercialLoan_SP
			 --,AVG_FEEAMOUNT_CommercialLoan_H1
			 --,CASE WHEN (AVG_FEEAMOUNT_CommercialLoan_H1 IS NULL AND AVG_FEEAMOUNT_CommercialLoan_H2 IS  NULL ) THEN AVG_FEEAMOUNT_CommercialLoan_H1 else (ISNULL(AVG_FEEAMOUNT_CommercialLoan_H1,0) - ISNULL(AVG_FEEAMOUNT_CommercialLoan_H2,0)) end [DFT_AVG_FEEAMOUNT_CommercialLoan_H1_H2]
			 --,CASE WHEN (AVG_FEEAMOUNT_CommercialLoan_H1 IS NULL AND AVG_FEEAMOUNT_CommercialLoan_H3 IS  NULL ) THEN AVG_FEEAMOUNT_CommercialLoan_H1 else (ISNULL(AVG_FEEAMOUNT_CommercialLoan_H1,0) - ISNULL(AVG_FEEAMOUNT_CommercialLoan_H3,0)) end [DFT_AVG_FEEAMOUNT_CommercialLoan_H1_H3]
			 ----,CASE WHEN (AVG_FEEAMOUNT_CommercialLoan_H1 IS NULL AND AVG_FEEAMOUNT_CommercialLoan_H4 IS  NULL ) THEN AVG_FEEAMOUNT_CommercialLoan_H1 else (ISNULL(AVG_FEEAMOUNT_CommercialLoan_H1,0) - ISNULL(AVG_FEEAMOUNT_CommercialLoan_H4,0)) end [DFT_AVG_FEEAMOUNT_CommercialLoan_H1_H4]

	         --,COUNT_LOAN_ADDON_RealEstate_H1
			 ,CASE WHEN ( COUNT_LOAN_ADDON_RealEstate_H1 IS NULL AND COUNT_LOAN_ADDON_RealEstate_H2 IS  NULL ) THEN COUNT_LOAN_ADDON_RealEstate_H1 else (ISNULL(COUNT_LOAN_ADDON_RealEstate_H1,0) - ISNULL(COUNT_LOAN_ADDON_RealEstate_H2,0)) end [DFT_COUNT_LOAN_ADDON_RealEstate_H1_H2]

			 --,COUNT_NEW_LOAN_RealEstate_H1
			 ,CASE WHEN ( COUNT_NEW_LOAN_RealEstate_H1 IS NULL AND COUNT_NEW_LOAN_RealEstate_H2 IS  NULL ) THEN COUNT_NEW_LOAN_RealEstate_H1 else (ISNULL(COUNT_NEW_LOAN_RealEstate_H1,0) - ISNULL(COUNT_NEW_LOAN_RealEstate_H2,0)) end [COUNT_NEW_LOAN_RealEstate_H1_H2]

			 --,COUNT_LOAN_PAYMENT_RealEstate_H1
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_RealEstate_H1 IS NULL AND COUNT_LOAN_PAYMENT_RealEstate_H2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_RealEstate_H1 else (ISNULL(COUNT_LOAN_PAYMENT_RealEstate_H1,0) - ISNULL(COUNT_LOAN_PAYMENT_RealEstate_H2,0)) end [DFT_COUNT_LOAN_PAYMENT_RealEstate_H1_H2]
	
			 --,COUNT_CASH_RealEstate_H1
			 ,CASE WHEN ( COUNT_CASH_RealEstate_H1 IS NULL AND COUNT_CASH_RealEstate_H2 IS  NULL ) THEN COUNT_CASH_RealEstate_H1 else (ISNULL(COUNT_CASH_RealEstate_H1,0) - ISNULL(COUNT_CASH_RealEstate_H2,0)) end [DFT_COUNT_CASH_RealEstate_H1_H2]

			 --,COUNT_DRAFT_RealEstate_H1
			 ,CASE WHEN ( COUNT_DRAFT_RealEstate_H1 IS NULL AND COUNT_DRAFT_RealEstate_H2 IS  NULL ) THEN COUNT_DRAFT_RealEstate_H1 else (ISNULL(COUNT_DRAFT_RealEstate_H1,0) - ISNULL(COUNT_DRAFT_RealEstate_H2,0)) end [DFT_COUNT_DRAFT_RealEstate_H1_H2]

			 --,COUNT_ACH_RealEstate_H1
			 ,CASE WHEN ( COUNT_ACH_RealEstate_H1 IS NULL AND COUNT_ACH_RealEstate_H2 IS  NULL ) THEN COUNT_ACH_RealEstate_H1 else (ISNULL(COUNT_ACH_RealEstate_H1,0) - ISNULL(COUNT_ACH_RealEstate_H2,0)) end [DFT_COUNT_ACH_RealEstate_H1_H2]

			 --,COUNT_FEE_RealEstate_H1
			 ,CASE WHEN ( COUNT_FEE_RealEstate_H1 IS NULL AND COUNT_FEE_RealEstate_H2 IS  NULL ) THEN COUNT_FEE_RealEstate_H1 else (ISNULL(COUNT_FEE_RealEstate_H1,0) - ISNULL(COUNT_FEE_RealEstate_H2,0)) end [DFT_COUNT_FEE_RealEstate_H1_H2]

			 --,COUNT_HOMEBANKING_RealEstate_H1
			 ,CASE WHEN (COUNT_HOMEBANKING_RealEstate_H1 IS NULL AND COUNT_HOMEBANKING_RealEstate_H2 IS  NULL ) THEN COUNT_HOMEBANKING_RealEstate_H1 else (ISNULL(COUNT_HOMEBANKING_RealEstate_H1,0) - ISNULL(COUNT_HOMEBANKING_RealEstate_H2,0)) end [DFT_COUNT_HOMEBANKING_RealEstate_H1_H2]

			 --,COUNT_INSURANCE_RealEstate_H1
			 ,CASE WHEN (COUNT_INSURANCE_RealEstate_H1 IS NULL AND COUNT_INSURANCE_RealEstate_H2 IS  NULL ) THEN COUNT_INSURANCE_RealEstate_H1 else (ISNULL(COUNT_INSURANCE_RealEstate_H1,0) - ISNULL(COUNT_INSURANCE_RealEstate_H2,0)) end [DFT_COUNT_INSURANCE_RealEstate_H1_H2]

			 --,COUNT_CHECKS_RealEstate_H1
			 ,CASE WHEN (COUNT_CHECKS_RealEstate_H1 IS NULL AND COUNT_CHECKS_RealEstate_H2 IS  NULL ) THEN COUNT_CHECKS_RealEstate_H1 else (ISNULL(COUNT_CHECKS_RealEstate_H1,0) - ISNULL(COUNT_CHECKS_RealEstate_H2,0)) end [DFT_COUNT_CHECKS_RealEstate_H1_H2] 

			 --,COUNT_PAYROLL_RealEstate_H1
			 ,CASE WHEN (COUNT_PAYROLL_RealEstate_H1 IS NULL AND COUNT_PAYROLL_RealEstate_H2 IS  NULL ) THEN COUNT_PAYROLL_RealEstate_H1 else (ISNULL(COUNT_PAYROLL_RealEstate_H1,0) - ISNULL(COUNT_PAYROLL_RealEstate_H2,0)) end [DFT_COUNT_PAYROLL_RealEstate_H1_H2]

			 --,COUNT_KIOSK_RealEstate_H1
			 ,CASE WHEN (COUNT_KIOSK_RealEstate_H1 IS NULL AND COUNT_KIOSK_RealEstate_H2 IS  NULL ) THEN COUNT_KIOSK_RealEstate_H1 else (ISNULL(COUNT_KIOSK_RealEstate_H1,0) - ISNULL(COUNT_KIOSK_RealEstate_H2,0)) end [DFT_COUNT_KIOSK_RealEstate_H1_H2]

			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_H1
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_H1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_H2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_H1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_H1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_H2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_RealEstate_H1_H2]

			 --,LOAN_TRANSACTION_AMOUNT_RealEstate_H1
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_RealEstate_H1 IS NULL AND LOAN_TRANSACTION_AMOUNT_RealEstate_H2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_RealEstate_H1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_H1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_RealEstate_H2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_H1_H2]

			 --,INTEREST_AMOUNT_RealEstate_H1
			 ,CASE WHEN (INTEREST_AMOUNT_RealEstate_H1 IS NULL AND INTEREST_AMOUNT_RealEstate_H2 IS  NULL ) THEN INTEREST_AMOUNT_RealEstate_H1 else (ISNULL(INTEREST_AMOUNT_RealEstate_H1,0) - ISNULL(INTEREST_AMOUNT_RealEstate_H2,0)) end [DFT_INTEREST_AMOUNT_RealEstate_H1_H2]

			 --,FEEAMOUNT_RealEstate_H1
			 ,CASE WHEN (FEEAMOUNT_RealEstate_H1 IS NULL AND FEEAMOUNT_RealEstate_H2 IS  NULL ) THEN FEEAMOUNT_RealEstate_H1 else (ISNULL(FEEAMOUNT_RealEstate_H1,0) - ISNULL(FEEAMOUNT_RealEstate_H2,0)) end [DFT_FEEAMOUNT_RealEstate_H1_H2]

			 --,AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_H1
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_H1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_H2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_H1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_H1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_H2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_H1_H2]

			 --,AVG_NEWBALANCE_RealEstate_H1
			 ,CASE WHEN (AVG_NEWBALANCE_RealEstate_H1 IS NULL AND AVG_NEWBALANCE_RealEstate_H2 IS  NULL ) THEN AVG_NEWBALANCE_RealEstate_H1 else (ISNULL(AVG_NEWBALANCE_RealEstate_H1,0) - ISNULL(AVG_NEWBALANCE_RealEstate_H2,0)) end [DFT_AVG_NEWBALANCE_RealEstate_H1_H2]

			 --,AVG_FEEAMOUNT_RealEstate_H1
			 ,CASE WHEN (AVG_FEEAMOUNT_RealEstate_H1 IS NULL AND AVG_FEEAMOUNT_RealEstate_H2 IS  NULL ) THEN AVG_FEEAMOUNT_RealEstate_H1 else (ISNULL(AVG_FEEAMOUNT_RealEstate_H1,0) - ISNULL(AVG_FEEAMOUNT_RealEstate_H2,0)) end [DFT_AVG_FEEAMOUNT_RealEstate_H1_H2]

	         --,COUNT_LOAN_ADDON_SecuredLoan_H1
			 ,CASE WHEN ( COUNT_LOAN_ADDON_SecuredLoan_H1 IS NULL AND COUNT_LOAN_ADDON_SecuredLoan_H2 IS  NULL ) THEN COUNT_LOAN_ADDON_SecuredLoan_H1 else (ISNULL(COUNT_LOAN_ADDON_SecuredLoan_H1,0) - ISNULL(COUNT_LOAN_ADDON_SecuredLoan_H2,0)) end [DFT_COUNT_LOAN_ADDON_SecuredLoan_H1_H2]

			 --,COUNT_NEW_LOAN_SecuredLoan_H1
			 ,CASE WHEN ( COUNT_NEW_LOAN_SecuredLoan_H1 IS NULL AND COUNT_NEW_LOAN_SecuredLoan_H2 IS  NULL ) THEN COUNT_NEW_LOAN_SecuredLoan_H1 else (ISNULL(COUNT_NEW_LOAN_SecuredLoan_H1,0) - ISNULL(COUNT_NEW_LOAN_SecuredLoan_H2,0)) end [COUNT_NEW_LOAN_SecuredLoan_H1_H2]

			 --,COUNT_LOAN_PAYMENT_SecuredLoan_H1
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_SecuredLoan_H1 IS NULL AND COUNT_LOAN_PAYMENT_SecuredLoan_H2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_SecuredLoan_H1 else (ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_H1,0) - ISNULL(COUNT_LOAN_PAYMENT_SecuredLoan_H2,0)) end [DFT_COUNT_LOAN_PAYMENT_SecuredLoan_H1_H2]

			 --,COUNT_CASH_SecuredLoan_H1
			 ,CASE WHEN ( COUNT_CASH_SecuredLoan_H1 IS NULL AND COUNT_CASH_SecuredLoan_H2 IS  NULL ) THEN COUNT_CASH_SecuredLoan_H1 else (ISNULL(COUNT_CASH_SecuredLoan_H1,0) - ISNULL(COUNT_CASH_SecuredLoan_H2,0)) end [DFT_COUNT_CASH_SecuredLoan_H1_H2]

			 --,COUNT_DRAFT_SecuredLoan_H1
			 ,CASE WHEN ( COUNT_DRAFT_SecuredLoan_H1 IS NULL AND COUNT_DRAFT_SecuredLoan_H2 IS  NULL ) THEN COUNT_DRAFT_SecuredLoan_H1 else (ISNULL(COUNT_DRAFT_SecuredLoan_H1,0) - ISNULL(COUNT_DRAFT_SecuredLoan_H2,0)) end [DFT_COUNT_DRAFT_SecuredLoan_H1_H2]

			 --,COUNT_ACH_SecuredLoan_H1
			 ,CASE WHEN ( COUNT_ACH_SecuredLoan_H1 IS NULL AND COUNT_ACH_SecuredLoan_H2 IS  NULL ) THEN COUNT_ACH_SecuredLoan_H1 else (ISNULL(COUNT_ACH_SecuredLoan_H1,0) - ISNULL(COUNT_ACH_SecuredLoan_H2,0)) end [DFT_COUNT_ACH_SecuredLoan_H1_H2]

			 --,COUNT_FEE_SecuredLoan_H1
			 ,CASE WHEN ( COUNT_FEE_SecuredLoan_H1 IS NULL AND COUNT_FEE_SecuredLoan_H2 IS  NULL ) THEN COUNT_FEE_SecuredLoan_H1 else (ISNULL(COUNT_FEE_SecuredLoan_H1,0) - ISNULL(COUNT_FEE_SecuredLoan_H2,0)) end [DFT_COUNT_FEE_SecuredLoan_H1_H2]

			 --,COUNT_HOMEBANKING_SecuredLoan_H1
			 ,CASE WHEN (COUNT_HOMEBANKING_SecuredLoan_H1 IS NULL AND COUNT_HOMEBANKING_SecuredLoan_H2 IS  NULL ) THEN COUNT_HOMEBANKING_SecuredLoan_H1 else (ISNULL(COUNT_HOMEBANKING_SecuredLoan_H1,0) - ISNULL(COUNT_HOMEBANKING_SecuredLoan_H2,0)) end [DFT_COUNT_HOMEBANKING_SecuredLoan_H1_H2]

			 --,COUNT_INSURANCE_SecuredLoan_H1
			 ,CASE WHEN (COUNT_INSURANCE_SecuredLoan_H1 IS NULL AND COUNT_INSURANCE_SecuredLoan_H2 IS  NULL ) THEN COUNT_INSURANCE_SecuredLoan_H1 else (ISNULL(COUNT_INSURANCE_SecuredLoan_H1,0) - ISNULL(COUNT_INSURANCE_SecuredLoan_H2,0)) end [DFT_COUNT_INSURANCE_SecuredLoan_H1_H2]

			 --,COUNT_CHECKS_SecuredLoan_H1
			 ,CASE WHEN (COUNT_CHECKS_SecuredLoan_H1 IS NULL AND COUNT_CHECKS_SecuredLoan_H2 IS  NULL ) THEN COUNT_CHECKS_SecuredLoan_H1 else (ISNULL(COUNT_CHECKS_SecuredLoan_H1,0) - ISNULL(COUNT_CHECKS_SecuredLoan_H2,0)) end [DFT_COUNT_CHECKS_SecuredLoan_H1_H2] 

			 --,COUNT_PAYROLL_SecuredLoan_H1
			 ,CASE WHEN (COUNT_PAYROLL_SecuredLoan_H1 IS NULL AND COUNT_PAYROLL_SecuredLoan_H2 IS  NULL ) THEN COUNT_PAYROLL_SecuredLoan_H1 else (ISNULL(COUNT_PAYROLL_SecuredLoan_H1,0) - ISNULL(COUNT_PAYROLL_SecuredLoan_H2,0)) end [DFT_COUNT_PAYROLL_SecuredLoan_H1_H2]

			 --,COUNT_KIOSK_SecuredLoan_H1
			 ,CASE WHEN (COUNT_KIOSK_SecuredLoan_H1 IS NULL AND COUNT_KIOSK_SecuredLoan_H2 IS  NULL ) THEN COUNT_KIOSK_SecuredLoan_H1 else (ISNULL(COUNT_KIOSK_SecuredLoan_H1,0) - ISNULL(COUNT_KIOSK_SecuredLoan_H2,0)) end [DFT_COUNT_KIOSK_SecuredLoan_H1_H2]

			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_H1
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_H1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_H2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_H1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_H1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_H2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_SecuredLoan_H1_H2]


			 --,LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1 IS NULL AND LOAN_TRANSACTION_AMOUNT_SecuredLoan_H2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_SecuredLoan_H2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1_H2]

			 --,INTEREST_AMOUNT_SecuredLoan_H1
			 ,CASE WHEN (INTEREST_AMOUNT_SecuredLoan_H1 IS NULL AND INTEREST_AMOUNT_SecuredLoan_H2 IS  NULL ) THEN INTEREST_AMOUNT_SecuredLoan_H1 else (ISNULL(INTEREST_AMOUNT_SecuredLoan_H1,0) - ISNULL(INTEREST_AMOUNT_SecuredLoan_H2,0)) end [DFT_INTEREST_AMOUNT_SecuredLoan_H1_H2]

			 --,FEEAMOUNT_SecuredLoan_H1
			 ,CASE WHEN (FEEAMOUNT_SecuredLoan_H1 IS NULL AND FEEAMOUNT_SecuredLoan_H2 IS  NULL ) THEN FEEAMOUNT_SecuredLoan_H1 else (ISNULL(FEEAMOUNT_SecuredLoan_H1,0) - ISNULL(FEEAMOUNT_SecuredLoan_H2,0)) end [DFT_FEEAMOUNT_SecuredLoan_H1_H2]

			 --,AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_H2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_H2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1_H2]

			 --,AVG_NEWBALANCE_SecuredLoan_H1
			 ,CASE WHEN (AVG_NEWBALANCE_SecuredLoan_H1 IS NULL AND AVG_NEWBALANCE_SecuredLoan_H2 IS  NULL ) THEN AVG_NEWBALANCE_SecuredLoan_H1 else (ISNULL(AVG_NEWBALANCE_SecuredLoan_H1,0) - ISNULL(AVG_NEWBALANCE_SecuredLoan_H2,0)) end [DFT_AVG_NEWBALANCE_SecuredLoan_H1_H2]

			 --,AVG_FEEAMOUNT_SecuredLoan_H1
			 ,CASE WHEN (AVG_FEEAMOUNT_SecuredLoan_H1 IS NULL AND AVG_FEEAMOUNT_SecuredLoan_H2 IS  NULL ) THEN AVG_FEEAMOUNT_SecuredLoan_H1 else (ISNULL(AVG_FEEAMOUNT_SecuredLoan_H1,0) - ISNULL(AVG_FEEAMOUNT_SecuredLoan_H2,0)) end [DFT_AVG_FEEAMOUNT_SecuredLoan_H1_H2]



	         --,COUNT_LOAN_ADDON_UnsecuredLoan_H1
			 ,CASE WHEN ( COUNT_LOAN_ADDON_UnsecuredLoan_H1 IS NULL AND COUNT_LOAN_ADDON_UnsecuredLoan_H2 IS  NULL ) THEN COUNT_LOAN_ADDON_UnsecuredLoan_H1 else (ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_H1,0) - ISNULL(COUNT_LOAN_ADDON_UnsecuredLoan_H2,0)) end [DFT_COUNT_LOAN_ADDON_UnsecuredLoan_H1_H2]

			 --,COUNT_NEW_LOAN_UnsecuredLoan_H1
			 ,CASE WHEN ( COUNT_NEW_LOAN_UnsecuredLoan_H1 IS NULL AND COUNT_NEW_LOAN_UnsecuredLoan_H2 IS  NULL ) THEN COUNT_NEW_LOAN_UnsecuredLoan_H1 else (ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_H1,0) - ISNULL(COUNT_NEW_LOAN_UnsecuredLoan_H2,0)) end [COUNT_NEW_LOAN_UnsecuredLoan_H1_H2]

			 --,COUNT_LOAN_PAYMENT_UnsecuredLoan_H1
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_UnsecuredLoan_H1 IS NULL AND COUNT_LOAN_PAYMENT_UnsecuredLoan_H2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_UnsecuredLoan_H1 else (ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_H1,0) - ISNULL(COUNT_LOAN_PAYMENT_UnsecuredLoan_H2,0)) end [DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_H1_H2]

			 --,COUNT_CASH_UnsecuredLoan_H1
			 ,CASE WHEN ( COUNT_CASH_UnsecuredLoan_H1 IS NULL AND COUNT_CASH_UnsecuredLoan_H2 IS  NULL ) THEN COUNT_CASH_UnsecuredLoan_H1 else (ISNULL(COUNT_CASH_UnsecuredLoan_H1,0) - ISNULL(COUNT_CASH_UnsecuredLoan_H2,0)) end [DFT_COUNT_CASH_UnsecuredLoan_H1_H2]

			 --,COUNT_DRAFT_UnsecuredLoan_H1
			 ,CASE WHEN ( COUNT_DRAFT_UnsecuredLoan_H1 IS NULL AND COUNT_DRAFT_UnsecuredLoan_H2 IS  NULL ) THEN COUNT_DRAFT_UnsecuredLoan_H1 else (ISNULL(COUNT_DRAFT_UnsecuredLoan_H1,0) - ISNULL(COUNT_DRAFT_UnsecuredLoan_H2,0)) end [DFT_COUNT_DRAFT_UnsecuredLoan_H1_H2]

			 --,COUNT_ACH_UnsecuredLoan_H1
			 ,CASE WHEN ( COUNT_ACH_UnsecuredLoan_H1 IS NULL AND COUNT_ACH_UnsecuredLoan_H2 IS  NULL ) THEN COUNT_ACH_UnsecuredLoan_H1 else (ISNULL(COUNT_ACH_UnsecuredLoan_H1,0) - ISNULL(COUNT_ACH_UnsecuredLoan_H2,0)) end [DFT_COUNT_ACH_UnsecuredLoan_H1_H2]

			 --,COUNT_FEE_UnsecuredLoan_H1
			 ,CASE WHEN ( COUNT_FEE_UnsecuredLoan_H1 IS NULL AND COUNT_FEE_UnsecuredLoan_H2 IS  NULL ) THEN COUNT_FEE_UnsecuredLoan_H1 else (ISNULL(COUNT_FEE_UnsecuredLoan_H1,0) - ISNULL(COUNT_FEE_UnsecuredLoan_H2,0)) end [DFT_COUNT_FEE_UnsecuredLoan_H1_H2]

			 --,COUNT_HOMEBANKING_UnsecuredLoan_H1
			 ,CASE WHEN (COUNT_HOMEBANKING_UnsecuredLoan_H1 IS NULL AND COUNT_HOMEBANKING_UnsecuredLoan_H2 IS  NULL ) THEN COUNT_HOMEBANKING_UnsecuredLoan_H1 else (ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_H1,0) - ISNULL(COUNT_HOMEBANKING_UnsecuredLoan_H2,0)) end [DFT_COUNT_HOMEBANKING_UnsecuredLoan_H1_H2]

			 --,COUNT_INSURANCE_UnsecuredLoan_H1
			 ,CASE WHEN (COUNT_INSURANCE_UnsecuredLoan_H1 IS NULL AND COUNT_INSURANCE_UnsecuredLoan_H2 IS  NULL ) THEN COUNT_INSURANCE_UnsecuredLoan_H1 else (ISNULL(COUNT_INSURANCE_UnsecuredLoan_H1,0) - ISNULL(COUNT_INSURANCE_UnsecuredLoan_H2,0)) end [DFT_COUNT_INSURANCE_UnsecuredLoan_H1_H2]

			 --,COUNT_CHECKS_UnsecuredLoan_H1
			 ,CASE WHEN (COUNT_CHECKS_UnsecuredLoan_H1 IS NULL AND COUNT_CHECKS_UnsecuredLoan_H2 IS  NULL ) THEN COUNT_CHECKS_UnsecuredLoan_H1 else (ISNULL(COUNT_CHECKS_UnsecuredLoan_H1,0) - ISNULL(COUNT_CHECKS_UnsecuredLoan_H2,0)) end [DFT_COUNT_CHECKS_UnsecuredLoan_H1_H2] 

			 --,COUNT_PAYROLL_UnsecuredLoan_H1
			 ,CASE WHEN (COUNT_PAYROLL_UnsecuredLoan_H1 IS NULL AND COUNT_PAYROLL_UnsecuredLoan_H2 IS  NULL ) THEN COUNT_PAYROLL_UnsecuredLoan_H1 else (ISNULL(COUNT_PAYROLL_UnsecuredLoan_H1,0) - ISNULL(COUNT_PAYROLL_UnsecuredLoan_H2,0)) end [DFT_COUNT_PAYROLL_UnsecuredLoan_H1_H2]

			 --,COUNT_KIOSK_UnsecuredLoan_H1
			 ,CASE WHEN (COUNT_KIOSK_UnsecuredLoan_H1 IS NULL AND COUNT_KIOSK_UnsecuredLoan_H2 IS  NULL ) THEN COUNT_KIOSK_UnsecuredLoan_H1 else (ISNULL(COUNT_KIOSK_UnsecuredLoan_H1,0) - ISNULL(COUNT_KIOSK_UnsecuredLoan_H2,0)) end [DFT_COUNT_KIOSK_UnsecuredLoan_H1_H2]

			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_H1
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_H1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_H2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_H1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_H1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_H2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_UnsecuredLoan_H1_H2]


			 --,LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1 IS NULL AND LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1_H2]

			 --,INTEREST_AMOUNT_UnsecuredLoan_H1
			 ,CASE WHEN (INTEREST_AMOUNT_UnsecuredLoan_H1 IS NULL AND INTEREST_AMOUNT_UnsecuredLoan_H2 IS  NULL ) THEN INTEREST_AMOUNT_UnsecuredLoan_H1 else (ISNULL(INTEREST_AMOUNT_UnsecuredLoan_H1,0) - ISNULL(INTEREST_AMOUNT_UnsecuredLoan_H2,0)) end [DFT_INTEREST_AMOUNT_UnsecuredLoan_H1_H2]

			 --,FEEAMOUNT_UnsecuredLoan_H1
			 ,CASE WHEN (FEEAMOUNT_UnsecuredLoan_H1 IS NULL AND FEEAMOUNT_UnsecuredLoan_H2 IS  NULL ) THEN FEEAMOUNT_UnsecuredLoan_H1 else (ISNULL(FEEAMOUNT_UnsecuredLoan_H1,0) - ISNULL(FEEAMOUNT_UnsecuredLoan_H2,0)) end [DFT_FEEAMOUNT_UnsecuredLoan_H1_H2]

			 --,AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1_H2]

			 --,AVG_NEWBALANCE_UnsecuredLoan_H1
			 ,CASE WHEN (AVG_NEWBALANCE_UnsecuredLoan_H1 IS NULL AND AVG_NEWBALANCE_UnsecuredLoan_H2 IS  NULL ) THEN AVG_NEWBALANCE_UnsecuredLoan_H1 else (ISNULL(AVG_NEWBALANCE_UnsecuredLoan_H1,0) - ISNULL(AVG_NEWBALANCE_UnsecuredLoan_H2,0)) end [DFT_AVG_NEWBALANCE_UnsecuredLoan_H1_H2]

			 --,AVG_FEEAMOUNT_UnsecuredLoan_H1
			 ,CASE WHEN (AVG_FEEAMOUNT_UnsecuredLoan_H1 IS NULL AND AVG_FEEAMOUNT_UnsecuredLoan_H2 IS  NULL ) THEN AVG_FEEAMOUNT_UnsecuredLoan_H1 else (ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_H1,0) - ISNULL(AVG_FEEAMOUNT_UnsecuredLoan_H2,0)) end [DFT_AVG_FEEAMOUNT_UnsecuredLoan_H1_H2]



	         --,COUNT_LOAN_ADDON_VehicleLoan_H1
			 ,CASE WHEN ( COUNT_LOAN_ADDON_VehicleLoan_H1 IS NULL AND COUNT_LOAN_ADDON_VehicleLoan_H2 IS  NULL ) THEN COUNT_LOAN_ADDON_VehicleLoan_H1 else (ISNULL(COUNT_LOAN_ADDON_VehicleLoan_H1,0) - ISNULL(COUNT_LOAN_ADDON_VehicleLoan_H2,0)) end [DFT_COUNT_LOAN_ADDON_VehicleLoan_H1_H2]

			 --,COUNT_NEW_LOAN_VehicleLoan_H1
			 ,CASE WHEN ( COUNT_NEW_LOAN_VehicleLoan_H1 IS NULL AND COUNT_NEW_LOAN_VehicleLoan_H2 IS  NULL ) THEN COUNT_NEW_LOAN_VehicleLoan_H1 else (ISNULL(COUNT_NEW_LOAN_VehicleLoan_H1,0) - ISNULL(COUNT_NEW_LOAN_VehicleLoan_H2,0)) end [COUNT_NEW_LOAN_VehicleLoan_H1_H2]

			 --,COUNT_LOAN_PAYMENT_VehicleLoan_H1
			 ,CASE WHEN ( COUNT_LOAN_PAYMENT_VehicleLoan_H1 IS NULL AND COUNT_LOAN_PAYMENT_VehicleLoan_H2 IS  NULL ) THEN COUNT_LOAN_PAYMENT_VehicleLoan_H1 else (ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_H1,0) - ISNULL(COUNT_LOAN_PAYMENT_VehicleLoan_H2,0)) end [DFT_COUNT_LOAN_PAYMENT_VehicleLoan_H1_H2]

			 --,COUNT_CASH_VehicleLoan_H1
			 ,CASE WHEN ( COUNT_CASH_VehicleLoan_H1 IS NULL AND COUNT_CASH_VehicleLoan_H2 IS  NULL ) THEN COUNT_CASH_VehicleLoan_H1 else (ISNULL(COUNT_CASH_VehicleLoan_H1,0) - ISNULL(COUNT_CASH_VehicleLoan_H2,0)) end [DFT_COUNT_CASH_VehicleLoan_H1_H2]

			 --,COUNT_DRAFT_VehicleLoan_H1
			 ,CASE WHEN ( COUNT_DRAFT_VehicleLoan_H1 IS NULL AND COUNT_DRAFT_VehicleLoan_H2 IS  NULL ) THEN COUNT_DRAFT_VehicleLoan_H1 else (ISNULL(COUNT_DRAFT_VehicleLoan_H1,0) - ISNULL(COUNT_DRAFT_VehicleLoan_H2,0)) end [DFT_COUNT_DRAFT_VehicleLoan_H1_H2]

			 --,COUNT_ACH_VehicleLoan_H1
			 ,CASE WHEN ( COUNT_ACH_VehicleLoan_H1 IS NULL AND COUNT_ACH_VehicleLoan_H2 IS  NULL ) THEN COUNT_ACH_VehicleLoan_H1 else (ISNULL(COUNT_ACH_VehicleLoan_H1,0) - ISNULL(COUNT_ACH_VehicleLoan_H2,0)) end [DFT_COUNT_ACH_VehicleLoan_H1_H2]

			 --,COUNT_FEE_VehicleLoan_H1
			 ,CASE WHEN ( COUNT_FEE_VehicleLoan_H1 IS NULL AND COUNT_FEE_VehicleLoan_H2 IS  NULL ) THEN COUNT_FEE_VehicleLoan_H1 else (ISNULL(COUNT_FEE_VehicleLoan_H1,0) - ISNULL(COUNT_FEE_VehicleLoan_H2,0)) end [DFT_COUNT_FEE_VehicleLoan_H1_H2]

			 --,COUNT_HOMEBANKING_VehicleLoan_H1
			 ,CASE WHEN (COUNT_HOMEBANKING_VehicleLoan_H1 IS NULL AND COUNT_HOMEBANKING_VehicleLoan_H2 IS  NULL ) THEN COUNT_HOMEBANKING_VehicleLoan_H1 else (ISNULL(COUNT_HOMEBANKING_VehicleLoan_H1,0) - ISNULL(COUNT_HOMEBANKING_VehicleLoan_H2,0)) end [DFT_COUNT_HOMEBANKING_VehicleLoan_H1_H2]

			 --,COUNT_INSURANCE_VehicleLoan_H1
			 ,CASE WHEN (COUNT_INSURANCE_VehicleLoan_H1 IS NULL AND COUNT_INSURANCE_VehicleLoan_H2 IS  NULL ) THEN COUNT_INSURANCE_VehicleLoan_H1 else (ISNULL(COUNT_INSURANCE_VehicleLoan_H1,0) - ISNULL(COUNT_INSURANCE_VehicleLoan_H2,0)) end [DFT_COUNT_INSURANCE_VehicleLoan_H1_H2]

			 --,COUNT_CHECKS_VehicleLoan_H1
			 ,CASE WHEN (COUNT_CHECKS_VehicleLoan_H1 IS NULL AND COUNT_CHECKS_VehicleLoan_H2 IS  NULL ) THEN COUNT_CHECKS_VehicleLoan_H1 else (ISNULL(COUNT_CHECKS_VehicleLoan_H1,0) - ISNULL(COUNT_CHECKS_VehicleLoan_H2,0)) end [DFT_COUNT_CHECKS_VehicleLoan_H1_H2] 

			 --,COUNT_PAYROLL_VehicleLoan_H1
			 ,CASE WHEN (COUNT_PAYROLL_VehicleLoan_H1 IS NULL AND COUNT_PAYROLL_VehicleLoan_H2 IS  NULL ) THEN COUNT_PAYROLL_VehicleLoan_H1 else (ISNULL(COUNT_PAYROLL_VehicleLoan_H1,0) - ISNULL(COUNT_PAYROLL_VehicleLoan_H2,0)) end [DFT_COUNT_PAYROLL_VehicleLoan_H1_H2]

			 --,COUNT_KIOSK_VehicleLoan_H1
			 ,CASE WHEN (COUNT_KIOSK_VehicleLoan_H1 IS NULL AND COUNT_KIOSK_VehicleLoan_H2 IS  NULL ) THEN COUNT_KIOSK_VehicleLoan_H1 else (ISNULL(COUNT_KIOSK_VehicleLoan_H1,0) - ISNULL(COUNT_KIOSK_VehicleLoan_H2,0)) end [DFT_COUNT_KIOSK_VehicleLoan_H1_H2]

			 --,COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_H1
			 ,CASE WHEN ( COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_H1 IS NULL AND COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_H2 IS  NULL ) THEN COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_H1 else (ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_H1,0) - ISNULL(COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_H2,0)) end [DFT_COUNT_AUDIO_RESPONSE_TELEPHONE_VehicleLoan_H1_H2]


			 --,LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1
			 ,CASE WHEN (LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1 IS NULL AND LOAN_TRANSACTION_AMOUNT_VehicleLoan_H2 IS  NULL ) THEN LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1 else (ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1,0) - ISNULL(LOAN_TRANSACTION_AMOUNT_VehicleLoan_H2,0)) end [DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2]

			 --,INTEREST_AMOUNT_VehicleLoan_H1
			 ,CASE WHEN (INTEREST_AMOUNT_VehicleLoan_H1 IS NULL AND INTEREST_AMOUNT_VehicleLoan_H2 IS  NULL ) THEN INTEREST_AMOUNT_VehicleLoan_H1 else (ISNULL(INTEREST_AMOUNT_VehicleLoan_H1,0) - ISNULL(INTEREST_AMOUNT_VehicleLoan_H2,0)) end [DFT_INTEREST_AMOUNT_VehicleLoan_H1_H2]

			 --,FEEAMOUNT_VehicleLoan_H1
			 ,CASE WHEN (FEEAMOUNT_VehicleLoan_H1 IS NULL AND FEEAMOUNT_VehicleLoan_H2 IS  NULL ) THEN FEEAMOUNT_VehicleLoan_H1 else (ISNULL(FEEAMOUNT_VehicleLoan_H1,0) - ISNULL(FEEAMOUNT_VehicleLoan_H2,0)) end [DFT_FEEAMOUNT_VehicleLoan_H1_H2]

			 --,AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1
			 ,CASE WHEN (AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1 IS NULL AND AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H2 IS  NULL ) THEN AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1 else (ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1,0) - ISNULL(AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H2,0)) end [DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2]
	
			 --,AVG_NEWBALANCE_VehicleLoan_H1
			 ,CASE WHEN (AVG_NEWBALANCE_VehicleLoan_H1 IS NULL AND AVG_NEWBALANCE_VehicleLoan_H2 IS  NULL ) THEN AVG_NEWBALANCE_VehicleLoan_H1 else (ISNULL(AVG_NEWBALANCE_VehicleLoan_H1,0) - ISNULL(AVG_NEWBALANCE_VehicleLoan_H2,0)) end [DFT_AVG_NEWBALANCE_VehicleLoan_H1_H2]

			 --,AVG_FEEAMOUNT_VehicleLoan_H1
			 ,CASE WHEN (AVG_FEEAMOUNT_VehicleLoan_H1 IS NULL AND AVG_FEEAMOUNT_VehicleLoan_H2 IS  NULL ) THEN AVG_FEEAMOUNT_VehicleLoan_H1 else (ISNULL(AVG_FEEAMOUNT_VehicleLoan_H1,0) - ISNULL(AVG_FEEAMOUNT_VehicleLoan_H2,0)) end [DFT_AVG_FEEAMOUNT_VehicleLoan_H1_H2]


			  INTO #LOAN_TRANSACTION_derived_vars 
			  FROM #transaction_loan

------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** DELINQUENCY Master Data ***\\\-------------------------------------------------------------------
  --      DECLARE @staticpooldate date
		--set @staticpooldate = '2022-06-30'

         DROP TABLE IF EXISTS #DELQ_INFO
		 SELECT *
		 INTO #DELQ_INFO
		 FROM
         (-- DECLARE @staticpooldate date
		--set @staticpooldate = '2022-06-30'
		 
		 SELECT SSN
		       ,AccountNumber
			   ,UNID
			   ,LoanDelqDays
			   ,Product_Flag
			   ,Processdate
 						   ,case when Processdate in ((EOMONTH(DATEADD(month,-12,@staticpooldate))),(EOMONTH(DATEADD(month,-11,@staticpooldate))),(EOMONTH(DATEADD(month,-10,@staticpooldate )))) then 'Q4'
		                         when Processdate in ((EOMONTH(DATEADD(month,-9,@staticpooldate ))),(EOMONTH(DATEADD(month,-8,@staticpooldate))),(EOMONTH(DATEADD(month,-7,@staticpooldate)))) then 'Q3'
 								 when Processdate in ((EOMONTH(DATEADD(month,-6,@staticpooldate ))),(EOMONTH(DATEADD(month,-5,@staticpooldate))),(EOMONTH(DATEADD(month,-4,@staticpooldate)))) then 'Q2'
								 when Processdate in ((EOMONTH(DATEADD(month,-3,@staticpooldate))),(EOMONTH(DATEADD(month,-2,@staticpooldate ))),(EOMONTH(DATEADD(month,-1,@staticpooldate )))) then 'Q1'
								 when Processdate in (@staticpooldate) then 'Staticpool'
							end Quarters
							,case when Processdate in (EOMONTH(DATEADD(month,-12,@staticpooldate)),(EOMONTH(DATEADD(month,-11,@staticpooldate))),(EOMONTH(DATEADD(month,-10,@staticpooldate))) 
							                         ,(EOMONTH(DATEADD(month,-9,@staticpooldate ))),(EOMONTH(DATEADD(month,-8,@staticpooldate))),(EOMONTH(DATEADD(month,-7,@staticpooldate)))) then 'H2'
 								  when Processdate in (EOMONTH(DATEADD(month,-6,@staticpooldate )),(EOMONTH(DATEADD(month,-5,@staticpooldate))),(EOMONTH(DATEADD(month,-4,@staticpooldate)))
								                      ,(EOMONTH(DATEADD(month,-3,@staticpooldate))),(EOMONTH(DATEADD(month,-2,@staticpooldate ))),(EOMONTH(DATEADD(month,-1,@staticpooldate )))) then 'H1'
							end HalfYearly

 						   ,case when Processdate in (EOMONTH(DATEADD(month,-12,@staticpooldate))) then '12MonthBack'
						         when Processdate in (EOMONTH(DATEADD(month,-9,@staticpooldate ))) then '9MonthBack'
 								 when Processdate in (EOMONTH(DATEADD(month,-6,@staticpooldate ))) then '6MonthBack'
								 when Processdate in (EOMONTH(DATEADD(month,-3,@staticpooldate))) then '3MonthBack' end MonthFlag
         
		 FROM
          (SELECT C.SSN
		         ,A.AccountNumber
				 ,B.Product_Flag
				 ,B.UNID
				 ,A.LoanDelqDays
				 ,datefromparts(left(A.ProcessDate,4),left(right(A.ProcessDate,4),2),right(A.ProcessDate,2)) Processdate			
 
		   FROM ARCUSYM000.ARCU.ARCULoanDetailed A
		   LEFT JOIN #static_unid B
		   ON A.AccountNumber = B.PARENTACCOUNT
		   LEFT JOIN #Static_SSN_account C
		   ON A.AccountNumber = C.AccountNumber) P ) D
		   where D.Quarters is not null 
			 and Processdate between (select EOMONTH(dateadd(MM,-12,@staticpooldate))) and (select EOMONTH(dateadd(MM,12,@staticpooldate))) 

			 DROP TABLE IF EXISTS #DELQ_MASTER
			 
			 SELECT *
			       , CASE WHEN ProductRealEstate_Cycle1_SP > 0 THEN 1 ELSE 0 END RealEstate_Cycle1Flag_SP
				   , CASE WHEN ProductRealEstate_Cycle2_SP > 0 THEN 1 ELSE 0 END RealEstate_Cycle2Flag_SP
				   , CASE WHEN ProductRealEstate_Cycle2plus_SP > 0 THEN 1 ELSE 0 END RealEstate_Cycle2plusFlag_SP
			       , CASE WHEN ProductSecuredLoan_Cycle1_SP > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle1Flag_SP
				   , CASE WHEN ProductSecuredLoan_Cycle2_SP > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle2Flag_SP
				   , CASE WHEN ProductSecuredLoan_Cycle2plus_SP > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle2plusFlag_SP
			       , CASE WHEN ProductUnsecuredLoan_Cycle1_SP > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle1Flag_SP
				   , CASE WHEN ProductUnsecuredLoan_Cycle2_SP > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle2Flag_SP
				   , CASE WHEN ProductUnsecuredLoan_Cycle2plus_SP > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle2plusFlag_SP
			       , CASE WHEN ProductVehicleLoan_Cycle1_SP > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle1Flag_SP
				   , CASE WHEN ProductVehicleLoan_Cycle2_SP > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle2Flag_SP
				   , CASE WHEN ProductVehicleLoan_Cycle2plus_SP > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle2plusFlag_SP
			       , CASE WHEN ProductLoan_Cycle1_SP > 0 THEN 1 ELSE 0 END Loan_Cycle1Flag_SP
				   , CASE WHEN ProductLoan_Cycle2_SP > 0 THEN 1 ELSE 0 END Loan_Cycle2Flag_SP
				   , CASE WHEN ProductLoan_Cycle2plus_SP > 0 THEN 1 ELSE 0 END Loan_Cycle2plusFlag_SP

			       , CASE WHEN ProductRealEstate_Cycle1_3MonthBack > 0 THEN 1 ELSE 0 END RealEstate_Cycle1Flag_3MonthBack
				   , CASE WHEN ProductRealEstate_Cycle2_3MonthBack > 0 THEN 1 ELSE 0 END RealEstate_Cycle2Flag_3MonthBack
				   , CASE WHEN ProductRealEstate_Cycle2plus_3MonthBack > 0 THEN 1 ELSE 0 END RealEstate_Cycle2plusFlag_3MonthBack
			       , CASE WHEN ProductSecuredLoan_Cycle1_3MonthBack > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle1Flag_3MonthBack
				   , CASE WHEN ProductSecuredLoan_Cycle2_3MonthBack > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle2Flag_3MonthBack
				   , CASE WHEN ProductSecuredLoan_Cycle2plus_3MonthBack > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle2plusFlag_3MonthBack
			       , CASE WHEN ProductUnsecuredLoan_Cycle1_3MonthBack > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle1Flag_3MonthBack
				   , CASE WHEN ProductUnsecuredLoan_Cycle2_3MonthBack > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle2Flag_3MonthBack
				   , CASE WHEN ProductUnsecuredLoan_Cycle2plus_3MonthBack > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle2plusFlag_3MonthBack
			       , CASE WHEN ProductVehicleLoan_Cycle1_3MonthBack > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle1Flag_3MonthBack
				   , CASE WHEN ProductVehicleLoan_Cycle2_3MonthBack > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle2Flag_3MonthBack
				   , CASE WHEN ProductVehicleLoan_Cycle2plus_3MonthBack > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle2plusFlag_3MonthBack
			       , CASE WHEN ProductLoan_Cycle1_3MonthBack > 0 THEN 1 ELSE 0 END Loan_Cycle1Flag_3MonthBack
				   , CASE WHEN ProductLoan_Cycle2_3MonthBack > 0 THEN 1 ELSE 0 END Loan_Cycle2Flag_3MonthBack
				   , CASE WHEN ProductLoan_Cycle2plus_3MonthBack > 0 THEN 1 ELSE 0 END Loan_Cycle2plusFlag_3MonthBack

			       , CASE WHEN ProductRealEstate_Cycle1_6MonthBack > 0 THEN 1 ELSE 0 END RealEstate_Cycle1Flag_6MonthBack
				   , CASE WHEN ProductRealEstate_Cycle2_6MonthBack > 0 THEN 1 ELSE 0 END RealEstate_Cycle2Flag_6MonthBack
				   , CASE WHEN ProductRealEstate_Cycle2plus_6MonthBack > 0 THEN 1 ELSE 0 END RealEstate_Cycle2plusFlag_6MonthBack
			       , CASE WHEN ProductSecuredLoan_Cycle1_6MonthBack > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle1Flag_6MonthBack
				   , CASE WHEN ProductSecuredLoan_Cycle2_6MonthBack > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle2Flag_6MonthBack
				   , CASE WHEN ProductSecuredLoan_Cycle2plus_6MonthBack > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle2plusFlag_6MonthBack
			       , CASE WHEN ProductUnsecuredLoan_Cycle1_6MonthBack > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle1Flag_6MonthBack
				   , CASE WHEN ProductUnsecuredLoan_Cycle2_6MonthBack > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle2Flag_6MonthBack
				   , CASE WHEN ProductUnsecuredLoan_Cycle2plus_6MonthBack > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle2plusFlag_6MonthBack
			       , CASE WHEN ProductVehicleLoan_Cycle1_6MonthBack > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle1Flag_6MonthBack
				   , CASE WHEN ProductVehicleLoan_Cycle2_6MonthBack > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle2Flag_6MonthBack
				   , CASE WHEN ProductVehicleLoan_Cycle2plus_6MonthBack > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle2plusFlag_6MonthBack
			       , CASE WHEN ProductLoan_Cycle1_6MonthBack > 0 THEN 1 ELSE 0 END Loan_Cycle1Flag_6MonthBack
				   , CASE WHEN ProductLoan_Cycle2_6MonthBack > 0 THEN 1 ELSE 0 END Loan_Cycle2Flag_6MonthBack
				   , CASE WHEN ProductLoan_Cycle2plus_6MonthBack > 0 THEN 1 ELSE 0 END Loan_Cycle2plusFlag_6MonthBack

			       , CASE WHEN ProductRealEstate_Cycle1_9MonthBack > 0 THEN 1 ELSE 0 END RealEstate_Cycle1Flag_9MonthBack
				   , CASE WHEN ProductRealEstate_Cycle2_9MonthBack > 0 THEN 1 ELSE 0 END RealEstate_Cycle2Flag_9MonthBack
				   , CASE WHEN ProductRealEstate_Cycle2plus_9MonthBack > 0 THEN 1 ELSE 0 END RealEstate_Cycle2plusFlag_9MonthBack
			       , CASE WHEN ProductSecuredLoan_Cycle1_9MonthBack > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle1Flag_9MonthBack
				   , CASE WHEN ProductSecuredLoan_Cycle2_9MonthBack > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle2Flag_9MonthBack
				   , CASE WHEN ProductSecuredLoan_Cycle2plus_9MonthBack > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle2plusFlag_9MonthBack
			       , CASE WHEN ProductUnsecuredLoan_Cycle1_9MonthBack > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle1Flag_9MonthBack
				   , CASE WHEN ProductUnsecuredLoan_Cycle2_9MonthBack > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle2Flag_9MonthBack
				   , CASE WHEN ProductUnsecuredLoan_Cycle2plus_9MonthBack > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle2plusFlag_9MonthBack
			       , CASE WHEN ProductVehicleLoan_Cycle1_9MonthBack > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle1Flag_9MonthBack
				   , CASE WHEN ProductVehicleLoan_Cycle2_9MonthBack > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle2Flag_9MonthBack
				   , CASE WHEN ProductVehicleLoan_Cycle2plus_9MonthBack > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle2plusFlag_9MonthBack
			       , CASE WHEN ProductLoan_Cycle1_9MonthBack > 0 THEN 1 ELSE 0 END Loan_Cycle1Flag_9MonthBack
				   , CASE WHEN ProductLoan_Cycle2_9MonthBack > 0 THEN 1 ELSE 0 END Loan_Cycle2Flag_9MonthBack
				   , CASE WHEN ProductLoan_Cycle2plus_9MonthBack > 0 THEN 1 ELSE 0 END Loan_Cycle2plusFlag_9MonthBack

			       , CASE WHEN ProductRealEstate_Cycle1_12MonthBack > 0 THEN 1 ELSE 0 END RealEstate_Cycle1Flag_12MonthBack
				   , CASE WHEN ProductRealEstate_Cycle2_12MonthBack > 0 THEN 1 ELSE 0 END RealEstate_Cycle2Flag_12MonthBack
				   , CASE WHEN ProductRealEstate_Cycle2plus_12MonthBack > 0 THEN 1 ELSE 0 END RealEstate_Cycle2plusFlag_12MonthBack
			       , CASE WHEN ProductSecuredLoan_Cycle1_12MonthBack > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle1Flag_12MonthBack
				   , CASE WHEN ProductSecuredLoan_Cycle2_12MonthBack > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle2Flag_12MonthBack
				   , CASE WHEN ProductSecuredLoan_Cycle2plus_12MonthBack > 0 THEN 1 ELSE 0 END SecuredLoan_Cycle2plusFlag_12MonthBack
			       , CASE WHEN ProductUnsecuredLoan_Cycle1_12MonthBack > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle1Flag_12MonthBack
				   , CASE WHEN ProductUnsecuredLoan_Cycle2_12MonthBack > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle2Flag_12MonthBack
				   , CASE WHEN ProductUnsecuredLoan_Cycle2plus_12MonthBack > 0 THEN 1 ELSE 0 END UnsecuredLoan_Cycle2plusFlag_12MonthBack
			       , CASE WHEN ProductVehicleLoan_Cycle1_12MonthBack > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle1Flag_12MonthBack
				   , CASE WHEN ProductVehicleLoan_Cycle2_12MonthBack > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle2Flag_12MonthBack
				   , CASE WHEN ProductVehicleLoan_Cycle2plus_12MonthBack > 0 THEN 1 ELSE 0 END VehicleLoan_Cycle2plusFlag_12MonthBack
			       , CASE WHEN ProductLoan_Cycle1_12MonthBack > 0 THEN 1 ELSE 0 END Loan_Cycle1Flag_12MonthBack
				   , CASE WHEN ProductLoan_Cycle2_12MonthBack > 0 THEN 1 ELSE 0 END Loan_Cycle2Flag_12MonthBack
				   , CASE WHEN ProductLoan_Cycle2plus_12MonthBack > 0 THEN 1 ELSE 0 END Loan_Cycle2plusFlag_12MonthBack
             INTO #DELQ_MASTER		                
			 FROM
			( SELECT SSN [SSN_DLQ]
			        ,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Staticpool' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductRealEstate_Cycle1_SP 
					,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Staticpool' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductRealEstate_Cycle2_SP 
					,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Staticpool' and LoanDelqDays >=60 then 1 else 0 end) ProductRealEstate_Cycle2plus_SP
			        ,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Staticpool' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductSecuredLoan_Cycle1_SP 
					,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Staticpool' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductSecuredLoan_Cycle2_SP 
					,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Staticpool' and LoanDelqDays >=60 then 1 else 0 end) ProductSecuredLoan_Cycle2plus_SP
			        ,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Staticpool' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductUnsecuredLoan_Cycle1_SP 
					,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Staticpool' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductUnsecuredLoan_Cycle2_SP 
					,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Staticpool' and LoanDelqDays >=60 then 1 else 0 end) ProductUnsecuredLoan_Cycle2plus_SP
			        ,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Staticpool' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductVehicleLoan_Cycle1_SP 
					,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Staticpool' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductVehicleLoan_Cycle2_SP 
					,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Staticpool' and LoanDelqDays >=60 then 1 else 0 end) ProductVehicleLoan_Cycle2plus_SP
			        ,SUM( CASE WHEN  Quarters = 'Staticpool' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductLoan_Cycle1_SP 
					,SUM( CASE WHEN  Quarters = 'Staticpool' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductLoan_Cycle2_SP 
					,SUM( CASE WHEN  Quarters = 'Staticpool' and LoanDelqDays >=60 then 1 else 0 end) ProductLoan_Cycle2plus_SP

			        ,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND MonthFlag = '3MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductRealEstate_Cycle1_3MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND MonthFlag = '3MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductRealEstate_Cycle2_3MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND MonthFlag = '3MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductRealEstate_Cycle2plus_3MonthBack
			        ,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND MonthFlag = '3MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductSecuredLoan_Cycle1_3MonthBack 
					,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND MonthFlag = '3MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductSecuredLoan_Cycle2_3MonthBack 
					,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND MonthFlag = '3MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductSecuredLoan_Cycle2plus_3MonthBack
			        ,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND MonthFlag = '3MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductUnsecuredLoan_Cycle1_3MonthBack 
					,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND MonthFlag = '3MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductUnsecuredLoan_Cycle2_3MonthBack 
					,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND MonthFlag = '3MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductUnsecuredLoan_Cycle2plus_3MonthBack
			        ,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND MonthFlag = '3MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductVehicleLoan_Cycle1_3MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND MonthFlag = '3MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductVehicleLoan_Cycle2_3MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND MonthFlag = '3MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductVehicleLoan_Cycle2plus_3MonthBack
			        ,SUM( CASE WHEN  MonthFlag = '3MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductLoan_Cycle1_3MonthBack 
					,SUM( CASE WHEN  MonthFlag = '3MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductLoan_Cycle2_3MonthBack 
					,SUM( CASE WHEN  MonthFlag = '3MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductLoan_Cycle2plus_3MonthBack

			        ,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND MonthFlag = '6MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductRealEstate_Cycle1_6MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND MonthFlag = '6MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductRealEstate_Cycle2_6MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND MonthFlag = '6MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductRealEstate_Cycle2plus_6MonthBack
			        ,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND MonthFlag = '6MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductSecuredLoan_Cycle1_6MonthBack 
					,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND MonthFlag = '6MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductSecuredLoan_Cycle2_6MonthBack 
					,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND MonthFlag = '6MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductSecuredLoan_Cycle2plus_6MonthBack
			        ,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND MonthFlag = '6MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductUnsecuredLoan_Cycle1_6MonthBack 
					,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND MonthFlag = '6MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductUnsecuredLoan_Cycle2_6MonthBack 
					,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND MonthFlag = '6MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductUnsecuredLoan_Cycle2plus_6MonthBack
			        ,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND MonthFlag = '6MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductVehicleLoan_Cycle1_6MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND MonthFlag = '6MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductVehicleLoan_Cycle2_6MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND MonthFlag = '6MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductVehicleLoan_Cycle2plus_6MonthBack
			        ,SUM( CASE WHEN  MonthFlag = '6MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductLoan_Cycle1_6MonthBack 
					,SUM( CASE WHEN  MonthFlag = '6MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductLoan_Cycle2_6MonthBack 
					,SUM( CASE WHEN  MonthFlag = '6MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductLoan_Cycle2plus_6MonthBack

			        ,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND MonthFlag = '9MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductRealEstate_Cycle1_9MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND MonthFlag = '9MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductRealEstate_Cycle2_9MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND MonthFlag = '9MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductRealEstate_Cycle2plus_9MonthBack
			        ,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND MonthFlag = '9MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductSecuredLoan_Cycle1_9MonthBack 
					,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND MonthFlag = '9MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductSecuredLoan_Cycle2_9MonthBack 
					,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND MonthFlag = '9MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductSecuredLoan_Cycle2plus_9MonthBack
			        ,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND MonthFlag = '9MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductUnsecuredLoan_Cycle1_9MonthBack 
					,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND MonthFlag = '9MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductUnsecuredLoan_Cycle2_9MonthBack 
					,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND MonthFlag = '9MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductUnsecuredLoan_Cycle2plus_9MonthBack
			        ,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND MonthFlag = '9MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductVehicleLoan_Cycle1_9MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND MonthFlag = '9MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductVehicleLoan_Cycle2_9MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND MonthFlag = '9MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductVehicleLoan_Cycle2plus_9MonthBack
			        ,SUM( CASE WHEN  MonthFlag = '9MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductLoan_Cycle1_9MonthBack 
					,SUM( CASE WHEN  MonthFlag = '9MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductLoan_Cycle2_9MonthBack 
					,SUM( CASE WHEN  MonthFlag = '9MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductLoan_Cycle2plus_9MonthBack

			        ,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND MonthFlag = '12MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductRealEstate_Cycle1_12MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND MonthFlag = '12MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductRealEstate_Cycle2_12MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND MonthFlag = '12MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductRealEstate_Cycle2plus_12MonthBack
			        ,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND MonthFlag = '12MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductSecuredLoan_Cycle1_12MonthBack 
					,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND MonthFlag = '12MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductSecuredLoan_Cycle2_12MonthBack 
					,SUM( CASE WHEN Product_Flag = 'SecuredLoan' AND MonthFlag = '12MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductSecuredLoan_Cycle2plus_12MonthBack
			        ,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND MonthFlag = '12MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductUnsecuredLoan_Cycle1_12MonthBack 
					,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND MonthFlag = '12MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductUnsecuredLoan_Cycle2_12MonthBack 
					,SUM( CASE WHEN Product_Flag = 'UnsecuredLoan' AND MonthFlag = '12MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductUnsecuredLoan_Cycle2plus_12MonthBack
			        ,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND MonthFlag = '12MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductVehicleLoan_Cycle1_12MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND MonthFlag = '12MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductVehicleLoan_Cycle2_12MonthBack 
					,SUM( CASE WHEN Product_Flag = 'Vehicleloan' AND MonthFlag = '12MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductVehicleLoan_Cycle2plus_12MonthBack
			        ,SUM( CASE WHEN  MonthFlag = '12MonthBack' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductLoan_Cycle1_12MonthBack 
					,SUM( CASE WHEN  MonthFlag = '12MonthBack' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductLoan_Cycle2_12MonthBack 
					,SUM( CASE WHEN  MonthFlag = '12MonthBack' and LoanDelqDays >=60 then 1 else 0 end) ProductLoan_Cycle2plus_12MonthBack
			  --      ,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Staticpool' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_CommercialLoan_SP] 
				 --   ,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q1' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_CommercialLoan_Q1] 
					--,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND Quarters = 'Q2' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_CommercialLoan_Q2] 	
					--,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND HalfYearly = 'H1' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_CommercialLoan_H1] 
					--,COUNT(Distinct CASE WHEN Product_Flag = 'Commercial_loan' AND HalfYearly = 'H2' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_CommercialLoan_H2]	
					--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Staticpool' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_RealEstate_SP] 
				 --   ,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q1' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_RealEstate_Q1] 
					--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Q2' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_RealEstate_Q2]	
					--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND HalfYearly = 'H1' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_RealEstate_H1] 
					--,COUNT(Distinct CASE WHEN Product_Flag = 'Real_Estate_loan' AND HalfYearly = 'H2' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_RealEstate_H2]
			  --      ,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Staticpool' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_SecuredLoan_SP] 
				 --   ,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q1' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_SecuredLoan_Q1] 
					--,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND Quarters = 'Q2' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_SecuredLoan_Q2]	
					--,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND HalfYearly = 'H1' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_SecuredLoan_H1] 
					--,COUNT(Distinct CASE WHEN Product_Flag = 'SecuredLoan' AND HalfYearly = 'H2' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_SecuredLoan_H2]
			  --      ,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Staticpool' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_UnsecuredLoan_SP] 
				 --   ,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q1' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_UnsecuredLoan_Q1] 
					--,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND Quarters = 'Q2' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_UnsecuredLoan_Q2] 	
					--,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND HalfYearly = 'H1' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_UnsecuredLoan_H1] 
					--,COUNT(Distinct CASE WHEN Product_Flag = 'UnsecuredLoan' AND HalfYearly = 'H2' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_UnsecuredLoan_H2]
			  --      ,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Staticpool' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Vehicleloan_SP] 
				 --   ,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q1' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Vehicleloan_Q1] 
					--,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND Quarters = 'Q2' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Vehicleloan_Q2] 	
					--,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND HalfYearly = 'H1' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Vehicleloan_H1] 
					--,COUNT(Distinct CASE WHEN Product_Flag = 'Vehicleloan' AND HalfYearly = 'H2' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Vehicleloan_H2]
			  --      ,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Staticpool' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Others_SP] 
				 --   ,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q1' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Others_Q1] 
					--,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND Quarters = 'Q2' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Others_Q2]	
					--,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND HalfYearly = 'H1' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Others_H1] 
					--,COUNT(Distinct CASE WHEN Product_Flag = 'Others' AND HalfYearly = 'H2' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Others_H2]
			  --      ,COUNT(Distinct CASE WHEN  Quarters = 'Staticpool' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Loan_SP] 
				 --   ,COUNT(Distinct CASE WHEN  Quarters = 'Q1' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Loan_Q1] 
					--,COUNT(Distinct CASE WHEN  Quarters = 'Q2' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Loan_Q2]
					--,COUNT(Distinct CASE WHEN  HalfYearly = 'H1' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Loan_H1] 
					--,COUNT(Distinct CASE WHEN  HalfYearly = 'H2' AND LoanDelqDays > 0 THEN UNID END) as [COUNT_DELQ_Loan_H2] 	
					
				--,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q1' THEN LoanDelqDays END) [Max_DelinquencyDays_CommercialLoan_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and Quarters = 'Q2' THEN LoanDelqDays END) [Max_DelinquencyDays_CommercialLoan_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H1' THEN LoanDelqDays END) [Max_DelinquencyDays_CommercialLoan_H1]
				--,MAX(CASE WHEN Product_Flag = 'Commercial_loan' and HalfYearly = 'H2' THEN LoanDelqDays END) [Max_DelinquencyDays_CommercialLoan_H2]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q1' THEN LoanDelqDays END) [Max_DelinquencyDays_RealEstate_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and Quarters = 'Q2' THEN LoanDelqDays END) [Max_DelinquencyDays_RealEstate_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H1' THEN LoanDelqDays END) [Max_DelinquencyDays_RealEstate_H1]
				--,MAX(CASE WHEN Product_Flag = 'Real_Estate_loan' and HalfYearly = 'H2' THEN LoanDelqDays END) [Max_DelinquencyDays_RealEstate_H2]
				--,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q1' THEN LoanDelqDays END) [Max_DelinquencyDays_SecuredLoan_Q1]
				--,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and Quarters = 'Q2' THEN LoanDelqDays END) [Max_DelinquencyDays_SecuredLoan_Q2]
				--,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H1' THEN LoanDelqDays END) [Max_DelinquencyDays_SecuredLoan_H1]
				--,MAX(CASE WHEN Product_Flag = 'SecuredLoan' and HalfYearly = 'H2' THEN LoanDelqDays END) [Max_DelinquencyDays_SecuredLoan_H2]
				--,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q1' THEN LoanDelqDays END) [Max_DelinquencyDays_UnsecuredLoan_Q1]
				--,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and Quarters = 'Q2' THEN LoanDelqDays END) [Max_DelinquencyDays_UnsecuredLoan_Q2]
				--,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H1' THEN LoanDelqDays END) [Max_DelinquencyDays_UnsecuredLoan_H1]
				--,MAX(CASE WHEN Product_Flag = 'UnsecuredLoan' and HalfYearly = 'H2' THEN LoanDelqDays END) [Max_DelinquencyDays_UnsecuredLoan_H2]
				--,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q1' THEN LoanDelqDays END) [Max_DelinquencyDays_Vehicleloan_Q1]
				--,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and Quarters = 'Q2' THEN LoanDelqDays END) [Max_DelinquencyDays_Vehicleloan_Q2]
				--,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H1' THEN LoanDelqDays END) [Max_DelinquencyDays_Vehicleloan_H1]
				--,MAX(CASE WHEN Product_Flag = 'Vehicleloan' and HalfYearly = 'H2' THEN LoanDelqDays END) [Max_DelinquencyDays_Vehicleloan_H2]
				--,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q3' THEN LoanDelqDays END) [Max_DelinquencyDays_Others_Q3]
				--,MAX(CASE WHEN Product_Flag = 'Others' and Quarters = 'Q4' THEN LoanDelqDays END) [Max_DelinquencyDays_Others_Q4]
				--,MAX(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H1' THEN LoanDelqDays END) [Max_DelinquencyDays_Others_H1]
				--,MAX(CASE WHEN Product_Flag = 'Others' and HalfYearly = 'H2' THEN LoanDelqDays END) [Max_DelinquencyDays_Others_H2]
				--,MAX(CASE WHEN Quarters = 'Q1' THEN LoanDelqDays END) [Max_DelinquencyDays_Loan_Q1]
				--,MAX(CASE WHEN Quarters = 'Q2' THEN LoanDelqDays END) [Max_DelinquencyDays_Loan_Q2]
				--,MAX(CASE WHEN HalfYearly = 'H1' THEN LoanDelqDays END) [Max_DelinquencyDays_Loan_H1]
				--,MAX(CASE WHEN HalfYearly = 'H2' THEN LoanDelqDays END) [Max_DelinquencyDays_Loan_H2]
			  --INTO #DELQ_MASTER		                
			  FROM #DELQ_INFO
			  GROUP BY SSN) P

/*********************************************************************** Harland Delinquency **************************************************************************/

		drop table if exists #static_harland

		 SELECT * 
					   into #static_harland 
					   from ( SELECT datefromparts(left(B.ProcessDate,4),right(left(B.ProcessDate,6),2),right(B.ProcessDate,2)) [Process date],B.USERCHAR1,SSN 
					         from (SELECT ProcessDate,USERCHAR1,PARENTACCOUNT FROM ARCUSYM000.dbo.TRACKING) B 
							        LEFT JOIN (SELECT DISTINCT PARENTACCOUNT,SSN FROM  ARCUSYM000..NAME) S
					    on B.PARENTACCOUNT=S.PARENTACCOUNT) f
						where [Process date] between eomonth(dateadd(month,-12,@staticpooldate)) and @staticpooldate 



	   drop table if exists #DELQ_harland

		Select distinct SSN [SSN_HARLAND]
		                ,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 1 and datediff(d, duedate, eomonth(cutoffdate)) < 30 and MonthFlag = 'SP' then 1 else 0  end)  [Cycle1_HarlandProduct_SP]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 30 and datediff(d, duedate, eomonth(cutoffdate)) < 60 and MonthFlag = 'SP' then 1 else 0  end) [Cycle2_HarlandProduct_SP]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 60 and MonthFlag = 'SP'  then 1 else 0 end) [Cycle2plus_HarlandProduct_SP]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 180 and MonthFlag = 'SP' then 1 else 0  end) [chargeoffflag_HarlandProduct_SP]
		                ,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 1 and datediff(d, duedate, eomonth(cutoffdate)) < 30 and MonthFlag = '12MonthBack' then 1 else 0  end)  [Cycle1_HarlandProduct_12MonthBack]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 30 and datediff(d, duedate, eomonth(cutoffdate)) < 60 and MonthFlag = '12MonthBack' then 1 else 0  end) [Cycle2_HarlandProduct_12MonthBack]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 60 and MonthFlag = '12MonthBack'  then 1 else 0 end) [Cycle2plus_HarlandProduct_12MonthBack]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 180 and MonthFlag = '12MonthBack' then 1 else 0  end) [chargeoffflag_HarlandProduct_12MonthBack]
		                ,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 1 and datediff(d, duedate, eomonth(cutoffdate)) < 30 and MonthFlag = '9MonthBack' then 1 else 0  end)  [Cycle1_HarlandProduct_9MonthBack]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 30 and datediff(d, duedate, eomonth(cutoffdate)) < 60 and MonthFlag = '9MonthBack' then 1 else 0  end) [Cycle2_HarlandProduct_9MonthBack]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 60 and MonthFlag = '9MonthBack'  then 1 else 0 end) [Cycle2plus_HarlandProduct_9MonthBack]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 180 and MonthFlag = '9MonthBack' then 1 else 0  end) [chargeoffflag_HarlandProduct_9MonthBack]
		                ,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 1 and datediff(d, duedate, eomonth(cutoffdate)) < 30 and MonthFlag = '6MonthBack' then 1 else 0  end)  [Cycle1_HarlandProduct_6MonthBack]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 30 and datediff(d, duedate, eomonth(cutoffdate)) < 60 and MonthFlag = '6MonthBack' then 1 else 0  end) [Cycle2_HarlandProduct_6MonthBack]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 60 and MonthFlag = '6MonthBack'  then 1 else 0 end) [Cycle2plus_HarlandProduct_6MonthBack]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 180 and MonthFlag = '6MonthBack' then 1 else 0  end) [chargeoffflag_HarlandProduct_6MonthBack]
		                ,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 1 and datediff(d, duedate, eomonth(cutoffdate)) < 30 and MonthFlag = '3MonthBack' then 1 else 0  end)  [Cycle1_HarlandProduct_3MonthBack]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 30 and datediff(d, duedate, eomonth(cutoffdate)) < 60 and MonthFlag = '3MonthBack' then 1 else 0  end) [Cycle2_HarlandProduct_3MonthBack]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 60 and MonthFlag = '3MonthBack'  then 1 else 0 end) [Cycle2plus_HarlandProduct_3MonthBack]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 180 and MonthFlag = '3MonthBack' then 1 else 0  end) [chargeoffflag_HarlandProduct_3MonthBack]
		into #DELQ_harland
		 from (
							SELECT SSN,h.loanid,InvestorID MortgageDescription,CutoffDate,h.DueDate
							,case when CutoffDate in (EOMONTH(DATEADD(month,-12,@staticpooldate))) then '12MonthBack'
						          when CutoffDate in (EOMONTH(DATEADD(month,-9,@staticpooldate ))) then '9MonthBack'
 								  when CutoffDate in (EOMONTH(DATEADD(month,-6,@staticpooldate ))) then '6MonthBack'
								  when CutoffDate in (EOMONTH(DATEADD(month,-3,@staticpooldate))) then '3MonthBack' 
								  when CutoffDate = @staticpooldate then 'SP' end MonthFlag

						FROM [UICCU].[dbo].[HarlandLoanCutoff] h
						left join ae_edw.dbo.f_mortgage f
						 on f.mortgageid = h.loanid and month(reportmonth) = month(cutoffdate)
						   and year(reportmonth) = year(cutoffdate)
                        left join 
					     #static_harland V
				       on h.LoanID=V.USERCHAR1 and h.CutoffDate = V.[Process date]
						WHERE loanprincipalbal > 0 AND RegPrincipalColl != investorprinbal AND (investorid LIKE '%bal' or investorid LIKE '%fix%' or investorid LIKE '%arm' or
													investorid LIKE 'E-10YR' or investorid LIKE 'E-WORK' or InvestorID like '%Equity%' or InvestorID like '%TDR%' or
													InvestorID = 'F-ARM' or InvestorID = 'FAB-HH' )
								   and investorprinbal is not null
								   and datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and RecordType <> 2
					) T 
					  where cutoffdate between eomonth(dateadd(month,-12,@staticpooldate)) and @staticpooldate 
				   group by SSN

--SELECT * FROM #DELQ_harland

SELECT * FROM #DELQ_harland

			  DROP TABLE IF EXISTS #loan_product_summary
			 
			 SELECT A.*, B.*,C.*,D.*
			  into #loan_product_summary
			   FROM #loan_product_holdings A
			  LEFT JOIN
			  #LOAN_TRANSACTION_derived_vars B
			  ON A.SSN001 = B.SSN002
			  LEFT JOIN 
			  #DELQ_MASTER C
			  ON A.SSN001 = C.SSN_DLQ
			  LEFT JOIN #DELQ_harland D
			  ON A.SSN001 = D.SSN_HARLAND

			  --SELECT SSN_L, COUNT(*) C FROM #loan_product_summary group by SSN_L
			  --SELECT * FROM #loan_product_summary where SSN_L = '584793617'
			 --DROP TABLE IF EXISTS #updated_loan_product_summary
			 
			 --SELECT CASE WHEN A.SSN001 = B.SSN002 THEN A.SSN001
			 --            WHEN A.SSN001 is null then B.SSN002
			 --		       WHEN B.SSN002 is null then A.SSN001 END [SSN_LOAN]
			 --,A.*,B.*
			 -- into #updated_loan_product_summary
			 --  FROM #loan_product_holdings A
			 -- FULL OUTER JOIN
			 -- #LOAN_TRANSACTION_MASTER B
			 -- ON A.SSN001 = B.SSN002

			  --SELECT DISTINCT SSN002 FROM #LOAN_TRANSACTION_MASTER where SSN002 not in (SELECT DISTINCT SSN001 from #loan_product_holdings) --3239
			   --SELECT DISTINCT SSN001 from #loan_product_holdings where SSN001 not in (SELECT DISTINCT SSN002 FROM #LOAN_TRANSACTION_MASTER) --27399


------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Credit Card ***\\\-------------------------------------------------------------------
			

			 
  drop table if exists #CC_Members_Static
  

	  select distinct [Social Security Number] 
	  into #CC_Members_Static
	  from TMGData.dbo.cardholder 
	  where Active_Flag=1 and ([External Status Code]='' or [Internal Status Code] in ('N',''))
	  and extract_datepart=left(convert(varchar,@staticpooldate,112),6)
	  --and datediff(MONTH,[Date First Active New],@staticpooldate) >= 6   
	   

			


		 drop table if exists #CC_data	
		
		
		select * 
		into #CC_data
		from 
		(
		SELECT  [Durable_Key]
	  ,case when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-12,@staticpooldate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-11,@staticpooldate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-10,@staticpooldate)),112),6)) then 'Q4'
		    when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-9,@staticpooldate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-8,@staticpooldate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-7,@staticpooldate),112)),6)) then 'Q3'
		    when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-6,@staticpooldate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-5,@staticpooldate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-4,@staticpooldate),112)),6)) then 'Q2'
		    when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-3,@staticpooldate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-2,@staticpooldate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-1,@staticpooldate),112)),6)) then 'Q1'
		    when extract_datepart in (left(convert(varchar,@staticpooldate,112),6)) then 'Staticpool' end Quarters
		    ,case when extract_datepart in ((left(convert(varchar,EOMONTH(DATEADD(month,-12,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-11,@staticpooldate),112)),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-10,@staticpooldate)),112),6))
			                               ,(left(convert(varchar,EOMONTH(DATEADD(month,-9,@staticpooldate)),112),6)) ,(left(convert(varchar,EOMONTH(DATEADD(month,-8,@staticpooldate),112)),6)) ,(left(convert(varchar,EOMONTH(DATEADD(month,-7,@staticpooldate)),112),6))) then 'H2'
 		    	  when extract_datepart in ((left(convert(varchar,EOMONTH(DATEADD(month,-6,@staticpooldate)),112),6)) ,(left(convert(varchar,EOMONTH(DATEADD(month,-5,@staticpooldate),112)),6)) ,(left(convert(varchar,EOMONTH(DATEADD(month,-4,@staticpooldate)),112),6))
				                           ,(left(convert(varchar,EOMONTH(DATEADD(month,-3,@staticpooldate)),112),6)) ,(left(convert(varchar,EOMONTH(DATEADD(month,-2,@staticpooldate),112)),6)) ,(left(convert(varchar,EOMONTH(DATEADD(month,-1,@staticpooldate)),112),6))) then 'H1'
		     end HalfYearly			

		,case when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-12,@staticpooldate),112)),6)) then '12MonthBack'
		      when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-9,@staticpooldate),112)),6)) then '9MonthBack'
		      when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-6,@staticpooldate),112)),6)) then '6MonthBack'
		      when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-3,@staticpooldate),112)),6)) then '3MonthBack' end MonthFlag


       ,[Social Security Number]
      ,[Credit Limit]
      ,[Extract Date]
       ,[AGE]
      ,[Account System Entry Date]
      ,[Card Account Debit Activity Code]
      ,[Last Statement Payment Count]
      ,[Last Statement Payment Amount]
      ,[Last Statement Sale Amount]
      ,[Last Statement Cash Amount]
      ,[Last Statement Return Amount]
      ,[Last Statment Sale Count]
      ,[Last Statement Cash Advance Count]
      ,[Last Statement Return Count]
      ,[Last Statement External Fee Amount]
      ,[Last Statement Credit Life Change Amount]
      ,[Last Statement Charge Late Amount]
      ,[Last Statement Charge Cash Amount]
      ,[Last Statement Charge Overlimit Amount]
      ,[Last Statement Charge Sale Amount]
      ,[Last Statement Merchandise Average Daily Balance Amount]
      ,[Last Statement Cash Average Daily Balance Amount]
      ,[Last Statement Average Daily Balance Amount]
      ,[Calc Norm Cash Annual Rate]
      ,[Calc Norm Mrch Annual Rate]
      ,[Charge-Off Amount]
      ,[Card Account Charge-Off Date]
      ,[Card Description]
      ,[Card Account Delinquent Day Account]
      ,[Total Amount Account Delinquency]
      ,[Last Statement Cash Interest Amount]
      ,[Accumulated Merchandise Interest Amount]
      ,[Last Statement Balance Amount]
	  ,CASE WHEN [Credit Limit] in (0,NULL) THEN [Last Statement Balance Amount] ELSE ([Last Statement Balance Amount]/[Credit Limit]) END [UTILIZATION_RATE_CC]
      ,[Last Statement Revolving Merchandise Amount]
      ,[extract_datepart]
      ,[Extract_ACCOUNT_OPEN_DATE]
      ,[spend]
      ,[Protected_Balance]
      ,[Promo_Balance]
      ,[Protected_Current_Interest]
      ,[Promo_Current_Interest]
      ,[RevolvingBalance]
      ,[Closed_account_flag]
      ,[mob]
      ,[ChargeoffAmount_final]
      ,[ChargeOff_Extract_DatePart]
	   ,TRIPFLAG
  FROM TMGData.dbo.cardholder 	-- Changed 042222
  where [Social Security Number] in (select [Social Security Number] from #CC_Members_Static)
  and Active_Flag=1
   ) a
    where  quarters is not null 
  ----and mob>=12  ---commented by nikita on 05/10/2022

--- Drift of CC data

		 Drop table if exists #Credit_Card_data
		select 
		SSN_CC
		,CASE WHEN PRODUCT_CC_STATICPOOL > 0 THEN 1 ELSE 0 END [CreditCard_StaticpoolFlag]
		,CASE WHEN PRODUCT_CC_Q1 > 0 THEN 1 ELSE 0 END [CreditCard_Q1Flag]
		,PRODUCT_CC_Q1
		,CASE WHEN PRODUCT_CC_Q1 IS NULL AND PRODUCT_CC_Q2 IS NULL THEN PRODUCT_CC_Q1 ELSE (ISNULL(PRODUCT_CC_Q1,0)-ISNULL(PRODUCT_CC_Q2,0)) END [DFT_PRODUCT_CC_Q1_Q2]

		,[Last Statement Payment Count_CC_Q1]
		,CASE WHEN ([Last Statement Payment Count_CC_Q1] IS NULL AND [Last Statement Payment Count_CC_Q2] IS  NULL ) THEN [Last Statement Payment Count_CC_Q1] else (ISNULL([Last Statement Payment Count_CC_Q1],0)-ISNULL([Last Statement Payment Count_CC_Q2],0)) end [DFT_Last Statement Payment Count_CC_Q1_Q2]

		,[Last Statement Payment Amount_CC_Q1]
		,CASE WHEN ([Last Statement Payment Amount_CC_Q1] IS NULL AND [Last Statement Payment Amount_CC_Q2] IS  NULL ) THEN [Last Statement Payment Amount_CC_Q1] else (ISNULL([Last Statement Payment Amount_CC_Q1],0)-ISNULL([Last Statement Payment Amount_CC_Q2],0)) end [DFT_Last Statement Payment Amount_CC_Q1_Q2]

		,[Last Statement Sale Amount_CC_Q1]
		,CASE WHEN ([Last Statement Sale Amount_CC_Q1] IS NULL AND [Last Statement Sale Amount_CC_Q2] IS  NULL ) THEN [Last Statement Sale Amount_CC_Q1] else (ISNULL([Last Statement Sale Amount_CC_Q1],0)-ISNULL([Last Statement Sale Amount_CC_Q2],0)) end [DFT_Last Statement Sale Amount_CC_Q1_Q2]

		,[Last Statement Cash Amount_CC_Q1]
		,CASE WHEN ([Last Statement Cash Amount_CC_Q1] IS NULL AND [Last Statement Cash Amount_CC_Q2] IS  NULL ) THEN [Last Statement Cash Amount_CC_Q1] else (ISNULL([Last Statement Cash Amount_CC_Q1],0)-ISNULL([Last Statement Cash Amount_CC_Q2],0)) end [DFT_Last Statement Cash Amount_CC_Q1_Q2]

		,[Last Statement Return Amount_CC_Q1]
		,CASE WHEN ([Last Statement Return Amount_CC_Q1] IS NULL AND [Last Statement Return Amount_CC_Q2] IS  NULL ) THEN [Last Statement Return Amount_CC_Q1] else (ISNULL([Last Statement Return Amount_CC_Q1],0)-ISNULL([Last Statement Return Amount_CC_Q2],0)) end [DFT_Last Statement Return Amount_CC_Q1_Q2]

		,[Last Statement Sale Count_CC_Q1]
		,CASE WHEN ([Last Statement Sale Count_CC_Q1] IS NULL AND [Last Statement Sale Count_CC_Q2] IS  NULL ) THEN [Last Statement Sale Count_CC_Q1] else (ISNULL([Last Statement Sale Count_CC_Q1],0)-ISNULL([Last Statement Sale Count_CC_Q2],0)) end [DFT_Last Statement Sale Count_CC_Q1_Q2]

		,[Last Statement Cash Advance Count_CC_Q1]
		,CASE WHEN ([Last Statement Cash Advance Count_CC_Q1] IS NULL AND [Last Statement Cash Advance Count_CC_Q2] IS  NULL ) THEN [Last Statement Cash Advance Count_CC_Q1] else (ISNULL([Last Statement Cash Advance Count_CC_Q1],0)-ISNULL([Last Statement Cash Advance Count_CC_Q2],0)) end [DFT_Last Statement Cash Advance Count_CC_Q1_Q2]

		,[Last Statement Return Count_CC_Q1]
		,CASE WHEN ([Last Statement Return Count_CC_Q1] IS NULL AND [Last Statement Return Count_CC_Q2] IS  NULL ) THEN [Last Statement Return Count_CC_Q1] else  (ISNULL([Last Statement Return Count_CC_Q1],0)-ISNULL([Last Statement Return Count_CC_Q2],0)) end [DFT_Last Statement Return Count_CC_Q1_Q2]

		,[Last Statement External Fee Amount_CC_Q1]
		,CASE WHEN ([Last Statement External Fee Amount_CC_Q1] IS NULL AND [Last Statement External Fee Amount_CC_Q2] IS  NULL ) THEN [Last Statement External Fee Amount_CC_Q1] else (ISNULL([Last Statement External Fee Amount_CC_Q1],0)-ISNULL([Last Statement External Fee Amount_CC_Q2],0)) end [DFT_Last Statement External Fee Amount_CC_Q1_Q2]

		,[Last Statement Credit Life Change Amount_CC_Q1]
		,CASE WHEN ([Last Statement Credit Life Change Amount_CC_Q1] IS NULL AND [Last Statement Credit Life Change Amount_CC_Q2] IS  NULL ) THEN [Last Statement Credit Life Change Amount_CC_Q1] else (ISNULL([Last Statement Credit Life Change Amount_CC_Q1],0)-ISNULL([Last Statement Credit Life Change Amount_CC_Q2],0)) end [DFT_Last Statement Credit Life Change Amount_CC_Q1_Q2]

		,[Last Statement Charge Late Amount_CC_Q1]
		,CASE WHEN ([Last Statement Charge Late Amount_CC_Q1] IS NULL AND [Last Statement Charge Late Amount_CC_Q2] IS  NULL ) THEN [Last Statement Charge Late Amount_CC_Q2] else (ISNULL([Last Statement Charge Late Amount_CC_Q1],0)-ISNULL([Last Statement Charge Late Amount_CC_Q2],0)) end [DFT_Last Statement Charge Late Amount_CC_Q1_Q2]

		,[Last Statement Charge Cash Amount_CC_Q1]
		,CASE WHEN ([Last Statement Charge Cash Amount_CC_Q1] IS NULL AND [Last Statement Charge Cash Amount_CC_Q2] IS  NULL ) THEN [Last Statement Charge Cash Amount_CC_Q1] else (ISNULL([Last Statement Charge Cash Amount_CC_Q1],0)-ISNULL([Last Statement Charge Cash Amount_CC_Q2],0)) end [DFT_Last Statement Charge Cash Amount_CC_Q1_Q2]

		,[Last Statement Charge Overlimit Amount_CC_Q1]
		,CASE WHEN ([Last Statement Charge Overlimit Amount_CC_Q1] IS NULL AND [Last Statement Charge Overlimit Amount_CC_Q2] IS  NULL ) THEN [Last Statement Charge Overlimit Amount_CC_Q1] else (ISNULL([Last Statement Charge Overlimit Amount_CC_Q1],0)-ISNULL([Last Statement Charge Overlimit Amount_CC_Q2],0)) end [DFT_Last Statement Charge Overlimit Amount_CC_Q1_Q2]

		,[Last Statement Charge Sale Amount_CC_Q1]
		,CASE WHEN ([Last Statement Charge Sale Amount_CC_Q1] IS NULL AND [Last Statement Charge Sale Amount_CC_Q2] IS  NULL ) THEN [Last Statement Charge Sale Amount_CC_Q1] else (ISNULL([Last Statement Charge Sale Amount_CC_Q1],0) - ISNULL([Last Statement Charge Sale Amount_CC_Q2],0)) end [DFT_Last Statement Charge Sale Amount_CC_Q1_Q2]

		,[Last Statement Merchandise Average Daily Balance Amount_CC_Q1]
		,CASE WHEN ([Last Statement Merchandise Average Daily Balance Amount_CC_Q1] IS NULL AND [Last Statement Merchandise Average Daily Balance Amount_CC_Q2] IS  NULL ) THEN [Last Statement Merchandise Average Daily Balance Amount_CC_Q1] else (ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_Q1],0) - ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_Q2],0)) end [DFT_Last Statement Merchandise Average Daily Balance Amount_CC_Q1_Q2]

		,[Last Statement Cash Average Daily Balance Amount_CC_Q1]
		,CASE WHEN ([Last Statement Cash Average Daily Balance Amount_CC_Q1] IS NULL AND [Last Statement Cash Average Daily Balance Amount_CC_Q2] IS  NULL ) THEN [Last Statement Cash Average Daily Balance Amount_CC_Q1] else (ISNULL([Last Statement Cash Average Daily Balance Amount_CC_Q1],0)- ISNULL([Last Statement Cash Average Daily Balance Amount_CC_Q2],0)) end [DFT_Last Statement Cash Average Daily Balance Amount_CC_Q1_Q2]

		,[Last Statement Average Daily Balance Amount_CC_Q1]
		,CASE WHEN ([Last Statement Average Daily Balance Amount_CC_Q1] IS NULL AND [Last Statement Average Daily Balance Amount_CC_Q2] IS  NULL ) THEN [Last Statement Average Daily Balance Amount_CC_Q1] else (ISNULL([Last Statement Average Daily Balance Amount_CC_Q1],0)-ISNULL([Last Statement Average Daily Balance Amount_CC_Q2],0)) end [DFT_Last Statement Average Daily Balance Amount_CC_Q1_Q2]

		,[spend_CC_Q1]
		,CASE WHEN ([spend_CC_Q1] IS NULL AND [spend_CC_Q2] IS  NULL ) THEN [spend_CC_Q1] else (ISNULL(spend_CC_Q1,0)- ISNULL(spend_CC_Q2,0)) end [DFT_spend_CC_Q1_Q2]

		,[Protected_Balance_CC_Q1]
		,CASE WHEN ([Protected_Balance_CC_Q1] IS NULL AND [Protected_Balance_CC_Q2] IS  NULL ) THEN [Protected_Balance_CC_Q1] else (ISNULL([Protected_Balance_CC_Q1],0)-ISNULL([Protected_Balance_CC_Q2],0)) end [DFT_Protected_Balance_CC_Q1_Q2]

		,[Promo_Balance_CC_Q1]
		,CASE WHEN ([Promo_Balance_CC_Q1] IS NULL AND [Promo_Balance_CC_Q2] IS  NULL ) THEN [Promo_Balance_CC_Q1] else (ISNULL([Promo_Balance_CC_Q1],0)-ISNULL([Promo_Balance_CC_Q2],0)) end [DFT_Promo_Balance_CC_Q1_Q2]

		,[Protected_Current_Interest_CC_Q1]
		,CASE WHEN ([Protected_Current_Interest_CC_Q1] IS NULL AND [Protected_Current_Interest_CC_Q2] IS  NULL ) THEN [Protected_Current_Interest_CC_Q1] else (ISNULL([Protected_Current_Interest_CC_Q1],0)- ISNULL([Protected_Current_Interest_CC_Q2],0)) end [DFT_Protected_Current_Interest_CC_Q1_Q2]

		,[Promo_Current_Interest_CC_Q1]
		,CASE WHEN ([Promo_Current_Interest_CC_Q1] IS NULL AND [Promo_Current_Interest_CC_Q2] IS  NULL ) THEN [Promo_Current_Interest_CC_Q1] else (ISNULL([Promo_Current_Interest_CC_Q1],0)- ISNULL([Promo_Current_Interest_CC_Q2],0)) end [DFT_Promo_Current_Interest_CC_Q1_Q2]

		,[RevolvingBalance_CC_Q1]
		,CASE WHEN ([RevolvingBalance_CC_Q1] IS NULL AND [RevolvingBalance_CC_Q2] IS  NULL ) THEN [RevolvingBalance_CC_Q1] else (ISNULL([RevolvingBalance_CC_Q1],0)-ISNULL([RevolvingBalance_CC_Q2],0)) end [DFT_RevolvingBalance_CC_Q1_Q2]

		,[AVG_UTILIZATION_RATE_CC_Q1]
		,CASE WHEN ([AVG_UTILIZATION_RATE_CC_Q1] IS NULL AND [AVG_UTILIZATION_RATE_CC_Q2] IS  NULL ) THEN [AVG_UTILIZATION_RATE_CC_Q1] else (ISNULL(AVG_UTILIZATION_RATE_CC_Q1,0)- ISNULL(AVG_UTILIZATION_RATE_CC_Q2,0)) end [DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2]

		--,PRODUCT_CC_H1
		,CASE WHEN PRODUCT_CC_H1 IS NULL AND PRODUCT_CC_H2 IS NULL THEN PRODUCT_CC_H1 ELSE (ISNULL(PRODUCT_CC_H1,0)-ISNULL(PRODUCT_CC_H2,0)) END [DFT_PRODUCT_CC_H1_H2]

		--,[Last Statement Payment Count_CC_H1]
		,CASE WHEN ([Last Statement Payment Count_CC_H1] IS NULL AND [Last Statement Payment Count_CC_H2] IS  NULL ) THEN [Last Statement Payment Count_CC_H1] else (ISNULL([Last Statement Payment Count_CC_H1],0)-ISNULL([Last Statement Payment Count_CC_H2],0)) end [DFT_Last Statement Payment Count_CC_H1_H2]

		--,[Last Statement Payment Amount_CC_H1]
		,CASE WHEN ([Last Statement Payment Amount_CC_H1] IS NULL AND [Last Statement Payment Amount_CC_H2] IS  NULL ) THEN [Last Statement Payment Amount_CC_H1] else (ISNULL([Last Statement Payment Amount_CC_H1],0)-ISNULL([Last Statement Payment Amount_CC_H2],0)) end [DFT_Last Statement Payment Amount_CC_H1_H2]

		--,[Last Statement Sale Amount_CC_H1]
		,CASE WHEN ([Last Statement Sale Amount_CC_H1] IS NULL AND [Last Statement Sale Amount_CC_H2] IS  NULL ) THEN [Last Statement Sale Amount_CC_H1] else (ISNULL([Last Statement Sale Amount_CC_H1],0)-ISNULL([Last Statement Sale Amount_CC_H2],0)) end [DFT_Last Statement Sale Amount_CC_H1_H2]

		--,[Last Statement Cash Amount_CC_H1]
		,CASE WHEN ([Last Statement Cash Amount_CC_H1] IS NULL AND [Last Statement Cash Amount_CC_H2] IS  NULL ) THEN [Last Statement Cash Amount_CC_H1] else (ISNULL([Last Statement Cash Amount_CC_H1],0)-ISNULL([Last Statement Cash Amount_CC_H2],0)) end [DFT_Last Statement Cash Amount_CC_H1_H2]

		--,[Last Statement Return Amount_CC_H1]
		,CASE WHEN ([Last Statement Return Amount_CC_H1] IS NULL AND [Last Statement Return Amount_CC_H2] IS  NULL ) THEN [Last Statement Return Amount_CC_H1] else (ISNULL([Last Statement Return Amount_CC_H1],0)-ISNULL([Last Statement Return Amount_CC_H2],0)) end [DFT_Last Statement Return Amount_CC_H1_H2]

		--,[Last Statement Sale Count_CC_H1]
		,CASE WHEN ([Last Statement Sale Count_CC_H1] IS NULL AND [Last Statement Sale Count_CC_H2] IS  NULL ) THEN [Last Statement Sale Count_CC_H1] else (ISNULL([Last Statement Sale Count_CC_H1],0)-ISNULL([Last Statement Sale Count_CC_H2],0)) end [DFT_Last Statement Sale Count_CC_H1_H2]

		--,[Last Statement Cash Advance Count_CC_H1]
		,CASE WHEN ([Last Statement Cash Advance Count_CC_H1] IS NULL AND [Last Statement Cash Advance Count_CC_H2] IS  NULL ) THEN [Last Statement Cash Advance Count_CC_H1] else (ISNULL([Last Statement Cash Advance Count_CC_H1],0)-ISNULL([Last Statement Cash Advance Count_CC_H2],0)) end [DFT_Last Statement Cash Advance Count_CC_H1_H2]

		--,[Last Statement Return Count_CC_H1]
		,CASE WHEN ([Last Statement Return Count_CC_H1] IS NULL AND [Last Statement Return Count_CC_H2] IS  NULL ) THEN [Last Statement Return Count_CC_H1] else  (ISNULL([Last Statement Return Count_CC_H1],0)-ISNULL([Last Statement Return Count_CC_H2],0)) end [DFT_Last Statement Return Count_CC_H1_H2]

		--,[Last Statement External Fee Amount_CC_H1]
		,CASE WHEN ([Last Statement External Fee Amount_CC_H1] IS NULL AND [Last Statement External Fee Amount_CC_H2] IS  NULL ) THEN [Last Statement External Fee Amount_CC_H1] else (ISNULL([Last Statement External Fee Amount_CC_H1],0)-ISNULL([Last Statement External Fee Amount_CC_H2],0)) end [DFT_Last Statement External Fee Amount_CC_H1_H2]

		--,[Last Statement Credit Life Change Amount_CC_H1]
		,CASE WHEN ([Last Statement Credit Life Change Amount_CC_H1] IS NULL AND [Last Statement Credit Life Change Amount_CC_H2] IS  NULL ) THEN [Last Statement Credit Life Change Amount_CC_H1] else (ISNULL([Last Statement Credit Life Change Amount_CC_H1],0)-ISNULL([Last Statement Credit Life Change Amount_CC_H2],0)) end [DFT_Last Statement Credit Life Change Amount_CC_H1_H2]

		--,[Last Statement Charge Late Amount_CC_H1]
		,CASE WHEN ([Last Statement Charge Late Amount_CC_H1] IS NULL AND [Last Statement Charge Late Amount_CC_H2] IS  NULL ) THEN [Last Statement Charge Late Amount_CC_H2] else (ISNULL([Last Statement Charge Late Amount_CC_H1],0)-ISNULL([Last Statement Charge Late Amount_CC_H2],0)) end [DFT_Last Statement Charge Late Amount_CC_H1_H2]

		--,[Last Statement Charge Cash Amount_CC_H1]
		,CASE WHEN ([Last Statement Charge Cash Amount_CC_H1] IS NULL AND [Last Statement Charge Cash Amount_CC_H2] IS  NULL ) THEN [Last Statement Charge Cash Amount_CC_H1] else (ISNULL([Last Statement Charge Cash Amount_CC_H1],0)-ISNULL([Last Statement Charge Cash Amount_CC_H2],0)) end [DFT_Last Statement Charge Cash Amount_CC_H1_H2]

		--,[Last Statement Charge Overlimit Amount_CC_H1]
		,CASE WHEN ([Last Statement Charge Overlimit Amount_CC_H1] IS NULL AND [Last Statement Charge Overlimit Amount_CC_H2] IS  NULL ) THEN [Last Statement Charge Overlimit Amount_CC_H1] else (ISNULL([Last Statement Charge Overlimit Amount_CC_H1],0)-ISNULL([Last Statement Charge Overlimit Amount_CC_H2],0)) end [DFT_Last Statement Charge Overlimit Amount_CC_H1_H2]

		--,[Last Statement Charge Sale Amount_CC_H1]
		,CASE WHEN ([Last Statement Charge Sale Amount_CC_H1] IS NULL AND [Last Statement Charge Sale Amount_CC_H2] IS  NULL ) THEN [Last Statement Charge Sale Amount_CC_H1] else (ISNULL([Last Statement Charge Sale Amount_CC_H1],0) - ISNULL([Last Statement Charge Sale Amount_CC_H2],0)) end [DFT_Last Statement Charge Sale Amount_CC_H1_H2]

		--,[Last Statement Merchandise Average Daily Balance Amount_CC_H1]
		,CASE WHEN ([Last Statement Merchandise Average Daily Balance Amount_CC_H1] IS NULL AND [Last Statement Merchandise Average Daily Balance Amount_CC_H2] IS  NULL ) THEN [Last Statement Merchandise Average Daily Balance Amount_CC_H1] else (ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_H1],0) - ISNULL([Last Statement Merchandise Average Daily Balance Amount_CC_H2],0)) end [DFT_Last Statement Merchandise Average Daily Balance Amount_CC_H1_H2]

		--,[Last Statement Cash Average Daily Balance Amount_CC_H1]
		,CASE WHEN ([Last Statement Cash Average Daily Balance Amount_CC_H1] IS NULL AND [Last Statement Cash Average Daily Balance Amount_CC_H2] IS  NULL ) THEN [Last Statement Cash Average Daily Balance Amount_CC_H1] else (ISNULL([Last Statement Cash Average Daily Balance Amount_CC_H1],0)- ISNULL([Last Statement Cash Average Daily Balance Amount_CC_H2],0)) end [DFT_Last Statement Cash Average Daily Balance Amount_CC_H1_H2]

		--,[Last Statement Average Daily Balance Amount_CC_H1]
		,CASE WHEN ([Last Statement Average Daily Balance Amount_CC_H1] IS NULL AND [Last Statement Average Daily Balance Amount_CC_H2] IS  NULL ) THEN [Last Statement Average Daily Balance Amount_CC_H1] else (ISNULL([Last Statement Average Daily Balance Amount_CC_H1],0)-ISNULL([Last Statement Average Daily Balance Amount_CC_H2],0)) end [DFT_Last Statement Average Daily Balance Amount_CC_H1_H2]

		--,[spend_CC_H1]
		,CASE WHEN ([spend_CC_H1] IS NULL AND [spend_CC_H2] IS  NULL ) THEN [spend_CC_H1] else (ISNULL(spend_CC_H1,0)- ISNULL(spend_CC_H2,0)) end [DFT_spend_CC_H1_H2]

		--,[Protected_Balance_CC_H1]
		,CASE WHEN ([Protected_Balance_CC_H1] IS NULL AND [Protected_Balance_CC_H2] IS  NULL ) THEN [Protected_Balance_CC_H1] else (ISNULL([Protected_Balance_CC_H1],0)-ISNULL([Protected_Balance_CC_H2],0)) end [DFT_Protected_Balance_CC_H1_H2]

		--,[Promo_Balance_CC_H1]
		,CASE WHEN ([Promo_Balance_CC_H1] IS NULL AND [Promo_Balance_CC_H2] IS  NULL ) THEN [Promo_Balance_CC_H1] else (ISNULL([Promo_Balance_CC_H1],0)-ISNULL([Promo_Balance_CC_H2],0)) end [DFT_Promo_Balance_CC_H1_H2]

		--,[Protected_Current_Interest_CC_H1]
		,CASE WHEN ([Protected_Current_Interest_CC_H1] IS NULL AND [Protected_Current_Interest_CC_H2] IS  NULL ) THEN [Protected_Current_Interest_CC_H1] else (ISNULL([Protected_Current_Interest_CC_H1],0)- ISNULL([Protected_Current_Interest_CC_H2],0)) end [DFT_Protected_Current_Interest_CC_H1_H2]

		--,[Promo_Current_Interest_CC_H1]
		,CASE WHEN ([Promo_Current_Interest_CC_H1] IS NULL AND [Promo_Current_Interest_CC_H2] IS  NULL ) THEN [Promo_Current_Interest_CC_H1] else (ISNULL([Promo_Current_Interest_CC_H1],0)- ISNULL([Promo_Current_Interest_CC_H2],0)) end [DFT_Promo_Current_Interest_CC_H1_H2]

		--,[RevolvingBalance_CC_H1]
		,CASE WHEN ([RevolvingBalance_CC_H1] IS NULL AND [RevolvingBalance_CC_H2] IS  NULL ) THEN [RevolvingBalance_CC_H1] else (ISNULL([RevolvingBalance_CC_H1],0)-ISNULL([RevolvingBalance_CC_H2],0)) end [DFT_RevolvingBalance_CC_H1_H2]

		--,[AVG_UTILIZATION_RATE_CC_H1]
		,CASE WHEN ([AVG_UTILIZATION_RATE_CC_H1] IS NULL AND [AVG_UTILIZATION_RATE_CC_H2] IS  NULL ) THEN [AVG_UTILIZATION_RATE_CC_H1] else (ISNULL(AVG_UTILIZATION_RATE_CC_H1,0)- ISNULL(AVG_UTILIZATION_RATE_CC_H2,0)) end [DFT_AVG_UTILIZATION_RATE_CC_H1_H2]


		--,[Social Security Number_CC]
		,Count_Durable_CC
		,max_credit_Limit
		,max_age_member_CC
		,[Max_Extract_ACCOUNT_OPEN_DATE_CC]
		,[Max_Closed_account_flag_CC]
		,Max_MOB_CC
		,ChargeoffAmount_final_CC
		,Max_chargoff_date_CC

		--,SSN_00
		,CL_CC_StaticPool
		,MOB_CC_staticPool
		,TRIP_FLAG_staticpool

		,ProductCC_Cycle1_SP
		,ProductCC_Cycle2_SP
		,ProductCC_Cycle2plus_SP
		,CASE WHEN ProductCC_Cycle1_SP > 0 THEN 1 ELSE 0 END CC_Cycle1Flag_SP 
		,CASE WHEN ProductCC_Cycle2_SP > 0 THEN 1 ELSE 0 END CC_Cycle2Flag_SP 
		,CASE WHEN ProductCC_Cycle2plus_SP > 0 THEN 1 ELSE 0 END CC_Cycle2plusFlag_SP 

		,ProductCC_Cycle1_3MBack
		,ProductCC_Cycle2_3MBack
		,ProductCC_Cycle2plus_3MBack
		,CASE WHEN ProductCC_Cycle1_3MBack > 0 THEN 1 ELSE 0 END CC_Cycle1Flag_3MBack 
		,CASE WHEN ProductCC_Cycle2_3MBack > 0 THEN 1 ELSE 0 END CC_Cycle2Flag_3MBack 
		,CASE WHEN ProductCC_Cycle2plus_3MBack > 0 THEN 1 ELSE 0 END CC_Cycle2plusFlag_3MBack 

		,ProductCC_Cycle1_6MBack
		,ProductCC_Cycle2_6MBack
		,ProductCC_Cycle2plus_6MBack
		,CASE WHEN ProductCC_Cycle1_6MBack > 0 THEN 1 ELSE 0 END CC_Cycle1Flag_6MBack 
		,CASE WHEN ProductCC_Cycle2_6MBack > 0 THEN 1 ELSE 0 END CC_Cycle2Flag_6MBack 
		,CASE WHEN ProductCC_Cycle2plus_6MBack > 0 THEN 1 ELSE 0 END CC_Cycle2plusFlag_6MBack 

		,ProductCC_Cycle1_9MBack
		,ProductCC_Cycle2_9MBack
		,ProductCC_Cycle2plus_9MBack
		,CASE WHEN ProductCC_Cycle1_9MBack > 0 THEN 1 ELSE 0 END CC_Cycle1Flag_9MBack 
		,CASE WHEN ProductCC_Cycle2_9MBack > 0 THEN 1 ELSE 0 END CC_Cycle2Flag_9MBack 
		,CASE WHEN ProductCC_Cycle2plus_9MBack > 0 THEN 1 ELSE 0 END CC_Cycle2plusFlag_9MBack 

		,ProductCC_Cycle1_12MBack
		,ProductCC_Cycle2_12MBack
		,ProductCC_Cycle2plus_12MBack
		,CASE WHEN ProductCC_Cycle1_12MBack > 0 THEN 1 ELSE 0 END CC_Cycle1Flag_12MBack 
		,CASE WHEN ProductCC_Cycle2_12MBack > 0 THEN 1 ELSE 0 END CC_Cycle2Flag_12MBack 
		,CASE WHEN ProductCC_Cycle2plus_12MBack > 0 THEN 1 ELSE 0 END CC_Cycle2plusFlag_12MBack 

		,(CL_CC_StaticPool-CreditLimit_CC_Q1) CL_DIFF_past_oneyear
		into #Credit_Card_data
		from 
		(
		select [Social Security Number] SSN_CC
		    
			,COUNT(DISTINCT CASE WHEN Quarters = 'Q1' THEN Durable_Key END) [PRODUCT_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q1]
			,SUM(case when Quarters='Q1' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q1]
			,SUM(case when Quarters='Q1' then [spend] END) [spend_CC_Q1]
			,SUM(case when Quarters='Q1' then [Protected_Balance] END) [Protected_Balance_CC_Q1]
			,SUM(case when Quarters='Q1' then [Promo_Balance] END) [Promo_Balance_CC_Q1]
			,SUM(case when Quarters='Q1' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q1]
			,SUM(case when Quarters='Q1' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q1]
			,SUM(case when Quarters='Q1' then [RevolvingBalance] END) [RevolvingBalance_CC_Q1]
			,max(case when Quarters='Q1' then [Credit Limit] end ) [CreditLimit_CC_Q1]
			,AVG(case when Quarters='Q1' then UTILIZATION_RATE_CC END) [AVG_UTILIZATION_RATE_CC_Q1]
			,SUM(case when ([Card Account Delinquent Day Account] >= 1 and [Card Account Delinquent Day Account] < 30) and MonthFlag = '3MonthBack' then 1 else 0 end) as ProductCC_Cycle1_3MBack
	        ,SUM(case when ([Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60) and MonthFlag = '3MonthBack' then 1 else 0 end) as ProductCC_Cycle2_3MBack
	        ,SUM(case when ([Card Account Delinquent Day Account] >= 60  and  MonthFlag = '3MonthBack') then 1 else 0 end) as ProductCC_Cycle2plus_3MBack

			,COUNT(DISTINCT CASE WHEN Quarters = 'Q2' THEN Durable_Key END) [PRODUCT_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q2]
			,SUM(case when Quarters='Q2' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q2]
			,SUM(case when Quarters='Q2' then [spend] END) [spend_CC_Q2]
			,SUM(case when Quarters='Q2' then [Protected_Balance] END) [Protected_Balance_CC_Q2]
			,SUM(case when Quarters='Q2' then [Promo_Balance] END) [Promo_Balance_CC_Q2]
			,SUM(case when Quarters='Q2' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q2]
			,SUM(case when Quarters='Q2' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q2]
			,SUM(case when Quarters='Q2' then [RevolvingBalance] END) [RevolvingBalance_CC_Q2]
			,AVG(case when Quarters='Q2' then UTILIZATION_RATE_CC END) [AVG_UTILIZATION_RATE_CC_Q2]
			,SUM(case when ([Card Account Delinquent Day Account] >= 1 and [Card Account Delinquent Day Account] < 30) and MonthFlag = '6MonthBack' then 1 else 0 end) as ProductCC_Cycle1_6MBack
	        ,SUM(case when ([Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60) and MonthFlag = '6MonthBack' then 1 else 0 end) as ProductCC_Cycle2_6MBack
	        ,SUM(case when ([Card Account Delinquent Day Account] >= 60  and  MonthFlag = '6MonthBack') then 1 else 0 end) as ProductCC_Cycle2plus_6MBack

			,COUNT(DISTINCT CASE WHEN Quarters = 'Q2' THEN Durable_Key END) [PRODUCT_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q3]
			,SUM(case when Quarters='Q3' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q3]
			,SUM(case when Quarters='Q3' then [spend] END) [spend_CC_Q3]
			,SUM(case when Quarters='Q3' then [Protected_Balance] END) [Protected_Balance_CC_Q3]
			,SUM(case when Quarters='Q3' then [Promo_Balance] END) [Promo_Balance_CC_Q3]
			,SUM(case when Quarters='Q3' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q3]
			,SUM(case when Quarters='Q3' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q3]
			,SUM(case when Quarters='Q3' then [RevolvingBalance] END) [RevolvingBalance_CC_Q3]
			,AVG(case when Quarters='Q3' then UTILIZATION_RATE_CC END) [AVG_UTILIZATION_RATE_CC_Q3]
			,SUM(case when ([Card Account Delinquent Day Account] >= 1 and [Card Account Delinquent Day Account] < 30) and MonthFlag = '9MonthBack' then 1 else 0 end) as ProductCC_Cycle1_9MBack
	        ,SUM(case when ([Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60) and MonthFlag = '9MonthBack' then 1 else 0 end) as ProductCC_Cycle2_9MBack
	        ,SUM(case when ([Card Account Delinquent Day Account] >= 60  and  MonthFlag = '9MonthBack') then 1 else 0 end) as ProductCC_Cycle2plus_9MBack

			,COUNT(DISTINCT CASE WHEN Quarters = 'Q4' THEN Durable_Key END) [PRODUCT_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Q4]
			,SUM(case when Quarters='Q4' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Q4]
			,SUM(case when Quarters='Q4' then [spend] END) [spend_CC_Q4]
			,SUM(case when Quarters='Q4' then [Protected_Balance] END) [Protected_Balance_CC_Q4]
			,SUM(case when Quarters='Q4' then [Promo_Balance] END) [Promo_Balance_CC_Q4]
			,SUM(case when Quarters='Q4' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Q4]
			,SUM(case when Quarters='Q4' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Q4]
			,SUM(case when Quarters='Q4' then [RevolvingBalance] END) [RevolvingBalance_CC_Q4]
			,AVG(case when Quarters='Q4' then UTILIZATION_RATE_CC END) [AVG_UTILIZATION_RATE_CC_Q4]
			,SUM(case when ([Card Account Delinquent Day Account] >= 1 and [Card Account Delinquent Day Account] < 30) and MonthFlag = '12MonthBack' then 1 else 0 end) as ProductCC_Cycle1_12MBack
	        ,SUM(case when ([Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60) and MonthFlag = '12MonthBack' then 1 else 0 end) as ProductCC_Cycle2_12MBack
	        ,SUM(case when ([Card Account Delinquent Day Account] >= 60  and  MonthFlag = '12MonthBack') then 1 else 0 end) as ProductCC_Cycle2plus_12MBack

			,COUNT(DISTINCT CASE WHEN Quarters = 'Staticpool' THEN Durable_Key END) [PRODUCT_CC_STATICPOOL]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Last Statement Payment Amount] END) [Last Statement Payment Amount)_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [spend] END) [spend_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Protected_Balance] END) [Protected_Balance_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Promo_Balance] END) [Promo_Balance_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_Staticpool]
			,SUM(case when Quarters='Staticpool' then [RevolvingBalance] END) [RevolvingBalance_CC_Staticpool]
			,AVG(case when Quarters='Staticpool' then UTILIZATION_RATE_CC END) [AVG_UTILIZATION_RATE_CC_Staticpool]
			,SUM(case when ([Card Account Delinquent Day Account] >= 1 and [Card Account Delinquent Day Account] < 30) and Quarters = 'Staticpool' then 1 else 0 end) as ProductCC_Cycle1_SP
	        ,SUM(case when ([Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60) and Quarters = 'Staticpool' then 1 else 0 end) as ProductCC_Cycle2_SP
	        ,SUM(case when ([Card Account Delinquent Day Account] >= 60  and Quarters = 'Staticpool') then 1 else 0 end) as ProductCC_Cycle2plus_SP

			,COUNT(DISTINCT CASE WHEN HalfYearly = 'H1' THEN Durable_Key END) [PRODUCT_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_H1]
			,SUM(case when HalfYearly='H1' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_H1]
			,SUM(case when HalfYearly='H1' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_H1]
			,SUM(case when HalfYearly='H1' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_H1]
			,SUM(case when HalfYearly='H1' then [spend] END) [spend_CC_H1]
			,SUM(case when HalfYearly='H1' then [Protected_Balance] END) [Protected_Balance_CC_H1]
			,SUM(case when HalfYearly='H1' then [Promo_Balance] END) [Promo_Balance_CC_H1]
			,SUM(case when HalfYearly='H1' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_H1]
			,SUM(case when HalfYearly='H1' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_H1]
			,SUM(case when HalfYearly='H1' then [RevolvingBalance] END) [RevolvingBalance_CC_H1]
			,max(case when HalfYearly='H1' then [Credit Limit] end ) [CreditLimit_CC_H1]
			,AVG(case when HalfYearly='H1' then UTILIZATION_RATE_CC END) [AVG_UTILIZATION_RATE_CC_H1]

			,COUNT(DISTINCT CASE WHEN HalfYearly = 'H2' THEN Durable_Key END) [PRODUCT_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statement Payment Count] END) [Last Statement Payment Count_CC_H2]
			,SUM(case when HalfYearly='H2' then [Last Statement Payment Amount] END) [Last Statement Payment Amount_CC_H2]
			,SUM(case when HalfYearly='H2' then [Last Statement Sale Amount] END) [Last Statement Sale Amount_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statement Cash Amount] END) [Last Statement Cash Amount_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statement Return Amount] END) [Last Statement Return Amount_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statment Sale Count] END) [Last Statement Sale Count_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statement Cash Advance Count] END) [Last Statement Cash Advance Count_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statement Return Count] END) [Last Statement Return Count_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statement External Fee Amount] END) [Last Statement External Fee Amount_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statement Credit Life Change Amount] END) [Last Statement Credit Life Change Amount_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statement Charge Late Amount] END) [Last Statement Charge Late Amount_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statement Charge Cash Amount] END) [Last Statement Charge Cash Amount_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statement Charge Overlimit Amount] END) [Last Statement Charge Overlimit Amount_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statement Charge Sale Amount] END) [Last Statement Charge Sale Amount_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statement Merchandise Average Daily Balance Amount] END) [Last Statement Merchandise Average Daily Balance Amount_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statement Cash Average Daily Balance Amount] END) [Last Statement Cash Average Daily Balance Amount_CC_H2]
			,SUM(case when HalfYearly='H2' then  [Last Statement Average Daily Balance Amount] END) [Last Statement Average Daily Balance Amount_CC_H2]
			,SUM(case when HalfYearly='H2' then [spend] END) [spend_CC_H2]
			,SUM(case when HalfYearly='H2' then [Protected_Balance] END) [Protected_Balance_CC_H2]
			,SUM(case when HalfYearly='H2' then [Promo_Balance] END) [Promo_Balance_CC_H2]
			,SUM(case when HalfYearly='H2' then [Protected_Current_Interest] END) [Protected_Current_Interest_CC_H2]
			,SUM(case when HalfYearly='H2' then [Promo_Current_Interest] END) [Promo_Current_Interest_CC_H2]
			,SUM(case when HalfYearly='H2' then [RevolvingBalance] END) [RevolvingBalance_CC_H2]
			,AVG(case when HalfYearly='H2' then UTILIZATION_RATE_CC END) [AVG_UTILIZATION_RATE_CC_H2]
			
			  from #CC_data
			  group by [Social Security Number]
			  ) a

		  left join (     
					  select [Social Security Number]  [Social Security Number_CC]
							,count(distinct Durable_Key) Count_Durable_CC
							,Max([Credit Limit]) max_credit_Limit
							,max(AGE) max_age_member_CC
							,max([Extract_ACCOUNT_OPEN_DATE]) [Max_Extract_ACCOUNT_OPEN_DATE_CC]
							,max([Closed_account_flag]) [Max_Closed_account_flag_CC]
						    ,max([mob]) Max_MOB_CC
					        ,sum([ChargeoffAmount_final]) ChargeoffAmount_final_CC
						    ,max([ChargeOff_Extract_DatePart]) Max_chargoff_date_CC
						 from #CC_data
						 group by [Social Security Number]
					 ) b
					 on a.SSN_CC=b.[Social Security Number_CC]
			 left join 			
					 (
					 select [Social Security Number] SSN_00,max([Credit Limit]) CL_CC_StaticPool
					 ,max(mob) MOB_CC_staticPool
					 ,max(case when TRIPFLAG='T' then 1
					 when TRIPFLAG='R' then 2
					 when TRIPFLAG='I' then 3
					 when TRIPFLAG='P' then 4 else null end) TRIP_FLAG_staticpool from #cc_data
					 where Quarters='staticpool'
					 group by [Social Security Number]
					 ) w
			 on a.ssn_cc=w.SSN_00	
			 
			 
			 DROP TABLE IF EXISTS #loan_product_master		   

			 SELECT a.* ,b.*
			 INTO #loan_product_master
			 FROM #loan_product_summary A
			 LEFT JOIN
			 #Credit_Card_data B
			 on A.SSN001 = B.SSN_CC 

			 --DROP TABLE IF EXISTS #updated_loan_product_master		   

			 --SELECT CASE WHEN A.SSN_LOAN = B.SSN_CC THEN SSN_LOAN
			 --            WHEN A.SSN_LOAN IS NULL THEN B.SSN_CC
			 --		       WHEN B.SSN_CC IS NULL THEN A.SSN_LOAN END [SSN_L],
			 --A.* ,B.*
			 --INTO #updated_loan_product_master	
			 --FROM #updated_loan_product_summary A
			 --FULL OUTER JOIN
			 --#Credit_Card_data B
			 --on A.SSN_LOAN = B.SSN_CC

			 --SELECT  SSN_CC FROM  #Credit_Card_data
			 --where SSN_CC not in (SELECT SSN FROM #loan_product_summary ) --0
			 --SELECT TOP 10 * into Analytics.dbo.SNSN FROM #loan_product_master

------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** DEPOSITS ***\\\-------------------------------------------------------------------

		--	  drop table if exists #groupproducttype_Deposits  ---grouping table updated by Nikita 03/06/2022
		--select *
		--,case when productname like '%business%' or  productname like '%commercial%'
		-- or productname like '%professional%' or productcode in  ('143','5080','105','149','5013')
	 --then 1 else 0 end Businessflag 
		--into #groupproducttype_Deposits
		--from
		--	(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName,ApplicationDescription,ApplicationTableName
		--	 from [AE_EDW].[tempods].[S_CRMProductType] a
		--	left join [AE_EDW].[tempods].[S_CRMApplicationType] b
		--	on a.ApplicationTypeID=b.ApplicationTypeID
		--	where ApplicationDescription is not null and ProductName!='IRA Savings'
		--	and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a

  --       DROP TABLE IF EXISTS #ShareCategory
  --       SELECT * 
  --       INTO #ShareCategory
  --       FROM
  --       (SELECT B.*,A.Businessflag 
		-- ,CASE WHEN A.ProductName = B.ShareTypeDescription THEN 1 ELSE 0 END [Description Flag]
		-- FROM #groupproducttype_Deposits A
  --       left Join 
  --       ARCUSYM000.ARCU.ARCUShareCategory B
  --       on A.ProductName = B.ShareTypeDescription) W
  --       where [Description Flag] = 1
  --       and ShareCategory3 not in ('IRA','HSA')

	  DROP TABLE IF EXISTS #ShareCategory
	 -- Consumer & Commercial Category in Money Market
		SELECT *, CASE WHEN (ShareCategory2 = 'Savings' and ShareCategory3 not in ('IRA','HSA')) then 'Savings'
			         WHEN (ShareCategory2 = 'Checking' and ShareCategory3 not in ('IRA','HSA')) then 'Checking'
					 WHEN (ShareCategory2 = 'CD' and ShareCategory3 not in ('IRA','HSA'))  then 'Certificates'
					 WHEN (ShareCategory2 = 'Money Market' and ShareCategory3 not in ('IRA','HSA')) then 'MoneyMarket' 
					 WHEN (ShareCategory2 in ('CD','Money Market') and ShareCategory3 = 'IRA')  then 'IRA'
					 WHEN (ShareCategory2 in ('Checking','Savings') and ShareCategory3 = 'HSA')  then 'HSA'
					 ELSE 'OTHERS' END [Deposit_Flag]
		into #ShareCategory
		FROM
		(
  		SELECT *,CASE WHEN ShareCategory2 ='Savings' and ShareCategory3='IRA' then 1 else 0 end [IRA_SAVINGS_FLAG]  
		from ARCUSYM000.ARCU.ARCUShareCategory
		) S
		where 1=1
			--and ShareCategory3 not in ('HSA','IRA') 
			and ShareCategory1 <> 'Non-Member'
			and ShareType <> '9997'   --(excluding Greenstate Corporate Checking)
			and IRA_SAVINGS_FLAG = 0
   
------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Membership Data (ShareCategorywise) ***\\\-------------------------------------------------------------------

    DROP TABLE IF EXISTS #deposits_account_data

		select SSN
		      ,UNID
			  ,ProcessDate
			  ,PARENTACCOUNT
			  ,id
			  ,TYPE
			  ,LASTDIVAMOUNT
			  ,BALANCE Month_end_balance
		      ,CHARGEOFFAMOUNT
			  ,CHARGEOFFDATE
			  ,CHARGEOFFTYPE
			  ,Closed_flag
			  ,left(ProcessDate,6) ProcessDate_v
		      ,close_date,open_date
			  ,process_date 
			  ,Quarters
			  ,HalfYearly
			  ,MOB
			  ,OVERDRAFTTOLERANCE
			  ,OVERDRAFTFEEYTD	
			  ,PENALTYYTD	
			  --,StaticPool_Saving_flag
			  , CASE WHEN (ShareCategory2 = 'Savings' and ShareCategory3 not in ('IRA','HSA')) then 'Savings'
			         WHEN (ShareCategory2 = 'Checking' and ShareCategory3 not in ('IRA','HSA')) then 'Checking'
					 WHEN (ShareCategory2 = 'CD' and ShareCategory3 not in ('IRA','HSA'))  then 'Certificates'
					 WHEN (ShareCategory2 = 'Money Market' and ShareCategory3 not in ('IRA','HSA')) then 'MoneyMarket' 
					 WHEN (ShareCategory2 in ('CD','Money Market') and ShareCategory3 = 'IRA')  then 'IRA'
					 WHEN (ShareCategory2 in ('Checking','Savings') and ShareCategory3 = 'HSA')  then 'HSA'
					 ELSE 'OTHERS' END [Deposit_Flag] --GREENSTATE CORPORATE CHECKING is the only in others
		into #deposits_account_data 
		from 
		(
		select  
		d.SSN
						   ,case when Process_Date in ((EOMONTH(DATEADD(month,-12,@staticpooldate))),(EOMONTH(DATEADD(month,-11,@staticpooldate))),(EOMONTH(DATEADD(month,-10,@staticpooldate )))) then 'Q4'
		                         when Process_Date in ((EOMONTH(DATEADD(month,-9,@staticpooldate ))),(EOMONTH(DATEADD(month,-8,@staticpooldate))),(EOMONTH(DATEADD(month,-7,@staticpooldate)))) then 'Q3'
 								 when Process_Date in ((EOMONTH(DATEADD(month,-6,@staticpooldate ))),(EOMONTH(DATEADD(month,-5,@staticpooldate))),(EOMONTH(DATEADD(month,-4,@staticpooldate)))) then 'Q2'
								 when Process_Date in ((EOMONTH(DATEADD(month,-3,@staticpooldate))),(EOMONTH(DATEADD(month,-2,@staticpooldate ))),(EOMONTH(DATEADD(month,-1,@staticpooldate )))) then 'Q1'
								 when Process_Date in (@staticpooldate) then 'Staticpool'
							end Quarters
							,case when Process_Date in (EOMONTH(DATEADD(month,-12,@staticpooldate)),(EOMONTH(DATEADD(month,-11,@staticpooldate))),(EOMONTH(DATEADD(month,-10,@staticpooldate))) 
							                           ,(EOMONTH(DATEADD(month,-9,@staticpooldate ))),(EOMONTH(DATEADD(month,-8,@staticpooldate))),(EOMONTH(DATEADD(month,-7,@staticpooldate)))) then 'H2'
 								  when Process_Date in (EOMONTH(DATEADD(month,-6,@staticpooldate )),(EOMONTH(DATEADD(month,-5,@staticpooldate))),(EOMONTH(DATEADD(month,-4,@staticpooldate)))
								                      ,(EOMONTH(DATEADD(month,-3,@staticpooldate))),(EOMONTH(DATEADD(month,-2,@staticpooldate ))),(EOMONTH(DATEADD(month,-1,@staticpooldate )))) then 'H1'
							end HalfYearly
		   ,DATEDIFF(MONTH,OPEN_DATE,@staticpooldate) MOB
		   --,case when ShareCategory2='savings' and Process_Date =@staticpooldate then 1 else 0 end StaticPool_Saving_flag
		,aa.*,c.Closed_flag
		,case when aa.close_date is null then '' 
		when len(month(aa.close_date))=1 then CONCAT(year(aa.close_date),0,month(aa.close_date))
		else CONCAT(year(aa.close_date),month(aa.close_date)) end  Closed_date_INT
		,case when len(month(aa.open_date))=1 then CONCAT(year(aa.open_date),0,month(aa.open_date))
		else CONCAT(year(aa.open_date),month(aa.open_date)) end  OPEN_date_INT_INT
		,E.ShareTypeDescription,E.ShareCategory2,E.ShareCategory3
		,case when ShareCategory2='CD' and BALANCE=0 then 0 else 1 end carryforward_flag ----not understood
		from 
					(select * from
							(	select *,case when [EOM_Process Date]=[Process Date] then 1 else 0 end EOM_flag 
										,case when (closedate is null and CHARGEOFFDATE is null) or ProcessDate_v=Close_date_v 
										or ProcessDate_v=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
										,case when OPEN_DATE=CLOSE_DATE then 0 else 1 end Funded_loan_flag
										,lag(Open_date,1) over (partition by Concat(parentaccount,id) order by processdate) Lag_opendate
											,lag(type,1) over (partition by Concat(parentaccount,id) order by processdate) Lag_Type
											,concat(PARENTACCOUNT,ID) UNID
										from
											(select a.*,EOMONTH([Process Date]) [EOM_Process Date]
											,case when ProcessDate_v=CHARGEOFFDATE_v then CHARGEOFFAMOUNT else 0 end CHARGEOFFAMOUNT_v
											,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
											else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date_v
											,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
											,cast(OPENDATE as date) Open_date
											,cast(CLOSEDATE as date) Close_date
											 from 
												 ( select * ,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
												 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v
												 ,left(ProcessDate,6) ProcessDate_v
												,datefromparts(left(processdate,4),right(left(processdate,6),2),right(processdate,2)) [Process Date] 
												from arcusym000.dbo.SAVINGS
												--where (chargeoffdate is null or chargeoffdate>='2021-11-01')
												) a
												 
											) F
								 ) aaa
								  where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
					 ) aa
		left join 
				(select UNID,max(closed_flag) Closed_flag
				from
						(select *,CONCAT(PARENTACCOUNT,ID) UNID,case when CLOSEDATE is null then 0 else 1 end closed_flag
						from 
								(select distinct PARENTACCOUNT,ID,CLOSEDATE 
								from [ARCUSYM000].dbo.SAVINGS
								 where PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
								 ) a 
						 )b
				group by UNID
				) c
		on aa.UNID=c.UNID
		left join #Static_SSN_account d
		on aa.PARENTACCOUNT=d.AccountNumber
		left join #ShareCategory E
		on e.ShareType=aa.TYPE
		where Process_Date between EOMONTH(DATEADD(month,-12,@staticpooldate)) and EOMONTH(DATEADD(month,12,@staticpooldate))
		and PARENTACCOUNT in (select AccountNumber from #Static_SSN_account ) 
		) ZZ
		where 1 = 1
		--and ShareCategory2 ='Savings'  
		and open_date<@staticpooldate and (close_date is null or close_date>@staticpooldate)
		and Funded_loan_flag=1 and Quarters is not null and Open_Flag=1 and carryforward_flag=1
		order by UNID,ProcessDate,TYPE

		--SELECT DISTINCT SSN FROM #deposits_account_data where Process_Date = '2021-08-31' -- 321868

		DROP TABLE IF EXISTS #membership_deposits

		SELECT A.SSN [SSN003]
		      ,PRODUCT_SAVINGS_SP [PRODUCT_SAVINGS_SP]
		      ,PRODUCT_SAVINGS_Q1 [PRODUCT_SAVINGS_Q1]
			  ,CASE WHEN (PRODUCT_SAVINGS_Q1 IS NULL AND PRODUCT_SAVINGS_Q2 IS  NULL ) THEN PRODUCT_SAVINGS_Q1 else (ISNULL(PRODUCT_SAVINGS_Q1,0) - ISNULL(PRODUCT_SAVINGS_Q2,0)) end [DFT_PRODUCT_SAVINGS_Q1_Q2]

			  ,MOB_SAVINGS

			  ,AVG_MONTH_END_BALANCE_SAVINGS_Q1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_SAVINGS_Q1 IS NULL AND AVG_MONTH_END_BALANCE_SAVINGS_Q2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_SAVINGS_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_Q2,0)) end [DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2] 

			  ,SUM_LASTDIVAMOUNT_SAVINGS_Q1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_SAVINGS_Q1 IS NULL AND SUM_LASTDIVAMOUNT_SAVINGS_Q2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_SAVINGS_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_Q2,0)) end [DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2]

			  --,AVG_CHARGEOFFAMOUNT_SAVINGS_SP
			  --,AVG_CHARGEOFFAMOUNT_SAVINGS_Q1
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_SAVINGS_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_SAVINGS_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_SAVINGS_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_SAVINGS_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_SAVINGS_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_Q1_Q2]

			  ,OVERDRAFTFEEYTD_SAVINGS_Q1
			  ,CASE WHEN (OVERDRAFTFEEYTD_SAVINGS_Q1 IS NULL AND OVERDRAFTFEEYTD_SAVINGS_Q2 IS NULL) THEN OVERDRAFTFEEYTD_SAVINGS_Q1 else (ISNULL(OVERDRAFTFEEYTD_SAVINGS_Q1,0)-ISNULL(OVERDRAFTFEEYTD_SAVINGS_Q2,0)) end [DFT_OVERDRAFTFEEYTD_SAVINGS_Q1_Q2]

			  --,PENALTYYTD_SAVINGS_Q1
			  --,CASE WHEN (PENALTYYTD_SAVINGS_Q1 IS NULL AND PENALTYYTD_SAVINGS_Q2 IS NULL) THEN PENALTYYTD_SAVINGS_Q1 else (ISNULL(PENALTYYTD_SAVINGS_Q1,0)-ISNULL(PENALTYYTD_SAVINGS_Q2,0)) end [DFT_PENALTYYTD_SAVINGS_Q1_Q2]

		      ,PRODUCT_CHECKING_SP [PRODUCT_CHECKING_SP]
		      ,PRODUCT_CHECKING_Q1 [PRODUCT_CHECKING_Q1]
			  ,CASE WHEN (PRODUCT_CHECKING_Q1 IS NULL AND PRODUCT_CHECKING_Q2 IS  NULL ) THEN PRODUCT_CHECKING_Q1 else (ISNULL(PRODUCT_CHECKING_Q1,0) - ISNULL(PRODUCT_CHECKING_Q2,0)) end [DFT_PRODUCT_CHECKING_Q1_Q2]

			  ,MOB_CHECKING
 
 			  ,AVG_MONTH_END_BALANCE_CHECKING_Q1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_CHECKING_Q1 IS NULL AND AVG_MONTH_END_BALANCE_CHECKING_Q2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_CHECKING_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_CHECKING_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_CHECKING_Q2,0)) end [DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2] 
	
			  ,SUM_LASTDIVAMOUNT_CHECKING_Q1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_CHECKING_Q1 IS NULL AND SUM_LASTDIVAMOUNT_CHECKING_Q2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_CHECKING_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_CHECKING_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_CHECKING_Q2,0)) end [DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2]
	
			  ,AVG_CHARGEOFFAMOUNT_CHECKING_SP
			  ,AVG_CHARGEOFFAMOUNT_CHECKING_Q1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_CHECKING_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_CHECKING_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_CHECKING_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_CHECKING_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_CHECKING_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q2]

			  ,OVERDRAFTFEEYTD_CHECKING_Q1
			  ,CASE WHEN (OVERDRAFTFEEYTD_CHECKING_Q1 IS NULL AND OVERDRAFTFEEYTD_CHECKING_Q2 IS NULL) THEN OVERDRAFTFEEYTD_CHECKING_Q1 else (ISNULL(OVERDRAFTFEEYTD_CHECKING_Q1,0)-ISNULL(OVERDRAFTFEEYTD_CHECKING_Q2,0)) end [DFT_OVERDRAFTFEEYTD_CHECKING_Q1_Q2]

			  --,PENALTYYTD_CHECKING_Q1
			  --,CASE WHEN (PENALTYYTD_CHECKING_Q1 IS NULL AND PENALTYYTD_CHECKING_Q2 IS NULL) THEN PENALTYYTD_CHECKING_Q1 else (ISNULL(PENALTYYTD_CHECKING_Q1,0)-ISNULL(PENALTYYTD_CHECKING_Q2,0)) end [DFT_PENALTYYTD_CHECKING_Q1_Q2]

		      ,PRODUCT_CERTIFICATES_SP [PRODUCT_CERTIFICATES_SP]
		      ,PRODUCT_CERTIFICATES_Q1 [PRODUCT_CERTIFICATES_Q1]
			  ,CASE WHEN (PRODUCT_CERTIFICATES_Q1 IS NULL AND PRODUCT_CERTIFICATES_Q2 IS  NULL ) THEN PRODUCT_CERTIFICATES_Q1 else (ISNULL(PRODUCT_CERTIFICATES_Q1,0) - ISNULL(PRODUCT_CERTIFICATES_Q2,0)) end [DFT_PRODUCT_CERTIFICATES_Q1_Q2]

			  ,MOB_CERTIFICATES

			  ,AVG_MONTH_END_BALANCE_CERTIFICATES_Q1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_CERTIFICATES_Q1 IS NULL AND AVG_MONTH_END_BALANCE_CERTIFICATES_Q2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_CERTIFICATES_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_Q2,0)) end [DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2] 

			  ,SUM_LASTDIVAMOUNT_CERTIFICATES_Q1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_CERTIFICATES_Q1 IS NULL AND SUM_LASTDIVAMOUNT_CERTIFICATES_Q2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_CERTIFICATES_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_Q2,0)) end [DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q2]

			  --,AVG_CHARGEOFFAMOUNT_CERTIFICATES_SP
			  --,AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1_Q2]

			  --,PENALTYYTD_CERTIFICATES_Q1
			  --,CASE WHEN (PENALTYYTD_CERTIFICATES_Q1 IS NULL AND PENALTYYTD_CERTIFICATES_Q2 IS NULL) THEN PENALTYYTD_CERTIFICATES_Q1 else (ISNULL(PENALTYYTD_CERTIFICATES_Q1,0)-ISNULL(PENALTYYTD_CERTIFICATES_Q2,0)) end [DFT_PENALTYYTD_CERTIFICATES_Q1_Q2]

		      --,PRODUCT_MONEYMARKET_SP [PRODUCT_MONEYMARKET_SP]
		      ,PRODUCT_MONEYMARKET_Q1 [PRODUCT_MONEYMARKET_Q1]
			  ,CASE WHEN (PRODUCT_MONEYMARKET_Q1 IS NULL AND PRODUCT_MONEYMARKET_Q2 IS  NULL ) THEN PRODUCT_MONEYMARKET_Q1 else (ISNULL(PRODUCT_MONEYMARKET_Q1,0) - ISNULL(PRODUCT_MONEYMARKET_Q2,0)) end [DFT_PRODUCT_MONEYMARKET_Q1_Q2]

			  ,MOB_MONEYMARKET

			  ,AVG_MONTH_END_BALANCE_MONEYMARKET_Q1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_MONEYMARKET_Q1 IS NULL AND AVG_MONTH_END_BALANCE_MONEYMARKET_Q2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_MONEYMARKET_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_Q2,0)) end [DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2] 

			  ,SUM_LASTDIVAMOUNT_MONEYMARKET_Q1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 IS NULL AND SUM_LASTDIVAMOUNT_MONEYMARKET_Q2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_Q2,0)) end [DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2]

			  --,AVG_CHARGEOFFAMOUNT_MONEYMARKET_SP
			  --,AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1_Q2]

			  ,OVERDRAFTFEEYTD_MONEYMARKET_Q1
			  ,CASE WHEN (OVERDRAFTFEEYTD_MONEYMARKET_Q1 IS NULL AND OVERDRAFTFEEYTD_MONEYMARKET_Q2 IS NULL) THEN OVERDRAFTFEEYTD_MONEYMARKET_Q1 else (ISNULL(OVERDRAFTFEEYTD_MONEYMARKET_Q1,0)-ISNULL(OVERDRAFTFEEYTD_MONEYMARKET_Q2,0)) end [DFT_OVERDRAFTFEEYTD_MONEYMARKET_Q1_Q2]

			  --,PENALTYYTD_MONEYMARKET_Q1
			  --,CASE WHEN (PENALTYYTD_MONEYMARKET_Q1 IS NULL AND PENALTYYTD_MONEYMARKET_Q2 IS NULL) THEN PENALTYYTD_MONEYMARKET_Q1 else (ISNULL(PENALTYYTD_MONEYMARKET_Q1,0)-ISNULL(PENALTYYTD_MONEYMARKET_Q2,0)) end [DFT_PENALTYYTD_MONEYMARKET_Q1_Q2]


		   --   ,PRODUCT_IRA_SP [PRODUCT_IRA_SP]
		   --   ,PRODUCT_IRA_Q1 [PRODUCT_IRA_Q1]
			  --,CASE WHEN (PRODUCT_IRA_Q1 IS NULL AND PRODUCT_IRA_Q2 IS  NULL ) THEN PRODUCT_IRA_Q1 else (ISNULL(PRODUCT_IRA_Q1,0) - ISNULL(PRODUCT_IRA_Q2,0)) end [DFT_PRODUCT_IRA_Q1_Q2]

			  --,MOB_IRA

			  --,AVG_MONTH_END_BALANCE_IRA_Q1
			  --,CASE WHEN (AVG_MONTH_END_BALANCE_IRA_Q1 IS NULL AND AVG_MONTH_END_BALANCE_IRA_Q2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_IRA_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_IRA_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_IRA_Q2,0)) end [DFT_AVG_MONTH_END_BALANCE_IRA_Q1_Q2] 

			  --,SUM_LASTDIVAMOUNT_IRA_Q1
			  --,CASE WHEN (SUM_LASTDIVAMOUNT_IRA_Q1 IS NULL AND SUM_LASTDIVAMOUNT_IRA_Q2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_IRA_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_IRA_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_IRA_Q2,0)) end [DFT_SUM_LASTDIVAMOUNT_IRA_Q1_Q2]

			  --,AVG_CHARGEOFFAMOUNT_IRA_Q1
			  --,CASE WHEN (AVG_CHARGEOFFAMOUNT_IRA_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_IRA_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_IRA_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_IRA_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_IRA_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_IRA_Q1_Q2]

		      ,PRODUCT_DEPOSITS_SP [PRODUCT_DEPOSITS_SP]
		      ,PRODUCT_DEPOSITS_Q1 [PRODUCT_DEPOSITS_Q1]
			  ,CASE WHEN (PRODUCT_DEPOSITS_Q1 IS NULL AND PRODUCT_DEPOSITS_Q2 IS  NULL ) THEN PRODUCT_DEPOSITS_Q1 else (ISNULL(PRODUCT_DEPOSITS_Q1,0) - ISNULL(PRODUCT_DEPOSITS_Q2,0)) end [DFT_PRODUCT_DEPOSITS_Q1_Q2]

			  ,MOB_DEPOSITS

			  ,AVG_MONTH_END_BALANCE_DEPOSITS_Q1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_DEPOSITS_Q1 IS NULL AND AVG_MONTH_END_BALANCE_DEPOSITS_Q2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_DEPOSITS_Q1 else (ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q1,0) - ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_Q2,0)) end [DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2] 

			  ,SUM_LASTDIVAMOUNT_DEPOSITS_Q1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_DEPOSITS_Q1 IS NULL AND SUM_LASTDIVAMOUNT_DEPOSITS_Q2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_DEPOSITS_Q1 else (ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_Q1,0)-ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_Q2,0)) end [DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2]

			  ,AVG_CHARGEOFFAMOUNT_DEPOSITS_SP
			  ,AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1 IS NULL AND AVG_CHARGEOFFAMOUNT_DEPOSITS_Q2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1 else (ISNULL(AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_DEPOSITS_Q2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q2]

		      --,PRODUCT_SAVINGS_H1 [PRODUCT_SAVINGS_H1]
			  ,CASE WHEN (PRODUCT_SAVINGS_H1 IS NULL AND PRODUCT_SAVINGS_H2 IS  NULL ) THEN PRODUCT_SAVINGS_H1 else (ISNULL(PRODUCT_SAVINGS_H1,0) - ISNULL(PRODUCT_SAVINGS_H2,0)) end [DFT_PRODUCT_SAVINGS_H1_H2]


			  --,AVG_MONTH_END_BALANCE_SAVINGS_H1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_SAVINGS_H1 IS NULL AND AVG_MONTH_END_BALANCE_SAVINGS_H2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_SAVINGS_H1 else (ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_H1,0) - ISNULL(AVG_MONTH_END_BALANCE_SAVINGS_H2,0)) end [DFT_AVG_MONTH_END_BALANCE_SAVINGS_H1_H2] 

			  --,SUM_LASTDIVAMOUNT_SAVINGS_H1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_SAVINGS_H1 IS NULL AND SUM_LASTDIVAMOUNT_SAVINGS_H2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_SAVINGS_H1 else (ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_H1,0)-ISNULL(SUM_LASTDIVAMOUNT_SAVINGS_H2,0)) end [DFT_SUM_LASTDIVAMOUNT_SAVINGS_H1_H2]

			  --,AVG_CHARGEOFFAMOUNT_SAVINGS_H1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_SAVINGS_H1 IS NULL AND AVG_CHARGEOFFAMOUNT_SAVINGS_H2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_SAVINGS_H1 else (ISNULL(AVG_CHARGEOFFAMOUNT_SAVINGS_H1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_SAVINGS_H2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_H1_H2]

			  ,CASE WHEN (OVERDRAFTFEEYTD_SAVINGS_H1 IS NULL AND OVERDRAFTFEEYTD_SAVINGS_H2 IS NULL) THEN OVERDRAFTFEEYTD_SAVINGS_H1 else (ISNULL(OVERDRAFTFEEYTD_SAVINGS_H1,0)-ISNULL(OVERDRAFTFEEYTD_SAVINGS_H2,0)) end [DFT_OVERDRAFTFEEYTD_SAVINGS_H1_H2]

			  --,CASE WHEN (PENALTYYTD_SAVINGS_H1 IS NULL AND PENALTYYTD_SAVINGS_H2 IS NULL) THEN PENALTYYTD_SAVINGS_H1 else (ISNULL(PENALTYYTD_SAVINGS_H1,0)-ISNULL(PENALTYYTD_SAVINGS_H2,0)) end [DFT_PENALTYYTD_SAVINGS_H1_H2]


		      --,PRODUCT_CHECKING_H1 [PRODUCT_CHECKING_H1]
			  ,CASE WHEN (PRODUCT_CHECKING_H1 IS NULL AND PRODUCT_CHECKING_H2 IS  NULL ) THEN PRODUCT_CHECKING_H1 else (ISNULL(PRODUCT_CHECKING_H1,0) - ISNULL(PRODUCT_CHECKING_H2,0)) end [DFT_PRODUCT_CHECKING_H1_H2]
 
 			  --,AVG_MONTH_END_BALANCE_CHECKING_H1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_CHECKING_H1 IS NULL AND AVG_MONTH_END_BALANCE_CHECKING_H2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_CHECKING_H1 else (ISNULL(AVG_MONTH_END_BALANCE_CHECKING_H1,0) - ISNULL(AVG_MONTH_END_BALANCE_CHECKING_H2,0)) end [DFT_AVG_MONTH_END_BALANCE_CHECKING_H1_H2] 
	
			  --,SUM_LASTDIVAMOUNT_CHECKING_H1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_CHECKING_H1 IS NULL AND SUM_LASTDIVAMOUNT_CHECKING_H2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_CHECKING_H1 else (ISNULL(SUM_LASTDIVAMOUNT_CHECKING_H1,0)-ISNULL(SUM_LASTDIVAMOUNT_CHECKING_H2,0)) end [DFT_SUM_LASTDIVAMOUNT_CHECKING_H1_H2]

			  --,AVG_CHARGEOFFAMOUNT_CHECKING_H1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_CHECKING_H1 IS NULL AND AVG_CHARGEOFFAMOUNT_CHECKING_H2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_CHECKING_H1 else (ISNULL(AVG_CHARGEOFFAMOUNT_CHECKING_H1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_CHECKING_H2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_CHECKING_H1_H2]

			  ,CASE WHEN (OVERDRAFTFEEYTD_CHECKING_H1 IS NULL AND OVERDRAFTFEEYTD_CHECKING_H2 IS NULL) THEN OVERDRAFTFEEYTD_CHECKING_H1 else (ISNULL(OVERDRAFTFEEYTD_CHECKING_H1,0)-ISNULL(OVERDRAFTFEEYTD_CHECKING_H2,0)) end [DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2]

			  --,CASE WHEN (PENALTYYTD_CHECKING_H1 IS NULL AND PENALTYYTD_CHECKING_H2 IS NULL) THEN PENALTYYTD_CHECKING_H1 else (ISNULL(PENALTYYTD_CHECKING_H1,0)-ISNULL(PENALTYYTD_CHECKING_H2,0)) end [DFT_PENALTYYTD_CHECKING_H1_H2]


		      --,PRODUCT_CERTIFICATES_H1 [PRODUCT_CERTIFICATES_H1]
			  ,CASE WHEN (PRODUCT_CERTIFICATES_H1 IS NULL AND PRODUCT_CERTIFICATES_H2 IS  NULL ) THEN PRODUCT_CERTIFICATES_H1 else (ISNULL(PRODUCT_CERTIFICATES_H1,0) - ISNULL(PRODUCT_CERTIFICATES_H2,0)) end [DFT_PRODUCT_CERTIFICATES_H1_H2]


			  --,AVG_MONTH_END_BALANCE_CERTIFICATES_H1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_CERTIFICATES_H1 IS NULL AND AVG_MONTH_END_BALANCE_CERTIFICATES_H2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_CERTIFICATES_H1 else (ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_H1,0) - ISNULL(AVG_MONTH_END_BALANCE_CERTIFICATES_H2,0)) end [DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_H1_H2] 

			  --,SUM_LASTDIVAMOUNT_CERTIFICATES_H1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_CERTIFICATES_H1 IS NULL AND SUM_LASTDIVAMOUNT_CERTIFICATES_H2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_CERTIFICATES_H1 else (ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_H1,0)-ISNULL(SUM_LASTDIVAMOUNT_CERTIFICATES_H2,0)) end [DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_H1_H2]

			  --,AVG_CHARGEOFFAMOUNT_CERTIFICATES_H1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_CERTIFICATES_H1 IS NULL AND AVG_CHARGEOFFAMOUNT_CERTIFICATES_H2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_CERTIFICATES_H1 else (ISNULL(AVG_CHARGEOFFAMOUNT_CERTIFICATES_H1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_CERTIFICATES_H2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_CERTIFICATES_H1_H2]

			  ,CASE WHEN (PENALTYYTD_CERTIFICATES_H1 IS NULL AND PENALTYYTD_CERTIFICATES_H2 IS NULL) THEN PENALTYYTD_CERTIFICATES_H1 else (ISNULL(PENALTYYTD_CERTIFICATES_H1,0)-ISNULL(PENALTYYTD_CERTIFICATES_H2,0)) end [DFT_PENALTYYTD_CERTIFICATES_H1_H2]


		      --,PRODUCT_MONEYMARKET_H1 [PRODUCT_MONEYMARKET_H1]
			  ,CASE WHEN (PRODUCT_MONEYMARKET_H1 IS NULL AND PRODUCT_MONEYMARKET_H2 IS  NULL ) THEN PRODUCT_MONEYMARKET_H1 else (ISNULL(PRODUCT_MONEYMARKET_H1,0) - ISNULL(PRODUCT_MONEYMARKET_H2,0)) end [DFT_PRODUCT_MONEYMARKET_H1_H2]

			  --,AVG_MONTH_END_BALANCE_MONEYMARKET_H1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_MONEYMARKET_H1 IS NULL AND AVG_MONTH_END_BALANCE_MONEYMARKET_H2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_MONEYMARKET_H1 else (ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_H1,0) - ISNULL(AVG_MONTH_END_BALANCE_MONEYMARKET_H2,0)) end [DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_H1_H2] 

			  --,SUM_LASTDIVAMOUNT_MONEYMARKET_H1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_MONEYMARKET_H1 IS NULL AND SUM_LASTDIVAMOUNT_MONEYMARKET_H2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_MONEYMARKET_H1 else (ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_H1,0)-ISNULL(SUM_LASTDIVAMOUNT_MONEYMARKET_H2,0)) end [DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_H1_H2]

			  --,AVG_CHARGEOFFAMOUNT_MONEYMARKET_H1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_MONEYMARKET_H1 IS NULL AND AVG_CHARGEOFFAMOUNT_MONEYMARKET_H2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_MONEYMARKET_H1 else (ISNULL(AVG_CHARGEOFFAMOUNT_MONEYMARKET_H1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_MONEYMARKET_H2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_MONEYMARKET_H1_H2]

			  ,CASE WHEN (OVERDRAFTFEEYTD_MONEYMARKET_H1 IS NULL AND OVERDRAFTFEEYTD_MONEYMARKET_H2 IS NULL) THEN OVERDRAFTFEEYTD_MONEYMARKET_H1 else (ISNULL(OVERDRAFTFEEYTD_MONEYMARKET_H1,0)-ISNULL(OVERDRAFTFEEYTD_MONEYMARKET_H2,0)) end [DFT_OVERDRAFTFEEYTD_MONEYMARKET_H1_H2]

			  --,CASE WHEN (PENALTYYTD_MONEYMARKET_H1 IS NULL AND PENALTYYTD_MONEYMARKET_H2 IS NULL) THEN PENALTYYTD_MONEYMARKET_H1 else (ISNULL(PENALTYYTD_MONEYMARKET_H1,0)-ISNULL(PENALTYYTD_MONEYMARKET_H2,0)) end [DFT_PENALTYYTD_MONEYMARKET_H1_H2]


		      --,PRODUCT_IRA_H1 [PRODUCT_IRA_H1]
			  ,CASE WHEN (PRODUCT_IRA_H1 IS NULL AND PRODUCT_IRA_H2 IS  NULL ) THEN PRODUCT_IRA_H1 else (ISNULL(PRODUCT_IRA_H1,0) - ISNULL(PRODUCT_IRA_H2,0)) end [DFT_PRODUCT_IRA_H1_H2]


			  --,AVG_MONTH_END_BALANCE_IRA_H1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_IRA_H1 IS NULL AND AVG_MONTH_END_BALANCE_IRA_H2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_IRA_H1 else (ISNULL(AVG_MONTH_END_BALANCE_IRA_H1,0) - ISNULL(AVG_MONTH_END_BALANCE_IRA_H2,0)) end [DFT_AVG_MONTH_END_BALANCE_IRA_H1_H2] 

			  --,SUM_LASTDIVAMOUNT_IRA_H1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_IRA_H1 IS NULL AND SUM_LASTDIVAMOUNT_IRA_H2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_IRA_H1 else (ISNULL(SUM_LASTDIVAMOUNT_IRA_H1,0)-ISNULL(SUM_LASTDIVAMOUNT_IRA_H2,0)) end [DFT_SUM_LASTDIVAMOUNT_IRA_H1_H2]

			  --,AVG_CHARGEOFFAMOUNT_IRA_H1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_IRA_H1 IS NULL AND AVG_CHARGEOFFAMOUNT_IRA_H2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_IRA_H1 else (ISNULL(AVG_CHARGEOFFAMOUNT_IRA_H1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_IRA_H2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_IRA_H1_H2]

		      --,PRODUCT_DEPOSITS_H1 [PRODUCT_DEPOSITS_H1]
			  ,CASE WHEN (PRODUCT_DEPOSITS_H1 IS NULL AND PRODUCT_DEPOSITS_H2 IS  NULL ) THEN PRODUCT_DEPOSITS_H1 else (ISNULL(PRODUCT_DEPOSITS_H1,0) - ISNULL(PRODUCT_DEPOSITS_H2,0)) end [DFT_PRODUCT_DEPOSITS_H1_H2]

			  --,AVG_MONTH_END_BALANCE_DEPOSITS_H1
			  ,CASE WHEN (AVG_MONTH_END_BALANCE_DEPOSITS_H1 IS NULL AND AVG_MONTH_END_BALANCE_DEPOSITS_H2 IS  NULL ) THEN AVG_MONTH_END_BALANCE_DEPOSITS_H1 else (ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_H1,0) - ISNULL(AVG_MONTH_END_BALANCE_DEPOSITS_H2,0)) end [DFT_AVG_MONTH_END_BALANCE_DEPOSITS_H1_H2] 

			  --,SUM_LASTDIVAMOUNT_DEPOSITS_H1
			  ,CASE WHEN (SUM_LASTDIVAMOUNT_DEPOSITS_H1 IS NULL AND SUM_LASTDIVAMOUNT_DEPOSITS_H2 IS  NULL ) THEN SUM_LASTDIVAMOUNT_DEPOSITS_H1 else (ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_H1,0)-ISNULL(SUM_LASTDIVAMOUNT_DEPOSITS_H2,0)) end [DFT_SUM_LASTDIVAMOUNT_DEPOSITS_H1_H2]

			  --,AVG_CHARGEOFFAMOUNT_DEPOSITS_H1
			  ,CASE WHEN (AVG_CHARGEOFFAMOUNT_DEPOSITS_H1 IS NULL AND AVG_CHARGEOFFAMOUNT_DEPOSITS_H2 IS NULL) THEN AVG_CHARGEOFFAMOUNT_DEPOSITS_H1 else (ISNULL(AVG_CHARGEOFFAMOUNT_DEPOSITS_H1,0)-ISNULL(AVG_CHARGEOFFAMOUNT_DEPOSITS_H2,0)) end [DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_H1_H2]


			  ,[SAVINGS_StaticpoolFlag]
			  ,[CHECKING_StaticpoolFlag]
			  ,[CERTIFICATES_StaticpoolFlag]
			  ,[MONEYMARKET_StaticpoolFlag]
			  ,[IRA_StaticpoolFlag]

		into #membership_deposits
		FROM 
		(
	     (SELECT * 
		         ,CASE WHEN PRODUCT_SAVINGS_SP > 0 THEN 1 ELSE 0 END [SAVINGS_StaticpoolFlag]
				 ,CASE WHEN PRODUCT_CHECKING_SP > 0 THEN 1 ELSE 0 END [CHECKING_StaticpoolFlag]
				 ,CASE WHEN PRODUCT_CERTIFICATES_SP > 0 THEN 1 ELSE 0 END [CERTIFICATES_StaticpoolFlag]
				 ,CASE WHEN PRODUCT_MONEYMARKET_SP > 0 THEN 1 ELSE 0 END [MONEYMARKET_StaticpoolFlag]
				 ,CASE WHEN PRODUCT_IRA_SP > 0 THEN 1 ELSE 0 END [IRA_StaticpoolFlag]
				 ,CASE WHEN PRODUCT_HSA_SP > 0 THEN 1 ELSE 0 END [HSA_StaticpoolFlag]

		         ,CASE WHEN PRODUCT_SAVINGS_Q1 > 0 THEN 1 ELSE 0 END [SAVINGS_Q1Flag]
				 ,CASE WHEN PRODUCT_CHECKING_Q1 > 0 THEN 1 ELSE 0 END [CHECKING_Q1Flag]
				 ,CASE WHEN PRODUCT_CERTIFICATES_Q1 > 0 THEN 1 ELSE 0 END [CERTIFICATES_Q1Flag]
				 ,CASE WHEN PRODUCT_MONEYMARKET_Q1 > 0 THEN 1 ELSE 0 END [MONEYMARKET_Q1Flag]
				 ,CASE WHEN PRODUCT_IRA_Q1 > 0 THEN 1 ELSE 0 END [IRA_Q1Flag]
				 ,CASE WHEN PRODUCT_HSA_Q1 > 0 THEN 1 ELSE 0 END [HSA_Q1Flag]
		   FROM
		  (
			 SELECT SSN
              ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Staticpool') then UNID END) [PRODUCT_SAVINGS_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then UNID END) [PRODUCT_SAVINGS_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then UNID END) [PRODUCT_SAVINGS_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then UNID END) [PRODUCT_SAVINGS_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then UNID END) [PRODUCT_SAVINGS_Q4]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and HalfYearly = 'H1') then UNID END) [PRODUCT_SAVINGS_H1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and HalfYearly = 'H2') then UNID END) [PRODUCT_SAVINGS_H2]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Staticpool') then TYPE END) [TYPE_SAVINGS_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then TYPE END) [TYPE_SAVINGS_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then TYPE END) [TYPE_SAVINGS_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then TYPE END) [TYPE_SAVINGS_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then TYPE END) [TYPE_SAVINGS_Q4]
			  ,MIN(CASE WHEN Deposit_Flag = 'Savings' then Open_date END) [OPENDATE_SAVINGS]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' then Close_date END) [CLOSEDATE_SAVINGS]

			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' then MOB END) [MOB_SAVINGS]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_SAVINGS_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_SAVINGS_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_SAVINGS_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_SAVINGS_Q4]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and HalfYearly = 'H1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_SAVINGS_H1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and HalfYearly = 'H2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_SAVINGS_H2]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_SAVINGS_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_SAVINGS_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_SAVINGS_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_SAVINGS_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_SAVINGS_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_SAVINGS_Q4]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Savings' and HalfYearly = 'H1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_SAVINGS_H1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Savings' and HalfYearly = 'H2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_SAVINGS_H2]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_SAVINGS_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_SAVINGS_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_SAVINGS_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_SAVINGS_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_SAVINGS_Q4]
              ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and HalfYearly = 'H1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_SAVINGS_H1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Savings' and HalfYearly = 'H2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_SAVINGS_H2]


					       --- Previously only SUM_LASTDIVAMOUNT_SAVINGS_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SAVINGS_SP]
			  ,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SAVINGS_Q1]
			  ,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SAVINGS_Q2]
			  ,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SAVINGS_Q3]
			  ,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SAVINGS_Q4]
			  ,AVG(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SAVINGS_H1]
			  ,AVG(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_SAVINGS_H2]

              ,MAX(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Staticpool'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_SAVINGS_SP]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_SAVINGS_Q1]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_SAVINGS_Q2]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_SAVINGS_Q3]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_SAVINGS_Q4]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H1'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_SAVINGS_H1]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H2'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_SAVINGS_H2]

              ,MAX(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Staticpool'  then PENALTYYTD END) [PENALTYYTD_SAVINGS_SP]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1'  then PENALTYYTD END) [PENALTYYTD_SAVINGS_Q1]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2'  then PENALTYYTD END) [PENALTYYTD_SAVINGS_Q2]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3'  then PENALTYYTD END) [PENALTYYTD_SAVINGS_Q3]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4'  then PENALTYYTD END) [PENALTYYTD_SAVINGS_Q4]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H1'  then PENALTYYTD END) [PENALTYYTD_SAVINGS_H1]
			  ,MAX(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H2'  then PENALTYYTD END) [PENALTYYTD_SAVINGS_H2]

			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Staticpool') then UNID END) [PRODUCT_CHECKING_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then UNID END) [PRODUCT_CHECKING_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then UNID END) [PRODUCT_CHECKING_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then UNID END) [PRODUCT_CHECKING_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then UNID END) [PRODUCT_CHECKING_Q4]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and HalfYearly = 'H1') then UNID END) [PRODUCT_CHECKING_H1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and HalfYearly = 'H2') then UNID END) [PRODUCT_CHECKING_H2]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Staticpool') then TYPE END) [TYPE_CHECKING_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then TYPE END) [TYPE_CHECKING_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then TYPE END) [TYPE_CHECKING_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then TYPE END) [TYPE_CHECKING_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then TYPE END) [TYPE_CHECKING_Q4]

			  ,MIN(CASE WHEN Deposit_Flag = 'Checking' then Open_date END) [OPENDATE_CHECKING]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' then Close_date END) [CLOSEDATE_CHECKING]

			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' then MOB END) [MOB_CHECKING]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CHECKING_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CHECKING_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CHECKING_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CHECKING_Q4]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and HalfYearly = 'H1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CHECKING_H1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and HalfYearly = 'H2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CHECKING_H2]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_CHECKING_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_CHECKING_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CHECKING_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CHECKING_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CHECKING_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CHECKING_Q4]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Checking' and HalfYearly = 'H1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CHECKING_H1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Checking' and HalfYearly = 'H2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CHECKING_H2]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_CHECKING_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CHECKING_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CHECKING_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CHECKING_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CHECKING_Q4]
              ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and HalfYearly = 'H1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CHECKING_H1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Checking' and HalfYearly = 'H2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CHECKING_H2]

					       --- Previously only SUM_LASTDIVAMOUNT_CHECKING_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CHECKING_SP]
			  ,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CHECKING_Q1]
			  ,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CHECKING_Q2]
			  ,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CHECKING_Q3]
			  ,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CHECKING_Q4]
			  ,AVG(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CHECKING_H1]
			  ,AVG(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CHECKING_H2]

              ,MAX(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Staticpool'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_CHECKING_SP]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_CHECKING_Q1]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_CHECKING_Q2]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_CHECKING_Q3]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_CHECKING_Q4]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H1'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_CHECKING_H1]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H2'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_CHECKING_H2]

              ,MAX(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Staticpool'  then PENALTYYTD END) [PENALTYYTD_CHECKING_SP]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1'  then PENALTYYTD END) [PENALTYYTD_CHECKING_Q1]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2'  then PENALTYYTD END) [PENALTYYTD_CHECKING_Q2]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3'  then PENALTYYTD END) [PENALTYYTD_CHECKING_Q3]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4'  then PENALTYYTD END) [PENALTYYTD_CHECKING_Q4]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H1'  then PENALTYYTD END) [PENALTYYTD_CHECKING_H1]
			  ,MAX(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H2'  then PENALTYYTD END) [PENALTYYTD_CHECKING_H2]

              ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Staticpool') then UNID END) [PRODUCT_CERTIFICATES_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then UNID END) [PRODUCT_CERTIFICATES_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then UNID END) [PRODUCT_CERTIFICATES_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then UNID END) [PRODUCT_CERTIFICATES_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then UNID END) [PRODUCT_CERTIFICATES_Q4]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and HalfYearly = 'H1') then UNID END) [PRODUCT_CERTIFICATES_H1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and HalfYearly = 'H2') then UNID END) [PRODUCT_CERTIFICATES_H2]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Staticpool') then TYPE END) [TYPE_CERTIFICATES_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then TYPE END) [TYPE_CERTIFICATES_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then TYPE END) [TYPE_CERTIFICATES_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then TYPE END) [TYPE_CERTIFICATES_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then TYPE END) [TYPE_CERTIFICATES_Q4]

			  ,MIN(CASE WHEN Deposit_Flag = 'Certificates' then Open_date END) [OPENDATE_CERTIFICATES]
			  ,MAX(CASE WHEN Deposit_Flag = 'Certificates' then Close_date END) [CLOSEDATE_CERTIFICATES]

			  ,MAX(CASE WHEN Deposit_Flag = 'Certificates' then MOB END) [MOB_CERTIFICATES]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CERTIFICATES_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CERTIFICATES_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CERTIFICATES_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CERTIFICATES_Q4]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and HalfYearly = 'H1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CERTIFICATES_H1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and HalfYearly = 'H2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_CERTIFICATES_H2]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_CERTIFICATES_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CERTIFICATES_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CERTIFICATES_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CERTIFICATES_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CERTIFICATES_Q4]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Certificates' and HalfYearly = 'H1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CERTIFICATES_H1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'Certificates' and HalfYearly = 'H2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_CERTIFICATES_H2]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_CERTIFICATES_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CERTIFICATES_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CERTIFICATES_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CERTIFICATES_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CERTIFICATES_Q4]
              ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and HalfYearly = 'H1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CERTIFICATES_H1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'Certificates' and HalfYearly = 'H2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_CERTIFICATES_H2]

					       --- Previously only SUM_LASTDIVAMOUNT_CERTIFICATES_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CERTIFICATES_SP]
			  ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q1]
			  ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q2]
			  ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q3]
			  ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CERTIFICATES_Q4]
			  ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CERTIFICATES_H1]
			  ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_CERTIFICATES_H2]

              ,MAX(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Staticpool'  then PENALTYYTD END) [PENALTYYTD_CERTIFICATES_SP]
			  ,MAX(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1'  then PENALTYYTD END) [PENALTYYTD_CERTIFICATES_Q1]
			  ,MAX(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2'  then PENALTYYTD END) [PENALTYYTD_CERTIFICATES_Q2]
			  ,MAX(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3'  then PENALTYYTD END) [PENALTYYTD_CERTIFICATES_Q3]
			  ,MAX(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4'  then PENALTYYTD END) [PENALTYYTD_CERTIFICATES_Q4]
			  ,MAX(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H1'  then PENALTYYTD END) [PENALTYYTD_CERTIFICATES_H1]
			  ,MAX(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H2'  then PENALTYYTD END) [PENALTYYTD_CERTIFICATES_H2]

              ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Staticpool') then UNID END) [PRODUCT_MONEYMARKET_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then UNID END) [PRODUCT_MONEYMARKET_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then UNID END) [PRODUCT_MONEYMARKET_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then UNID END) [PRODUCT_MONEYMARKET_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then UNID END) [PRODUCT_MONEYMARKET_Q4]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1') then UNID END) [PRODUCT_MONEYMARKET_H1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2') then UNID END) [PRODUCT_MONEYMARKET_H2]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Staticpool') then TYPE END) [TYPE_MONEYMARKET_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then TYPE END) [TYPE_MONEYMARKET_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then TYPE END) [TYPE_MONEYMARKET_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then TYPE END) [TYPE_MONEYMARKET_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then TYPE END) [TYPE_MONEYMARKET_Q4]
			  ,MIN(CASE WHEN Deposit_Flag = 'MoneyMarket' then Open_date END) [OPENDATE_MONEYMARKET]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' then Close_date END) [CLOSEDATE_MONEYMARKET]

			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' then MOB END) [MOB_MONEYMARKET]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_MONEYMARKET_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_MONEYMARKET_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_MONEYMARKET_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_MONEYMARKET_Q4]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_MONEYMARKET_H1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_MONEYMARKET_H2]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_MONEYMARKET_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_MONEYMARKET_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_MONEYMARKET_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_MONEYMARKET_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_MONEYMARKET_Q4]
			  ,AVG(CASE WHEN (Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_MONEYMARKET_H1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_MONEYMARKET_H2]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_MONEYMARKET_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_Q4]
              ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_H1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_MONEYMARKET_H2]

					       --- Previously only SUM_LASTDIVAMOUNT_MONEYMARKET_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_MONEYMARKET_SP]
			  ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q1]
			  ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q2]
			  ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q3]
			  ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_MONEYMARKET_Q4]
			  ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_MONEYMARKET_H1]
			  ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_MONEYMARKET_H2]

              ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Staticpool'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_MONEYMARKET_SP]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_MONEYMARKET_Q1]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_MONEYMARKET_Q2]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_MONEYMARKET_Q3]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_MONEYMARKET_Q4]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_MONEYMARKET_H1]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2'  then OVERDRAFTFEEYTD END) [OVERDRAFTFEEYTD_MONEYMARKET_H2]

              ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Staticpool'  then PENALTYYTD END) [PENALTYYTD_MONEYMARKET_SP]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1'  then PENALTYYTD END) [PENALTYYTD_MONEYMARKET_Q1]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2'  then PENALTYYTD END) [PENALTYYTD_MONEYMARKET_Q2]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3'  then PENALTYYTD END) [PENALTYYTD_MONEYMARKET_Q3]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4'  then PENALTYYTD END) [PENALTYYTD_MONEYMARKET_Q4]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1'  then PENALTYYTD END) [PENALTYYTD_MONEYMARKET_H1]
			  ,MAX(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2'  then PENALTYYTD END) [PENALTYYTD_MONEYMARKET_H2]

              ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Staticpool') then UNID END) [PRODUCT_IRA_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q1') then UNID END) [PRODUCT_IRA_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q2') then UNID END) [PRODUCT_IRA_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q3') then UNID END) [PRODUCT_IRA_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q4') then UNID END) [PRODUCT_IRA_Q4]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and HalfYearly = 'H1') then UNID END) [PRODUCT_IRA_H1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and HalfYearly = 'H2') then UNID END) [PRODUCT_IRA_H2]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Staticpool') then TYPE END) [TYPE_IRA_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q1') then TYPE END) [TYPE_IRA_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q2') then TYPE END) [TYPE_IRA_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q3') then TYPE END) [TYPE_IRA_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q4') then TYPE END) [TYPE_IRA_Q4]
			  ,MIN(CASE WHEN Deposit_Flag = 'IRA' then Open_date END) [OPENDATE_IRA]
			  ,MAX(CASE WHEN Deposit_Flag = 'IRA' then Close_date END) [CLOSEDATE_IRA]

			  ,MAX(CASE WHEN Deposit_Flag = 'IRA' then MOB END) [MOB_IRA]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_IRA_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_IRA_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_IRA_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_IRA_Q4]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and HalfYearly = 'H1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_IRA_H1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and HalfYearly = 'H2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_IRA_H2]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_IRA_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_IRA_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_IRA_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_IRA_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_IRA_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_IRA_Q4]
			  ,AVG(CASE WHEN (Deposit_Flag = 'IRA' and HalfYearly = 'H1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_IRA_H1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'IRA' and HalfYearly = 'H2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_IRA_H2]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_IRA_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_IRA_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_IRA_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_IRA_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_IRA_Q4]
              ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and HalfYearly = 'H1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_IRA_H1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'IRA' and HalfYearly = 'H2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_IRA_H2]

					       --- Previously only SUM_LASTDIVAMOUNT_IRA_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_IRA_SP]
			  ,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_IRA_Q1]
			  ,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_IRA_Q2]
			  ,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_IRA_Q3]
			  ,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_IRA_Q4]
			  ,AVG(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_IRA_H1]
			  ,AVG(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_IRA_H2]

              ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Staticpool') then UNID END) [PRODUCT_HSA_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q1') then UNID END) [PRODUCT_HSA_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q2') then UNID END) [PRODUCT_HSA_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q3') then UNID END) [PRODUCT_HSA_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q4') then UNID END) [PRODUCT_HSA_Q4]
					
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Staticpool') then TYPE END) [TYPE_HSA_SP]
		      ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q1') then TYPE END) [TYPE_HSA_Q1]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q2') then TYPE END) [TYPE_HSA_Q2]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q3') then TYPE END) [TYPE_HSA_Q3]
			  ,COUNT(DISTINCT CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q4') then TYPE END) [TYPE_HSA_Q4]
			  ,MIN(CASE WHEN Deposit_Flag = 'HSA' then Open_date END) [OPENDATE_HSA]
			  ,MAX(CASE WHEN Deposit_Flag = 'HSA' then Close_date END) [CLOSEDATE_HSA]

			  ,MAX(CASE WHEN Deposit_Flag = 'HSA' then MOB END) [MOB_HSA]
			  
			  ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q1') then Month_end_balance END) [SUM_MONTH_END_BALANCE_HSA_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q2') then Month_end_balance END) [SUM_MONTH_END_BALANCE_HSA_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q3') then Month_end_balance END) [SUM_MONTH_END_BALANCE_HSA_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q4') then Month_end_balance END) [SUM_MONTH_END_BALANCE_HSA_Q4]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_HSA_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_HSA_Q1_Q4 was taken 

			  ,AVG(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q1') then Month_end_balance END) [AVG_MONTH_END_BALANCE_HSA_Q1]
			  ,AVG(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q2') then Month_end_balance END) [AVG_MONTH_END_BALANCE_HSA_Q2]
			  ,AVG(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q3') then Month_end_balance END) [AVG_MONTH_END_BALANCE_HSA_Q3]
			  ,AVG(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q4') then Month_end_balance END) [AVG_MONTH_END_BALANCE_HSA_Q4]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_HSA_Q1 was taken 

              ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q1') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_HSA_Q1]
			  ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q2') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_HSA_Q2]
			  ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q3') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_HSA_Q3]
			  ,SUM(CASE WHEN (Deposit_Flag = 'HSA' and Quarters = 'Q4') then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_HSA_Q4]

					       --- Previously only SUM_LASTDIVAMOUNT_HSA_Q1 was taken

              ,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_HSA_SP]
			  ,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_HSA_Q1]
			  ,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_HSA_Q2]
			  ,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_HSA_Q3]
			  ,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_HSA_Q4]

		    FROM #deposits_account_data
		    group by SSN
			 ) P
			) A
			LEFT JOIN 
			(
			SELECT SSN
              ,COUNT(DISTINCT CASE WHEN Quarters = 'Staticpool' then UNID END) [PRODUCT_DEPOSITS_SP]
		      ,COUNT(DISTINCT CASE WHEN Quarters = 'Q1'then UNID END) [PRODUCT_DEPOSITS_Q1]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q2'then UNID END) [PRODUCT_DEPOSITS_Q2]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q3'then UNID END) [PRODUCT_DEPOSITS_Q3]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q4'then UNID END) [PRODUCT_DEPOSITS_Q4]
		      ,COUNT(DISTINCT CASE WHEN HalfYearly = 'H1'then UNID END) [PRODUCT_DEPOSITS_H1]
			  ,COUNT(DISTINCT CASE WHEN HalfYearly = 'H2'then UNID END) [PRODUCT_DEPOSITS_H2]
					
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Staticpool' then TYPE END) [TYPE_DEPOSITS_SP]
		      ,COUNT(DISTINCT CASE WHEN Quarters = 'Q1' then TYPE END) [TYPE_DEPOSITS_Q1]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q2' then TYPE END) [TYPE_DEPOSITS_Q2]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q3' then TYPE END) [TYPE_DEPOSITS_Q3]
			  ,COUNT(DISTINCT CASE WHEN Quarters = 'Q4' then TYPE END) [TYPE_DEPOSITS_Q4]
			  ,MIN(Open_date) [MIN_OPENDATE_DEPOSITS]
			  ,MAX(Close_date) [MAX_CLOSEDATE_DEPOSITS]

			  ,MAX( MOB ) [MOB_DEPOSITS]
			  
			  ,SUM(CASE WHEN Quarters = 'Q1' then Month_end_balance END) [SUM_MONTH_END_BALANCE_DEPOSITS_Q1]
			  ,SUM(CASE WHEN Quarters = 'Q2' then Month_end_balance END) [SUM_MONTH_END_BALANCE_DEPOSITS_Q2]
			  ,SUM(CASE WHEN Quarters = 'Q3' then Month_end_balance END) [SUM_MONTH_END_BALANCE_DEPOSITS_Q3]
			  ,SUM(CASE WHEN Quarters = 'Q4' then Month_end_balance END) [SUM_MONTH_END_BALANCE_DEPOSITS_Q4]

					       --- Previously only DFT_SUM_MONTH_END_BALANCE_DEPOSITS_Q1_Q2, DFT_SUM_MONTH_END_BALANCE_DEPOSITS_Q1_Q4 was taken 

			  ,AVG(CASE WHEN Quarters = 'Q1' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q1]
			  ,AVG(CASE WHEN Quarters = 'Q2' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q2]
			  ,AVG(CASE WHEN Quarters = 'Q3' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q3]
			  ,AVG(CASE WHEN Quarters = 'Q4' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_Q4]
			  ,AVG(CASE WHEN HalfYearly = 'H1' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_H1]
			  ,AVG(CASE WHEN HalfYearly = 'H2' then Month_end_balance END) [AVG_MONTH_END_BALANCE_DEPOSITS_H2]
			        
					       --- Previously only AVG_MONTH_END_BALANCE_DEPOSITS_Q1 was taken 

              ,SUM(CASE WHEN Quarters = 'Q1' then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_DEPOSITS_Q1]
			  ,SUM(CASE WHEN Quarters = 'Q2' then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_DEPOSITS_Q2]
			  ,SUM(CASE WHEN Quarters = 'Q3' then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_DEPOSITS_Q3]
			  ,SUM(CASE WHEN Quarters = 'Q4' then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_DEPOSITS_Q4]
              ,SUM(CASE WHEN HalfYearly = 'H1' then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_DEPOSITS_H1]
			  ,SUM(CASE WHEN HalfYearly = 'H2' then LASTDIVAMOUNT END) [SUM_LASTDIVAMOUNT_DEPOSITS_H2]

					       --- Previously only SUM_LASTDIVAMOUNT_DEPOSITS_Q1 was taken

              ,AVG(CASE WHEN  Quarters = 'Staticpool'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_DEPOSITS_SP]	
			  ,AVG(CASE WHEN  Quarters = 'Q1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1]	
			  ,AVG(CASE WHEN  Quarters = 'Q2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_DEPOSITS_Q2]	
			  ,AVG(CASE WHEN  Quarters = 'Q3'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_DEPOSITS_Q3]		
			  ,AVG(CASE WHEN  Quarters = 'Q4'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_DEPOSITS_Q4]		
			  ,AVG(CASE WHEN  HalfYearly = 'H1'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_DEPOSITS_H1]	
			  ,AVG(CASE WHEN  HalfYearly = 'H2'  then CHARGEOFFAMOUNT END) [AVG_CHARGEOFFAMOUNT_DEPOSITS_H2]

			FROM #deposits_account_data
			group by SSN
			) B
			ON A.SSN = B.SSN
		 
		) 

		---Refer 5199 line of Previous Data Creation

		--SELECT TOP 100 * FROM #membership_deposits

		--SELECT TOP 100 * FROM ARCUSYM000..SAVINGSTRANSACTION
		
		--SELECT TOP 100 * FROM #deposits_account_data


------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Transaction Data (ShareCategorywise) ***\\\-----------------------------------------------

     DROP TABLE IF EXISTS #static_unid_deposits
     
     SELECT UNID,PARENTACCOUNT,Deposit_Flag,Process_Date
     into #static_unid_deposits
     from #deposits_account_data

     DROP TABLE IF EXISTS #deposit_transaction_temp1
     SELECT B.Deposit_Flag
			,case when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(dateadd(month,-10,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-11,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-12,@staticpooldate)),112),6))) then 'Q4'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(dateadd(month,-7,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-8,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-9,@staticpooldate)),112),6))) then 'Q3'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(dateadd(month,-4,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-5,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-6,@staticpooldate)),112),6))) then 'Q2'
		    when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(dateadd(month,-3,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-2,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-1,@staticpooldate)),112),6))) then 'Q1'
		    when EFFECTIVEDATE_v1 in (left(convert(varchar,@staticpooldate,112),6)) then 'Staticpool' end Quarters
		    ,case when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(DATEADD(month,-12,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-11,@staticpooldate)),112),6)),(left(convert(varchar,DATEADD(month,-10,@staticpooldate),112),6))
			                              ,(left(convert(varchar,EOMONTH(DATEADD(month,-9,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-8,@staticpooldate)),112),6)),(left(convert(varchar,DATEADD(month,-7,@staticpooldate),112),6))) then 'H2'
 		    	  when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(DATEADD(month,-6,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-5,@staticpooldate)),112),6)),(left(convert(varchar,DATEADD(month,-4,@staticpooldate),112),6))
				                          ,(left(convert(varchar,EOMONTH(DATEADD(month,-3,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH((DATEADD(month,-2,@staticpooldate))),112),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-1,@staticpooldate)),112),6))) then 'H1'
		     end HalfYearly	
	
	 ,A.*
	 ,C.SSN
	    into #deposit_transaction_temp1
		from 
		(
		SELECT  [PARENTACCOUNT]
      ,[PARENTID]
	  ,CONCAT(PARENTACCOUNT,PARENTID) UNID
      --,[COMMENTCODE]
      --,[TRANSFERCODE]
      --,[ADJUSTMENTCODE]
      --,[REGECODE]
      --,[REGDCHECKCODE]
      --,[REGDTRANSFERCODE]
      --,[VOIDCODE]
      --,[SUBACTIONCODE]
      --,[SEQUENCENUMBER]
      ,cast([EFFECTIVEDATE] as date) [EFFECTIVEDATE]
      --,[POSTDATE]
      --,[POSTTIME]
      --,[USERNUMBER]
      --,[USEROVERRIDE]
      --,[SECURITYLEVELS]
      ,[DESCRIPTION]
      ,[ACTIONCODE]
      ,[SOURCECODE]
      ,[BALANCECHANGE]
	  ,case when BALANCECHANGE >=0 then BALANCECHANGE else 0 end Deposited_amount
	  , case when BALANCECHANGE <0 then BALANCECHANGE else 0 end withdrawl_amount
	  ,[INTEREST]
      ,[NEWBALANCE]
      ,[FEEAMOUNT]
      --,[ESCROWAMOUNT]
      ,[LASTTRANDATE]
      --,[MATURITYLOANDUEDATE]
      --,[COMMENT]
      --,[BRANCH]
      --,[CONSOLENUMBER]
      --,[BATCHSEQUENCE]
      --,[SALESTAXAMOUNT]
      --,[ACTIVITYDATE]
      --,[BILLEDFEEAMOUNT]
      --,[PROCESSORUSER]
      --,[MEMBERBRANCH]
      --,[PREVAVAILBALANCE]
      --,[SUBSOURCE]
      --,[CONFIRMATIONSEQ]
      --,[MICRACCTNUM]
      --,[MICRRT]
      --,[RECURRINGTRAN]
      --,[FEEEXMTCRTSYAMT]
      --,[ESCROWUNPAIDBALCHG]
      --,[ESCROWAPPLIEDBALCHG]
      --,[UNAPPLIEDPARTIALPMTCHG]
      --,[FEECOUNTBY]
      --,[BALSEGCOUNT]
      --,[LATECHGWAIVEDAMT]
      --,[LATECHGUNPAIDCHGAMT]
      --,[PREVLATECHGDATE]
      --,[PREVLATECHGACCRUED]
      --,[LATECHGFIELDSVALID]
      --,[BALSEGID1]
      --,[BALSEGPMTCHANGEDATE1]
      --,[INTEFFECTDATE]
      --,[BALSEGPREVFIRSTPMTDATE1]
	  ,case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE))
		 else CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVEDATE_v1
	 FROM [ARCUSYM000].[dbo].[SAVINGSTRANSACTION]
	  WHERE  ACTIONCODE!='C') A
	 left join #static_unid_deposits B
	 ON A.UNID = B.UNID
	 left join #Static_SSN_account C
	 on A.PARENTACCOUNT = C.AccountNumber
	 --and A.EFFECTIVEDATE_v1 = B.Process_Date
	-- day wise data include all dates 
	where EFFECTIVEDATE_v1 between left(convert(varchar,EOMONTH(dateadd(month,-12,@staticpooldate)),112),6) and left(convert(varchar,@staticpooldate,112),6)
  
  
   
--select PARENTACCOUNT,PARENTID,UNID
--			,count(*) Transaction_COUNT
--			,sum(BALANCECHANGE) Transaction_amount
--			,AVG(BALANCECHANGE) AVG_BALANCECHANGE
--			,sum(Deposited_amount) Deposited_amount
--			,count(Deposited_amount) Deposited_count
--			,sum(withdrawl_amount) withdrawal_amount
--			,count(withdrawl_amount) withdrawal_count
--			,sum(INTEREST) Sum_INTEREST
--			,EFFECTIVEDATE_v1
--		into ##Certificates_transaction

        DROP TABLE IF EXISTS #deposit_transaction_temp2
            
  --      SELECT B.SSN
  --              ,A.*
  --      INTO #deposit_transaction_temp2 
  --      From
		--(
		 SELECT * 
		 INTO #deposit_transaction_temp2 
		 FROM
		 (
          (SELECT  SSN
		        --,PARENTACCOUNT
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_SAVINGS_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H1' THEN 1 END) [TRANSACTION_COUNT_SAVINGS_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H2' THEN 1 END) [TRANSACTION_COUNT_SAVINGS_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_SAVINGS_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_SAVINGS_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_SAVINGS_H2]
           
                ,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_TRANSACTION_SAVINGS_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_TRANSACTION_SAVINGS_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_TRANSACTION_SAVINGS_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_TRANSACTION_SAVINGS_Q4]
                ,AVG(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H1' THEN BALANCECHANGE END) [AVG_TRANSACTION_SAVINGS_H1]
            	,AVG(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H2' THEN BALANCECHANGE END) [AVG_TRANSACTION_SAVINGS_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_SAVINGS_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_SAVINGS_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_SAVINGS_H2]					
            		
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN 1 END) [DEPOSITED_COUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN 1 END) [DEPOSITED_COUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN 1 END) [DEPOSITED_COUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN 1 END) [DEPOSITED_COUNT_SAVINGS_Q4]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H1' THEN 1 END) [DEPOSITED_COUNT_SAVINGS_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H2' THEN 1 END) [DEPOSITED_COUNT_SAVINGS_H2]

            
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_SAVINGS_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_SAVINGS_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_SAVINGS_H2]
            
                ,COUNT(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_SAVINGS_Q1]
            	,COUNT(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_SAVINGS_Q2]
            	,COUNT(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_SAVINGS_Q3]
            	,COUNT(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_SAVINGS_Q4]
                ,COUNT(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H1' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_SAVINGS_H1]
            	,COUNT(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H2' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_SAVINGS_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_SAVINGS_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_SAVINGS_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_SAVINGS_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_SAVINGS_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H1' THEN INTEREST END) [SUM_INTEREST_SAVINGS_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Savings' and HalfYearly = 'H2' THEN INTEREST END) [SUM_INTEREST_SAVINGS_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_CHECKING_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H1' THEN 1 END) [TRANSACTION_COUNT_CHECKING_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H2' THEN 1 END) [TRANSACTION_COUNT_CHECKING_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CHECKING_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CHECKING_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CHECKING_H2]
            
                ,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_TRANSACTION_CHECKING_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_TRANSACTION_CHECKING_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_TRANSACTION_CHECKING_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_TRANSACTION_CHECKING_Q4]
                ,AVG(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H1' THEN BALANCECHANGE END) [AVG_TRANSACTION_CHECKING_H1]
            	,AVG(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H2' THEN BALANCECHANGE END) [AVG_TRANSACTION_CHECKING_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CHECKING_Q4]	
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CHECKING_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CHECKING_H2]
            		
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_COUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_COUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_COUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_COUNT_CHECKING_Q4]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H1' THEN Deposited_amount END) [DEPOSITED_COUNT_CHECKING_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H2' THEN Deposited_amount END) [DEPOSITED_COUNT_CHECKING_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CHECKING_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CHECKING_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CHECKING_H2]

				,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN 1 END) [WITHDRAWAL_COUNT_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN 1 END) [WITHDRAWAL_COUNT_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN 1 END) [WITHDRAWAL_COUNT_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN 1 END) [WITHDRAWAL_COUNT_CHECKING_Q4]
				,SUM(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H1' THEN 1 END) [WITHDRAWAL_COUNT_CHECKING_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H2' THEN 1 END) [WITHDRAWAL_COUNT_CHECKING_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_CHECKING_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_CHECKING_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_CHECKING_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_CHECKING_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H1' THEN INTEREST END) [SUM_INTEREST_CHECKING_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Checking' and HalfYearly = 'H2' THEN INTEREST END) [SUM_INTEREST_CHECKING_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_CERTIFICATES_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H1' THEN 1 END) [TRANSACTION_COUNT_CERTIFICATES_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H2' THEN 1 END) [TRANSACTION_COUNT_CERTIFICATES_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_CERTIFICATES_H2]
            
                ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_TRANSACTION_CERTIFICATES_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_TRANSACTION_CERTIFICATES_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_TRANSACTION_CERTIFICATES_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_TRANSACTION_CERTIFICATES_Q4]
                ,AVG(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H1' THEN BALANCECHANGE END) [AVG_TRANSACTION_CERTIFICATES_H1]
            	,AVG(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H2' THEN BALANCECHANGE END) [AVG_TRANSACTION_CERTIFICATES_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CERTIFICATES_Q4]	
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CERTIFICATES_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_CERTIFICATES_H2]
            		
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN 1 END) [DEPOSITED_COUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN 1 END) [DEPOSITED_COUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN 1 END) [DEPOSITED_COUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN 1 END) [DEPOSITED_COUNT_CERTIFICATES_Q4]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H1' THEN 1 END) [DEPOSITED_COUNT_CERTIFICATES_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H2' THEN 1 END) [DEPOSITED_COUNT_CERTIFICATES_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CERTIFICATES_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CERTIFICATES_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_CERTIFICATES_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN 1 END) [WITHDRAWAL_COUNT_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN 1 END) [WITHDRAWAL_COUNT_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN 1 END) [WITHDRAWAL_COUNT_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN 1 END) [WITHDRAWAL_COUNT_CERTIFICATES_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H1' THEN 1 END) [WITHDRAWAL_COUNT_CERTIFICATES_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H2' THEN 1 END) [WITHDRAWAL_COUNT_CERTIFICATES_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_CERTIFICATES_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_CERTIFICATES_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_CERTIFICATES_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_CERTIFICATES_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H1' THEN INTEREST END) [SUM_INTEREST_CERTIFICATES_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'Certificates' and HalfYearly = 'H2' THEN INTEREST END) [SUM_INTEREST_CERTIFICATES_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_MONEYMARKET_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1' THEN 1 END) [TRANSACTION_COUNT_MONEYMARKET_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2' THEN 1 END) [TRANSACTION_COUNT_MONEYMARKET_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_MONEYMARKET_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_MONEYMARKET_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_MONEYMARKET_H2]
            
                ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_TRANSACTION_MONEYMARKET_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_TRANSACTION_MONEYMARKET_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_TRANSACTION_MONEYMARKET_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_TRANSACTION_MONEYMARKET_Q4]
                ,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1' THEN BALANCECHANGE END) [AVG_TRANSACTION_MONEYMARKET_H1]
            	,AVG(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2' THEN BALANCECHANGE END) [AVG_TRANSACTION_MONEYMARKET_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_MONEYMARKET_Q4]	
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_MONEYMARKET_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_MONEYMARKET_H2]
            		
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN 1 END) [DEPOSITED_COUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN 1 END) [DEPOSITED_COUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN 1 END) [DEPOSITED_COUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN 1 END) [DEPOSITED_COUNT_MONEYMARKET_Q4]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1' THEN 1 END) [DEPOSITED_COUNT_MONEYMARKET_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2' THEN 1 END) [DEPOSITED_COUNT_MONEYMARKET_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_MONEYMARKET_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_MONEYMARKET_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_MONEYMARKET_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN 1 END) [WITHDRAWAL_COUNT_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN 1 END) [WITHDRAWAL_COUNT_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN 1 END) [WITHDRAWAL_COUNT_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN 1 END) [WITHDRAWAL_COUNT_MONEYMARKET_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1' THEN 1 END) [WITHDRAWAL_COUNT_MONEYMARKET_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2' THEN 1 END) [WITHDRAWAL_COUNT_MONEYMARKET_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_MONEYMARKET_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_MONEYMARKET_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_MONEYMARKET_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_MONEYMARKET_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H1' THEN INTEREST END) [SUM_INTEREST_MONEYMARKET_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'MoneyMarket' and HalfYearly = 'H2' THEN INTEREST END) [SUM_INTEREST_MONEYMARKET_H2]

                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_IRA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_IRA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_IRA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_IRA_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H1' THEN 1 END) [TRANSACTION_COUNT_IRA_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H2' THEN 1 END) [TRANSACTION_COUNT_IRA_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_IRA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_IRA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_IRA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_IRA_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_IRA_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_IRA_H2]
            
                ,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_TRANSACTION_IRA_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_TRANSACTION_IRA_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_TRANSACTION_IRA_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_TRANSACTION_IRA_Q4]
                ,AVG(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H1' THEN BALANCECHANGE END) [AVG_TRANSACTION_IRA_H1]
            	,AVG(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H2' THEN BALANCECHANGE END) [AVG_TRANSACTION_IRA_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_IRA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_IRA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_IRA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_IRA_Q4]	
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_IRA_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_IRA_H2]
            		
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN 1 END) [DEPOSITED_COUNT_IRA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN 1 END) [DEPOSITED_COUNT_IRA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN 1 END) [DEPOSITED_COUNT_IRA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN 1 END) [DEPOSITED_COUNT_IRA_Q4]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H1' THEN 1 END) [DEPOSITED_COUNT_IRA_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H2' THEN 1 END) [DEPOSITED_COUNT_IRA_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_IRA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_IRA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_IRA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_IRA_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_IRA_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_IRA_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN 1 END) [WITHDRAWAL_COUNT_IRA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN 1 END) [WITHDRAWAL_COUNT_IRA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN 1 END) [WITHDRAWAL_COUNT_IRA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN 1 END) [WITHDRAWAL_COUNT_IRA_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H1' THEN 1 END) [WITHDRAWAL_COUNT_IRA_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H2' THEN 1 END) [WITHDRAWAL_COUNT_IRA_H2]
            
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_IRA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_IRA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_IRA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_IRA_Q4]
                ,SUM(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H1' THEN INTEREST END) [SUM_INTEREST_IRA_H1]
            	,SUM(CASE WHEN Deposit_Flag = 'IRA' and HalfYearly = 'H2' THEN INTEREST END) [SUM_INTEREST_IRA_H2]

                ,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_HSA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_HSA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_HSA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_HSA_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_HSA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_HSA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_HSA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_HSA_Q4]
            
                ,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_TRANSACTION_HSA_Q1]
            	,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_TRANSACTION_HSA_Q2]
            	,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_TRANSACTION_HSA_Q3]
            	,AVG(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_TRANSACTION_HSA_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_HSA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_HSA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_HSA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_HSA_Q4]	
            		
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN 1 END) [DEPOSITED_COUNT_HSA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN 1 END) [DEPOSITED_COUNT_HSA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN 1 END) [DEPOSITED_COUNT_HSA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN 1 END) [DEPOSITED_COUNT_HSA_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_HSA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_HSA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_HSA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_HSA_Q4]
            
                ,COUNT(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_HSA_Q1]
            	,COUNT(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_HSA_Q2]
            	,COUNT(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_HSA_Q3]
            	,COUNT(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_HSA_Q4]
            
                ,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_HSA_Q1]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_HSA_Q2]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_HSA_Q3]
            	,SUM(CASE WHEN Deposit_Flag = 'HSA' and Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_HSA_Q4]

        from #deposit_transaction_temp1
        --group by PARENTACCOUNT
		group by SSN ) P
		LEFT JOIN 
		(SELECT SSN [SSN_D]
		 --PARENTACCOUNT [P_D]
                ,SUM(CASE WHEN Quarters = 'Q1' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_Q4]
                ,SUM(CASE WHEN HalfYearly = 'H1' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_H1]
            	,SUM(CASE WHEN HalfYearly = 'H2' THEN 1 END) [TRANSACTION_COUNT_DEPOSITS_H2]
            
                ,SUM(CASE WHEN Quarters = 'Q1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_DEPOSITS_Q4]
                ,SUM(CASE WHEN HalfYearly = 'H1' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_DEPOSITS_H1]
            	,SUM(CASE WHEN HalfYearly = 'H2' THEN BALANCECHANGE END) [TRANSACTION_AMOUNT_DEPOSITS_H2]
            
                ,AVG(CASE WHEN Quarters = 'Q1' THEN BALANCECHANGE END) [AVG_TRANSACTION_DEPOSITS_Q1]
            	,AVG(CASE WHEN Quarters = 'Q2' THEN BALANCECHANGE END) [AVG_TRANSACTION_DEPOSITS_Q2]
            	,AVG(CASE WHEN Quarters = 'Q3' THEN BALANCECHANGE END) [AVG_TRANSACTION_DEPOSITS_Q3]
            	,AVG(CASE WHEN Quarters = 'Q4' THEN BALANCECHANGE END) [AVG_TRANSACTION_DEPOSITS_Q4]
                ,AVG(CASE WHEN HalfYearly = 'H1' THEN BALANCECHANGE END) [AVG_TRANSACTION_DEPOSITS_H1]
            	,AVG(CASE WHEN HalfYearly = 'H2' THEN BALANCECHANGE END) [AVG_TRANSACTION_DEPOSITS_H2]
            
                ,SUM(CASE WHEN Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_AMOUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_AMOUNT_DEPOSITS_Q4]	
                ,SUM(CASE WHEN HalfYearly = 'H1' THEN Deposited_amount END) [DEPOSITED_AMOUNT_DEPOSITS_H1]
            	,SUM(CASE WHEN HalfYearly = 'H2' THEN Deposited_amount END) [DEPOSITED_AMOUNT_DEPOSITS_H2]
            		
            	,SUM(CASE WHEN Quarters = 'Q1' THEN Deposited_amount END) [DEPOSITED_COUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN Deposited_amount END) [DEPOSITED_COUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN Deposited_amount END) [DEPOSITED_COUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN Deposited_amount END) [DEPOSITED_COUNT_DEPOSITS_Q4]
            	,SUM(CASE WHEN HalfYearly = 'H1' THEN Deposited_amount END) [DEPOSITED_COUNT_DEPOSITS_H1]
            	,SUM(CASE WHEN HalfYearly = 'H2' THEN Deposited_amount END) [DEPOSITED_COUNT_DEPOSITS_H2]
            
                ,SUM(CASE WHEN Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_Q4]
                ,SUM(CASE WHEN HalfYearly = 'H1' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_H1]
            	,SUM(CASE WHEN HalfYearly = 'H2' THEN withdrawl_amount END) [WITHDRAWAL_AMOUNT_DEPOSITS_H2]
            
                ,COUNT(CASE WHEN Quarters = 'Q1' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_DEPOSITS_Q1]
            	,COUNT(CASE WHEN Quarters = 'Q2' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_DEPOSITS_Q2]
            	,COUNT(CASE WHEN Quarters = 'Q3' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_DEPOSITS_Q3]
            	,COUNT(CASE WHEN Quarters = 'Q4' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_DEPOSITS_Q4]
                ,COUNT(CASE WHEN HalfYearly = 'H1' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_DEPOSITS_H1]
            	,COUNT(CASE WHEN HalfYearly = 'H2' THEN withdrawl_amount END) [WITHDRAWAL_COUNT_DEPOSITS_H2]
            
                ,SUM(CASE WHEN Quarters = 'Q1' THEN INTEREST END) [SUM_INTEREST_DEPOSITS_Q1]
            	,SUM(CASE WHEN Quarters = 'Q2' THEN INTEREST END) [SUM_INTEREST_DEPOSITS_Q2]
            	,SUM(CASE WHEN Quarters = 'Q3' THEN INTEREST END) [SUM_INTEREST_DEPOSITS_Q3]
            	,SUM(CASE WHEN Quarters = 'Q4' THEN INTEREST END) [SUM_INTEREST_DEPOSITS_Q4]	
                ,SUM(CASE WHEN HalfYearly = 'H1' THEN INTEREST END) [SUM_INTEREST_DEPOSITS_H1]
            	,SUM(CASE WHEN HalfYearly = 'H2' THEN INTEREST END) [SUM_INTEREST_DEPOSITS_H2]	
								
		FROM #deposit_transaction_temp1
		--group by PARENTACCOUNT 
		group by SSN) Q
		ON P.SSN = Q.SSN_D
		) 
  --      left join #Static_SSN_account B
  --      on A.PARENTACCOUNT = B.AccountNumber

		DROP TABLE IF EXISTS #deposits_transaction

		SELECT SSN [SSN004]
		      , [TRANSACTION_COUNT_SAVINGS_Q1] 
			  , CASE WHEN ( TRANSACTION_COUNT_SAVINGS_Q1 IS NULL AND TRANSACTION_COUNT_SAVINGS_Q2 IS  NULL ) THEN TRANSACTION_COUNT_SAVINGS_Q1 else (ISNULL(TRANSACTION_COUNT_SAVINGS_Q1,0) - ISNULL(TRANSACTION_COUNT_SAVINGS_Q2,0)) end DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2

			  , [TRANSACTION_AMOUNT_SAVINGS_Q1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_SAVINGS_Q1 IS NULL AND TRANSACTION_AMOUNT_SAVINGS_Q2 IS  NULL ) THEN TRANSACTION_AMOUNT_SAVINGS_Q1 else (ISNULL(TRANSACTION_AMOUNT_SAVINGS_Q1,0) - ISNULL(TRANSACTION_AMOUNT_SAVINGS_Q2,0)) end DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2

			  , [AVG_TRANSACTION_SAVINGS_Q1]
			  , CASE WHEN (AVG_TRANSACTION_SAVINGS_Q1 IS NULL AND AVG_TRANSACTION_SAVINGS_Q2 IS  NULL ) THEN AVG_TRANSACTION_SAVINGS_Q1 else (ISNULL(AVG_TRANSACTION_SAVINGS_Q1,0)  - ISNULL(AVG_TRANSACTION_SAVINGS_Q2,0)) end DFT_AVG_TRANSACTION_SAVINGS_Q1_Q2

			  , [DEPOSITED_AMOUNT_SAVINGS_Q1] 
			  , CASE WHEN (AVG_TRANSACTION_SAVINGS_Q1 IS NULL AND AVG_TRANSACTION_SAVINGS_Q2 IS  NULL ) THEN AVG_TRANSACTION_SAVINGS_Q1 else (ISNULL(DEPOSITED_AMOUNT_SAVINGS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_SAVINGS_Q2,0)) end DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2

			  , [DEPOSITED_COUNT_SAVINGS_Q1]
			  , CASE WHEN (DEPOSITED_COUNT_SAVINGS_Q1 IS NULL AND DEPOSITED_COUNT_SAVINGS_Q2 IS  NULL ) THEN DEPOSITED_COUNT_SAVINGS_Q1 else (ISNULL(DEPOSITED_COUNT_SAVINGS_Q1,0) - ISNULL(DEPOSITED_COUNT_SAVINGS_Q2,0)) end [DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2]

			  , [WITHDRAWAL_AMOUNT_SAVINGS_Q1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_SAVINGS_Q1 IS NULL AND WITHDRAWAL_AMOUNT_SAVINGS_Q2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_SAVINGS_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q2,0)) end [DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_SAVINGS_Q1 IS NULL AND WITHDRAWAL_AMOUNT_SAVINGS_Q3 IS  NULL ) THEN WITHDRAWAL_AMOUNT_SAVINGS_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q3,0)) end [DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3]
			  --, CASE WHEN (WITHDRAWAL_AMOUNT_SAVINGS_Q1 IS NULL AND WITHDRAWAL_AMOUNT_SAVINGS_Q4 IS  NULL ) THEN WITHDRAWAL_AMOUNT_SAVINGS_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_Q4,0)) end [DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q4]
			  , [WITHDRAWAL_COUNT_SAVINGS_Q1]
			  , CASE WHEN (WITHDRAWAL_COUNT_SAVINGS_Q1 IS NULL AND WITHDRAWAL_COUNT_SAVINGS_Q2 IS  NULL ) THEN WITHDRAWAL_COUNT_SAVINGS_Q1 else (ISNULL(WITHDRAWAL_COUNT_SAVINGS_Q1,0) - ISNULL(WITHDRAWAL_COUNT_SAVINGS_Q2,0)) end [DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2]

			  , [SUM_INTEREST_SAVINGS_Q1]
			  , CASE WHEN (SUM_INTEREST_SAVINGS_Q1 IS NULL AND SUM_INTEREST_SAVINGS_Q2 IS  NULL ) THEN SUM_INTEREST_SAVINGS_Q1 else (ISNULL(SUM_INTEREST_SAVINGS_Q1,0) - ISNULL(SUM_INTEREST_SAVINGS_Q2,0)) end [DFT_SUM_INTEREST_SAVINGS_Q1_Q2]


		      , [TRANSACTION_COUNT_CHECKING_Q1] 
			  , CASE WHEN ( TRANSACTION_COUNT_CHECKING_Q1 IS NULL AND TRANSACTION_COUNT_CHECKING_Q2 IS  NULL ) THEN TRANSACTION_COUNT_CHECKING_Q1 else (ISNULL(TRANSACTION_COUNT_CHECKING_Q1,0) - ISNULL(TRANSACTION_COUNT_CHECKING_Q2,0)) end DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2

			  , [TRANSACTION_AMOUNT_CHECKING_Q1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_CHECKING_Q1 IS NULL AND TRANSACTION_AMOUNT_CHECKING_Q2 IS  NULL ) THEN TRANSACTION_AMOUNT_CHECKING_Q1 else (ISNULL(TRANSACTION_AMOUNT_CHECKING_Q1,0) - ISNULL(TRANSACTION_AMOUNT_CHECKING_Q2,0)) end DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2

			  , [AVG_TRANSACTION_CHECKING_Q1]
			  , CASE WHEN (AVG_TRANSACTION_CHECKING_Q1 IS NULL AND AVG_TRANSACTION_CHECKING_Q2 IS  NULL ) THEN AVG_TRANSACTION_CHECKING_Q1 else (ISNULL(AVG_TRANSACTION_CHECKING_Q1,0)  - ISNULL(AVG_TRANSACTION_CHECKING_Q2,0)) end DFT_AVG_TRANSACTION_CHECKING_Q1_Q2

			  , [DEPOSITED_AMOUNT_CHECKING_Q1] 
			  , CASE WHEN (AVG_TRANSACTION_CHECKING_Q1 IS NULL AND AVG_TRANSACTION_CHECKING_Q2 IS  NULL ) THEN AVG_TRANSACTION_CHECKING_Q1 else (ISNULL(DEPOSITED_AMOUNT_CHECKING_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_CHECKING_Q2,0)) end DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2

			  , [DEPOSITED_COUNT_CHECKING_Q1]
			  , CASE WHEN (DEPOSITED_COUNT_CHECKING_Q1 IS NULL AND DEPOSITED_COUNT_CHECKING_Q2 IS  NULL ) THEN DEPOSITED_COUNT_CHECKING_Q1 else (ISNULL(DEPOSITED_COUNT_CHECKING_Q1,0) - ISNULL(DEPOSITED_COUNT_CHECKING_Q2,0)) end [DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2]

			  , [WITHDRAWAL_AMOUNT_CHECKING_Q1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_CHECKING_Q1 IS NULL AND WITHDRAWAL_AMOUNT_CHECKING_Q2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_CHECKING_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_CHECKING_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_CHECKING_Q2,0)) end [DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2]

			  , [WITHDRAWAL_COUNT_CHECKING_Q1]
			  , CASE WHEN (WITHDRAWAL_COUNT_CHECKING_Q1 IS NULL AND WITHDRAWAL_COUNT_CHECKING_Q2 IS  NULL ) THEN WITHDRAWAL_COUNT_CHECKING_Q1 else (ISNULL(WITHDRAWAL_COUNT_CHECKING_Q1,0) - ISNULL(WITHDRAWAL_COUNT_CHECKING_Q2,0)) end [DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2]

			  , [SUM_INTEREST_CHECKING_Q1]
			  , CASE WHEN (SUM_INTEREST_CHECKING_Q1 IS NULL AND SUM_INTEREST_CHECKING_Q2 IS  NULL ) THEN SUM_INTEREST_CHECKING_Q1 else (ISNULL(SUM_INTEREST_CHECKING_Q1,0) - ISNULL(SUM_INTEREST_CHECKING_Q2,0)) end [DFT_SUM_INTEREST_CHECKING_Q1_Q2]


		      , [TRANSACTION_COUNT_CERTIFICATES_Q1] 
			  , CASE WHEN ( TRANSACTION_COUNT_CERTIFICATES_Q1 IS NULL AND TRANSACTION_COUNT_CERTIFICATES_Q2 IS  NULL ) THEN TRANSACTION_COUNT_CERTIFICATES_Q1 else (ISNULL(TRANSACTION_COUNT_CERTIFICATES_Q1,0) - ISNULL(TRANSACTION_COUNT_CERTIFICATES_Q2,0)) end DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q2

			  , [TRANSACTION_AMOUNT_CERTIFICATES_Q1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_CERTIFICATES_Q1 IS NULL AND TRANSACTION_AMOUNT_CERTIFICATES_Q2 IS  NULL ) THEN TRANSACTION_AMOUNT_CERTIFICATES_Q1 else (ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_Q1,0) - ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_Q2,0)) end DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q2

			  , [AVG_TRANSACTION_CERTIFICATES_Q1]
			  , CASE WHEN (AVG_TRANSACTION_CERTIFICATES_Q1 IS NULL AND AVG_TRANSACTION_CERTIFICATES_Q2 IS  NULL ) THEN AVG_TRANSACTION_CERTIFICATES_Q1 else (ISNULL(AVG_TRANSACTION_CERTIFICATES_Q1,0)  - ISNULL(AVG_TRANSACTION_CERTIFICATES_Q2,0)) end DFT_AVG_TRANSACTION_CERTIFICATES_Q1_Q2

			  , [DEPOSITED_AMOUNT_CERTIFICATES_Q1] 
			  , CASE WHEN (AVG_TRANSACTION_CERTIFICATES_Q1 IS NULL AND AVG_TRANSACTION_CERTIFICATES_Q2 IS  NULL ) THEN AVG_TRANSACTION_CERTIFICATES_Q1 else (ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_Q2,0)) end DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q2

			  , [DEPOSITED_COUNT_CERTIFICATES_Q1]
			  , CASE WHEN (DEPOSITED_COUNT_CERTIFICATES_Q1 IS NULL AND DEPOSITED_COUNT_CERTIFICATES_Q2 IS  NULL ) THEN DEPOSITED_COUNT_CERTIFICATES_Q1 else (ISNULL(DEPOSITED_COUNT_CERTIFICATES_Q1,0) - ISNULL(DEPOSITED_COUNT_CERTIFICATES_Q2,0)) end [DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q2]

			  , [WITHDRAWAL_AMOUNT_CERTIFICATES_Q1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_CERTIFICATES_Q1 IS NULL AND WITHDRAWAL_AMOUNT_CERTIFICATES_Q2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_CERTIFICATES_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_Q2,0)) end [DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q2]

			  , [WITHDRAWAL_COUNT_CERTIFICATES_Q1]
			  , CASE WHEN (WITHDRAWAL_COUNT_CERTIFICATES_Q1 IS NULL AND WITHDRAWAL_COUNT_CERTIFICATES_Q2 IS  NULL ) THEN WITHDRAWAL_COUNT_CERTIFICATES_Q1 else (ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_Q1,0) - ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_Q2,0)) end [DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q2]

			  , [SUM_INTEREST_CERTIFICATES_Q1]
			  , CASE WHEN (SUM_INTEREST_CERTIFICATES_Q1 IS NULL AND SUM_INTEREST_CERTIFICATES_Q2 IS  NULL ) THEN SUM_INTEREST_CERTIFICATES_Q1 else (ISNULL(SUM_INTEREST_CERTIFICATES_Q1,0) - ISNULL(SUM_INTEREST_CERTIFICATES_Q2,0)) end [DFT_SUM_INTEREST_CERTIFICATES_Q1_Q2]


		      , [TRANSACTION_COUNT_MONEYMARKET_Q1] 
			  , CASE WHEN ( TRANSACTION_COUNT_MONEYMARKET_Q1 IS NULL AND TRANSACTION_COUNT_MONEYMARKET_Q2 IS  NULL ) THEN TRANSACTION_COUNT_MONEYMARKET_Q1 else (ISNULL(TRANSACTION_COUNT_MONEYMARKET_Q1,0) - ISNULL(TRANSACTION_COUNT_MONEYMARKET_Q2,0)) end DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q2

			  , [TRANSACTION_AMOUNT_MONEYMARKET_Q1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_MONEYMARKET_Q1 IS NULL AND TRANSACTION_AMOUNT_MONEYMARKET_Q2 IS  NULL ) THEN TRANSACTION_AMOUNT_MONEYMARKET_Q1 else (ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_Q1,0) - ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_Q2,0)) end DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q2

			  , [AVG_TRANSACTION_MONEYMARKET_Q1]
			  , CASE WHEN (AVG_TRANSACTION_MONEYMARKET_Q1 IS NULL AND AVG_TRANSACTION_MONEYMARKET_Q2 IS  NULL ) THEN AVG_TRANSACTION_MONEYMARKET_Q1 else (ISNULL(AVG_TRANSACTION_MONEYMARKET_Q1,0)  - ISNULL(AVG_TRANSACTION_MONEYMARKET_Q2,0)) end DFT_AVG_TRANSACTION_MONEYMARKET_Q1_Q2

			  , [DEPOSITED_AMOUNT_MONEYMARKET_Q1] 
			  , CASE WHEN (AVG_TRANSACTION_MONEYMARKET_Q1 IS NULL AND AVG_TRANSACTION_MONEYMARKET_Q2 IS  NULL ) THEN AVG_TRANSACTION_MONEYMARKET_Q1 else (ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_Q2,0)) end DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q2

			  , [DEPOSITED_COUNT_MONEYMARKET_Q1]
			  , CASE WHEN (DEPOSITED_COUNT_MONEYMARKET_Q1 IS NULL AND DEPOSITED_COUNT_MONEYMARKET_Q2 IS  NULL ) THEN DEPOSITED_COUNT_MONEYMARKET_Q1 else (ISNULL(DEPOSITED_COUNT_MONEYMARKET_Q1,0) - ISNULL(DEPOSITED_COUNT_MONEYMARKET_Q2,0)) end [DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q2]

			  , [WITHDRAWAL_AMOUNT_MONEYMARKET_Q1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_MONEYMARKET_Q1 IS NULL AND WITHDRAWAL_AMOUNT_MONEYMARKET_Q2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_MONEYMARKET_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_Q2,0)) end [DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q2]

			  , [WITHDRAWAL_COUNT_MONEYMARKET_Q1]
			  , CASE WHEN (WITHDRAWAL_COUNT_MONEYMARKET_Q1 IS NULL AND WITHDRAWAL_COUNT_MONEYMARKET_Q2 IS  NULL ) THEN WITHDRAWAL_COUNT_MONEYMARKET_Q1 else (ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_Q1,0) - ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_Q2,0)) end [DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q2]

			  , [SUM_INTEREST_MONEYMARKET_Q1]
			  , CASE WHEN (SUM_INTEREST_MONEYMARKET_Q1 IS NULL AND SUM_INTEREST_MONEYMARKET_Q2 IS  NULL ) THEN SUM_INTEREST_MONEYMARKET_Q1 else (ISNULL(SUM_INTEREST_MONEYMARKET_Q1,0) - ISNULL(SUM_INTEREST_MONEYMARKET_Q2,0)) end [DFT_SUM_INTEREST_MONEYMARKET_Q1_Q2]


		   --   , [TRANSACTION_COUNT_IRA_Q1] 
			  --, CASE WHEN ( TRANSACTION_COUNT_IRA_Q1 IS NULL AND TRANSACTION_COUNT_IRA_Q2 IS  NULL ) THEN TRANSACTION_COUNT_IRA_Q1 else (ISNULL(TRANSACTION_COUNT_IRA_Q1,0) - ISNULL(TRANSACTION_COUNT_IRA_Q2,0)) end DFT_TRANSACTION_COUNT_IRA_Q1_Q2

			  --, [TRANSACTION_AMOUNT_IRA_Q1]				  
			  --, CASE WHEN (TRANSACTION_AMOUNT_IRA_Q1 IS NULL AND TRANSACTION_AMOUNT_IRA_Q2 IS  NULL ) THEN TRANSACTION_AMOUNT_IRA_Q1 else (ISNULL(TRANSACTION_AMOUNT_IRA_Q1,0) - ISNULL(TRANSACTION_AMOUNT_IRA_Q2,0)) end DFT_TRANSACTION_AMOUNT_IRA_Q1_Q2

			  --, [AVG_TRANSACTION_IRA_Q1]
			  --, CASE WHEN (AVG_TRANSACTION_IRA_Q1 IS NULL AND AVG_TRANSACTION_IRA_Q2 IS  NULL ) THEN AVG_TRANSACTION_IRA_Q1 else (ISNULL(AVG_TRANSACTION_IRA_Q1,0)  - ISNULL(AVG_TRANSACTION_IRA_Q2,0)) end DFT_AVG_TRANSACTION_IRA_Q1_Q2

			  --, [DEPOSITED_AMOUNT_IRA_Q1] 
			  --, CASE WHEN (AVG_TRANSACTION_IRA_Q1 IS NULL AND AVG_TRANSACTION_IRA_Q2 IS  NULL ) THEN AVG_TRANSACTION_IRA_Q1 else (ISNULL(DEPOSITED_AMOUNT_IRA_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_IRA_Q2,0)) end DFT_DEPOSITED_AMOUNT_IRA_Q1_Q2

			  --, [DEPOSITED_COUNT_IRA_Q1]
			  --, CASE WHEN (DEPOSITED_COUNT_IRA_Q1 IS NULL AND DEPOSITED_COUNT_IRA_Q2 IS  NULL ) THEN DEPOSITED_COUNT_IRA_Q1 else (ISNULL(DEPOSITED_COUNT_IRA_Q1,0) - ISNULL(DEPOSITED_COUNT_IRA_Q2,0)) end [DFT_DEPOSITED_COUNT_IRA_Q1_Q2]

			  --, [WITHDRAWAL_AMOUNT_IRA_Q1]
			  --, CASE WHEN (WITHDRAWAL_AMOUNT_IRA_Q1 IS NULL AND WITHDRAWAL_AMOUNT_IRA_Q2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_IRA_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_IRA_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_IRA_Q2,0)) end [DFT_WITHDRAWAL_AMOUNT_IRA_Q1_Q2]

			  --, [WITHDRAWAL_COUNT_IRA_Q1]
			  --, CASE WHEN (WITHDRAWAL_COUNT_IRA_Q1 IS NULL AND WITHDRAWAL_COUNT_IRA_Q2 IS  NULL ) THEN WITHDRAWAL_COUNT_IRA_Q1 else (ISNULL(WITHDRAWAL_COUNT_IRA_Q1,0) - ISNULL(WITHDRAWAL_COUNT_IRA_Q2,0)) end [DFT_WITHDRAWAL_COUNT_IRA_Q1_Q2]

			  --, [SUM_INTEREST_IRA_Q1]
			  --, CASE WHEN (SUM_INTEREST_IRA_Q1 IS NULL AND SUM_INTEREST_IRA_Q2 IS  NULL ) THEN SUM_INTEREST_IRA_Q1 else (ISNULL(SUM_INTEREST_IRA_Q1,0) - ISNULL(SUM_INTEREST_IRA_Q2,0)) end [DFT_SUM_INTEREST_IRA_Q1_Q2]

		      , [TRANSACTION_COUNT_DEPOSITS_Q1] 
			  , CASE WHEN ( TRANSACTION_COUNT_DEPOSITS_Q1 IS NULL AND TRANSACTION_COUNT_DEPOSITS_Q2 IS  NULL ) THEN TRANSACTION_COUNT_DEPOSITS_Q1 else (ISNULL(TRANSACTION_COUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_COUNT_DEPOSITS_Q2,0)) end DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q2

			  , [TRANSACTION_AMOUNT_DEPOSITS_Q1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_DEPOSITS_Q1 IS NULL AND TRANSACTION_AMOUNT_DEPOSITS_Q2 IS  NULL ) THEN TRANSACTION_AMOUNT_DEPOSITS_Q1 else (ISNULL(TRANSACTION_AMOUNT_DEPOSITS_Q1,0) - ISNULL(TRANSACTION_AMOUNT_DEPOSITS_Q2,0)) end DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2

			  , [AVG_TRANSACTION_DEPOSITS_Q1]
			  , CASE WHEN (AVG_TRANSACTION_DEPOSITS_Q1 IS NULL AND AVG_TRANSACTION_DEPOSITS_Q2 IS  NULL ) THEN AVG_TRANSACTION_DEPOSITS_Q1 else (ISNULL(AVG_TRANSACTION_DEPOSITS_Q1,0)  - ISNULL(AVG_TRANSACTION_DEPOSITS_Q2,0)) end DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q2

			  , [DEPOSITED_AMOUNT_DEPOSITS_Q1] 
			  , CASE WHEN (AVG_TRANSACTION_DEPOSITS_Q1 IS NULL AND AVG_TRANSACTION_DEPOSITS_Q2 IS  NULL ) THEN AVG_TRANSACTION_DEPOSITS_Q1 else (ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q2,0)) end DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2
			  , CASE WHEN (AVG_TRANSACTION_DEPOSITS_Q1 IS NULL AND AVG_TRANSACTION_DEPOSITS_Q3 IS  NULL ) THEN AVG_TRANSACTION_DEPOSITS_Q1 else (ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q3,0)) end DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3
			  --, CASE WHEN (AVG_TRANSACTION_DEPOSITS_Q1 IS NULL AND AVG_TRANSACTION_DEPOSITS_Q4 IS  NULL ) THEN AVG_TRANSACTION_DEPOSITS_Q1 else (ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q1,0)  - ISNULL(DEPOSITED_AMOUNT_DEPOSITS_Q4,0)) end DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q4
			  , [DEPOSITED_COUNT_DEPOSITS_Q1]
			  , CASE WHEN (DEPOSITED_COUNT_DEPOSITS_Q1 IS NULL AND DEPOSITED_COUNT_DEPOSITS_Q2 IS  NULL ) THEN DEPOSITED_COUNT_DEPOSITS_Q1 else (ISNULL(DEPOSITED_COUNT_DEPOSITS_Q1,0) - ISNULL(DEPOSITED_COUNT_DEPOSITS_Q2,0)) end [DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2]

			  , [WITHDRAWAL_AMOUNT_DEPOSITS_Q1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_DEPOSITS_Q1 IS NULL AND WITHDRAWAL_AMOUNT_DEPOSITS_Q2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_DEPOSITS_Q1 else (ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_Q2,0)) end [DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2]

			  , [WITHDRAWAL_COUNT_DEPOSITS_Q1]
			  , CASE WHEN (WITHDRAWAL_COUNT_DEPOSITS_Q1 IS NULL AND WITHDRAWAL_COUNT_DEPOSITS_Q2 IS  NULL ) THEN WITHDRAWAL_COUNT_DEPOSITS_Q1 else (ISNULL(WITHDRAWAL_COUNT_DEPOSITS_Q1,0) - ISNULL(WITHDRAWAL_COUNT_DEPOSITS_Q2,0)) end [DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2]

			  , [SUM_INTEREST_DEPOSITS_Q1]
			  , CASE WHEN (SUM_INTEREST_DEPOSITS_Q1 IS NULL AND SUM_INTEREST_DEPOSITS_Q2 IS  NULL ) THEN SUM_INTEREST_DEPOSITS_Q1 else (ISNULL(SUM_INTEREST_DEPOSITS_Q1,0) - ISNULL(SUM_INTEREST_DEPOSITS_Q2,0)) end [DFT_SUM_INTEREST_DEPOSITS_Q1_Q2]


		      --, [TRANSACTION_COUNT_SAVINGS_H1] 
			  , CASE WHEN ( TRANSACTION_COUNT_SAVINGS_H1 IS NULL AND TRANSACTION_COUNT_SAVINGS_H2 IS  NULL ) THEN TRANSACTION_COUNT_SAVINGS_H1 else (ISNULL(TRANSACTION_COUNT_SAVINGS_H1,0) - ISNULL(TRANSACTION_COUNT_SAVINGS_H2,0)) end DFT_TRANSACTION_COUNT_SAVINGS_H1_H2

			  --, [TRANSACTION_AMOUNT_SAVINGS_H1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_SAVINGS_H1 IS NULL AND TRANSACTION_AMOUNT_SAVINGS_H2 IS  NULL ) THEN TRANSACTION_AMOUNT_SAVINGS_H1 else (ISNULL(TRANSACTION_AMOUNT_SAVINGS_H1,0) - ISNULL(TRANSACTION_AMOUNT_SAVINGS_H2,0)) end DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2

			  --, [AVG_TRANSACTION_SAVINGS_H1]
			  , CASE WHEN (AVG_TRANSACTION_SAVINGS_H1 IS NULL AND AVG_TRANSACTION_SAVINGS_H2 IS  NULL ) THEN AVG_TRANSACTION_SAVINGS_H1 else (ISNULL(AVG_TRANSACTION_SAVINGS_H1,0)  - ISNULL(AVG_TRANSACTION_SAVINGS_H2,0)) end DFT_AVG_TRANSACTION_SAVINGS_H1_H2

			  --, [DEPOSITED_AMOUNT_SAVINGS_H1] 
			  , CASE WHEN (AVG_TRANSACTION_SAVINGS_H1 IS NULL AND AVG_TRANSACTION_SAVINGS_H2 IS  NULL ) THEN AVG_TRANSACTION_SAVINGS_H1 else (ISNULL(DEPOSITED_AMOUNT_SAVINGS_H1,0)  - ISNULL(DEPOSITED_AMOUNT_SAVINGS_H2,0)) end DFT_DEPOSITED_AMOUNT_SAVINGS_H1_H2

			  --, [DEPOSITED_COUNT_SAVINGS_H1]
			  , CASE WHEN (DEPOSITED_COUNT_SAVINGS_H1 IS NULL AND DEPOSITED_COUNT_SAVINGS_H2 IS  NULL ) THEN DEPOSITED_COUNT_SAVINGS_H1 else (ISNULL(DEPOSITED_COUNT_SAVINGS_H1,0) - ISNULL(DEPOSITED_COUNT_SAVINGS_H2,0)) end [DFT_DEPOSITED_COUNT_SAVINGS_H1_H2]

			  --, [WITHDRAWAL_AMOUNT_SAVINGS_H1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_SAVINGS_H1 IS NULL AND WITHDRAWAL_AMOUNT_SAVINGS_H2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_SAVINGS_H1 else (ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_H1,0) - ISNULL(WITHDRAWAL_AMOUNT_SAVINGS_H2,0)) end [DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2]
	
			  --, [WITHDRAWAL_COUNT_SAVINGS_H1]
			  , CASE WHEN (WITHDRAWAL_COUNT_SAVINGS_H1 IS NULL AND WITHDRAWAL_COUNT_SAVINGS_H2 IS  NULL ) THEN WITHDRAWAL_COUNT_SAVINGS_H1 else (ISNULL(WITHDRAWAL_COUNT_SAVINGS_H1,0) - ISNULL(WITHDRAWAL_COUNT_SAVINGS_H2,0)) end [DFT_WITHDRAWAL_COUNT_SAVINGS_H1_H2]

			  --, [SUM_INTEREST_SAVINGS_H1]
			  , CASE WHEN (SUM_INTEREST_SAVINGS_H1 IS NULL AND SUM_INTEREST_SAVINGS_H2 IS  NULL ) THEN SUM_INTEREST_SAVINGS_H1 else (ISNULL(SUM_INTEREST_SAVINGS_H1,0) - ISNULL(SUM_INTEREST_SAVINGS_H2,0)) end [DFT_SUM_INTEREST_SAVINGS_H1_H2]


		      --, [TRANSACTION_COUNT_CHECKING_H1] 
			  , CASE WHEN ( TRANSACTION_COUNT_CHECKING_H1 IS NULL AND TRANSACTION_COUNT_CHECKING_H2 IS  NULL ) THEN TRANSACTION_COUNT_CHECKING_H1 else (ISNULL(TRANSACTION_COUNT_CHECKING_H1,0) - ISNULL(TRANSACTION_COUNT_CHECKING_H2,0)) end DFT_TRANSACTION_COUNT_CHECKING_H1_H2

			  --, [TRANSACTION_AMOUNT_CHECKING_H1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_CHECKING_H1 IS NULL AND TRANSACTION_AMOUNT_CHECKING_H2 IS  NULL ) THEN TRANSACTION_AMOUNT_CHECKING_H1 else (ISNULL(TRANSACTION_AMOUNT_CHECKING_H1,0) - ISNULL(TRANSACTION_AMOUNT_CHECKING_H2,0)) end DFT_TRANSACTION_AMOUNT_CHECKING_H1_H2

			  --, [AVG_TRANSACTION_CHECKING_H1]
			  , CASE WHEN (AVG_TRANSACTION_CHECKING_H1 IS NULL AND AVG_TRANSACTION_CHECKING_H2 IS  NULL ) THEN AVG_TRANSACTION_CHECKING_H1 else (ISNULL(AVG_TRANSACTION_CHECKING_H1,0)  - ISNULL(AVG_TRANSACTION_CHECKING_H2,0)) end DFT_AVG_TRANSACTION_CHECKING_H1_H2

			  --, [DEPOSITED_AMOUNT_CHECKING_H1] 
			  , CASE WHEN (AVG_TRANSACTION_CHECKING_H1 IS NULL AND AVG_TRANSACTION_CHECKING_H2 IS  NULL ) THEN AVG_TRANSACTION_CHECKING_H1 else (ISNULL(DEPOSITED_AMOUNT_CHECKING_H1,0)  - ISNULL(DEPOSITED_AMOUNT_CHECKING_H2,0)) end DFT_DEPOSITED_AMOUNT_CHECKING_H1_H2

			  --, [DEPOSITED_COUNT_CHECKING_H1]
			  , CASE WHEN (DEPOSITED_COUNT_CHECKING_H1 IS NULL AND DEPOSITED_COUNT_CHECKING_H2 IS  NULL ) THEN DEPOSITED_COUNT_CHECKING_H1 else (ISNULL(DEPOSITED_COUNT_CHECKING_H1,0) - ISNULL(DEPOSITED_COUNT_CHECKING_H2,0)) end [DFT_DEPOSITED_COUNT_CHECKING_H1_H2]

			  --, [WITHDRAWAL_AMOUNT_CHECKING_H1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_CHECKING_H1 IS NULL AND WITHDRAWAL_AMOUNT_CHECKING_H2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_CHECKING_H1 else (ISNULL(WITHDRAWAL_AMOUNT_CHECKING_H1,0) - ISNULL(WITHDRAWAL_AMOUNT_CHECKING_H2,0)) end [DFT_WITHDRAWAL_AMOUNT_CHECKING_H1_H2]

			  --, [WITHDRAWAL_COUNT_CHECKING_H1]
			  , CASE WHEN (WITHDRAWAL_COUNT_CHECKING_H1 IS NULL AND WITHDRAWAL_COUNT_CHECKING_H2 IS  NULL ) THEN WITHDRAWAL_COUNT_CHECKING_H1 else (ISNULL(WITHDRAWAL_COUNT_CHECKING_H1,0) - ISNULL(WITHDRAWAL_COUNT_CHECKING_H2,0)) end [DFT_WITHDRAWAL_COUNT_CHECKING_H1_H2]

			  --, [SUM_INTEREST_CHECKING_H1]
			  , CASE WHEN (SUM_INTEREST_CHECKING_H1 IS NULL AND SUM_INTEREST_CHECKING_H2 IS  NULL ) THEN SUM_INTEREST_CHECKING_H1 else (ISNULL(SUM_INTEREST_CHECKING_H1,0) - ISNULL(SUM_INTEREST_CHECKING_H2,0)) end [DFT_SUM_INTEREST_CHECKING_H1_H2]


		      --, [TRANSACTION_COUNT_CERTIFICATES_H1] 
			  , CASE WHEN ( TRANSACTION_COUNT_CERTIFICATES_H1 IS NULL AND TRANSACTION_COUNT_CERTIFICATES_H2 IS  NULL ) THEN TRANSACTION_COUNT_CERTIFICATES_H1 else (ISNULL(TRANSACTION_COUNT_CERTIFICATES_H1,0) - ISNULL(TRANSACTION_COUNT_CERTIFICATES_H2,0)) end DFT_TRANSACTION_COUNT_CERTIFICATES_H1_H2

			  --, [TRANSACTION_AMOUNT_CERTIFICATES_H1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_CERTIFICATES_H1 IS NULL AND TRANSACTION_AMOUNT_CERTIFICATES_H2 IS  NULL ) THEN TRANSACTION_AMOUNT_CERTIFICATES_H1 else (ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_H1,0) - ISNULL(TRANSACTION_AMOUNT_CERTIFICATES_H2,0)) end DFT_TRANSACTION_AMOUNT_CERTIFICATES_H1_H2

			  --, [AVG_TRANSACTION_CERTIFICATES_H1]
			  , CASE WHEN (AVG_TRANSACTION_CERTIFICATES_H1 IS NULL AND AVG_TRANSACTION_CERTIFICATES_H2 IS  NULL ) THEN AVG_TRANSACTION_CERTIFICATES_H1 else (ISNULL(AVG_TRANSACTION_CERTIFICATES_H1,0)  - ISNULL(AVG_TRANSACTION_CERTIFICATES_H2,0)) end DFT_AVG_TRANSACTION_CERTIFICATES_H1_H2

			  --, [DEPOSITED_AMOUNT_CERTIFICATES_H1] 
			  , CASE WHEN (AVG_TRANSACTION_CERTIFICATES_H1 IS NULL AND AVG_TRANSACTION_CERTIFICATES_H2 IS  NULL ) THEN AVG_TRANSACTION_CERTIFICATES_H1 else (ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_H1,0)  - ISNULL(DEPOSITED_AMOUNT_CERTIFICATES_H2,0)) end DFT_DEPOSITED_AMOUNT_CERTIFICATES_H1_H2

			  --, [DEPOSITED_COUNT_CERTIFICATES_H1]
			  , CASE WHEN (DEPOSITED_COUNT_CERTIFICATES_H1 IS NULL AND DEPOSITED_COUNT_CERTIFICATES_H2 IS  NULL ) THEN DEPOSITED_COUNT_CERTIFICATES_H1 else (ISNULL(DEPOSITED_COUNT_CERTIFICATES_H1,0) - ISNULL(DEPOSITED_COUNT_CERTIFICATES_H2,0)) end [DFT_DEPOSITED_COUNT_CERTIFICATES_H1_H2]

			  --, [WITHDRAWAL_AMOUNT_CERTIFICATES_H1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_CERTIFICATES_H1 IS NULL AND WITHDRAWAL_AMOUNT_CERTIFICATES_H2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_CERTIFICATES_H1 else (ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_H1,0) - ISNULL(WITHDRAWAL_AMOUNT_CERTIFICATES_H2,0)) end [DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_H1_H2]

			  --, [WITHDRAWAL_COUNT_CERTIFICATES_H1]
			  , CASE WHEN (WITHDRAWAL_COUNT_CERTIFICATES_H1 IS NULL AND WITHDRAWAL_COUNT_CERTIFICATES_H2 IS  NULL ) THEN WITHDRAWAL_COUNT_CERTIFICATES_H1 else (ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_H1,0) - ISNULL(WITHDRAWAL_COUNT_CERTIFICATES_H2,0)) end [DFT_WITHDRAWAL_COUNT_CERTIFICATES_H1_H2]

			  --, [SUM_INTEREST_CERTIFICATES_H1]
			  , CASE WHEN (SUM_INTEREST_CERTIFICATES_H1 IS NULL AND SUM_INTEREST_CERTIFICATES_H2 IS  NULL ) THEN SUM_INTEREST_CERTIFICATES_H1 else (ISNULL(SUM_INTEREST_CERTIFICATES_H1,0) - ISNULL(SUM_INTEREST_CERTIFICATES_H2,0)) end [DFT_SUM_INTEREST_CERTIFICATES_H1_H2]


		      --, [TRANSACTION_COUNT_MONEYMARKET_H1] 
			  , CASE WHEN ( TRANSACTION_COUNT_MONEYMARKET_H1 IS NULL AND TRANSACTION_COUNT_MONEYMARKET_H2 IS  NULL ) THEN TRANSACTION_COUNT_MONEYMARKET_H1 else (ISNULL(TRANSACTION_COUNT_MONEYMARKET_H1,0) - ISNULL(TRANSACTION_COUNT_MONEYMARKET_H2,0)) end DFT_TRANSACTION_COUNT_MONEYMARKET_H1_H2

			  --, [TRANSACTION_AMOUNT_MONEYMARKET_H1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_MONEYMARKET_H1 IS NULL AND TRANSACTION_AMOUNT_MONEYMARKET_H2 IS  NULL ) THEN TRANSACTION_AMOUNT_MONEYMARKET_H1 else (ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_H1,0) - ISNULL(TRANSACTION_AMOUNT_MONEYMARKET_H2,0)) end DFT_TRANSACTION_AMOUNT_MONEYMARKET_H1_H2

			  --, [AVG_TRANSACTION_MONEYMARKET_H1]
			  , CASE WHEN (AVG_TRANSACTION_MONEYMARKET_H1 IS NULL AND AVG_TRANSACTION_MONEYMARKET_H2 IS  NULL ) THEN AVG_TRANSACTION_MONEYMARKET_H1 else (ISNULL(AVG_TRANSACTION_MONEYMARKET_H1,0)  - ISNULL(AVG_TRANSACTION_MONEYMARKET_H2,0)) end DFT_AVG_TRANSACTION_MONEYMARKET_H1_H2

			  --, [DEPOSITED_AMOUNT_MONEYMARKET_H1] 
			  , CASE WHEN (AVG_TRANSACTION_MONEYMARKET_H1 IS NULL AND AVG_TRANSACTION_MONEYMARKET_H2 IS  NULL ) THEN AVG_TRANSACTION_MONEYMARKET_H1 else (ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_H1,0)  - ISNULL(DEPOSITED_AMOUNT_MONEYMARKET_H2,0)) end DFT_DEPOSITED_AMOUNT_MONEYMARKET_H1_H2

			  --, [DEPOSITED_COUNT_MONEYMARKET_H1]
			  , CASE WHEN (DEPOSITED_COUNT_MONEYMARKET_H1 IS NULL AND DEPOSITED_COUNT_MONEYMARKET_H2 IS  NULL ) THEN DEPOSITED_COUNT_MONEYMARKET_H1 else (ISNULL(DEPOSITED_COUNT_MONEYMARKET_H1,0) - ISNULL(DEPOSITED_COUNT_MONEYMARKET_H2,0)) end [DFT_DEPOSITED_COUNT_MONEYMARKET_H1_H2]

			  --, [WITHDRAWAL_AMOUNT_MONEYMARKET_H1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_MONEYMARKET_H1 IS NULL AND WITHDRAWAL_AMOUNT_MONEYMARKET_H2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_MONEYMARKET_H1 else (ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_H1,0) - ISNULL(WITHDRAWAL_AMOUNT_MONEYMARKET_H2,0)) end [DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_H1_H2]

			  --, [WITHDRAWAL_COUNT_MONEYMARKET_H1]
			  , CASE WHEN (WITHDRAWAL_COUNT_MONEYMARKET_H1 IS NULL AND WITHDRAWAL_COUNT_MONEYMARKET_H2 IS  NULL ) THEN WITHDRAWAL_COUNT_MONEYMARKET_H1 else (ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_H1,0) - ISNULL(WITHDRAWAL_COUNT_MONEYMARKET_H2,0)) end [DFT_WITHDRAWAL_COUNT_MONEYMARKET_H1_H2]

			  --, [SUM_INTEREST_MONEYMARKET_H1]
			  , CASE WHEN (SUM_INTEREST_MONEYMARKET_H1 IS NULL AND SUM_INTEREST_MONEYMARKET_H2 IS  NULL ) THEN SUM_INTEREST_MONEYMARKET_H1 else (ISNULL(SUM_INTEREST_MONEYMARKET_H1,0) - ISNULL(SUM_INTEREST_MONEYMARKET_H2,0)) end [DFT_SUM_INTEREST_MONEYMARKET_H1_H2]


		   --   --, [TRANSACTION_COUNT_IRA_H1] 
			  --, CASE WHEN ( TRANSACTION_COUNT_IRA_H1 IS NULL AND TRANSACTION_COUNT_IRA_H2 IS  NULL ) THEN TRANSACTION_COUNT_IRA_H1 else (ISNULL(TRANSACTION_COUNT_IRA_H1,0) - ISNULL(TRANSACTION_COUNT_IRA_H2,0)) end DFT_TRANSACTION_COUNT_IRA_H1_H2

			  ----, [TRANSACTION_AMOUNT_IRA_H1]				  
			  --, CASE WHEN (TRANSACTION_AMOUNT_IRA_H1 IS NULL AND TRANSACTION_AMOUNT_IRA_H2 IS  NULL ) THEN TRANSACTION_AMOUNT_IRA_H1 else (ISNULL(TRANSACTION_AMOUNT_IRA_H1,0) - ISNULL(TRANSACTION_AMOUNT_IRA_H2,0)) end DFT_TRANSACTION_AMOUNT_IRA_H1_H2

			  ----, [AVG_TRANSACTION_IRA_H1]
			  --, CASE WHEN (AVG_TRANSACTION_IRA_H1 IS NULL AND AVG_TRANSACTION_IRA_H2 IS  NULL ) THEN AVG_TRANSACTION_IRA_H1 else (ISNULL(AVG_TRANSACTION_IRA_H1,0)  - ISNULL(AVG_TRANSACTION_IRA_H2,0)) end DFT_AVG_TRANSACTION_IRA_H1_H2

			  ----, [DEPOSITED_AMOUNT_IRA_H1] 
			  --, CASE WHEN (AVG_TRANSACTION_IRA_H1 IS NULL AND AVG_TRANSACTION_IRA_H2 IS  NULL ) THEN AVG_TRANSACTION_IRA_H1 else (ISNULL(DEPOSITED_AMOUNT_IRA_H1,0)  - ISNULL(DEPOSITED_AMOUNT_IRA_H2,0)) end DFT_DEPOSITED_AMOUNT_IRA_H1_H2

			  ----, [DEPOSITED_COUNT_IRA_H1]
			  --, CASE WHEN (DEPOSITED_COUNT_IRA_H1 IS NULL AND DEPOSITED_COUNT_IRA_H2 IS  NULL ) THEN DEPOSITED_COUNT_IRA_H1 else (ISNULL(DEPOSITED_COUNT_IRA_H1,0) - ISNULL(DEPOSITED_COUNT_IRA_H2,0)) end [DFT_DEPOSITED_COUNT_IRA_H1_H2]

			  ----, [WITHDRAWAL_AMOUNT_IRA_H1]
			  --, CASE WHEN (WITHDRAWAL_AMOUNT_IRA_H1 IS NULL AND WITHDRAWAL_AMOUNT_IRA_H2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_IRA_H1 else (ISNULL(WITHDRAWAL_AMOUNT_IRA_H1,0) - ISNULL(WITHDRAWAL_AMOUNT_IRA_H2,0)) end [DFT_WITHDRAWAL_AMOUNT_IRA_H1_H2]

			  ----, [WITHDRAWAL_COUNT_IRA_H1]
			  --, CASE WHEN (WITHDRAWAL_COUNT_IRA_H1 IS NULL AND WITHDRAWAL_COUNT_IRA_H2 IS  NULL ) THEN WITHDRAWAL_COUNT_IRA_H1 else (ISNULL(WITHDRAWAL_COUNT_IRA_H1,0) - ISNULL(WITHDRAWAL_COUNT_IRA_H2,0)) end [DFT_WITHDRAWAL_COUNT_IRA_H1_H2]

			  ----, [SUM_INTEREST_IRA_H1]
			  --, CASE WHEN (SUM_INTEREST_IRA_H1 IS NULL AND SUM_INTEREST_IRA_H2 IS  NULL ) THEN SUM_INTEREST_IRA_H1 else (ISNULL(SUM_INTEREST_IRA_H1,0) - ISNULL(SUM_INTEREST_IRA_H2,0)) end [DFT_SUM_INTEREST_IRA_H1_H2]

		      --, [TRANSACTION_COUNT_DEPOSITS_H1] 
			  , CASE WHEN ( TRANSACTION_COUNT_DEPOSITS_H1 IS NULL AND TRANSACTION_COUNT_DEPOSITS_H2 IS  NULL ) THEN TRANSACTION_COUNT_DEPOSITS_H1 else (ISNULL(TRANSACTION_COUNT_DEPOSITS_H1,0) - ISNULL(TRANSACTION_COUNT_DEPOSITS_H2,0)) end DFT_TRANSACTION_COUNT_DEPOSITS_H1_H2

			  --, [TRANSACTION_AMOUNT_DEPOSITS_H1]				  
			  , CASE WHEN (TRANSACTION_AMOUNT_DEPOSITS_H1 IS NULL AND TRANSACTION_AMOUNT_DEPOSITS_H2 IS  NULL ) THEN TRANSACTION_AMOUNT_DEPOSITS_H1 else (ISNULL(TRANSACTION_AMOUNT_DEPOSITS_H1,0) - ISNULL(TRANSACTION_AMOUNT_DEPOSITS_H2,0)) end DFT_TRANSACTION_AMOUNT_DEPOSITS_H1_H2

			  --, [AVG_TRANSACTION_DEPOSITS_H1]
			  , CASE WHEN (AVG_TRANSACTION_DEPOSITS_H1 IS NULL AND AVG_TRANSACTION_DEPOSITS_H2 IS  NULL ) THEN AVG_TRANSACTION_DEPOSITS_H1 else (ISNULL(AVG_TRANSACTION_DEPOSITS_H1,0)  - ISNULL(AVG_TRANSACTION_DEPOSITS_H2,0)) end DFT_AVG_TRANSACTION_DEPOSITS_H1_H2

			  --, [DEPOSITED_AMOUNT_DEPOSITS_H1] 
			  , CASE WHEN (AVG_TRANSACTION_DEPOSITS_H1 IS NULL AND AVG_TRANSACTION_DEPOSITS_H2 IS  NULL ) THEN AVG_TRANSACTION_DEPOSITS_H1 else (ISNULL(DEPOSITED_AMOUNT_DEPOSITS_H1,0)  - ISNULL(DEPOSITED_AMOUNT_DEPOSITS_H2,0)) end DFT_DEPOSITED_AMOUNT_DEPOSITS_H1_H2

			  --, [DEPOSITED_COUNT_DEPOSITS_H1]
			  , CASE WHEN (DEPOSITED_COUNT_DEPOSITS_H1 IS NULL AND DEPOSITED_COUNT_DEPOSITS_H2 IS  NULL ) THEN DEPOSITED_COUNT_DEPOSITS_H1 else (ISNULL(DEPOSITED_COUNT_DEPOSITS_H1,0) - ISNULL(DEPOSITED_COUNT_DEPOSITS_H2,0)) end [DFT_DEPOSITED_COUNT_DEPOSITS_H1_H2]

			  --, [WITHDRAWAL_AMOUNT_DEPOSITS_H1]
			  , CASE WHEN (WITHDRAWAL_AMOUNT_DEPOSITS_H1 IS NULL AND WITHDRAWAL_AMOUNT_DEPOSITS_H2 IS  NULL ) THEN WITHDRAWAL_AMOUNT_DEPOSITS_H1 else (ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_H1,0) - ISNULL(WITHDRAWAL_AMOUNT_DEPOSITS_H2,0)) end [DFT_WITHDRAWAL_AMOUNT_DEPOSITS_H1_H2]

			  --, [WITHDRAWAL_COUNT_DEPOSITS_H1]
			  , CASE WHEN (WITHDRAWAL_COUNT_DEPOSITS_H1 IS NULL AND WITHDRAWAL_COUNT_DEPOSITS_H2 IS  NULL ) THEN WITHDRAWAL_COUNT_DEPOSITS_H1 else (ISNULL(WITHDRAWAL_COUNT_DEPOSITS_H1,0) - ISNULL(WITHDRAWAL_COUNT_DEPOSITS_H2,0)) end [DFT_WITHDRAWAL_COUNT_DEPOSITS_H1_H2]

			  --, [SUM_INTEREST_DEPOSITS_H1]
			  , CASE WHEN (SUM_INTEREST_DEPOSITS_H1 IS NULL AND SUM_INTEREST_DEPOSITS_H2 IS  NULL ) THEN SUM_INTEREST_DEPOSITS_H1 else (ISNULL(SUM_INTEREST_DEPOSITS_H1,0) - ISNULL(SUM_INTEREST_DEPOSITS_H2,0)) end [DFT_SUM_INTEREST_DEPOSITS_H1_H2]


		into #deposits_transaction
		from #deposit_transaction_temp2

		DROP TABLE IF EXISTS #deposits_summary
		SELECT * 
		into #deposits_summary 
		FROM #membership_deposits A
		left join #deposits_transaction B
		on A.SSN003  = B.SSN004

		
		--DROP TABLE IF EXISTS #updated_deposits_summary
		--SELECT CASE WHEN A.SSN003  = B.SSN004 THEN A.SSN003 
		--            WHEN A.SSN003 is NULL THEN B.SSN004
		--			WHEN B.SSN004 is NULL THEN A.SSN003 END [SSN_Dep]
		--			,A.*,B.*
		--into #updated_deposits_summary 
		--FROM #membership_deposits A
		--full outer join #deposits_transaction B
		--on A.SSN003  = B.SSN004

		-- Merging the Loan Product Summary and Deposits Summary

		DROP TABLE IF EXISTS #merged_loan_deposits_summary
		SELECT * 
		into #merged_loan_deposits_summary
		FROM #deposits_summary A
		left join 
		#loan_product_master B
		on A.SSN003 = B.SSN001

		--DROP TABLE IF EXISTS #updated_merged_loan_deposits_summary
		--SELECT CASE WHEN A.SSN_Dep = B.SSN_L THEN SSN_Dep
		--            WHEN A.SSN_Dep IS NULL THEN B.SSN_L
		--			WHEN B.SSN_L IS NULL THEN A.SSN_Dep END [FINAL_SSN]
		--into #updated_merged_loan_deposits_summary
		--FROM #updated_deposits_summary A
		--full outer join 
		--#updated_loan_product_master B
		--on A.SSN_Dep = B.SSN_L
		
		--DROP TABLE IF EXISTS Analytics.dbo.SN_depositsLOAN 
		--SELECT TOP 10 *
		--into Analytics.dbo.SN_depositsLOAN
		--FROM #merged_loan_deposits_summary

	/* Appending OnlineBanking data to Master data  */

	drop table if exists #loan_dep_onlinebanking
	select  A.*,DATEDIFF ( day, LastLogon, @staticpooldate) AS "Days Since Last Login" 
	into #loan_dep_onlinebanking -- new copy of master data
	from #merged_loan_deposits_summary as A
	LEFT join Q2EVE.[dbo].[vwMemberOnlineBankingSummary] as B
	on A.SSN003 = B.SSN

	/* BUREAU DATA */

	DROP TABLE IF EXISTS #BUREAU_DATA
	SELECT * 
	INTO #BUREAU_DATA
	FROM
	 OPENQUERY([GSDWSQL01],'SELECT * FROM [BureauData].[dbo].[TransUnionAttributeHistory] WHERE DATE = ''202206''')
	--SELECT COUNT(SSN003) FROM #loan_dep_onlinebanking
	--SELECT COUNT(DISTINCT SSN003) FROM #loan_dep_onlinebanking

	/** Appending Bureau Data to master data 091322 **/

    drop table if exists #MasterData
	select SSN003,
			PRODUCT_SAVINGS_SP,
			PRODUCT_SAVINGS_Q1,
			DFT_PRODUCT_SAVINGS_Q1_Q2,
			MOB_SAVINGS,
			AVG_MONTH_END_BALANCE_SAVINGS_Q1,
			DFT_AVG_MONTH_END_BALANCE_SAVINGS_Q1_Q2,
			SUM_LASTDIVAMOUNT_SAVINGS_Q1,
			DFT_SUM_LASTDIVAMOUNT_SAVINGS_Q1_Q2,
			PRODUCT_CHECKING_SP,
			PRODUCT_CHECKING_Q1,
			DFT_PRODUCT_CHECKING_Q1_Q2,
			MOB_CHECKING,
			AVG_MONTH_END_BALANCE_CHECKING_Q1,
			DFT_AVG_MONTH_END_BALANCE_CHECKING_Q1_Q2,
			SUM_LASTDIVAMOUNT_CHECKING_Q1,
			DFT_SUM_LASTDIVAMOUNT_CHECKING_Q1_Q2,
			AVG_CHARGEOFFAMOUNT_CHECKING_SP,
			AVG_CHARGEOFFAMOUNT_CHECKING_Q1,
			DFT_AVG_CHARGEOFFAMOUNT_CHECKING_Q1_Q2,
			OVERDRAFTFEEYTD_CHECKING_Q1,
			DFT_OVERDRAFTFEEYTD_CHECKING_Q1_Q2,
			PRODUCT_CERTIFICATES_SP,
			PRODUCT_CERTIFICATES_Q1,
			DFT_PRODUCT_CERTIFICATES_Q1_Q2,
			MOB_CERTIFICATES,
			AVG_MONTH_END_BALANCE_CERTIFICATES_Q1,
			DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_Q1_Q2,
			SUM_LASTDIVAMOUNT_CERTIFICATES_Q1,
			DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_Q1_Q2,
			--PRODUCT_MONEYMARKET_SP,
			PRODUCT_MONEYMARKET_Q1,
			DFT_PRODUCT_MONEYMARKET_Q1_Q2,
			MOB_MONEYMARKET,
			AVG_MONTH_END_BALANCE_MONEYMARKET_Q1,
			DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_Q1_Q2,
			SUM_LASTDIVAMOUNT_MONEYMARKET_Q1,
			DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_Q1_Q2,
			PRODUCT_DEPOSITS_SP,
			PRODUCT_DEPOSITS_Q1,
			DFT_PRODUCT_DEPOSITS_Q1_Q2,
			MOB_DEPOSITS,
			AVG_MONTH_END_BALANCE_DEPOSITS_Q1,
			DFT_AVG_MONTH_END_BALANCE_DEPOSITS_Q1_Q2,
			SUM_LASTDIVAMOUNT_DEPOSITS_Q1,
			DFT_SUM_LASTDIVAMOUNT_DEPOSITS_Q1_Q2,
			AVG_CHARGEOFFAMOUNT_DEPOSITS_SP,
			AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1,
			DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_Q1_Q2,
			DFT_PRODUCT_SAVINGS_H1_H2,
			DFT_AVG_MONTH_END_BALANCE_SAVINGS_H1_H2,
			DFT_SUM_LASTDIVAMOUNT_SAVINGS_H1_H2,
			DFT_AVG_CHARGEOFFAMOUNT_SAVINGS_H1_H2,
			DFT_OVERDRAFTFEEYTD_SAVINGS_H1_H2,
			DFT_PRODUCT_CHECKING_H1_H2,
			DFT_AVG_MONTH_END_BALANCE_CHECKING_H1_H2,
			DFT_SUM_LASTDIVAMOUNT_CHECKING_H1_H2,
			DFT_AVG_CHARGEOFFAMOUNT_CHECKING_H1_H2,
			DFT_OVERDRAFTFEEYTD_CHECKING_H1_H2,
			DFT_PRODUCT_CERTIFICATES_H1_H2,
			DFT_AVG_MONTH_END_BALANCE_CERTIFICATES_H1_H2,
			DFT_SUM_LASTDIVAMOUNT_CERTIFICATES_H1_H2,
			DFT_PENALTYYTD_CERTIFICATES_H1_H2,
			DFT_PRODUCT_MONEYMARKET_H1_H2,
			DFT_AVG_MONTH_END_BALANCE_MONEYMARKET_H1_H2,
			DFT_SUM_LASTDIVAMOUNT_MONEYMARKET_H1_H2,
			DFT_PRODUCT_DEPOSITS_H1_H2,
			DFT_AVG_MONTH_END_BALANCE_DEPOSITS_H1_H2,
			DFT_SUM_LASTDIVAMOUNT_DEPOSITS_H1_H2,
			DFT_AVG_CHARGEOFFAMOUNT_DEPOSITS_H1_H2,
			SAVINGS_StaticpoolFlag,
			CHECKING_StaticpoolFlag,
			CERTIFICATES_StaticpoolFlag,
			MONEYMARKET_StaticpoolFlag,
			SSN004,
			TRANSACTION_COUNT_SAVINGS_Q1,
			DFT_TRANSACTION_COUNT_SAVINGS_Q1_Q2,
			TRANSACTION_AMOUNT_SAVINGS_Q1,
			DFT_TRANSACTION_AMOUNT_SAVINGS_Q1_Q2,
			AVG_TRANSACTION_SAVINGS_Q1,
			DFT_AVG_TRANSACTION_SAVINGS_Q1_Q2,
			DEPOSITED_AMOUNT_SAVINGS_Q1,
			DFT_DEPOSITED_AMOUNT_SAVINGS_Q1_Q2,
			DEPOSITED_COUNT_SAVINGS_Q1,
			DFT_DEPOSITED_COUNT_SAVINGS_Q1_Q2,
			WITHDRAWAL_AMOUNT_SAVINGS_Q1,
			DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q2,
			DFT_WITHDRAWAL_AMOUNT_SAVINGS_Q1_Q3,
			WITHDRAWAL_COUNT_SAVINGS_Q1,
			DFT_WITHDRAWAL_COUNT_SAVINGS_Q1_Q2,
			TRANSACTION_COUNT_CHECKING_Q1,
			DFT_TRANSACTION_COUNT_CHECKING_Q1_Q2,
			TRANSACTION_AMOUNT_CHECKING_Q1,
			DFT_TRANSACTION_AMOUNT_CHECKING_Q1_Q2,
			AVG_TRANSACTION_CHECKING_Q1,
			DFT_AVG_TRANSACTION_CHECKING_Q1_Q2,
			DEPOSITED_AMOUNT_CHECKING_Q1,
			DFT_DEPOSITED_AMOUNT_CHECKING_Q1_Q2,
			DEPOSITED_COUNT_CHECKING_Q1,
			DFT_DEPOSITED_COUNT_CHECKING_Q1_Q2,
			WITHDRAWAL_AMOUNT_CHECKING_Q1,
			DFT_WITHDRAWAL_AMOUNT_CHECKING_Q1_Q2,
			WITHDRAWAL_COUNT_CHECKING_Q1,
			DFT_WITHDRAWAL_COUNT_CHECKING_Q1_Q2,
			TRANSACTION_COUNT_CERTIFICATES_Q1,
			DFT_TRANSACTION_COUNT_CERTIFICATES_Q1_Q2,
			TRANSACTION_AMOUNT_CERTIFICATES_Q1,
			DFT_TRANSACTION_AMOUNT_CERTIFICATES_Q1_Q2,
			AVG_TRANSACTION_CERTIFICATES_Q1,
			DFT_AVG_TRANSACTION_CERTIFICATES_Q1_Q2,
			DEPOSITED_AMOUNT_CERTIFICATES_Q1,
			DFT_DEPOSITED_AMOUNT_CERTIFICATES_Q1_Q2,
			DEPOSITED_COUNT_CERTIFICATES_Q1,
			DFT_DEPOSITED_COUNT_CERTIFICATES_Q1_Q2,
			WITHDRAWAL_AMOUNT_CERTIFICATES_Q1,
			DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_Q1_Q2,
			WITHDRAWAL_COUNT_CERTIFICATES_Q1,
			DFT_WITHDRAWAL_COUNT_CERTIFICATES_Q1_Q2,
			SUM_INTEREST_CERTIFICATES_Q1,
			DFT_SUM_INTEREST_CERTIFICATES_Q1_Q2,
			TRANSACTION_COUNT_MONEYMARKET_Q1,
			DFT_TRANSACTION_COUNT_MONEYMARKET_Q1_Q2,
			TRANSACTION_AMOUNT_MONEYMARKET_Q1,
			DFT_TRANSACTION_AMOUNT_MONEYMARKET_Q1_Q2,
			AVG_TRANSACTION_MONEYMARKET_Q1,
			DFT_AVG_TRANSACTION_MONEYMARKET_Q1_Q2,
			DEPOSITED_AMOUNT_MONEYMARKET_Q1,
			DFT_DEPOSITED_AMOUNT_MONEYMARKET_Q1_Q2,
			DEPOSITED_COUNT_MONEYMARKET_Q1,
			DFT_DEPOSITED_COUNT_MONEYMARKET_Q1_Q2,
			WITHDRAWAL_AMOUNT_MONEYMARKET_Q1,
			DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_Q1_Q2,
			WITHDRAWAL_COUNT_MONEYMARKET_Q1,
			DFT_WITHDRAWAL_COUNT_MONEYMARKET_Q1_Q2,
			TRANSACTION_COUNT_DEPOSITS_Q1,
			DFT_TRANSACTION_COUNT_DEPOSITS_Q1_Q2,
			TRANSACTION_AMOUNT_DEPOSITS_Q1,
			DFT_TRANSACTION_AMOUNT_DEPOSITS_Q1_Q2,
			AVG_TRANSACTION_DEPOSITS_Q1,
			DFT_AVG_TRANSACTION_DEPOSITS_Q1_Q2,
			DEPOSITED_AMOUNT_DEPOSITS_Q1,
			DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q2,
			DFT_DEPOSITED_AMOUNT_DEPOSITS_Q1_Q3,
			DEPOSITED_COUNT_DEPOSITS_Q1,
			DFT_DEPOSITED_COUNT_DEPOSITS_Q1_Q2,
			WITHDRAWAL_AMOUNT_DEPOSITS_Q1,
			DFT_WITHDRAWAL_AMOUNT_DEPOSITS_Q1_Q2,
			WITHDRAWAL_COUNT_DEPOSITS_Q1,
			DFT_WITHDRAWAL_COUNT_DEPOSITS_Q1_Q2,
			SUM_INTEREST_DEPOSITS_Q1,
			DFT_SUM_INTEREST_DEPOSITS_Q1_Q2,
			DFT_TRANSACTION_COUNT_SAVINGS_H1_H2,
			DFT_TRANSACTION_AMOUNT_SAVINGS_H1_H2,
			DFT_AVG_TRANSACTION_SAVINGS_H1_H2,
			DFT_DEPOSITED_AMOUNT_SAVINGS_H1_H2,
			DFT_DEPOSITED_COUNT_SAVINGS_H1_H2,
			DFT_WITHDRAWAL_AMOUNT_SAVINGS_H1_H2,
			DFT_WITHDRAWAL_COUNT_SAVINGS_H1_H2,
			DFT_TRANSACTION_COUNT_CHECKING_H1_H2,
			DFT_TRANSACTION_AMOUNT_CHECKING_H1_H2,
			DFT_AVG_TRANSACTION_CHECKING_H1_H2,
			DFT_DEPOSITED_AMOUNT_CHECKING_H1_H2,
			DFT_DEPOSITED_COUNT_CHECKING_H1_H2,
			DFT_WITHDRAWAL_AMOUNT_CHECKING_H1_H2,
			DFT_WITHDRAWAL_COUNT_CHECKING_H1_H2,
			DFT_TRANSACTION_COUNT_CERTIFICATES_H1_H2,
			DFT_TRANSACTION_AMOUNT_CERTIFICATES_H1_H2,
			DFT_AVG_TRANSACTION_CERTIFICATES_H1_H2,
			DFT_DEPOSITED_AMOUNT_CERTIFICATES_H1_H2,
			DFT_DEPOSITED_COUNT_CERTIFICATES_H1_H2,
			DFT_WITHDRAWAL_AMOUNT_CERTIFICATES_H1_H2,
			DFT_WITHDRAWAL_COUNT_CERTIFICATES_H1_H2,
			DFT_SUM_INTEREST_CERTIFICATES_H1_H2,
			DFT_TRANSACTION_COUNT_MONEYMARKET_H1_H2,
			DFT_TRANSACTION_AMOUNT_MONEYMARKET_H1_H2,
			DFT_AVG_TRANSACTION_MONEYMARKET_H1_H2,
			DFT_DEPOSITED_AMOUNT_MONEYMARKET_H1_H2,
			DFT_DEPOSITED_COUNT_MONEYMARKET_H1_H2,
			DFT_WITHDRAWAL_AMOUNT_MONEYMARKET_H1_H2,
			DFT_WITHDRAWAL_COUNT_MONEYMARKET_H1_H2,
			DFT_TRANSACTION_COUNT_DEPOSITS_H1_H2,
			DFT_TRANSACTION_AMOUNT_DEPOSITS_H1_H2,
			DFT_AVG_TRANSACTION_DEPOSITS_H1_H2,
			DFT_DEPOSITED_AMOUNT_DEPOSITS_H1_H2,
			DFT_DEPOSITED_COUNT_DEPOSITS_H1_H2,
			DFT_WITHDRAWAL_AMOUNT_DEPOSITS_H1_H2,
			DFT_WITHDRAWAL_COUNT_DEPOSITS_H1_H2,
			DFT_SUM_INTEREST_DEPOSITS_H1_H2,
			SSN001,
			PRODUCT_RealEstate_Q1,
			DFT_PRODUCT_RealEstate_Q1_Q2,
			PRODUCT_SecuredLoan_Q1,
			DFT_PRODUCT_SecuredLoan_Q1_Q2,
			PRODUCT_UnsecuredLoan_Q1,
			DFT_PRODUCT_UnsecuredLoan_Q1_Q2,
			PRODUCT_VehicleLoan_Q1,
			DFT_PRODUCT_VehicleLoan_Q1_Q2,
			DFT_PRODUCT_Loan_Q1_Q2,
			RealEstate_MOB,
			SecuredLoan_MOB,
			UnsecuredLoan_MOB,
			Vehicleloan_MOB,
			MAX_Loan_MOB,
			PAYMENTCOUNT_RealEstate_Q1,
			DFT_PAYMENTCOUNT_RealEstate_Q1_Q2,
			PAYMENTCOUNT_SecuredLoan_Q1,
			DFT_PAYMENTCOUNT_SecuredLoan_Q1_Q2,
			PAYMENTCOUNT_UnsecuredLoan_Q1,
			DFT_PAYMENTCOUNT_UnsecuredLoan_Q1_Q2,
			PAYMENTCOUNT_VehicleLoan_Q1,
			DFT_PAYMENTCOUNT_VehicleLoan_Q1_Q2,
			PAYMENTCOUNT_Loan_Q1,
			DFT_PAYMENTCOUNT_Loan_Q1_Q2,
			SUM_OriginalBalance_RealEstate_Q1,
			DFT_SUM_OriginalBalance_RealEstate_Q1_Q2,
			SUM_OriginalBalance_SecuredLoan_Q1,
			DFT_SUM_OriginalBalance_SecuredLoan_Q1_Q2,
			SUM_OriginalBalance_UnsecuredLoan_Q1,
			DFT_SUM_OriginalBalance_UnsecuredLoan_Q1_Q2,
			SUM_OriginalBalance_VehicleLoan_Q1,
			DFT_SUM_OriginalBalance_VehicleLoan_Q1_Q2,
			SUM_OriginalBalance_Loan_Q1,
			DFT_SUM_OriginalBalance_Loan_Q1_Q2,
			SUM_PAYMENT_RealEstate_Q1,
			DFT_SUM_PAYMENT_RealEstate_Q1_Q2,
			SUM_PAYMENT_SecuredLoan_Q1,
			DFT_SUM_PAYMENT_SecuredLoan_Q1_Q2,
			SUM_PAYMENT_UnsecuredLoan_Q1,
			DFT_SUM_PAYMENT_UnsecuredLoan_Q1_Q2,
			SUM_PAYMENT_VehicleLoan_Q1,
			DFT_SUM_PAYMENT_VehicleLoan_Q1_Q2,
			SUM_PAYMENT_Loan_Q1,
			DFT_SUM_PAYMENT_Loan_Q1_Q2,
			MAX_INTERESTRATE_RealEstate_Q1,
			DFT_MAX_INTERESTRATE_RealEstate_Q1_Q2,
			MAX_INTERESTRATE_SecuredLoan_Q1,
			DFT_MAX_INTERESTRATE_SecuredLoan_Q1_Q2,
			MAX_INTERESTRATE_UnsecuredLoan_Q1,
			DFT_MAX_INTERESTRATE_UnsecuredLoan_Q1_Q2,
			MAX_INTERESTRATE_VehicleLoan_Q1,
			DFT_MAX_INTERESTRATE_VehicleLoan_Q1_Q2,
			MAX_INTERESTRATE_Loan_Q1,
			DFT_MAX_INTERESTRATE_Loan_Q1_Q2,
			MAX_CREDITLIMIT_RealEstate_Q1,
			DFT_MAX_CREDITLIMIT_RealEstate_Q1_Q2,
			MAX_CREDITLIMIT_UnsecuredLoan_Q1,
			MAX_CREDITLIMIT_Loan_Q1,
			DFT_MAX_CREDITLIMIT_Loan_Q1_Q2,
			AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q1,
			DFT_AVG_CHARGEOFFAMOUNT_Real_Estate_loan_Q1_Q2,
			AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q1,
			DFT_AVG_CHARGEOFFAMOUNT_UnsecuredLoan_Q1_Q2,
			AVG_CHARGEOFFAMOUNT_SecuredLoan_Q1,
			AVG_CHARGEOFFAMOUNT_Vehicleloan_Q1,
			DFT_AVG_CHARGEOFFAMOUNT_Vehicleloan_Q1_Q2,
			AVG_CHARGEOFFAMOUNT_Loan_Q1,
			DFT_AVG_CHARGEOFFAMOUNT_Loan_Q1_Q2,
			--COUNT_DUEDAY1_RealEstate_Q1,
			--COUNT_DUEDAY1_RealEstate_Q2,
			--COUNT_DUEDAY1_SecuredLoan_Q1,
			--COUNT_DUEDAY1_SecuredLoan_Q2,
			--COUNT_DUEDAY1_UnsecuredLoan_Q1,
			--COUNT_DUEDAY1_UnsecuredLoan_Q2,
			--COUNT_DUEDAY1_VehicleLoan_Q1,
			--COUNT_DUEDAY1_VehicleLoan_Q2,
			DFT_PRODUCT_RealEstate_H1_H2,
			DFT_PRODUCT_SecuredLoan_H1_H2,
			DFT_PRODUCT_UnsecuredLoan_H1_H2,
			DFT_PRODUCT_VehicleLoan_H1_H2,
			DFT_PRODUCT_Loan_H1_H2,
			DFT_PAYMENTCOUNT_RealEstate_H1_H2,
			DFT_PAYMENTCOUNT_SecuredLoan_H1_H2,
			DFT_PAYMENTCOUNT_UnsecuredLoan_H1_H2,
			DFT_PAYMENTCOUNT_VehicleLoan_H1_H2,
			DFT_PAYMENTCOUNT_Loan_H1_H2,
			DFT_SUM_OriginalBalance_RealEstate_H1_H2,
			DFT_SUM_OriginalBalance_SecuredLoan_H1_H2,
			DFT_SUM_OriginalBalance_UnsecuredLoan_H1_H2,
			DFT_SUM_OriginalBalance_VehicleLoan_H1_H2,
			DFT_SUM_OriginalBalance_Loan_H1_H2,
			DFT_SUM_PAYMENT_RealEstate_H1_H2,
			DFT_SUM_PAYMENT_SecuredLoan_H1_H2,
			DFT_SUM_PAYMENT_UnsecuredLoan_H1_H2,
			DFT_SUM_PAYMENT_VehicleLoan_H1_H2,
			DFT_SUM_PAYMENT_Loan_H1_H2,
			DFT_MAX_INTERESTRATE_RealEstate_H1_H2,
			DFT_MAX_INTERESTRATE_SecuredLoan_H1_H2,
			DFT_MAX_INTERESTRATE_UnsecuredLoan_H1_H2,
			DFT_MAX_INTERESTRATE_VehicleLoan_H1_H2,
			DFT_MAX_INTERESTRATE_Loan_H1_H2,
			DFT_MAX_CREDITLIMIT_RealEstate_H1_H2,
			DFT_MAX_CREDITLIMIT_UnsecuredLoan_H1_H2,
			DFT_MAX_CREDITLIMIT_Loan_H1_H2,
			DFT_AVG_CHARGEOFFAMOUNT_Real_Estate_loan_H1_H2,
			DFT_AVG_CHARGEOFFAMOUNT_UnsecuredLoan_H1_H2,
			DFT_AVG_CHARGEOFFAMOUNT_SecuredLoan_H1_H2,
			DFT_AVG_CHARGEOFFAMOUNT_Vehicleloan_H1_H2,
			DFT_AVG_CHARGEOFFAMOUNT_Loan_H1_H2,
			--COUNT_DUEDAY1_RealEstate_H1,
			--COUNT_DUEDAY1_RealEstate_H2,
			--COUNT_DUEDAY1_SecuredLoan_H1,
			--COUNT_DUEDAY1_SecuredLoan_H2,
			--COUNT_DUEDAY1_UnsecuredLoan_H1,
			--COUNT_DUEDAY1_UnsecuredLoan_H2,
			--COUNT_DUEDAY1_VehicleLoan_H1,
			--COUNT_DUEDAY1_VehicleLoan_H2,
			RealEstate_Month_to_Maturity,
			SecuredLoan_Month_to_Maturity,
			UnsecuredLoan_Month_to_Maturity,
			Vehicleloan_Month_to_Maturity,
			Max_Loan_Month_to_Maturity,
			Delinquency_RealEstate_SP,
			Delinquency_SecuredLoan_SP,
			Delinquency_UnsecuredLoan_SP,
			Delinquency_Vehicleloan_SP,
			Delinquency_Others_SP,
			Delinquency_Loan_SP,
			RealEstate_StaticPoolFlag,
			SecuredLoan_StaticPoolFlag,
			UnsecuredLoan_StaticPoolFlag,
			VehicleLoan_StaticPoolFlag,
			MAX_DAYSINCEDUEDATE_Real_Estate_loan_SP,
			MAX_DAYSINCEDUEDATE_Real_Estate_loan_Q1,
			MAX_DAYSINCEDUEDATE_Real_Estate_loan_Q2,
			MAX_DAYSINCEDUEDATE_Real_Estate_loan_H1,
			MAX_DAYSINCEDUEDATE_Real_Estate_loan_H2,
			MAX_DAYSINCEDUEDATE_SecuredLoan_SP,
			MAX_DAYSINCEDUEDATE_SecuredLoan_Q1,
			MAX_DAYSINCEDUEDATE_SecuredLoan_Q2,
			MAX_DAYSINCEDUEDATE_SecuredLoan_H1,
			MAX_DAYSINCEDUEDATE_SecuredLoan_H2,
			MAX_DAYSINCEDUEDATE_UnsecuredLoan_SP,
			MAX_DAYSINCEDUEDATE_UnsecuredLoan_Q1,
			MAX_DAYSINCEDUEDATE_UnsecuredLoan_Q2,
			MAX_DAYSINCEDUEDATE_UnsecuredLoan_H1,
			MAX_DAYSINCEDUEDATE_UnsecuredLoan_H2,
			MAX_DAYSINCEDUEDATE_Vehicleloan_SP,
			MAX_DAYSINCEDUEDATE_Vehicleloan_Q1,
			MAX_DAYSINCEDUEDATE_Vehicleloan_Q2,
			MAX_DAYSINCEDUEDATE_Vehicleloan_H1,
			MAX_DAYSINCEDUEDATE_Vehicleloan_H2,
			MAX_DAYSINCEDUEDATE_Loan_SP,
			MAX_DAYSINCEDUEDATE_Loan_Q1,
			MAX_DAYSINCEDUEDATE_Loan_Q2,
			MAX_DAYSINCEDUEDATE_Loan_H1,
			MAX_DAYSINCEDUEDATE_Loan_H2,
			MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_SP,
			MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_Q1,
			MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_Q2,
			MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_H1,
			MAX_DFT_DUEPAYMENTDAYS_Real_Estate_loan_H2,
			MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_SP,
			MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_Q1,
			MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_Q2,
			MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_H1,
			MAX_DFT_DUEPAYMENTDAYS_SecuredLoan_H2,
			MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_SP,
			MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_Q1,
			MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_Q2,
			MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_H1,
			MAX_DFT_DUEPAYMENTDAYS_UnsecuredLoan_H2,
			MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_SP,
			MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_Q1,
			MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_Q2,
			MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H1,
			MAX_DFT_DUEPAYMENTDAYS_Vehicleloan_H2,
			MAX_DFT_DUEPAYMENTDAYS_Loan_SP,
			MAX_DFT_DUEPAYMENTDAYS_Loan_Q1,
			MAX_DFT_DUEPAYMENTDAYS_Loan_Q2,
			MAX_DFT_DUEPAYMENTDAYS_Loan_H1,
			MAX_DFT_DUEPAYMENTDAYS_Loan_H2,
			CREDIT_SCORE_SP,
			DFT_CREDIT_SCORE_SP_Q4,
			SSN002,
			COUNT_LOAN_ADDON_STATICPOOL,
			COUNT_LOAN_ADDON_Q1,
			DFT_COUNT_LOAN_ADDON_Q1_Q2,
			COUNT_NEW_LOAN_STATICPOOL,
			COUNT_NEW_LOAN_Q1,
			DFT_COUNT_NEW_LOAN_Q1_Q2,
			COUNT_LOAN_PAYMENT_STATICPOOL,
			COUNT_LOAN_PAYMENT_Q1,
			DFT_COUNT_LOAN_PAYMENT_Q1_Q2,
			COUNT_CASH_STATICPOOL,
			COUNT_CASH_Q1,
			DFT_COUNT_CASH_Q1_Q2,
			COUNT_DRAFT_STATICPOOL,
			COUNT_DRAFT_Q1,
			DFT_COUNT_DRAFT_Q1_Q2,
			COUNT_ACH_STATICPOOL,
			COUNT_ACH_Q1,
			DFT_COUNT_ACH_Q1_Q2,
			COUNT_FEE_STATICPOOL,
			COUNT_FEE_Q1,
			DFT_COUNT_FEE_Q1_Q2,
			COUNT_HOMEBANKING_STATICPOOL,
			COUNT_HOMEBANKING_Q1,
			DFT_COUNT_HOMEBANKING_Q1_Q2,
			COUNT_INSURANCE_STATICPOOL,
			COUNT_INSURANCE_Q1,
			DFT_COUNT_INSURANCE_Q1_Q2,
			COUNT_CHECKS_STATICPOOL,
			COUNT_CHECKS_Q1,
			DFT_COUNT_CHECKS_Q1_Q2,
			COUNT_KIOSK_STATICPOOL,
			COUNT_KIOSK_Q1,
			DFT_COUNT_KIOSK_Q1_Q2,
			COUNT_LOAN_ADDON_RealEstate_Q1,
			DFT_COUNT_LOAN_ADDON_RealEstate_Q1_Q2,
			COUNT_NEW_LOAN_RealEstate_Q1,
			COUNT_NEW_LOAN_RealEstate_Q1_Q2,
			COUNT_LOAN_PAYMENT_RealEstate_Q1,
			DFT_COUNT_LOAN_PAYMENT_RealEstate_Q1_Q2,
			COUNT_CASH_RealEstate_Q1,
			DFT_COUNT_CASH_RealEstate_Q1_Q2,
			COUNT_DRAFT_RealEstate_Q1,
			DFT_COUNT_DRAFT_RealEstate_Q1_Q2,
			COUNT_ACH_RealEstate_Q1,
			DFT_COUNT_ACH_RealEstate_Q1_Q2,
			COUNT_FEE_RealEstate_Q1,
			DFT_COUNT_FEE_RealEstate_Q1_Q2,
			COUNT_HOMEBANKING_RealEstate_Q1,
			DFT_COUNT_HOMEBANKING_RealEstate_Q1_Q2,
			COUNT_INSURANCE_RealEstate_Q1,
			DFT_COUNT_INSURANCE_RealEstate_Q1_Q2,
			COUNT_CHECKS_RealEstate_Q1,
			DFT_COUNT_CHECKS_RealEstate_Q1_Q2,
			COUNT_KIOSK_RealEstate_Q1,
			DFT_COUNT_KIOSK_RealEstate_Q1_Q2,
			LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,
			DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2,
			INTEREST_AMOUNT_RealEstate_Q1,
			DFT_INTEREST_AMOUNT_RealEstate_Q1_Q2,
			FEEAMOUNT_RealEstate_Q1,
			DFT_FEEAMOUNT_RealEstate_Q1_Q2,
			AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1,
			DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_Q1_Q2,
			AVG_NEWBALANCE_RealEstate_Q1,
			DFT_AVG_NEWBALANCE_RealEstate_Q1_Q2,
			AVG_FEEAMOUNT_RealEstate_Q1,
			DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q2,
			DFT_AVG_FEEAMOUNT_RealEstate_Q1_Q3,
			COUNT_LOAN_ADDON_SecuredLoan_Q1,
			DFT_COUNT_LOAN_ADDON_SecuredLoan_Q1_Q2,
			COUNT_NEW_LOAN_SecuredLoan_Q1,
			COUNT_NEW_LOAN_SecuredLoan_Q1_Q2,
			COUNT_LOAN_PAYMENT_SecuredLoan_Q1,
			DFT_COUNT_LOAN_PAYMENT_SecuredLoan_Q1_Q2,
			COUNT_CASH_SecuredLoan_Q1,
			DFT_COUNT_CASH_SecuredLoan_Q1_Q2,
			COUNT_DRAFT_SecuredLoan_Q1,
			DFT_COUNT_DRAFT_SecuredLoan_Q1_Q2,
			COUNT_ACH_SecuredLoan_Q1,
			DFT_COUNT_ACH_SecuredLoan_Q1_Q2,
			COUNT_FEE_SecuredLoan_Q1,
			DFT_COUNT_FEE_SecuredLoan_Q1_Q2,
			COUNT_HOMEBANKING_SecuredLoan_Q1,
			DFT_COUNT_HOMEBANKING_SecuredLoan_Q1_Q2,
			COUNT_INSURANCE_SecuredLoan_Q1,
			DFT_COUNT_INSURANCE_SecuredLoan_Q1_Q2,
			COUNT_CHECKS_SecuredLoan_Q1,
			DFT_COUNT_CHECKS_SecuredLoan_Q1_Q2,
			COUNT_KIOSK_SecuredLoan_Q1,
			DFT_COUNT_KIOSK_SecuredLoan_Q1_Q2,
			LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,
			DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2,
			INTEREST_AMOUNT_SecuredLoan_Q1,
			DFT_INTEREST_AMOUNT_SecuredLoan_Q1_Q2,
			FEEAMOUNT_SecuredLoan_Q1,
			DFT_FEEAMOUNT_SecuredLoan_Q1_Q2,
			AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1,
			DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_Q1_Q2,
			AVG_NEWBALANCE_SecuredLoan_Q1,
			DFT_AVG_NEWBALANCE_SecuredLoan_Q1_Q2,
			AVG_FEEAMOUNT_SecuredLoan_Q1,
			DFT_AVG_FEEAMOUNT_SecuredLoan_Q1_Q2,
			COUNT_LOAN_ADDON_UnsecuredLoan_Q1,
			DFT_COUNT_LOAN_ADDON_UnsecuredLoan_Q1_Q2,
			COUNT_NEW_LOAN_UnsecuredLoan_Q1,
			COUNT_NEW_LOAN_UnsecuredLoan_Q1_Q2,
			COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1,
			DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_Q1_Q2,
			COUNT_CASH_UnsecuredLoan_Q1,
			DFT_COUNT_CASH_UnsecuredLoan_Q1_Q2,
			COUNT_DRAFT_UnsecuredLoan_Q1,
			DFT_COUNT_DRAFT_UnsecuredLoan_Q1_Q2,
			COUNT_ACH_UnsecuredLoan_Q1,
			DFT_COUNT_ACH_UnsecuredLoan_Q1_Q2,
			COUNT_FEE_UnsecuredLoan_Q1,
			DFT_COUNT_FEE_UnsecuredLoan_Q1_Q2,
			COUNT_HOMEBANKING_UnsecuredLoan_Q1,
			DFT_COUNT_HOMEBANKING_UnsecuredLoan_Q1_Q2,
			COUNT_INSURANCE_UnsecuredLoan_Q1,
			DFT_COUNT_INSURANCE_UnsecuredLoan_Q1_Q2,
			COUNT_CHECKS_UnsecuredLoan_Q1,
			DFT_COUNT_CHECKS_UnsecuredLoan_Q1_Q2,
			COUNT_KIOSK_UnsecuredLoan_Q1,
			DFT_COUNT_KIOSK_UnsecuredLoan_Q1_Q2,
			LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,
			DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2,
			INTEREST_AMOUNT_UnsecuredLoan_Q1,
			DFT_INTEREST_AMOUNT_UnsecuredLoan_Q1_Q2,
			FEEAMOUNT_UnsecuredLoan_Q1,
			DFT_FEEAMOUNT_UnsecuredLoan_Q1_Q2,
			AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1,
			DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_Q1_Q2,
			AVG_NEWBALANCE_UnsecuredLoan_Q1,
			DFT_AVG_NEWBALANCE_UnsecuredLoan_Q1_Q2,
			AVG_FEEAMOUNT_UnsecuredLoan_Q1,
			DFT_AVG_FEEAMOUNT_UnsecuredLoan_Q1_Q2,
			COUNT_LOAN_ADDON_VehicleLoan_Q1,
			DFT_COUNT_LOAN_ADDON_VehicleLoan_Q1_Q2,
			COUNT_NEW_LOAN_VehicleLoan_Q1,
			COUNT_NEW_LOAN_VehicleLoan_Q1_Q2,
			COUNT_LOAN_PAYMENT_VehicleLoan_Q1,
			DFT_COUNT_LOAN_PAYMENT_VehicleLoan_Q1_Q2,
			COUNT_CASH_VehicleLoan_Q1,
			DFT_COUNT_CASH_VehicleLoan_Q1_Q2,
			COUNT_DRAFT_VehicleLoan_Q1,
			DFT_COUNT_DRAFT_VehicleLoan_Q1_Q2,
			COUNT_ACH_VehicleLoan_Q1,
			DFT_COUNT_ACH_VehicleLoan_Q1_Q2,
			COUNT_FEE_VehicleLoan_Q1,
			DFT_COUNT_FEE_VehicleLoan_Q1_Q2,
			COUNT_HOMEBANKING_VehicleLoan_Q1,
			DFT_COUNT_HOMEBANKING_VehicleLoan_Q1_Q2,
			COUNT_INSURANCE_VehicleLoan_Q1,
			DFT_COUNT_INSURANCE_VehicleLoan_Q1_Q2,
			COUNT_CHECKS_VehicleLoan_Q1,
			DFT_COUNT_CHECKS_VehicleLoan_Q1_Q2,
			COUNT_KIOSK_VehicleLoan_Q1,
			DFT_COUNT_KIOSK_VehicleLoan_Q1_Q2,
			LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,
			DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2,
			INTEREST_AMOUNT_VehicleLoan_Q1,
			DFT_INTEREST_AMOUNT_VehicleLoan_Q1_Q2,
			FEEAMOUNT_VehicleLoan_Q1,
			DFT_FEEAMOUNT_VehicleLoan_Q1_Q2,
			AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1,
			DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_Q1_Q2,
			AVG_NEWBALANCE_VehicleLoan_Q1,
			DFT_AVG_NEWBALANCE_VehicleLoan_Q1_Q2,
			AVG_FEEAMOUNT_VehicleLoan_Q1,
			DFT_AVG_FEEAMOUNT_VehicleLoan_Q1_Q2,
			DFT_COUNT_LOAN_ADDON_H1_H2,
			DFT_COUNT_NEW_LOAN_H1_H2,
			DFT_COUNT_LOAN_PAYMENT_H1_H2,
			DFT_COUNT_CASH_H1_H2,
			DFT_COUNT_DRAFT_H1_H2,
			DFT_COUNT_ACH_H1_H2,
			DFT_COUNT_FEE_H1_H2,
			DFT_COUNT_HOMEBANKING_H1_H2,
			DFT_COUNT_INSURANCE_H1_H2,
			DFT_COUNT_CHECKS_H1_H2,
			DFT_COUNT_KIOSK_H1_H2,
			DFT_COUNT_LOAN_ADDON_RealEstate_H1_H2,
			COUNT_NEW_LOAN_RealEstate_H1_H2,
			DFT_COUNT_LOAN_PAYMENT_RealEstate_H1_H2,
			DFT_COUNT_CASH_RealEstate_H1_H2,
			DFT_COUNT_DRAFT_RealEstate_H1_H2,
			DFT_COUNT_ACH_RealEstate_H1_H2,
			DFT_COUNT_FEE_RealEstate_H1_H2,
			DFT_COUNT_HOMEBANKING_RealEstate_H1_H2,
			DFT_COUNT_INSURANCE_RealEstate_H1_H2,
			DFT_COUNT_CHECKS_RealEstate_H1_H2,
			DFT_COUNT_KIOSK_RealEstate_H1_H2,
			DFT_LOAN_TRANSACTION_AMOUNT_RealEstate_H1_H2,
			DFT_INTEREST_AMOUNT_RealEstate_H1_H2,
			DFT_FEEAMOUNT_RealEstate_H1_H2,
			DFT_AVG_LOAN_TRANSACTION_AMOUNT_RealEstate_H1_H2,
			DFT_AVG_NEWBALANCE_RealEstate_H1_H2,
			DFT_AVG_FEEAMOUNT_RealEstate_H1_H2,
			DFT_COUNT_LOAN_ADDON_SecuredLoan_H1_H2,
			COUNT_NEW_LOAN_SecuredLoan_H1_H2,
			DFT_COUNT_LOAN_PAYMENT_SecuredLoan_H1_H2,
			DFT_COUNT_CASH_SecuredLoan_H1_H2,
			DFT_COUNT_DRAFT_SecuredLoan_H1_H2,
			DFT_COUNT_ACH_SecuredLoan_H1_H2,
			DFT_COUNT_FEE_SecuredLoan_H1_H2,
			DFT_COUNT_HOMEBANKING_SecuredLoan_H1_H2,
			DFT_COUNT_INSURANCE_SecuredLoan_H1_H2,
			DFT_COUNT_CHECKS_SecuredLoan_H1_H2,
			DFT_COUNT_KIOSK_SecuredLoan_H1_H2,
			DFT_LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1_H2,
			DFT_INTEREST_AMOUNT_SecuredLoan_H1_H2,
			DFT_FEEAMOUNT_SecuredLoan_H1_H2,
			DFT_AVG_LOAN_TRANSACTION_AMOUNT_SecuredLoan_H1_H2,
			DFT_AVG_NEWBALANCE_SecuredLoan_H1_H2,
			DFT_AVG_FEEAMOUNT_SecuredLoan_H1_H2,
			DFT_COUNT_LOAN_ADDON_UnsecuredLoan_H1_H2,
			COUNT_NEW_LOAN_UnsecuredLoan_H1_H2,
			DFT_COUNT_LOAN_PAYMENT_UnsecuredLoan_H1_H2,
			DFT_COUNT_CASH_UnsecuredLoan_H1_H2,
			DFT_COUNT_DRAFT_UnsecuredLoan_H1_H2,
			DFT_COUNT_ACH_UnsecuredLoan_H1_H2,
			DFT_COUNT_FEE_UnsecuredLoan_H1_H2,
			DFT_COUNT_HOMEBANKING_UnsecuredLoan_H1_H2,
			DFT_COUNT_INSURANCE_UnsecuredLoan_H1_H2,
			DFT_COUNT_CHECKS_UnsecuredLoan_H1_H2,
			DFT_COUNT_KIOSK_UnsecuredLoan_H1_H2,
			DFT_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1_H2,
			DFT_INTEREST_AMOUNT_UnsecuredLoan_H1_H2,
			DFT_FEEAMOUNT_UnsecuredLoan_H1_H2,
			DFT_AVG_LOAN_TRANSACTION_AMOUNT_UnsecuredLoan_H1_H2,
			DFT_AVG_NEWBALANCE_UnsecuredLoan_H1_H2,
			DFT_AVG_FEEAMOUNT_UnsecuredLoan_H1_H2,
			DFT_COUNT_LOAN_ADDON_VehicleLoan_H1_H2,
			COUNT_NEW_LOAN_VehicleLoan_H1_H2,
			DFT_COUNT_LOAN_PAYMENT_VehicleLoan_H1_H2,
			DFT_COUNT_CASH_VehicleLoan_H1_H2,
			DFT_COUNT_DRAFT_VehicleLoan_H1_H2,
			DFT_COUNT_ACH_VehicleLoan_H1_H2,
			DFT_COUNT_FEE_VehicleLoan_H1_H2,
			DFT_COUNT_HOMEBANKING_VehicleLoan_H1_H2,
			DFT_COUNT_INSURANCE_VehicleLoan_H1_H2,
			DFT_COUNT_CHECKS_VehicleLoan_H1_H2,
			DFT_COUNT_KIOSK_VehicleLoan_H1_H2,
			DFT_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2,
			DFT_INTEREST_AMOUNT_VehicleLoan_H1_H2,
			DFT_FEEAMOUNT_VehicleLoan_H1_H2,
			DFT_AVG_LOAN_TRANSACTION_AMOUNT_VehicleLoan_H1_H2,
			DFT_AVG_NEWBALANCE_VehicleLoan_H1_H2,
			DFT_AVG_FEEAMOUNT_VehicleLoan_H1_H2,
			SSN_DLQ,
			ProductRealEstate_Cycle1_SP,
			ProductRealEstate_Cycle2_SP,
			ProductRealEstate_Cycle2plus_SP,
			ProductSecuredLoan_Cycle1_SP,
			ProductSecuredLoan_Cycle2_SP,
			ProductSecuredLoan_Cycle2plus_SP,
			ProductUnsecuredLoan_Cycle1_SP,
			ProductUnsecuredLoan_Cycle2_SP,
			ProductUnsecuredLoan_Cycle2plus_SP,
			ProductVehicleLoan_Cycle1_SP,
			ProductVehicleLoan_Cycle2_SP,
			ProductVehicleLoan_Cycle2plus_SP,
			ProductLoan_Cycle1_SP,
			ProductLoan_Cycle2_SP,
			ProductLoan_Cycle2plus_SP,
			ProductRealEstate_Cycle1_3MonthBack,
			ProductRealEstate_Cycle2_3MonthBack,
			ProductRealEstate_Cycle2plus_3MonthBack,
			ProductSecuredLoan_Cycle1_3MonthBack,
			ProductSecuredLoan_Cycle2_3MonthBack,
			ProductSecuredLoan_Cycle2plus_3MonthBack,
			ProductUnsecuredLoan_Cycle1_3MonthBack,
			ProductUnsecuredLoan_Cycle2_3MonthBack,
			ProductUnsecuredLoan_Cycle2plus_3MonthBack,
			ProductVehicleLoan_Cycle1_3MonthBack,
			ProductVehicleLoan_Cycle2_3MonthBack,
			ProductVehicleLoan_Cycle2plus_3MonthBack,
			ProductLoan_Cycle1_3MonthBack,
			ProductLoan_Cycle2_3MonthBack,
			ProductLoan_Cycle2plus_3MonthBack,
			ProductRealEstate_Cycle1_6MonthBack,
			ProductRealEstate_Cycle2_6MonthBack,
			ProductRealEstate_Cycle2plus_6MonthBack,
			ProductSecuredLoan_Cycle1_6MonthBack,
			ProductSecuredLoan_Cycle2_6MonthBack,
			ProductSecuredLoan_Cycle2plus_6MonthBack,
			ProductUnsecuredLoan_Cycle1_6MonthBack,
			ProductUnsecuredLoan_Cycle2_6MonthBack,
			ProductUnsecuredLoan_Cycle2plus_6MonthBack,
			ProductVehicleLoan_Cycle1_6MonthBack,
			ProductVehicleLoan_Cycle2_6MonthBack,
			ProductVehicleLoan_Cycle2plus_6MonthBack,
			ProductLoan_Cycle1_6MonthBack,
			ProductLoan_Cycle2_6MonthBack,
			ProductLoan_Cycle2plus_6MonthBack,
			ProductRealEstate_Cycle1_9MonthBack,
			ProductRealEstate_Cycle2_9MonthBack,
			ProductRealEstate_Cycle2plus_9MonthBack,
			ProductSecuredLoan_Cycle1_9MonthBack,
			ProductSecuredLoan_Cycle2_9MonthBack,
			ProductSecuredLoan_Cycle2plus_9MonthBack,
			ProductUnsecuredLoan_Cycle1_9MonthBack,
			ProductUnsecuredLoan_Cycle2_9MonthBack,
			ProductUnsecuredLoan_Cycle2plus_9MonthBack,
			ProductVehicleLoan_Cycle1_9MonthBack,
			ProductVehicleLoan_Cycle2_9MonthBack,
			ProductVehicleLoan_Cycle2plus_9MonthBack,
			ProductLoan_Cycle1_9MonthBack,
			ProductLoan_Cycle2_9MonthBack,
			ProductLoan_Cycle2plus_9MonthBack,
			ProductRealEstate_Cycle1_12MonthBack,
			ProductRealEstate_Cycle2_12MonthBack,
			ProductRealEstate_Cycle2plus_12MonthBack,
			ProductSecuredLoan_Cycle1_12MonthBack,
			ProductSecuredLoan_Cycle2_12MonthBack,
			ProductSecuredLoan_Cycle2plus_12MonthBack,
			ProductUnsecuredLoan_Cycle1_12MonthBack,
			ProductUnsecuredLoan_Cycle2_12MonthBack,
			ProductUnsecuredLoan_Cycle2plus_12MonthBack,
			ProductVehicleLoan_Cycle1_12MonthBack,
			ProductVehicleLoan_Cycle2_12MonthBack,
			ProductVehicleLoan_Cycle2plus_12MonthBack,
			ProductLoan_Cycle1_12MonthBack,
			ProductLoan_Cycle2_12MonthBack,
			ProductLoan_Cycle2plus_12MonthBack,
			RealEstate_Cycle1Flag_SP,
			RealEstate_Cycle2Flag_SP,
			RealEstate_Cycle2plusFlag_SP,
			SecuredLoan_Cycle1Flag_SP,
			SecuredLoan_Cycle2Flag_SP,
			SecuredLoan_Cycle2plusFlag_SP,
			UnsecuredLoan_Cycle1Flag_SP,
			UnsecuredLoan_Cycle2Flag_SP,
			UnsecuredLoan_Cycle2plusFlag_SP,
			VehicleLoan_Cycle1Flag_SP,
			VehicleLoan_Cycle2Flag_SP,
			VehicleLoan_Cycle2plusFlag_SP,
			Loan_Cycle1Flag_SP,
			Loan_Cycle2Flag_SP,
			Loan_Cycle2plusFlag_SP,
			RealEstate_Cycle1Flag_3MonthBack,
			RealEstate_Cycle2Flag_3MonthBack,
			RealEstate_Cycle2plusFlag_3MonthBack,
			SecuredLoan_Cycle1Flag_3MonthBack,
			SecuredLoan_Cycle2Flag_3MonthBack,
			SecuredLoan_Cycle2plusFlag_3MonthBack,
			UnsecuredLoan_Cycle1Flag_3MonthBack,
			UnsecuredLoan_Cycle2Flag_3MonthBack,
			UnsecuredLoan_Cycle2plusFlag_3MonthBack,
			VehicleLoan_Cycle1Flag_3MonthBack,
			VehicleLoan_Cycle2Flag_3MonthBack,
			VehicleLoan_Cycle2plusFlag_3MonthBack,
			Loan_Cycle1Flag_3MonthBack,
			Loan_Cycle2Flag_3MonthBack,
			Loan_Cycle2plusFlag_3MonthBack,
			RealEstate_Cycle1Flag_6MonthBack,
			RealEstate_Cycle2Flag_6MonthBack,
			RealEstate_Cycle2plusFlag_6MonthBack,
			SecuredLoan_Cycle1Flag_6MonthBack,
			SecuredLoan_Cycle2Flag_6MonthBack,
			SecuredLoan_Cycle2plusFlag_6MonthBack,
			UnsecuredLoan_Cycle1Flag_6MonthBack,
			UnsecuredLoan_Cycle2Flag_6MonthBack,
			UnsecuredLoan_Cycle2plusFlag_6MonthBack,
			VehicleLoan_Cycle1Flag_6MonthBack,
			VehicleLoan_Cycle2Flag_6MonthBack,
			VehicleLoan_Cycle2plusFlag_6MonthBack,
			Loan_Cycle1Flag_6MonthBack,
			Loan_Cycle2Flag_6MonthBack,
			Loan_Cycle2plusFlag_6MonthBack,
			RealEstate_Cycle1Flag_9MonthBack,
			RealEstate_Cycle2Flag_9MonthBack,
			RealEstate_Cycle2plusFlag_9MonthBack,
			SecuredLoan_Cycle1Flag_9MonthBack,
			SecuredLoan_Cycle2Flag_9MonthBack,
			SecuredLoan_Cycle2plusFlag_9MonthBack,
			UnsecuredLoan_Cycle1Flag_9MonthBack,
			UnsecuredLoan_Cycle2Flag_9MonthBack,
			UnsecuredLoan_Cycle2plusFlag_9MonthBack,
			VehicleLoan_Cycle1Flag_9MonthBack,
			VehicleLoan_Cycle2Flag_9MonthBack,
			VehicleLoan_Cycle2plusFlag_9MonthBack,
			Loan_Cycle1Flag_9MonthBack,
			Loan_Cycle2Flag_9MonthBack,
			Loan_Cycle2plusFlag_9MonthBack,
			RealEstate_Cycle1Flag_12MonthBack,
			RealEstate_Cycle2Flag_12MonthBack,
			RealEstate_Cycle2plusFlag_12MonthBack,
			SecuredLoan_Cycle1Flag_12MonthBack,
			SecuredLoan_Cycle2Flag_12MonthBack,
			SecuredLoan_Cycle2plusFlag_12MonthBack,
			UnsecuredLoan_Cycle1Flag_12MonthBack,
			UnsecuredLoan_Cycle2Flag_12MonthBack,
			UnsecuredLoan_Cycle2plusFlag_12MonthBack,
			VehicleLoan_Cycle1Flag_12MonthBack,
			VehicleLoan_Cycle2Flag_12MonthBack,
			VehicleLoan_Cycle2plusFlag_12MonthBack,
			Loan_Cycle1Flag_12MonthBack,
			Loan_Cycle2Flag_12MonthBack,
			Loan_Cycle2plusFlag_12MonthBack,
			Cycle1_HarlandProduct_SP,
			Cycle2_HarlandProduct_SP,
			Cycle2plus_HarlandProduct_SP,
			chargeoffflag_HarlandProduct_SP,
			Cycle1_HarlandProduct_12MonthBack,
			Cycle2_HarlandProduct_12MonthBack,
			Cycle2plus_HarlandProduct_12MonthBack,
			chargeoffflag_HarlandProduct_12MonthBack,
			Cycle1_HarlandProduct_9MonthBack,
			Cycle2_HarlandProduct_9MonthBack,
			Cycle2plus_HarlandProduct_9MonthBack,
			chargeoffflag_HarlandProduct_9MonthBack,
			Cycle1_HarlandProduct_6MonthBack,
			Cycle2_HarlandProduct_6MonthBack,
			Cycle2plus_HarlandProduct_6MonthBack,
			chargeoffflag_HarlandProduct_6MonthBack,
			Cycle1_HarlandProduct_3MonthBack,
			Cycle2_HarlandProduct_3MonthBack,
			Cycle2plus_HarlandProduct_3MonthBack,
			chargeoffflag_HarlandProduct_3MonthBack,
			SSN_CC,
			CreditCard_StaticpoolFlag,
			CreditCard_Q1Flag,
			PRODUCT_CC_Q1,
			DFT_PRODUCT_CC_Q1_Q2,
			[Last Statement Payment Count_CC_Q1],
			[DFT_Last Statement Payment Count_CC_Q1_Q2],
			[Last Statement Payment Amount_CC_Q1],
			[DFT_Last Statement Payment Amount_CC_Q1_Q2],
			[Last Statement Sale Amount_CC_Q1],
			[DFT_Last Statement Sale Amount_CC_Q1_Q2],
			[Last Statement Cash Amount_CC_Q1],
			[DFT_Last Statement Cash Amount_CC_Q1_Q2],
			[Last Statement Return Amount_CC_Q1],
			[DFT_Last Statement Return Amount_CC_Q1_Q2],
			[Last Statement Sale Count_CC_Q1],
			[DFT_Last Statement Sale Count_CC_Q1_Q2],
			[Last Statement Cash Advance Count_CC_Q1],
			[DFT_Last Statement Cash Advance Count_CC_Q1_Q2],
			[Last Statement Return Count_CC_Q1],
			[DFT_Last Statement Return Count_CC_Q1_Q2],
			[Last Statement External Fee Amount_CC_Q1],
			[DFT_Last Statement External Fee Amount_CC_Q1_Q2],
			[Last Statement Credit Life Change Amount_CC_Q1],
			[DFT_Last Statement Credit Life Change Amount_CC_Q1_Q2],
			[Last Statement Charge Late Amount_CC_Q1],
			[DFT_Last Statement Charge Late Amount_CC_Q1_Q2],
			[Last Statement Charge Cash Amount_CC_Q1],
			[DFT_Last Statement Charge Cash Amount_CC_Q1_Q2],
			[Last Statement Charge Overlimit Amount_CC_Q1],
			[DFT_Last Statement Charge Overlimit Amount_CC_Q1_Q2],
			[Last Statement Charge Sale Amount_CC_Q1],
			[DFT_Last Statement Charge Sale Amount_CC_Q1_Q2],
			[Last Statement Merchandise Average Daily Balance Amount_CC_Q1],
			[DFT_Last Statement Merchandise Average Daily Balance Amount_CC_Q1_Q2],
			[Last Statement Cash Average Daily Balance Amount_CC_Q1],
			[DFT_Last Statement Cash Average Daily Balance Amount_CC_Q1_Q2],
			[Last Statement Average Daily Balance Amount_CC_Q1],
			[DFT_Last Statement Average Daily Balance Amount_CC_Q1_Q2],
			spend_CC_Q1,
			DFT_spend_CC_Q1_Q2,
			Protected_Balance_CC_Q1,
			DFT_Protected_Balance_CC_Q1_Q2,
			Promo_Balance_CC_Q1,
			DFT_Promo_Balance_CC_Q1_Q2,
			Protected_Current_Interest_CC_Q1,
			DFT_Protected_Current_Interest_CC_Q1_Q2,
			Promo_Current_Interest_CC_Q1,
			DFT_Promo_Current_Interest_CC_Q1_Q2,
			RevolvingBalance_CC_Q1,
			DFT_RevolvingBalance_CC_Q1_Q2,
			AVG_UTILIZATION_RATE_CC_Q1,
			DFT_AVG_UTILIZATION_RATE_CC_Q1_Q2,
			DFT_PRODUCT_CC_H1_H2,
			[DFT_Last Statement Payment Count_CC_H1_H2],
			[DFT_Last Statement Payment Amount_CC_H1_H2],
			[DFT_Last Statement Sale Amount_CC_H1_H2],
			[DFT_Last Statement Cash Amount_CC_H1_H2],
			[DFT_Last Statement Return Amount_CC_H1_H2],
			[DFT_Last Statement Sale Count_CC_H1_H2],
			[DFT_Last Statement Cash Advance Count_CC_H1_H2],
			[DFT_Last Statement Return Count_CC_H1_H2],
			[DFT_Last Statement External Fee Amount_CC_H1_H2],
			[DFT_Last Statement Credit Life Change Amount_CC_H1_H2],
			[DFT_Last Statement Charge Late Amount_CC_H1_H2],
			[DFT_Last Statement Charge Cash Amount_CC_H1_H2],
			[DFT_Last Statement Charge Overlimit Amount_CC_H1_H2],
			[DFT_Last Statement Charge Sale Amount_CC_H1_H2],
			[DFT_Last Statement Merchandise Average Daily Balance Amount_CC_H1_H2],
			[DFT_Last Statement Cash Average Daily Balance Amount_CC_H1_H2],
			[DFT_Last Statement Average Daily Balance Amount_CC_H1_H2],
			DFT_spend_CC_H1_H2,
			DFT_Protected_Balance_CC_H1_H2,
			DFT_Promo_Balance_CC_H1_H2,
			DFT_Protected_Current_Interest_CC_H1_H2,
			DFT_Promo_Current_Interest_CC_H1_H2,
			DFT_RevolvingBalance_CC_H1_H2,
			DFT_AVG_UTILIZATION_RATE_CC_H1_H2,
			Count_Durable_CC,
			max_credit_Limit,
			max_age_member_CC,
			Max_Extract_ACCOUNT_OPEN_DATE_CC,
			Max_Closed_account_flag_CC,
			Max_MOB_CC,
			ChargeoffAmount_final_CC,
			Max_chargoff_date_CC,
			CL_CC_StaticPool,
			MOB_CC_staticPool,
			TRIP_FLAG_staticpool,
			ProductCC_Cycle1_SP,
			ProductCC_Cycle2_SP,
			ProductCC_Cycle2plus_SP,
			CC_Cycle1Flag_SP,
			CC_Cycle2Flag_SP,
			CC_Cycle2plusFlag_SP,
			ProductCC_Cycle1_3MBack,
			ProductCC_Cycle2_3MBack,
			ProductCC_Cycle2plus_3MBack,
			CC_Cycle1Flag_3MBack,
			CC_Cycle2Flag_3MBack,
			CC_Cycle2plusFlag_3MBack,
			ProductCC_Cycle1_6MBack,
			ProductCC_Cycle2_6MBack,
			ProductCC_Cycle2plus_6MBack,
			CC_Cycle1Flag_6MBack,
			CC_Cycle2Flag_6MBack,
			CC_Cycle2plusFlag_6MBack,
			ProductCC_Cycle1_9MBack,
			ProductCC_Cycle2_9MBack,
			ProductCC_Cycle2plus_9MBack,
			CC_Cycle1Flag_9MBack,
			CC_Cycle2Flag_9MBack,
			CC_Cycle2plusFlag_9MBack,
			ProductCC_Cycle1_12MBack,
			ProductCC_Cycle2_12MBack,
			ProductCC_Cycle2plus_12MBack,
			CC_Cycle1Flag_12MBack,
			CC_Cycle2Flag_12MBack,
			CC_Cycle2plusFlag_12MBack,
			CL_DIFF_past_oneyear,
			[Days Since Last Login],
			FICO,
			CCAPREstimate,
			AggregatedSpendPast3Months,
			TopOfWalletCCAnnualSpend,
			TopOfWalletCCCurrentBalance,
			OpenTradeCount,
			OpenTradeBalance,
			AutoOpenTradeCount,
			AutoLoanOrgBalanceP12Months,
			AutoOpenTradeBalance,
			CCCount,
			CCOpenCount,
			CCTotalAvailableLOC,
			CCOpenBalance,
			ChargeOffTradeCountP12Months,
			ChargeOffTotalBalance,
			BankruptcyCount,
			NumberInquiriesP6Months,
			CCWorstRatingP12Months,
			AutoWorstRatingP12Months,
			MortgageWorstRatingP12Months,
			HELOCWorstRatingP12Months,
			HEWorstRatingP12Months,
			HEOpenCount,
			HETotalAvailableLOC,
			HEOpenBalance,
			HELOCOpenCount,
			HELOCTotalAvailableLOC,
			HELOCOpenBalance,
			MortgageOpenCount,
			MortgageOpenBalance,
			RevolvingAccountCount,
			CCRevolvingBalance,
			CCTripTypeP6Months,
			StudentLoanOpenCount,
			StudentLoanOpenBalance
	into #MasterData
	from
	(select  A.*
	  ,B.[FICO]
      ,B.[CCAPREstimate]
      ,B.[AggregatedSpendPast3Months]
      ,B.[TopOfWalletCCAnnualSpend]
      ,B.[TopOfWalletCCCurrentBalance]
      ,B.[OpenTradeCount]                   
      ,B.[OpenTradeBalance]                  
      ,B.[AutoOpenTradeCount]               
      ,B.[AutoLoanOrgBalanceP12Months]
      ,B.[AutoOpenTradeBalance]             
      ,B.[CCCount]
      ,B.[CCOpenCount]                      
      ,B.[CCTotalAvailableLOC]              
      ,B.[CCOpenBalance]                    
      ,B.[ChargeOffTradeCountP12Months]
      ,B.[ChargeOffTotalBalance]
      ,B.[ForeclosureCountP12Months]
      ,B.[ForeclosureTotalBalance]
      ,B.[BankruptcyCount]
      ,B.[NumberInquiriesP6Months]        
      ,B.[CCWorstRatingP12Months]
      ,B.[AutoWorstRatingP12Months]
      ,B.[MortgageWorstRatingP12Months]
      ,B.[HELOCWorstRatingP12Months]
      ,B.[HEWorstRatingP12Months]
      ,B.[HEOpenCount]                    
      ,B.[HETotalAvailableLOC]            
      ,B.[HEOpenBalance]                 
      ,B.[HELOCOpenCount]
      ,B.[HELOCTotalAvailableLOC]
      ,B.[HELOCOpenBalance]
      ,B.[MortgageOpenCount]             
      ,B.[MortgageOpenBalance]            
      ,B.[RevolvingAccountCount]
      ,B.[CCRevolvingBalance]
      ,B.[CCTripTypeP6Months]
      ,B.[StudentLoanOpenCount]          
      ,B.[StudentLoanOpenBalance]
	--into #MasterData
	from #loan_dep_onlinebanking  as A
	LEFT join #BUREAU_DATA  B
	on a.SSN003 = b.SSN ) W




	/************************* Previous Model Final Variable Creation ************************/

     		Drop table if exists #creditdate
		select fullExtractdate ,extract_datepart
		into #creditdate
		from tmgdata.dbo.cardholder where fullExtractdate	between dateadd(month,-12,@staticcreditdate) and @staticcreditdate
		group by fullExtractdate ,extract_datepart	
		
		Drop table if exists #Processdate
		select Process_date,max(ProcessDate) MAX_ProcessDate ,max([Process date]) [Process date]
		into #Processdate
		from
			(
			select ProcessDate,left(ProcessDate,6) Process_date
			,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
			from ARCUSYM000.dbo.NAME group by ProcessDate
			) A 
			where [Process date] between dateadd(month,-12,@staticpooldate) and @staticpooldate
			group by Process_Date
			order by Process_Date

			--select * FROM #Processdate order by 1

		--drop table if exists #groupproducttype_Deposits0
		--select *
		--,case when ProductName like '%money%'  or ProductName like '% MM %' then 'MoneyMarket'
		--when ProductName='Youth Savings' and ApplicationDescription='Certificates' then 'Savings'
		--when ProductCode=0 and ApplicationDescription='Certificates' then 'Savings'
		--when ProductName='40 Month CD' and ApplicationDescription='Certificates' then 'Checking'
		--when ProductName='Certificate' and ApplicationDescription='Certificates' then 'Checking' 
		--when ProductName='Public Funds' and ApplicationDescription='Certificates' then 'Certificates'  
		-- else ApplicationDescription end Product_Group_wise
		--into #groupproducttype_Deposits0
		--from
		--	(select b.ApplicationTypeID,cast(ProductCode as int) ProductCode,ProductName
		--	,ApplicationDescription,ApplicationTableName
		--	 from [AE_EDW].[tempods].[S_CRMProductType] a
		--	left join [AE_EDW].[tempods].[S_CRMApplicationType] b
		--	on a.ApplicationTypeID=b.ApplicationTypeID
		--	where ApplicationDescription is not null
		--	and  ProductCode not in ('xx','wm','lpl') and ApplicationTableName='Deposits') a
		--order by ProductCode
		
		Drop table if exists #saving_static_info
		select parentaccount,ID
		into #saving_static_info
		from 
								(
										select *,case when [EOM_Process Date]=[Process Date] then 1 else 0 end EOM_flag 
										,case when (closedate is null and CHARGEOFFDATE is null) or Process_Date=close_date 
										or Process_Date=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
										from
											(select a.*,EOMONTH([Process Date]) [EOM_Process Date]
											,case when OPENDATE=CLOSEDATE then 0 else 1 end Funded_loan_flag
											,case when Process_Date=CHARGEOFFDATE_v then CHARGEOFFAMOUNT else 0 end CHARGEOFFAMOUNT_v
											,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
											else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
											 from 
												 ( select * ,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
												 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v,left(ProcessDate,6) Process_Date
												,datefromparts(left(processdate,4),right(left(processdate,6),2),right(processdate,2)) [Process Date] from arcusym000.dbo.SAVINGS
												--where (chargeoffdate is null or chargeoffdate>='2020-01-01')
												) a
												where  [Process Date]=@staticpooldate
												
											) F
								 ) aa
						left join #ShareCategory E
						on E.ShareType =aa.TYPE
						 where Funded_loan_flag=1 and Open_Flag=1

					

		Drop table if exists #Share_Static_info
		select PARENTACCOUNT,ID,SSN
		,SharePrimeNameFirst First,SharePrimeNameLAST Last,SharePrimeNameSTREET Street,SharePrimeNameCITY CITY,SharePrimeNameSTATE STATE
		   ,SharePrimeNameZIPCODE ZIPCODE,SharePrimeNameBIRTHDATE BIRTHDATE
		    into #Share_Static_info
			from #saving_static_info A left join 
						(select *,ROW_NUMBER() over(partition by AccountNumber order by ProcessDate desc) SR_NO
						from		(select AccountNumber,shareid,SharePrimeNameSSN SSN,ProcessDate
								,SharePrimeNameFirst,SharePrimeNameLAST,SharePrimeNameSTREET,SharePrimeNameCITY,SharePrimeNameSTATE
								   ,SharePrimeNameZIPCODE,SharePrimeNameBIRTHDATE
								from arcusym000.arcu.ARCUSharePrimeNames where ProcessDate in (select max_ProcessDate from #Processdate)
								group by AccountNumber,shareid,SharePrimeNameSSN ,ProcessDate
								,SharePrimeNameFirst,SharePrimeNameLAST,SharePrimeNameSTREET,SharePrimeNameCITY,SharePrimeNameSTATE
								   ,SharePrimeNameZIPCODE,SharePrimeNameBIRTHDATE) BA 
						) B 
		on a.PARENTACCOUNT=b.AccountNumber --and a.id=b.ShareID
		where SR_NO=1 and SSN is not null
		

		Drop table if exists #Delinquencyall
		select processdate,Process_date,AccountNumber,LoanID,Cycle1,Cycle2,Cycle3,Cycle4,Cycle5,Cycle6,LoanchargeoffFlag,CONCAT(AccountNumber,LoanID) UNID
		into #Delinquencyall
		from
		 (
				 select 
				Convert(date, cast(l.Processdate as nvarchar)) as Date, l.ProcessDate,left(l.ProcessDate,6) Process_date,
				AccountNumber,LoanID,l.LoanOpenDate,LoanDelqDays,
				case when LoanDelqDays between 1 and 29 then 1 else 0 end Cycle1 
				,case when LoanDelqDays between 30 and 59 then 1 else 0 end Cycle2 
				,case when LoanDelqDays between 60 and 89 then 1 else 0 end Cycle3 
				,case when LoanDelqDays between 90 and 119 then 1 else 0 end Cycle4 
				,case when LoanDelqDays between 120 and 149 then 1 else 0 end Cycle5 
				,case when LoanDelqDays between 150 and 179 then 1 else 0 end Cycle6
				,Case when LoanChargeoffDate Is not null then 1 else 0 end as LoanchargeoffFlag
				,LoanPastDueAmount,LoanBalance,l.LoanChargeoffDate,l.LoanType,alc.LoanTypeDescription, 
				Count(t.locator) as BankruptcyCount 
				from(select *,Cast(convert(varchar(20),ProcessDate,112) as date) [Process date] from arcusym000.arcu.ARCULoanDetailed)  as l
						left join arcusym000.arcu.ARCULoanCategory as alc on alc.LoanType = l.LoanType
						left join ARCUSYM000.dbo.tracking as t on t.processdate = l.ProcessDate and t.PARENTACCOUNT = l.AccountNumber 
						and t.TYPE = 36 and (t.EXPIREDATE is null or t.EXPIREDATE < Convert(date, cast(t.processdate as varchar)))
				where LoanDelqDays > 0 
				and l.[Process date] = @staticpooldate
				group by l.ProcessDate,l.AccountNumber,l.LoanID,l.LoanOpenDate,l.LoanPastDueAmount,l.LoanChargeoffDate
				,l.LoanType,alc.LoanTypeDescription, l.LoanDelqDays, LoanBalance
			) A
		order by AccountNumber,LoanID,ProcessDate


								drop table if exists #LoanStatic_01
								select 
								   [ProcessDate],[Process date],[Process_date],[PARENTACCOUNT],concat(PARENTACCOUNT,ID) UNID
								  ,[ID],TYPE,OPENdate,Open_date,closedate,Close_date,Charge_off_date,CHARGEOFFDATE,MOB,Loan_Term,Month_to_Maturity
								  ,[PARTIALPAYMENT],[PAYMENT],[LASTPAYMENTDATE],DUEDATE,[PAYMENTCOUNT],[INTERESTRATE]
								  ,[LATECHARGELASTYEAR],[BALANCE],[DESCRIPTION],[BRANCH]
								  ,b.LoanCategory2,b.LoanCategory3,b.LoanCategory4
								  ,case when LoanCategory2='Vehicle' then 'Vehicle'
								   when LoanCategory2='Personal' and LoanCategory3='Secured' then 'Personal_Secured'
								   when LoanCategory2='Personal' and LoanCategory3='Unsecured' then 'Personal_Unsecured'
								   when LoanCategory2='Real Estate' and LoanCategory4 like 'HEL%' then 'HELOC' 
								   when LoanCategory2='Real Estate' then 'Real Estate'
								   when LoanCategory2='Commercial Loans' then 'Commercial Loans'
								   when LoanCategory2='Construction And Development' then 'Construction And Development'
								   when LoanTypeDescription like '%AUTO (OL)' then 'Vehicle' else LoanTypeDescription end Loan_Categories
								  into #LoanStatic_01
								from
											(
											select *
											,CONCAT(PARENTACCOUNT,ID) UNID,case when opendate=closedate then 0 else 1 end Flag
											,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date then 1 else 0 end Open_Flag
											,DATEDIFF(month,OPENDATE,@staticpooldate) MOB	-- add the @Staticpooldate
											,DATEDIFF(month,OPENDATE,MATURITYDATE) Loan_Term
											,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
												from 
													(select *
													,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
													else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
													,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
													else concat(year(opendate),month(opendate)) end Open_date
													,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
													else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
													,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
													,left(ProcessDate,6) Process_date
													from ARCUSYM000.dbo.LOAN
													--where (CHARGEOFFDATE>='2020-10-31' or CHARGEOFFDATE is null ) 
													) H
											 where  ORIGINALDATE is not null and OpenDate is not null 
											 and CLOSEDATE is null and CHARGEOFFDATE is null
											 and [Process date]=@staticpooldate		-- Later give the @staticpooldate date here 
											 and MATURITYDATE>@staticpooldate	-- add 3 month in currrent date
											) A
									left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
									on b.loantype=a.TYPE
									where Flag=1 and Open_Flag=1 and concat(PARENTACCOUNT,ID) not in  (Select UNID from #Delinquencyall)
									order by PARENTACCOUNT,ProcessDate

		Drop table if exists #Loan_Static_info
		select PARENTACCOUNT,ID,SSN
		,LoanPrimeNameFirst FIRST,LoanPrimeNameLAST LAST,LoanPrimeNameSTREET STREET,LoanPrimeNameCITY CITY,LoanPrimeNameSTATE STATE
		   ,LoanPrimeNameZIPCODE ZIPCODE,LoanPrimeNameBIRTHDATE BIRTHDATE
		    into #Loan_Static_info
			from #LoanStatic_01 A left join 
		(select AccountNumber,Loanid,LoanPrimeNameSSN SSN
		,LoanPrimeNameFirst,LoanPrimeNameLAST,LoanPrimeNameSTREET,LoanPrimeNameCITY,LoanPrimeNameSTATE
		   ,LoanPrimeNameZIPCODE,LoanPrimeNameBIRTHDATE
		from arcusym000.arcu.ARCULoanPrimeNames where cast(convert(varchar(20),ProcessDate,112) as date)=@staticpooldate
		and LoanPrimeNameLast!='U OF I COMM C U NON-MEMBER TRAN ACCT'
		) B on a.PARENTACCOUNT=b.AccountNumber and a.id=b.loanID
									-- 95555
		Drop table if exists #LoanStatic
		select b.SSN,a.* 
		into #LoanStatic
		from #LoanStatic_01 a left join #Loan_Static_info b on a.UNID=concat(b.PARENTACCOUNT,b.ID)
		--MOrtgage
		drop table if exists #Tracking
		select parentaccount,ID,(USERCHAR1) USERCHAR1,EXPIREDATE,ProcessDate,left(ProcessDate,6) Process_Date 
		into #Tracking
		from (select parentaccount,ID,(USERCHAR1) USERCHAR1,EXPIREDATE,ProcessDate,Cast(convert(varchar(20),ProcessDate,112) as date) [Process date] 
			from ARCUSYM000.dbo.TRACKING where len(USERCHAR1)=10 and ISNUMERIC(USERCHAR1)=1 
			) A 
		where [Process Date] in (select [Process date] from #Processdate) and (EXPIREDATE is null or EXPIREDATE>[Process date])
		group by parentaccount,ID,USERCHAR1,EXPIREDATE,ProcessDate

	
		drop table if exists #Mortgage
		select  b.parentaccount,
		a.*,case when Extractdate=Opendate then 1 else 0 end New_flag,d.MortgageOriginalBalance orignalbalance
		into #Mortgage
		from (select case when len(month(AsOfDate))=1 then concat(year(AsOfDate),0,month(AsOfDate)) else concat(year(AsOfDate),month(AsOfDate)) end Extractdate
				,case when len(month(MortgageOpenDate))=1 then concat(year(MortgageOpenDate),0,month(MortgageOpenDate)) else concat(year(MortgageOpenDate),month(MortgageOpenDate)) end Opendate
				,* from AE_EDW.dbo.F_Mortgage_Daily) A
		left join #Tracking b
		on a.mortgageid=b.USERCHAR1 and a.Extractdate=b.Process_Date
		left join AE_EDW.dbo.D_Mortgage d on a.mortgageid=d.MortgageID
		where CoreMortgageStatus='Active' and AsOfDate=@staticpooldate and
		 b.EXPIREDATE is null  and MortgageDueDate >= @staticpooldate and CurrentBalance > 0 and b.PARENTACCOUNT is not null

		 --select * from #Mortgage where PARENTACCOUNT is null and mortgageid in (select USERCHAR1 from ARCUSYM000.dbo.TRACKING)

		Drop table if exists #Corporate_Static_info 
		select * 
		into #Corporate_Static_info 
		from #Share_Static_info where FIRST is null
		union
		select PARENTACCOUNT,case when isnumeric(ID)=1 then ID else null end ID,SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE 
		from #Loan_Static_info where FIRST is null
		
		Drop table if exists #Missing_SSN
		select PARENTACCOUNT,ID,SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE 
		into #Missing_SSN
		from #Share_Static_info where FIRST is not null and SSN is null
		--GROUP BY SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE 
		 --SELECT * FROM #Missing_SSN  -- 0 -- Check 6/2/23
		Drop table if exists #Missing_SSN_map
		select a.PARENTACCOUNT,b.ID,a.SSN,a.FIRST,a.Last,a.STREET,a.CITY,a.STATE,a.ZIPCODE,a.BIRTHDATE 
		into #Missing_SSN_map
		from ARCUSYM000.dbo.name A left join #Missing_SSN b on a.PARENTACCOUNT=b.PARENTACCOUNT
		where a.PARENTACCOUNT in (select PARENTACCOUNT from #Missing_SSN) 
		and Cast(convert(varchar(20),ProcessDate,112) as date)=@staticpooldate and a.ssn is not null
		Drop table if exists #Merged_Static_info
		select * 
		into #Merged_Static_info
		from		(select PARENTACCOUNT,case when isnumeric(ID)=0 then null else ID end ID,SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE,'Deposit' Flag 
				from #Share_Static_info where FIRST is not null and SSN is not null
				union
				select PARENTACCOUNT,case when isnumeric(ID)=0 then null else ID end ID,SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE,'Loan' Flag 
				from #Loan_Static_info where FIRST is not null 
				union 
				select PARENTACCOUNT,case when isnumeric(ID)=0 then null else ID end ID,SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE,'Deposit' Flag from #Missing_SSN_map
				) A
		Drop table if exists #mortgage_missing
		select a.PARENTACCOUNT 
		into #mortgage_missing
		from #mortgage a left join #Merged_Static_info b on a.PARENTACCOUNT =b.PARENTACCOUNT where b.PARENTACCOUNT  is null
		
		-- Identifying missing information from the name table
		Drop table if exists #mortgage_missing_found
		select PARENTACCOUNT,null ID,SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE,'Deposit' Flag 
		into #mortgage_missing_found
		from ARCUSYM000.dbo.name where PARENTACCOUNT in (select PARENTACCOUNT from #mortgage_missing)
		and convert(varchar(20),processdate,112)=@staticpooldate 

		--select distinct PARENTACCOUNT from #Merged_Static_info where PARENTACCOUNT in (select distinct PARENTACCOUNT from #Mortgage)
		--select SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE from #Merged_Static_info
		--group by SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE


									drop table if exists #ltvtemp
										-- Variable 1 -- LTV
										Select distinct PARENTACCOUNT,MAX(case when USERRATE1 > 200000 then 200 else USERRATE1/1000 end) as OriginationLTV 
										into #ltvtemp
										from (select *,Cast(convert(varchar(20),ProcessDate,112) as date) [Process date]  
											from ARCUSYM000.dbo.LOANTRACKING) A where TYPE = 30 and [Process Date] = @staticpooldate
										and (EXPIREDATE is null or EXPIREDATE > Convert(date, cast(processdate as varchar)))
										 and CONCAT(Parentaccount,id) in (Select UNID from #LoanStatic where Loan_Categories = 'Vehicle' )
										 group by PARENTACCOUNT
										order by 2 desc

									
								drop table if exists #tempstatic
								Select a.*,OriginationLTV 
								into #tempstatic 
								from #LoanStatic a left join #ltvtemp b  on a.PARENTACCOUNT = b.PARENTACCOUNT

								-- Variable 2 -- DTI
								drop table if exists #dtitemp
											SELECT 
												 [Account]
												,[LoanID]
												,A.[ApplicationID]
												--,R.dti
												into #dtitemp
											FROM [UICCU].[dbo].[vwLoanApplicationID] A
											--left join [ACAKCELSQL01].[Temenos].[Lending].[uvwApplicationRatio] R with (nolock)
											--	on A.applicationid = R.ApplicationID
		-- Merging dti and static pool
			Drop table if exists #tempstatic2		
			Select * into #tempstatic2 from #tempstatic a left join #dtitemp b on a.PARENTACCOUNT = b.account and a.ID = b.loanid

			--Lien flag--
						drop table if exists #temp4
						Select distinct PARENTACCOUNT,ID,case when USERDATE4 is null then 1 else 0 end as Lien_flag
						into #temp4
						from (select *,Cast(convert(varchar(20),ProcessDate,112) as date) [Process date] 
						from ARCUSYM000.dbo.LOANTRACKING) A where TYPE = 30 and [Process Date] = @staticpooldate
						and (EXPIREDATE is null or EXPIREDATE > Convert(date, cast(processdate as varchar)))
						 and CONCAT(Parentaccount,id) in (Select UNID from #LoanStatic where Loan_Categories = 'Vehicle' )

	Drop table if exists #tempstatic3
	 Select a.*,b.Lien_flag into #tempstatic3 from #tempstatic2 a left join #temp4 b on a.PARENTACCOUNT = b.PARENTACCOUNT and a.ID = b.id

	 --Cpi flag--
	 Drop table if exists #temp5
	 Select *,case when EXPIREDATE is null then 0 else 1 end cpiflag 
	 into #temp5
	  from (select *,Cast(convert(varchar(20),ProcessDate,112) as date) [Process date] from ARCUSYM000.dbo.LOANTRACKING) A 
	  where TYPE = 55 and [Process Date] = @staticpooldate  and
	  CONCAT(Parentaccount,id) in (Select UNID from #LoanStatic where Loan_Categories = 'Vehicle' )

	  Drop table if exists #tempstatic4
	  Select a.*,cpiflag into #tempstatic4 from #tempstatic3 a left join #temp5 b on a.PARENTACCOUNT = b.PARENTACCOUNT and a.ID = b.id
	 --OriginationLTVHeloc
	  drop table if exists #temp6
	Select distinct PARENTACCOUNT,avg(userrate1/1000) as OriginationLTVHeloc
	into #temp6
	from
	(select *,Cast(convert(varchar(20),ProcessDate,112) as date) [Process date] from ARCUSYM000.dbo.LOANTRACKING) A where TYPE = 31 and [Process Date] = @staticpooldate
	and (EXPIREDATE is null or EXPIREDATE > Convert(date, cast(processdate as varchar)))
	 and CONCAT(Parentaccount,id) in (Select UNID from #LoanStatic where Loan_Categories = 'HELOC' )
	group by PARENTACCOUNT
	order by 2 desc

	drop table if exists #tempstatic5
	  Select a.*,OriginationLTVHeloc into #tempstatic5 from #tempstatic4 a left join #temp6 b on a.PARENTACCOUNT=b.parentaccount

  -- Flags--
									drop table if exists #LoanStatic_2
									Select a.SSN,parentaccount,Max(Case when Loan_Categories = 'HELOC' then 1 else 0 end) as 'heloc_loan_flag' 
									,max(Case when Loan_Categories = 'Personal_Secured' then 1 else 0 end) as 'Personal_Secured_Flag' 
									,max(Case when Loan_Categories = 'Personal_UnSecured' then 1 else 0 end) as 'Personal_Unsecured_Flag'
									,max(Case when Loan_Categories = 'Real Estate' then 1 else 0 end) as 'Real_Estate_flag' 
									,max(Case when Loan_Categories = 'Vehicle' then 1 else 0 end) as 'Vehicle_flag' 
									,0 mortgageflag,0 creditcardflag,sum(BALANCE) CURRENTBALANCE
									into #Loanstatic_2
									from #LoanStatic A Where SSN is not null
									group by SSN,PARENTACCOUNT


	--Select * from #mortgage where MortgageID in (Select cast(AccountID as varchar) from ##temp)

	drop table if exists #Mortgage_02
	Select distinct b.SSN,a.parentaccount,0 heloc_loan_flag, 0 personal_secured_flag, 0 personal_unsecured_flag
		,0 real_estate_flag, 0 vehicle_flag, 1 mortgageflag ,0 creditcardflag,CurrentBalance
		into #mortgage_02
		  from #Mortgage a	
		  left join (select PARENTACCOUNT,SSN from #Merged_Static_info where flag='Deposit' group by PARENTACCOUNT,SSN) B on a.PARENTACCOUNT=b.PARENTACCOUNT
		 
		 drop table if exists #Mortgage2 
		select *
		into #Mortgage2
		from		  (select case when a.SSN is null then b.SSN else a.SSN end SSN,a.parentaccount,heloc_loan_flag,personal_secured_flag,personal_unsecured_flag
				,real_estate_flag,vehicle_flag,mortgageflag ,creditcardflag,CurrentBalance 
				from #mortgage_02 a
				  left join #mortgage_missing_found b on a.PARENTACCOUNT=b.PARENTACCOUNT) A
				  where SSN is not null
				  
		Drop table if exists #Mortgagebalance
	Select b.SSN,a.parentaccount ,SUM(orignalbalance) mortgagebalance ,COUNT(MortgageID) mortgage_count 
	into #mortgagebalance 
	from #Mortgage a left join #Mortgage2 b on a.PARENTACCOUNT=b.PARENTACCOUNT
	where b.ssn is not null
	group by SSN,a.PARENTACCOUNT
		--select * from #mortgage_missing_found where PARENTACCOUNT in (select PARENTACCOUNT from #mortgage2)-- 11,419

	drop table if exists #CC_Members_Static
	  select distinct [Social Security Number],Durable_Key
	  into #CC_Members_Static
	  from TMGdata.dbo.cardholder a
	  where Active_Flag=1 and [External Status Code]='' and [Internal Status Code] in ('N','')
	  --and fullExtractdate='2021-02-01' AND [Card Description] NOT IN ('Mastercard Business') --- ERROR 
	  and fullExtractdate=@staticcreditdate AND [Card Description] NOT IN ('Mastercard Business') --- UPDATED(NEEDS TO BE CHECKED 6/2/23)
	 		--SELECT * FROM #CC_Members_Static
	--Select distinct [Card Description] from TMGdata.dbo.cardholder

	Drop table if exists #ClosedChargeoff
	  SELECT C.PARENTACCOUNT,C.SSN_UserChar3 SSN_ARCU,TMGDurableKey_UserChar10 Durablekey
	 into #ClosedChargeoff
	 from 
			 (select *,datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) [Process Date]
			 FROM ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard) C
	 WHERE C.[Process Date] = EOmonth(@staticpooldate) AND C.ExpireDate is null and c.ExternalStatus_UserChar8  in ('CLOSED') 
	

	Drop table if exists  #temp19
	SELECT distinct  format(cast(C.[Social Security Number] as int),'000000000') [Social Security Number],Durable_Key, T.PARENTACCOUNT
	into #temp19
	FROM #CC_Members_Static C
	LEFT JOIN (select * from
	(select *,datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) [Process Date] 
	from ARCUSYM000.tracking.tvwARCUTRACKINGCreditCard) JJ
	where [Process Date]=eomonth(@staticpooldate)) T
		ON (T.TMGDurableKey_UserChar10 = C.Durable_Key OR (TMGDurableKey_UserChar10 is null and T.SSN_UserChar3 = C.[Social Security Number]))
		AND T.[Process Date] = EOmonth(@staticpooldate)
	left join #ClosedChargeoff F on c.[Social Security Number]=F.SSN_ARCU

	--select distinct SSN from #Merged_Static_info where PARENTACCOUNT in (select distinct PARENTACCOUNT from #temp19)
	Drop table if exists #Creditcaard_Static_info
	select PARENTACCOUNT,0 ID,SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE,'Creditcard' Flag 
	into #Creditcaard_Static_info
	from ARCUSYM000.dbo.name where PARENTACCOUNT in (select  PARENTACCOUNT from #temp19) and convert(varchar(20),processdate,112)=@staticpooldate
	Drop table if exists #creditcard_1
	select c.PARENTACCOUNT,0 ID,c.SSN,c.First,c.Last,c.Street,c.CITY,c.STATE,c.ZIPCODE,c.BIRTHDATE,'Creditcard' Flag 
	into #creditcard_1
	from #temp19 a 
	left join #Creditcaard_Static_info b on a.PARENTACCOUNT=b.PARENTACCOUNT
	left join #Merged_Static_info c on a.PARENTACCOUNT=c.PARENTACCOUNT
	where b.SSN is null and c.PARENTACCOUNT is not null
	Drop table if exists #credit_missing
	select a.* 
	into #credit_missing
	from #temp19 a left join #Creditcaard_Static_info b on a.PARENTACCOUNT=b.PARENTACCOUNT
	left join #creditcard_1 c on a.PARENTACCOUNT=c.PARENTACCOUNT where b.PARENTACCOUNT is null and c.PARENTACCOUNT is null 

	--select PARENTACCOUNT,0 ID,SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE,'Creditcard' Flag from #Merged_Static_info 
	--where SSN in (select distinct [Social Security Number] from #credit_missing)
	--group by PARENTACCOUNT,SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE
	Drop table if exists #credit_missing_found
	select PARENTACCOUNT,0 ID,SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE,'Creditcard' Flag
	into #credit_missing_found from ARCUSYM000.dbo.name where SSN in (select distinct [Social Security Number] from #credit_missing) 
	and  convert(varchar(20),processdate,112)=@staticpooldate
	group by PARENTACCOUNT,SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE
	
	Drop table if exists #Merged_Static_info_v1
	select format(PARENTACCOUNT,'0000000000') PARENTACCOUNT,format(ID,'0000') ID,SSN,First,Last,Street,CITY,State,ZIPCODE,BIRTHDATE,Flag
	into #Merged_Static_info_v1
	from(select  Cast(PARENTACCOUNT as int) PARENTACCOUNT,Cast(cast(ID as float) as int) ID ,cast(SSN as int) SSN,Cast(First as varchar(30)) First
	,Cast(Last as varchar(30)) Last,cast(Street as varchar(50)) Street,cast(CITY as varchar(50)) CITY
	,Cast(STATE as varchar(50)) STATE,cast(ZIPCODE as varchar(20)) ZIPCODE,cast(BIRTHDATE as date) BIRTHDATE,cast(Flag as varchar(15)) Flag
	from (select PARENTACCOUNT,case when ISNUMERIC(ID)=1 then ID else null end ID,SSN,First,Last,Street,CITY,STATE,ZIPCODE,BIRTHDATE,Flag
	 from #Merged_Static_info ) A
	union 
	select * from #creditcard_1
	union 
	select * from #credit_missing_found
	union 
	select * from #mortgage_missing_found) A

	Drop table if exists #Final_static_SSN_mapping
	select format(SSN,'000000000') SSN,First,Last,Street,City,State,Zipcode,Birthdate 
	into #Final_static_SSN_mapping
	from #Merged_Static_info_v1
	group by SSN,First,Last,Street,City,State,Zipcode,Birthdate

	Drop table if exists #duplicate_SSN
	select SSN,count(*)  cnt
	into #duplicate_SSN
	from #Final_static_SSN_mapping
	group by SSN having count(*)>1

	--select distinct SSN,First,Last,Street,City,State,Zipcode,Birthdate 
	--from #Final_static_SSN_mapping where SSN in (select SSN from #duplicate_SSN)
	--order by SSN
		
	drop table if exists #cc_members_static2
	Select distinct [Social Security Number] SSN,parentaccount,0 heloc_loan_flag, 0 personal_secured_flag, 0 personal_unsecured_flag
	,0 real_estate_flag, 0 vehicle_flag, 0 mortgageflag ,1 creditcardflag,0 CURRENTBALANCE
	into #cc_members_static2
		from #temp19			


		  drop table if exists #temp
		  Select * 
		  into #temp 
		  from #Loanstatic_2 
		  union all 
		  Select * from #mortgage2 
		  union all 
		  select * from #cc_members_static2

		Drop table if exists #loanstaticfinal
		Select SSN,PARENTACCOUNT,max(heloc_loan_flag) heloc_loan_flag,max(personal_secured_flag) personal_secured_flag,max(personal_unsecured_flag) personal_unsecured_flag
		,max(real_estate_flag) real_estate_flag,max(vehicle_flag) vehicle_flag,max(mortgageflag) mortgageflag,max(creditcardflag) creditcardflag
		into #loanstaticfinal 
		from #temp
		group by SSN,PARENTACCOUNT
		
		
		Drop table if exists #NAME
		SELECT distinct N.PARENTACCOUNT,N.SSN,N.FIRST, N.LAST, N.BIRTHDATE, n.userchar3 FICO_Staticpool,STREET,CITY,STATE,ZIPCODE 
		INTO #NAME
		FROM
			(
			SELECT SSN,PARENTACCOUNT, FIRST, LAST, BIRTHDATE,case when isnumeric(n.USERCHAR3)=1 then n.USERCHAR3 else 0 end USERCHAR3 ,STREET,CITY,STATE,ZIPCODE
			FROM ARCUSYM000.dbo.NAME N
			LEFT JOIN ARCUSYM000.dbo.ACCOUNT A
				ON N.PARENTACCOUNT = A.ACCOUNTNUMBER
				AND N.ProcessDate = A.ProcessDate
			WHERE N.TYPE = 0 AND N.ProcessDate =concat(left(@staticpooldate ,4),right(left(@staticpooldate ,7),2),right(@staticpooldate ,2))--(SELECT MAX(ProcessDate) FROM ARCUSYM000.dbo.IRS)
				AND N.LAST <> 'NEW MEMBER' AND N.BIRTHDATE is not null AND N.SSNTYPE in (0,9) AND N.NAMEFORMAT = 0 
			) N 
			where PARENTACCOUNT in (Select PARENTACCOUNT from #loanstaticfinal group by PARENTACCOUNT)
		
		
		drop table if exists #duplicate
		select SSN,count(PARENTACCOUNT) CNT 
		into #duplicate
		from #NAME
		group by SSN
		having count(PARENTACCOUNT)>1
		
		drop table if exists #NAME1
		select a.SSN,PARENTACCOUNT
		into #NAME1
		from #NAME A
		left join #duplicate b
		on a.SSN=b.SSN
		where b.SSN is null
	
		drop table if exists #temp15
		select SSN,AccountNumber as parentaccount
		into #temp15
		from AE_EDW.dbo.D_Member
		where SSN in
		(select SSN from #duplicate)
	
	drop table if exists #FinalName
		select a.*
		,case when b.FICO_Staticpool is null or b.FICO_Staticpool>1000 then 0 else b.FICO_Staticpool end FICO_Staticpool
		,FIRST,LAST,STREET,CITY,STATE,ZIPCODE,BIRTHDATE 
		into #FinalName 
		from
				(select *
				from #NAME1
				union 
				select * from #temp15) a
				left join #NAME b
				on a.PARENTACCOUNT=b.PARENTACCOUNT	
		--   issue in duplicate value in parentaccount 	   
		--   select * from #duplicate where PARENTACCOUNT in ('0014296178')
		--   select * from #FinalName where PARENTACCOUNT in ('0014296178','0013874411')
		  --select * from ARCUSYM000.dbo.ACCOUNT where convert(varchar(20),processdate,112)=@staticpooldate and CLOSEDATE is null
		  -- select * from AE_EDW.dbo.D_Member where AccountNumber in (Select PA from Analytics.dbo.Member_level_risk_score where PARENTACCOUNT is null)
		  -- select top 100 LoanPrimeNameFirst,LoanPrimeNameLAST,LoanPrimeNameSTREET,LoanPrimeNameCITY,LoanPrimeNameSTATE
		  -- ,LoanPrimeNameZIPCODE,LoanPrimeNameBIRTHDATE
		  -- from ARCUSYM000.arcu.ARCULoanPrimeNames
		  -- select distinct AccountNumber from AE_EDW.dbo.D_Member where AccountNumber in (select distinct parentaccount from #name)
		
		drop table if exists #Delinquency
		select processdate,Process_date,AccountNumber,LoanID,sum(Cycle1) Cycle1 ,sum(Cycle2) Cycle2
		,sum(Cycle3) Cycle3,sum(Cycle4) Cycle4,sum(Cycle5) Cycle5,sum(Cycle6) Cycle6,sum(LoanchargeoffFlag) LoanchargeoffFlag
		into #Delinquency
		from
		 (
				 select 
				Convert(date, cast(l.Processdate as nvarchar)) as Date, l.ProcessDate,left(l.ProcessDate,6) Process_date,
				AccountNumber, 
				LoanID, 
				l.LoanOpenDate, 
				LoanDelqDays,
				case when LoanDelqDays between 1 and 29 then 1 else 0 end Cycle1 
				,case when LoanDelqDays between 30 and 59 then 1 else 0 end Cycle2 
				,case when LoanDelqDays between 60 and 89 then 1 else 0 end Cycle3 
				,case when LoanDelqDays between 90 and 119 then 1 else 0 end Cycle4 
				,case when LoanDelqDays between 120 and 149 then 1 else 0 end Cycle5 
				,case when LoanDelqDays between 150 and 179 then 1 else 0 end Cycle6
				,Case when LoanChargeoffDate Is not null then 1 else 0 end as LoanchargeoffFlag
				,LoanPastDueAmount, LoanBalance,l.LoanChargeoffDate,l.LoanType, 
				alc.LoanTypeDescription, Count(t.locator) as BankruptcyCount 
				from arcusym000.arcu.ARCULoanDetailed  as l
						left join arcusym000.arcu.ARCULoanCategory as alc on alc.LoanType = l.LoanType
						left join ARCUSYM000.dbo.tracking as t on t.processdate = l.ProcessDate and t.PARENTACCOUNT = l.AccountNumber 
						and t.TYPE = 36 and (t.EXPIREDATE is null or t.EXPIREDATE < Convert(varchar(20),t.processdate,112))
				where LoanDelqDays > 0 
				and l.processdate in (select MAX_ProcessDate from #processdate)
				--and l.AccountNumber in (select PARENTACCOUNT from #loanstaticfinal group by PARENTACCOUNT)
				group by l.ProcessDate,l.AccountNumber,l.LoanID,l.LoanOpenDate,l.LoanPastDueAmount,l.LoanChargeoffDate
				,l.LoanType,alc.LoanTypeDescription, l.LoanDelqDays, LoanBalance
		) A
		group by  processdate,Process_date,AccountNumber,LoanID
		order by AccountNumber,LoanID,ProcessDate
		

		-- Mortgage Deliquency ---
			drop table if exists #delinquency2
		Select LoanId
		 ,isnull(sum([DQ 1+ Days Flag]),0) [DQ 1+ Days Flag]
		 ,isnull(sum([DQ 30+ Days Flag]),0) [DQ 30+ Days Flag]
		 ,isnull(sum([DQ 60+ Days Flag]),0) [DQ 60+ Days Flag]
		 ,isnull(sum([DQ 90+ Days Flag]),0) [DQ 90+ Days Flag]
		 ,isnull(sum([DQ 120+ Days Flag]),0) [DQ 120+ Days Flag]
		 ,isnull(sum([DQ 150+ Days Flag]),0) [DQ 150+ Days Flag]
		 ,isnull(sum(chargeoffflag),0) chargeoffflag
		into #delinquency2
		 from (
		Select distinct LoanID,[DQ 1+ Days Flag],[DQ 30+ Days Flag],[DQ 60+ Days Flag],[DQ 90+ Days Flag],[DQ 120+ Days Flag],[DQ 150+ Days Flag],chargeoffflag
		from (
							SELECT h.loanid,InvestorID MortgageDescription
							,case when datediff(d, h.duedate, DateAdd(month, -1, eomonth(cutoffdate)))  < 30 then 'New' end New30Flag
							,case when datediff(d, h.duedate, DateAdd(month, -1, eomonth(cutoffdate)))  between 30 and 60 then 'New' end New61Flag
							,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and datediff(d, h.duedate, eomonth(cutoffdate)) < 30 then investorprinbal end [DQ 1+ Days]
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 30 and datediff(d, h.duedate, eomonth(cutoffdate)) < 61 then investorprinbal end [DQ 30+ Days]
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 61 and datediff(d, h.duedate, eomonth(cutoffdate)) < 182 then investorprinbal end [DQ 61+ Days]
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 182 and datediff(d, h.duedate, eomonth(cutoffdate)) < 365 then investorprinbal end [DQ 182+ Days]
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 365 or legalstatus is not null then investorprinbal end [DQ 365+ Days]
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and datediff(d, h.duedate, eomonth(cutoffdate)) < 30 then 1 else 0  end        [DQ 1+ Days Flag]
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 30 and datediff(d, h.duedate, eomonth(cutoffdate)) < 60 then 1 else 0  end       [DQ 30+ Days Flag]
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 60 and datediff(d, h.duedate, eomonth(cutoffdate)) < 90 then 1 else 0 end       [DQ 60+ Days Flag]
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 90 and datediff(d, h.duedate, eomonth(cutoffdate)) < 120  then 1 else 0 end     [DQ 90+ Days Flag]
						 ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 120 and datediff(d, h.duedate, eomonth(cutoffdate)) < 150  then 1 else 0 end [DQ 120+ Days Flag]
						 ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 150 and datediff(d, h.duedate, eomonth(cutoffdate)) < 180  then 1 else 0 end [DQ 150+ Days Flag]
						 ,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 180 then 1 else 0 end chargeoffflag
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 60  then 1 else 0 end flag
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 30 and datediff(d, h.duedate, eomonth(cutoffdate)) < 61 then investorprinbal end [DQ CODE 30+ Days]
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 61 and datediff(d, h.duedate, eomonth(cutoffdate)) < 182 then investorprinbal end [DQ CODE 61+ Days]
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 182 and datediff(d, h.duedate, eomonth(cutoffdate)) < 365 then investorprinbal end [DQ CODE 182+ Days]
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 365 or legalstatus is not null then investorprinbal end [DQ CODE 365+ Days]
						,h.duedate NextDueDate,lastpmtrecd,CutoffDate,MortgageOpenDate,InvestorPrinBal
						,datediff(d, h.duedate, eomonth(cutoffdate)) DQDays
						,Case when len(MONTH(CutoffDate)) = 1 then CONCAT(YEAR(cutoffdate),0,month(cutoffdate))
						else CONCAT(YEAR(cutoffdate),month(cutoffdate)) end as extract_date
						FROM [UICCU].[dbo].[HarlandLoanCutoff] h
						left join ae_edw.dbo.f_mortgage f on f.mortgageid = h.loanid and month(reportmonth) = month(cutoffdate)
														and year(reportmonth) = year(cutoffdate)
						WHERE loanprincipalbal > 0 AND RegPrincipalColl != investorprinbal AND (investorid LIKE '%bal' or investorid LIKE '%fix%' or investorid LIKE '%arm' or
													investorid LIKE 'E-10YR' or investorid LIKE 'E-WORK' or InvestorID like '%Equity%' or InvestorID like '%TDR%' or
													InvestorID = 'F-ARM' or InvestorID = 'FAB-HH' )
								   and investorprinbal is not null
								   and datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and RecordType <> 2
					) T 
					  where cutoffdate <@staticpooldate)k
				   group by LoanID


		 Drop table if exists #deliquency3
		Select PARENTACCOUNT
		,max(isnull([DQ 1+ Days Flag],0)) [DQ 1+ Days Flag]
				 ,Sum(isnull([DQ 30+ Days Flag],0)) [DQ 30+ Days Flag]
				 ,Sum(isnull([DQ 60+ Days Flag],0)) [DQ 60+ Days Flag]
				 ,Sum(isnull([DQ 90+ Days Flag],0)) [DQ 90+ Days Flag]
				 ,Sum(isnull([DQ 120+ Days Flag],0)) [DQ 120+ Days Flag]
				 ,Sum(isnull([DQ 150+ Days Flag],0)) [DQ 150+ Days Flag]
				 ,Sum(isnull(chargeoffflag,0)) chargeoffflag
		 into #deliquency3
		 from (Select * from #Mortgage) a left join #delinquency2 b on a.MortgageID = b.LoanID group by PARENTACCOUNT
		 
				Drop table if exists #LoanAccount
								select [ProcessDate],[Process date],[Process_date],Quarters,MonthBack_seg,[PARENTACCOUNT],UNID
								  ,[ID],TYPE,OPENdate,Open_date,closedate,Close_date,Charge_off_date,CHARGEOFFDATE
								  ,[INTERESTRATE],day(LASTPAYMENTDATE) Payment_day,abs(day(DUEDATE)-day(LASTPAYMENTDATE)) Diff_Due_Payment
								  ,[BALANCE],b.LoanCategory2,b.LoanCategory3,b.LoanCategory4
								  ,case when LoanCategory2='Vehicle' then 'Vehicle'
								   when LoanCategory2='Personal' and LoanCategory3='Secured' then 'Personal_Secured'
								   when LoanCategory2='Personal' and LoanCategory3='Unsecured' then 'Personal_Unsecured'
								   when LoanCategory2='Real Estate' and LoanCategory4 like 'HEL%' then 'HELOC' 
								   when LoanCategory2='Real Estate' then 'Real_Estate'
								   when LoanCategory2='Commercial Loans' then 'Commercial Loans'
								   when LoanCategory2='Construction And Development' then 'Construction And Development'
								   when LoanTypeDescription like '%AUTO (OL)' then 'Vehicle' else LoanTypeDescription end Loan_Categories
								  into #LoanAccount
								from
											(
											select *,CONCAT(PARENTACCOUNT,ID) UNID
											,case when [Process date] between EOMONTH(dateadd(month,-3,@staticpooldate)) and EOMONTH(dateadd(month,-1,@staticpooldate)) then 'Q1'
						when [Process date] between EOMONTH(dateadd(month,-6,@staticpooldate)) and EOMONTH(dateadd(month,-4,@staticpooldate)) then 'Q2'
						when [Process date] between EOMONTH(dateadd(month,-9,@staticpooldate)) and EOMONTH(dateadd(month,-7,@staticpooldate)) then 'Q3'
						when [Process date] =@staticpooldate then 'Staticpool' end Quarters 
											  ,case when [Process date] = EOMONTH(dateadd(month,-4,@staticpooldate)) then 'M4'
												 when [Process date] = EOMONTH(dateadd(month,-3,@staticpooldate))then 'M3'
												 when [Process date] = EOMONTH(dateadd(month,-2,@staticpooldate)) then 'M2'
												 when [Process date] = EOMONTH(dateadd(month,-1,@staticpooldate)) then 'M1' end MonthBack_seg 
											,case when opendate=closedate then 0 else 1 end Flag
											,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date 
											then 1 else 0 end Open_Flag
											,DATEDIFF(month,OPENDATE,@staticpooldate) Loan_MOB	-- add the @Staticpooldate
											,DATEDIFF(month,OPENDATE,MATURITYDATE) Loan_Term
											,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
												from 
													(
													select *
													,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
													else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
													,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
													else concat(year(opendate),month(opendate)) end Open_date
													,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
													else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
													,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
													,left(ProcessDate,6) Process_date
													from ARCUSYM000.dbo.LOAN
													--where (CHARGEOFFDATE>='2019-01-31' or CHARGEOFFDATE is null ) 
													) H
											 where  ORIGINALDATE is not null and OpenDate is not null 
											 --and [Process date]='2019-01-31'		-- Later add -12 month the @staticpooldate date here 
											 and MATURITYDATE>@staticpooldate	-- add 3 month in currrent date
											 and ProcessDate in (select MAX_ProcessDate from #Processdate)
											) A
									left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
									on b.loantype=a.TYPE
									where Flag=1 and Open_Flag=1
									--and UNID in (select UNID from #LoanStatic group by UNID)
									and PARENTACCOUNT in (Select distinct PARENTACCOUNT from #loanstaticfinal)
									order by PARENTACCOUNT,ProcessDate															


		--	select * from #LoanAccountMerg	-- 1,460,078
		 drop table if exists #LoanAccountMerg
		select a.*
		,d.Cycle1,d.Cycle2,d.Cycle3,D.Cycle4,d.Cycle5,d.Cycle6,d.LoanchargeoffFlag
		into #LoanAccountMerg
		from	 (select B.SSN,a.PARENTACCOUNT,a.[Process date],a.ProcessDate,a.Process_date,a.UNID,a.Diff_Due_Payment,a.Quarters
					,a.MonthBack_seg,Loan_Categories,BALANCE
			 from (select * from #LoanAccount) A
			left join (select *,concat(PARENTACCOUNT,id) UNID from #Merged_Static_info where flag='Loan') b
			on a.UNID=b.UNID
			) A
		left join #Delinquency D
		on a.UNID=CONCAT(d.AccountNumber,d.loanid) and a.Process_date=d.Process_date
		where SSN is not null
		order by a.PARENTACCOUNT,a.Process_date

		--select PARENTACCOUNT,UNID,SSN from #LoanAccountMerg where SSN is null and UNID in (select concat(PARENTACCOUNT,loanid) from ARCUSYM000.arcu.ARCULoanPrimeNames)
		--group by PARENTACCOUNT,UNID,SSN

		drop table if exists #Max_loan
		select a.SSN,a.PARENTACCOUNT,case when isnumeric(b.FICO_Staticpool) = 0 then NUll
		when b.FICO_Staticpool > 1000 then 0
		else b.FICO_Staticpool end FICO_Staticpool,isnull(max(Cycle1),0) Cycle1,isnull(max(Cycle2),0) Cycle2,isnull(max(Cycle3),0) Cycle3
		,isnull(max(Cycle4),0) Cycle4,isnull(max(Cycle5),0) Cycle5,isnull(max(Cycle6),0) Cycle6 ,isnull(max(LoanchargeoffFlag),0) LoanchargeoffFlag
		into #Max_loan 
		from #LoanAccountMerg a left join #finalname b on a.SSN=b.SSN 
		group by a.PARENTACCOUNT,a.SSN,b.FICO_Staticpool order by b.FICO_Staticpool
		
		Drop table if exists #Vehicle
		select SSN,parentaccount,count(distinct UNID) [# Vehicle loan],Avg(case when Quarters='Staticpool' then Diff_Due_Payment else 0 end) Diff_Due_Payment_Vehicle_Staticpool
		,sum(case when Quarters='Staticpool' then BALANCE else 0 end) Vehicle_Balance
		into #Vehicle
		from #LoanAccountMerg 
		where Loan_Categories='Vehicle' 
		group by SSN,parentaccount

		Drop table if exists #HELOC
		select SSN,parentaccount,count(distinct UNID) [# HELOC loan]
		,sum(case when Quarters='Staticpool' then BALANCE else 0 end) Heloc_Balance
		into #HELOC
		from #LoanAccountMerg 
		where Loan_Categories='HELOC' 
		group by SSN,parentaccount
		

		
		Drop table if exists #Personal_Secured
		select SSN,parentaccount,count(distinct UNID) [# Personal_Secured loan]
		,sum(case when Quarters='Staticpool' then BALANCE else 0 end) Secured_Balance
		into #Personal_Secured
		from #LoanAccountMerg 
		where Loan_Categories='Personal_Secured' 
		group by SSN,parentaccount
		
		
		Drop table if exists #Personal_Unsecured
		select SSN,parentaccount,count(distinct UNID) [# Personal_Unsecured loan]
		,sum(case when Quarters='Staticpool' then BALANCE else 0 end) Unsecured_Balance
		into #Personal_Unsecured
		from #LoanAccountMerg 
		where Loan_Categories='Personal_Unsecured' 
		group by SSN,parentaccount

		
		Drop table if exists #Real_Estate
		select SSN,parentaccount,count(distinct UNID) [# Real_Estate loan]
		,sum(case when Quarters='Staticpool' then BALANCE else 0 end) [2ndMortgage_Balance]
		into #Real_Estate
		from #LoanAccountMerg 
		where Loan_Categories='Real_Estate'  
		group by SSN,parentaccount

		drop table if exists #Loanstatic2
		select * 
		into #loanstatic2 
		from #loanstaticfinal 

		drop table if exists #staticloan
		Select PARENTACCOUNT
		,max(cpiflag) cpiflag
		,max(OriginationLTV) originationltv
		,max(Lien_flag) Lien_flag
		into #staticloan
		 from #tempstatic5
		 group by PARENTACCOUNT

		drop table if exists #loandata
		select a.SSN,a.PARENTACCOUNT
		,b.[Diff_Due_Payment_Vehicle_Staticpool],b.[# Vehicle loan]
		,c.[# HELOC loan],d.[# Personal_Secured loan],e.[# Personal_Unsecured loan],f.[# Real_Estate loan]
		,l.cpiflag,l.Lien_flag,l.originationltv
		,isnull(b.Vehicle_Balance,0)+isnull(c.Heloc_Balance,0)+isnull(d.Secured_Balance,0)+isnull(e.Unsecured_Balance,0)+isnull(f.[2ndMortgage_Balance],0) Loan_Balance
		,case when isnumeric(H.FICO_Staticpool) = 0 then NUll
		when H.FICO_Staticpool > 1000 then 0
		else H.FICO_Staticpool end FICO_Staticpool
		,(isnull(g.Cycle1,0) + isnull(m.[DQ 1+ Days Flag],0)) as cycle1
		,(isnull(g.Cycle2,0) + isnull(m.[DQ 30+ Days Flag],0)) as cycle2
		 ,(isnull(g.Cycle3,0) + isnull(m.[DQ 60+ Days Flag],0)) as cycle3 ,(isnull(g.Cycle4,0) + isnull(m.[DQ 90+ Days Flag],0)) as cycle4
		 ,(isnull(g.Cycle5,0) + isnull(m.[DQ 120+ Days Flag],0)) as cycle5,(isnull(g.Cycle6,0) + isnull(m.[DQ 150+ Days Flag],0)) as cycle6
		 ,(isnull(g.LoanchargeoffFlag,0) + isnull(m.chargeoffflag,0)) as LoanchargeoffFlag
		into #loandata
		from #loanstatic2 a
		left join (select SSN,sum([# Vehicle loan]) [# Vehicle loan],max(Diff_Due_Payment_Vehicle_Staticpool) Diff_Due_Payment_Vehicle_Staticpool
		,sum(Vehicle_Balance) Vehicle_Balance from #Vehicle group by SSN) b on a.SSN=b.SSN
		left join (select SSN,sum([# HELOC loan]) [# HELOC loan],sum(Heloc_Balance) Heloc_Balance 
		from #HELOC group by SSN) c on a.SSN=c.SSN
		left join (select SSN,sum([# Personal_Secured loan]) [# Personal_Secured loan],sum(Secured_Balance) Secured_Balance from #Personal_Secured
		group by SSN) d on a.SSN=d.SSN
		left join (select SSN,sum([# Personal_unSecured loan]) [# Personal_UnSecured loan],sum(UNSecured_Balance) Unsecured_Balance from #Personal_Unsecured
		group by SSN) e on a.SSN=e.SSN
		left join (select SSN,sum([# Real_Estate loan]) [# Real_Estate loan],sum([2ndMortgage_Balance]) [2ndMortgage_Balance] from #Real_Estate
		group by SSN) f on a.SSN=f.SSN
		left join (select SSN,max(FICO_Staticpool) FICO_Staticpool,max(Cycle1) Cycle1,max(Cycle2) Cycle2,max(Cycle3) Cycle3,max(Cycle4) Cycle4
		,max(Cycle5) Cycle5,max(Cycle6) Cycle6,max(LoanchargeoffFlag) LoanchargeoffFlag from #Max_loan group by SSN) g on a.SSN=g.SSN   
		left join #FinalName h on a.SSN=h.SSN
		left join #staticloan l on a.PARENTACCOUNT = l.PARENTACCOUNT
		left join #deliquency3 m on a.PARENTACCOUNT = m.PARENTACCOUNT
		
		--select * from #deliquency3 where SSN=439579267
		-- select count(*) from #SavingsAccount 5,545,178
		drop table if exists #SavingsAccount
		select B.SSN,ProcessDate,Process_Date,a.[PARENTACCOUNT],a.id,a.UNID,type,opendate,MATURITYDATE,CLOSEDATE,Close_date,CHARGEOFFDATE_v,CHARGEOFFAMOUNT_v
		,BALANCE,Deposit_Flag,LASTDIVAMOUNT,[# Chargeoff Deposit],Close_flag,Chargeoff_flag,Quarters,MonthBack_seg
		into #SavingsAccount
		from
				(
						select 
						ProcessDate,Process_Date,[Process Date],[PARENTACCOUNT],id,CONCAT(PARENTACCOUNT,ID) UNID,type,opendate,MATURITYDATE,CLOSEDATE,Close_date,CHARGEOFFDATE_v,CHARGEOFFAMOUNT_v
						,case when closedate is null and chargeoffdate is null then BALANCE else 0 end BALANCE,E.Deposit_Flag
						,LASTDIVAMOUNT,Overdraftfeeytd,COURTESYFEEMTD,NSFFEEMTD
						,case when CHARGEOFFAMOUNT_v>0 then 1 else 0 end [# Chargeoff Deposit]
						,case when Close_date=Process_Date then 1 else 0 end Close_flag
						,case when CHARGEOFFDATE_v=Process_Date then 1 else 0 end Chargeoff_flag
						,case when Deposit_Flag='Certificates' and BALANCE=0 then 0 else 1 end carryforward_flag
						,case when [Process Date] in ((DATEADD(month,-12,@staticpooldate )),(DATEADD(month,-11,@staticpooldate )),(DATEADD(month,-10,@staticpooldate ))) then 'Q4'
						 when [Process Date] in ((DATEADD(month,-9,@staticpooldate )),(DATEADD(month,-8,@staticpooldate)),(DATEADD(month,-7,@staticpooldate))) then 'Q3'
						 when [Process Date] in ((DATEADD(month,-6,@staticpooldate )),(DATEADD(month,-5,@staticpooldate)),(DATEADD(month,-4,@staticpooldate))) then 'Q2'
						 when [Process Date] in ((DATEADD(month,-3,@staticpooldate)),(DATEADD(month,-2,@staticpooldate )),(DATEADD(month,-1,@staticpooldate ))) then 'Q1'
						 when [Process Date] in (@staticpooldate) then 'Staticpool'
						  end Quarters
						  ,case when [Process Date] in ((DATEADD(month,-4,@staticpooldate))) then 'M4'
						 when [Process Date] in ((DATEADD(month,-3,@staticpooldate))) then 'M3'
						 when [Process Date] in ((DATEADD(month,-2,@staticpooldate))) then 'M2'
						 when [Process Date] in ((DATEADD(month,-1,@staticpooldate))) then 'M1'
						 end MonthBack_seg 
						from 
								(
										select *,case when [EOM_Process Date]=[Process Date] then 1 else 0 end EOM_flag 
										,case when (closedate is null and CHARGEOFFDATE is null) or Process_Date=close_date 
										or Process_Date=CHARGEOFFDATE_v then 1 else 0 end Open_Flag
										from
											(select a.*,EOMONTH([Process Date]) [EOM_Process Date]
											,case when OPENDATE=CLOSEDATE then 0 else 1 end Funded_loan_flag
											,case when Process_Date=CHARGEOFFDATE_v then CHARGEOFFAMOUNT else 0 end CHARGEOFFAMOUNT_v
											,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
											else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
											 from 
												 ( select * ,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
												 else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end CHARGEOFFDATE_v,left(ProcessDate,6) Process_Date
												,datefromparts(left(processdate,4),right(left(processdate,6),2),right(processdate,2)) [Process Date] from arcusym000.dbo.SAVINGS
												--where (chargeoffdate is null or chargeoffdate>='2020-01-01')
												) a
												where  ProcessDate in (select MAX_ProcessDate from #processdate)
												and PARENTACCOUNT in (select PARENTACCOUNT from #saving_static_info)
											) F
								 ) aa
						left join #ShareCategory E
						on E.ShareType=aa.TYPE
						 where Funded_loan_flag=1 and Open_Flag=1
						group by ProcessDate,[Process Date],Process_Date,[PARENTACCOUNT],id,type,CLOSEDATE,CHARGEOFFDATE_v,CHARGEOFFAMOUNT_v,LASTDIVAMOUNT
						,BALANCE,e.Deposit_Flag,opendate,MATURITYDATE,chargeoffdate,Close_date,Overdraftfeeytd,COURTESYFEEMTD,NSFFEEMTD
				) A
				left join (select format(SSN,'000000000') SSN,PARENTACCOUNT from #Merged_Static_info_v1 where flag='Deposit'
							group by SSN,PARENTACCOUNT) B 
				on a.PARENTACCOUNT=b.PARENTACCOUNT
				where b.SSN is not null
				order by a.PARENTACCOUNT,a.id,ProcessDate

		--select * from (select PARENTACCOUNT from #SavingsAccount where SSN is null group by PARENTACCOUNT) A
		--where PARENTACCOUNT in (select AccountNumber from ARCUSYM000.arcu.ARCUSharePrimeNames)
		--select SSN,FIRST,LAST from ARCUSYM000.dbo.NAME where PARENTACCOUNT='0014130380'
		--select SharePrimeNameSSN,SharePrimeNameFirst,SharePrimeNameLast from ARCUSYM000.arcu.ARCUSharePrimeNames where AccountNumber='0014130380'
		--select * from (select PARENTACCOUNT from #SavingsAccount where SSN is null group by PARENTACCOUNT) A
		--where PARENTACCOUNT in (select PARENTACCOUNT from #Merged_Static_info_v1)

			drop table if exists #SavingAccountMerg
			select SSN,
			a.Process_Date,a.ProcessDate,PARENTACCOUNT,BALANCE,Quarters,TYPE,UNID,MonthBack_seg,Deposit_Flag
			into #SavingAccountMerg
			from #SavingsAccount A
			
			drop table if exists #Savings
			select SSN,
			parentaccount,count(distinct UNID) [# Savings] , 1 savingsflag
			,Sum(case when Quarters='Staticpool' and type not in (100,160,103,104) then BALANCE else 0 end)  BALANCE_Savings_Staticpool
			into #Savings
			from #SavingAccountMerg 
			where Deposit_Flag='Savings' 
			group by SSN,parentaccount
			order by parentaccount

			drop table if exists #Checking
			select SSN,
			parentaccount,count(distinct UNID) [# Checking]
			,Sum(case when Quarters='Staticpool' AND TYPE NOT IN (143,146) then BALANCE else 0 end)  BALANCE_Checking_Staticpool
			, 1 checkingaccountflag
			into #Checking
			from #SavingAccountMerg 
			where Deposit_Flag='Checking'
			group by SSN,parentaccount
			order by parentaccount

				

			drop table if exists #Certificates
			select SSN,parentaccount,count(distinct UNID) [# Certificates]
			,Sum(case when Quarters='Staticpool' then BALANCE else 0 end)  BALANCE_certificates_Staticpool,1 certificateflag
			into #Certificates
			from #SavingAccountMerg 
			where Deposit_Flag='Certificates'
			group by SSN,parentaccount
			order by parentaccount

			
			drop table if exists #MoneyMarket
			select SSN,
			parentaccount,count(distinct UNID) [# MoneyMarket]
			,Sum(case when Quarters='Staticpool' and type not in (162,163,165) then BALANCE else 0 end)  BALANCE_MoneyMarket_Staticpool
			into #MoneyMarket
			from #SavingAccountMerg 
			where Deposit_Flag='MoneyMarket'
			group by SSN,parentaccount
			order by parentaccount

			drop table if exists #savingmerg
			select a.SSN,a.parentaccount,isnull(b.[# Savings],0)+isnull(c.[# Checking],0)+isnull(d.[# MoneyMarket],0)+isnull(e.[# Certificates],0) [# Deposit]
			,b.BALANCE_Savings_Staticpool,BALANCE_Checking_Staticpool,BALANCE_certificates_Staticpool,BALANCE_MoneyMarket_Staticpool
			,isnull(b.Balance_Savings_Staticpool,0) +isnull(Balance_Checking_Staticpool,0) +isnull(Balance_certificates_Staticpool,0) 
			+isnull(Balance_MoneyMarket_Staticpool,0) Current_Deposit_Balance
			into #SavingMerg
			from #Savings a
			left join #Savings b on a.parentaccount=b.parentaccount
			left join #Checking c on a.parentaccount=c.parentaccount
			left join #MoneyMarket d on a.parentaccount=d.parentaccount
			left join #Certificates e on a.parentaccount=e.parentaccount

		Drop table if exists #CC_data
		select * 
		into #CC_data
		from 
		(
		SELECT  a.[Durable_Key],b.PARENTACCOUNT,mob,[Card Account Delinquent Day Account],extract_datepart,b.[Social Security Number] SSN
		FROM TMGData.[dbo].[cardholder] a
		  left join #temp19 b
		  on a.[Social Security Number]=b.[Social Security Number]
		  where a.[Social Security Number] in (select [Social Security Number] from #CC_Members_Static)
		  and Active_Flag=1 ) a 
		  where mob>=12


		-- creditcard deliquency --
		drop table if exists #ccdeliquent
		Select PArentaccount,sum(cycle1_cc)cycle_cc1,sum(cycle2_cc)cycle_cc2,sum(cycle3_cc)cycle_cc3,sum(cycle4_cc)cycle_cc4,sum(cycle5_cc)cycle_cc5
		,sum(cycle6_cc)cycle_cc6,sum(ccchargeoff) ccchargeoff
		into #ccdeliquent
		  from(
		Select  parentaccount,
		 case when [Card Account Delinquent Day Account] between 1 and 29 then 1 else 0 end   cycle1_cc
		 ,case when [Card Account Delinquent Day Account] between 30 and 59 then 1 else 0 end cycle2_cc
		 ,case when [Card Account Delinquent Day Account] between 60 and 89 then 1 else 0 end cycle3_cc
		 ,case when [Card Account Delinquent Day Account] between 90 and 119 then 1 else 0 end  cycle4_cc
		 ,case when [Card Account Delinquent Day Account] between 120 and 149 then 1 else 0 end cycle5_cc
		 ,case when [Card Account Delinquent Day Account] between 150 and 179 then 1 else 0 end cycle6_cc
		 ,case when [Card Account Delinquent Day Account] > 179 then 1 else 0 end  ccchargeoff
		  FROM 
		-- Change the date type
		#CC_data where extract_datepart in (select extract_datepart from #creditdate)) T 
		group by PARENTACCOUNT

		--Select * from #CC_Members_Static
		Drop table if exists #Credit_Card_data
		select PARENTACCOUNT,count(distinct Durable_Key) Count_Durable_CC
			into #Credit_Card_data
			 from #CC_data
			 group by PARENTACCOUNT

			 --SELECT * FROM #CC_Members_Static   --- 0

	-- Change the Primary table 
	
		
	Drop table if exists #temp_Loan_saving_merg
	Select a.Parentaccount,a.SSN,a.[# Deposit],a.Current_Deposit_Balance,d.Loan_Balance
	,d.[Diff_Due_Payment_Vehicle_Staticpool],d.FICO_Staticpool,d.Cycle1,d.Cycle2,d.Cycle3,d.Cycle4,d.Cycle5,d.Cycle6,d.LoanchargeoffFlag
	,d.[# HELOC loan],d.[# Personal_Secured loan],d.[# Personal_Unsecured loan],d.[# Real_Estate loan],d.[# Vehicle loan]
	,e.[mortgage_count],a.BALANCE_Savings_Staticpool,a.BALANCE_Checking_Staticpool,a.BALANCE_certificates_Staticpool,a.BALANCE_MoneyMarket_Staticpool
	,d.cpiflag,d.Lien_flag,d.originationltv
			into #temp_Loan_saving_merg
			from (select * from #loandata ) D
			left join #SavingMerg A
			on a.SSN = d.SSN
			left join (select * from #mortgagebalance) e
			on a.SSN = e.SSN
		--select * from #loandata where SSN=439579267
		--select * from #SavingMerg where SSN is null
		 --select * from #temp_Loan_saving_merg where SSN is null
		 -- select * from #loandata where SSN=484088895

		 drop table if exists #finaltemp
		 --drop table if exists Analytics.dbo.MemberLevelRiskScore3
		select case when SSN is null then b.[Social Security Number] else SSN end SSN,isnull([# Deposit],0) [# Deposit]
		,PA,a.[Diff_Due_Payment_Vehicle_Staticpool],a.[FICO_Staticpool],isnull(a.Cycle1,0) Cycle1
		,isnull(a.Cycle2,0) Cycle2,isnull(A.Cycle3,0) Cycle3,isnull(a.Cycle4,0) Cycle4,isnull(a.Cycle5,0) Cycle5,isnull(a.Cycle6,0) Cycle6,isnull(a.LoanchargeoffFlag,0) LoanchargeoffFlag
		,isnull(a.#loanproducts,0) #loanproducts,isnull(a.totaldepositbalance,0) totaldepositbalance,isnull(A.cpiflag,0) cpiflag
		,isnull(a.Lien_flag,0) Lien_flag,isnull(A.originationltv,0) originationltv,isnull(Loan_Balance,0) Loan_Balance
		into #finaltemp
		from		(Select SSN
				 ,case when a.PARENTACCOUNT is not null then a.PARENTACCOUNT else b.PARENTACCOUNT end as PA
				,a.[# Deposit]
				,a.[Diff_Due_Payment_Vehicle_Staticpool]
				,a.[FICO_Staticpool]
				,a.Cycle1
				,a.Cycle2
				,A.Cycle3
				,a.Cycle4
				,a.Cycle5
				,a.Cycle6
				,a.LoanchargeoffFlag
				,(isnull([# HELOC loan],0) +isnull([# Personal_Secured loan],0) +isnull([# Personal_Unsecured loan],0)
				+isnull([# Real_Estate loan],0) + isnull([# Vehicle loan] ,0) +isnull([mortgage_count],0) + isnull([Count_Durable_CC],0)) as #loanproducts
				,(isnull(BALANCE_Savings_Staticpool,0)+isnull(BALANCE_Checking_Staticpool,0)+isnull(BALANCE_MoneyMarket_Staticpool,0)+isnull(BALANCE_Certificates_Staticpool,0)) totaldepositbalance
				,A.cpiflag
				,a.Lien_flag
				,A.originationltv
				,Loan_Balance
				from #temp_Loan_saving_merg a full outer join (select * from #Credit_Card_data) b on a.PARENTACCOUNT = b.PARENTACCOUNT
				) A
		left join #temp19 b on a.PA=b.PARENTACCOUNT
		--	 select count(distinct PARENTACCOUNT) from #temp where PARENTACCOUNT is null
		--  select * from #temp_Loan_saving_merg where SSN=484088895
		--   select count(*) from #finaltemp  where SSN is null
		--    select count(*) from #Credit_Card_data 
		--	select count(*) from Analytics.dbo.MemberLevelRiskScore4 where SSN is null
		-- Credit card and all products delinquency merge 
		Drop table if exists #temp_previousmodel
		Select a.*, 
		(isnull(a.cycle1,0) +ISNULL(b.cycle_cc1,0)) finalcycle1,(isnull(a.cycle2,0) +ISNULL(b.cycle_cc2,0)) finalcycle2
		,(isnull(a.cycle3,0) +ISNULL(b.cycle_cc3,0)) finalcycle3,(isnull(a.cycle4,0) +ISNULL(b.cycle_cc4,0)) finalcycle4
		,(isnull(a.cycle5,0) +ISNULL(b.cycle_cc5,0)) finalcycle5,(isnull(a.cycle6,0) +ISNULL(b.cycle_cc6,0)) finalcycle6		
		,(isnull(a.LoanchargeoffFlag,0) +ISNULL(b.ccchargeoff,0)) finalLoanchargeoffFlag
		into #temp_previousmodel
		  from #finaltemp a left join (select * from #ccdeliquent) b on a.PA = b.PARENTACCOUNT
		 
		  --	select count(*) from #finaltemp where SSN is null
		  Delete from #temp_previousmodel where PA is null

    Drop table if exists #previousmodel_finalvar
    SELECT * 
	INTO #previousmodel_finalvar
	from
	(Select SSN,max(finalcycle2) finalcycle2,max(FICO_Staticpool) FICO_Staticpool,max(finalcycle1) finalcycle1
	,max(finalLoanchargeoffFlag) finalLoanchargeoffFlag,sum([#loanproducts]) [#loanproducts],sum(totaldepositbalance) totaldepositbalance
	 ,max(Diff_Due_Payment_Vehicle_Staticpool) Diff_Due_Payment_Vehicle_Staticpool,max(cpiflag) cpiflag,max(originationltv) originationltv
	 ,sum([# Deposit]) [# Deposit],sum(Loan_Balance) Loan_Balance,max(Lien_flag) Lien_flag
	 from #temp_previousmodel
	 group by SSN
	 --,PA,FICO_Staticpool,finalLoanchargeoffFlag,[#loanproducts],totaldepositbalance
	 --,Diff_Due_Payment_Vehicle_Staticpool,cpiflag,originationltv,[# Deposit],Loan_Balance,Lien_flag
	 ) A

		  
/************* Traget Flag Creation  **************/

/************* 1. CREDIT CARD  **************/

drop table if exists #temp1
select Durable_Key,[Credit Limit],mob,[Card Description],
	[Last Statement Balance Amount],RevolvingBalance,
	([Last Statement Sale Amount]-[Last Statement Return Amount]) as spend,
	TRIPFLAG,[Last Statement Payment Amount], Extract_DatePart as sp_month
    into #temp1
	FROM TMGData.[dbo].[cardholder]
	where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business')
	and [External Status Code] not in ('c','z')
	and Extract_DatePart = 202206 and mob > 11 and [card account delinquent day account]<60


drop table if exists #DelinquencyCycle
select Durable_Key ,[Social Security Number],
	sum(case when [Card Account Delinquent Day Account] >= 1 and [Card Account Delinquent Day Account] < 30 then 1 else 0 end) as Cycle1,
	sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Cycle2,
	sum(case when ([Card Account Delinquent Day Account] >=60 or chargeoffamount_final>0) then 1 else 0 end) as Cycle2plus
	into #DelinquencyCycle
	from TMGData.[dbo].[cardholder]
	where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business')
	and Extract_DatePart between 202206 + 1 and 202212 
	and Durable_Key in 
	(select Durable_Key from #temp1)
	group by Durable_Key,[Social Security Number]


	--select * From #DelinquencyCycle

	
    drop table if exists #targetvarCC
	select distinct [Social Security Number] SSN
	into #targetvarCC from #DelinquencyCycle
	where Cycle2plus>=1  -- 1453

/************* 2. AUTO LOAN & PERSONAL LOAN  **************/

/********** A. Declaring SP **************/

   --DECLARE @staticpooldate DATE
   --SET @staticpooldate = '2022-06-30'

  --  (select datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Processdate from
		--(select (ProcessDate) processdate from ARCUSYM000..LOAN where ProcessDate = '2022-06-30') A)

/*********** B. Loan Static ************/

	drop table if exists #LoanStaticap
	select * 
	into #LoanStaticap
	from
	(
	select 
		[ProcessDate],[Process date],[Process_date],[PARENTACCOUNT],concat(PARENTACCOUNT,ID) UNID,
		LoanCategory2,LoanCategory3
	
		from
			(
			select *,CONCAT(PARENTACCOUNT,ID) UNID
			,case when opendate=closedate then 0 else 1 end Flag
			,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date 
			then 1 else 0 end Open_Flag
			,DATEDIFF(month,OPENDATE,@staticpooldate) MOB	
				from 
					(select *
					,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
					else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
					,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
					else concat(year(opendate),month(opendate)) end Open_date
					,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
					else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
					,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
					,left(ProcessDate,6) Process_date
					from ARCUSYM000.dbo.LOAN
					--where (CHARGEOFFDATE>=@staticpooldate or CHARGEOFFDATE is null ) 
					) H
				where  ORIGINALDATE is not null and OpenDate is not null 
				and CLOSEDATE is null and CHARGEOFFDATE is null
				and [Process date]=@staticpooldate		-- Later give the @staticpooldate date here 
				and MATURITYDATE>@staticpooldate	-- add 3 month in currrent date
			) A
				left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
				on b.loantype=a.TYPE
				where Flag=1 and Open_Flag=1 
				) D
				where (LoanCategory2 ='Vehicle' or LoanCategory2='Personal')
				order by PARENTACCOUNT,ProcessDate

/*********** C. Delinquency Cycles for AUTO LOAN *************/



		drop table if exists #TargetDELQ
		select AccountNumber Parentaccount,max(Chargoffflag) Chargoffflag,
		max(Target_Cycle1) Target_Cycle1,max(Target_Cycle2) Target_Cycle2,max(Target_Cycle3) Target_Cycle3
		into #TargetDELQ
		from
		( select 
		Convert(date, cast(l.Processdate as nvarchar)) as Date, l.ProcessDate,left(l.ProcessDate,6) Process_date,
		AccountNumber,LoanID,l.LoanOpenDate,LoanDelqDays,
		case when LoanDelqDays between 1 and 29 then 1 else 0 end Target_Cycle1 
		,case when LoanDelqDays between 30 and 59 then 1 else 0 end Target_Cycle2 
		,case when LoanDelqDays between 60 and 180 then 1 else 0 end Target_Cycle3 ,
		case when LoanChargeoffDate is not null then 1 else 0 end Chargoffflag
		,LoanPastDueAmount, LoanBalance,l.LoanChargeoffDate, l.LoanType,alc.LoanTypeDescription,
		Count(t.locator) as BankruptcyCount 
		from arcusym000.arcu.ARCULoanDetailed  as l
				left join arcusym000.arcu.ARCULoanCategory as alc on alc.LoanType = l.LoanType
				left join ARCUSYM000.dbo.tracking as t on t.processdate = l.ProcessDate and t.PARENTACCOUNT = l.AccountNumber 
				and t.TYPE = 36 
				and (t.EXPIREDATE is null or t.EXPIREDATE < Convert(date, cast(t.processdate as varchar)))
		where LoanDelqDays > 0 and concat(AccountNumber,loanid) in (select UNID from #LoanStaticap) 

		and l.processdate in (20220731,20220831,20220930,20221031,20221130,20221231) -- add the @staticpooldate + 3 month
		group by l.ProcessDate, l.AccountNumber,l.LoanID,l.LoanOpenDate,l.LoanPastDueAmount,l.LoanChargeoffDate, l.LoanType, alc.LoanTypeDescription, l.LoanDelqDays, LoanBalance
		) A
		group by AccountNumber
		order by AccountNumber		


		DROP TABLE IF EXISTS #TARGET_AUTOPER
		select distinct Parentaccount
		INTO #TARGET_AUTOPER
		 from #TargetDELQ
		where Target_Cycle3=1 or Chargoffflag =1 --4239

		DROP TABLE IF EXISTS #TARGET_AUTOPER_SSN
		select distinct A.Parentaccount,B.SSN
		INTO #TARGET_AUTOPER_SSN
		 from #TARGET_AUTOPER A
		 LEFT JOIN ARCUSYM000..NAME B
		 ON A.Parentaccount=B.PARENTACCOUNT  --4403


		
	--MOrtgage TF


	drop table if exists #Extractdate_mortgage
	select  Extractdate,max(AsOfDate) AsOfDate
	into #Extractdate_mortgage
	from (select case when len(month(AsOfDate))=1 then concat(year(AsOfDate),0,month(AsOfDate)) else concat(year(AsOfDate),month(AsOfDate)) end Extractdate,* 
	from AE_EDW..F_Mortgage_Daily) A
	where CoreMortgageStatus='Active' 
	group by Extractdate
	order by Extractdate


	--select * from #Extractdate_mortgage

	drop table if exists #Max_processdate_Mortgage
	select Process_Date,max(ProcessDate) ProcessDate
			into #Max_processdate_Mortgage 
			from
			(select parentaccount,(USERCHAR1) USERCHAR1,EXPIREDATE,ProcessDate,left(ProcessDate,6) Process_Date 
						from ARCUSYM000..TRACKING 
						group by parentaccount,USERCHAR1,EXPIREDATE,ProcessDate) A
						where Process_Date between 202106 and 202206
			group by Process_Date

	go
			drop table if exists #Tracking
			select parentaccount,ID,(USERCHAR1) USERCHAR1,EXPIREDATE,ProcessDate,left(ProcessDate,6) Process_Date 
			into #Tracking
			from ARCUSYM000..TRACKING where ProcessDate in (select ProcessDate from #Max_processdate_Mortgage)
			group by parentaccount,ID,USERCHAR1,EXPIREDATE,ProcessDate

			--select USERCHAR1 from  #Tracking
	go
			-- Harland loans 

			drop table if exists #Mortgage1
			select  b.parentaccount,
			a.*,case when Extractdate=Opendate then 1 else 0 end New_flag
			into #Mortgage1
			from (select case when len(month(AsOfDate))=1 then concat(year(AsOfDate),0,month(AsOfDate)) else concat(year(AsOfDate),month(AsOfDate)) end Extractdate
					,case when len(month(MortgageOpenDate))=1 then concat(year(MortgageOpenDate),0,month(MortgageOpenDate)) else concat(year(MortgageOpenDate),month(MortgageOpenDate)) end Opendate
					,* from AE_EDW..F_Mortgage_Daily) A
			left join #Tracking b
			on a.mortgageid=b.USERCHAR1 and a.Extractdate=b.Process_Date	
			where CoreMortgageStatus='Active' and AsOfDate='2022-06-30' 
			and AsOfDate in (select AsOfDate from #Extractdate_mortgage) and b.EXPIREDATE is null and MortgageDueDate>'2022-06-30'  
			and CurrentBalance>0
			go

			--select * from AE_EDW..F_Mortgage_Daily

			Drop table if exists #Del_accounts
			select * 
			into #Del_accounts
			from 		(select h.*,Case when len(MONTH(CutoffDate)) = 1 then CONCAT(YEAR(cutoffdate),0,month(cutoffdate))
							else CONCAT(YEAR(cutoffdate),month(cutoffdate)) end as extract_date
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 1  then 1 else 0 end DQ_Flag
						FROM [UICCU].[dbo].[HarlandLoanCutoff] h
							left join ae_edw.dbo.f_mortgage f on f.mortgageid = h.loanid and month(reportmonth) = month(cutoffdate)
															and year(reportmonth) = year(cutoffdate)
							WHERE loanprincipalbal > 0 AND RegPrincipalColl != investorprinbal AND (investorid LIKE '%bal' or investorid LIKE '%fix%' or investorid LIKE '%arm' or
														investorid LIKE 'E-10YR' or investorid LIKE 'E-WORK' or InvestorID like '%Equity%' or InvestorID like '%TDR%' or
														InvestorID = 'F-ARM' or InvestorID = 'FAB-HH' )
									   and investorprinbal is not null
									   and datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and RecordType <> 2
									   and mortgageid in (select mortgageid from #Mortgage1)
					) A where extract_date = 202206 and DQ_Flag=1
			go

		
			--select * from #Mortgage1

			--select * from [UICCU].[dbo].[HarlandLoanCutoff]

			drop table if exists #Mortgage
			select a.* into #Mortgage from #Mortgage1 a 
			left join #Del_accounts b on a.MortgageID=b.loanid where b.LoanID is null

				Drop table if exists #Processdate
			select 
			Process_date,max(ProcessDate) MAX_ProcessDate 
			into #Processdate
			from
				(
				select ProcessDate,left(ProcessDate,6) Process_date
				,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
				from ARCUSYM000..NAME group by ProcessDate
				) A 
				where [Process date] between dateadd(month,-12,'2022-06-30') and '2022-06-30'
				group by Process_Date
				order by Process_Date
	
		drop table if exists #Delinquency
			select processdate,Process_date,AccountNumber,LoanID,Cycle1 ,Cycle2 ,Cycle2plus 
			into #Delinquency
			from
			 (
					 select 
					Convert(date, cast(l.Processdate as nvarchar)) as Date, l.ProcessDate,left(l.ProcessDate,6) Process_date,
					AccountNumber,LoanID,l.LoanOpenDate,LoanDelqDays,
					case when LoanDelqDays between 1 and 29 then 1 else 0 end Cycle1 
					,case when LoanDelqDays between 30 and 59 then 1 else 0 end Cycle2 
					,case when LoanDelqDays >=60 or LoanChargeoffDate is not null  then 1 else 0 end Cycle2plus 
			
					from arcusym000.arcu.ARCULoanDetailed  as l
							left join arcusym000.arcu.ARCULoanCategory as alc on alc.LoanType = l.LoanType
							left join ARCUSYM000.dbo.tracking as t on t.processdate = l.ProcessDate and t.PARENTACCOUNT = l.AccountNumber 
							and t.TYPE = 36 and (t.EXPIREDATE is null or t.EXPIREDATE < Convert(date, cast(t.processdate as varchar)))
							left join [ARCUSYM000].[arcu].[ARCULoanCategory] V on l.LoanType=v.LoanType
					where LoanDelqDays > 0 
					and
					( v.LoanCategory2='Real Estate'
					or v.LoanCategory3='2nd Mortgage'
					or v.LoanCategory4 like '%HEL%')
					and l.processdate in (select MAX_ProcessDate from #processdate)
					and l.AccountNumber in (select PARENTACCOUNT from #Mortgage group by PARENTACCOUNT)
					group by l.ProcessDate,l.AccountNumber,l.LoanID,l.LoanOpenDate,l.LoanPastDueAmount,l.LoanChargeoffDate
					,l.LoanType, l.LoanDelqDays
			) A
			order by AccountNumber,LoanID,ProcessDate



		
			go
			Drop table if exists #Delinquency_hardland
			select PARENTACCOUNT,[DQ 1+ Days Flag],[DQ 30+ Days Flag],[DQ 60+ Days Flag],DQ_Flag
						into #Delinquency_hardland
						from 		(select m.PARENTACCOUNT,h.*,Case when len(MONTH(CutoffDate)) = 1 then CONCAT(YEAR(cutoffdate),0,month(cutoffdate))
										else CONCAT(YEAR(cutoffdate),month(cutoffdate)) end as extract_date
									,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 1  then 1 else 0 end DQ_Flag
									,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and datediff(d, h.duedate, eomonth(cutoffdate)) < 30 then 1 else 0  end [DQ 1+ Days Flag]
								,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 30 and datediff(d, h.duedate, eomonth(cutoffdate)) < 60 then 1 else 0  end [DQ 30+ Days Flag]
								,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 60 and datediff(d, h.duedate, eomonth(cutoffdate)) < 90 then 1 else 0  end [DQ 60+ Days Flag]
									FROM [UICCU].[dbo].[HarlandLoanCutoff] h
										left join (select MortgageID,parentaccount from #Mortgage) m on h.LoanID=m.MortgageID
										WHERE loanprincipalbal > 0 AND RegPrincipalColl != investorprinbal AND (investorid LIKE '%bal' or investorid LIKE '%fix%' or investorid LIKE '%arm' or
																	investorid LIKE 'E-10YR' or investorid LIKE 'E-WORK' or InvestorID like '%Equity%' or InvestorID like '%TDR%' or
																	InvestorID = 'F-ARM' or InvestorID = 'FAB-HH' )
												   and investorprinbal is not null
												   and datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and RecordType <> 2
												   and m.mortgageid is not null
								) A 
					where extract_date in (select process_date from #Processdate) and DQ_Flag=1
			group by PARENTACCOUNT,[DQ 1+ Days Flag],[DQ 30+ Days Flag],[DQ 60+ Days Flag],DQ_Flag
		
			drop table if exists #risk_mortgage
			select distinct PARENTACCOUNT
			into #risk_mortgage
			 from
			(select AccountNumber PARENTACCOUNT from #Delinquency where Cycle2plus=1
			union 
			select PARENTACCOUNT from #Delinquency_hardland where [DQ 60+ Days Flag]=1) P



			--select * from #risk_mortgage
       /******* TAKING SSN FROM RISK *******/
		drop table if exists #risk_mortgage_ssn

		SELECT DISTINCT SSN
		INTO #risk_mortgage_ssn
		 FROM #risk_mortgage E
		LEFT JOIN ARCUSYM000..NAME F
		ON E.PARENTACCOUNT = F.PARENTACCOUNT


		 /******* COMBINING ALL TARGET FLAGS *******/

		 DROP TABLE IF EXISTS #TARGET_SSN

		 SELECT DISTINCT SSN 
		 INTO #TARGET_SSN
		 FROM
		 ( SELECT * FROM #targetvarCC
		 UNION
		 SELECT SSN FROM #TARGET_AUTOPER_SSN
		 UNION
		 SELECT DISTINCT SSN FROM #risk_mortgage_ssn) T   -- 5598

		 	/**** FINAL TABLE CREATION (Analytics.dbo.REVISED_MASTER_MemberRiskScore) ****/

			drop table if exists Analytics.dbo.REVISED_MASTER_MemberRiskScore
			SELECT AA.*
			,BB.cpiflag
			,BB.Diff_Due_Payment_Vehicle_Staticpool
			,BB.FICO_Staticpool
			,BB.finalcycle1
			,BB.finalcycle2
			,BB.finalLoanchargeoffFlag
			,BB.Lien_flag
			,BB.#loanproducts
			,BB.originationltv
			,CASE WHEN  AA.SSN003 = CC.SSN THEN 1 ELSE 0 END [RISK_TARGET]
			INTO Analytics.dbo.REVISED_MASTER_MemberRiskScore
			FROM #MasterData AA
			LEFT JOIN
			 #previousmodel_finalvar BB
			 ON AA.SSN003 = BB.SSN
			LEFT JOIN 
			 #TARGET_SSN CC
			ON AA.SSN003 = CC.SSN

			--SELECT COUNT(SSN003) FROM Analytics.dbo.REVISED_MASTER_MemberRiskScore
			--SELECT COUNT(DISTINCT SSN003) FROM Analytics.dbo.REVISED_MASTER_MemberRiskScore --406899

			/************ SPLITTING INTO TRAIN AND TEST **************/

			DROP TABLE IF EXISTS #SPLIT

			SELECT *,(CASE WHEN NTILE(10) OVER (ORDER BY RAND()) <= 7 THEN 'TRAIN' ELSE 'TEST' END) SPLIT
			INTO #SPLIT
			FROM Analytics.dbo.REVISED_MASTER_MemberRiskScore

		
			/************ TRAIN DATA ************/

			DROP TABLE IF EXISTS Analytics.dbo.REVISED_MemberRiskScore_TRAIN

			SELECT * 
			INTO Analytics.dbo.REVISED_MemberRiskScore_TRAIN
			FROM #SPLIT
			WHERE SPLIT = 'TRAIN'    --284830

			/************ TEST DATA ************/

			DROP TABLE IF EXISTS Analytics.dbo.REVISED_MemberRiskScore_TEST

			SELECT * 
			INTO Analytics.dbo.REVISED_MemberRiskScore_TEST
			FROM #SPLIT
			WHERE SPLIT = 'TEST'     --122069


--/************************************************************* UPDATED RISK MODEL DATA ( 4/4/23 ) ********************************************************************************/

--			DROP TABLE IF EXISTS #temp_combined
--			SELECT SSN003
--			,cpiflag
--			,Diff_Due_Payment_Vehicle_Staticpool
--			,FICO_Staticpool
--			,finalcycle1
--			,finalcycle2
--			,finalLoanchargeoffFlag
--			,Lien_flag
--			,#loanproducts
--			,originationltv
--			,RISK_TARGET
--			INTO #temp_combined
--			FROM 
--			(SELECT * FROM Analytics.dbo.MemberRiskScore_TEST_REVISED
--			union all
--			SELECT * from  Analytics.dbo.MemberRiskScore_TRAIN_REVISED) A  --186281

--			drop table if exists Analytics.dbo.REVISED_MASTER_MemberRiskScore

--			SELECT BB.*
--			,AA.cpiflag
--			,AA.Diff_Due_Payment_Vehicle_Staticpool
--			,AA.FICO_Staticpool
--			,AA.finalcycle1
--			,AA.finalcycle2
--			,AA.finalLoanchargeoffFlag
--			,AA.Lien_flag
--			,AA.#loanproducts
--			,AA.originationltv
--			,AA.RISK_TARGET
--			INTO Analytics.dbo.REVISED_MASTER_MemberRiskScore
--			FROM #temp_combined AA
--			LEFT JOIN  #MasterData BB
--			ON AA.SSN003 = BB.SSN003

--			/*********** Revised Train Data *************/

--			DROP TABLE IF EXISTS Analytics.dbo.MemberRiskScore_TRAIN

--			SELECT *
--			INTO Analytics.dbo.MemberRiskScore_TRAIN
--			FROM Analytics.dbo.REVISED_MASTER_MemberRiskScore
--			WHERE SSN003 IN (SELECT SSN003 from   Analytics.dbo.MemberRiskScore_TRAIN_REVISED)  --130451

--			/*********** Revised Test Data ***************/

--		    DROP TABLE IF EXISTS Analytics.dbo.MemberRiskScore_TEST

--			SELECT *
--			INTO Analytics.dbo.MemberRiskScore_TEST
--			FROM Analytics.dbo.REVISED_MASTER_MemberRiskScore
--			WHERE SSN003 IN (SELECT SSN003 from  Analytics.dbo.MemberRiskScore_TEST_REVISED)  --55830


--/********************************************************** DROPPING THE ONLY DEPOSIT PRODUCTS ***************************************************/

--			DROP TABLE IF EXISTS Analytics.dbo.MemberRiskScore_REVISED
--            SELECT *
--			INTO Analytics.dbo.MemberRiskScore_REVISED
--			FROM Analytics.dbo.REVISED_MASTER_MemberRiskScore
--			WHERE SSN003 in
--			(SELECT distinct SSN FROM #loan_woCC
--			union all
--			select distinct [Social Security Number] from #CC_Members_Static) --- 186281
  
-- /********************************************************* DROPPING FROM TRAIN ****************************************************************/          
			
--			DROP TABLE IF EXISTS Analytics.dbo.MemberRiskScore_TRAIN_REVISED
--			SELECT *
--			INTO Analytics.dbo.MemberRiskScore_TRAIN_REVISED
--			 FROM Analytics.dbo.REVISED_MemberRiskScore_TRAIN
--			where SSN003 IN (SELECT SSN003 FROM Analytics.dbo.MemberRiskScore_REVISED)  -- 130451

-- /********************************************************* DROPPING FROM TEST ****************************************************************/ 

--			DROP TABLE IF EXISTS Analytics.dbo.MemberRiskScore_TEST_REVISED
--			SELECT *
--			INTO Analytics.dbo.MemberRiskScore_TEST_REVISED
--			 FROM Analytics.dbo.REVISED_MemberRiskScore_TEST
--			where SSN003 IN (SELECT SSN003 FROM Analytics.dbo.MemberRiskScore_REVISED) -- 55830



/******************************************************************* Combining the Train and Test *********************************************************************************/

          DROP TABLE IF EXISTS #combined_train_test_previous
		  
		  SELECT SSN003 [MEMBER]
			,cpiflag
			,Diff_Due_Payment_Vehicle_Staticpool
			,FICO_Staticpool
			,finalcycle1
			,finalcycle2
			,finalLoanchargeoffFlag
			,Lien_flag
			,#loanproducts
			,originationltv
			,RISK_TARGET
			,SPLIT
		  INTO 	#combined_train_test_previous
		  FROM
		  (SELECT * FROM Analytics.dbo.MemberRiskScore_TRAIN 
		  UNION ALL
		  SELECT * FROM Analytics.dbo.MemberRiskScore_TEST)	U	
		
		  DROP TABLE IF EXISTS #RiskMaster
		  SELECT * 
		  INTO #RiskMaster
		  FROM #MasterData
		  where SSN003 in (SELECT SSN003 FROM Analytics.dbo.MemberRiskScore_TRAIN 
		                   UNION ALL
		                   SELECT SSN003 FROM Analytics.dbo.MemberRiskScore_TEST) 

          DROP TABLE IF EXISTS #MEMBER_RISK_SCORE_23

		  SELECT * 
		  INTO #MEMBER_RISK_SCORE_23
		  FROM #RiskMaster A
		  LEFT JOIN #combined_train_test_previous B
		  ON A.SSN003 = B.MEMBER 

		  DROP TABLE IF EXISTS Analytics.dbo.MemberRiskScore_V2_TRAIN 

		  SELECT *
		  INTO Analytics.dbo.MemberRiskScore_V2_TRAIN  
		  FROM #MEMBER_RISK_SCORE_23 where SPLIT = 'TRAIN'     -- 130451

		  DROP TABLE IF EXISTS Analytics.dbo.MemberRiskScore_V2_TEST

		  SELECT *
		  INTO Analytics.dbo.MemberRiskScore_V2_TEST  
		  FROM #MEMBER_RISK_SCORE_23 where SPLIT = 'TEST'       -- 55830
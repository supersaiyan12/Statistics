
USE [Analytics]
--GO
/****** Object:  StoredProcedure [dbo].[Member Level Risk Scoring_V1]    Script Date: 1/23/2024 3:52:18 AM ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
 --creating SP 


 --ALTER procedure [dbo].[Member Level Risk Scoring_V1] 
	--	as
	--		begin

 		DECLARE @staticpooldate date
		set @staticpooldate = '2023-06-30'

		declare @staticcreditdate date
		set  @staticcreditdate = '2023-06-01'
		--SELECT @staticcreditdate

		print (@staticcreditdate)

 --staticpool active loan members 
		drop table if exists #Name
		SELECT distinct  SSN,b.PARENTACCOUNT,
		case when isnumeric(TRY_CAST(a.USERCHAR3 AS INT))=1 then a.USERCHAR3 else 0  end FICO_Staticpool,a.USERCHAR3
		into #NAME
FROM 
    (SELECT *, datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_date 
    FROM ARCUSYM000.dbo.NAME) a
    LEFT JOIN ARCUSYM000.dbo.LOAN b 
	ON a.PARENTACCOUNT=b.PARENTACCOUNT AND a.ProcessDate=b.ProcessDate
WHERE a.TYPE=0 AND a.Process_date=@staticpooldate;
--select top 1000 * from #name where USERCHAR3 is null
--creating flag for the varible 

--select * from #name
 
 drop table if exists #membership_loan

		--DECLARE @staticpooldate date
		--set @staticpooldate = '2022-06-30'
			
			--select distinct parentaccount from #commercial_loan
              select *
			    
				,case when  (LoanCategory1 like 'commercial%')
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then  'Commercial_loan'
                 --when LoanCategory3 = '1st Mortgage'
				 --and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 --and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 --then 'Real_Estate_loan1'
				 --when LoanCategory3 = '2nd Mortgage'
				 --and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 --and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 --then 'Real_Estate_loan2'
				 when LoanCategory3 in ('1st Mortgage','2nd Mortgage')
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then 'Real_Estate_loan'
                when LoanCategory3 = 'Secured'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				 then 'SecuredLoan' 
                when LoanCategory3 = 'Unsecured'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				  then 'UnsecuredLoan' 
				when LoanCategory2 ='Vehicle'
				 and LoanCategory3 not in ('Writeoff','Workout/TDR')
				 and LoanCategory4 not in ('Writeoff','Workout/TDR')
				  then 'Vehicleloan' else 'Others' end as Product_Flag
           into #membership_loan
			from
			(
					select a.[ProcessDate]
						   ,left(a.ProcessDate,6) ProcessDate_V
						   ,Process_Date
						   ,Open_date
						   ,Close_date
						   ,case when Process_Date in ((EOMONTH(DATEADD(month,-12,@staticpooldate))),(EOMONTH(DATEADD(month,-11,@staticpooldate))),(EOMONTH(DATEADD(month,-10,@staticpooldate )))) then 'Q4'
		                         when Process_Date in ((EOMONTH(DATEADD(month,-9,@staticpooldate ))),(EOMONTH(DATEADD(month,-8,@staticpooldate))),(EOMONTH(DATEADD(month,-7,@staticpooldate)))) then 'Q3'
 								 when Process_Date in ((EOMONTH(DATEADD(month,-6,@staticpooldate ))),(EOMONTH(DATEADD(month,-5,@staticpooldate))),(EOMONTH(DATEADD(month,-4,@staticpooldate)))) then 'Q2'
								 when Process_Date in ((EOMONTH(DATEADD(month,-3,@staticpooldate))),(EOMONTH(DATEADD(month,-2,@staticpooldate ))),(EOMONTH(DATEADD(month,-1,@staticpooldate )))) then 'Q1'
								 when Process_Date in (@staticpooldate) then 'Staticpool'
							end Quarters
							,case when Process_Date in (EOMONTH(DATEADD(month,-12,@staticpooldate)),(EOMONTH(DATEADD(month,-11,@staticpooldate))),(EOMONTH(DATEADD(month,-10,@staticpooldate))) 
							                           ,(EOMONTH(DATEADD(month,-9,@staticpooldate ))),(EOMONTH(DATEADD(month,-8,@staticpooldate))),(EOMONTH(DATEADD(month,-7,@staticpooldate)))) then 'H2'
 								  when Process_Date in (EOMONTH(DATEADD(month,-6,@staticpooldate )),(EOMONTH(DATEADD(month,-5,@staticpooldate))),(EOMONTH(DATEADD(month,-4,@staticpooldate)))
								                      ,(EOMONTH(DATEADD(month,-3,@staticpooldate))),(EOMONTH(DATEADD(month,-2,@staticpooldate ))),(EOMONTH(DATEADD(month,-1,@staticpooldate )))) then 'H1'
							end HalfYearly
							,d.SSN
							,d.FICO_Staticpool
							,a.[PARENTACCOUNT]
							--,a.FICO_Staticpool
							,a.[ID]
							,rtrim(Ltrim(CONCAT(a.PARENTACCOUNT,ID))) UNID
							,case when len(month(a.closedate))=1 then CONCAT(year(a.closedate),0,month(a.closedate))
							      else CONCAT(year(a.closedate),month(a.closedate)) end  Closed_date_INT
							,case when len(month(a.opendate))=1 then CONCAT(year(a.opendate),0,month(a.opendate))
							      else CONCAT(year(a.opendate),month(a.opendate)) end  OPEN_date_INT
							,DATEDIFF(month,a.OPEN_DATE,@staticpooldate) MOB
							,DATEDIFF(month,@staticpooldate,MATURITYDATE) Month_to_Maturity
							,a.[TYPE]
							,a.[LASTFMDATE]
							,[LASTTRANDATE]
							,[ORIGINALDATE]
							,a.[OPENDATE]
							,a.[CLOSEDATE]
							,[LOANCODE]
							,[APPROVALCODE]
							,[APPROVALDATE]
							,[PAYMENTFREQUENCY]
							,[PARTIALPAYMENT]
							,[PAYMENT]
							,[PAYMENTCOUNT]
							,[DUEDAY1]
							,[DUEDAY2]
							,[INTERESTRATE]
							,[ORIGINALBALANCE]
							,BALANCE
							,[CREDITLIMIT]
							,[DESCRIPTION]
							,[NSFMONTHTODATE]
							,[MATURITYDATE]
							,[APR]
							,[CREDITSCORE]
							,LASTPAYMENTDATE
							,DUEDATE
							,abs(day(DUEDATE)-day(LASTPAYMENTDATE)) DFT_DUEPAYMENTDAYS
							,abs(day(DUEDATE)-day(@staticpooldate)) DAYSINCEDUEDATE
							--,(BALANCE/CREDITLIMIT) [UTILIZATION_RATE]
							,[ADVANCEAMOUNT]
							,b.LoanCategory1
							,b.LoanCategory2
							,b.LoanCategory3
							,b.LoanCategory4
							,b.LoanCategory5
							,b.LoanTypeDescription
							,CRPMTCURRENT
							,CHARGEOFFAMOUNT
							,PAYMENTSKIPS
					  from 
					 (
						 select * 
						 ,datefromparts(left(ProcessDate ,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) Process_Date
						 ,cast(OPENDATE as date) Open_date
						 ,cast(CLOSEDATE as date) Close_date,cast(MATURITYDATE as date) as MATURITY_DATE ,
						 case when isnumeric(TRY_CAST(USERCHAR3 AS INT))=1 then USERCHAR3 else 0  end FICO_Staticpool
						 from ARCUSYM000.dbo.LOAN 
				     ) a
			
					left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
					on b.loantype=a.TYPE
					left join 
					#NAME d
					on a.PARENTACCOUNT=d.PARENTACCOUNT
					--left join  #Static_SSN_account d
					--on a.PARENTACCOUNT=d.AccountNumber
					where  ORIGINALDATE is not null 
					and a.OpenDate is not null and a.Open_date < @staticpooldate  
					and (a.CLOSEDATE is null or a.Close_date>@staticpooldate )   
					and process_date /*= @staticpooldate*/between (select EOMONTH(dateadd(MM,-12,@staticpooldate))) and (select EOMONTH(dateadd(MM,12,@staticpooldate))) 
					--and  PARENTACCOUNT in (select distinct AccountNumber PARENTACCOUNT from #Static_SSN_account )
		) AA
		where		LoanCategory3 not in ('Writeoff','Workout/TDR')
				    and LoanCategory4 not in ('Writeoff','Workout/TDR')
					and OPEN_DATE<@staticpooldate
					and (Close_date is null or Close_date>@staticpooldate) 
					and ORIGINALDATE <= Open_date 
					and Quarters is not null

--ssn and loan balance as on staticpool 
	DROP TABLE IF EXISTS #LOANBALANCE
	SELECT SSN,SUM(CASE WHEN Quarters='Staticpool' THEN BALANCE END ) LOANBALANCE  
	INTO #LOANBALANCE 
	FROM #membership_loan
	GROUP BY SSN

--ssn and deposit  balance as on staticpool 
--DECLARE @staticpooldate date
--		 set  @staticpooldate= (Select case when Processdate=eomonth(Processdate) then Processdate else eomonth(dateadd(month,-1,Processdate)) end Processdate from
--		(select datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Processdate from
--				(select max(processdate) Processdate from ARCUSYM000.dbo.savings) A
--		) B)


	drop table if exists #Deposit_balance
	sELECT b.SSN,Sum(a.BALANCE) Deposit_balance--,datefromparts(left(a.ProcessDate ,4),right(left(a.ProcessDate,6),2),right(a.ProcessDate,2)) Process_date 
	into #Deposit_balance
	from ARCUSYM000.dbo.SAVINGS a
	left join ARCUSYM000..name b 
	on a.PARENTACCOUNT=b.PARENTACCOUNT
	and a.ProcessDate=b.ProcessDate
	where b.ssn in (select distinct ssn from #LOANBALANCE)
	and datefromparts(left(a.ProcessDate ,4),right(left(a.ProcessDate,6),2),right(a.ProcessDate,2)) = @staticpooldate
	group by SSN

--select * from #Deposit_balance

		DROP TABLE IF EXISTS #loan_woCC

		SELECT DISTINCT SSN
		INTO #loan_woCC
		FROM #membership_loan



-----------Deposit balance---------===================================

		
-----Creating max interset loan q1
	
	DROP TABLE IF EXISTS #interestrate

	SELECT SSN
	,MAX(CASE WHEN Quarters = 'Q1' THEN INTERESTRATE END) [MAX_INTERESTRATE_Loan_Q1]	
	into #interestrate
	from #membership_loan
	group by SSN

	 DROP TABLE IF EXISTS #static_unid
	SELECT DISTINCT UNID,PARENTACCOUNT,Product_Flag 
	into #static_unid 
	FROM #membership_loan

	--select * from #interestrate


	---------------------------
	
 --for creating DFT_COUNT_LOAN_ADDON_H1_H2

--DECLARE @staticpooldate date
--		 set  @staticpooldate= (Select case when Processdate=eomonth(Processdate) then Processdate else eomonth(dateadd(month,-1,Processdate)) end Processdate from
--		(select datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Processdate from
--				(select max(processdate) Processdate from ARCUSYM000.dbo.savings) A
--		) B)

--		declare @staticcreditdate date
--		 set  @staticcreditdate= (select max(cast(fullExtractdate as date)) Date from TMGData.dbo.cardholder)
--		--SELECT @staticcreditdate
	
			DROP TABLE IF EXISTS #temp_loan_transaction
			SELECT X.SSN,bb.*,Product_Flag 
			into #temp_loan_transaction
		from 
		(

		select unid,PARENTACCOUNT
		,case when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(dateadd(month,-10,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-11,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-12,@staticpooldate)),112),6))) then 'Q4'
		when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(dateadd(month,-7,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-8,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-9,@staticpooldate)),112),6))) then 'Q3'
		when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(dateadd(month,-4,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-5,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-6,@staticpooldate)),112),6))) then 'Q2'
		when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(dateadd(month,-3,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-2,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(dateadd(month,-1,@staticpooldate)),112),6))) then 'Q1'
		when EFFECTIVEDATE_v1 in (left(convert(varchar,@staticpooldate,112),6)) then 'Staticpool' end Quarters
		,case when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(DATEADD(month,-12,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-11,@staticpooldate)),112),6)),(left(convert(varchar,DATEADD(month,-10,@staticpooldate),112),6))
			                            ,(left(convert(varchar,EOMONTH(DATEADD(month,-9,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-8,@staticpooldate)),112),6)),(left(convert(varchar,DATEADD(month,-7,@staticpooldate),112),6))) then 'H2'
 		    	when EFFECTIVEDATE_v1 in ((left(convert(varchar,EOMONTH(DATEADD(month,-6,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-5,@staticpooldate)),112),6)),(left(convert(varchar,DATEADD(month,-4,@staticpooldate),112),6))
				                        ,(left(convert(varchar,EOMONTH(DATEADD(month,-3,@staticpooldate)),112),6)),(left(convert(varchar,EOMONTH((DATEADD(month,-2,@staticpooldate))),112),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-1,@staticpooldate)),112),6))) then 'H1'
		    end HalfYearly			
		,EFFECTIVEDATE_v1
		,ACTIONCODE,SOURCECODE
		,case when ACTIONCODE='A' then 1 else 0 end Loan_addon
		,case when ACTIONCODE='N' then 1 else 0 end New_loan
		,case when ACTIONCODE='N' then 1 else 0 end loan_payment
		,case when SOURCECODE='C' then 1 else 0 end CASH
		,case when SOURCECODE='D' then 1 else 0 end DRAFT
		,case when SOURCECODE='E' then 1 else 0 end ACH
		,case when SOURCECODE='F' then 1 else 0 end FEE
		,case when SOURCECODE='H' then 1 else 0 end HOMEBANKING
		,case when SOURCECODE='I' then 1 else 0 end INSURANCE
		,case when SOURCECODE='K' then 1 else 0 end CHECKS
		,case when SOURCECODE='P' then 1 else 0 end PAYROLL
		,case when SOURCECODE='S' then 1 else 0 end KIOSK
		,case when SOURCECODE='T' then 1 else 0 end  AUDIO_RESPONSE_TELEPHONE
		,CASE WHEN ACTIONCODE='A' AND SOURCECODE='C' THEN 'LOANADDON_CASH'
		WHEN ACTIONCODE='A' AND SOURCECODE='F' THEN 'LOANADDON_FEE'
		WHEN ACTIONCODE='A' AND SOURCECODE='H' THEN 'LOANADDON_HOMEBANKING'
		WHEN ACTIONCODE='A' AND SOURCECODE='I' THEN 'LOANADDON_INSURANCE'
		WHEN ACTIONCODE='A' AND SOURCECODE='K' THEN 'LOANADDON_CHECK'
		WHEN ACTIONCODE='A' AND SOURCECODE='T' THEN 'LOANADDON_RESPONSE_TELEPHONE'
		WHEN ACTIONCODE='A' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'LOANADDON'
		WHEN ACTIONCODE='N' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'NEWLOAN'
		WHEN ACTIONCODE='N' AND SOURCECODE='K' THEN 'NEWLOAN_CHECKS'
		WHEN ACTIONCODE='N' AND SOURCECODE='S' THEN 'NEWLOAN_KIOSK'
		WHEN ACTIONCODE='P' AND (SOURCECODE IS NULL OR SOURCECODE='') THEN 'LOANPAYMENT'
			
		WHEN ACTIONCODE='P' AND SOURCECODE='C' THEN 'LOANPAYMENT_CASH'
		WHEN ACTIONCODE='P' AND SOURCECODE='D' THEN 'LOANPAYMENT_DRAFT'
		WHEN ACTIONCODE='P' AND SOURCECODE='E' THEN 'LOANPAYMENT_ACH'
		WHEN ACTIONCODE='P' AND SOURCECODE='H' THEN 'LOANPAYMENT_HOMEBANKING'
		WHEN ACTIONCODE='P' AND SOURCECODE='K' THEN 'LOANPAYMENT_CHECKS'
		WHEN ACTIONCODE='P' AND SOURCECODE='P' THEN 'LOANPAYMENT_PAYROLL'
		WHEN ACTIONCODE='P' AND SOURCECODE='S' THEN 'LOANPAYMENT_KIOSK'
		WHEN ACTIONCODE='P' AND SOURCECODE='T' THEN  'LOANPAYMENT_RESPONSE_TELEPHONE' end action_source_code
		,BALANCECHANGE Transaction_amount,NEWBALANCE
		,INTEREST Interest_amount, FEEAMOUNT
		from	(

				select CONCAT(PARENTACCOUNT,PARENTID) UNID
				,PARENTACCOUNT,PARENTID
				,TRANSFERCODE
				,case when len(month(effectivedate))=1 then CONCAT(year(effectivedate),0,month(effectivedate))
				else CONCAT(year(effectivedate),month(effectivedate)) end EFFECTIVEDATE_v1
				,cast(EFFECTIVEDATE as date) EFFECTIVEDATE ,POSTDATE
				,ACTIONCODE,SOURCECODE,BALANCECHANGE,NEWBALANCE,INTEREST,FEEAMOUNT
				from [ARCUSYM000].dbo.LOANTRANSACTION
				where
				ACTIONCODE in ('A','N','P') AND SOURCECODE in ('C','D','E','F','H','I','K','P','S','T')
					and ACTIONCODE !='C' 
					) AA --where parentaccount=0014465465
			)bb
			left join #static_unid W
					on bb.UNID = W.UNID
					left join #NAME X
					on bb.PARENTACCOUNT = X.PARENTACCOUNT
			where bb.Quarters is not null 
			and bb.EFFECTIVEDATE_v1 between (Cast((left(convert(varchar,dateadd(month,-12,@staticpooldate),112),6)) as int)) 
			and cast((left(convert(varchar,@staticpooldate,112),6)) as int)
			

			--select * from #temp_loan_transaction
			 --group by PARENTACCOUNT
			 --,UNID
			 --,Quarters,action_source_code

    drop table if exists #LOAN_TRANSACTION_derived_vars

		SELECT  [SSN002],
		CASE WHEN ( COUNT_LOAN_ADDON_H1 IS NULL AND COUNT_LOAN_ADDON_H2 IS  NULL ) THEN COUNT_LOAN_ADDON_H1 
		else (ISNULL(COUNT_LOAN_ADDON_H1,0)-ISNULL(COUNT_LOAN_ADDON_H2,0)) end DFT_COUNT_LOAN_ADDON_H1_H2
		INTO #LOAN_TRANSACTION_derived_vars
		from
		(
		SELECT
		SSN [SSN002]
	,sum(CASE WHEN HalfYearly = 'H1' then Loan_addon END) COUNT_LOAN_ADDON_H1
	,sum(CASE WHEN HalfYearly = 'H2' then Loan_addon END) COUNT_LOAN_ADDON_H2
		from #temp_loan_transaction
		group by SSN
		) A
			
			--select * from #LOAN_TRANSACTION_derived_vars


			

----------------------------------------------------------Creating MortgageFlag_Cycle2_SP-----------------------------------------------------
 

DECLARE @staticpooldate2 date
		 set  @staticpooldate2= '2023-06-01'
----SELECT @staticpooldate2 
--		declare @staticcreditdate date
--		 set  @staticcreditdate= (select max(cast(fullExtractdate as date)) Date from TMGData.dbo.cardholder)
--		--SELECT @staticcreditdate

         DROP TABLE IF EXISTS #DELQ_INFO
		 SELECT *
		 INTO #DELQ_INFO
		 FROM
         (-- DECLARE @staticpooldate2 date
		--set @staticpooldate2 = '2022-06-30'
		 
		 SELECT SSN
		       ,AccountNumber
			   ,UNID
			   ,LoanDelqDays
			   ,Product_Flag
			   ,Processdate
 						   ,case when Processdate in ((EOMONTH(DATEADD(month,-12,@staticpooldate2))),(EOMONTH(DATEADD(month,-11,@staticpooldate2))),(EOMONTH(DATEADD(month,-10,@staticpooldate2 )))) then 'Q4'
		                         when Processdate in ((EOMONTH(DATEADD(month,-9,@staticpooldate2 ))),(EOMONTH(DATEADD(month,-8,@staticpooldate2))),(EOMONTH(DATEADD(month,-7,@staticpooldate2)))) then 'Q3'
 								 when Processdate in ((EOMONTH(DATEADD(month,-6,@staticpooldate2 ))),(EOMONTH(DATEADD(month,-5,@staticpooldate2))),(EOMONTH(DATEADD(month,-4,@staticpooldate2)))) then 'Q2'
								 when Processdate in ((EOMONTH(DATEADD(month,-3,@staticpooldate2))),(EOMONTH(DATEADD(month,-2,@staticpooldate2 ))),(EOMONTH(DATEADD(month,-1,@staticpooldate2 )))) then 'Q1'
								 when Processdate in (@staticpooldate2) then 'Staticpool'
							end Quarters
							,case when Processdate in (EOMONTH(DATEADD(month,-12,@staticpooldate2)),(EOMONTH(DATEADD(month,-11,@staticpooldate2))),(EOMONTH(DATEADD(month,-10,@staticpooldate2))) 
							                         ,(EOMONTH(DATEADD(month,-9,@staticpooldate2 ))),(EOMONTH(DATEADD(month,-8,@staticpooldate2))),(EOMONTH(DATEADD(month,-7,@staticpooldate2)))) then 'H2'
 								  when Processdate in (EOMONTH(DATEADD(month,-6,@staticpooldate2 )),(EOMONTH(DATEADD(month,-5,@staticpooldate2))),(EOMONTH(DATEADD(month,-4,@staticpooldate2)))
								                      ,(EOMONTH(DATEADD(month,-3,@staticpooldate2))),(EOMONTH(DATEADD(month,-2,@staticpooldate2 ))),(EOMONTH(DATEADD(month,-1,@staticpooldate2 )))) then 'H1'
							end HalfYearly

 						   ,case when Processdate in (EOMONTH(DATEADD(month,-12,@staticpooldate2))) then '12MonthBack'
						         when Processdate in (EOMONTH(DATEADD(month,-9,@staticpooldate2 ))) then '9MonthBack'
 								 when Processdate in (EOMONTH(DATEADD(month,-6,@staticpooldate2 ))) then '6MonthBack'
								 when Processdate in (EOMONTH(DATEADD(month,-3,@staticpooldate2))) then '3MonthBack' end MonthFlag
         
		 FROM
          (SELECT C.SSN
		         ,A.AccountNumber
				 ,B.Product_Flag
				 ,B.UNID
				 ,A.LoanDelqDays
				 ,datefromparts(left(A.ProcessDate,4),left(right(A.ProcessDate,4),2),right(A.ProcessDate,2)) Processdate			
 
		   FROM ARCUSYM000.ARCU.ARCULoanDetailed A
		   LEFT JOIN #static_unid B
		   ON A.AccountNumber = B.PARENTACCOUNT
		   LEFT JOIN #NAME C
		   ON A.AccountNumber = C.PARENTACCOUNT) P ) D
		   where D.Quarters is not null 
			 and Processdate between (select EOMONTH(dateadd(MM,-12,@staticpooldate2))) and (select EOMONTH(dateadd(MM,12,@staticpooldate2))) 

			--select * from #DELQ_INFO
			
			 DROP TABLE IF EXISTS #DELQ_MASTER
			 
			 SELECT *
			       , CASE WHEN ProductRealEstate_Cycle1_SP > 0 THEN 1 ELSE 0 END RealEstate_Cycle1Flag_SP
				   , CASE WHEN ProductRealEstate_Cycle2_SP > 0 THEN 1 ELSE 0 END RealEstate_Cycle2Flag_SP
				  
             INTO #DELQ_MASTER		                
			 FROM
			( SELECT SSN [SSN_DLQ]
			        ,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Staticpool' and LoanDelqDays between 1 and 29 then 1 else 0 end) ProductRealEstate_Cycle1_SP 
					,SUM( CASE WHEN Product_Flag = 'Real_Estate_loan' AND Quarters = 'Staticpool' and LoanDelqDays between 30 and 59 then 1 else 0 end) ProductRealEstate_Cycle2_SP 
			
			  --INTO #DELQ_MASTER		                
			  FROM #DELQ_INFO
			  GROUP BY SSN) P
			 -- select * from #DELQ_MASTER
/*********************************************************************** Harland Delinquency **************************************************************************/

		drop table if exists #static_harland

		 SELECT * 
					   into #static_harland 
					   from ( SELECT datefromparts(left(B.ProcessDate,4),right(left(B.ProcessDate,6),2),right(B.ProcessDate,2)) [Process date],B.USERCHAR1,SSN 
					         from (SELECT ProcessDate,USERCHAR1,PARENTACCOUNT FROM ARCUSYM000.dbo.TRACKING) B 
							        LEFT JOIN (SELECT DISTINCT PARENTACCOUNT,SSN FROM  ARCUSYM000..NAME) S
					    on B.PARENTACCOUNT=S.PARENTACCOUNT) f
						where [Process date] between eomonth(dateadd(month,-12,@staticpooldate2)) and @staticpooldate2 

						--select * from ae_edw.dbo.f_mortgage where year(reportmonth)>2022
						--select CutoffDate from [UICCU].[dbo].[HarlandLoanCutoff] order by 1 desc

--select * from #static_harland

	   drop table if exists #DELQ_harland

		Select distinct SSN [SSN_HARLAND]
		                ,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 1 and datediff(d, duedate, eomonth(cutoffdate)) < 30 and MonthFlag = 'SP' then 1 else 0  end)  [Cycle1_HarlandProduct_SP]
						,SUM(case when datediff(d, duedate, eomonth(cutoffdate)) >= 30 and datediff(d, duedate, eomonth(cutoffdate)) < 60 and MonthFlag = 'SP' then 1 else 0  end) [Cycle2_HarlandProduct_SP]
					
		into #DELQ_harland
		 from (
							SELECT SSN,h.loanid,InvestorID MortgageDescription,CutoffDate,h.DueDate
							,case when CutoffDate in (EOMONTH(DATEADD(month,-12,@staticpooldate2))) then '12MonthBack'
						          when CutoffDate in (EOMONTH(DATEADD(month,-9,@staticpooldate2 ))) then '9MonthBack'
 								  when CutoffDate in (EOMONTH(DATEADD(month,-6,@staticpooldate2 ))) then '6MonthBack'
								  when CutoffDate in (EOMONTH(DATEADD(month,-3,@staticpooldate2))) then '3MonthBack' 
								  when CutoffDate = @staticpooldate2 then 'SP' end MonthFlag

						FROM [UICCU].[dbo].[HarlandLoanCutoff] h
						left join ae_edw.dbo.f_mortgage f
						 on f.mortgageid = h.loanid and month(reportmonth) = month(cutoffdate)
						   and year(reportmonth) = year(cutoffdate)
                        left join 
					     #static_harland V
				       on h.LoanID=V.USERCHAR1 and h.CutoffDate = V.[Process date]
						WHERE loanprincipalbal > 0 AND RegPrincipalColl != investorprinbal AND (investorid LIKE '%bal' or investorid LIKE '%fix%' or investorid LIKE '%arm' or
													investorid LIKE 'E-10YR' or investorid LIKE 'E-WORK' or InvestorID like '%Equity%' or InvestorID like '%TDR%' or
													InvestorID = 'F-ARM' or InvestorID = 'FAB-HH' )
								   and investorprinbal is not null
								   and datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and RecordType <> 2
					) T 
					  where cutoffdate between eomonth(dateadd(month,-12,@staticpooldate2)) and @staticpooldate2 
				   group by SSN


	--select * from #DELQ_harland
	drop table if exists #flag
	SELECT SSN,case when Cycle2_Mortgage_SP > 0 then 1 else 0 end MortgageFlag_Cycle2_SP
	into #FLAG
	FROM
	( SELECT N.SSN,I.ProductRealEstate_Cycle2_SP,J.Cycle2_HarlandProduct_SP ,(I.ProductRealEstate_Cycle2_SP+J.Cycle2_HarlandProduct_SP) AS Cycle2_Mortgage_SP
	FROM #NAME N
	LEFT JOIN
	#DELQ_MASTER I
	ON N.SSN =I.SSN_DLQ
	left join 
	#DELQ_harland J
	on N.SSN = J.SSN_HARLAND) v

--	select * from #flag where MortgageFlag_Cycle2_SP>0

	--select distinct count(*),ssn from #FLAG
	--group by ssn		
				   					

------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------///*** Credit Card ***\\\-------------------------------------------------------------------
	
		--DECLARE @staticpooldate date
		-- set  @staticpooldate= (Select case when Processdate=eomonth(Processdate) then Processdate else eomonth(dateadd(month,-1,Processdate)) end Processdate from
		--(select datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Processdate from
		--		(select max(processdate) Processdate from ARCUSYM000.dbo.savings) A
		--) B)

		--declare @staticcreditdate date
		-- set  @staticcreditdate= (select max(cast(fullExtractdate as date)) Date from TMGData.dbo.cardholder)
		----SEL	
			
---For creating [RevolvingBalance_CC_Q1]
			 
  drop table if exists #CC_Members_Static
  

	  select distinct [Social Security Number] 
	  into #CC_Members_Static
	  from TMGData.dbo.cardholder 
	  where Active_Flag=1 and ([External Status Code]='' or [Internal Status Code] in ('N',''))
	  and extract_datepart=left(convert(varchar,@staticcreditdate,112),6)
	  --and datediff(MONTH,[Date First Active New],@staticcreditdate) >= 6   
	   

	drop table if exists #CC_data	
		
	select * 
	into #CC_data
	from 
	(
	SELECT  [Durable_Key]
	,case when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-12,@staticcreditdate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-11,@staticcreditdate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-10,@staticcreditdate)),112),6)) then 'Q4'
		when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-9,@staticcreditdate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-8,@staticcreditdate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-7,@staticcreditdate),112)),6)) then 'Q3'
		when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-6,@staticcreditdate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-5,@staticcreditdate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-4,@staticcreditdate),112)),6)) then 'Q2'
		when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-3,@staticcreditdate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-2,@staticcreditdate)),112),6),left(convert(varchar,EOMONTH(dateadd(month,-1,@staticcreditdate),112)),6)) then 'Q1'
		when extract_datepart in (left(convert(varchar,@staticcreditdate,112),6)) then 'Staticpool' end Quarters
		,case when extract_datepart in ((left(convert(varchar,EOMONTH(DATEADD(month,-12,@staticcreditdate)),112),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-11,@staticcreditdate),112)),6)),(left(convert(varchar,EOMONTH(DATEADD(month,-10,@staticcreditdate)),112),6))
			                            ,(left(convert(varchar,EOMONTH(DATEADD(month,-9,@staticcreditdate)),112),6)) ,(left(convert(varchar,EOMONTH(DATEADD(month,-8,@staticcreditdate),112)),6)) ,(left(convert(varchar,EOMONTH(DATEADD(month,-7,@staticcreditdate)),112),6))) then 'H2'
 		    	when extract_datepart in ((left(convert(varchar,EOMONTH(DATEADD(month,-6,@staticcreditdate)),112),6)) ,(left(convert(varchar,EOMONTH(DATEADD(month,-5,@staticcreditdate),112)),6)) ,(left(convert(varchar,EOMONTH(DATEADD(month,-4,@staticcreditdate)),112),6))
				                        ,(left(convert(varchar,EOMONTH(DATEADD(month,-3,@staticcreditdate)),112),6)) ,(left(convert(varchar,EOMONTH(DATEADD(month,-2,@staticcreditdate),112)),6)) ,(left(convert(varchar,EOMONTH(DATEADD(month,-1,@staticcreditdate)),112),6))) then 'H1'
		    end HalfYearly			

	,case when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-12,@staticcreditdate),112)),6)) then '12MonthBack'
		    when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-9,@staticcreditdate),112)),6)) then '9MonthBack'
		    when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-6,@staticcreditdate),112)),6)) then '6MonthBack'
		    when extract_datepart in (left(convert(varchar,EOMONTH(dateadd(month,-3,@staticcreditdate),112)),6)) then '3MonthBack' end MonthFlag
    ,[Social Security Number]
    ,[RevolvingBalance]
     
FROM TMGData.dbo.cardholder 	-- Changed 042222
where [Social Security Number] in (select [Social Security Number] from #CC_Members_Static)
and Active_Flag=1
) a
where  quarters is not null 
  ----and mob>=12  ---commented by nikita on 05/10/2022

--- Drift of CC data

		Drop table if exists #Credit_Card_data
	select 
	SSN_CC
		
	,[RevolvingBalance_CC_Q1]
	into #Credit_Card_data
	from 
	(
	select [Social Security Number] SSN_CC
	
		,SUM(case when Quarters='Q1' then [RevolvingBalance] END) [RevolvingBalance_CC_Q1]
	
			from #CC_data
			group by [Social Security Number]
			) a

			--select * from #Credit_Card_data

			  ---====================final data ====================================================

	--Fetching bureau data 
	
			  
DROP TABLE IF EXISTS #BUREAU_DATA
	SELECT * 
	INTO #BUREAU_DATA
	FROM
	 OPENQUERY([GSDWSQL01],'SELECT * FROM [BureauData].[dbo].[TransUnionAttributeHistory] WHERE DATE = ''202208''')

	 --select top 10 * from #BUREAU_DATA

drop table if exists #1 

Select Distinct a.PARENTACCOUNT,a.ssn,max(a.FICO_Staticpool) FICO_Staticpool,
max(b.MAX_INTERESTRATE_Loan_Q1) MAX_INTERESTRATE_Loan_Q1,max(c.DFT_COUNT_LOAN_ADDON_H1_H2) DFT_COUNT_LOAN_ADDON_H1_H2
,max(d.RevolvingBalance_CC_Q1) RevolvingBalance_CC_Q1,max(e.MortgageFlag_Cycle2_SP) MortgageFlag_Cycle2_SP,
max(f.opentradecount)opentradecount
into #1
from #membership_loan a 
left join #interestrate b 
on a.SSN=b.SSN
left join 
#LOAN_TRANSACTION_derived_vars c on
a.ssn=c.SSN002
left join 
#Credit_Card_data d
on a.SSN=d.SSN_CC
left join 
#BUREAU_DATA f
on a.SSN=f.ssn
left join 
#flag e
on a.ssn=e.SSN
group by a.PARENTACCOUNT,a.SSN

--=========================replacing null value ---------------------------------

	drop table if exists #2
	select PARENTACCOUNT,SSN,
	ISNULL(FICO_Staticpool,-9999999) FICO_Staticpool,
	ISNULL(MAX_INTERESTRATE_Loan_Q1,-9999999) MAX_INTERESTRATE_Loan_Q1,
	ISNULL(DFT_COUNT_LOAN_ADDON_H1_H2,-9999999) DFT_COUNT_LOAN_ADDON_H1_H2,
	ISNULL(RevolvingBalance_CC_Q1,-9999999) RevolvingBalance_CC_Q1,
	ISNULL(MortgageFlag_Cycle2_SP,-9999999) MortgageFlag_Cycle2_SP,
	ISNULL(opentradecount,-9999999) opentradecount
	into #2
	from #1


--select * from #2
--===================================================

-- Woe binnig 

 Drop table if exists #TEMPSTEP1
	 Select PARENTACCOUNT,SSN,
	 case when FICO_Staticpool  <= 656 then 97.3
	 when FICO_Staticpool <= 781 then -138.3
	 else -379.9 end as woe_Fico_Staticpool
	,case when MAX_INTERESTRATE_Loan_Q1 <= 4440 then -110.4
	 when MAX_INTERESTRATE_Loan_Q1 <= 8340  then 4.1
	 else  114.6 end as woe_MAX_INTERESTRATE_Loan_Q1
	,case when DFT_COUNT_LOAN_ADDON_H1_H2 <= -9999999  then -80.3
	 when DFT_COUNT_LOAN_ADDON_H1_H2 <= -1 then 71.2 
	 when DFT_COUNT_LOAN_ADDON_H1_H2 <= 0 then -24.5 
	 else 131.2
	 end as woe_DFT_COUNT_LOAN_ADDON_H1_H2
	,case when OpenTradeCount <= -9999999 then -48.7
	 when OpenTradeCount <= 2 then 90.4
	 when OpenTradeCount <= 5 then 24.2
	 else -25.0
	  end as woe_OpenTradeCount
	,case when RevolvingBalance_CC_Q1 <=1  then -37.2
	 when RevolvingBalance_CC_Q1 <=1  then -37.2
	 else 45.1 end as woe_RevolvingBalance_CC_Q1
	,case when MortgageFlag_Cycle2_SP <= -9999999 then -1.9
	 else 156.8   end as woe_MortgageFlag_Cycle2_SP
	 into #TEMPSTEP1
	from #1 

	 drop table if exists #tempstep2
	--equation---
	 Select *,-3.6083941 + (0.0093079 * woe_Fico_Staticpool)+(0.0051991 * woe_MAX_INTERESTRATE_Loan_Q1)
	  +(0.005565 * woe_DFT_COUNT_LOAN_ADDON_H1_H2)+(0.008918 * woe_OpenTradeCount)
	  +(0.0071832 * woe_RevolvingBalance_CC_Q1)+(0.0056309 * woe_MortgageFlag_Cycle2_SP)
	 X
	  into #tempstep2
	 from #TEMPSTEP1

--probability
	 drop table if exists #tempstep3
	 Select *,convert(decimal(10,5),EXP(X)/(1+EXP(X))) probability into #tempstep3 from #tempstep2
	--SELECT * FROM #tempstep3
	
	
/************* Traget Flag Creation  **************/
 		DECLARE @staticpooldate date
		set @staticpooldate = '2023-06-30'

		declare @staticcreditdate date
		set  @staticcreditdate = '2023-06-01'
/************* 1. CREDIT CARD  **************/

drop table if exists #temp1
select Durable_Key,[Credit Limit],mob,[Card Description],
	[Last Statement Balance Amount],RevolvingBalance,
	([Last Statement Sale Amount]-[Last Statement Return Amount]) as spend,
	TRIPFLAG,[Last Statement Payment Amount], Extract_DatePart as sp_month
    into #temp1
	FROM TMGData.[dbo].[cardholder]
	where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business')
	and [External Status Code] not in ('c','z')
	and Extract_DatePart = 202206 and mob > 11 and [card account delinquent day account]<60


drop table if exists #DelinquencyCycle
select Durable_Key ,[Social Security Number],
	sum(case when [Card Account Delinquent Day Account] >= 1 and [Card Account Delinquent Day Account] < 30 then 1 else 0 end) as Cycle1,
	sum(case when [Card Account Delinquent Day Account] >= 30 and [Card Account Delinquent Day Account] < 60 then 1 else 0 end) as Cycle2,
	sum(case when ([Card Account Delinquent Day Account] >=60 or chargeoffamount_final>0) then 1 else 0 end) as Cycle2plus
	into #DelinquencyCycle
	from TMGData.[dbo].[cardholder]
	where [Active_flag] = 1 and [Card Description] not in ('Mastercard Business')
	and Extract_DatePart between 202206 + 1 and 202212 
	and Durable_Key in 
	(select Durable_Key from #temp1)
	group by Durable_Key,[Social Security Number]


	--select * From #DelinquencyCycle

	
    drop table if exists #targetvarCC
	select distinct [Social Security Number] SSN
	into #targetvarCC from #DelinquencyCycle
	where Cycle2plus>=1  -- 1453

/************* 2. AUTO LOAN & PERSONAL LOAN  **************/

/********** A. Declaring SP **************/

   --DECLARE @staticpooldate DATE
   --SET @staticpooldate = '2022-06-30'

  --  (select datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Processdate from
		--(select (ProcessDate) processdate from ARCUSYM000..LOAN where ProcessDate = '2022-06-30') A)

/*********** B. Loan Static ************/

	drop table if exists #LoanStaticap
	select * 
	into #LoanStaticap
	from
	(
	select 
		[ProcessDate],[Process date],[Process_date],[PARENTACCOUNT],concat(PARENTACCOUNT,ID) UNID,
		LoanCategory2,LoanCategory3
	
		from
			(
			select *,CONCAT(PARENTACCOUNT,ID) UNID
			,case when opendate=closedate then 0 else 1 end Flag
			,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date or process_date=Charge_off_date 
			then 1 else 0 end Open_Flag
			,DATEDIFF(month,OPENDATE,@staticpooldate) MOB	
				from 
					(select *
					,case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
					else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
					,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
					else concat(year(opendate),month(opendate)) end Open_date
					,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
					else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
					,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
					,left(ProcessDate,6) Process_date
					from ARCUSYM000.dbo.LOAN
					--where (CHARGEOFFDATE>=@staticpooldate or CHARGEOFFDATE is null ) 
					) H
				where  ORIGINALDATE is not null and OpenDate is not null 
				and CLOSEDATE is null and CHARGEOFFDATE is null
				and [Process date]=@staticpooldate		-- Later give the @staticpooldate date here 
				and MATURITYDATE>@staticpooldate	-- add 3 month in currrent date
			) A
				left join [ARCUSYM000].[arcu].[ARCULoanCategory] b
				on b.loantype=a.TYPE
				where Flag=1 and Open_Flag=1 
				) D
				where (LoanCategory2 ='Vehicle' or LoanCategory2='Personal')
				order by PARENTACCOUNT,ProcessDate

/*********** C. Delinquency Cycles for AUTO LOAN *************/



		drop table if exists #TargetDELQ
		select AccountNumber Parentaccount,max(Chargoffflag) Chargoffflag,
		max(Target_Cycle1) Target_Cycle1,max(Target_Cycle2) Target_Cycle2,max(Target_Cycle3) Target_Cycle3
		into #TargetDELQ
		from
		( select 
		Convert(date, cast(l.Processdate as nvarchar)) as Date, l.ProcessDate,left(l.ProcessDate,6) Process_date,
		AccountNumber,LoanID,l.LoanOpenDate,LoanDelqDays,
		case when LoanDelqDays between 1 and 29 then 1 else 0 end Target_Cycle1 
		,case when LoanDelqDays between 30 and 59 then 1 else 0 end Target_Cycle2 
		,case when LoanDelqDays between 60 and 180 then 1 else 0 end Target_Cycle3 ,
		case when LoanChargeoffDate is not null then 1 else 0 end Chargoffflag
		,LoanPastDueAmount, LoanBalance,l.LoanChargeoffDate, l.LoanType,alc.LoanTypeDescription,
		Count(t.locator) as BankruptcyCount 
		from arcusym000.arcu.ARCULoanDetailed  as l
				left join arcusym000.arcu.ARCULoanCategory as alc on alc.LoanType = l.LoanType
				left join ARCUSYM000.dbo.tracking as t on t.processdate = l.ProcessDate and t.PARENTACCOUNT = l.AccountNumber 
				and t.TYPE = 36 
				and (t.EXPIREDATE is null or t.EXPIREDATE < Convert(date, cast(t.processdate as varchar)))
		where LoanDelqDays > 0 and concat(AccountNumber,loanid) in (select UNID from #LoanStaticap) 

		and l.processdate in (20220731,20220831,20220930,20221031,20221130,20221231) -- add the @staticpooldate + 3 month
		group by l.ProcessDate, l.AccountNumber,l.LoanID,l.LoanOpenDate,l.LoanPastDueAmount,l.LoanChargeoffDate, l.LoanType, alc.LoanTypeDescription, l.LoanDelqDays, LoanBalance
		) A
		group by AccountNumber
		order by AccountNumber		


		DROP TABLE IF EXISTS #TARGET_AUTOPER
		select distinct Parentaccount
		INTO #TARGET_AUTOPER
		 from #TargetDELQ
		where Target_Cycle3=1 or Chargoffflag =1 --4239

		DROP TABLE IF EXISTS #TARGET_AUTOPER_SSN
		select distinct A.Parentaccount,B.SSN
		INTO #TARGET_AUTOPER_SSN
		 from #TARGET_AUTOPER A
		 LEFT JOIN ARCUSYM000..NAME B
		 ON A.Parentaccount=B.PARENTACCOUNT  --4403


		
	--MOrtgage TF


	drop table if exists #Extractdate_mortgage
	select  Extractdate,max(AsOfDate) AsOfDate
	into #Extractdate_mortgage
	from (select case when len(month(AsOfDate))=1 then concat(year(AsOfDate),0,month(AsOfDate)) else concat(year(AsOfDate),month(AsOfDate)) end Extractdate,* 
	from AE_EDW..F_Mortgage_Daily) A
	where CoreMortgageStatus='Active' 
	group by Extractdate
	order by Extractdate


	--select * from #Extractdate_mortgage

	drop table if exists #Max_processdate_Mortgage
	select Process_Date,max(ProcessDate) ProcessDate
			into #Max_processdate_Mortgage 
			from
			(select parentaccount,(USERCHAR1) USERCHAR1,EXPIREDATE,ProcessDate,left(ProcessDate,6) Process_Date 
						from ARCUSYM000..TRACKING 
						group by parentaccount,USERCHAR1,EXPIREDATE,ProcessDate) A
						where Process_Date between 202106 and 202206
			group by Process_Date

	go
			drop table if exists #Tracking
			select parentaccount,ID,(USERCHAR1) USERCHAR1,EXPIREDATE,ProcessDate,left(ProcessDate,6) Process_Date 
			into #Tracking
			from ARCUSYM000..TRACKING where ProcessDate in (select ProcessDate from #Max_processdate_Mortgage)
			group by parentaccount,ID,USERCHAR1,EXPIREDATE,ProcessDate

			--select USERCHAR1 from  #Tracking
	go
			-- Harland loans 

			drop table if exists #Mortgage1
			select  b.parentaccount,
			a.*,case when Extractdate=Opendate then 1 else 0 end New_flag
			into #Mortgage1
			from (select case when len(month(AsOfDate))=1 then concat(year(AsOfDate),0,month(AsOfDate)) else concat(year(AsOfDate),month(AsOfDate)) end Extractdate
					,case when len(month(MortgageOpenDate))=1 then concat(year(MortgageOpenDate),0,month(MortgageOpenDate)) else concat(year(MortgageOpenDate),month(MortgageOpenDate)) end Opendate
					,* from AE_EDW..F_Mortgage_Daily) A
			left join #Tracking b
			on a.mortgageid=b.USERCHAR1 and a.Extractdate=b.Process_Date	
			where CoreMortgageStatus='Active' and AsOfDate='2022-06-30' 
			and AsOfDate in (select AsOfDate from #Extractdate_mortgage) and b.EXPIREDATE is null and MortgageDueDate>'2022-06-30'  
			and CurrentBalance>0
			go

			--select * from AE_EDW..F_Mortgage_Daily

			Drop table if exists #Del_accounts
			select * 
			into #Del_accounts
			from 		(select h.*,Case when len(MONTH(CutoffDate)) = 1 then CONCAT(YEAR(cutoffdate),0,month(cutoffdate))
							else CONCAT(YEAR(cutoffdate),month(cutoffdate)) end as extract_date
						,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 1  then 1 else 0 end DQ_Flag
						FROM [UICCU].[dbo].[HarlandLoanCutoff] h
							left join ae_edw.dbo.f_mortgage f on f.mortgageid = h.loanid and month(reportmonth) = month(cutoffdate)
															and year(reportmonth) = year(cutoffdate)
							WHERE loanprincipalbal > 0 AND RegPrincipalColl != investorprinbal AND (investorid LIKE '%bal' or investorid LIKE '%fix%' or investorid LIKE '%arm' or
														investorid LIKE 'E-10YR' or investorid LIKE 'E-WORK' or InvestorID like '%Equity%' or InvestorID like '%TDR%' or
														InvestorID = 'F-ARM' or InvestorID = 'FAB-HH' )
									   and investorprinbal is not null
									   and datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and RecordType <> 2
									   and mortgageid in (select mortgageid from #Mortgage1)
					) A where extract_date = 202206 and DQ_Flag=1
			go

		
			--select * from #Mortgage1

			--select * from [UICCU].[dbo].[HarlandLoanCutoff]

			drop table if exists #Mortgage
			select a.* into #Mortgage from #Mortgage1 a 
			left join #Del_accounts b on a.MortgageID=b.loanid where b.LoanID is null

				Drop table if exists #Processdate
			select 
			Process_date,max(ProcessDate) MAX_ProcessDate 
			into #Processdate
			from
				(
				select ProcessDate,left(ProcessDate,6) Process_date
				,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
				from ARCUSYM000..NAME group by ProcessDate
				) A 
				where [Process date] between dateadd(month,-12,'2022-06-30') and '2022-06-30'
				group by Process_Date
				order by Process_Date
	
		drop table if exists #Delinquency
			select processdate,Process_date,AccountNumber,LoanID,Cycle1 ,Cycle2 ,Cycle2plus 
			into #Delinquency
			from
			 (
					 select 
					Convert(date, cast(l.Processdate as nvarchar)) as Date, l.ProcessDate,left(l.ProcessDate,6) Process_date,
					AccountNumber,LoanID,l.LoanOpenDate,LoanDelqDays,
					case when LoanDelqDays between 1 and 29 then 1 else 0 end Cycle1 
					,case when LoanDelqDays between 30 and 59 then 1 else 0 end Cycle2 
					,case when LoanDelqDays >=60 or LoanChargeoffDate is not null  then 1 else 0 end Cycle2plus 
			
					from arcusym000.arcu.ARCULoanDetailed  as l
							left join arcusym000.arcu.ARCULoanCategory as alc on alc.LoanType = l.LoanType
							left join ARCUSYM000.dbo.tracking as t on t.processdate = l.ProcessDate and t.PARENTACCOUNT = l.AccountNumber 
							and t.TYPE = 36 and (t.EXPIREDATE is null or t.EXPIREDATE < Convert(date, cast(t.processdate as varchar)))
							left join [ARCUSYM000].[arcu].[ARCULoanCategory] V on l.LoanType=v.LoanType
					where LoanDelqDays > 0 
					and
					( v.LoanCategory2='Real Estate'
					or v.LoanCategory3='2nd Mortgage'
					or v.LoanCategory4 like '%HEL%')
					and l.processdate in (select MAX_ProcessDate from #processdate)
					and l.AccountNumber in (select PARENTACCOUNT from #Mortgage group by PARENTACCOUNT)
					group by l.ProcessDate,l.AccountNumber,l.LoanID,l.LoanOpenDate,l.LoanPastDueAmount,l.LoanChargeoffDate
					,l.LoanType, l.LoanDelqDays
			) A
			order by AccountNumber,LoanID,ProcessDate



		
			go
			Drop table if exists #Delinquency_hardland
			select PARENTACCOUNT,[DQ 1+ Days Flag],[DQ 30+ Days Flag],[DQ 60+ Days Flag],DQ_Flag
						into #Delinquency_hardland
						from 		(select m.PARENTACCOUNT,h.*,Case when len(MONTH(CutoffDate)) = 1 then CONCAT(YEAR(cutoffdate),0,month(cutoffdate))
										else CONCAT(YEAR(cutoffdate),month(cutoffdate)) end as extract_date
									,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 1  then 1 else 0 end DQ_Flag
									,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and datediff(d, h.duedate, eomonth(cutoffdate)) < 30 then 1 else 0  end [DQ 1+ Days Flag]
								,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 30 and datediff(d, h.duedate, eomonth(cutoffdate)) < 60 then 1 else 0  end [DQ 30+ Days Flag]
								,case when datediff(d, h.duedate, eomonth(cutoffdate)) >= 60 and datediff(d, h.duedate, eomonth(cutoffdate)) < 90 then 1 else 0  end [DQ 60+ Days Flag]
									FROM [UICCU].[dbo].[HarlandLoanCutoff] h
										left join (select MortgageID,parentaccount from #Mortgage) m on h.LoanID=m.MortgageID
										WHERE loanprincipalbal > 0 AND RegPrincipalColl != investorprinbal AND (investorid LIKE '%bal' or investorid LIKE '%fix%' or investorid LIKE '%arm' or
																	investorid LIKE 'E-10YR' or investorid LIKE 'E-WORK' or InvestorID like '%Equity%' or InvestorID like '%TDR%' or
																	InvestorID = 'F-ARM' or InvestorID = 'FAB-HH' )
												   and investorprinbal is not null
												   and datediff(d, h.duedate, eomonth(cutoffdate)) >= 1 and RecordType <> 2
												   and m.mortgageid is not null
								) A 
					where extract_date in (select process_date from #Processdate) and DQ_Flag=1
			group by PARENTACCOUNT,[DQ 1+ Days Flag],[DQ 30+ Days Flag],[DQ 60+ Days Flag],DQ_Flag
		
			drop table if exists #risk_mortgage
			select distinct PARENTACCOUNT
			into #risk_mortgage
			 from
			(select AccountNumber PARENTACCOUNT from #Delinquency where Cycle2plus=1
			union 
			select PARENTACCOUNT from #Delinquency_hardland where [DQ 60+ Days Flag]=1) P



			--select * from #risk_mortgage
       /******* TAKING SSN FROM RISK *******/
		drop table if exists #risk_mortgage_ssn

		SELECT DISTINCT SSN
		INTO #risk_mortgage_ssn
		 FROM #risk_mortgage E
		LEFT JOIN ARCUSYM000..NAME F
		ON E.PARENTACCOUNT = F.PARENTACCOUNT


		 /******* COMBINING ALL TARGET FLAGS *******/

		 DROP TABLE IF EXISTS #TARGET_SSN

		 SELECT DISTINCT SSN 
		 INTO #TARGET_SSN
		 FROM
		 ( SELECT * FROM #targetvarCC
		 UNION
		 SELECT SSN FROM #TARGET_AUTOPER_SSN
		 UNION
		 SELECT DISTINCT SSN FROM #risk_mortgage_ssn) T 	
	
	
	SELECT DISTINCT A.SSN,A.probability 
	, CASE WHEN A.SSN = B.SSN THEN 1 ELSE 0 END Risk_Target
	FROM #tempstep3 A
	LEFT JOIN #TARGET_SSN B
	ON A.SSN = B.SSN
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	Drop table if exists Analytics.dbo.SN_Risk_Validation_Jun23
	--Drop table if exists #tempstep4
	 Select *,rank() over (order by probability Asc) Ranking 
	 into Analytics.dbo.SN_Risk_Validation_Jun23
	 --into #tempstep4 
	 from #tempstep3 

	 DROP TABLE IF EXISTS #TEMPSTEP5
	 Select  
	 avg(Probability) average,stDev(Probability) SD
	 ,max(Probability) max1,MIN(probability) min1,max(ranking) max_rank
	into #tempstep5
	 from #tempstep4

	 Drop table if exists #Final_static_SSN_mapping
	select  SSN,First,Last,Street,City,State,Zipcode,Birthdate 
	into #Final_static_SSN_mapping
	from ARCUSYM000.dbo.NAME
	where SSN in (select ssn from #membership_loan)
	group by SSN,First,Last,Street,City,State,Zipcode,Birthdate

	 Drop table if exists #Final_static_SSN_mapping_v
	 select SSN,first,Last,Street,City,State,Zipcode,cast(BIRTHDATE as date) BIRTHDATE 
	 into #Final_static_SSN_mapping_v
	 from #Final_static_SSN_mapping
		  Group by SSN,first,Last,Street,City,State,Zipcode,BIRTHDATE 

--=================================================


select * from #1 where MortgageFlag_Cycle2_SP>0

select  distinct * from #membership_loan where FICO_Staticpool is null

--======================================testing 


--select * from ARCUSYM000..loan 
--where PARENTACCOUNT='0193810783'

--select * from ARCUSYM000..NAME 
--where PARENTACCOUNT='0193810783'


--select * from #1

-------------------------------------------------woe 




----------==========================================================to do tomorrow --======================================================

--1.balances  

	--DECLARE @staticpooldate date
	--	 set  @staticpooldate= (Select case when Processdate=eomonth(Processdate) then Processdate else eomonth(dateadd(month,-1,Processdate)) end Processdate from
	--	(select datefromparts(left(ProcessDate,4),left(right(ProcessDate,4),2),right(ProcessDate,2)) Processdate from
	--			(select max(processdate) Processdate from ARCUSYM000.dbo.savings) A
	--	) B)

	--	declare @staticcreditdate date
	--	 set  @staticcreditdate= (select max(cast(fullExtractdate as date)) Date from TMGData.dbo.cardholder)
	--	--SELECT @staticcreditdate

 
 
-----------------------------
--////************** Unemployment
				Drop table if exists #Unemployment
				select 
				a.PARENTACCOUNT,1 Unemployment_Flag,sum(BALANCECHANGE) Total_Amount_Benefit,count(distinct a.EFFECTIVE_DATE) [Benefit received months],count(*) [# times benefit received]
				into #Unemployment
				from 
				(
				select PARENTACCOUNT,PARENTID,EFFECTIVEDATE,SEQUENCENUMBER-1 as SEQUENCENUMBER,COMMENT
				, case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE)) 
				else  CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVE_DATE from ARCUSYM000.dbo.SAVINGSTRANSACTION
				where COMMENT like '%TYPE: UNEMPLOYME  CO: ST OF IA-UI PAY%' and EFFECTIVEDATE between dateadd(month,-6,@staticpooldate) and @staticpooldate
				) A 
				left join 
				(
				select PARENTACCOUNT,PARENTID,EFFECTIVEDATE,SEQUENCENUMBER,COMMENT,BALANCECHANGE
				, case when len(month(EFFECTIVEDATE))=1 then CONCAT(year(EFFECTIVEDATE),0,month(EFFECTIVEDATE)) 
				else  CONCAT(year(EFFECTIVEDATE),month(EFFECTIVEDATE)) end EFFECTIVE_DATE from ARCUSYM000.dbo.SAVINGSTRANSACTION
				where EFFECTIVEDATE between dateadd(month,-6,@staticpooldate) and @staticpooldate
				) b
				on a.PARENTACCOUNT=b.PARENTACCOUNT and a.PARENTID=b.PARENTID
				and a.EFFECTIVEDATE=b.EFFECTIVEDATE and a.SEQUENCENUMBER=b.SEQUENCENUMBER
				where a.PARENTACCOUNT in (select PARENTACCOUNT from #membership_loan) --#savings 
				group by a.PARENTACCOUNT


				--*********///////// Over Draft ******************
		Drop table if exists #Overdraft
		select PARENTACCOUNT,count(*) [# Overdraft], sum(abs(BALANCECHANGE)) [Overdraft Fee]
		into #Overdraft
		from ( select  * ,left(convert(int,convert(varchar(20),POSTDATE,112)),6) Date 
		from ARCUSYM000.dbo.SAVINGSTRANSACTION) A 
		where  POSTDATE between eomonth(dateadd(month,-6,@staticpooldate)) and @staticpooldate
		and DESCRIPTION like '%OD Privilege Fee%'
		group by PARENTACCOUNT


--***************/// LOC Flag
	 drop table if exists #LOC
	  select PARENTACCOUNT,avg(BALANCE) Avg_LOC_Balance,b.LOC
	  into #LOC
	  from		  
		(select * ,case when opendate=closedate then 0 else 1 end Flag
		,case when (closedate is null and CHARGEOFFDATE is null) or process_date=close_date 
		or process_date=Charge_off_date then 1 else 0 end Open_Flag
		from								
				( select a.* from 
						(select * ,
						case when len(month(CHARGEOFFDATE))=1 then concat(year(CHARGEOFFDATE),0,month(CHARGEOFFDATE))
						else concat(year(CHARGEOFFDATE),month(CHARGEOFFDATE)) end Charge_off_date
						,case when len(month(opendate))=1 then concat(year(opendate),0,month(opendate))
						else concat(year(opendate),month(opendate)) end Open_date
						,case when len(month(CLOSEDATE))=1 then concat(year(CLOSEDATE),0,month(CLOSEDATE))
						else concat(year(CLOSEDATE),month(CLOSEDATE)) end Close_date
						,datefromparts(left(ProcessDate,4),right(left(ProcessDate,6),2),right(ProcessDate,2)) [Process date]
						,left(ProcessDate,6) Process_date
						from ARCUSYM000.dbo.loan) A 
						left join #membership_loan b 
						on a.[Process date]=b.Process_Date and CONCAT(a.PARENTACCOUNT,a.ID)=b.UNID
				where b.BALANCE>0 and b.UNID is not null 
				) AA
				  where  ORIGINALDATE is not null and OpenDate is not null 
				  and aa.[Process Date] between dateadd(month,-6,@staticpooldate) and @staticpooldate
				  ) A 
		  left join					
		  (select *,
		  case when (LoanCategory4='LOC' or LoanCategory4 = 'HELOC') then 1 else 0 end LOC,
		case when LoanCategory2='Personal' and LoanCategory3='Unsecured' then 'Personal_Unsecured'
		when LoanCategory2='Personal' and LoanCategory3='Secured' then 'Personal_Secured'
		when LoanCategory4 like '%1st %' then 'Mortgage'
		when LoanCategory4 like '%HEL%' then 'HELOC'
		when LoanCategory4 in ('Piggyback Balloon','Workout/TDR','Writeoff') then 'Other RealEstate'
		when LoanCategory4='Vehicle' then 'Vehicle' else LoanCategory2 end Loan_category 
		from ARCUSYM000.arcu.ARCULoanCategory) b
		  on a.TYPE=b.LoanType
		  where  Flag=1 and Open_Flag=1 and b.loc=1
		  group by PARENTACCOUNT,b.LOC

		  ---final query

		  Drop table if exists #Final_loan_score_table
	Select a.*,isnull(b.AutoLoanScore,0) AutoLoanScore,isnull(c.PersonalLoanScore,0) PersonalLoanScore,
	isnull(d.CreditLoanScore,0) CreditLoanScore
	,isnull(e.MortgageLoanScore,0) MortgageLoanScore,isnull(f.Overdraft_flag,0) Overdraft_flag,
	isnull(g.Unemployment_Flag,0) Unemployment_Flag
	,isnull(h.LOC,0) LOC,i.LOANBALANCE,j.Deposit_balance
	into #Final_loan_score_table
	from
		(select distinct
		a.PARENTACCOUNT,a.[Final Score],b.*
			from 
				(Select PARENTACCOUNT,SSN
				,cast(((probability -min1)/(max1-min1)) as decimal(5,3)) [Final Score]
				FROM #tempstep4 
				left join #tempstep5 on 1=1
				) A
				left join (Select SSN,First,last,street,city,state,ZIPCODE,BIRTHDATE 
				from #Final_static_SSN_mapping_v) b on a.SSN=b.SSN
		) A 
		left join (Select SSN,Final_score AutoLoanScore from  analytics.dbo.PDQAutoloantriggerdata) B on a.SSN=B.SSN
		left join (Select SSN,Final_score PersonalLoanScore from  analytics.dbo.PDQtriggersPersonalloan) C on a.SSN=C.SSN
		left join (Select [Social security number] SSN,Final_score CreditLoanScore from  analytics.dbo.PDQTriggerCreditCardTargetListTable) D on a.SSN=D.SSN
		left join (select ssn,loanbalance from #LOANBALANCE)i on a.ssn=i.SSN
		left join (select ssn,Deposit_balance from #Deposit_balance)j on a.ssn=j.SSN
		left join (Select SSN,Final_score MortgageLoanScore from Analytics.dbo.MortgageloansTargetlist) E on a.SSN=E.SSN
		left join (Select *,1 Overdraft_flag from #Overdraft) F on a.PARENTACCOUNT=f.PARENTACCOUNT
		left join #Unemployment G on a.PARENTACCOUNT=G.PARENTACCOUNT
		left join #LOC H on a.PARENTACCOUNT=H.PARENTACCOUNT 
			order by [Final Score]

				--select * from #Final_loan_score_table
		
		Drop table if exists #Final_loan_score_table_1
		select  a.SSN,[Final Score],First,last,street,city,state,ZIPCODE,BIRTHDATE,
		isnull(AutoLoanScore,0)+isnull(CreditLoanScore,0)+isnull(PersonalLoanScore,0)
		+isnull(MortgageLoanScore,0) PDQScore,isnull(LOC,0)+isnull(Overdraft_flag,0)
		+isnull(Unemployment_Flag,0) [Supportive Trigger]
		,isnull(Deposit_balance,0)+isnull(LOANBALANCE,0) Overall_Balance
		into #Final_loan_score_table_1
		from #Final_loan_score_table a
		--left join 
		--#Deposit_balance b 
		--on a.SSN=b.SSN
		--left join 
		--#LOANBALANCE c
		--on a.SSN=b.SSN
		--group by a.SSN,[Final Score],First,last,street,city,state,ZIPCODE,BIRTHDATE,AutoLoanScore,CreditLoanScore,PersonalLoanScore,MortgageLoanScore,Overdraft_flag,LOC,Unemployment_Flag,LOANBALANCE,Deposit_balance

		
		Drop table if exists #Final_loan_score_table_2
		Select max(PDQScore) Max_PDQScore,min(PDQScore) Min_PDQScore,
		max([Supportive Trigger]) [Max Supportive Trigger],min([Supportive Trigger]) [Min Supportive Trigger]
		,max(Overall_Balance) Max_Overall_Balance,Min(Overall_Balance) Min_Overall_Balance
		into #Final_loan_score_table_2
		from #Final_loan_score_table_1 
		
		Drop table if exists #Final_loan_score_table_3
		Select SSN,First,last,street,city,state,ZIPCODE,BIRTHDATE
		,([Final Score]*60) +([Norm PDQ Score]*15)+([Norm Balance]*15)+([Norm Supportive Trigger]*10) Score
		
		into #Final_loan_score_table_3
		from
			(select A.SSN,a.[Final Score],First,last,street,city,state,ZIPCODE,BIRTHDATE
				
			,cast((a.Overall_Balance-Min_Overall_Balance)/(Max_Overall_Balance-Min_Overall_Balance) as decimal(5,3))  [Norm Balance]
			,cast(((a.PDQScore-Min_PDQScore)/cast((Max_PDQScore-Min_PDQScore) as decimal(5,2))) as decimal(5,3))  [Norm PDQ Score]
			,Cast((a.[Supportive Trigger] -[Min Supportive Trigger])/cast(([Max Supportive Trigger]-[Min Supportive Trigger]) as float)as decimal(5,3))  [Norm Supportive Trigger]
			from #Final_loan_score_table_1 A
			Left join #Final_loan_score_table_2 B on 1=1
			) A 

		-- Check the Multi Parentaccount Loan and deposit balance SSN 482961284

		Drop table if exists #memberriskfinaltable
		Select distinct SSN,First,last,street,city,state,ZIPCODE,BIRTHDATE,
		--sum(depo) [$ Deposit],max([$ Loan]) [$ Loan],
		max(Final_score) Final_score
		,Cast(getdate() as date) AsOfdate
		into #memberriskfinaltable
		from		
		(select SSN,First,last,street,city,state,ZIPCODE,BIRTHDATE
				,Cast(((Score-Min_Score)/(Max_Score-Min_Score)) As decimal(6,2))*100 Final_score
				--,[# Deposit],[# Loan],[$ Deposit],[$ Loan] 
				from #Final_loan_score_table_3 A 
				left join (select max(Score) Max_Score,min(Score) Min_Score 
				from #Final_loan_score_table_3) b 
				on 1=1
				) A
		group by SSN,First,last,street,city,state,ZIPCODE,BIRTHDATE

		--select * from #memberriskfinaltable order by Final_score desc

		---remove 

		
		 drop table if exists #tempremove_duplicates
		  select *
		  into #tempremove_duplicates
		   from 

		 (
		 select row_number() over (partition by SSN  order by LASTADDRCHGDATE desc ) as  row_num ,  *  
		 from arcusym000.dbo.name
		  where SSN in ( select distinct ssn from  #memberriskfinaltable) 
		  and processdate=(select max(ProcessDate) from arcusym000.dbo.name)
		  and type=0
		   ) as aa
		  where  row_num=1 
	


	drop table if exists  #Member_level_risk_score
			
		  select distinct a.[SSN]
      ,b.[First]
      ,b.[last]
      ,b.[street]
      ,b.[city]
      ,b.[state]
      ,b.[ZIPCODE]
      ,b.[BIRTHDATE]
          ,a.[Final_score]
      ,[AsOfdate]
	  into #Member_level_risk_score from  #memberriskfinaltable a
		  left join #tempremove_duplicates b
		  on a.ssn=b.ssn 

		--select count(*) from #Member_level_risk_score	order by Final_score desc		
				
		-- delete from #Member_level_risk_score where ssn is null

		-- select count(*) from Member_level_risk_score
		 

		 
		---additional request by Debra for Delinquency Status and Banruptcy Status
		

		--Main Loan table of SSN
		drop table if exists #Directory1
		select distinct parentaccount, format(cast(ssn as int),'000000000') SSN
		into #Directory1
		 from arcusym000.dbo.loanname 
		where ProcessDate in ( select max(processdate)  from arcusym000.dbo.loanname) 
	
	drop table if exists #Directory2
		select distinct parentaccount,  format(cast(ssn as int),'000000000') SSN
		into #Directory2
		 from arcusym000.dbo.name 
		where ProcessDate in ( select max(processdate)  from arcusym000.dbo.name) 
		and type=0
				
		drop table if exists #Directory
		select *
		into #Directory
		 from #Directory1
		union
		select * from #Directory2
	
		
		--Delinquency Status

		drop table if exists #current_delinquency
		select distinct  AccountNumber, Loanid , concat( AccountNumber,LoanId) UNID,LoanDelqDays
		into #current_delinquency from ARCUSYM000.arcu.arculoandetailed
		where ProcessDate in ( select max(processdate)  from ARCUSYM000.arcu.arculoandetailed)
		and LoanStatus='Open' and loanbalance<>0

	--Loan table del with parentaccount
		drop table if exists #Delinquency_productwise
		select    AccountNumber, 
		Max(cast(LoanDelqDays as Numeric)) DelinqunecyDays
		into #Delinquency_productwise
		from #current_delinquency 
		group by AccountNumber
		


		-- case when sum(cast(c.LoanDelqDays as Numeric))>0 then
		--'Delinquent'   when sum(cast(c.LoanDelqDays as Numeric))=0 then 'Not Delinquent'  
		--end Delinqunecy_Status
		

		 --Loan table del joined to ssn 
		 drop table  if exists #DelinquencyStatus
		 select ssn, DelinqunecyDays
		 into #DelinquencyStatus
		  from #Directory a
		  left join #Delinquency_productwise b 
		  on a.PARENTACCOUNT=b.AccountNumber
		  where b.DelinqunecyDays is not null

		  
		--Credit Cards Delinquency 

		 Drop table if exists #creditcarddelinquency2
		Select distinct format(cast([social security number] as int),'000000000') SSN ,
		Max(cast([Card Account Delinquent Day Account new] as Numeric)) DelinqunecyDays
		 into #creditcarddelinquency2
			 from
		  (select * 
		,case when pre_del>0 then pre_del-lead(date,1) over(partition by Durable_Key order by extract_datepart) 
		else [Card Account Delinquent Day Account] end [Card Account Delinquent Day Account new]
		,lead(date,1) over(partition by Durable_Key order by extract_datepart) pre_days
		from 
		(select *,day(eomonth(cast(fullExtractdate as date))) date
		,lead([Card Account Delinquent Day Account],1) over(partition by Durable_Key order by extract_datepart) pre_del
		from TMGData.dbo.cardholder where Active_Flag=1 and [External Status Code] not in ('C')
		and fullExtractdate in  (select max(fullExtractdate) fullExtractdate from TMGData.dbo.cardholder)
		) AB  ) A
			where fullExtractdate in  (select max(fullExtractdate) fullExtractdate from TMGData.dbo.cardholder)
			and active_flag = 1
			group by [Social Security Number]


		--	Union of CC and Loan delinquency
		drop table if exists  #FinalDelinquencyStatus
			 select * 
			 into #FinalDelinquencyStatus
			 from #DelinquencyStatus
			 union
			 select * from #creditcarddelinquency2

			 select * from #FinalDelinquencyStatus
			 where ssn is not null
		 
		 --one unique row after the union
		 drop table if exists #FinalDelDays_Uniquerow
		 select SSN , Max(cast(DelinqunecyDays as Numeric)) DelinqunecyDays
		 into #FinalDelDays_Uniquerow
		 from #FinalDelinquencyStatus
		 group by SSN


		 select * from #FinalDelDays_Uniquerow


		--Join Directory and Delinquency Status
		--final delinquency join to main table
	
	
		 drop table if exists #final
		select a.*, b.DelinqunecyDays
		into #Final
		from #Member_level_risk_score a
		left join #FinalDelDays_Uniquerow b
		on a.ssn=b.ssn

		---Creating final table 

		--Drop table if exists analytics.dbo.Member_Level_Risk_Score_v2
		--select * 
		--into analytics.dbo.Member_Level_Risk_Score_v2
		--from #final
END
		--select ssn ,count(*) from #Final 
		--  group by ssn 
		--having count(*)>1 -- order by Final_score desc




		--select count(*) from Member_level_risk_score  where DelinqunecyDays=0
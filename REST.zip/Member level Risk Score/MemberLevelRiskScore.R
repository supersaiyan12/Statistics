rm(list=ls())
library(RODBC)
library(odbc)
databaseConnection <- odbcDriverConnect("Driver={SQL Server};server=10.200.102.244;database=Analytics;uid=Curisesadamhuseni;pwd=Analyst@1990")
#databaseConnection <- odbcDriverConnect("Driver={SQL Server};server=ACARCU01;database=Analytics;trusted_connection=TRUE")
Direct_vehicle_Data <- RODBC::sqlQuery(databaseConnection, "select  *  from Analytics..MemberLevelRiskScore2")
Direct_vehicle_dataframe <- data.frame(Direct_vehicle_Data,stringsAsFactors=FALSE)

colnames.listofallvar <-colnames(Direct_vehicle_dataframe)
write.csv(colnames.listofallvar,"listofvairable.csv")

Direct_vehicle_dataframe1 <- Direct_vehicle_dataframe[,c(482,2,3,4,5,6,7,8,9,10,11,12,13,14,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,95,96,98,102,111,112,113,114,115,116,117,118,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,217,218,220,222,224,226,227,228,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,251,253,255,258,264,265,266,267,268,269,270,271,272,273,274,275,276,277,278,279,280,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,304,305,306,307,308,309,310,311,312,313,314,315,316,317,318,319,320,321,322,323,324,325,326,327,328,329,330,331,332,333,334,335,336,337,338,339,340,341,344,345,346,347,348,349,350,351,352,353,354,355,356,357,358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451,452,453,454,455,456,457,458,459,460,461,462,463,464,465,466,468,469,470,472,473,474,477,478,479,480,482)]
Direct_vehicle_dataframe1 <- replace(Direct_vehicle_dataframe1,is.na(Direct_vehicle_dataframe1),-99999999)
colnames.Direct_vehicle_dataframe1 <- colnames(Direct_vehicle_dataframe1)
write.csv(colnames.Direct_vehicle_dataframe1,"colnames.Direct_vehicle_dataframe1.csv")

sum(is.na(Direct_vehicle_dataframe1$target_variable_new))
Direct_vehicle_dataframe1$target_variable_new <- as.factor(Direct_vehicle_dataframe1$target_variable_new)


library(woeBinning)
binning <- woe.binning(Direct_vehicle_dataframe1,'target_variable_new',Direct_vehicle_dataframe1)
tabulate.binning <- woe.binning.table(binning)

WOEsumm <-data.matrix(tabulate.binning, rownames.force = NA)
write.csv(WOEsumm,"WOE&IV_Direct_vehicle.csv") 

Direct_vehicle_dataframe2 <- Direct_vehicle_dataframe1[,c(1,52,56,66,67,68,78,407,408,411,402,105,113,125,127,136,137,395,385,382,394,390,389,391,392,388,387,393,380,379,383,386,381,384,167,168,404,405,403,406,409,228,229,275,276,398,400,399,277,278,279,401,396,280,291,301,307,314,316,13,32)]
#colnames(Direct_vehicle_dataframe2)
Direct_vehicle_dataframe2$target_variable_new <- as.factor(Direct_vehicle_dataframe2$target_variable_new)

library(randomForest)
set.seed(2017)
RF <- randomForest(target_variable_new ~.,data = Direct_vehicle_dataframe2,ntree=100)
print(RF)
Important_vr <- importance(RF)
write.csv(Important_vr,"Imp_VR100_VehicleDirect.csv")
library(randomForestExplainer)
min_depth_frame <- min_depth_distribution(RF)
plot_min_depth_distribution(min_depth_frame)

importance_frame <- measure_importance(RF)
save(importance_frame, file = "importance_frame_Direct_vehicle.rda")
load("importance_frame_Direct_vehicle.rda")
importance_frame
write.csv(importance_frame,"Importance_frame_all_Direct_vehicle.csv")

Colnames.V_2<- colnames(Direct_vehicle_dataframe2)
write.csv(Colnames.V_2,"colnames.Direct_vehicle_dataframe2.csv")

Direct_vehicle_dataframe3<- Direct_vehicle_dataframe1[,c(1,52,56,66,67,68,78,407,408,411,402,105,113,125,127,136,137,395,385,382,394,390,389,391,392,388,387,393,380,379,383,386,381,384,167,168,404,405,403,406,409,228,229,275,276,398,400,399,277,278,279,401,396,280,291,301,307,314,316,13,32)]

Direct_vehicle_dataframe3$target_variable_new <- as.numeric(as.character(Direct_vehicle_dataframe3$target_variable_new))

require(caTools)
library(caTools)
set.seed(123)   #  set seed to ensure you always have same random numbers generated
sample = sample.split(Direct_vehicle_dataframe3,SplitRatio = 0.60) # splits the data in the ratio mentioned in SplitRatio. After splitting marks these rows as logical TRUE and the the remaining are marked as logical FALSE
train1 =subset(Direct_vehicle_dataframe3,sample ==TRUE) # creates a training dataset named train1 with rows which are marked as TRUE
test1=subset(Direct_vehicle_dataframe3, sample==FALSE)

write.csv(train1,"Train1.csv") 



library(woeBinning)

Binning.train <- woe.binning(train1,'target_variable_new',train1)
Training_dataset_woe <- woe.binning.deploy(train1, Binning.train, add.woe.or.dum.var = "woe")
colnames(Training_dataset_woe)
tabulate.binning.Train <- woe.binning.table(Binning.train)
WOEsumm <-data.matrix(tabulate.binning, rownames.force = NA)

library(My.stepwise)


my.variable.list <- c(#"woe.FICO_Staticpool.binned"
                      "woe.ACHAutopay_Flag_month_vehicle_staticpool.binned"
                      ,"woe.RevolvingBalance_CC_Staticpool.binned"
                      ,"woe.Avg_BALANCE_Checking_Q1.binned"
                      ,"woe.sum_Interest_amount_Vehicle_Q1.binned"
                      #,"woe.heloc_loan_flag.binned"
                     # ,"woe.Q1_FICO_Q3.binned"
                      ,"woe.Diff_Due_Payment_Vehicle_Staticpool.binned"
                      ,"woe.Sum_FEEAMOUNT_Vehicle_Q1.binned"
                      ,"woe.PARTIALPAYMENT_Vehicle_Staticpool.binned"
                      ,"woe.X..Deposit.Home.Banking_Savings_Q1.1.binned"
                      #,"woe.Transaction_COUNT_Savings_Q1.binned"
                      #,"woe.Deposited_amount_Savings_Q1.binned"
                      #,"woe.Deposited_count_Savings_Q1.binned"
                     ,"woe.AVG_BALANCECHANGE_Savings_Q1.binned"
                      )


My.stepwise.glm.results <- My.stepwise.glm(Y = "target_variable_new", my.variable.list, data = Training_dataset_woe, sle = 0.05,
                                           sls = 0.05, myfamily="binomial")

CSVdata <-Training_dataset_woe[c("target_variable_new","woe.Diff_Due_Payment_Vehicle_Staticpool.binned","woe.heloc_loan_flag.binned")]
#write.csv(CSVdata,"CSVdata.csv")

Training_dataset_woe$target_variable_new  <- as.numeric(as.character(Training_dataset_woe$target_variable_new))
GLM_Model <- glm(target_variable_new~ woe.FICO_Staticpool.binned
                   +woe.ACHAutopay_Flag_month_vehicle_staticpool.binned
                   +woe.RevolvingBalance_CC_Staticpool.binned
                   +woe.Avg_BALANCE_Checking_Q1.binned
                   +woe.sum_Interest_amount_Vehicle_Q1.binned
                   +woe.Sum_FEEAMOUNT_Vehicle_Q1.binned
                   +woe.Q1_FICO_Q3.binned
                 ,data = Training_dataset_woe,family = binomial)




summary(GLM_Model)
library(car)
library(carData)
Anova(GLM_Model, type="II", test="Wald")
vif(GLM_Model)
alias.result <- alias(GLM_Model)

fitted.results <- predict(GLM_Model,Training_dataset_woe,type='response')
score_train <- data.frame(Training_dataset_woe$target_variable_new,fitted.results)
write.csv(score_train,"score_train_MemberlevelNoFICO.csv")

library(gplots)
library(ROCR)
library(pROC)
pdata3 <- as.numeric(format(round(predict(GLM_Model,data = Training_dataset_woe,type='response',na.action = na.pass))))

fitpreds = predict(GLM_Model,Training_dataset_woe,type="response")
fitpred = prediction(fitpreds,Training_dataset_woe$target_variable_new)
fitperf = performance(fitpred,"tpr","fpr")
plot(fitperf,col="green",lwd=2,main="ROC Curve for Logistic:  Adult")
abline(a=0,b=1,lwd=2,lty=2,col="gray")
library(AUC)
auc(fitpreds,(Training_dataset_woe$target_variable_new))

predictions <- as.numeric(predict(GLM_Model, Training_dataset_woe, type = 'response'))
multiclass.roc(Training_dataset_woe$target_variable_new, predictions)


#************* TEST****************

library(woeBinning)
Binning.test <- woe.binning(test1,'target_variable_new',test1)
Test_dataset_woe <- woe.binning.deploy(test1, Binning.test, add.woe.or.dum.var = "woe")

fitted.test.results <- predict(GLM_Model,Test_dataset_woe,type='response')
score_test <- data.frame(Test_dataset_woe$target_variable_new,fitted.test.results)
write.csv(score_test,"score_test_Memberlevel.csv")

library(gplots)
library(ROCR)
library(pROC)
pdata3 <- as.numeric(format(round(predict(GLM_Model,data = Test_dataset_woe,type='response',na.action = na.pass))))

fitpreds = predict(GLM_Model,Test_dataset_woe,type="response")
fitpred = prediction(fitpreds,Test_dataset_woe$target_variable_new)
fitperf = performance(fitpred,"tpr","fpr")
plot(fitperf,col="green",lwd=2,main="ROC Curve for Logistic:  Adult")
abline(a=0,b=1,lwd=2,lty=2,col="gray")
library(AUC)
auc(fitpreds,(Test_dataset_woe$target_variable_new))

predictions <- as.numeric(predict(GLM_Model, Test_dataset_woe, type = 'response'))
multiclass.roc(Test_dataset_woe$target_variable_new, predictions)


#*************//// BINNING \\*********

library(woeBinning)
train2 <- train1[,c("target_variable_new","Max_Month_to_Maturity_Total_loan_ACCT","avg_Deposited_count_savings_Staticpool","sum_FEECOUNT1_checkings_Q4","AVG_withdrawal_amount_Total_Deposit_ACCT","SUM_Month_end_balance_Total_Deposit_ACCT","SUM_LASTDIVAMOUNT_Total_Deposit_ACCT"
)]

Binning.train2 <- woe.binning(train2,'target_variable_new',train2)
Training_dataset_woe2 <- woe.binning.deploy(train2, Binning.train, add.woe.or.dum.var = "woe")
colnames(Training_dataset_woe2)
tabulate.binning.Train2 <- woe.binning.table(Binning.train2)
WOEsumm2 <-data.matrix(tabulate.binning.Train2, rownames.force = NA)


#************* WOE binning For Visulisation ************

train3 <- train1[,c("target_variable_new","AVG_Month_end_balance_Total_Deposit_ACCT")]
cc <- data.frame()
library(woe)

for( i in 2)
{
  
  
  aa <- data.frame(colnames(train3)[i],woe(Data = train3,colnames(train3)[i],TRUE,"target_variable_new",10,Bad = 0,Good = 1))
  cc <- rbind(cc,aa)
}

write.csv(cc,file = "WOESummary_DV_model.csv") 


#*************** PRINCIPLE COMPONANT ANALYSIS
Direct_vehicle_train1 <- train1[,c(3:85)]

Direct_vehicle.PCA <- prcomp(Direct_vehicle_train1,center = TRUE,scale. = TRUE)
summary(Direct_vehicle.PCA)
str(Direct_vehicle.PCA)
Direct_vehivle_PC <- Direct_vehicle.PCA$x
print(Direct_vehivle_PC)
ss=as.data.frame(Direct_vehivle_PC)
write.csv(ss,"PCA.value.csv")
write.csv(train1,"Train1.value.csv")
class(ss)
names(Direct_vehicle.PCA)
Direct_vehicle.PCA$rotation
my.variable.list1 <- c("PC1","PC2","PC3","PC4","PC5","PC6")
library(My.stepwise)                     
My.stepwise.glm.results <- My.stepwise.glm(Y = train1$target_variable_new, ss[,1:6], data = ss, sle = 0.05,
                                           sls = 0.05, myfamily="binomial")

LM_model <- glm(train1$target_variable_new ~ Direct_vehivle_PC[,1:6])
summary(LM_model)

library(devtools)
install_github("vqv/ggbiplot")
library(ggbiplot)
ggbitplot(Direct_vehicle.PCA)

library(car)
library(carData)
Anova(LM_model, type="II", test="Wald")
vif(LM_model)
alias.result <- alias(LM_model)

fitted.results <- predict(LM_model,Direct_vehivle_PC,type='response')
score_train <- data.frame(Direct_vehivle_PC,fitted.results)
write.csv(score_train,"direct.vehicle.pca.csv")


#****************** Creating sample data for response 10%
NROW(train1) 
colnames(train1)
library(data.table)
train1.table  <- data.table(train1)
Train1.sample <- train1.table[-sample(which(train1$target_variable_new==0),66218)]
NROW(Train1.sample)
sum(Train1.sample$target_variable_new)


library(woeBinning)

Binning.train.sample <- woe.binning(Train1.sample,'target_variable_new',Train1.sample)
Training_dataset_woe.sample <- woe.binning.deploy(Train1.sample, Binning.train.sample, add.woe.or.dum.var = "woe")
colnames(Training_dataset_woe)
tabulate.binning.Train.sample <- woe.binning.table(Binning.train.sample)
WOEsumm <-data.matrix(tabulate.binning, rownames.force = NA)

library(My.stepwise)




my.variable.list.sample <- c("woe.AVG_withdrawal_amount_Total_Deposit_ACCT.binned"
                             ,"woe.AVG_Month_end_balance_Total_Deposit_ACCT.binned"
                             ,"woe.Max_Month_to_Maturity_Total_loan_ACCT.binned"
                             ,"woe.avg_Deposited_count_Checkings_Q1.binned"
                             ,"woe.MOB_Checkings.binned"
                             ,"woe.SUM_LASTDIVAMOUNT_Total_Deposit_ACCT.binned"
                             ,"woe.Avg_withdrawal_count_Checkings_Q4.binned"
                             ,"woe.sum_FEECOUNT1_checkings_Q4.binned")

my.variable.list.sample <- c("woe.AVG_withdrawal_amount_Total_Deposit_ACCT.binned"
                             ,"woe.SUM_Month_end_balance_Total_Deposit_ACCT.binned"
                             ,"woe.Max_Month_to_Maturity_Total_loan_ACCT.binned"
                             ,"woe.avg_Deposited_count_savings_Staticpool.binned"
                             ,"woe.sum_FEECOUNT1_checkings_Q4.binned"
                             ,"woe.Sum_LASTDIVAMOUNT_Checkings_Q1.binned"
                             ,"woe.MOB_Checkings.binned")


My.stepwise.glm.results <- My.stepwise.glm(Y = "target_variable_new", my.variable.list.sample, data = Training_dataset_woe.sample, sle = 0.05,
                                           sls = 0.05, myfamily="binomial")



GLM_Model.sample <- glm(target_variable_new~ woe.AVG_withdrawal_amount_Total_Deposit_ACCT.binned
                        + woe.AVG_Month_end_balance_Total_Deposit_ACCT.binned
                        + woe.Max_Month_to_Maturity_Total_loan_ACCT.binned
                        + woe.avg_Deposited_count_Checkings_Q1.binned
                        + woe.MOB_Checkings.binned
                        + woe.SUM_LASTDIVAMOUNT_Total_Deposit_ACCT.binned
                        + woe.Avg_withdrawal_count_Checkings_Q4.binned
                        + woe.sum_FEECOUNT1_checkings_Q4.binned
                        ,data = Training_dataset_woe.sample,family = "binomial")

summary(GLM_Model.sample)
library(car)
library(carData)
Anova(GLM_Model.sample, type="II", test="Wald")
vif(GLM_Model.sample)
alias.result <- alias(GLM_Model.sample)

fitted.results <- predict(GLM_Model.sample,Training_dataset_woe.sample,type='response')
score_train <- data.frame(Training_dataset_woe.sample,fitted.results)
write.csv(score_train,"score_train_Direct_vehicle_Sample_t1.csv")

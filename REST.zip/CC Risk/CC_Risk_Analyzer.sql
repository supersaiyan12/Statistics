
CREATE PROCEDURE dbo.CC_RiskAnalyzer
AS
BEGIN


DECLARE @date_cc AS VARCHAR(6) =(Select max(extract_datepart) from TMGData.dbo.cardholder)
DECLARE @DATE_CC_12M AS VARCHAR(6)=(SELECT CASE WHEN RIGHT(MAX(extract_datepart),2)<=11 THEN MAX(extract_datepart) - 99 ELSE MAX(extract_datepart) - 11 END AS DATE_12M
									FROM TMGData.dbo.cardholder )


DROP TABLE IF EXISTS #CC_Risk
SELECT *
INTO #CC_Risk
FROM TMGData.dbo.cardholder WITH (NOLOCK)
WHERE 1=1
	AND extract_datepart BETWEEN @DATE_CC_12M AND @date_cc
	AND [Social Security Number] IS NOT NULL 
	AND [Social Security Number]<>0
	AND Active_Flag = 1
	AND [External Status Code] in ('') 
	--AND [Internal Status Code] in ('','N')

--select extract_datepart
--	,count(*)
--from #CC_Risk
--group by extract_datepart
--order by 1 desc


DROP TABLE IF EXISTS #TrackingSubset
SELECT *
INTO #TrackingSubset
FROM arcusym000.tracking.tvwARCUTRACKINGCreditCard NOLOCK
WHERE 1=1
	AND LEFT(ProcessDate,6) >= @DATE_CC_12M
	AND DATEFROMPARTS(LEFT(PROCESSDATE,4),left(right(PROCESSDATE,4),2),right(PROCESSDATE,2)) = EOMONTH(DATEFROMPARTS(LEFT(PROCESSDATE,4),left(right(PROCESSDATE,4),2),right(PROCESSDATE,2)))



DROP TABLE IF EXISTS Analytics.dbo.CardApproval
SELECT LEFT(PROCESSDATE,6) AS extract_datepart
	,DATEFROMPARTS(LEFT(PROCESSDATE,4),left(right(PROCESSDATE,4),2),right(PROCESSDATE,2)) AS fullExtractdate
	,CardNumber_UserChar1 AS [Account Number]
	,SSN_USERCHAR3 AS [Social Security Number]
	,CASE WHEN MISCELLANEOUS3_USERCHAR13 = 'A' THEN 'Pre-approved'
		WHEN Miscellaneous3_UserChar13 = 'ACUX' THEN 'Pre-approved - CuneXus' 
		ELSE 'Underwriting' END AS Approval
INTO Analytics.dbo.CardApproval
FROM #TrackingSubset
WHERE 1=1
	AND LEFT(ProcessDate,6) BETWEEN @DATE_CC_12M AND @date_cc
	AND CardNumber_UserChar1 IN (SELECT [Account Number] FROM TMGData.dbo.cardholder WITH (NOLOCK)
									WHERE 1=1
										AND extract_datepart BETWEEN @DATE_CC_12M AND @date_cc
										AND [Social Security Number] IS NOT NULL 
										AND [Social Security Number]<>0
										AND Active_Flag = 1
										AND [External Status Code] in ('') )


--SELECT *
--FROM Analytics.dbo.CardApproval


--SELECT fullExtractdate
--	,Approval
--	,COUNT(*)
--FROM Analytics.dbo.CardApproval
--GROUP BY fullExtractdate
--	,Approval
--ORDER BY fullExtractdate
--	,Approval




--SELECT distinct [Card Account Delinquent Day Account]
--FROM #CC_Risk
--where extract_datepart = 202304
--ORDER BY 1 DESC


DROP TABLE IF EXISTS Analytics.dbo.Risk_KPIs
SELECT A.extract_datepart
	,fullExtractdate
	,Durable_Key
	,[Master Account Key]
	,A.[Account Number]
	,CONCAT(Durable_Key,[Master Account Key]) AS CONCAT_ID
	,A.[Social Security Number]
	,[Last Statement Balance Amount]
	,[Credit Limit]
	,[Last Statement Payment Amount]
	,TRIPFLAG
	,[Card Account Delinquent Day Account]
	,[Total Amount Account Delinquency]
	--,B.Approval
	,CASE WHEN [Card Account Delinquent Day Account] > 0 THEN 'Delq' ELSE 'Non-Delq' END AS Delq_Flag
	,CASE WHEN [Last Statement Payment Amount] <= (0.02*[Last Statement Balance Amount])
		AND [Last Statement Balance Amount] <> 0 
		AND [Last Statement Payment Amount] <> 0 THEN 'Min Payment' ELSE 'More than Min Due' END AS Min_Pymnt_Flag
	,CASE WHEN [Last Statement Balance Amount] = [Credit Limit] THEN 1 ELSE 0 END AS Max_Out_Flag
	,CASE WHEN [Last Statement Balance Amount] > [Credit Limit] THEN 1 ELSE 0 END AS Overlimit_Flag
	,CASE WHEN [Last Statement Balance Amount] = [Credit Limit] THEN 'Maxed Out'
		WHEN [Last Statement Balance Amount] > [Credit Limit] THEN 'Overlimit'
		ELSE 'Good' END AS Card_Util
	,([Last Statement Balance Amount]/[Credit Limit])*100 AS Utilization_Rate
	,CASE WHEN ([Last Statement Balance Amount]/[Credit Limit])*100 <= 20 THEN '0% - 20%'
		WHEN ([Last Statement Balance Amount]/[Credit Limit])*100 <= 40  THEN '20% - 40%'
		WHEN ([Last Statement Balance Amount]/[Credit Limit])*100 <= 50 THEN '40% - 50%'
		WHEN ([Last Statement Balance Amount]/[Credit Limit])*100 < 75 THEN '50% - 75%'
		WHEN ([Last Statement Balance Amount]/[Credit Limit])*100 >=75 THEN '>=75%'
		END AS Utilization
	,CASE WHEN ([Last Statement Balance Amount]/[Credit Limit])*100 <= 20 THEN 1
		WHEN ([Last Statement Balance Amount]/[Credit Limit])*100 <= 40  THEN 2
		WHEN ([Last Statement Balance Amount]/[Credit Limit])*100 <= 50 THEN 3
		WHEN ([Last Statement Balance Amount]/[Credit Limit])*100 < 75 THEN 4
		WHEN ([Last Statement Balance Amount]/[Credit Limit])*100 >=75 THEN 5
		END AS Utilization_Sort_Order
INTO Analytics.dbo.Risk_KPIs
FROM #CC_Risk A
--LEFT JOIN #TRACKING_SUBSET B
--	ON A.extract_datepart = B.extract_datepart
--	AND A.[Account Number] = B.[Account Number]
--	AND A.[Social Security Number] = B.[Social Security Number]
	 

--SELECT extract_datepart
--	,Card_Util
--	,COUNT(*)
--FROM Analytics.dbo.Risk_KPIs
--WHERE Card_Util != 'GOOD'
--GROUP BY extract_datepart
--	,Card_Util
--ORDER BY extract_datepart
--	,Card_Util

--SELECT Utilization
--	,count(*)
--FROM Analytics.dbo.Risk_KPIs
--WHERE 1=1
--	AND extract_datepart = 202303
--	--AND Min_Pymnt_Flag = 1
--group by Utilization


--SELECT *
--	,[Last Statement Balance Amount]/[Credit Limit]
--FROM Analytics.dbo.Risk_KPIs
--WHERE 1=1
--	AND extract_datepart = 202303


--SELECT extract_datepart
--	,Card_Util
--	,COUNT(*)
--FROM Analytics.dbo.Risk_KPIs
--WHERE 1=1
--	--AND extract_datepart = 202303
--	AND Min_Pymnt_Flag = 1
--	and Card_Util != 'Good'
--GROUP BY extract_datepart
--	,Card_Util
--ORDER BY extract_datepart
--	,Card_Util


--SELECT extract_datepart
--	,Min_Pymnt_Flag
--	,COUNT(*)
--FROM Analytics.dbo.Risk_KPIs
--WHERE 1=1
--	--AND extract_datepart = 202303
--	--AND Min_Pymnt_Flag = 1
--GROUP BY extract_datepart
--	,Min_Pymnt_Flag
--ORDER BY extract_datepart
--	,Min_Pymnt_Flag



--SELECT extract_datepart, Delq_Flag
--	,AVG(Utilization_Rate)
--FROM Analytics..Risk_KPIs
----WHERE Delq_Flag = 1
--GROUP BY extract_datepart, Delq_Flag
--ORDER BY extract_datepart, Delq_Flag


DROP TABLE IF EXISTS #CC_Risk_Months
SELECT *
INTO #CC_Risk_Months
FROM TMGData.dbo.cardholder WITH (NOLOCK)
WHERE 1=1
	--AND extract_datepart BETWEEN @DATE_CC_12M AND @date_cc
	AND [Social Security Number] IS NOT NULL 
	AND [Social Security Number]<>0
	AND Active_Flag = 1
	AND [External Status Code] in ('') 
	--AND [Internal Status Code] in ('','N')


DROP TABLE IF EXISTS #CC_Risk_Months_Flags
SELECT extract_datepart
	,fullExtractdate
	,Durable_Key
	,[Master Account Key]
	,[Account Number]
	,[Social Security Number]
	,[Last Statement Balance Amount]
	,[Credit Limit]
	,[Last Statement Payment Amount]
	,TRIPFLAG
	,[Card Account Delinquent Day Account]
	,([Last Statement Balance Amount]/[Credit Limit])*100 AS Utilization_Rate
	,CASE WHEN ([Last Statement Balance Amount]/[Credit Limit])*100 >= 75 THEN 1 ELSE 0 END AS Util75_Flag
	,CASE WHEN [Last Statement Balance Amount] = [Credit Limit] THEN 1 ELSE 0 END AS MaxedOut_Flag
	--,ROW_NUMBER() OVER (PARTITION BY Durable_Key, [Master Account Key] ORDER BY extract_datepart) AS ROW_NUM_MAXEDOUT
	,CASE WHEN [Last Statement Balance Amount] > [Credit Limit] THEN 1 ELSE 0 END AS Overlimit_Flag
	,ROW_NUMBER() OVER (PARTITION BY Durable_Key, [Master Account Key] ORDER BY extract_datepart) AS ROW_NUM_UTIL
	--,ROW_NUMBER() OVER (PARTITION BY Durable_Key, [Master Account Key] ORDER BY extract_datepart) AS ROW_NUM_OVERLIMIT
INTO #CC_Risk_Months_Flags
FROM #CC_Risk_Months
--ORDER BY [Social Security Number], extract_datepart


--SELECT extract_datepart
--	,fullExtractdate
--	,Durable_Key
--	,[Master Account Key]
--	,[Account Number]
--	,[Social Security Number]
--	,[Credit Limit]
--	,[Last Statement Balance Amount]
--	,[Last Statement Payment Amount]
--	,Util75_Flag
--	,ROW_NUM_UTIL
--	,MaxedOut_Flag
--	,Overlimit_Flag
--	,TRIPFLAG
--FROM #CC_Risk_Months_Flags
--WHERE [Social Security Number] = 100089530
--ORDER BY [Social Security Number], extract_datepart,Durable_Key
--	,[Master Account Key]

DROP TABLE IF EXISTS #CC_Risk_Months1
SELECT *
	,CASE WHEN Util75_Flag = 1 THEN ROW_NUM_UTIL ELSE 0 END AS Util75_Months
	,CASE WHEN MaxedOut_Flag = 1 THEN ROW_NUM_UTIL ELSE 0 END AS MaxedOut_Months
	,CASE WHEN Overlimit_Flag = 1 THEN ROW_NUM_UTIL ELSE 0 END AS Overlimit_Months
INTO #CC_Risk_Months1
FROM #CC_Risk_Months_Flags
WHERE Util75_Flag = 1
--ORDER BY [Social Security Number], extract_datepart

--select *
--from #CC_Risk_Months
--where Durable_Key = 15599543	
--and [Master Account Key] in (18337815,23109900,23961314)
--ORDER BY [Social Security Number], extract_datepart



DROP TABLE IF EXISTS ANALYTICS.DBO.CC_Risk_Util_Months
SELECT Durable_Key
	,[Master Account Key]
	,CONCAT(Durable_Key,[Master Account Key]) AS CONCAT_ID
	,SUM(Util75_Flag) AS Util75_TotalMonths
	--,ISNULL(MIN(CASE WHEN Util75_Flag > 0 THEN ROW_NUM_UTIL ELSE NULL END),0) AS Util75_Months
	,MIN(ROW_NUM_UTIL) Util75_Months
	,MIN(CASE WHEN MaxedOut_Flag > 0 THEN ROW_NUM_UTIL ELSE NULL END) AS MaxedOut_Months
	,MIN(CASE WHEN Overlimit_Flag > 0 THEN ROW_NUM_UTIL ELSE NULL END) AS Overlimit_Months
INTO ANALYTICS.DBO.CC_Risk_Util_Months
FROM #CC_Risk_Months1
GROUP BY Durable_Key
	,[Master Account Key]
	,CONCAT(Durable_Key,[Master Account Key])
--ORDER BY [Social Security Number], extract_datepart

--select *
--from ANALYTICS.DBO.CC_Risk_Util_Months
--where Durable_Key = 15599543	
--and [Master Account Key] in (18337815,23109900,23961314)

--SELECT AVG(Overlimit_Months)
--FROM ANALYTICS.DBO.CC_Risk_Util_Months



------- DELQ CARDS AVG UTIL MONTHS

DROP TABLE IF EXISTS #CC_Risk_Months_Flags_Delq
SELECT extract_datepart
	,fullExtractdate
	,Durable_Key
	,[Master Account Key]
	,[Account Number]
	,[Social Security Number]
	,[Last Statement Balance Amount]
	,[Credit Limit]
	,[Last Statement Payment Amount]
	,TRIPFLAG
	,[Card Account Delinquent Day Account]
	,([Last Statement Balance Amount]/[Credit Limit])*100 AS Utilization_Rate
	,CASE WHEN ([Last Statement Balance Amount]/[Credit Limit])*100 >= 75 THEN 1 ELSE 0 END AS Util75_Flag
	,CASE WHEN [Last Statement Balance Amount] = [Credit Limit] THEN 1 ELSE 0 END AS MaxedOut_Flag
	--,ROW_NUMBER() OVER (PARTITION BY Durable_Key, [Master Account Key] ORDER BY extract_datepart) AS ROW_NUM_MAXEDOUT
	,CASE WHEN [Last Statement Balance Amount] > [Credit Limit] THEN 1 ELSE 0 END AS Overlimit_Flag
	,ROW_NUMBER() OVER (PARTITION BY Durable_Key, [Master Account Key] ORDER BY extract_datepart) AS ROW_NUM_UTIL
	--,ROW_NUMBER() OVER (PARTITION BY Durable_Key, [Master Account Key] ORDER BY extract_datepart) AS ROW_NUM_OVERLIMIT
INTO #CC_Risk_Months_Flags_Delq
FROM #CC_Risk_Months
WHERE [Card Account Delinquent Day Account] > 0
--ORDER BY [Social Security Number], extract_datepart


--SELECT extract_datepart
--	,fullExtractdate
--	,Durable_Key
--	,[Master Account Key]
--	,[Account Number]
--	,[Social Security Number]
--	,[Credit Limit]
--	,[Last Statement Balance Amount]
--	,[Last Statement Payment Amount]
--	,Util75_Flag
--	,ROW_NUM_UTIL
--	,MaxedOut_Flag
--	,Overlimit_Flag
--	,TRIPFLAG
--FROM #CC_Risk_Months_Flags
--WHERE [Social Security Number] = 100089530
--ORDER BY [Social Security Number], extract_datepart,Durable_Key
--	,[Master Account Key]

DROP TABLE IF EXISTS #CC_Risk_Months1_Delq
SELECT *
	,CASE WHEN Util75_Flag = 1 THEN ROW_NUM_UTIL ELSE 0 END AS Util75_Months
	,CASE WHEN MaxedOut_Flag = 1 THEN ROW_NUM_UTIL ELSE 0 END AS MaxedOut_Months
	,CASE WHEN Overlimit_Flag = 1 THEN ROW_NUM_UTIL ELSE 0 END AS Overlimit_Months
INTO #CC_Risk_Months1_Delq
FROM #CC_Risk_Months_Flags_Delq
WHERE Util75_Flag = 1
--ORDER BY [Social Security Number], extract_datepart

--select *
--from #CC_Risk_Months
--where Durable_Key = 15599543	
--and [Master Account Key] in (18337815,23109900,23961314)
--ORDER BY [Social Security Number], extract_datepart



DROP TABLE IF EXISTS ANALYTICS.DBO.CC_Risk_Util_Months_Delq
SELECT Durable_Key
	,[Master Account Key]
	,CONCAT(Durable_Key,[Master Account Key]) AS CONCAT_ID
	,SUM(Util75_Flag) AS Util75_TotalMonths
	--,ISNULL(MIN(CASE WHEN Util75_Flag > 0 THEN ROW_NUM_UTIL ELSE NULL END),0) AS Util75_Months
	,MIN(ROW_NUM_UTIL) Util75_Months
	,MIN(CASE WHEN MaxedOut_Flag > 0 THEN ROW_NUM_UTIL ELSE NULL END) AS MaxedOut_Months
	,MIN(CASE WHEN Overlimit_Flag > 0 THEN ROW_NUM_UTIL ELSE NULL END) AS Overlimit_Months
INTO ANALYTICS.DBO.CC_Risk_Util_Months_Delq
FROM #CC_Risk_Months1_Delq
GROUP BY Durable_Key
	,[Master Account Key]
	,CONCAT(Durable_Key,[Master Account Key])
--ORDER BY [Social Security Number], extract_datepart

--select *
--from ANALYTICS.DBO.CC_Risk_Util_Months
--where Durable_Key = 15599543	
--and [Master Account Key] in (18337815,23109900,23961314)

--SELECT AVG(Overlimit_Months)
--FROM ANALYTICS.DBO.CC_Risk_Util_Months


-------NON DELQ CARDS AVG UTIL MONTHS

DROP TABLE IF EXISTS #CC_Risk_Months_Flags_NonDelq
SELECT extract_datepart
	,fullExtractdate
	,Durable_Key
	,[Master Account Key]
	,[Account Number]
	,[Social Security Number]
	,[Last Statement Balance Amount]
	,[Credit Limit]
	,[Last Statement Payment Amount]
	,TRIPFLAG
	,[Card Account Delinquent Day Account]
	,([Last Statement Balance Amount]/[Credit Limit])*100 AS Utilization_Rate
	,CASE WHEN ([Last Statement Balance Amount]/[Credit Limit])*100 >= 75 THEN 1 ELSE 0 END AS Util75_Flag
	,CASE WHEN [Last Statement Balance Amount] = [Credit Limit] THEN 1 ELSE 0 END AS MaxedOut_Flag
	--,ROW_NUMBER() OVER (PARTITION BY Durable_Key, [Master Account Key] ORDER BY extract_datepart) AS ROW_NUM_MAXEDOUT
	,CASE WHEN [Last Statement Balance Amount] > [Credit Limit] THEN 1 ELSE 0 END AS Overlimit_Flag
	,ROW_NUMBER() OVER (PARTITION BY Durable_Key, [Master Account Key] ORDER BY extract_datepart) AS ROW_NUM_UTIL
	--,ROW_NUMBER() OVER (PARTITION BY Durable_Key, [Master Account Key] ORDER BY extract_datepart) AS ROW_NUM_OVERLIMIT
INTO #CC_Risk_Months_Flags_NonDelq
FROM #CC_Risk_Months
WHERE [Card Account Delinquent Day Account] = 0
--ORDER BY [Social Security Number], extract_datepart


--SELECT extract_datepart
--	,fullExtractdate
--	,Durable_Key
--	,[Master Account Key]
--	,[Account Number]
--	,[Social Security Number]
--	,[Credit Limit]
--	,[Last Statement Balance Amount]
--	,[Last Statement Payment Amount]
--	,Util75_Flag
--	,ROW_NUM_UTIL
--	,MaxedOut_Flag
--	,Overlimit_Flag
--	,TRIPFLAG
--FROM #CC_Risk_Months_Flags
--WHERE [Social Security Number] = 100089530
--ORDER BY [Social Security Number], extract_datepart,Durable_Key
--	,[Master Account Key]

DROP TABLE IF EXISTS #CC_Risk_Months1_NonDelq
SELECT *
	,CASE WHEN Util75_Flag = 1 THEN ROW_NUM_UTIL ELSE 0 END AS Util75_Months
	,CASE WHEN MaxedOut_Flag = 1 THEN ROW_NUM_UTIL ELSE 0 END AS MaxedOut_Months
	,CASE WHEN Overlimit_Flag = 1 THEN ROW_NUM_UTIL ELSE 0 END AS Overlimit_Months
INTO #CC_Risk_Months1_NonDelq
FROM #CC_Risk_Months_Flags_NonDelq
WHERE Util75_Flag = 1
--ORDER BY [Social Security Number], extract_datepart

--select *
--from #CC_Risk_Months
--where Durable_Key = 15599543	
--and [Master Account Key] in (18337815,23109900,23961314)
--ORDER BY [Social Security Number], extract_datepart



DROP TABLE IF EXISTS ANALYTICS.DBO.CC_Risk_Util_Months_NonDelq
SELECT Durable_Key
	,[Master Account Key]
	,CONCAT(Durable_Key,[Master Account Key]) AS CONCAT_ID
	,SUM(Util75_Flag) AS Util75_TotalMonths
	--,ISNULL(MIN(CASE WHEN Util75_Flag > 0 THEN ROW_NUM_UTIL ELSE NULL END),0) AS Util75_Months
	,MIN(ROW_NUM_UTIL) Util75_Months
	,MIN(CASE WHEN MaxedOut_Flag > 0 THEN ROW_NUM_UTIL ELSE NULL END) AS MaxedOut_Months
	,MIN(CASE WHEN Overlimit_Flag > 0 THEN ROW_NUM_UTIL ELSE NULL END) AS Overlimit_Months
INTO ANALYTICS.DBO.CC_Risk_Util_Months_NonDelq
FROM #CC_Risk_Months1_NonDelq
GROUP BY Durable_Key
	,[Master Account Key]
	,CONCAT(Durable_Key,[Master Account Key])
--ORDER BY [Social Security Number], extract_datepart

--select *
--from ANALYTICS.DBO.CC_Risk_Util_Months
--where Durable_Key = 15599543	
--and [Master Account Key] in (18337815,23109900,23961314)

--SELECT AVG(Overlimit_Months)
--FROM ANALYTICS.DBO.CC_Risk_Util_Months



-------BT vs Non-BT

DROP TABLE IF EXISTS #BT_SUBSET
SELECT extract_datepart 
	,fullExtractdate
	,[RDT_TRANSACTION_DATE]
	,RDT_CHD_ACCOUNT_NUMBER
	,[Account Number]
	,[Social Security Number]
	,Durable_Key
	,[Master Account Key]
	,[Last Statement Balance Amount]
	,RDT_TRANSACTION_AMOUNT
	,RDT_MRCH_SIC_CODE
	,Extract_ACCOUNT_OPEN_DATE
	,AA.[Account System Entry Date]
INTO #BT_SUBSET
FROM TMGData..cardholder AA
LEFT JOIN TMGData..TMGCompleteCC BB
	ON CAST(LEFT(CONCAT(20,[RDT_TRANSACTION_DATE]),6) AS INT) = AA.extract_datepart 
	AND BB.RDT_CHD_ACCOUNT_NUMBER = AA.[Account Number]
WHERE 1=1
	AND [Social Security Number] IS NOT NULL 
	AND [Social Security Number]<>0
	AND Active_Flag = 1
	AND [External Status Code] in ('') 


--SELECT extract_datepart 
--	,[RDT_TRANSACTION_DATE]
--	,RDT_CHD_ACCOUNT_NUMBER
--	,[Account Number]
--	,[Social Security Number]
--	,Durable_Key
--	,[Master Account Key]
--	,[Last Statement Balance Amount]
--	,RDT_TRANSACTION_AMOUNT
--	,RDT_MRCH_SIC_CODE
--	,Extract_ACCOUNT_OPEN_DATE
--FROM TMGData..cardholder AA
--LEFT JOIN TMGData..TMGCompleteCC BB
--	ON CAST(LEFT(CONCAT(20,[RDT_TRANSACTION_DATE]),6) AS INT) = AA.extract_datepart 
--	AND BB.RDT_CHD_ACCOUNT_NUMBER = AA.[Account Number]
--WHERE RDT_MRCH_SIC_CODE IN (0,3,6)
--	AND RDT_CHD_ACCOUNT_NUMBER = '5184811000057049'
--	AND extract_datepart = '202305'
--	AND LEFT([RDT_TRANSACTION_DATE],4) = '2305'


DROP TABLE IF EXISTS #BT_SUBSET_MIN_OPENDATE
SELECT Durable_Key
	,[Master Account Key]
	,CONCAT(Durable_Key,[Master Account Key]) AS CONCAT_ID
	,MIN([Account System Entry Date]) AS MIN_OPEN_DATE
	--,MIN(CASE WHEN RDT_MRCH_SIC_CODE IN (0,3,6) THEN [Account System Entry Date] ELSE '2999-99-31' END) AS MIN_BT_OPEN_DATE
INTO #BT_SUBSET_MIN_OPENDATE
FROM #BT_SUBSET
WHERE 1=1
	--AND RDT_MRCH_SIC_CODE IN (0,3,6)
GROUP BY Durable_Key
	,[Master Account Key]
	,CONCAT(Durable_Key,[Master Account Key])


DROP TABLE IF EXISTS #BT_NonBT
SELECT A.*
	,CONCAT_ID
	,MIN_OPEN_DATE
	,CASE WHEN EOMONTH(fullExtractdate) = EOMONTH(MIN_OPEN_DATE) AND RDT_MRCH_SIC_CODE IN (0,3,6) THEN 1 ELSE 0 END AS BT_NonBT
INTO #BT_NonBT
FROM #BT_SUBSET A
LEFT JOIN #BT_SUBSET_MIN_OPENDATE B
	ON A.Durable_Key = B.Durable_Key
	AND A.[Master Account Key] = B.[Master Account Key]


--SELECT Durable_Key
--	,[Master Account Key]
--	,COUNT(DISTINCT [Account System Entry Date])
--FROM #BT_SUBSET
--GROUP BY Durable_Key
--	,[Master Account Key]
--ORDER BY 3 DESC


--SELECT *
--FROM #BT_SUBSET
--WHERE Durable_Key = 9597333
--AND [Master Account Key] = 17469154
--ORDER BY extract_datepart


--SELECT *
--FROM #BT_NonBT
--WHERE Durable_Key = 16919651	
--AND [Master Account Key] = 19878105
--ORDER BY extract_datepart

--SELECT *
--FROM #BT_NonBT
--WHERE RDT_CHD_ACCOUNT_NUMBER IS NULL


DROP TABLE IF EXISTS ANALYTICS.DBO.BT_NonBT
SELECT Durable_Key
	,[Master Account Key]
	,CONCAT_ID
	,MAX(BT_NonBT) AS BT_NonBT_Flag
INTO ANALYTICS.DBO.BT_NonBT
FROM #BT_NonBT
GROUP BY Durable_Key
	,[Master Account Key]
	,CONCAT_ID


--DECLARE @date_cc AS VARCHAR(6) =(Select max(extract_datepart) from TMGData.dbo.cardholder)
--DECLARE @DATE_CC_12M AS VARCHAR(6)=(SELECT CASE WHEN RIGHT(MAX(extract_datepart),2)<=11 THEN MAX(extract_datepart) - 99 ELSE MAX(extract_datepart) - 11 END AS DATE_12M
--									FROM TMGData.dbo.cardholder )

DROP TABLE IF EXISTS ANALYTICS.DBO.BT_NonBT_MONTHS
SELECT fullExtractdate 
	,Durable_Key
	,[Master Account Key]
	,CONCAT_ID
	,MAX(BT_NonBT) AS BT_NonBT_Flag
INTO ANALYTICS.DBO.BT_NonBT_MONTHS
FROM #BT_NonBT
WHERE extract_datepart BETWEEN @DATE_CC_12M AND @date_cc
GROUP BY fullExtractdate
	,Durable_Key
	,[Master Account Key]
	,CONCAT_ID


--SELECT EOMONTH(fullExtractdate)
--	,BT_NonBT_Flag
--	,COUNT(*)
--FROM ANALYTICS.DBO.BT_NonBT_MONTHS
--GROUP BY EOMONTH(fullExtractdate)
--	,BT_NonBT_Flag
--ORDER BY EOMONTH(fullExtractdate)
--	,BT_NonBT_Flag



END




